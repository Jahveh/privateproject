package com.menards.ssc.test.api.endpoint;

import org.testng.annotations.Test;
import java.net.URI;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class TestCategoryRefreshEndpoint {
    private String credential = "8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92";
    
    @Test(enabled = true)
    public void testCategoryRefresh() {
        ClientConfig config = new DefaultClientConfig();
        Client client = Client.create(config);
        try{
	        URI uri = UriBuilder.fromUri("http://stage-ssc.mymenards.com/ssc/rest/category/refresh").build();
	        WebResource service = client.resource(uri);
	        service.header("category-refresh-credential",credential).get(String.class);
        }catch(Exception e) {
        	e.printStackTrace();
        }
    }
}
