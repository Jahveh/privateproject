package com.menards.ssc.test.dao;

import java.util.List;

import javax.annotation.Resource;

import org.broadleafcommerce.core.catalog.domain.Category;
import org.broadleafcommerce.core.catalog.domain.CategoryImpl;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.testng.annotations.Test;

import com.menards.ssc.dao.product.MenardProductDao;
import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardProductOption;
import com.menards.ssc.test.base.BaseTest;

public class ProductDaoTest extends BaseTest {

	@Resource(name = "blProductDao")
    private MenardProductDao productDao; 
	
	private static final Integer PAGE_SIZE = 10;
	private static final Long categoryId = 100102L;
	private static final Long productId = 9370000L;
	
	@Test
    public void testFindProductsForCategory() throws Exception {
    	List<Product> products = productDao.findProductsByCategoryId(categoryId, PAGE_SIZE, 0, null, null);
    	assert products.size() > 0 && products.size() <= PAGE_SIZE;
    }
	
	@Test
    public void testCountProductForCategory(){
    	Category category = new CategoryImpl();
    	category.setId(categoryId);
    	Long totalResults = productDao.countProductForCategory(category, null);
    	assert totalResults > 0 ;
    }
	
	@Test
	public void testGetAccessoriesByProduct(){
		MenardProduct product = productDao.getMenardProductById(productId);
		assert product != null;
		List<MenardProductOption> options = productDao.getAccessoriesByProduct(product);
		assert options != null;
	}
	
//	@Test
//	public void testGetMenardSkuStatus(){
//		String storeId = "1002";
//		String skuCode = "9370000";
//		MenardSkuStatus status = productDao.getMenardSkuStatus(storeId, skuCode);
//		assert status != null;
//		assert storeId.equals(status.getPk().getStoreId());
//		assert skuCode.equals(status.getPk().getSkuCode());
//	}
	
//	@Test
//	public void testFindMenardSkuStatus(){
//		String storeId = "1002";
//		Set<Long> set = new HashSet<Long>();
//		set.add(1231305l);
//		set.add(1467701l);
//		set.add(1467707l);
//		set.add(1467713l);
//		set.add(1467719l);
//		set.add(1467725l);		
//		List<MenardSkuStatus> status = productDao.findMenardSkuStatus(storeId, set);
//		assert status != null && status.size() == 6;
//	
//	}

	
}
