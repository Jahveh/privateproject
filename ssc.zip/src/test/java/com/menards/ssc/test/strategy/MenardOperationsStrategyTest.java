package com.menards.ssc.test.strategy;

import java.util.Arrays;

import org.apache.commons.lang.StringUtils;
import org.testng.annotations.Test;

import com.menards.ssc.domain.order.MenardDiscreteOrderItemImpl;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.strategy.approve.MenardItemApproveStrategy;
import com.menards.ssc.strategy.approve.MenardOperationsStrategy;

public class MenardOperationsStrategyTest {

	private MenardItemApproveStrategy strategy = new MenardOperationsStrategy();

	private MenardOrderItem item = new MenardDiscreteOrderItemImpl();

	private String fulfillerCode = MenardFulfillerType.OPERATIONS.getKey();

	@Test(groups =  {"OrderItemApproveStrategy"})
	public void operationsStrategyTest() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException {
		
		for (String type : Arrays.asList(MenardOrderRequestType.Contractor.getKey(), 
				MenardOrderRequestType.Human_Resources.getKey(), 
				MenardOrderRequestType.Scheduling_1.getKey(),
				MenardOrderRequestType.Scheduling_2.getKey(),
				MenardOrderRequestType.Training.getKey(),
			MenardOrderRequestType.Security.getKey())) {
		item.setFulfillerTypeCode(fulfillerCode);
		item.setRequestType(type);

		//Go order and has the same fulfiller type		
		item.setStatus(null);
		item.setStatus(strategy.getInitStatus(item, true, fulfillerCode));
		assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());

		// Not Go order
		item.setStatus(null);
		item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
		assert MenardOrderItemStatus.PENDING_GM.getValue().equals(item.getStatus());

		// Not Go order and pending gm
		item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.PENDING_GO.getValue().equals(item.getStatus());

		// Not Go order and pending gm
		item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
		assert MenardOrderItemStatus.GM_DECLINED.getValue().equals(item.getStatus());

		// Not Go order and pending go
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());

		// Not Go order and pending go
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.BACKORDERED.getKey()));
		assert MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());

		// Not Go order and pending go
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
		assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());

		// Not Go order and pending bo
		
		item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
		assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());

		// Not Go order and pending bo
		
		item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());
	}
}
	@Test(expectedExceptions = {RuntimeException.class})
	public void unnormalConditionEmptyTest() {
		assert StringUtils.isEmpty(strategy.getInitStatus(null, false, null));
		assert StringUtils.isEmpty(strategy.getInitStatus(null, true, null));
		assert StringUtils.isEmpty(strategy.nextStage(null, MenardItemApproveAction.DECLINED.getKey()));
	}

}