package com.menards.ssc.test.strategy;

import org.apache.commons.lang.StringUtils;
import org.testng.annotations.Test;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.order.MenardDiscreteOrderItemImpl;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.strategy.approve.MenardItemApproveStrategy;
import com.menards.ssc.strategy.approve.MenardMidwestStrategy;

public class MenardMidwestStrategyTest {

	private MenardItemApproveStrategy strategy = new MenardMidwestStrategy();

	private MenardOrderItem item = new MenardDiscreteOrderItemImpl();

	private String fulfillerCode = MenardFulfillerType.MIDWEST.getKey();

	@Test(groups =  {"OrderItemApproveStrategy"})
	public void employmentStrategyTest() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException {

		item.setFulfillerTypeCode(fulfillerCode);
        item.setRequestType(MenardOrderRequestType.Literature.getKey());

		// Go order and has the same fulfiller type
		item.setStatus(null);
		item.setDcItem(CommonConstant.TRUE_STRING);
		item.setStatus(strategy.getInitStatus(item, true, fulfillerCode));
		assert MenardOrderItemStatus.BATCHED_FOR_DC.getValue().equals(item.getStatus());

		item.setStatus(null);
		item.setDcItem(CommonConstant.FALSE_STRING);
		item.setStatus(strategy.getInitStatus(item, true, fulfillerCode));
		assert MenardOrderItemStatus.COMPLETED.getValue().equals(item.getStatus());

		// Not Go order
		item.setStatus(null);
		item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
		assert MenardOrderItemStatus.PENDING_GM.getValue().equals(item.getStatus());

		// Not Go order and pending gm
		item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		item.setDcItem(CommonConstant.TRUE_STRING);
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.BATCHED_FOR_DC.getValue().equals(item.getStatus());

		item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		item.setDcItem(CommonConstant.FALSE_STRING);
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.PENDING_GO.getValue().equals(item.getStatus());

		// Not Go order and PENDING_GO
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setDcItem(CommonConstant.TRUE_STRING);
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.BATCHED_FOR_DC.getValue().equals(item.getStatus());

		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setDcItem(CommonConstant.FALSE_STRING);
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.COMPLETED.getValue().equals(item.getStatus());

		// pending bm and decline
		item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
		assert MenardOrderItemStatus.GM_DECLINED.getValue().equals(item.getStatus());

		// pending go and decline
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
		assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());

		// pending go and back order
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.BACKORDERED.getKey()));
		assert MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());

		//back order and approve
		item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
		item.setDcItem(CommonConstant.TRUE_STRING);
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.BATCHED_FOR_DC.getValue().equals(item.getStatus());

		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setDcItem(CommonConstant.FALSE_STRING);
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.COMPLETED.getValue().equals(item.getStatus());
		//back order and decline
		item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
		assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());

	}
	
	@Test(expectedExceptions = {RuntimeException.class})
	public void unnormalConditionEmptyTest() {
		assert StringUtils.isEmpty(strategy.getInitStatus(null, false, null));
		assert StringUtils.isEmpty(strategy.getInitStatus(null, true, null));
		assert StringUtils.isEmpty(strategy.nextStage(null, MenardItemApproveAction.DECLINED.getKey()));
	}
}