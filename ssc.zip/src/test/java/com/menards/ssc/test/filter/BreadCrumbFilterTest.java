package com.menards.ssc.test.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import junit.framework.Assert;

import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockServletContext;
import org.testng.annotations.Test;

import com.menards.ssc.domain.breadcrumb.BreadCrumbConfig;
import com.menards.ssc.filter.BreadCrumbFilter;
import com.menards.ssc.listener.breadcrumb.BreadCrumbConfigPreLoader;

public class BreadCrumbFilterTest {
	
	
	@Test
	public void testFilter() throws IOException, ServletException{
		BreadCrumbFilter filter = new BreadCrumbFilter();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setContextPath("contextPath");
		request.setRequestURI("contextPath/home/page?hello=world");
		
		HttpServletResponse response = new MockHttpServletResponse();
		HttpSession session = Mockito.mock(HttpSession.class);
		request.setSession(session);
		ServletContext servletContext = new MockServletContext();
		
		Map<String, List<BreadCrumbConfig>> configMap = new HashMap<String, List<BreadCrumbConfig>>();
		BreadCrumbConfig config1 = new BreadCrumbConfig();
		config1.setCrumbLink("config1_crumb_link");
		config1.setCrumbName("config1_crumb_name");
		config1.setCrumbOrder(10);
		config1.setPageUrl("/home/page");
		BreadCrumbConfig config2 = new BreadCrumbConfig();
		config2.setCrumbLink("config2_crumb_link");
		config2.setCrumbName("config2_crumb_name");
		config2.setCrumbOrder(20);
		config2.setPageUrl("/home/page");
		List<BreadCrumbConfig> configList = new ArrayList<BreadCrumbConfig>();
		configList.add(config1);
		configList.add(config2);
		configMap.put("/home/page", configList);
		
		servletContext.setAttribute(BreadCrumbConfigPreLoader.BREAD_CRUMB_CONFIG_MAP_SERVLET_CONTEXT_KEY, configMap);
		Mockito.when(session.getServletContext()).thenReturn(servletContext);
		filter.doFilter(request, response, Mockito.mock(FilterChain.class));
		Assert.assertEquals("[{\"pageUrl\":\"/home/page\",\"crumbName\":\"config1_crumb_name\",\"crumbLink\":\"config1_crumb_link\",\"crumbOrder\":10},{\"pageUrl\":\"/home/page\",\"crumbName\":\"config2_crumb_name\",\"crumbLink\":\"config2_crumb_link\",\"crumbOrder\":20}]",request.getAttribute("breadCrumbJson"));
		
		
	}
	
}
