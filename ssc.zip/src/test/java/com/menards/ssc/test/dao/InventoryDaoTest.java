package com.menards.ssc.test.dao;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.menards.ssc.dao.inventory.MenardInventoryDao;
import com.menards.ssc.domain.inventory.MenardInventoryDTO;
import com.menards.ssc.test.base.BaseTest;

public class InventoryDaoTest extends BaseTest {

	@Resource
	private MenardInventoryDao menardInventoryDao;

	@Test
	@Transactional
	public void getInventory() {

		List<MenardInventoryDTO> inventory = menardInventoryDao.getInventory();
		assert inventory.size() > 0;

	}
	
	
	@Test
	@Transactional
	public void getInventoryBySku() {

		String sku = "9031550";
		List<MenardInventoryDTO> inventory = menardInventoryDao.getInventoryBySku(sku);
		assert inventory.size() > 0;

	}
}
