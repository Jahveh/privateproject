package com.menards.ssc.test.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts.mock.MockHttpServletRequest;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.testng.annotations.Test;

import com.menards.ssc.controller.inventory.InventoryController;
import com.menards.ssc.test.base.BaseTest;

public class InventoryControllerTest extends BaseTest {

	@Resource(name = "menardInventoryController")
	private InventoryController inventoryController;

	@Test
	@Transactional
	public void testGetInvQuantityOnHand() throws Exception {

		Model model = new ExtendedModelMap();
		HttpServletRequest request = new MockHttpServletRequest();
		String mv = inventoryController.getInvQuantityOnHand(model, request);
		assert "inventory/monthlySupplyInventory".equals(mv);

	}

	@Test
	@Transactional
	public void testUpdateInventory() throws Exception {

		Model model = new ExtendedModelMap();

		String[] sku = {"9031550"};
		String[] quantity = {"66"};
		String mv = inventoryController.updateInventory(model, quantity,sku);
		assert "inventory/confirm".equals(mv);
		
		
		String[] skuFalse = {"9031550"};
		String[] quantityFalse = {"66666"};
		String mvFalse = inventoryController.updateInventory(model, quantityFalse,skuFalse);
		assert "inventory/monthlySupplyInventory".equals(mvFalse);	

	}
	
	@Test
	@Transactional
	public void testPrint() throws Exception {

		Model model = new ExtendedModelMap();
		HttpServletRequest request = new MockHttpServletRequest();
		String mv = inventoryController.print(model, request);
		assert "inventory/print".equals(mv);

	}
	
	@Test
	@Transactional
	public void testInventory() throws Exception {		
		String mv = inventoryController.inventory();
		assert "redirect:/inventory/getInvQuantityOnHand".equals(mv);

	}
	
	

}
