package com.menards.ssc.test.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.mail.SimpleMailMessage;
import org.testng.annotations.Test;

import com.menards.ssc.service.email.EmailSenderService;
import com.menards.ssc.test.base.BaseTest;

public class EmailSenderServiceTest extends BaseTest {

	@Resource(name = "emailSenderService")
	private EmailSenderService emailSenderService;

	@Test
	public void testSendEmailWithTemplate() {		
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo("leo.yang@bleum.com");
		message.setFrom("leo.yang@bleum.com");	
		message.setCc("Nancy.Tang@bleum.com");
		message.setSubject("adsfasdfadf subject");
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("name", "Leo.yang");
		model.put("storeNumber", "1111");			
		model.put("menardsSku", "1ff11");
		model.put("ftDescription", "114ewrtw11");			
		model.put("quantity", "11opiuop11");
		model.put("orderItemLineNumber", "112435211");			
		model.put("orderId", "11xzvz11");
		model.put("attentionName", "General Manager");
		
		model.put("storeName", "11wrqw11");
		model.put("storeCity", "11zxcv11");
		model.put("storeState", "11iuoyo11");			
		model.put("storeZip", "11erq11");			
		model.put("storePhone", "11896811");			
		model.put("storeAddress", "11er11");		
		boolean result = emailSenderService.sendEmailWithTemplate(message, "com/menard/ssc/test/service/factTagEmail.vm", model);
		assert result;
	}
	
	@Test
	public void testSendEmaile() {		
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo("leo.yang@bleum.com");
		message.setFrom("leo.yang@bleum.com");
		message.setCc("Nancy.Tang@bleum.com");
		message.setText("This is a text email");
		boolean result = emailSenderService.sendTextEmail(message);
		assert result;
	}
}
