package com.menards.ssc.test.listener;

import java.lang.reflect.Field;

import javax.annotation.Resource;
import javax.servlet.ServletContext;

import org.broadleafcommerce.core.catalog.service.CatalogService;
import org.mockito.Mockito;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.mock.web.MockServletContext;
import org.springframework.web.context.WebApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.menards.ssc.listener.navigation.CategoryPreLoader;
import com.menards.ssc.service.catalog.CategoryTreeService;
import com.menards.ssc.test.base.BaseTest;

public class CategoryPreLoaderTest extends BaseTest{
	@Resource(name = "blCatalogService")
	private CatalogService catalogService;
	
	@Test
	public void testPreloader() throws SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException{
		ContextRefreshedEvent event = Mockito.mock(ContextRefreshedEvent.class);
		WebApplicationContext appContext = Mockito.mock(WebApplicationContext.class);
		ServletContext servletContext = new MockServletContext();
		Mockito.when(event.getApplicationContext()).thenReturn(appContext);
		Mockito.when(appContext.getServletContext()).thenReturn(servletContext);
		CategoryPreLoader preloader = new CategoryPreLoader();
		Field field = CategoryPreLoader.class.getDeclaredField("catalogService");
		field.setAccessible(true);
		field.set(preloader, catalogService);

		preloader.onApplicationEvent(event);
		
		Assert.assertTrue(servletContext.getAttribute(CategoryTreeService.CATEGORY_TREE_DICTIONARY_SERVLET_CONTEXT_KEY)!=null);
		Assert.assertEquals(preloader.getOrder(), 10);

	}
}
