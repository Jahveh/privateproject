package com.menards.ssc.test.dao;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.menards.ssc.dao.sign.MenardColorSignDao;
import com.menards.ssc.dao.sign.MenardSignDao;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.catalog.SignDTO;
import com.menards.ssc.domain.setremodel.SetRemodelDTO;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.domain.sign.SignSaleInfo;
import com.menards.ssc.domain.sign.SignVersion;
import com.menards.ssc.domain.sign.Stock;
import com.menards.ssc.test.base.BaseTest;
import com.menards.ssc.util.MenardUtil;

public class MenardSignDaoTest extends BaseTest {

	@Resource
	private MenardSignDao menardSignDao;
	
	@Resource
	private MenardColorSignDao menardColorSignDao;

	/*@Test*/	
	@Transactional
	public void findSignPage() {
		Integer page = 1;
		Integer size = 10;
		String  queryString = null;		
		queryString = "blade";
		initContext("jreynold");
		
		SearchResult<Sign> result = menardSignDao.findSignPage(page, size, queryString);
		System.out.println(result.getResult().size());
		assert result.getResult().size() > 0;		
		
		initContext("tsmith_SPR");		
		result = menardSignDao.findSignPage(page, size, queryString);
		System.out.println(result.getResult().size());
		assert result.getResult().size() > 0;
	}
	
	
		
	@Test(groups="getPrePrintedFactTags")
	public void getPrePrintedFactTags() {		
		List<Sign> result = menardSignDao.getPrePrintedFactTags("3490413", Integer.MAX_VALUE, 0);
		assert result.size() >= 1;
	}
	
	/*@Test	*/
	@Transactional
	public void findSaleSignPage() {		
		Integer page = 1;
		Integer size = 10;
		String  queryString = null;		
		queryString = "blade";		
		SearchResult<Sign> result = menardSignDao.findSaleSignPage(page, size, queryString, 3011);
		assert result.getResult().size() == 1;	
	}
	
	/*@Test*/
	@Transactional
	public void getSaleSigns() {
		List<SignSaleInfo> list = menardSignDao.getSaleSigns(2304999, 3011);
		assert list.size() >=0;	 
	}
	
	/*@Test*/
	public void testGetSetRemodelByStoreId(){
		String storeId = "3011";
		SetRemodelDTO remodel =  menardSignDao.getSetRemodelByStoreId(storeId);
		assert remodel != null;
	}
	
	/*@Test*/
	@Transactional("signTransactionManager")
	public void testUpdateRemodelDate(){
		SetRemodelDTO remodel = new SetRemodelDTO();
		remodel.setStoreId("3011");
		remodel.setStartDate(MenardUtil.parseDate("2014-02-14", "yyyy-MM-dd"));
		remodel.setEndDate(MenardUtil.parseDate("2014-02-16", "yyyy-MM-dd"));
		int count =  menardSignDao.updateRemodelDate(remodel);
		assert count > 0 ;
		SetRemodelDTO result =  menardSignDao.getSetRemodelByStoreId(remodel.getStoreId());
		
		assert result != null;
		assert remodel.getStartDate().equals(result.getStartDate());
		assert remodel.getEndDate().equals(result.getEndDate());
	}
	
	/*@Test*/
	@Transactional
	public void testInsertSignOrder(){		
		SignDTO signDTO = new SignDTO();		
		SignVersion sign = new SignVersion();
		sign.setSignId(11569);
		sign.setDept(2);
		sign.setVersionId(10);
		sign.setPromonbr(5);
		sign.setLaminate(3);
		sign.setSignname("3351830");
		signDTO.setYard("3204");
		signDTO.setEmail("Jason@bleum.com");
		Stock stock = new Stock();
		stock.setStockId(300);
		
		signDTO.setSignVersion(sign);
		signDTO.setStock(stock);
		Map<Integer, String> map = menardSignDao.insertSignOrder(signDTO);
		assert map.size() > 0;
	}
}
