package com.menards.ssc.test.service;

import com.menards.ssc.domain.catalog.MenardProductDTO;
import com.menards.ssc.domain.catalog.ProductDetailDTO;
import com.menards.ssc.service.catalog.MenardCatalogService;
import com.menards.ssc.test.base.BaseTest;

import org.broadleafcommerce.common.web.BroadleafRequestContext;
import org.broadleafcommerce.core.catalog.domain.Category;
import org.broadleafcommerce.core.catalog.domain.CategoryImpl;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import java.util.List;

public class CatalogServiceTest extends BaseTest{

	
    @Resource(name = "blCatalogService")
    private MenardCatalogService catalogService;
    
    private static final Integer PAGE_SIZE = 10;
	private static final Long categoryId = 100102L;
	private  static Long  PRODUCT_ID = 9370000L;
	private  static Long  SKU_ID = 9370000L;
	
	@BeforeTest
	public void initRequest(){
		//mock reqeust context
		HttpServletRequest request = new MockHttpServletRequest();
		BroadleafRequestContext broadleafRequestContext = new BroadleafRequestContext();
		broadleafRequestContext.setRequest(request);
		BroadleafRequestContext.setBroadleafRequestContext(broadleafRequestContext);
	}

    @Test
    public void testGetAllCategories() throws Exception {
    	List<Category> allCategories = catalogService.findAllCategories();
    	assert allCategories.size() > 0;
    }
    
    
    @Test
    public void testFindProductsForCategory() throws Exception {
    	Category category = new CategoryImpl();
    	category.setId(categoryId);
    	List<Product> products = catalogService.findProductsByCategoryId(category.getId(), PAGE_SIZE, 0);
    	assert products.size() > 0 && products.size() <= PAGE_SIZE;
    }
    
    @Test
    public void testCountProductForCategory(){
    	Category category = new CategoryImpl();
    	category.setId(categoryId);
    	Long totalResults = catalogService.countProductForCategory(category, null);
    	assert totalResults > 0 ;
    }
    
    @Test
    @Transactional("blTransactionManager")
    public void testGetMenardProductById() throws ItemNotFoundException{
    	MenardProductDTO dto = catalogService.getMenardProductById(PRODUCT_ID);
    	assert dto!= null;
    	assert dto.getProduct() != null;
    	assert dto.getProduct().getProductAttributes() != null;
    	
    	if(dto.getProduct().getDefaultSku() != null){
    		assert dto.getSelectedSku() != null;
    	}
    	
    }
    
    @Test
    @Transactional("blTransactionManager")
    public void testGetMenardProductDetail() throws ItemNotFoundException{
    	ProductDetailDTO dto = catalogService.getMenardProductDetail(PRODUCT_ID, SKU_ID);
    	assert dto!= null;
    	
    	//assert dto.getDescriptionShort() != null;
    	
    }
}
