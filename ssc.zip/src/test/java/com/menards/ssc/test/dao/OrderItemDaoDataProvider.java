package com.menards.ssc.test.dao;

import java.util.Date;

import org.broadleafcommerce.core.order.service.type.OrderItemType;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.testng.annotations.DataProvider;

import com.menards.ssc.domain.order.MenardDiscreteOrderItemImpl;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderImpl;
import com.menards.ssc.domain.order.MenardOrderItem;

public class OrderItemDaoDataProvider {

    @DataProvider(name = "basicOrderItem")
    public static Object[][] provideBasicCategory() {

    	 MenardOrder order = new MenardOrderImpl();
    	 order.setId(100000000l);
    	 order.setLoadOrderId(100000000l);
		 order.setStatus(OrderStatus.IN_PROCESS);	
		 order.setSubmitDate(new Date());
		 
		 MenardOrderItem item = new MenardDiscreteOrderItemImpl();
		 item.setOrderItemType(OrderItemType.DISCRETE);
		 item.setOrder(order);
		 item.setQuantity(1);
		 order.getOrderItems().add(item);
        return new Object[][] { { order } };
    }
}
