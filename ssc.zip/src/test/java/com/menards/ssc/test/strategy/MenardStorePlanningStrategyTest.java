package com.menards.ssc.test.strategy;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.testng.annotations.Test;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.order.MenardDiscreteOrderItemImpl;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.strategy.approve.MenardItemApproveStrategy;
import com.menards.ssc.strategy.approve.MenardStorePlanningStrategy;

public class MenardStorePlanningStrategyTest {

	private MenardItemApproveStrategy strategy = new MenardStorePlanningStrategy();
	
	private MenardOrderItem item = new MenardDiscreteOrderItemImpl();
	
	private String fulfillerCode = MenardFulfillerType.STORE_PLANNING.getKey();
	
	private Set<String> requestTypes = new HashSet<String>();
	{
		requestTypes.add(MenardOrderRequestType.GSS.getKey());
		requestTypes.add(MenardOrderRequestType.GSS_Fixture.getKey());
		requestTypes.add(MenardOrderRequestType.GSS_Pallet_Racking.getKey());
	}
	
	@Test(groups = {"OrderItemApproveStrategy"})
	public void signShopStrategyTest() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException {
		
		item.setFulfillerTypeCode(fulfillerCode);
		for (String type : requestTypes) {
			
			//Go order and not dc item
			item.setRequestType(type);
			item.setStatus(null);
			item.setDcItem(CommonConstant.FALSE_STRING);
			item.setStatus(strategy.getInitStatus(item, true, fulfillerCode));
			assert MenardOrderItemStatus.COMPLETED.getValue().equals(item.getStatus());
			
			//Go order and dc item
			item.setDcItem(CommonConstant.TRUE_STRING);
			item.setStatus(strategy.getInitStatus(item, true, fulfillerCode));
			assert MenardOrderItemStatus.BATCHED_FOR_DC.getValue().equals(item.getStatus());
			
			//not Go order
			item.setStatus(null);
			item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
			assert MenardOrderItemStatus.PENDING_GM.getValue().equals(item.getStatus());
			
			//Current pending GM and approve
			item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
			item.setStoreRemodel(CommonConstant.TRUE_STRING);
			item.setDcItem(CommonConstant.FALSE_STRING);
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.PENDING_GO.getValue().equals(item.getStatus());
			
			//Current pending GM and approve
			item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
			item.setStoreRemodel(CommonConstant.TRUE_STRING);
			item.setDcItem(CommonConstant.TRUE_STRING);
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.BATCHED_FOR_DC.getValue().equals(item.getStatus());
			
			//Current pending GO and approve
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			item.setDcItem(CommonConstant.TRUE_STRING);
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.BATCHED_FOR_DC.getValue().equals(item.getStatus());
			
			//Current pending GO and approve
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			item.setDcItem(CommonConstant.FALSE_STRING);
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.COMPLETED.getValue().equals(item.getStatus());
			
			//Current pending GO and decline
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			item.setDcItem(CommonConstant.TRUE_STRING);
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
			assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
			
			//Current pending GO and backorder
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.BACKORDERED.getKey()));
			assert MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());
			
			//Current back order, approve and not is dc
			item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
			item.setDcItem(CommonConstant.FALSE_STRING);
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.COMPLETED.getValue().equals(item.getStatus());
			
			//Current back order, approve and dc
			item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
			item.setDcItem(CommonConstant.TRUE_STRING);
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.BATCHED_FOR_DC.getValue().equals(item.getStatus());
			
			//Current back order and decline
			item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
			assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
		}
	}
	
	@Test(expectedExceptions = {RuntimeException.class})
	public void unnormalConditionEmptyTest() {
		assert StringUtils.isEmpty(strategy.getInitStatus(null, false, null));
		assert StringUtils.isEmpty(strategy.getInitStatus(null, true, null));
		assert StringUtils.isEmpty(strategy.nextStage(null, MenardItemApproveAction.DECLINED.getKey()));
	}

}