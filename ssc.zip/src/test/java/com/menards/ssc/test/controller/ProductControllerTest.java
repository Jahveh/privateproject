package com.menards.ssc.test.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.testng.annotations.Test;

import com.menards.ssc.controller.catalog.ProductController;
import com.menards.ssc.test.base.BaseTest;

public class ProductControllerTest  extends BaseTest{

	protected static final Long productId = 9370000L;
	protected static final Long skuId = 9370000L;
	
	
	@Resource(name = "blProductController")
	private ProductController productController;
	
	@Test
	@Transactional
	public void testProductDetail() throws ItemNotFoundException{
		Model model = new ExtendedModelMap();
		HttpServletRequest request = new MockHttpServletRequest();
		String viewName = productController.productDetail(productId, skuId, true, null, model, null, request);
		assert "catalog/product".equals(viewName);
	}
}
