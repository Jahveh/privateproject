package com.menards.ssc.test.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.menards.ssc.domain.inventory.MenardInventoryDTO;
import com.menards.ssc.service.inventory.MenardInventoryService;
import com.menards.ssc.test.base.BaseTest;

public class InventoryServiceTest extends BaseTest{

	@Resource
	private MenardInventoryService menardInventoryService;

	@Test
	@Transactional
	public void getInventory() {

		List<MenardInventoryDTO> inventory = menardInventoryService.getInventory();
		assert inventory.size() > 0;

	}	
	
	@Test
	@Transactional
	public void getInventoryBySku() {
		
		String[] sku = {"9031550"};
		String[] quantity = {"66"};
		List<MenardInventoryDTO> inventory = menardInventoryService.updateInventory(sku, quantity);
		assert inventory.size() == 0;
		
		
		String[] skuFalse = {"9031550"};
		String[] quantityFalse = {"66666"};
		List<MenardInventoryDTO> inventoryFalse = menardInventoryService.updateInventory(skuFalse, quantityFalse);
		assert inventoryFalse.size() > 0;

	}
}
