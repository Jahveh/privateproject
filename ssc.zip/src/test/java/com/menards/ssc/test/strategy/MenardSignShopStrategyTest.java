package com.menards.ssc.test.strategy;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.testng.annotations.Test;

import com.menards.ssc.domain.order.MenardDiscreteOrderItemImpl;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.service.catalog.MenardColorSignService;
import com.menards.ssc.strategy.approve.MenardItemApproveStrategy;
import com.menards.ssc.strategy.approve.MenardSignShopStrategy;

public class MenardSignShopStrategyTest {

	private MenardColorSignService mockedService = mock(MenardColorSignService.class);

	private MenardItemApproveStrategy strategy = new MenardSignShopStrategy();
	
	private MenardOrderItem item = new MenardDiscreteOrderItemImpl();

	private Set<String> otherSignTypes = new HashSet<String>();
	{
		otherSignTypes.add(MenardOrderRequestType.Green_6mm.getKey());
		otherSignTypes.add(MenardOrderRequestType.Green_3mm.getKey());
		otherSignTypes.add(MenardOrderRequestType.White_6mm.getKey());
		otherSignTypes.add(MenardOrderRequestType.White_3mm.getKey());
		otherSignTypes.add(MenardOrderRequestType.Styrene_White_020.getKey());
		otherSignTypes.add(MenardOrderRequestType.Styrene_White_040.getKey());
		otherSignTypes.add(MenardOrderRequestType.Styrene_White_118.getKey());
		otherSignTypes.add(MenardOrderRequestType.White_Steel_10x16.getKey());
		otherSignTypes.add(MenardOrderRequestType.Green_Steel_16x24.getKey());
		otherSignTypes.add(MenardOrderRequestType.Plywood.getKey());
		otherSignTypes.add(MenardOrderRequestType.Flexible.getKey());
		otherSignTypes.add(MenardOrderRequestType.Sign_Shop_Other.getKey());
		item.setFulfillerTypeCode(MenardFulfillerType.SIGN_SHOP.getKey());	
	}

	@Test(groups =  {"OrderItemApproveStrategy"})
	public void signShopStrategyTest() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException {		
		Field field = MenardSignShopStrategy.class.getDeclaredField("colorSignService");
		field.setAccessible(true);
		field.set(strategy, mockedService);

		for (String type : Arrays.asList(MenardOrderRequestType.GSS_Sign.getKey(),
				MenardOrderRequestType.GSS_Sign_GM.getKey())) {
			item.setRequestType(type);
			
			//Is Go order and insert sign order successfully
			when(mockedService.saveSignOrder(item)).thenReturn(true);
			item.setStatus(strategy.getInitStatus(item, true, MenardFulfillerType.SIGN_SHOP.getKey()));
			assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());

			//Is Go order but insert sign order unsuccessfully
			when(mockedService.saveSignOrder(item)).thenReturn(false);
			item.setStatus(strategy.getInitStatus(item, true, MenardFulfillerType.SIGN_SHOP.getKey()));
			assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());

			//Is Go order but different fulfiller type
			when(mockedService.saveSignOrder(item)).thenReturn(true);
			item.setStatus(strategy.getInitStatus(item, true, MenardFulfillerType.EMPLOYMENT_OFFICE.getKey()));
			assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());
			
			//Is not Go order
			if (MenardOrderRequestType.GSS_Sign_GM.getKey().equals(type)) {
				item.setStatus(null);
				item.setStatus(strategy.getInitStatus(item, false, MenardFulfillerType.EMPLOYMENT_OFFICE.getKey()));
				assert MenardOrderItemStatus.PENDING_GM.getValue().equals(item.getStatus());
			} else {
				item.setStatus(null);
				when(mockedService.saveSignOrder(item)).thenReturn(true);
				item.setStatus(strategy.getInitStatus(item, false, MenardFulfillerType.EMPLOYMENT_OFFICE.getKey()));
				assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());
				item.setStatus(null);
				when(mockedService.saveSignOrder(item)).thenReturn(false);
				item.setStatus(strategy.getInitStatus(item, false, MenardFulfillerType.EMPLOYMENT_OFFICE.getKey()));
				assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
			}

			// Current pending GM and approve
			approveAndInsertSignOrder(item, MenardOrderItemStatus.PENDING_GM.getValue());

			// Current pending GM and Decline
			item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
			assert MenardOrderItemStatus.GM_DECLINED.getValue().equals(item.getStatus());

			// Backorder and approve
			approveAndInsertSignOrder(item, MenardOrderItemStatus.BACKORDERED.getValue());

			// Backorder and Decline
			item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
			assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
		}
	}

	@Test(groups =  {"OrderItemApproveStrategy"}, dependsOnMethods = "signShopStrategyTest")
	public void otherSignTypeTest() {
		
		for (String type : otherSignTypes) {
			item.setRequestType(type);
			
			//Go order initial status
			item.setStatus(null);
			item.setStatus(strategy.getInitStatus(item, true, MenardFulfillerType.SIGN_SHOP.getKey()));
			assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());
			
			//Not Go order initial status
			item.setStatus(null);
			item.setStatus(strategy.getInitStatus(item, false, MenardFulfillerType.SIGN_SHOP.getKey()));
			assert MenardOrderItemStatus.PENDING_GM.getValue().equals(item.getStatus());
			
			//PENDING_GM approve
			item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.PENDING_GO.getValue().equals(item.getStatus());
			
			//PENDING_GM
			item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
			assert MenardOrderItemStatus.GM_DECLINED.getValue().equals(item.getStatus());
			
			
			//PENDING_GO approve
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());
			
			//PENDING_GO decline
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
			assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
			
			//PENDING_GO back order
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.BACKORDERED.getKey()));
			assert MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());
			
			//Back order approve
			item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());
			
			//Back order decline
			item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
			assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
		}
	}

	private void approveAndInsertSignOrder(MenardOrderItem item, String status) {
		when(mockedService.saveSignOrder(item)).thenReturn(true);
		item.setStatus(status);
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());
		item.setStatus(status);
		when(mockedService.saveSignOrder(item)).thenReturn(false);
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
	}
	
	@Test(expectedExceptions = {RuntimeException.class})
	public void unnormalConditionEmptyTest() {
		assert StringUtils.isEmpty(strategy.getInitStatus(null, false, null));
		assert StringUtils.isEmpty(strategy.getInitStatus(null, true, null));
		assert StringUtils.isEmpty(strategy.nextStage(null, MenardItemApproveAction.DECLINED.getKey()));
	}

}