package com.menards.ssc.test.controller.cart.validator;

import javax.annotation.Resource;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.testng.annotations.Test;

import com.menards.ssc.controller.cart.validator.PlaceOptionFormValidator;
import com.menards.ssc.domain.order.MenardOrderOptionsDTO;
import com.menards.ssc.test.base.BaseTest;

public class PlaceOptionFormValidatorTest extends BaseTest{

	
	@Resource(name = "placeOptionFormValidator")
	private PlaceOptionFormValidator placeOptionFormValidator;
	
	@Test(dataProvider="placeOptionFormProvider", dataProviderClass=CartValidatorDataProvider.class)
	public void testDefaultValidate(MenardOrderOptionsDTO option, BindingResult errors){
		placeOptionFormValidator.validate(option, errors);
		assert errors.hasErrors();
		
		boolean dueDateErr = false;
		boolean commentErr = false;
		boolean requestByErr = false;
		for(FieldError err : errors.getFieldErrors()){
			if("dueDate".equals(err.getField()) && "cart.place.due.date.empty".equals(err.getCode())){
				dueDateErr = true;
			}else if("comment".equals(err.getField()) && "cart.place.comment.empty".equals(err.getCode())){
				commentErr = true;
			}else if("requestBy".equals(err.getField()) && "cart.place.request.by.empty".equals(err.getCode())){
				requestByErr = true;
			}
		}
		
		assert dueDateErr;
		assert commentErr;
		assert requestByErr;
		
	}
	
	@Test(dataProvider="placeOptionFormProvider", dataProviderClass=CartValidatorDataProvider.class)
	public void testValidate(MenardOrderOptionsDTO option, BindingResult errors){
		placeOptionFormValidator.validate(option, errors);
		assert errors.hasErrors();
		
		StringBuffer comment = new StringBuffer();
		for(int i=0;i<PlaceOptionFormValidator.PLACE_COMMENT_MAX_LENGTH+1;i++){
			comment.append("x");
		}
		
		StringBuffer grouping = new StringBuffer();
		for(int i=0;i<PlaceOptionFormValidator.PLACE_GROUPING_MAX_LENGTH+1;i++){
			grouping.append("x");
		}
		
		StringBuffer requestBy = new StringBuffer();
		for(int i=0;i<PlaceOptionFormValidator.PLACE_REQUEST_BY_MAX_LENGTH+1;i++){
			requestBy.append("x");
		}
		
		option.setComment(comment.toString());
		option.setGroup(grouping.toString());
		option.setRequestBy(requestBy.toString());
		placeOptionFormValidator.validate(option, errors);
		
		assert errors.hasErrors();
		
		boolean commentLengthErr = false;
		boolean groupingLengthErr = false;
		boolean requestByLengthErr = false;
		for(FieldError err : errors.getFieldErrors()){
			if("group".equals(err.getField()) && "cart.place.grouping.maxlength".equals(err.getCode())){
				groupingLengthErr = true;
			}else if("comment".equals(err.getField()) && "cart.place.comment.maxlength".equals(err.getCode())){
				commentLengthErr = true;
			}else if("requestBy".equals(err.getField()) && "cart.place.request.by.maxlength".equals(err.getCode())){
				requestByLengthErr = true;
			}
		}
		
		assert commentLengthErr;
		assert groupingLengthErr;
		assert requestByLengthErr;
	}
	
	
	@Test
	public void testSupportCls(){
		assert placeOptionFormValidator.supports(MenardOrderOptionsDTO.class);
	}
}
