/*
 * MenardsWebServiceTest
 * 
 * 2014-05-02
 *
 * Copyright (c) 2014
 * Menard Inc.
 */
package com.menards.ssc.test.webservice;

import com.menards.ssc.test.base.BaseTest;
import com.menards.ssc.webservice.MenardsWebService;
import com.menards.ssc.webservice.MenardsWebServiceImpl;
import com.menards.ssc.webservice.dto.Attribute;
import com.menards.ssc.webservice.dto.Category;
import com.menards.ssc.webservice.dto.Product;
import com.menards.ssc.webservice.dto.Sku;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.jaxws.JaxWsServerFactoryBean;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.ArrayList;

/**
 * Test Menards public web services
 */
public class MenardsWebServiceTest extends BaseTest {

    private static int STORE_NUMBER = 3011;
    private static Long SKU_ID = 1689949371993771L;
    private static Long PRODUCT_ID = 845524441814649L;
    private static Long CATEGORY_ID = 2534374302026061L;
    private static String CATEGORY_URL = "/Assortments/Kiosk/UniversalCatalog/SOS/Fixtures/BaseShoe";
    private MenardsWebService service;


    @BeforeTest
    public void init() {
        // setup testing server
        MenardsWebServiceImpl implementor = new MenardsWebServiceImpl();
        JaxWsServerFactoryBean svrFactory = new JaxWsServerFactoryBean();
        svrFactory.setServiceClass(MenardsWebService.class);
        svrFactory.setAddress("http://localhost:8080/ssc/ws/menards/v1");
        svrFactory.setServiceBean(implementor);
        svrFactory.create();

        // setup client
        JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
        factory.setServiceClass(MenardsWebService.class);
        factory.setAddress("http://localhost:8080/ssc/ws/menards/v1");
        service = (MenardsWebService) factory.create();
    }

    @Test
    public void getProduct(MenardsWebService service) {
        Product product = service.getProduct(PRODUCT_ID, STORE_NUMBER);
        assert product.getModelNum().equals("9370059");
        System.out.println("========== getProduct ==========");
        System.out.println(product);
    }

    @Test
    public void getCategoryById(MenardsWebService service) {
        Category category = service.getCategoryById(CATEGORY_ID);
        assert category.getName().equals("BaseShoe");
        System.out.println("========== getCategoryById ==========");
        System.out.println(category);
    }


    @Test
    public void getCategoryByPath(MenardsWebService service) {
        Category category = service.getCategoryByPath(CATEGORY_URL);
        assert category.getName().equals("BaseShoe");
        System.out.println("========== getCategoryByPath ==========");
        System.out.println(category);
    }


    @Test
    public void getSku(MenardsWebService service) {
        Sku sku = service.getSku(SKU_ID, STORE_NUMBER);
        assert sku.getSkuCode().equals("9000001");
        assert sku.getMenardSku().equals("9370063");
        assert sku.getDescription().equals("BROWN");
        System.out.println("========== getSku ==========");
        System.out.println(sku);
    }


    @Test
    public void getSkus(MenardsWebService service) {
        ArrayList<Sku> skus = service.getSkus(PRODUCT_ID, STORE_NUMBER);
        assert skus.size() == 1;
        System.out.println("========== getSkus ==========");
        System.out.println(skus);
    }


    @Test
    public void getCategoryAttributesById(MenardsWebService service) {
        ArrayList<Attribute> attributeList = service.getCategoryAttributesById(CATEGORY_ID);
        assert attributeList.size() > 0;
        System.out.println("========== getCategoryAttributesById ==========");
        System.out.println(attributeList);
    }


    @Test
    public void getCategoryAttributesByPath(MenardsWebService service) {
        ArrayList<Attribute> attributeList = service.getCategoryAttributesByPath(CATEGORY_URL);
        assert attributeList.size() > 0;
        System.out.println("========== getCategoryAttributesByPath ==========");
        System.out.println(attributeList);
    }


    @Test
    public void getProductAttributes(MenardsWebService service) {
        ArrayList<Attribute> attributeList = service.getProductAttributes(PRODUCT_ID);
        assert attributeList.size() > 0;
        System.out.println("========== getProductAttributes ==========");
        System.out.println(attributeList);
    }


    @Test
    public void getSkuAttributes(MenardsWebService service) {
        ArrayList<Attribute> attributeList = service.getSkuAttributes(SKU_ID);
        assert attributeList.size() > 0;
        System.out.println("========== getSkuAttributes ==========");
        System.out.println(attributeList);
    }

}