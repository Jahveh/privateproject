package com.menards.ssc.test.base;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.test.annotation.NotTransactional;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.TestContext;
import org.springframework.test.context.support.AbstractTestExecutionListener;
import org.springframework.test.context.transaction.AfterTransaction;
import org.springframework.test.context.transaction.BeforeTransaction;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionConfigurationAttributes;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionException;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.AnnotationTransactionAttributeSource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.DelegatingTransactionAttribute;
import org.springframework.transaction.interceptor.TransactionAttribute;
import org.springframework.transaction.interceptor.TransactionAttributeSource;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

@SuppressWarnings("deprecation")
public class MergeTransactionalTestExecutionListener extends AbstractTestExecutionListener {

    private static final Log logger = LogFactory.getLog(MergeTransactionalTestExecutionListener.class);

    protected final TransactionAttributeSource attributeSource = new AnnotationTransactionAttributeSource();

    private TransactionConfigurationAttributes configAttributes;

    private volatile int transactionsStarted = 0;

    private final Map<Method, TransactionContext> transactionContextCache =
            Collections.synchronizedMap(new IdentityHashMap<Method, TransactionContext>());


    @SuppressWarnings("serial")
    @Override
    public void beforeTestMethod(TestContext testContext) throws Exception {
        final Method testMethod = testContext.getTestMethod();
        Assert.notNull(testMethod, "The test method of the supplied TestContext must not be null");

        if (this.transactionContextCache.remove(testMethod) != null) {
            throw new IllegalStateException("Cannot start new transaction without ending existing transaction: " +
                    "Invoke endTransaction() before startNewTransaction().");
        }

        if (!testMethod.isAnnotationPresent(Transactional.class)) {
            return;
        }

        TransactionAttribute transactionAttribute =
                this.attributeSource.getTransactionAttribute(testMethod, testContext.getTestClass());
        TransactionDefinition transactionDefinition = null;
        if (transactionAttribute != null) {
            transactionDefinition = new DelegatingTransactionAttribute(transactionAttribute) {
                public String getName() {
                    return testMethod.getName();
                }
            };
        }

        if (transactionDefinition != null) {
            if (logger.isDebugEnabled()) {
                logger.debug("Explicit transaction definition [" + transactionDefinition +
                        "] found for test context [" + testContext + "]");
            }
            TransactionContext txContext =
                    new TransactionContext(getTransactionManager(testContext), transactionDefinition);
            runBeforeTransactionMethods(testContext);
            startNewTransaction(testContext, txContext);
            this.transactionContextCache.put(testMethod, txContext);
        }
    }


    @Override
    public void afterTestMethod(TestContext testContext) throws Exception {
        Method testMethod = testContext.getTestMethod();
        Assert.notNull(testMethod, "The test method of the supplied TestContext must not be null");

        // If the transaction is still active...
        TransactionContext txContext = this.transactionContextCache.remove(testMethod);
        if (txContext != null && !txContext.transactionStatus.isCompleted()) {
            try {
                endTransaction(testContext, txContext);
            }
            finally {
                runAfterTransactionMethods(testContext);
            }
        }
    }


    protected void runBeforeTransactionMethods(TestContext testContext) throws Exception {
        try {
            List<Method> methods = getAnnotatedMethods(testContext.getTestClass(), BeforeTransaction.class);
            Collections.reverse(methods);
            for (Method method : methods) {
                if (logger.isDebugEnabled()) {
                    logger.debug("Executing @BeforeTransaction method [" + method + "] for test context ["
                            + testContext + "]");
                }
                method.invoke(testContext.getTestInstance());
            }
        }
        catch (InvocationTargetException ex) {
            logger.error("Exception encountered while executing @BeforeTransaction methods for test context ["
                    + testContext + "]", ex.getTargetException());
            ReflectionUtils.rethrowException(ex.getTargetException());
        }
    }


    protected void runAfterTransactionMethods(TestContext testContext) throws Exception {
        Throwable afterTransactionException = null;

        List<Method> methods = getAnnotatedMethods(testContext.getTestClass(), AfterTransaction.class);
        for (Method method : methods) {
            try {
                if (logger.isDebugEnabled()) {
                    logger.debug("Executing @AfterTransaction method [" + method + "] for test context [" +
                            testContext + "]");
                }
                method.invoke(testContext.getTestInstance());
            }
            catch (InvocationTargetException ex) {
                Throwable targetException = ex.getTargetException();
                if (afterTransactionException == null) {
                    afterTransactionException = targetException;
                }
                logger.error("Exception encountered while executing @AfterTransaction method [" + method +
                        "] for test context [" + testContext + "]", targetException);
            }
            catch (Exception ex) {
                if (afterTransactionException == null) {
                    afterTransactionException = ex;
                }
                logger.error("Exception encountered while executing @AfterTransaction method [" + method +
                        "] for test context [" + testContext + "]", ex);
            }
        }

        if (afterTransactionException != null) {
            ReflectionUtils.rethrowException(afterTransactionException);
        }
    }


    private void startNewTransaction(TestContext testContext, TransactionContext txContext) throws Exception {
        txContext.startTransaction();
        ++this.transactionsStarted;
        if (logger.isInfoEnabled()) {
            logger.info("Began transaction (" + this.transactionsStarted + "): transaction manager [" +
                    txContext.transactionManager + "]; rollback [" + isRollback(testContext) + "]");
        }
    }

  
    private void endTransaction(TestContext testContext, TransactionContext txContext) throws Exception {
        boolean rollback = isRollback(testContext);
        if (logger.isTraceEnabled()) {
            logger.trace("Ending transaction for test context [" + testContext + "]; transaction manager [" +
                    txContext.transactionStatus + "]; rollback [" + rollback + "]");
        }
        txContext.endTransaction(rollback);
        if (logger.isInfoEnabled()) {
            logger.info((rollback ? "Rolled back" : "Committed") +
                    " transaction after test execution for test context [" + testContext + "]");
        }
    }


    protected final PlatformTransactionManager getTransactionManager(TestContext testContext) {
        if (this.configAttributes == null) {
            this.configAttributes = retrieveTransactionConfigurationAttributes(testContext.getTestClass());
        }
        String transactionManagerName = this.configAttributes.getTransactionManagerName();
        try {
            return (PlatformTransactionManager) BaseTest.getContext().getBean(
                    transactionManagerName, PlatformTransactionManager.class);
        }
        catch (BeansException ex) {
            if (logger.isWarnEnabled()) {
                logger.warn("Caught exception while retrieving transaction manager with bean name [" +
                        transactionManagerName + "] for test context [" + testContext + "]", ex);
            }
            throw ex;
        }
    }


    protected final boolean isDefaultRollback(TestContext testContext) throws Exception {
        return retrieveTransactionConfigurationAttributes(testContext.getTestClass()).isDefaultRollback();
    }


    protected final boolean isRollback(TestContext testContext) throws Exception {
        boolean rollback = isDefaultRollback(testContext);
        Rollback rollbackAnnotation = testContext.getTestMethod().getAnnotation(Rollback.class);
        if (rollbackAnnotation != null) {
            boolean rollbackOverride = rollbackAnnotation.value();
            if (logger.isDebugEnabled()) {
                logger.debug("Method-level @Rollback(" + rollbackOverride + ") overrides default rollback [" + rollback
                        + "] for test context [" + testContext + "]");
            }
            rollback = rollbackOverride;
        }
        else {
            if (logger.isDebugEnabled()) {
                logger.debug("No method-level @Rollback override: using default rollback [" + rollback
                        + "] for test context [" + testContext + "]");
            }
        }
        return rollback;
    }


    private List<Class<?>> getSuperClasses(Class<?> clazz) {
        ArrayList<Class<?>> results = new ArrayList<Class<?>>();
        Class<?> current = clazz;
        while (current != null) {
            results.add(current);
            current = current.getSuperclass();
        }
        return results;
    }

 
    private List<Method> getAnnotatedMethods(Class<?> clazz, Class<? extends Annotation> annotationType) {
        List<Method> results = new ArrayList<Method>();
        for (Class<?> eachClass : getSuperClasses(clazz)) {
            Method[] methods = eachClass.getDeclaredMethods();
            for (Method eachMethod : methods) {
                Annotation annotation = eachMethod.getAnnotation(annotationType);
                if (annotation != null && !isShadowed(eachMethod, results)) {
                    results.add(eachMethod);
                }
            }
        }
        return results;
    }


    private boolean isShadowed(Method method, List<Method> previousMethods) {
        for (Method each : previousMethods) {
            if (isShadowed(method, each)) {
                return true;
            }
        }
        return false;
    }

 
    private boolean isShadowed(Method current, Method previous) {
        if (!previous.getName().equals(current.getName())) {
            return false;
        }
        if (previous.getParameterTypes().length != current.getParameterTypes().length) {
            return false;
        }
        for (int i = 0; i < previous.getParameterTypes().length; i++) {
            if (!previous.getParameterTypes()[i].equals(current.getParameterTypes()[i])) {
                return false;
            }
        }
        return true;
    }

    private TransactionConfigurationAttributes retrieveTransactionConfigurationAttributes(Class<?> clazz) {
        Class<TransactionConfiguration> annotationType = TransactionConfiguration.class;
        TransactionConfiguration config = clazz.getAnnotation(annotationType);
        if (logger.isDebugEnabled()) {
            logger.debug("Retrieved @TransactionConfiguration [" + config + "] for test class [" + clazz + "]");
        }

        String transactionManagerName;
        boolean defaultRollback;
        if (config != null) {
            transactionManagerName = config.transactionManager();
            defaultRollback = config.defaultRollback();
        }
        else {
            transactionManagerName = (String) AnnotationUtils.getDefaultValue(annotationType, "transactionManager");
            defaultRollback = (Boolean) AnnotationUtils.getDefaultValue(annotationType, "defaultRollback");
        }

        TransactionConfigurationAttributes configAttributes =
                new TransactionConfigurationAttributes(transactionManagerName, defaultRollback);
        if (logger.isDebugEnabled()) {
            logger.debug("Retrieved TransactionConfigurationAttributes [" + configAttributes + "] for class [" + clazz + "]");
        }
        return configAttributes;
    }


    /**
     * Internal context holder for a specific test method.
     */
    private static class TransactionContext {

        private final PlatformTransactionManager transactionManager;

        private final TransactionDefinition transactionDefinition;

        private TransactionStatus transactionStatus;

        public TransactionContext(PlatformTransactionManager transactionManager, TransactionDefinition transactionDefinition) {
            this.transactionManager = transactionManager;
            this.transactionDefinition = transactionDefinition;
        }

        public void startTransaction() {
            this.transactionStatus = this.transactionManager.getTransaction(this.transactionDefinition);
        }

        public void endTransaction(boolean rollback) {
            if (rollback) {
                this.transactionManager.rollback(this.transactionStatus);
            }
            else {
                this.transactionManager.commit(this.transactionStatus);
            }
        }
    }

}
