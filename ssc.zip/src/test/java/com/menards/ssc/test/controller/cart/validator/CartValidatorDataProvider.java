package com.menards.ssc.test.controller.cart.validator;

import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.testng.annotations.DataProvider;

import com.menards.ssc.domain.order.MenardCartinfoDTO;
import com.menards.ssc.domain.order.MenardOrderOptionsDTO;

public class CartValidatorDataProvider {
	
	@DataProvider(name = "cartInfoFormValidator")
	public static Object[][] getCartinfoForm() {
		MenardCartinfoDTO cartinfoDTO = new MenardCartinfoDTO();
		BindingResult result = new BeanPropertyBindingResult(cartinfoDTO, "cartinfoDTO");
		return new Object[][]{{cartinfoDTO, result}};
    }
	
	
	@DataProvider(name = "placeOptionFormProvider")
	public static Object[][] getPlaceOptionForm() {
		MenardOrderOptionsDTO option = new MenardOrderOptionsDTO();
		BindingResult result = new BeanPropertyBindingResult(option, "menardOrderItemRequestDTO");
		return new Object[][]{{option, result}};
    }
}
