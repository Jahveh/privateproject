package com.menards.ssc.test.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.menards.ssc.dao.product.MenardProductDescDao;
import com.menards.ssc.domain.catalog.MenardProductDesc;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.test.base.BaseTest;

public class MenardProductDescDaoTest extends BaseTest {

	@Resource
	private MenardProductDescDao menardProductDescDao;

	@PersistenceUnit(unitName = "blPU")
	private EntityManagerFactory entityManagerFactory;

	private List<MenardProductDesc> persistentDesc = new ArrayList<MenardProductDesc>();
	
	private List<MenardProductDesc> skuClassPersistentDesc = new ArrayList<MenardProductDesc>();
	
	List<String> list = Arrays.asList("2667666","1311206","2667666", "1311206" );
	
	@Test(dependsOnMethods="prepareTestData") 
    public void findDescPage() {    	
		//Persist the test data to database
		Integer page = 1;
		Integer size = 100;
		String  queryString = null;		
		queryString = "050 10657";
		SearchResult<MenardProductDesc> result = menardProductDescDao.findDescPage(page, size, queryString, list);
		assert result.getResult().size() >= 0;
		
		queryString = "Black%";
		result = menardProductDescDao.findDescPage(page, size, queryString,  null);	
		assert result.getResult().size() >= 0;
		
		queryString = "_Black";
		result = menardProductDescDao.findDescPage(page, size, queryString,  list);
		assert result.getResult().size() >= 0;
		
		queryString = " .Black ";
		result = menardProductDescDao.findDescPage(page, size, queryString,  list);	
		assert result.getResult().size() >= 0;
		
		queryString = "4X8";
		result = menardProductDescDao.findDescPage(page, size, queryString,  list);	
		assert result.getResult().size() >= 0;
		
		page = 3;
		size = 10;
		queryString = "050";
		result = menardProductDescDao.findDescPage(page, size, queryString,  list);
		assert result.getResult().size() >= 0;
		
		page = 2;
		size = 20;
		queryString = "050";
		result = menardProductDescDao.findDescPage(page, size, queryString,  list);
		assert result.getResult().size() >= 0;
	}
	
	@Test(testName="prepareTestData", dataProvider = "productDescDaoDataProvider", dataProviderClass = ProductDescDaoDataProvider.class)  	
	public void prepareTestData(List<MenardProductDesc> descList) {
		EntityManager manager = entityManagerFactory.createEntityManager();
		EntityTransaction t = manager.getTransaction();
		try {
			t.begin();
	    	for (MenardProductDesc menardProductDesc : descList) {
	    		manager.persist(menardProductDesc);
	    		persistentDesc.add(menardProductDesc);
			}
	    	
	    	MenardProductDesc descOne = new MenardProductDesc();
	    	MenardProductDesc.MenardProductDescPK pk = new MenardProductDesc.MenardProductDescPK();
	    	pk.setOpensku(-100l);
	    	pk.setSkuCode("100");
	    	descOne.setId(pk);
	    	descOne.setSkuType("deptclass|1");
	    	descOne.setCreatedBy("deptclass");
	    	skuClassPersistentDesc.add(descOne);
	    	manager.persist(descOne);
	    	
	    	MenardProductDesc descTwo= new MenardProductDesc();
	    	MenardProductDesc.MenardProductDescPK pkTwo = new MenardProductDesc.MenardProductDescPK();
	    	pkTwo.setOpensku(-99l);
	    	pkTwo.setSkuCode("100");
	    	descTwo.setId(pkTwo);
	    	descTwo.setSkuType("deptclass|100");
	    	descTwo.setCreatedBy("deptclass");
	    	skuClassPersistentDesc.add(descTwo);
	    	manager.persist(descTwo);
	    	
	    	MenardProductDesc descThree= new MenardProductDesc();
	    	MenardProductDesc.MenardProductDescPK pkThree = new MenardProductDesc.MenardProductDescPK();
	    	pkThree.setOpensku(1001920l);
	    	pkThree.setSkuCode("1001920");
	    	descThree.setId(pkThree);
	    	descThree.setSkuType("single|845524442295887|1689949373782724");
	    	descThree.setCreatedBy("bm");
	    	skuClassPersistentDesc.add(descThree);
	    	manager.persist(descThree);
	    	t.commit();
	    	manager.close();
	    } catch (Exception e) {
	        t.rollback();
	    }
    }
	
	@AfterTest
    public void clearUpOrderData() {
		EntityManager manager = entityManagerFactory.createEntityManager();
		EntityTransaction t = manager.getTransaction();
		try {
			t.begin();
			for (MenardProductDesc menardProductDesc : persistentDesc) {		
				manager.remove(manager.find(MenardProductDesc.class, menardProductDesc.getId()));
			}
			
			for (MenardProductDesc menardProductDesc : skuClassPersistentDesc) {		
				manager.remove(manager.find(MenardProductDesc.class, menardProductDesc.getId()));
			}
			t.commit();
			manager.close();
	    } catch (Exception e) {
	        t.rollback();
	    }
    }
	
	@Test(dependsOnMethods="prepareTestData") 
	public void findProductDescPage() {
		SearchResult<MenardProductDesc> result = menardProductDescDao.findProductDescPage(1, 100, null, list);
		assert result.getResult().size() >= 1;
		result = menardProductDescDao.findProductDescPage(1, 100, "1", null);
		assert result.getResult().size() >= 1;
		result = menardProductDescDao.findProductDescPage(1, 100, "100", null);
		assert result.getResult().size() >= 1;
		result = menardProductDescDao.findProductDescPage(1, 100, "100", null);
		assert result.getResult().size() >= 1;
	}

	/*@Test	
	public void updateProductDescription() {
		int count = menardProductDescDao.resetOpenSkuProductDesc("skuman");
        assert count >= 0;
	}

	@Test
	public void updateDescSkuType() {
		int count = menardProductDescDao.postUpdateDescSkuType();
		assert count >= 0;
	}

	@Test
	public void findSkuProductInfo() {
		List<MenardProductDesc> list = menardProductDescDao.findSkuProductInfo();
		assert list.size() >= 0;
	}*/
}
