package com.menards.ssc.test.dao;

import java.util.List;

import javax.annotation.Resource;

import org.broadleafcommerce.common.currency.service.BroadleafCurrencyService;
import org.broadleafcommerce.common.locale.service.LocaleService;
import org.broadleafcommerce.core.catalog.dao.ProductDao;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.broadleafcommerce.profile.core.service.CustomerService;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.menards.ssc.dao.order.MenardOrderDao;
import com.menards.ssc.dao.order.MenardOrderItemDao;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.test.base.BaseTest;
import com.menards.ssc.test.service.OrderDataProvider;

public class MenardOrderDaoTest extends BaseTest{

	 @Resource
	 private MenardOrderDao orderDao;
	 
	 @Resource
	 private MenardOrderItemDao orderItemDao;
	 
	 @Resource
	 private BroadleafCurrencyService broadleafCurrencyService;
	 
	 @Resource
	 private LocaleService localeService;
	 
	 @Resource(name = "blCustomerService")
	 protected CustomerService customerService;
	 
	 
	 @Resource
	 private ProductDao productDao;
	 
	 @Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	 @Transactional
	 public void testSaveMenardOrder(Order order){
		 order = orderDao.saveMenardOrder(order);
		 
		 assert order != null ;
		 assert order.getId() != null;
		 assert order.getOrderItems() != null ;
		 assert order.getOrderItems().size() > 0;
	 }
	 
	 
	 @Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	 @Transactional
	 public void testFindMenardOrderByStatus(Order order){
		 order.setStatus(OrderStatus.IN_PROCESS);
		 MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		 ((MenardOrder)order).setCreatedByUserId(user.getUserId());
		 order = orderDao.saveMenardOrder(order);
		 List<MenardOrder> orders = orderDao.findMenardOrderByStatus(OrderStatus.IN_PROCESS);
		 assert orders.size() > 0;
	 }

}
