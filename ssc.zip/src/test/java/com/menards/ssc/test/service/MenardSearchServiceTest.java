/**
 * 
 */
package com.menards.ssc.test.service;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.mockito.Mockito;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.menards.mymenards.integration.vo.SecureUser;
import com.menards.ssc.dao.product.MenardProductDescDao;
import com.menards.ssc.dao.sign.MenardColorSignDao;
import com.menards.ssc.dao.sign.MenardSignDao;
import com.menards.ssc.domain.catalog.MenardProductDesc;
import com.menards.ssc.domain.catalog.SearchCriteria;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.catalog.SkuDTO;
import com.menards.ssc.domain.catalog.MenardProductDesc.MenardProductDescPK;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.domain.sign.SignSaleInfo;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.catalog.MenardSearchService;
import com.menards.ssc.service.catalog.MenardSearchServiceImpl;
import com.menards.ssc.service.skustatus.MenardSkuStatusService;



/**
 * <p>MenardSearchServiceTest</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class MenardSearchServiceTest {
	
	private SecureUser user = new SecureUser();
	
	@BeforeTest
	public void initContext() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
    	SecurityContext context = new SecurityContextImpl();
    	MenardUserDetails details = new MenardUserDetails("BCKOFF01.3281", "", Arrays.asList(new SimpleGrantedAuthority("ddd")));
    	UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(details,
    			Arrays.asList(new SimpleGrantedAuthority("ddd")));
    	context.setAuthentication(token);
    	Field field = MenardUserDetails.class.getDeclaredField("secureUser");
		field.setAccessible(true);		
		field.set(details, user);
    	SecurityContextHolder.setContext(context);
	}

	@Test
	public void testSearchForSupplies() throws Exception {
		MenardProductDescDao mockedDao = mock(MenardProductDescDao.class);		
		MenardSkuStatusService skuStatusService = mock(MenardSkuStatusService.class);
		
		MenardSearchService service = new MenardSearchServiceImpl();	
		Field field = MenardSearchServiceImpl.class.getDeclaredField("productDescDao");
		field.setAccessible(true);
		field.set(service, mockedDao);
		SearchResult<MenardProductDesc> tmp = prepareSuppliesSearchData();
		
		field = MenardSearchServiceImpl.class.getDeclaredField("skuStatusService");
		field.setAccessible(true);
		field.set(service, skuStatusService);
		
		Set<Long> skuCode = new HashSet<Long>();
		skuCode.add(1231305l);
		skuCode.add(1231306l);
		Map<String, String>  skuCodeMap = new HashMap<String, String>();
		skuCodeMap.put("1011205", "1");
		skuCodeMap.put("1011500", "2");
		skuCodeMap.put("1011501", "2");
		skuCodeMap.put("1011502", "1");
		skuCodeMap.put("1011503", "4");
		skuCodeMap.put("1011504", "5");
		skuCodeMap.put("1013398", "1");
		skuCodeMap.put("1013399", "1");		
		when(skuStatusService.getDerivedStatusMapByStoreSku(Mockito.anyListOf(Integer.class), Mockito.anyInt())).thenReturn(skuCodeMap);		
		
		SearchCriteria criteria =  new SearchCriteria();
		criteria.setPage(1);
		criteria.setPageSize(10);
		criteria.setQuery("main");
		
		user.setYard(true); 
		user.setStoreNumber("1203");
		
		when(mockedDao.findDescPage(1, 10, "main", skuCodeMap.keySet())).thenReturn(tmp);
		
		criteria.setYardNumber("1203");
		SearchResult<SkuDTO> result = service.findSkuPage(criteria);
	    assert result.getResult().size() >= 0;
	    //assert result.getResult().get(0).getSkuId().equals(10020221l);
	    //assert result.getResult().get(1).getSkuId().equals(10020222l);
	    
	    //Test super GO
		user.setYard(false); 
		user.setStoreNumber("1203");
		when(mockedDao.findDescPage(1, 10, "main", CollectionUtils.EMPTY_COLLECTION)).thenReturn(tmp);
		
		//criteria.setType(MenardSearchType.SUPPLIES.getKey());
		criteria.setYardNumber("1203");
		result = service.findSkuPage(criteria);
	    assert result.getResult().size() >= 2;
	    //assert result.getResult().get(0).getSkuId().equals(10020221l);
	    //assert result.getResult().get(1).getSkuId().equals(10020222l);
	}
	
	private SearchResult<MenardProductDesc> prepareSuppliesSearchData() {		
		SearchResult<MenardProductDesc> result = new SearchResult<MenardProductDesc>();
		result.setPage(1);
		result.setPageSize(10);
		MenardProductDesc desc = new MenardProductDesc();
		MenardProductDescPK pk = new MenardProductDescPK();
		pk.setSkuCode("10020221");
		pk.setProductId(30020222l);
		desc.setId(pk);
		desc.setSkuDesc("This is a long desc");
		desc.setProductDesc("This is a short desc");
		result.addElement(desc);
		
		MenardProductDesc desc1 = new MenardProductDesc();
		MenardProductDescPK pk1 = new MenardProductDescPK();
		pk1.setSkuCode("10020222");
		pk1.setProductId(30020222l);
		desc1.setId(pk1);
		desc1.setSkuDesc("This is a long desc");
		desc1.setProductDesc("This is a short desc");
		desc1.setDescription1("This is a long desc");
		desc1.setDescription2("This is a short desc");
		result.addElement(desc1);
		
		return result;
	}
	
	@Test
	public void testSearchForSign() throws Exception{
		MenardSignDao mockedDao = mock(MenardSignDao.class);
		SearchResult<Sign> parameter = new SearchResult<Sign>();
		parameter.addElement(new Sign());
		parameter.addElement(new Sign());
		when(mockedDao.findSignPage(1, 10, "blade")).thenReturn(parameter);
		
		//Return total rows
		when(mockedDao.findSignTotalCount("blade", 100, false)).thenReturn(10);
		
		MenardColorSignDao colorMockedDao = mock(MenardColorSignDao.class);
		SearchResult<Sign> colorSignResult = new SearchResult<Sign>();
		colorSignResult.addElement(new Sign());
		colorSignResult.addElement(new Sign());
		when(colorMockedDao.findColorSignPageWithIndex(10, 20, "blade", 0)).thenReturn(colorSignResult);
		when(colorMockedDao.findColorSignCount("blade", 0)).thenReturn(160);
		
		List<Sign> list = new ArrayList<Sign>();
		list.add(new Sign());
		when(mockedDao.getPrePrintedFactTags("blade", 0, 0)).thenReturn(list);
		
		MenardSearchService service = new MenardSearchServiceImpl();	
		Field field = MenardSearchServiceImpl.class.getDeclaredField("signDao");
		field.setAccessible(true);
		field.set(service, mockedDao);
		
		Field colorField = MenardSearchServiceImpl.class.getDeclaredField("colorSignDao");
		colorField.setAccessible(true);
		colorField.set(service, colorMockedDao);
		
		SearchCriteria criteria =  new SearchCriteria();
		criteria.setPage(1);
		criteria.setPageSize(10);
		criteria.setQuery("blade");
		SearchResult<Sign> result = service.findSignPage(criteria);
		assert result.getResult().size() >= 1;
	}
	
	@Test
	public void testSearchForSaleSign() throws Exception{
		user.setYard(true); 
		user.setStoreNumber("1203");
		MenardSignDao mockedDao = mock(MenardSignDao.class);
		SearchResult<Sign> parameter = new SearchResult<Sign>();
		parameter.addElement(new Sign(100, 1203));
		parameter.addElement(new Sign(200, 1203));
		when(mockedDao.findSaleSignPage(1, 10, "blade", 1203)).thenReturn(parameter);
		
		List<SignSaleInfo> list = new ArrayList<SignSaleInfo>();
		list.add(new SignSaleInfo(100, "100", "100", "100", "100"));
		List<SignSaleInfo> list2 = new ArrayList<SignSaleInfo>();
		list2.add(new SignSaleInfo(200, "200", "200", "200", "200"));
		when(mockedDao.getSaleSigns(100, 1203)).thenReturn(list);
		when(mockedDao.getSaleSigns(200, 1203)).thenReturn(list2);
		
		MenardSearchService service = new MenardSearchServiceImpl();	
		Field field = MenardSearchServiceImpl.class.getDeclaredField("signDao");
		field.setAccessible(true);
		field.set(service, mockedDao);
		
		SearchCriteria criteria =  new SearchCriteria();
		criteria.setPage(1);
		criteria.setPageSize(10);
		criteria.setQuery("blade");
		criteria.setYardNumber("1203");
		SearchResult<Sign> result = service.findSaleSignPage(criteria);
		assert result.getResult().size() == 2;
		assert result.getResult().get(0).getSignID() == 100;
		assert result.getResult().get(1).getSignID() == 200;
		
		user.setStoreNumber("0");
		result = service.findSaleSignPage(criteria);
		assert result.getResult().size() == 2;
		assert result.getResult().get(0).getSignID() == 100;
		assert result.getResult().get(1).getSignID() == 200;
	}
}
