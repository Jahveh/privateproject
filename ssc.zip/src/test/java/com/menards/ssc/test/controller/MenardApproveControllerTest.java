package com.menards.ssc.test.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.mock.MockHttpServletRequest;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;
import org.testng.annotations.Test;

import com.menards.ssc.controller.order.MenardOrderApproveController;
import com.menards.ssc.domain.order.ItemApproveRequestDTO;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderItemApproveRequestDTO;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.test.dao.OrderItemDaoDataProvider;
import com.menards.ssc.test.service.MenardOrderItemServiceTest;

public class MenardApproveControllerTest extends MenardOrderItemServiceTest {
	
	@Resource(name="menardOrderApproveController")
	private MenardOrderApproveController menardOrderApproveController;
	
	@Test(groups =  {"OrderItemapprove"}, dependsOnMethods={"testFindAllOrderItemsForApproval"},  dataProvider="basicOrderItem", dataProviderClass=OrderItemDaoDataProvider.class)
	@Transactional
	public void showAllOrderItemsForApprovalTest(MenardOrder order) {
		initData(order);
		MenardOrderItemFilterDTO filter  = new MenardOrderItemFilterDTO();
		Model model = new RedirectAttributesModelMap();		
		HttpServletRequest request = new MockHttpServletRequest();
		String viewName = menardOrderApproveController.showAllOrderItemsForApproval(model, filter, request);	
		assert viewName.equals("order/orderItemsForApprove");
		filter.setTrackingStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		viewName = menardOrderApproveController.showAllOrderItemsForApproval(model, filter, request);	
		assert viewName.equals("order/orderItemsForApprove");		
	}
	
	@Test(groups =  {"OrderItemapprove"}, dependsOnMethods={"testFindAllOrderItemsForApproval"},  dataProvider="basicOrderItem", dataProviderClass=OrderItemDaoDataProvider.class)
	@Transactional
	public void printAllOrderItems(MenardOrder order) {
		initData(order);
		MenardOrderItemFilterDTO filter  = new MenardOrderItemFilterDTO();
		Model model = new RedirectAttributesModelMap();		
		HttpServletRequest request = new MockHttpServletRequest();
		String viewName = menardOrderApproveController.showAllOrderItemsForApproval(model, filter, request);	
		assert viewName.equals("order/orderItemsForApprove");
		filter.setTrackingStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		viewName = menardOrderApproveController.printAllOrderItems(model, filter,request);	
		assert viewName.equals("order/orderItemsPrint");		
	}
	
	@Test(groups =  {"OrderItemapprove"}, dependsOnMethods={"testFindAllOrderItemsForApproval"},  dataProvider="basicOrderItem", dataProviderClass=OrderItemDaoDataProvider.class)
	@Transactional
	public void showCountTest(MenardOrder order) {
		initData(order);	
		String viewName = menardOrderApproveController.countOrderItemsForApprove();	
		assert  StringUtils.startsWith(viewName, "{\"count\":\"");
	}
	
	@Test(groups =  {"OrderItemapprove"}, dependsOnMethods={"testFindAllOrderItemsForApproval"},  dataProvider="basicOrderItem", dataProviderClass=OrderItemDaoDataProvider.class)
	@Transactional
	public void approveOrderItemsTest(MenardOrder order) {
		initData(order);
		Model model = new RedirectAttributesModelMap();
        List<ItemApproveRequestDTO> items = new ArrayList<ItemApproveRequestDTO>();    	
    	MenardOrderItemApproveRequestDTO dto = new MenardOrderItemApproveRequestDTO();
    	items.add(new ItemApproveRequestDTO(itemId, null));
    	String viewName = menardOrderApproveController.approveOrderItems(model, dto); 
    	assert viewName.equals("order/orderItemsApproveResult");
    	dto.setItems(items);
    	viewName = menardOrderApproveController.approveOrderItems(model, dto);   	
    		
		assert viewName.equals("order/orderItemsApproveResult");		
	}
}
