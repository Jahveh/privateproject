package com.menards.ssc.test.jms;

import javax.annotation.Resource;

import org.testng.annotations.Test;

import com.menards.ssc.jms.JmsQueueSender;
import com.menards.ssc.test.base.BaseTest;

public class JmsTest extends BaseTest {
	
  @Resource(name="jmsQueueSender")
  private JmsQueueSender sender;
	
  @Test
  public void testClothingMessage() {	  
	  String message = "This is a test message";
	  boolean result =  sender.send(message);
	  assert result;
  }
}
