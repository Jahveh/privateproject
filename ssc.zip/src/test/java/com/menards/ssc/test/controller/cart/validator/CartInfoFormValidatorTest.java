package com.menards.ssc.test.controller.cart.validator;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.testng.annotations.Test;

import com.menards.ssc.controller.cart.validator.CartInfoFormValidator;
import com.menards.ssc.domain.order.MenardCartinfoDTO;
import com.menards.ssc.test.base.BaseTest;

public class CartInfoFormValidatorTest  extends BaseTest{

	@Resource(name = "cartInfoFormValidator")
	private CartInfoFormValidator cartInfoFormValidator;
	
	@Test(dataProvider="cartInfoFormValidator", dataProviderClass=CartValidatorDataProvider.class)
	public void testDefaultValidate(MenardCartinfoDTO cartinfoDTO, BindingResult errors){
		cartInfoFormValidator.validate(cartinfoDTO, errors);
		assert !errors.hasErrors();
	}
	
	@Test(dataProvider="cartInfoFormValidator", dataProviderClass=CartValidatorDataProvider.class)
	public void testValidate(MenardCartinfoDTO cartinfoDTO, BindingResult errors){
		cartInfoFormValidator.validate(cartinfoDTO, errors);
		assert !errors.hasErrors();
		
		StringBuffer listName = new StringBuffer();
		for(int i = 0; i < CartInfoFormValidator.ORDER_LISTNAME_MAX_LENGTH + 1; i ++){
			listName.append("x");
		}
		
		StringBuffer comment = new StringBuffer();
		for(int i = 0; i < CartInfoFormValidator.ORDER_COMMENT_MAX_LENGTH + 1; i ++){
			comment.append("x");
		}
		
		cartinfoDTO.setListName(listName.toString());
		cartinfoDTO.setComment(comment.toString());
		cartInfoFormValidator.validate(cartinfoDTO, errors);
		
		assert errors.hasErrors();
		
		boolean listNameErr = false;
		boolean commentErr = false;
		List<FieldError> errEles = errors.getFieldErrors();
		for(FieldError err : errEles){
			if("listName".equals(err.getField()) && "cart.order.listname.maxlength".equals(err.getCode())){
				listNameErr = true;
			}else if("comment".equals(err.getField()) && "cart.order.comment.maxlength".equals(err.getCode())){
				commentErr = true;
			}
		}
		
		assert listNameErr;
		assert commentErr;
		
	}
	
	@Test
	public void testSupportCls(){
		assert cartInfoFormValidator.supports(MenardCartinfoDTO.class);
	}
	
}
