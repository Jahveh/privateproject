package com.menards.ssc.test.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import javax.annotation.Resource;

import org.broadleafcommerce.common.currency.domain.BroadleafCurrency;
import org.broadleafcommerce.common.currency.service.BroadleafCurrencyService;
import org.broadleafcommerce.common.locale.domain.Locale;
import org.broadleafcommerce.common.locale.service.LocaleService;
import org.broadleafcommerce.core.catalog.dao.ProductDao;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.broadleafcommerce.profile.core.domain.Customer;
import org.broadleafcommerce.profile.core.service.CustomerService;
import org.joda.time.DateTime;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.menards.ssc.dao.order.MenardOrderDao;
import com.menards.ssc.dao.order.MenardOrderItemDao;
import com.menards.ssc.domain.order.MenardCartinfoDTO;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.domain.order.MenardOrderItemTrackingHistory;
import com.menards.ssc.enums.MenardOrderItemSort;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.service.order.MenardOrderService;
import com.menards.ssc.test.base.BaseTest;
import com.menards.ssc.test.service.OrderDataProvider;

@Transactional("blTransactionManager")
public class OrderItemDaoTest extends BaseTest{
	
	@Resource(name = "blCustomerService")
    protected CustomerService customerService;
    
    @Resource
    private MenardOrderDao orderDao;   
    
	@Resource(name = "menardOrderService")
    protected MenardOrderService menardOrderService;
	 
    @Resource
    private MenardOrderItemDao orderItemDao;
 
    @Resource
    private BroadleafCurrencyService broadleafCurrencyService;
 
    @Resource
    private LocaleService localeService;
 
    @Resource
    private ProductDao productDao;
    
    private Long itemId = null;
    private Long orderId = null;
 
    @Test(groups =  {"OrderItemapprove"}, dataProvider="basicOrderItem", dataProviderClass=OrderItemDaoDataProvider.class)  
    /*@Transactional(propagation=Propagation.MANDATORY)
    @Rollback(false)*/
    public void findOrderItems(MenardOrder order) {
    	String storeId = "" + ((new Random()).nextInt()*(-1) % 100000 + 1l);
    	Long skuId = 9370000l;
    	
    	String requestType = MenardOrderRequestType.BM_Fact_Tag.getKey();
    	Set<String> set = new HashSet<String>();
    	set.add(MenardOrderItemStatus.PENDING_GM.getValue());
    	
    	//Prepare all the fundamental data
    	BroadleafCurrency currency = broadleafCurrencyService.findCurrencyByCode("USD");		 
    	order.setStatus(OrderStatus.SUBMITTED);
		order.setCurrency(currency);
		order.setStoreId(storeId.toString());
		Locale locale = localeService.findLocaleByCode("en_US");
		order.setLocale(locale);
		order.setCustomer(getCustomer(1l));
		Product product = productDao.readProductById(skuId);
		MenardOrderItem item = (MenardOrderItem)order.getOrderItems().get(0);		
		item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());//set status
		item.setStatusDate((new DateTime()).minusDays(7).toDate());//Set date
		item.setRequestType(requestType);
		item.setProduct(product);
		item.setSku(product.getDefaultSku());
		item.setMenardOrder(order);
		
		MenardCartinfoDTO cartinfoDTO = new MenardCartinfoDTO();
		MenardOrder o = (MenardOrder)menardOrderService.saveMenardOrder(order, cartinfoDTO);	
		orderId = o.getId();	
		itemId = o.getOrderItems().get(0).getId();
		assert o.getId() != null;
		MenardOrderItemFilterDTO filter = new MenardOrderItemFilterDTO();
		filter.setStoreId(storeId);
		List<MenardOrderItem> list = orderItemDao.findOrderItems(filter);
		assert list.size() == 1;	
		
		filter.setRequestType(requestType);
		list = orderItemDao.findOrderItems(filter);
		assert list.size() == 1;		
		
		filter.setDays(7);
		list = orderItemDao.findOrderItems(filter);
		assert list.size() == 1;		
		
		filter.setSort(MenardOrderItemSort.ITEM_ID_DESC.getKey());
		list = orderItemDao.findOrderItems(filter);
		assert list.size() == 1;
		
		filter.setSort(MenardOrderItemSort.ORDER_ID_DESC.getKey());
		list = orderItemDao.findOrderItems(filter);
		assert list.size() == 1;
		
		filter.setSort(MenardOrderItemSort.STATUS_DATE_DESC.getKey());
		list = orderItemDao.findOrderItems(filter);
		assert list.size() == 1;		
		
		filter.setSkuId(skuId);
		list = orderItemDao.findOrderItems(filter);
		assert list.size() == 1;		
    }
    
    @Test(groups =  {"OrderItemapprove"}, dependsOnMethods={"findOrderItems"}) 
    public void testReadOrderItem() throws Exception {		
    	MenardOrderItem item = orderItemDao.readMenardOrderItemById(itemId);    	
		assert item != null; 
    }
    
    @AfterTest
    public void clearUpOrderData() {
    	if(orderId != null){
    		Order order = menardOrderService.getOrderById(orderId);
    		if(order != null){    			
    			menardOrderService.deleteOrder(order);
    		}
    	}
    }

	@Test
    public void testSaveOrderItemTrackingHistory() throws Exception {
		MenardOrderItemTrackingHistory history = new MenardOrderItemTrackingHistory();
		Long orderId = 1L;
		history.setOrderId(orderId);
		Long orderItemId= 1L;
		history.setOrderItemId(orderItemId);
		history.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		history.setCreateDate(new Date());
		history.setCreateBy("ut customer");
		history = orderItemDao.saveOrderItemTrackingHistory(history);
		
		assert history!=null && history.getId() != null; 
    }
	
	/*@Test
    public void testGetOrderItemTrackingHistory() throws Exception {		
		Long orderItemNumber=3653L;
		Long orderId=702L;
		List<MenardOrderItemTrackingHistory> history =  orderDao.getTrackingHistory(orderItemNumber,orderId);		
		 assert history.size()>0;
    }*/
	
	private Customer getCustomer(Long customerId){
    	Customer customer =  customerService.readCustomerById(customerId);
    	if(customer == null){
    		customer = customerService.createCustomer();
    		customer = customerService.saveCustomer(customer);
    	}
    	return customer;
    }
	
	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional("blTransactionManager")
	public void testFindOrderItems(Order cart){
		orderDao.save(cart);
		cart.setStatus(OrderStatus.SUBMITTED);
		cart.setSubmitDate(new Date());

		Long storeId1 = 3011l;
		List<String> storeIds = new ArrayList<String>();
		storeIds.add(String.valueOf(storeId1));

		((MenardOrder) cart).setDueDate(new Date());
		((MenardOrder) cart).setCommentPlaced("order options comment test");
		((MenardOrder) cart).setOrderType("NEW");
		((MenardOrder) cart).setGrouping("grouping test");
		((MenardOrder) cart).setDeptId("100");
		((MenardOrder) cart).setRequestBy("request by ut");

		Long cartId = cart.getId();
		orderDao.save(cart);
		cart = menardOrderService.findOrderById(cartId);
		menardOrderService.placedOrder(cart, storeIds);
		Long skuId = 9370000l;
		List<MenardOrderItem> items = orderItemDao.findOrderItems(skuId, storeId1.toString());
		assert items != null;
		assert items.size() > 0;
	}
	
}
