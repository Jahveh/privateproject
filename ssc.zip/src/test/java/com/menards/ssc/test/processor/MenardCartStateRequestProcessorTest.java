package com.menards.ssc.test.processor;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.broadleafcommerce.common.web.BroadleafRequestContext;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.web.order.CartState;
import org.broadleafcommerce.core.web.order.security.CartStateRequestProcessor;
import org.broadleafcommerce.profile.core.domain.Customer;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.menards.ssc.test.base.BaseTest;
import com.menards.ssc.test.service.OrderDataProvider;

public class MenardCartStateRequestProcessorTest extends BaseTest{

	protected static String cartRequestAttributeName = "cart";
	protected static String customerRequestAttributeName = "customer";
	
	
	@Resource(name = "blCartStateRequestProcessor")
    protected CartStateRequestProcessor cartStateProcessor;
	
	private HttpServletRequest request;
	
	@BeforeTest
	public void initRequest(){
		//mock reqeust context
		request = new MockHttpServletRequest();
		BroadleafRequestContext broadleafRequestContext = new BroadleafRequestContext();
		broadleafRequestContext.setRequest(request);
		BroadleafRequestContext.setBroadleafRequestContext(broadleafRequestContext);
	}


	@Test(dataProvider="mockCustomer", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void testProcess(Customer customer){
		WebRequest webRequest = new ServletWebRequest((HttpServletRequest) request);
		webRequest.setAttribute(customerRequestAttributeName, customer, WebRequest.SCOPE_REQUEST);
		cartStateProcessor.process(webRequest);
		
		Order order = CartState.getCart();
		
		assert order != null;
	}

}
