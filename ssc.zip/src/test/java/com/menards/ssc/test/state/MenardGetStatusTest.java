package com.menards.ssc.test.state;

import java.util.HashMap;
import java.util.Map;

import org.broadleafcommerce.core.catalog.domain.ProductAttribute;
import org.broadleafcommerce.core.catalog.domain.ProductAttributeImpl;
import org.broadleafcommerce.core.catalog.domain.SkuAttribute;
import org.testng.annotations.Test;

import com.menards.ssc.constants.ProductAttributeKey;
import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardProductImpl;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.catalog.MenardSkuDTO;
import com.menards.ssc.domain.catalog.MenardSkuImpl;
import com.menards.ssc.enums.SkuStatus;
import com.menards.ssc.enums.SkuVisibility;
import com.menards.ssc.state.MenardGetStatus;
import com.menards.ssc.test.base.BaseTest;

public class MenardGetStatusTest extends BaseTest{

	@Test
	public void testGetSkuVisibility(){
		MenardProduct product = new MenardProductImpl();
		Map<String, ProductAttribute> productAttributes = new HashMap<String, ProductAttribute>();
		product.setProductAttributes(productAttributes);
		
		MenardSku sku = new MenardSkuImpl();
		Map<String, SkuAttribute> skuAttributes = new HashMap<String, SkuAttribute>();
		sku.setSkuAttributes(skuAttributes);
		sku.setProduct(product);
		
		
		
//		STOCK(0), 
//		DISCONTINUED(1), 
//		SEASONAL(2), 
//		DELETED(3), 
//		SPECIAL_ORDER(4), 
//		DC_SPECIAL_ORDER(5);
		
		
		MenardSkuDTO skuDto = new MenardSkuDTO(sku);
		//MenardSkuStatus status = new MenardSkuStatus();
		//null
		//skuDto.setSkuStatus(status);
		SkuVisibility skuVisibility = MenardGetStatus.getSkuVisibility(skuDto);
		assert SkuVisibility.DELETED.equals(skuVisibility);
		
		System.out.println(SkuVisibility.DELETED.equals(skuVisibility));
		
		
		//STOCK(0)

		skuDto.setSkuStatusCode(String.valueOf(SkuStatus.STOCK.getCode()));
		skuVisibility = MenardGetStatus.getSkuVisibility(skuDto);
		assert SkuVisibility.DELETED.equals(skuVisibility);
		
		System.out.println(SkuVisibility.DELETED.equals(skuVisibility));
		
		String key = ProductAttributeKey.DCM.toUpperCase();
		String value = "Y";
		ProductAttribute pa = new ProductAttributeImpl();
		pa.setName(key);
		pa.setValue(value);
		product.getProductAttributes().put(key, pa);
		skuVisibility = MenardGetStatus.getSkuVisibility(skuDto);
		assert SkuVisibility.DELETED.equals(skuVisibility);
		
		System.out.println(SkuVisibility.STOCK_NOT_ORDERABLE.equals(skuVisibility));
		
//		DISCONTINUED(1), 
		skuDto.setSkuStatusCode(String.valueOf(SkuStatus.DISCONTINUED.getCode()));
		skuVisibility = MenardGetStatus.getSkuVisibility(skuDto);
		assert SkuVisibility.DELETED.equals(skuVisibility);
		
		System.out.println(SkuVisibility.DELETED.equals(skuVisibility));
		
//		SEASONAL(2), 
		skuDto.setSkuStatusCode(String.valueOf(SkuStatus.SEASONAL.getCode()));
		skuVisibility = MenardGetStatus.getSkuVisibility(skuDto);
		assert SkuVisibility.DELETED.equals(skuVisibility);
		
		System.out.println(SkuVisibility.DELETED.equals(skuVisibility));
		
//		DELETED(2), 
		skuDto.setSkuStatusCode(String.valueOf(SkuStatus.DELETED.getCode()));
		skuVisibility = MenardGetStatus.getSkuVisibility(skuDto);
		assert SkuVisibility.DELETED.equals(skuVisibility);
		
		System.out.println(SkuVisibility.DELETED.equals(skuVisibility));
		
//		SPECIAL_ORDER(2), 
		skuDto.setSkuStatusCode(String.valueOf(SkuStatus.SPECIAL_ORDER.getCode()));
		skuVisibility = MenardGetStatus.getSkuVisibility(skuDto);
		assert SkuVisibility.SPECIAL_ORDER.equals(skuVisibility);
		
		System.out.println(SkuVisibility.SPECIAL_ORDER.equals(skuVisibility));
		
//		DC_SPECIAL_ORDER(2), 
		skuDto.setSkuStatusCode(String.valueOf(SkuStatus.DC_SPECIAL_ORDER.getCode()));
		skuVisibility = MenardGetStatus.getSkuVisibility(skuDto);
		assert SkuVisibility.SPECIAL_ORDER.equals(skuVisibility);
		
		System.out.println(SkuVisibility.SPECIAL_ORDER.equals(skuVisibility));
	}
	
}
