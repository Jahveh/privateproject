package com.menards.ssc.test.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.DataProvider;

import com.menards.ssc.domain.catalog.MenardProductDesc;
import com.menards.ssc.domain.catalog.MenardProductDesc.MenardProductDescPK;

public class ProductDescDaoDataProvider {
	
	public static List<String> SKUCODE_LIST = Arrays.asList("050 10657 24","050 10657 28","050 10657 58",
			"050 10657 912","050 22156 24","050 22156 28","050 22156 58","050 22156 912","050 22197 24",
			"050 22197 28","050 22197 58","050 22197 912","050 27358 24","050 27358 28","050 27358 58",
			"050 27358 912","050 27597 24","050 27597 28","050 27597 58","050 27597 912","050 27751 24");
	public static String[][] DESC = new String[][] {
		{"1'11\"x7'4\"NadeenAnna  Area Rug","1'11\"x7'4\"NadeenAnna  Area RugNadeen Anna Black%"},
		{"5'3x7'6\"NadeenAnna  Area Rug","5'3x7'6\"NadeenAnna  Area RugNadeen Anna _Black"},
		{"7'10\"x10'6NadeenAnna  Area Rug","7'10\"x10'6NadeenAnna  Area RugNadeen Anna .Black"},
		{"1'11\"x7'4\"NadeenAnnabel Area Rug","1'11\"x7'4\"NadeenAnnabel Area RugNadeen Annabel Burgundy"},
		{"5'3x7'6\"NadeenAnnabel Area Rug","5'3x7'6\"NadeenAnnabel Area RugNadeen Annabel Burgundy"},
		{"7'10\"x10'6NadeenAnnabel Area Rug","7'10\"x10'6NadeenAnnabel Area RugNadeen Annabel Burgundy"},
		{"5'3x7'6\"StylesAquarius Area Rug","5'3x7'6\"StylesAquarius Area RugStyles Aquarius Sunset"},
		{"7'10\"x10'6StylesAquarius Area Rug","7'10\"x10'6StylesAquarius Area RugStyles Aquarius Sunset"},
		{"1'11\"x7'4\"NadeenBotticelli Area Rug","1'11\"x7'4\"NadeenBotticelli Area RugNadeen Botticelli Black"},
		{"1'11\"x7'4\"NadeenBotticelli Area Rug","1'11\"x7'4\"NadeenBotticelli Area RugNadeen Botticelli Burgundy"},
		{"5'3x7'6\"NadeenBotticelli Area Rug","5'3x7'6\"NadeenBotticelli Area RugNadeen Botticelli Black"},
		{"5'3x7'6\"NadeenBotticelli Area Rug","5'3x7'6\"NadeenBotticelli Area RugNadeen Botticelli Burgundy"},
		{"7'10\"x10'6NadeenBotticelli Area Rug","7'10\"x10'6NadeenBotticelli Area RugNadeen Botticelli Black"},
		{"7'10\"x10'6NadeenBotticelli Area Rug","7'10\"x10'6NadeenBotticelli Area RugNadeen Botticelli Burgundy"},
		{"1'10\"x3'China GardenCabaret Area Rug","1'10\"x3'China GardenCabaret Area RugChina Garden Cabaret Olive"},
		{"1'11\"x7'2\"China GardenCabaret Area Rug","1'11\"x7'2\"China 4X8 GardenCabaret Area RugChina Garden Cabaret Olive"},
		{"5'3x7'2\"China GardenCabaret Area Rug","5'3x7'2\"China GardenCabaret Area RugChina Garden Cabaret Olive"},
		{"7'10\"x10'6China GardenCabaret Area Rug","7'10\"x10'6China 4X8 GardenCabaret Area RugChina Garden Cabaret Olive"},
		{"1'10\"x3'China GardenChestnut Wind Area Rug","1'10\"x3'China GardenChestnut Wind Area RugChina Garden Chestnut Wind Linen"},
		{"1'11\"x7'2\"China GardenChestnut Wind Area Rug","1'11\"x7'2\"China GardenChestnut Wind Area RugChina Garden Chestnut Wind Linen"},
		{"5'3x7'\"China GardenChestnut Wind Area Rug","5'3x7'2\"China GardenChestnut Wind Area RugChina Garden Chestnut Wind Linen"}
	};

    @DataProvider(name = "productDescDaoDataProvider")
    public static Object[][] provideBasicCategory() {
    	 List<MenardProductDesc> list = new ArrayList<MenardProductDesc>();
    	 long i = 0;
    	 for (String skuCode : SKUCODE_LIST) {
    		list.add(buildDesc(skuCode, ++i, i, i));
		 }
        return new Object[][] { {list} };
    }
    
    private static MenardProductDesc buildDesc(String skuCode, Long skuId, Long productId, Long opensku) {
    	MenardProductDesc desc = new MenardProductDesc();
    	MenardProductDescPK pk = new MenardProductDescPK();
    	pk.setSkuCode(skuId.toString());
    	pk.setProductId(productId);
    	pk.setOpensku(opensku);
    	desc.setId(pk);  
    	desc.setSkuDesc(DESC[skuId.intValue() - 1][0]);
    	desc.setProductDesc(DESC[skuId.intValue() - 1][1]);
    	desc.setDescription1(DESC[skuId.intValue() - 1][0]);
    	desc.setDescription2(DESC[skuId.intValue() - 1][1]);
    	return desc;
    }
}
