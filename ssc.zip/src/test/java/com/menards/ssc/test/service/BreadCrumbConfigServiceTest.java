package com.menards.ssc.test.service;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Assert;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.menards.ssc.domain.breadcrumb.BreadCrumbConfig;
import com.menards.ssc.service.breadcrumb.BreadCrumbConfigService;
import com.menards.ssc.test.base.BaseTest;

@Transactional("blTransactionManager")
@TransactionConfiguration(defaultRollback = true)
public class BreadCrumbConfigServiceTest extends BaseTest{
	@Resource(name="breadCrumbConfigService")
	private BreadCrumbConfigService breadCrumbConfigService;
	
	
	@Test
	public void testGetBreadCrumbConfigService(){
		List<BreadCrumbConfig> configs = breadCrumbConfigService.getAllBreadCrumbConfigs();
		Assert.assertTrue(configs.size()>0);
	}

}
