package com.menards.ssc.test.listener;

import java.lang.reflect.Field;

import javax.annotation.Resource;
import javax.servlet.ServletContext;

import org.apache.struts.mock.MockServletContext;
import org.mockito.Mockito;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.web.context.WebApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.menards.ssc.listener.breadcrumb.BreadCrumbConfigPreLoader;
import com.menards.ssc.service.breadcrumb.BreadCrumbConfigService;
import com.menards.ssc.test.base.BaseTest;

public class BreadCrumbConfigPreLoaderTest extends BaseTest{
	
	@Resource(name="breadCrumbConfigService")
	private BreadCrumbConfigService breadCrumbConfigService;
	
	//ServletContext servletContext = ((WebApplicationContext) event.getApplicationContext()).getServletContext();
	@Test
	public void testBreadCrumbConfigPreLoader() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException{
		ContextRefreshedEvent event = Mockito.mock(ContextRefreshedEvent.class);
		WebApplicationContext appContext = Mockito.mock(WebApplicationContext.class);
		ServletContext servletContext = new MockServletContext();
		Mockito.when(event.getApplicationContext()).thenReturn(appContext);
		Mockito.when(appContext.getServletContext()).thenReturn(servletContext);
		
		BreadCrumbConfigPreLoader preloader = new BreadCrumbConfigPreLoader();
		
		Field field = BreadCrumbConfigPreLoader.class.getDeclaredField("breadCrumbConfigService");
		field.setAccessible(true);
		field.set(preloader, breadCrumbConfigService);
		
		
		preloader.onApplicationEvent(event);
		
		Assert.assertTrue(servletContext.getAttribute(BreadCrumbConfigPreLoader.BREAD_CRUMB_CONFIG_MAP_SERVLET_CONTEXT_KEY)!=null);
		Assert.assertEquals(preloader.getOrder(), 20);
	}
	
	
}
