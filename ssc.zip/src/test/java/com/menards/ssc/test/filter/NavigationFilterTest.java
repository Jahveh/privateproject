package com.menards.ssc.test.filter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockServletContext;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.menards.ssc.domain.navigation.CategoryTreeNode;
import com.menards.ssc.filter.NavigationFilter;
import com.menards.ssc.service.catalog.CategoryTreeService;


public class NavigationFilterTest{

	@Test(dataProvider="requestURI")
	public void test1(String requestURI) throws IOException, ServletException{
		Map<Long, CategoryTreeNode> categoryTreeDictionary = new HashMap<Long, CategoryTreeNode>();
		CategoryTreeNode node = new CategoryTreeNode();
		node.setUrl("/home/page");
		node.setCategoryId(10000L);
		categoryTreeDictionary.put(10000L, node);
		MockServletContext servletContext = new MockServletContext();
		servletContext.setAttribute(CategoryTreeService.CATEGORY_TREE_DICTIONARY_SERVLET_CONTEXT_KEY, categoryTreeDictionary);
		
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setContextPath("contextPath");
//		request.setRequestURI("contextPath/home/page?hello=world");
		request.setRequestURI(requestURI);
		HttpSession session = Mockito.mock(HttpSession.class);
		request.setSession(session);
		Mockito.when(session.getServletContext()).thenReturn(servletContext);
		
		NavigationFilter filter = new NavigationFilter();
		filter.doFilter(request, Mockito.mock(HttpServletResponse.class), Mockito.mock(FilterChain.class));
	}
	
	@DataProvider(name="requestURI")
	public Object[][] data(){
		return new String[][]{{"contextPath/home/page?hello=world"},{"contextPath/home/page/another/page?hello=world"}};
	}
	
	
}
