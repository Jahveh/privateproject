package com.menards.ssc.test.strategy;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.mockito.Mockito;
import org.springframework.mail.SimpleMailMessage;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.menards.ssc.config.PropertiesConfig;
import com.menards.ssc.config.PropertiesHelper;
import com.menards.ssc.domain.order.MenardDiscreteOrderItemImpl;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderImpl;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.yard.Store;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.jms.JmsQueueSender;
import com.menards.ssc.service.email.EmailSenderService;
import com.menards.ssc.service.yard.MenardYardService;
import com.menards.ssc.strategy.approve.MenardFactTagStrategy;
import com.menards.ssc.strategy.approve.MenardItemApproveStrategy;
import com.menards.ssc.strategy.approve.MenardPayrollStrategy;

public class MenardFactTagStrategyTest {

	private MenardItemApproveStrategy strategy = new MenardFactTagStrategy();

	private MenardOrderItem item = new MenardDiscreteOrderItemImpl();

	private String fulfillerCode = MenardFulfillerType.FACT_TAG.getKey();

	@Test(groups = { "OrderItemApproveStrategy" })
	public void noVendorFactTest() {

		item.setFulfillerTypeCode(fulfillerCode);
		item.setRequestType(MenardOrderRequestType.Hardware_Fact_Tag.getKey());

		// Go order and has the same fulfiller type
		item.setStatus(null);
		item.setStatus(strategy.getInitStatus(item, true, fulfillerCode));
		assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());

		// Not Go order
		item.setStatus(null);
		item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
		assert MenardOrderItemStatus.PENDING_GO.getValue().equals(item.getStatus());

		// Not Go order and pending go
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());

		// Not Go order and pending go
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.BACKORDERED.getKey()));
		assert MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());

		// Not Go order and pending go
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
		assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());

		// Not Go order and pending bo

		item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
		assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());

		// Not Go order and pending bo

		item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());
	}

	@BeforeTest
	public void setup() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		EmailSenderService service = mock(EmailSenderService.class);
		when(service.sendEmailWithTemplate(Mockito.any(SimpleMailMessage.class), Mockito.anyString(), Mockito.anyMap())).thenReturn(true);
		Field serviceField = MenardFactTagStrategy.class.getDeclaredField("emailSenderService");
		serviceField.setAccessible(true);
		serviceField.set(strategy, service);
		
		MenardYardService mockedService = mock(MenardYardService.class);		
		Store store = new Store();
		store.setStoreNumber("3011");
		store.setStoreName("storename");
		store.setZip("54755");	
		when(mockedService.getStore(Mockito.anyString())).thenReturn(store);
		Field field;
		field = MenardFactTagStrategy.class.getDeclaredField("yardService");
		field.setAccessible(true);
		field.set(strategy, mockedService);
		
		PropertiesHelper helper = new PropertiesHelper();	
		helper.setProperties(new Properties());
		Field sender = PropertiesConfig.class.getDeclaredField("helper");
		sender.setAccessible(true);
		sender.set(PropertiesConfig.class, helper);
		
		MenardOrder order = new MenardOrderImpl();
		order.setId(100000l);
		order.setStoreId("3011");
		item.setMenardOrder(order);
	}

	@Test(groups = { "OrderItemApproveStrategy" })
	public void vendorFactTest() {

		item.setFulfillerTypeCode(fulfillerCode);
		item.setRequestType(MenardOrderRequestType.Vendor_Fact_Tag.getKey());

		// Go order and has the same fulfiller type
		item.setStatus(null);
		item.setStatus(strategy.getInitStatus(item, true, fulfillerCode));
		assert MenardOrderItemStatus.SENDING_EMAIL.getValue().equals(item.getStatus());

		// Not Go order
		item.setStatus(null);
		item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
		assert MenardOrderItemStatus.PENDING_GM.getValue().equals(item.getStatus());

		// Not Go order and pending gm
		item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.SENDING_EMAIL.getValue().equals(item.getStatus());

		// Not Go order and pending gm
		item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
		assert MenardOrderItemStatus.GM_DECLINED.getValue().equals(item.getStatus());

		// Not Go order and pending go
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.SENDING_EMAIL.getValue().equals(item.getStatus());
	}

	@Test(expectedExceptions = { RuntimeException.class })
	public void unnormalConditionEmptyTest() {
		assert StringUtils.isEmpty(strategy.getInitStatus(null, false, null));
		assert StringUtils.isEmpty(strategy.getInitStatus(null, true, null));
		assert StringUtils.isEmpty(strategy.nextStage(null, MenardItemApproveAction.DECLINED.getKey()));
	}
}