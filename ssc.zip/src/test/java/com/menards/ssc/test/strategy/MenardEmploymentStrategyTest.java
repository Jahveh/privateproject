package com.menards.ssc.test.strategy;

import org.apache.commons.lang.StringUtils;
import org.testng.annotations.Test;

import com.menards.ssc.domain.order.MenardDiscreteOrderItemImpl;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.strategy.approve.MenardEmploymentOfficeStrategy;
import com.menards.ssc.strategy.approve.MenardItemApproveStrategy;

public class MenardEmploymentStrategyTest {

	private MenardItemApproveStrategy strategy = new MenardEmploymentOfficeStrategy();

	private MenardOrderItem item = new MenardDiscreteOrderItemImpl();

	private String fulfillerCode = MenardFulfillerType.SIGN_PRODUCTION.getKey();

	@Test(groups =  {"OrderItemApproveStrategy"})
	public void employmentStrategyTest() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException {

		/*assert StringUtils.isEmpty(strategy.getInitStatus(null, null, null));
		assert StringUtils.isEmpty(strategy.getInitStatus(null, true, null));
		assert StringUtils.isEmpty(strategy.nextStage(null, MenardItemApproveAction.DECLINED.getKey()));*/
		item.setFulfillerTypeCode(fulfillerCode);
		item.setRequestType(MenardOrderRequestType.Employment_Office.getKey());
		// Go order and has the same fulfiller type		
		item.setStatus(null);
		item.setStatus(strategy.getInitStatus(item, true, fulfillerCode));
		assert MenardOrderItemStatus.COMPLETED.getValue().equals(item.getStatus());

		// Not Go order
		
		item.setStatus(null);
		item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
		assert MenardOrderItemStatus.PENDING_GM.getValue().equals(item.getStatus());

		// Not Go order and pending gm
		
		item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.PENDING_GO.getValue().equals(item.getStatus());

		// Not Go order and pending gm
		
		item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
		assert MenardOrderItemStatus.GM_DECLINED.getValue().equals(item.getStatus());

		// Not Go order and pending go
		
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.COMPLETED.getValue().equals(item.getStatus());

		// Not Go order and pending go
		
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.BACKORDERED.getKey()));
		assert MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());

		// Not Go order and pending go
		
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
		assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());

		// Not Go order and pending bo
		
		item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
		assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());

		// Not Go order and pending bo
		
		item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.COMPLETED.getValue().equals(item.getStatus());
	}
	
	@Test(expectedExceptions = {RuntimeException.class})
	public void unnormalConditionEmptyTest() {
		assert StringUtils.isEmpty(strategy.getInitStatus(null, false, null));
		assert StringUtils.isEmpty(strategy.getInitStatus(null, true, null));
		assert StringUtils.isEmpty(strategy.nextStage(null, MenardItemApproveAction.DECLINED.getKey()));
	}
}