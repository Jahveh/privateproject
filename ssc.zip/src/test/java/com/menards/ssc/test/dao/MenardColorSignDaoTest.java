package com.menards.ssc.test.dao;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.broadleafcommerce.common.money.Money;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.menards.ssc.dao.sign.MenardColorSignDao;
import com.menards.ssc.dao.sign.MenardSignDao;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.order.MenardDiscreteOrderItemImpl;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderImpl;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.test.base.BaseTest;

@TransactionConfiguration(transactionManager = "colorSignTransactionManager", defaultRollback = true)
public class MenardColorSignDaoTest extends BaseTest {

	@Resource
	private MenardSignDao menardSignDao;
	
	@Resource
	private MenardColorSignDao menardColorSignDao;
	
	@Test
	public void findColorSignPage() {
		Integer page = 1;
		Integer size = 10;
		String  queryString = null;		
		queryString = "sign";
		SearchResult<Sign> result = menardColorSignDao.findColorSignPage(page, size, queryString, 0);
		System.out.println(result.getResult().size());
		assert result.getResult().size() >= 0;
	}
	
	@Test
	public void findColorSignByIds() {	
		Map<Integer, Sign> result = menardColorSignDao.findSignListById(Arrays.asList(4211,4212,4213,4214,4215,4216,4217,4218));
		assert result.size() >= 0;
	}
	
	@Test
	public void findColorCount() {	
		int count = menardColorSignDao.findColorSignCount("sign", null);
		System.out.println(count);
		count = menardColorSignDao.findColorSignCount("sign", 3011);
		System.out.println(count);
		assert count >= 0;
	}
	
	@Test
	public void findColorSignPageWithIndex() {	
		SearchResult<Sign> result = menardColorSignDao.findColorSignPageWithIndex(0, 200, "sign", null);
		result = menardColorSignDao.findColorSignPageWithIndex(0, 200, "sign", 3011);
		assert result.getResult().size() >= 0;
	}
	
	@Test
	@Transactional
	public void testInsertColorSignOrder(){
		Sign sign = new Sign();
		sign.setSignID(11569);
		MenardOrderItem item = new MenardDiscreteOrderItemImpl();
		MenardOrder order = new MenardOrderImpl();
		order.setOrderNumber("55");
		//order.setDeptId("55");
		order.setCreatedByUserId("recve01");
		item.setMenardOrder(order);
		item.setQuantity(10);
		item.setSignYardNum("3204");
		item.setOrder(order);
		item.setRetailPrice(new Money(1000));
		item.setSalePrice(new Money(1000));
		menardColorSignDao.insertSignOrder(sign, item);
		assert true;
	}
}
