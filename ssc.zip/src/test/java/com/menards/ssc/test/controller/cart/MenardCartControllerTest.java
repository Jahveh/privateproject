package com.menards.ssc.test.controller.cart;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.broadleafcommerce.common.web.BroadleafRequestContext;
import org.broadleafcommerce.core.catalog.domain.Category;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.domain.OrderItem;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.broadleafcommerce.core.web.order.CartState;
import org.broadleafcommerce.profile.core.domain.Customer;
import org.broadleafcommerce.profile.core.service.CustomerService;
import org.broadleafcommerce.profile.web.core.CustomerState;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.menards.ssc.controller.cart.MenardCartController;
import com.menards.ssc.dao.order.MenardOrderDao;
import com.menards.ssc.dao.product.MenardProductDao;
import com.menards.ssc.domain.cart.AddCartRequest;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.order.MenardCartinfoDTO;
import com.menards.ssc.domain.order.MenardOrderOptionsDTO;
import com.menards.ssc.enums.MenardDepartment;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.catalog.MenardCatalogService;
import com.menards.ssc.service.order.MenardOrderService;
import com.menards.ssc.test.base.BaseTest;
import com.menards.ssc.test.service.OrderDataProvider;

public class MenardCartControllerTest extends BaseTest{
	
	@Resource(name = "menardOrderService")
	protected MenardOrderService menardOrderService;
	
	@Resource(name = "blCatalogService")
	private MenardCatalogService catalogService;
	
	@Resource
	private MenardOrderDao orderDao;
	
	@Resource(name="blCustomerService")
	protected CustomerService customerService;
	
	@Resource(name="menardCartController")
	private MenardCartController cartController;
	
	@Resource(name = "blProductDao")
    private MenardProductDao productDao; 
	
	
	private static final Long categoryId = 100102L;
	private static final Long productId = 9370000L;
	private static final Long skuId = 9370000L;
	private static final Long customerId = 10000000L;
	
	
	private void initRequest(){
		//mock reqeust context
		HttpServletRequest request = new MockHttpServletRequest();
		BroadleafRequestContext broadleafRequestContext = new BroadleafRequestContext();
		broadleafRequestContext.setRequest(request);
		BroadleafRequestContext.setBroadleafRequestContext(broadleafRequestContext);
	}
	
	private void initCart(){		
		Customer customer = customerService.readCustomerById(customerId);
		if(customer == null){
			customer = customerService.createCustomer();
			customer = customerService.saveCustomer(customer);
		}
		CustomerState.setCustomer(customer);
		
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		Order cart = menardOrderService.findCartByUserId(user.getUserId());
		if (cart == null) {
			cart = menardOrderService.createOrderForNewUser(user.getUserId());
		}
		CartState.setCart(cart);
	}
	
	@BeforeMethod
	public void setup(){
		initRequest();
		initCart();
	}
	
	@Test
	@Transactional
	public void  getCart(){
		Model model = new ExtendedModelMap();
		String retView = cartController.getCart(model, new MockHttpServletRequest());
		assert "cart/cart".equals(retView);
	}
	
	
	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void update_1(Order order) throws ItemNotFoundException{
		orderDao.save(order);
		addItemToCart(order);
		CartState.setCart(order);
		OrderItem orderItem = order.getOrderItems().get(0);
		Model model = new ExtendedModelMap();
		AddCartRequest request = new AddCartRequest();
		List<SkuCartItem> cartItems = new ArrayList<SkuCartItem>();
		request.setCartItems(cartItems);
		
		//"redirect:"+url
		request.setNavigation("testUrl");
		String retView = cartController.update(model, request, new BeanPropertyBindingResult(request, ""), new MockHttpServletRequest());
		assert "redirect:testUrl".equals(retView);
		
		//redirect:/
		request.setNavigation("continueShopping");
		retView = cartController.update(model, request, new BeanPropertyBindingResult(request, ""), new MockHttpServletRequest());
		assert "redirect:/".equals(retView);
		
		//error
		SkuCartItem item = new SkuCartItem();
		cartItems.add(item);
		retView = cartController.update(model, request, new BeanPropertyBindingResult(request, ""), new MockHttpServletRequest());
		assert "cart/cart".equals(retView);
		
		//navigation == null
		request.setNavigation(null);
		item.setOrderItemId(orderItem.getId());
		item.setSkuId(skuId);
		item.setProductId(productId);
		item.setComment("test comment");
		item.setQuantity(1);
		retView = cartController.update(model, request, new BeanPropertyBindingResult(request, ""), new MockHttpServletRequest());
		assert "redirect:/cart".equals(retView);
		
		//edit
		Product product = productDao.readProductById(productId);
		request.setNavigation("edit:"+orderItem.getId()+";"+product.getUrl());
		retView = cartController.update(model, request, new BeanPropertyBindingResult(request, ""), new MockHttpServletRequest());
		assert ("redirect:"+product.getUrl()).equals(retView);
		
	}
	
	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void update_2(Order order) throws ItemNotFoundException{
		orderDao.save(order);
		addItemToCart(order);
		CartState.setCart(order);
		OrderItem orderItem = order.getOrderItems().get(0);
		Model model = new ExtendedModelMap();
		AddCartRequest reqeust = new AddCartRequest();
		List<SkuCartItem> cartItems = new ArrayList<SkuCartItem>();
		reqeust.setCartItems(cartItems);
		SkuCartItem item = new SkuCartItem();
		item.setOrderItemId(orderItem.getId());
		item.setProductId(productId);
		item.setSkuId(skuId);
		item.setComment("test comment");
		item.setQuantity(1);
		cartItems.add(item);
		
		
		reqeust.setNavigation("continueShopping");
		reqeust.setCartItems(cartItems);
		addItemToCart(order);
		CartState.setCart(order);
		String retView = cartController.update(model, reqeust, new BeanPropertyBindingResult(reqeust, ""), new MockHttpServletRequest());
		Category category = catalogService.findCategoryById(categoryId);
		assert ("redirect:"+category.getUrl()).equals(retView);
	}
	
	private Order addItemToCart(Order cart) throws ItemNotFoundException {
		SkuCartItem cartItem = new SkuCartItem();
		cartItem.setProductId(productId);
		cartItem.setSkuId(skuId);
		cartItem.setQuantity(1);
		cart = menardOrderService.addItem(cart, cartItem);
		return cart;
	}
	
	@Test
	public void navigateToCartInfo(){
		MenardCartinfoDTO cartinfoDTO = new MenardCartinfoDTO();
		ModelAndView mv = cartController.navigateToCartInfo(cartinfoDTO);
		
		assert "/cart/cartinfo".equals(mv.getViewName());		
	}
	
	@Test
	@Transactional
	public void saveOrder(){
		MenardCartinfoDTO cartinfoDTO = new MenardCartinfoDTO();
		cartinfoDTO.setListName("listName xxxxx");
		cartinfoDTO.setComment("comment xxxxx");
		String retView = cartController.saveOrder(cartinfoDTO, new BeanPropertyBindingResult(cartinfoDTO, ""));
		
		assert "redirect:/cart".equals(retView);
	}
	
	@Test
	@Transactional
	public void testNaviagteToOrderOptions(){
		MenardOrderOptionsDTO orderOptionsDTO = new MenardOrderOptionsDTO();
		ModelAndView mv = cartController.naviagteToOrderOptions(orderOptionsDTO, "");
		
		assert "/cart/options".equals(mv.getViewName());
	}
	
	@Test
	@Transactional
	public void testPlaceOrder(){
		MenardOrderOptionsDTO orderOptionsDTO = new MenardOrderOptionsDTO();
		Model model = new ExtendedModelMap();
		String retView = cartController.placeOrder(model ,
				orderOptionsDTO, new BeanPropertyBindingResult(orderOptionsDTO, ""),
				new RedirectAttributesModelMap());
		
		assert !model.asMap().isEmpty();
		assert "/cart/options".equals(retView);
		
		orderOptionsDTO.setComment("comment xxx");
		orderOptionsDTO.setDeptId(MenardDepartment.BACK_OFFICE.getKey());
		orderOptionsDTO.setDueDate(new Date());
		orderOptionsDTO.setGroup("xxxx");
		orderOptionsDTO.setOrderCode("xxxx");
		orderOptionsDTO.setOrderType("xxx");
		orderOptionsDTO.setRequestBy("xxxx");
		List<String> storeIds = new ArrayList<String>();
		storeIds.add("3011");
		orderOptionsDTO.setStoreIds(storeIds);
		
		retView = cartController.placeOrder(model , orderOptionsDTO, 
				new BeanPropertyBindingResult(orderOptionsDTO, ""),
				new RedirectAttributesModelMap());
		assert "redirect:/cart/placedpage".equals(retView);
	}
	
	@Test
	public void naviagteToPlacedpage(){
		ModelAndView mv = cartController.naviagteToPlacedpage();
		
		assert "/cart/placed".equals(mv.getViewName());
	}
	
	@Test
	public void getOrders(){
		HttpServletRequest request = new MockHttpServletRequest();
		ModelAndView mv = cartController.getOrders(request);
		
		assert "/cart/orders".equals(mv.getViewName());
	}
	
	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void replaceOrder(Order order){
		orderDao.save(order);
		Long orderId = order.getId();
		String retView = cartController.replaceOrder(orderId);
		assert "redirect:/cart".equals(retView);
	}
	
	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void delete(Order order){
		orderDao.save(order);
		Long orderId = order.getId();
		String retView = cartController.delete(orderId);
		assert "redirect:/cart/orders".equals(retView);
	}
	
}
