package com.menards.ssc.test.controller;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.ui.Model;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;
import org.testng.annotations.Test;

import com.menards.ssc.controller.search.SearchController;
import com.menards.ssc.domain.catalog.SearchCriteria;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.catalog.SkuDTO;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.enums.MenardSearchType;
import com.menards.ssc.service.catalog.MenardSearchService;
import com.menards.ssc.test.base.BaseTest;

public class SearchControllerTest extends BaseTest {

	@Resource
	private SearchController searchController;
	
	/*@Resource
	private LocalValidatorFactoryBean  localValidator;*/

	@Test(testName="search", dataProvider = "searchDataProvider", dataProviderClass = SearchDataProvider.class)  
	public void searchSku(SearchResult<SkuDTO> resultOne, SearchResult<SkuDTO> resultTwo, SearchResult<Sign> signOneList, SearchResult<Sign> signTwoList) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		SearchCriteria criteria = null;
		Model model = new RedirectAttributesModelMap();	
		BindingResult result = new BeanPropertyBindingResult(criteria, "criteria");
		MenardSearchService mockedService = mock(MenardSearchService.class);
		when(mockedService.findSkuPage(criteria)).thenReturn(resultTwo);
		Field field = SearchController.class.getDeclaredField("searchService");
		field.setAccessible(true);
		field.set(searchController, mockedService);
		
		//When the criteria is null
		String view = searchController.search(model, criteria, result);
		assert view.equals("catalog/searchResultPage");	
		
		//When the query string is blank
		criteria = new SearchCriteria();
		view = searchController.search(model, criteria, result);
		assert view.equals("catalog/searchResultPage");	
		
		//When the criteria is not null
		criteria = new SearchCriteria();
		criteria.setPage(10);
		criteria.setPageSize(20);
		criteria.setType(MenardSearchType.SUPPLIES.getKey());
		criteria.setQuery("main");
		assert(result.getErrorCount() == 0);
		assert view.equals("catalog/searchResultPage");	
		
		//When there are only one product
		when(mockedService.findSkuPage(criteria)).thenReturn(resultOne);
		view = searchController.search(model, criteria, result);
		assert StringUtils.startsWith(view, "redirect:/product/200");
		
		//Add the validate error
		FieldError query = new FieldError("criteria", "query", "ma", true, new String[]{"criteria.query"}, new Object[]{"40", "40", MenardSearchType.SUPPLIES.getDescription() + " and " + MenardSearchType.SIGN.getDescription()}, "This field is not correct");
		result.addError(query);
		criteria.setQuery("ssssssssssssssssssssssssssssssssssssssssss");
		view = searchController.search(model, criteria, result);
		assert view.equals("catalog/searchResultPage");	
		
		//Add the validate error
		query = new FieldError("criteria", "query", "ma", true, new String[]{"criteria.query"}, new Object[]{"40", "40", MenardSearchType.SUPPLIES.getDescription() + " and " + MenardSearchType.SALE_SIGN.getDescription()}, "This field is not correct");
		result.addError(query);
		criteria.setType(MenardSearchType.SALE_SIGN.getKey());
		criteria.setQuery("ssssssssssssssssssssssssssssssssssssssssss");
		view = searchController.search(model, criteria, result);
		assert view.equals("catalog/searchResultPage");	
		
		criteria = new SearchCriteria();
		result = new BeanPropertyBindingResult(criteria, "criteria");
		criteria.setPage(10);
		criteria.setPageSize(20);
		criteria.setType(MenardSearchType.SIGN.getKey());
		criteria.setQuery("main");
		when(mockedService.findSignPage(criteria)).thenReturn(signOneList);
		view = searchController.search(model, criteria, result);
		assert view.equals("catalog/searchResultPage");	
		
		criteria.setType(MenardSearchType.SIGN.getKey());
		SearchResult<Sign> emptyResult = new SearchResult<Sign>();
		when(mockedService.findSignPage(criteria)).thenReturn(emptyResult);
		view = searchController.search(model, criteria, result);
		assert view.equals("catalog/NoSign");
		
		criteria.setType(MenardSearchType.SALE_SIGN.getKey());
		when(mockedService.findSaleSignPage(criteria)).thenReturn(signOneList);
		view = searchController.search(model, criteria, result);
		assert view.equals("catalog/searchResultPage");	
		
		when(mockedService.findSaleSignPage(criteria)).thenReturn(emptyResult);
		view = searchController.search(model, criteria, result);
		assert view.equals("catalog/NoSaleSign");	
		
		//Go redirected to end
		criteria.setType("sss");
		when(mockedService.findSaleSignPage(criteria)).thenReturn(emptyResult);
		view = searchController.search(model, criteria, result);
		assert view.equals("catalog/searchResultPage");
	}
}
