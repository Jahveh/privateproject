/*
 * Copyright 2008-2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.menards.ssc.test.controller;

import java.util.ArrayList;

import org.testng.annotations.DataProvider;

import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.catalog.SkuDTO;
import com.menards.ssc.domain.sign.Sign;

public class SearchDataProvider {

    @DataProvider(name = "searchDataProvider")
    public static Object[][] provideBasicCategory() {

    	SearchResult<SkuDTO> resultOne = new SearchResult<SkuDTO>();
    	resultOne.setPage(1);
    	resultOne.setPageSize(200);
    	resultOne.setTotalResults(100);
    	resultOne.setResult(new ArrayList<SkuDTO>());
    	
    	SearchResult<SkuDTO> resultTwo = new SearchResult<SkuDTO>();
    	resultTwo.setPage(1);
    	resultTwo.setPageSize(200);
    	resultTwo.setTotalResults(100);
    	resultTwo.setResult(new ArrayList<SkuDTO>());
		
		SkuDTO dto = new SkuDTO();
		dto.setDescription("description");
		dto.setSkuId(1000l);
		dto.setProductId(200l);		
		resultOne.getResult().add(dto);
		resultTwo.getResult().add(dto);
		
		SkuDTO dtoTwo = new SkuDTO();
		dtoTwo.setDescription("description");
		dtoTwo.setSkuId(1000l);
		dtoTwo.setProductId(200l);
		resultTwo.getResult().add(dtoTwo);
		
		
		SearchResult<Sign> signOneList = new SearchResult<Sign>();
		Sign signOne = new Sign();
		signOneList.addElement(signOne);
		
		SearchResult<Sign> signTwoList = new SearchResult<Sign>();
		Sign signTwo = new Sign();
		signTwoList.addElement(signOne);
		signTwoList.addElement(signTwo);
		
		
        return new Object[][] { { resultOne, resultTwo, signOneList, signTwoList} };
    }
}
