package com.menards.ssc.test.dao;

import javax.annotation.Resource;

import org.broadleafcommerce.core.catalog.dao.SkuDao;
import org.broadleafcommerce.core.catalog.domain.Sku;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.menards.ssc.test.base.BaseTest;



public class SkuDaoTest extends BaseTest {

    private Long skuId;

    @Resource
    private SkuDao skuDao;    
   
    
    @Test(groups = { "readSkuById" })
    @Transactional
    public void readSkuById() {
    	skuId = 9370000l;
        Sku item = skuDao.readSkuById(skuId);
        assert item != null;
        assert item.getId() == skuId;
    }

}
