package com.menards.ssc.test.controller;

import javax.annotation.Resource;

import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;
import org.testng.annotations.Test;

import com.menards.ssc.controller.catalog.BusinessCardController;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.catalog.BusinessCardDTO;
import com.menards.ssc.enums.MenardTitle;
import com.menards.ssc.test.base.BaseTest;

public class BusinessCardControllerTest  extends BaseTest{

	protected static final Long productId = 9370000L;
	protected static final Long skuId = 9370000L;
	
	
	@Resource(name = "businessCardController")
	private BusinessCardController businessCardController;
	

	@Test
	public void testNavigateBusinessCard() throws ItemNotFoundException {
		Model model = new ExtendedModelMap();
		SkuCartItem cartItem = new SkuCartItem();
        BusinessCardDTO businessCard = new BusinessCardDTO();
		cartItem.setSkuId(skuId);
		cartItem.setProductId(productId);
		String viewName =  businessCardController.navigateBusinessCard(cartItem, businessCard, model);
		
		assert "catalog/businesscard".equals(viewName);
	}
	
	@Test
	public void testHandleBusinessCard() throws ItemNotFoundException {
		SkuCartItem cartItem = new SkuCartItem();
		cartItem.setSkuId(skuId);
		cartItem.setProductId(productId);
		BindingResult result = new BeanPropertyBindingResult(cartItem, "");
		
		BusinessCardDTO card = new BusinessCardDTO();
		card.setTitle(MenardTitle.GM.getName());
		ModelAndView view =  businessCardController.confirm(cartItem, result, card);
		
		assert "catalog/businesscardconfirm".equals(view.getViewName());
	}
	
	
}
