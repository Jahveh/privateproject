package com.menards.ssc.test.controller;

import java.util.Date;

import javax.annotation.Resource;

import org.broadleafcommerce.common.currency.domain.BroadleafCurrency;
import org.broadleafcommerce.common.currency.service.BroadleafCurrencyService;
import org.broadleafcommerce.common.locale.domain.Locale;
import org.broadleafcommerce.common.locale.service.LocaleService;
import org.broadleafcommerce.core.catalog.dao.ProductDao;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.order.dao.OrderDao;
import org.broadleafcommerce.core.order.domain.DiscreteOrderItem;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.domain.OrderItem;
import org.broadleafcommerce.core.order.service.type.OrderItemType;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.broadleafcommerce.profile.core.domain.Customer;
import org.broadleafcommerce.profile.core.service.CustomerService;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.ModelAndView;
import org.testng.annotations.Test;

import com.menards.ssc.controller.order.TrackingHistoryController;
import com.menards.ssc.dao.order.MenardOrderDao;
import com.menards.ssc.dao.order.MenardOrderItemDao;
import com.menards.ssc.domain.order.MenardOrderItemTrackingHistory;
import com.menards.ssc.service.order.MenardOrderService;
import com.menards.ssc.test.base.BaseTest;

public class TrackingHistoryControllerTest extends BaseTest {

	@Resource(name = "menardOrderService")
	private MenardOrderService orderService;

	@Resource(name = "blOrderDao")
	private OrderDao orderDao;

	@Resource(name = "menardOrderDao")
	private MenardOrderDao menardOrderDao;

	@Resource(name = "menardOrderItemDao")
	private MenardOrderItemDao menardOrderItemDao;

	@Resource
	private BroadleafCurrencyService broadleafCurrencyService;

	@Resource
	private LocaleService localeService;

	@Resource
	private ProductDao productDao;

	@Resource(name = "blCustomerService")
	protected CustomerService customerService;

	private static final Long customerId = 1L;

	@Resource(name = "menardTrackingHistoryController")
	private TrackingHistoryController trackingHistoryController;

	@Test
	@Transactional
	public void testGetTrackingHistory() throws Exception {

		Order order = mockOrder();
		order = menardOrderDao.saveMenardOrder(order);

		MenardOrderItemTrackingHistory history = new MenardOrderItemTrackingHistory();
		history.setOrderId(order.getId());
		history.setOrderItemId(order.getOrderItems().get(0).getId());
		history.setStatus(null);
		history.setCreateDate(new Date());
		history.setCreateBy(null);
		menardOrderItemDao.saveOrderItemTrackingHistory(history);

		ModelAndView mv = trackingHistoryController.getTrackingHistory(order.getId(), order.getOrderItems().get(0)
				.getId());
		assert "order/trackingHistory".equals(mv.getViewName());

	}

	private Customer getCustomer() {
		Customer customer = customerService.readCustomerById(customerId);
		if (customer == null) {
			customer = customerService.createCustomer();
			customer = customerService.saveCustomer(customer);
		}
		return customer;
	}

	private Order mockOrder() {
		BroadleafCurrency currency = broadleafCurrencyService.findCurrencyByCode("USD");
		Order order = orderDao.create();
		order.setStatus(OrderStatus.SUBMITTED);
		order.setCurrency(currency);
		Locale locale = localeService.findLocaleByCode("en_US");
		order.setLocale(locale);

		OrderItem item = menardOrderItemDao.create(OrderItemType.DISCRETE);
		item.setOrder(order);
		item.setQuantity(1);
		Product product = productDao.readProductById(9370000L);
		((DiscreteOrderItem) item).setProduct(product);
		((DiscreteOrderItem) item).setSku(product.getDefaultSku());

		order.getOrderItems().add(item);

		Customer customer = getCustomer();
		order.setCustomer(customer);
		return order;
	}

}
