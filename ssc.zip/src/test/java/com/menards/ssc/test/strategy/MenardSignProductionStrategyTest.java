package com.menards.ssc.test.strategy;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.testng.annotations.Test;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.order.MenardDiscreteOrderItemImpl;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.service.catalog.MenardColorSignService;
import com.menards.ssc.service.catalog.MenardSignService;
import com.menards.ssc.strategy.approve.MenardItemApproveStrategy;
import com.menards.ssc.strategy.approve.MenardSignProductionStrategy;

public class MenardSignProductionStrategyTest {

	private MenardItemApproveStrategy strategy = new MenardSignProductionStrategy();

	private MenardOrderItem item = new MenardDiscreteOrderItemImpl();

	private String fulfillerCode = MenardFulfillerType.SIGN_PRODUCTION.getKey();

	private MenardColorSignService colorSignService = mock(MenardColorSignService.class);

	private MenardSignService signService = mock(MenardSignService.class);

	private Set<String> requestTypes = new HashSet<String>();
	{
		requestTypes.add(MenardOrderRequestType.Merch_Sign.getKey());
		requestTypes.add(MenardOrderRequestType.Zoomer.getKey());
		requestTypes.add(MenardOrderRequestType.Color_Signbase.getKey());
		requestTypes.add(MenardOrderRequestType.Color_Signbase_GM.getKey());
		Field field;
		try {
			field = MenardSignProductionStrategy.class.getDeclaredField("colorSignService");
			field.setAccessible(true);
			field.set(strategy, colorSignService);

			field = MenardSignProductionStrategy.class.getDeclaredField("signService");
			field.setAccessible(true);
			field.set(strategy, signService);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void signTest() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException {

		item.setFulfillerTypeCode(fulfillerCode);

		for (String type : requestTypes) {
			//Go order and has the same fulfiller type
			item.setRequestType(type);
			// item.setDcItem(CommonConstant.FALSE_STRING);
			processMerchSignAndZoomer(type, fulfillerCode);
			
			//Go order and has the different fulfiller type and print store
			item.setStorePrint(CommonConstant.TRUE_STRING);
			processMerchSignAndZoomer(type, fulfillerCode);
			
			//not Go order		
			item.setStatus(null);
			item.setStorePrint(CommonConstant.FALSE_STRING);
			if (MenardOrderRequestType.Color_Signbase_GM.getKey().equals(type)) {
				item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
				assert MenardOrderItemStatus.PENDING_GM.getValue().equals(item.getStatus());
			} else {				
				if (MenardOrderRequestType.Merch_Sign.getKey().equals(type)
						|| MenardOrderRequestType.Zoomer.getKey().equals(type)) {
					item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
					if (item.isStorePrint()) {
						assert MenardOrderItemStatus.PRINTED_AT_STORE.getValue().equals(item.getStatus());
					} else {
						assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());
					}
				} else {
					when(colorSignService.saveSignOrder(item)).thenReturn(true);
					item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
					assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());
			
					item.setStatus(null);
					when(colorSignService.saveSignOrder(item)).thenReturn(false);
					item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
					assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
				}
			}
			
			//Pending GM and not store print	
			item.setStorePrint(CommonConstant.FALSE_STRING);
			item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
			if (MenardOrderRequestType.Merch_Sign.getKey().equals(type)
					|| MenardOrderRequestType.Zoomer.getKey().equals(type)) {
				item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
				assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());
			} else {
				when(colorSignService.saveSignOrder(item)).thenReturn(true);
				item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
				assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());
		
				item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
				when(colorSignService.saveSignOrder(item)).thenReturn(false);
				item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
				assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
			}
			
			//Pending GM and not store print	
			item.setStorePrint(CommonConstant.TRUE_STRING);
			item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			if (MenardOrderRequestType.Merch_Sign.getKey().equals(type)
					|| MenardOrderRequestType.Zoomer.getKey().equals(type)) {
				assert MenardOrderItemStatus.PRINTED_AT_STORE.getValue().equals(item.getStatus());
			}
			
			//Pending GM and decline
			item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
			assert MenardOrderItemStatus.GM_DECLINED.getValue().equals(item.getStatus());
		
			//Pending GO and approve
			process(MenardOrderItemStatus.PENDING_GO.getValue(), type);
			
			//Pending GO and decline
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
			assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
			
			//Pending GO and backorder
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.BACKORDERED.getKey()));
			assert MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());
			
			//Pending backorder and approve			
			process(MenardOrderItemStatus.BACKORDERED.getValue(), type);
		}
	}
	
	@Test(groups =  {"OrderItemApproveStrategy"})
	public void welcomeSignsTest() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException {

		item.setFulfillerTypeCode(fulfillerCode);

		for (String type : Arrays.asList(MenardOrderRequestType.Welcome_Sign.getKey(), 
				MenardOrderRequestType.Business_Cards.getKey(), 
				MenardOrderRequestType.Color_Sign.getKey())) {
			
			//Go order and has the same fulfiller type
			item.setRequestType(type);
			item.setStatus(null);
			item.setStatus(strategy.getInitStatus(item, true, fulfillerCode));
			assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());
			
			//Not Go order
			item.setRequestType(type);
			item.setStatus(null);
			item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
			assert MenardOrderItemStatus.PENDING_GM.getValue().equals(item.getStatus());
			
			//Not Go order and pending gm
			item.setRequestType(type);
			item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.PENDING_GO.getValue().equals(item.getStatus());
			
			//Not Go order and pending gm
			item.setRequestType(type);
			item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
			assert MenardOrderItemStatus.GM_DECLINED.getValue().equals(item.getStatus());
			
			//Not Go order and pending go
			item.setRequestType(type);
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());
			
			//Not Go order and pending go
			item.setRequestType(type);
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.BACKORDERED.getKey()));
			assert MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());
			
			//Not Go order and pending go
			item.setRequestType(type);
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
			assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
			
			//Not Go order and pending bo
			item.setRequestType(type);
			item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.DECLINED.getKey()));
			assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
			
			//Not Go order and pending bo
			item.setRequestType(type);
			item.setStatus(MenardOrderItemStatus.BACKORDERED.getValue());
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());
		}
	}
	
	@Test
	public void cardStockTest() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException {
		
		item.setFulfillerTypeCode(fulfillerCode);
        String type = MenardOrderRequestType.CARD_STOCK.getKey();
		//Go order and has the same fulfiller type
		item.setRequestType(type);
		item.setStatus(null);
		item.setDcItem(CommonConstant.TRUE_STRING);
		item.setStatus(strategy.getInitStatus(item, true, fulfillerCode));
		processDcitem(true);
		
		item.setDcItem(CommonConstant.FALSE_STRING);
		item.setStatus(strategy.getInitStatus(item, true, fulfillerCode));
		processDcitem(true);
		
		item.setStatus(null);
		item.setDcItem(CommonConstant.TRUE_STRING);
		item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
		assert MenardOrderItemStatus.PENDING_GM.getValue().equals(item.getStatus());
	}
	
	private void processDcitem(Boolean isPendingGO) {
		if (item.isDcItem()) {
			assert MenardOrderItemStatus.BATCHED_FOR_DC.getValue().equals(item.getStatus());
			return;
		}
		if (isPendingGO) {
			assert MenardOrderItemStatus.IN_THE_MAIL.getValue().equals(item.getStatus());
		} else {
			assert MenardOrderItemStatus.PENDING_GO.getValue().equals(item.getStatus());
		}
	}
	
	private void process(String status, String type) {
		if (MenardOrderRequestType.Merch_Sign.getKey().equals(type)
				|| MenardOrderRequestType.Zoomer.getKey().equals(type)) {
			item.setStatus(status);
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			if (item.isStorePrint()) {
				assert MenardOrderItemStatus.PRINTED_AT_STORE.getValue().equals(item.getStatus());
			} else {
				assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());
			}
		} else {
			item.setStatus(status);
			when(colorSignService.saveSignOrder(item)).thenReturn(true);
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());
	
			item.setStatus(status);		
			when(colorSignService.saveSignOrder(item)).thenReturn(false);
			item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
			assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
		}
	}
	

	private void processMerchSignAndZoomer(String type, String fulfillerType) {
		if (MenardOrderRequestType.Merch_Sign.getKey().equals(type)
				|| MenardOrderRequestType.Zoomer.getKey().equals(type)) {
			item.setStatus(null);
			item.setStatus(strategy.getInitStatus(item, true, fulfillerType));
			if (item.isStorePrint()) {
				assert MenardOrderItemStatus.PRINTED_AT_STORE.getValue().equals(item.getStatus());
			} else {
				assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());
			}
		} else {
			item.setStatus(null);
			when(colorSignService.saveSignOrder(item)).thenReturn(true);
			item.setStatus(strategy.getInitStatus(item, true, fulfillerType));
			assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());
			item.setStatus(null);
			when(colorSignService.saveSignOrder(item)).thenReturn(false);
			item.setStatus(strategy.getInitStatus(item, true, fulfillerType));
			assert MenardOrderItemStatus.GO_DECLINED.getValue().equals(item.getStatus());
		}
	}
	
	@Test(expectedExceptions = {RuntimeException.class})
	public void unnormalConditionEmptyTest() {
		assert StringUtils.isEmpty(strategy.getInitStatus(null, false, null));
		assert StringUtils.isEmpty(strategy.getInitStatus(null, true, null));
		assert StringUtils.isEmpty(strategy.nextStage(null, MenardItemApproveAction.DECLINED.getKey()));
	}
}