package com.menards.ssc.test.dao;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.broadleafcommerce.common.currency.domain.BroadleafCurrency;
import org.broadleafcommerce.common.currency.service.BroadleafCurrencyService;
import org.broadleafcommerce.common.locale.domain.Locale;
import org.broadleafcommerce.common.locale.service.LocaleService;
import org.broadleafcommerce.core.catalog.dao.ProductDao;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.order.dao.OrderDao;
import org.broadleafcommerce.core.order.domain.DiscreteOrderItem;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.domain.OrderItem;
import org.broadleafcommerce.core.order.service.type.OrderItemType;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.broadleafcommerce.profile.core.domain.Customer;
import org.broadleafcommerce.profile.core.service.CustomerService;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.menards.ssc.dao.order.MenardOrderDao;
import com.menards.ssc.dao.order.MenardOrderItemDao;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderItemHistory;
import com.menards.ssc.domain.order.MenardOrderItemTrackingHistory;
import com.menards.ssc.test.base.BaseTest;

public class OrderDaoTest extends BaseTest {
	

	@Resource(name = "blOrderDao")
	private OrderDao orderDao;

	@Resource(name = "menardOrderDao")
	private MenardOrderDao menardOrderDao;
	
	@Resource(name = "menardOrderItemDao")
	private MenardOrderItemDao menardOrderItemDao;
	
	@Resource
	private BroadleafCurrencyService broadleafCurrencyService;
	
	@Resource
	private LocaleService localeService;
	
	@Resource
	private ProductDao productDao;
	
	@Resource(name = "blCustomerService")
	protected CustomerService customerService;	
	
	
	private static final Long customerId = 1L;	
	private static final String storeId = "3055";
	private static final Integer days = 7;

	@Test(groups = { "readOrderById" })
	@Transactional
	public void testReadOrderById() {		
		
		Order order = mockOrder();
		order = menardOrderDao.saveMenardOrder(order);
		Order viewOrder = menardOrderDao.readOrderById(order.getId());
		assert viewOrder != null;
		assert viewOrder.getId() == order.getId();
		 
	}

	@Test
	@Transactional
	public void testGetOrderByFilter() {		
		
		Order order = mockOrder();
		((MenardOrder)order).setStoreId(storeId);
		order.setStatus(OrderStatus.SUBMITTED);
		order.setSubmitDate(new Date());
		order = menardOrderDao.saveMenardOrder(order);
		List<MenardOrder> list = menardOrderDao.getOrderByFilter(((MenardOrder)order).getStoreId(), days, order.getId());
		assert list != null;
		assert list.size() > 0;
		
		
		
		Order orderAlternative = mockOrder();
		((MenardOrder)orderAlternative).setStoreId(storeId);
		orderAlternative.setStatus(OrderStatus.SUBMITTED);
		orderAlternative.setSubmitDate(new Date());
		orderAlternative = menardOrderDao.saveMenardOrder(orderAlternative);
		List<MenardOrder> listAlternative = menardOrderDao.getOrderByFilter("", null, null);
		assert listAlternative != null;
		assert listAlternative.size() > 0;
	}
	
	@Test
	@Transactional
	public void testGetTrackingHistory() {
		
		Order order = mockOrder();
		order = menardOrderDao.saveMenardOrder(order);
		
		
		MenardOrderItemTrackingHistory history = new MenardOrderItemTrackingHistory();
		history.setOrderId(order.getId());
		history.setOrderItemId(order.getOrderItems().get(0).getId());
		history.setStatus(null);
		history.setCreateDate(new Date());
		history.setCreateBy(null);
		menardOrderItemDao.saveOrderItemTrackingHistory(history);		
		
		
		MenardOrderItemHistory menardOrderItemHistory = menardOrderDao.getTrackingHistory(order.getOrderItems().get(0).getId());
		assert menardOrderItemHistory != null;
		assert menardOrderItemHistory.getId() == order.getOrderItems().get(0).getId();
		
	}
	
	
	private Customer getCustomer(){
    	Customer customer =  customerService.readCustomerById(customerId);
    	if(customer == null){
    		customer = customerService.createCustomer();
    		customer = customerService.saveCustomer(customer);
    	}
    	return customer;
    }
	
	private Order mockOrder(){
		 BroadleafCurrency currency = broadleafCurrencyService.findCurrencyByCode("USD");
		 Order order = orderDao.create();
		 order.setStatus(OrderStatus.SUBMITTED);
		 order.setCurrency(currency);
		 Locale locale = localeService.findLocaleByCode("en_US");
		 order.setLocale(locale);		 
		 
		 
		 OrderItem item = menardOrderItemDao.create(OrderItemType.DISCRETE);
		 item.setOrder(order);
		 item.setQuantity(1);
		 Product product = productDao.readProductById(9370000L);
		 ((DiscreteOrderItem)item).setProduct(product);
		 ((DiscreteOrderItem)item).setSku(product.getDefaultSku());
		 
		 order.getOrderItems().add(item);
		 
		 Customer customer =  getCustomer();
		 order.setCustomer(customer);
		 return order;		 
	 }	
	
	

}
