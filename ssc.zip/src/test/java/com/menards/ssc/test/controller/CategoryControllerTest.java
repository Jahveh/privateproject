package com.menards.ssc.test.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.broadleafcommerce.core.catalog.domain.Category;
import org.broadleafcommerce.core.search.service.SearchService;
import org.broadleafcommerce.core.web.service.SearchFacetDTOService;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.menards.ssc.controller.catalog.CategoryController;
import com.menards.ssc.domain.navigation.CategoryTreeNode;
import com.menards.ssc.service.catalog.MenardCatalogService;
import com.menards.ssc.test.base.BaseTest;


public class CategoryControllerTest extends BaseTest{
    @Resource(name = "blSearchService")
    protected SearchService searchService;
    
    @Resource(name = "blSearchFacetDTOService")
    protected SearchFacetDTOService facetService;
    
	@Resource(name = "blCatalogService")
    private MenardCatalogService catalogService;
	
	private CategoryController categoryController;
	private HttpServletRequest httpRequest;
	private HttpServletResponse httpResponse;
	public static final String CATEGORY_TREE_SERVLET_CONTEXT_KEY = "categoryTree";
	public static final String CATEGORY_TREE_DICTIONARY_SERVLET_CONTEXT_KEY = "categoryTreeDictionary";
	
	@BeforeMethod
	public void setup(){
		categoryController = new CategoryController();
		categoryController.setCatalogService(catalogService);
		categoryController.setFacetService(facetService);
		categoryController.setSearchService(searchService);
		httpRequest = buildMockHttpRequest();
		httpResponse = new MockHttpServletResponse();
		
	}
	
	@Test(enabled=true)
	public void testQuerySubcategories() throws Exception{
		httpRequest.setAttribute("category", httpRequest.getSession().getServletContext().getAttribute(CATEGORY_TREE_SERVLET_CONTEXT_KEY));
		ModelAndView mv = categoryController.handleRequest(httpRequest, httpResponse);
		System.out.println("testQuerySubcategories++++++"+mv.getViewName());
		assert "layout/home".equals(mv.getViewName());
	}
	
	@SuppressWarnings("unchecked")
	@Test(enabled=true)
	public void testQueryProductByCategory() throws Exception{
		CategoryTreeNode leafNode = null;
		Map<Long, CategoryTreeNode> categoryTreeDictionary = (Map<Long, CategoryTreeNode>)httpRequest.getSession().getServletContext().getAttribute(CATEGORY_TREE_DICTIONARY_SERVLET_CONTEXT_KEY);
		for(CategoryTreeNode ctn : categoryTreeDictionary.values()){
			if(ctn.isLeafNode()){
				leafNode = ctn;
				break;
			}
		}
		httpRequest.setAttribute("category", leafNode);
		ModelAndView mv = categoryController.handleRequest(httpRequest, httpResponse);
		System.out.println("testQueryProductByCategory++++++"+mv.getViewName());
		assert "catalog/productlist".equals(mv.getViewName());
	}
	
	private HttpServletRequest buildMockHttpRequest(){
		HttpServletRequest request = new MockHttpServletRequest();
		cramRequest(request);
		return request;
	}
	
	private void cramRequest(HttpServletRequest request) {
    	List<Category> list = catalogService.findAllCategories();
    	ServletContext servletContext = request.getSession().getServletContext();
        Map<Long, CategoryTreeNode> categoryTreeDictionary = createCategoryTreeDictionary(list);
        CategoryTreeNode root = getRootCatetoryTreeNode(categoryTreeDictionary);
        putCategoryTreeIntoServletContext(root, categoryTreeDictionary, servletContext);
    	markLeafNodes(categoryTreeDictionary);
    }
    
    private Map<Long, CategoryTreeNode> createCategoryTreeDictionary(List<Category> list){
    	Map<Long, CategoryTreeNode> categoryTreeDictionary = new HashMap<Long, CategoryTreeNode>();
    	for(Category category : list){
        	CategoryTreeNode treeNode = new CategoryTreeNode();
        	treeNode.setCategoryId(category.getId());
        	treeNode.setCategoryName(category.getName());
        	
        	if (category.getDefaultParentCategory() != null) {
        		treeNode.setParentCategoryId(category.getDefaultParentCategory().getId());
        	}
        	
        	treeNode.setUrl(category.getUrl());
        	treeNode.setCategoryDesc(category.getDescription());
        	//to-do
        	treeNode.setCategoryImgUrl(null);
        	categoryTreeDictionary.put(category.getId(), treeNode);
        }
    	return categoryTreeDictionary;
    }
    
    private CategoryTreeNode getRootCatetoryTreeNode(Map<Long, CategoryTreeNode> categoryTreeDictionary){
    	CategoryTreeNode root = null;
    	for(Map.Entry<Long, CategoryTreeNode> entry : categoryTreeDictionary.entrySet()){
    		CategoryTreeNode currentCategory = entry.getValue();
    		CategoryTreeNode parentCategory = categoryTreeDictionary.get(currentCategory.getParentCategoryId());
			currentCategory.setParentCategory(parentCategory);
    		if(parentCategory.getCategoryId().equals(currentCategory.getCategoryId())){
    			root = currentCategory;
    		}else{
    			parentCategory.getSubCategories().add(currentCategory);
    		}
    	}
    	return root;
    }
    
    private void putCategoryTreeIntoServletContext(CategoryTreeNode root, Map<Long, CategoryTreeNode> categoryTreeDictionary, ServletContext servletContext){
    	servletContext.setAttribute(CATEGORY_TREE_SERVLET_CONTEXT_KEY, root);
    	servletContext.setAttribute(CATEGORY_TREE_DICTIONARY_SERVLET_CONTEXT_KEY , categoryTreeDictionary);
    }
    
    private void markLeafNodes(Map<Long, CategoryTreeNode> categoryTreeDictionary){
    	for(CategoryTreeNode node : categoryTreeDictionary.values()){
    		if(node.getSubCategories().size()==0){
    			node.setLeafNode(true);
    		}else{
    			node.setLeafNode(false);
    		}
    	}
    }

	
	
}
