package com.menards.ssc.test.base;

import java.lang.management.ManagementFactory;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.broadleafcommerce.common.extensibility.context.MergeClassPathXMLApplicationContext;
import org.broadleafcommerce.common.extensibility.context.StandardConfigLocations;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.testng.annotations.BeforeTest;

import com.menards.mymenards.integration.vo.SecureUser;
import com.menards.ssc.security.MenardUserDetails;

@TransactionConfiguration(transactionManager = "blTransactionManager", defaultRollback = true)
@TestExecutionListeners(inheritListeners = false, value = { MergeDependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class, MergeTransactionalTestExecutionListener.class })
public abstract class BaseTest extends AbstractTestNGSpringContextTests {

	/*
	 * @PersistenceContext(unitName = "blPU") protected EntityManager em;
	 */

	protected static MergeClassPathXMLApplicationContext mergeContext = null;

	protected static List<String> moduleContexts = new ArrayList<String>();

	public static MergeClassPathXMLApplicationContext getContext() {
		try {
			if (mergeContext == null) {
				// Note that as of 2.2.0, this array will no longer include "bl-applicationContext-test", as we want
				// that to
				// be the very last context loaded.
				String[] contexts = StandardConfigLocations.retrieveAll(StandardConfigLocations.TESTCONTEXTTYPE);

				// After the framework applicationContexts are loaded, we want the module ones
				List<String> additionalContexts = new ArrayList<String>(moduleContexts);

				// Lastly, we want the test applicationContext
				additionalContexts.add("bl-applicationContext-test.xml");
				additionalContexts.add("applicationContext-client.xml");
				additionalContexts.add("menard-datasource-test.xml");
				additionalContexts.add("applicationContext.xml");
				additionalContexts.add("bl-cms-contentClient-applicationContext.xml");

				// If we're running in legacy test mode, we need that one too
				if (ManagementFactory.getRuntimeMXBean().getInputArguments().contains("-Dlegacy=true")) {
					additionalContexts.add("bl-applicationContext-test-legacy.xml");
				}

				String[] strArray = new String[additionalContexts.size()];
				mergeContext = new MergeClassPathXMLApplicationContext(contexts, additionalContexts.toArray(strArray));
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		initContext();
		return mergeContext;
	}

	protected static List<String> getModuleContexts() {
		return moduleContexts;
	}

	
	protected static void initContext() {
		initContext("tsmith_SG");
	}

	protected static void initContext(String username) {
		SecurityContext context = new SecurityContextImpl();
		MenardUserDetails details = new MenardUserDetails(username, "",
				Arrays.asList(new SimpleGrantedAuthority("ddd")));
		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(details,
				Arrays.asList(new SimpleGrantedAuthority("ddd")));
		context.setAuthentication(token);
		try {
			SecurityContextHolder.setContext(context);
			SecureUser user = new SecureUser();
			Field field = MenardUserDetails.class.getDeclaredField("secureUser");
			field.setAccessible(true);
			field.set(details, user);
			user.setYard(true);
			user.setStoreNumber("3281");
			user.setUserId("BCKOFF013011");
		} catch (Exception e) {
          System.out.println(e);
		}
	}
}
