package com.menards.ssc.test.controller;

import javax.annotation.Resource;

import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.validation.BeanPropertyBindingResult;
import org.testng.annotations.Test;

import com.menards.ssc.controller.catalog.UpdateQuantityController;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.cart.UpdateQuantityDTO;
import com.menards.ssc.test.base.BaseTest;


public class UpdateQuantityControllerTest extends BaseTest {
	
	protected static final Long productId = 9370000L;
	protected static final Long skuId = 9370000L;
	
	
	@Resource(name = "updateQuantityController")
	private UpdateQuantityController updateQuantityController;

	@Test
	public void testNavigateUpdateQuantity() throws ItemNotFoundException{
		Model model = new ExtendedModelMap();
		UpdateQuantityDTO uqd = new UpdateQuantityDTO();
		uqd.setSkuId(skuId + "");
		uqd.setProductId(productId + "");
		String viewName =  updateQuantityController.navigateUpdateQuantity(uqd,
				new BeanPropertyBindingResult(uqd, ""), model);
		
		assert "catalog/updatequantity".equals(viewName);
	}
	
}
