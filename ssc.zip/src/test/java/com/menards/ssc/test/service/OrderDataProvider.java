package com.menards.ssc.test.service;

import org.broadleafcommerce.common.currency.domain.BroadleafCurrency;
import org.broadleafcommerce.common.currency.service.BroadleafCurrencyService;
import org.broadleafcommerce.common.locale.domain.Locale;
import org.broadleafcommerce.common.locale.service.LocaleService;
import org.broadleafcommerce.core.catalog.dao.ProductDao;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.order.domain.DiscreteOrderItem;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.domain.OrderItem;
import org.broadleafcommerce.core.order.service.type.OrderItemType;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.broadleafcommerce.profile.core.domain.Customer;
import org.broadleafcommerce.profile.core.service.CustomerService;
import org.testng.annotations.DataProvider;

import com.menards.ssc.dao.order.MenardOrderDao;
import com.menards.ssc.dao.order.MenardOrderItemDao;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

public class OrderDataProvider{
	
	private static MenardOrderDao orderDao;
	
	private static MenardOrderItemDao orderItemDao;
	
	private static ProductDao productDao;
	
	private static BroadleafCurrencyService broadleafCurrencyService;
	
	private static LocaleService localeService;

	protected static CustomerService customerService;
	
	private static final Long customerId = 2L;
	private static final Long productId = 9370000L;
	
	public OrderDataProvider(){}
	
	public OrderDataProvider(
			MenardOrderDao orderDao,
			MenardOrderItemDao orderItemDao,
			ProductDao productDao,
			BroadleafCurrencyService broadleafCurrencyService,
			LocaleService localeService,
			CustomerService customerService){
		this.orderDao = orderDao;
		this.orderItemDao = orderItemDao;
		this.productDao = productDao;
		this.localeService = localeService;
		this.customerService = customerService;
		this.broadleafCurrencyService = broadleafCurrencyService;
	}

	@DataProvider(name = "mockOrder")
    public static Object[][] mockOrder() {

		BroadleafCurrency currency = broadleafCurrencyService.findCurrencyByCode("USD");
		Order order = orderDao.create();
		order.setStatus(OrderStatus.IN_PROCESS);
		order.setCurrency(currency);
		Locale locale = localeService.findLocaleByCode("en_US");
		order.setLocale(locale);

		OrderItem item = orderItemDao.create(OrderItemType.DISCRETE);
		((MenardOrderItem)item).setFulfillerTypeCode(MenardFulfillerType.MIDWEST.getKey());
		item.setOrder(order);
		item.setQuantity(1);
		Product product = productDao.readProductById(productId);
		((DiscreteOrderItem)item).setProduct(product);
		((DiscreteOrderItem)item).setSku(product.getDefaultSku());

		Customer customer = getCustomerWithSaved(customerId);
		order.setCustomer(customer);
		order.getOrderItems().add(item);
		
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		((MenardOrder)order).setCreatedByUserId(user.getUserId());

		order = orderDao.save(order);
		return new Object[][]{{order}};
    }
	

	private static Customer getCustomerWithSaved(Long customerId){
		Customer customer =  customerService.readCustomerById(customerId);
		if(customer == null){
			customer = customerService.createCustomer();
			customer = customerService.saveCustomer(customer);
		}
		return customer;
	}
	
	@DataProvider(name = "mockCustomer")
	public static Object[][] mockCustomer(){
		Customer customer = getCustomerWithSaved(customerId);
		
		return new Object[][]{{customer}};
	}
	
}
