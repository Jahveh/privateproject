package com.menards.ssc.test.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.broadleafcommerce.common.currency.domain.BroadleafCurrency;
import org.broadleafcommerce.common.currency.service.BroadleafCurrencyService;
import org.broadleafcommerce.common.locale.domain.Locale;
import org.broadleafcommerce.common.locale.service.LocaleService;
import org.broadleafcommerce.common.money.Money;
import org.broadleafcommerce.core.catalog.dao.ProductDao;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.broadleafcommerce.profile.core.domain.Customer;
import org.broadleafcommerce.profile.core.service.CustomerService;
import org.joda.time.DateTime;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.controller.order.MenardOrderItemFilterData;
import com.menards.ssc.dao.order.MenardOrderDao;
import com.menards.ssc.dao.order.MenardOrderItemDao;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.catalog.MenardSkuImpl;
import com.menards.ssc.domain.order.ItemApproveRequestDTO;
import com.menards.ssc.domain.order.MenardCartinfoDTO;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.order.MenardOrderItemApproveRequestDTO;
import com.menards.ssc.domain.order.MenardOrderItemDTO;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.service.order.MenardOrderItemService;
import com.menards.ssc.service.order.MenardOrderService;
import com.menards.ssc.service.yard.MenardYardService;
import com.menards.ssc.test.base.BaseTest;
import com.menards.ssc.test.dao.OrderItemDaoDataProvider;

@Transactional
public class MenardOrderItemServiceTest extends BaseTest{

	@Resource(name = "menardOrderItemService")
	private MenardOrderItemService menardOrderItemService;
	
	@Resource(name = "blCustomerService")
    protected CustomerService customerService;
    
    @Resource
    private MenardOrderDao orderDao;   
    
	@Resource(name = "menardOrderService")
    protected MenardOrderService menardOrderService;
	 
    @Resource
    private MenardOrderItemDao orderItemDao;
 
    @Resource
    private BroadleafCurrencyService broadleafCurrencyService;
 
    @Resource
    private LocaleService localeService;
    
    @Resource(name = "menardYardService")
	private MenardYardService yardService;
    
    @Resource
    private ProductDao productDao;
    
    protected Long itemId = null;
    
    protected Long storeId = null;
    
    protected Long orderId = null;
    

    @Test(groups =  {"OrderItemapprove"}, dataProvider="basicOrderItem", dataProviderClass=OrderItemDaoDataProvider.class)  
    @Rollback
    @Transactional
    public void testFindAllOrderItemsForApproval(MenardOrder order) throws Exception {
    	initData(order);
    	
		String requestType = MenardOrderRequestType.Employment_Office.getKey();
		
		MenardOrderItemFilterDTO filterDTO = new MenardOrderItemFilterDTO();		
		filterDTO.setStoreId(storeId.toString());
		
		List<MenardOrderItemDTO> list = null;
		list = menardOrderItemService.findAllOrderItemsForApproval(filterDTO);
		assert list.size() >= 1;
		
		filterDTO.setTrackingStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		list = menardOrderItemService.findAllOrderItemsForApproval(filterDTO);
		assert list.size() >= 1;			
		
		filterDTO.setRequestType(requestType);
		 list = menardOrderItemService.findAllOrderItemsForApproval(filterDTO);
		assert list.size() >= 1;			
		
		filterDTO.setDays(7);
		list = menardOrderItemService.findAllOrderItemsForApproval(filterDTO);
		assert list.size() >= 1;	
		filterDTO.setSort("ItemIdDESC");
		
		list = menardOrderItemService.findAllOrderItemsForApproval(filterDTO);
		assert list.size() >= 1;	
		
		filterDTO.setPage(1);
		filterDTO.setSize(10);
		list = menardOrderItemService.findOrderItemsPageForApproval(filterDTO).getResult();
		assert list.size() >=1;	
    	
    }
    
   
    protected void initData(MenardOrder order) {
    	storeId = (new Random()).nextInt()*(-1) % 100000 + 1l;
    	Long skuId = 9370000l;
    	
    	String requestType = MenardOrderRequestType.Employment_Office.getKey();
    	Set<String> set = new HashSet<String>();
    	set.add(MenardOrderItemStatus.PENDING_GM.getValue());
    	
    	//Prepare all the fundamental data
    	BroadleafCurrency currency = broadleafCurrencyService.findCurrencyByCode("USD");		 
		order.setStatus(OrderStatus.SUBMITTED);
		order.setCurrency(currency);
		order.setStoreId(storeId.toString());
		Locale locale = localeService.findLocaleByCode("en_US");
		order.setLocale(locale);
		order.setCustomer(getCustomer(1L));
		Product product = productDao.readProductById(skuId);
		MenardOrderItem item = (MenardOrderItem)order.getOrderItems().get(0);		
		item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());//set status
		item.setStatusDate((new DateTime()).minusDays(7).toDate());//Set date
		item.setRequestType(requestType);
		item.setProduct(product);
		MenardSku sku = new MenardSkuImpl();
		sku.setSkuCode("1234567");
		sku.setId(9370000l);
		sku.setProduct(product);
		sku.setRetailPrice(new Money(new BigDecimal(1000)));
		item.setSku(sku);
		item.setMenardOrder(order);
		item.setFulfillerTypeCode(MenardFulfillerType.EMPLOYMENT_OFFICE.getKey());
		MenardCartinfoDTO cartinfoDTO = new MenardCartinfoDTO();
		MenardOrder o = (MenardOrder)menardOrderService.saveMenardOrder(order, cartinfoDTO);
		itemId = o.getOrderItems().get(0).getId();
		orderId = o.getId();    	
    }
    
    @Test(groups =  {"OrderItemapprove"},dependsOnMethods={"testFindAllOrderItemsForApproval"}, dataProvider="basicOrderItem", dataProviderClass=OrderItemDaoDataProvider.class)
    @Rollback
    @Transactional
    public void testApproveOrderItems(MenardOrder order) throws Exception {
    	initData(order);
    	List<ItemApproveRequestDTO> items = new ArrayList<ItemApproveRequestDTO>();
    	
    	MenardOrderItemApproveRequestDTO dto = new MenardOrderItemApproveRequestDTO();
    	
    	Map<String, List<MenardOrderItemDTO>> map = menardOrderItemService.approveOrderItems(items);   	
    	assert map == MapUtils.EMPTY_MAP; 
    	
    	items.add(new ItemApproveRequestDTO(itemId, MenardItemApproveAction.APPROVED.getKey()));
    	items.add(new ItemApproveRequestDTO(itemId, ""));
    	
    	map = menardOrderItemService.approveOrderItems(items); 
    	assert map.get(storeId.toString()).size() >=1 
    			&& MenardOrderItemStatus.PENDING_GO.getDescription().equals(
    					map.get(storeId.toString()).get(0).getStatus());   
    	items.clear();
    	
    	items.add(new ItemApproveRequestDTO(itemId, MenardItemApproveAction.BACKORDERED.getKey()));   
    	map = menardOrderItemService.approveOrderItems(items); 
    	assert map.get(storeId.toString()).size() >=1  
    			&& MenardOrderItemStatus.BACKORDERED.getDescription().equals(
    					map.get(storeId.toString()).get(0).getStatus());   
    	items.clear();
    	items.add(new ItemApproveRequestDTO(itemId, MenardItemApproveAction.DECLINED.getKey()));
    	map = menardOrderItemService.approveOrderItems(items); 
    	assert map.get(storeId.toString()).size() >=1 
    			&& MenardOrderItemStatus.GO_DECLINED.getDescription().equals(
    					map.get(storeId.toString()).get(0).getStatus());   
    	items.clear();
    	dto.setItems(items);
    	dto.toString();
    }
    
    
    @Test(groups =  {"OrderItemapprove"})
    public void testMenardOrderItemFilterData() throws Exception {    	
    	MenardOrderItemFilterData data = MenardOrderItemFilterData.createInstance(CommonConstant.QUERY_TYPE_APPROVE, yardService);    	
    	assert data != null && data.getRequestType().size() >= 0;    	
        data = MenardOrderItemFilterData.createInstance(CommonConstant.QUERYTYPE_HISTORY, yardService);    	
    	assert data != null && data.getRequestType().size() >= 0;
    	data = MenardOrderItemFilterData.createInstance("aaaaaa", null);    	
      	assert data != null && CollectionUtils.isEmpty(data.getStatus());
    }
    
    /*@AfterTest
    public void clearUpOrderData() {
    	if(orderId != null){
    		Order order = menardOrderService.getOrderById(orderId);
    		if(order != null){    			
    			menardOrderService.deleteOrder(order);
    		}
    	}
    }*/
    
    private Customer getCustomer(Long customerId){
    	Customer customer =  customerService.readCustomerById(customerId);
    	if(customer == null){
    		customer = customerService.createCustomer();
    		customer = customerService.saveCustomer(customer);
    	}
    	return customer;
    }
}
