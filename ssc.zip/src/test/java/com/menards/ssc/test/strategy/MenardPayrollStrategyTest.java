package com.menards.ssc.test.strategy;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.menards.order.clothing.ClothingOrder;
import com.menards.order.clothing.OrderLine;
import com.menards.order.clothing.OrderStatus;
import com.menards.ssc.constants.CommonConstant;
import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;
import org.apache.commons.lang.StringUtils;
import org.broadleafcommerce.common.money.Money;
import org.broadleafcommerce.core.catalog.domain.SkuAttribute;
import org.broadleafcommerce.core.catalog.domain.SkuAttributeImpl;
import org.mockito.Mockito;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.menards.ssc.constants.SkuAttributeKey;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.catalog.MenardSkuImpl;
import com.menards.ssc.domain.order.MenardDiscreteOrderItemImpl;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderImpl;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.yard.Store;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.jms.JmsQueueSender;
import com.menards.ssc.service.yard.MenardYardService;
import com.menards.ssc.strategy.approve.MenardItemApproveStrategy;
import com.menards.ssc.strategy.approve.MenardPayrollStrategy;
import com.menards.ssc.util.MenardUtil;

public class MenardPayrollStrategyTest {

	private MenardItemApproveStrategy strategy = new MenardPayrollStrategy();

	private MenardOrderItem item = new MenardDiscreteOrderItemImpl();

	private String fulfillerCode = MenardFulfillerType.SIGN_PRODUCTION.getKey();
	
	
//	@BeforeTest
	public void setup() {		
		MenardOrder order = new MenardOrderImpl();
		order.setId(1000l);
		order.setDeptId("100");
		order.setOrderNumber("100");
		order.setStoreId("1");
		item.setMenardOrder(order);
		item.setLineNumber(100);
		MenardSku sku = new MenardSkuImpl();
		sku.setId(9370000L);
		sku.setSkuCode("9370000");
		sku.setAvailable(true);	
		sku.setRetailPrice(new Money(1000));
		item.setSku(sku);
		Map<String, SkuAttribute> skuAttribute = sku.getSkuAttributes();
		SkuAttribute attr = new SkuAttributeImpl();
		attr.setId(1000l);
		attr.setName(sku.getMenardSku());
		attr.setValue("9370000");		
		skuAttribute.put(sku.getMenardSku(), attr);
		sku.setSkuAttributes(skuAttribute);
		MenardYardService mockedService = mock(MenardYardService.class);		
		Store store = new Store();
		store.setStoreNumber("3011");
		store.setStoreName("storename");
		store.setZip("54755");		
		try {
			when(mockedService.getStore("1")).thenReturn(store);
			Field field;
			field = MenardPayrollStrategy.class.getDeclaredField("yardService");
			field.setAccessible(true);
			field.set(strategy, mockedService);
			
			JmsQueueSender jmsQueueSender = mock(JmsQueueSender.class);		
			when(jmsQueueSender.send(Mockito.anyString())).thenReturn(true);
			Field sender;
			sender = MenardPayrollStrategy.class.getDeclaredField("jmsQueueSender");
			sender.setAccessible(true);
			sender.set(strategy, jmsQueueSender);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

    @Test
    public void testJaxbMarshalling() {
        MenardOrder menardOrder = new MenardOrderImpl();
        menardOrder.setId(123L);
        menardOrder.setDeptId("234");
        List<MenardOrderItem> list = new ArrayList<MenardOrderItem>();
        item.setMenardOrder(menardOrder);
        item.setLineNumber(100);
        MenardSku sku = new MenardSkuImpl();
        sku.setId(9370000L);
        sku.setSkuCode("9370000");
        sku.setAvailable(true);
        sku.setRetailPrice(new Money(1000));
        item.setSku(sku);
        list.add(item);
        Store store = new Store();
        store.setStoreNumber("1999");
        store.setZip("95008");
        store.setStoreName("test store");

        String xml = new MenardPayrollStrategy().generateMessage(menardOrder, list, store);
        System.out.println("Marshaled Menard Order Object :: \n" + xml);


    }

	@Test(groups =  {"OrderItemApproveStrategy"})
	public void employmentStrategyTest() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException {
		
		item.setFulfillerTypeCode(fulfillerCode);
		item.setRequestType(MenardOrderRequestType.Clothing.getKey());
		
		// Go order and has the same fulfiller type		
		item.setStatus(null);
		item.setStatus(strategy.getInitStatus(item, true, fulfillerCode));
		assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());

		// Not Go order		
		item.setStatus(null);
		item.setStatus(strategy.getInitStatus(item, false, fulfillerCode));
		assert MenardOrderItemStatus.PENDING_GM.getValue().equals(item.getStatus());

		// Not Go order and pending gm		
		item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());

		
		// Not Go order and pending go
		item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		item.setStatus(strategy.nextStage(item, MenardItemApproveAction.APPROVED.getKey()));
		assert MenardOrderItemStatus.REQUEST_SENT.getValue().equals(item.getStatus());
	}
	@Test(expectedExceptions = {RuntimeException.class})
	public void unnormalConditionEmptyTest() {
		assert StringUtils.isEmpty(strategy.getInitStatus(null, false, null));
		assert StringUtils.isEmpty(strategy.getInitStatus(null, true, null));
		assert StringUtils.isEmpty(strategy.nextStage(null, MenardItemApproveAction.DECLINED.getKey()));
	}
}