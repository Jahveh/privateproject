package com.menards.ssc.test.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.broadleafcommerce.common.currency.domain.BroadleafCurrency;
import org.broadleafcommerce.common.currency.service.BroadleafCurrencyService;
import org.broadleafcommerce.common.locale.domain.Locale;
import org.broadleafcommerce.common.locale.service.LocaleService;
import org.broadleafcommerce.common.web.BroadleafRequestContext;
import org.broadleafcommerce.core.catalog.dao.ProductDao;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.order.domain.DiscreteOrderItem;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.domain.OrderItem;
import org.broadleafcommerce.core.order.service.OrderService;
import org.broadleafcommerce.core.order.service.exception.AddToCartException;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.broadleafcommerce.core.order.service.type.OrderItemType;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.broadleafcommerce.profile.core.domain.Customer;
import org.broadleafcommerce.profile.core.service.CustomerService;
import org.broadleafcommerce.profile.web.core.CustomerState;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.menards.ssc.dao.order.MenardOrderDao;
import com.menards.ssc.dao.order.MenardOrderItemDao;
import com.menards.ssc.domain.cart.AddCartRequest;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.order.MenardCartinfoDTO;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderDTO;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.domain.order.MenardOrderItemHistory;
import com.menards.ssc.domain.order.MenardOrderItemTrackingHistory;
import com.menards.ssc.domain.order.MenardOrderOptionsDTO;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.order.MenardOrderItemService;
import com.menards.ssc.service.order.MenardOrderService;
import com.menards.ssc.test.base.BaseTest;

@Transactional("blTransactionManager")
public class OrderServiceTest extends BaseTest {

	@Resource(name = "menardOrderItemDao")
	private MenardOrderItemDao menardOrderItemDao;

	@Resource(name = "menardOrderItemService")
	private MenardOrderItemService menardOrderItemService;
	
	@Resource(name = "blOrderService")
	protected OrderService orderService;

	@Resource
	private MenardOrderDao orderDao;

	@Resource
	private ProductDao productDao;

	@Resource
	private MenardOrderItemDao orderItemDao;

	@Resource(name = "menardOrderService")
	protected MenardOrderService menardOrderService;

	@Resource(name = "blCustomerService")
	protected CustomerService customerService;

	@Resource
	private BroadleafCurrencyService broadleafCurrencyService;

	@Resource
	private LocaleService localeService;

	private static final Long customerId = 1L;
	private static final Long productId = 9370000L;
	private static final Long skuId = 9370000L;
	private static final Integer days = 7;
	private static final String storeId = "3055";


	@BeforeTest
	public void initRequest(){
		//mock reqeust context
		HttpServletRequest request = new MockHttpServletRequest();
		BroadleafRequestContext broadleafRequestContext = new BroadleafRequestContext();
		broadleafRequestContext.setRequest(request);
		BroadleafRequestContext.setBroadleafRequestContext(broadleafRequestContext);
	}

	@Test
	@Transactional
	public void testGetOrderByFilter() throws Exception {

		MenardOrderItemFilterDTO filterDTO = new MenardOrderItemFilterDTO() ;
		Order order = mockOrder();
		
		((MenardOrder) order).setStoreId(storeId);
		order.setStatus(OrderStatus.SUBMITTED);
		order.setSubmitDate(new Date());
		order = orderDao.saveMenardOrder(order);
		
		filterDTO.setOrderId(order.getId());
		filterDTO.setStoreId(((MenardOrder)order).getStoreId());
		filterDTO.setDays(days);
		
		List<MenardOrderDTO> list = menardOrderService.getOrderByFilter(filterDTO);
		assert list != null;
		assert list.size() > 0;	
		
		MenardOrderItemFilterDTO filterDTONull = new MenardOrderItemFilterDTO() ;
		Order orderAlternative = mockOrder();
		
		((MenardOrder) orderAlternative).setStoreId(storeId);
		orderAlternative.setStatus(OrderStatus.SUBMITTED);
		orderAlternative.setSubmitDate(new Date());
		orderAlternative = orderDao.saveMenardOrder(orderAlternative);
		filterDTONull.setOrderId(null);
		filterDTONull.setStoreId("");
		filterDTONull.setDays(null);
		
		List<MenardOrderDTO> listAlternative = menardOrderService.getOrderByFilter(filterDTONull);
		assert listAlternative != null;
		assert listAlternative.size() > 0;
		
	}
	
	
	@Test
	@Transactional
	public void testGetOrderById() throws Exception {
		
		Order order = mockOrder();		
		order = orderDao.saveMenardOrder(order);		
		Order testOrder = menardOrderService.getOrderById(order.getId());
		assert testOrder != null;
		assert testOrder.getId() == order.getId();	
	}
	
	
	@Test
	@Transactional
	public void testGetTrackingHistory() {
		
		Order order = mockOrder();
		order = orderDao.saveMenardOrder(order);		
		
		MenardOrderItemTrackingHistory history = new MenardOrderItemTrackingHistory();
		history.setOrderId(order.getId());
		history.setOrderItemId(order.getOrderItems().get(0).getId());
		history.setStatus(null);
		history.setCreateDate(new Date());
		history.setCreateBy(null);
		menardOrderItemDao.saveOrderItemTrackingHistory(history);		
		
		MenardOrderItemHistory menardOrderItemHistory = menardOrderService.getTrackingHistory(order.getOrderItems().get(0).getId());
		assert menardOrderItemHistory != null;
		assert menardOrderItemHistory.getId() == order.getOrderItems().get(0).getId();
		
	}

	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void testAddItem(Order cart) throws ItemNotFoundException {
		orderDao.save(cart);
		addItemToCart(cart);
		assert cart != null;
		assert cart.getOrderItems() != null;
		assert cart.getOrderItems().size() > 0;
		boolean hasProduct = false;
		for(OrderItem item : cart.getOrderItems()){
			MenardOrderItem orderItem = (MenardOrderItem)item;
			if(productId.equals(orderItem.getProduct().getId())){
				hasProduct = true;
			}
		}
		assert hasProduct;
	}

	
	private Order addItemToCart(Order cart) throws ItemNotFoundException {
		SkuCartItem cartItem = new SkuCartItem();
		cartItem.setProductId(productId);
		cartItem.setSkuId(skuId);
		cartItem.setQuantity(1);
		cart = menardOrderService.addItem(cart, cartItem);
		return cart;
	}
	
	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void testAddItems2Cart(Order cart) throws ItemNotFoundException{
		orderDao.save(cart);
		AddCartRequest request = new AddCartRequest();
		SkuCartItem cartItem = new SkuCartItem();
		cartItem.setProductId(productId);
		cartItem.setSkuId(skuId);
		cartItem.setQuantity(1);
		request.setMainSku(cartItem);
		menardOrderService.addItems2Cart(cart, request);
		Order order = menardOrderService.findOrderById(cart.getId());
		assert order != null;
		assert order.getOrderItems().size() > 0 ;
	}

	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void testUpdateOrderItems(Order cart) throws ItemNotFoundException {
		orderDao.save(cart);
		if (cart.getOrderItems().size() == 0) {
			cart = addItemToCart(cart);
		}

		DiscreteOrderItem orderItem = (DiscreteOrderItem) cart.getOrderItems().get(0);
		Long orderItemId = orderItem.getId();

		SkuCartItem itemRequest = new SkuCartItem();
		itemRequest.setProductId(orderItem.getProduct().getId());
		itemRequest.setQuantity(2);
		itemRequest.setOrderItemId(orderItem.getId());
//		itemRequest.setItemAttributes(new HashMap<String, String>());

		List<SkuCartItem> itemRequests = new ArrayList<SkuCartItem>();
		itemRequests.add(itemRequest);

		cart = menardOrderService.updateOrderItems(cart, itemRequests);

		boolean updated = false;
		for (OrderItem item : cart.getOrderItems()) {
			if (item.getId().equals(orderItemId) && item.getQuantity() == 2) {
				updated = true;
			}
		}
		assert updated;
	}

	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void testUpdateOrderItemsWithRemoveItem(Order cart) throws ItemNotFoundException {
		orderDao.save(cart);
		if (cart.getOrderItems().size() == 0) {
			cart = addItemToCart(cart);
		}
		cart = addItemToCart(cart);

		int size = cart.getOrderItems().size();
		DiscreteOrderItem removedOrderItem = (DiscreteOrderItem) cart.getOrderItems().get(0);
		Long removedOrderItemId = removedOrderItem.getId();
		
		DiscreteOrderItem orderItem = (DiscreteOrderItem) cart.getOrderItems().get(1);
		Long orderItemId = orderItem.getId();

		SkuCartItem itemRequest = new SkuCartItem();
		itemRequest.setProductId(orderItem.getProduct().getId());
		itemRequest.setQuantity(2);
		itemRequest.setOrderItemId(orderItemId);
//		itemRequest.setItemAttributes(new HashMap<String, String>());

		List<SkuCartItem> itemRequests = new ArrayList<SkuCartItem>();
		itemRequests.add(itemRequest);

		cart = menardOrderService.updateOrderItems(removedOrderItemId, cart, itemRequests);

		boolean updated = false;
		for (OrderItem item : cart.getOrderItems()) {
			if (item.getId().equals(orderItemId)) {
				updated = true;
			}
		}
		assert updated;

		assert size == cart.getOrderItems().size() + 1;
	}


	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void testSaveMenardOrder(Order order) {
		orderDao.save(order);
		MenardCartinfoDTO cartinfoDTO = new MenardCartinfoDTO();
		order = menardOrderService.saveMenardOrder(order, cartinfoDTO);

		assert order != null;
		assert order.getId() != null;
		assert order.getOrderItems() != null;
		assert order.getOrderItems().size() > 0;

		order = menardOrderService.findOrderById(order.getId());
		assert order != null;
		assert order.getId() != null;
		assert order.getOrderItems() != null;
		assert order.getOrderItems().size() > 0;
	}


	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void testPlacedOrder(Order cart) throws AddToCartException, ItemNotFoundException {
		orderDao.save(cart);
		if (cart.getOrderItems().size() == 0) {
			cart = addItemToCart(cart);
		}
		cart.setStatus(OrderStatus.SUBMITTED);
		cart.setSubmitDate(new Date());

		Long storeId1 = 3011l;
		Long storeId2 = 3013l;
		List<String> storeIds = new ArrayList<String>();
		storeIds.add(String.valueOf(storeId1));
		storeIds.add(String.valueOf(storeId2));

		MenardOrderOptionsDTO option = newMenardOrderOptionsDTO(storeIds);

		((MenardOrder) cart).setDueDate(new Date());
		((MenardOrder) cart).setCommentPlaced("order options comment test");
		((MenardOrder) cart).setOrderType("NEW");
		((MenardOrder) cart).setGrouping("grouping test");
		((MenardOrder) cart).setDeptId("100");
		((MenardOrder) cart).setRequestBy("request by ut");

		Long cartId = cart.getId();
		orderDao.save(cart);
		cart = menardOrderService.findOrderById(cartId);
		

		menardOrderService.placedOrder(cart, option.getStoreIds());

		cart = menardOrderService.findOrderById(cartId);

		assert cart != null;
		assert OrderStatus.SUBMITTED.equals(cart.getStatus());

		assert "NEW".equals(((MenardOrder) cart).getOrderType());
	}

	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void testFindMenardOrderByStatus(Order order) {
		order.setStatus(OrderStatus.NAMED);
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		((MenardOrder)order).setCreatedByUserId(user.getUserId());
		orderDao.saveMenardOrder(order);
		 
		List<MenardOrder> orders = menardOrderService.findMenardOrderByStatus(OrderStatus.NAMED);
		assert orders != null;
	}

	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void testReplaceCart(Order cart) {
		orderDao.save(cart);
		Order  order = mockOrder();
		Order newCart = menardOrderService.replaceCart(cart, order.getId());
		assert newCart != null;
		assert newCart.getId() != null;
		assert !newCart.getId().equals(cart.getId());
	}

	@Test(dataProvider="mockOrder", dataProviderClass=OrderDataProvider.class)
	@Transactional
	public void testDeleteOrder(Order order){
		orderDao.save(order);
		Long orderId = order.getId();
		menardOrderService.deleteOrder(order);
		Order deletedOrder = menardOrderService.findOrderById(orderId);
		assert deletedOrder == null;
	}

	private MenardOrderOptionsDTO newMenardOrderOptionsDTO(List<String> storeIds) {
		MenardOrderOptionsDTO option = new MenardOrderOptionsDTO();
		option.setStoreIds(storeIds);
		option.setDueDate(new Date());
		option.setComment("order options comment test");
		option.setOrderType("NEW");
		option.setGroup("grouping test");
		option.setDeptId("100");
		option.setRequestBy("request by tester");
		return option;
	}


	@Transactional
	private Order mockOrder() {
		BroadleafCurrency currency = broadleafCurrencyService.findCurrencyByCode("USD");
		Order order = orderDao.create();
		order.setStatus(OrderStatus.IN_PROCESS);
		order.setCurrency(currency);
		Locale locale = localeService.findLocaleByCode("en_US");
		order.setLocale(locale);

		Customer customer = getCustomerWithSaved(customerId);
		CustomerState.setCustomer(customer);
		order.setCustomer(customer);

		orderDao.save(order);

		OrderItem item = orderItemDao.create(OrderItemType.DISCRETE);
		item.setOrder(order);
		item.setQuantity(1);
		Product product = productDao.readProductById(productId);
		((DiscreteOrderItem) item).setProduct(product);
		((DiscreteOrderItem) item).setSku(product.getDefaultSku());
		order.getOrderItems().add(item);

		return orderDao.save(order);
	}

	private Customer getCustomerWithSaved(Long customerId) {
		Customer customer = customerService.readCustomerById(customerId);
		if (customer == null) {
			customer = customerService.createCustomer();
		}
		return customerService.saveCustomer(customer);
	}



}
