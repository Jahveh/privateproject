package com.menards.ssc.test.service.sku;

/**
 * Please modify this class to meet your needs
 * This class is not complete
 */

import java.util.Arrays;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.menards.service.sku.DerivedStatus;
import com.menards.service.sku.GetDerivedStatusByStoreSkuResponse;
import com.menards.service.sku.GetStoreAvailabilityBySkuResponse;
import com.menards.service.sku.SkuService;
import com.menards.service.sku.StoreAvailability;
import com.menards.ssc.service.skustatus.SSCGetDerivedStatusByStoreSku;
import com.menards.ssc.service.skustatus.SSCGetStoreAvailabilityBySku;

public final class MenardSkuStatusClient {

	private MenardSkuStatusClient() {
	}

	public static void main(String args[]) throws Exception {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] { "applicationContext-client.xml" });
		SkuService skuService = (SkuService) context.getBean("skuService");
		SSCGetStoreAvailabilityBySku parameter = new SSCGetStoreAvailabilityBySku();
		parameter.setSkuNumbers(Arrays.asList(1000009,1021004,1021017,1021020,1021075));
		GetStoreAvailabilityBySkuResponse responseOne = skuService.getStoreAvailabilityBySku(parameter);
		
		for (StoreAvailability availability : responseOne.getReturn().getStoreAvailability()) {
			System.out.println(availability.getSkuNumber() + "|" + availability.isStoreAvailabilityFlag());
		}
		
		SSCGetDerivedStatusByStoreSku parameters = new SSCGetDerivedStatusByStoreSku();
		parameters.setStoreNumber(3259);
		parameters.setSkuNumbers(Arrays.asList(1000009,1021004,9409969,9409968,9409967,9409966,9409965,9409964,9409963,9409962,9409961,9409960,9409959,9409958));
		
		GetDerivedStatusByStoreSkuResponse response = skuService.getDerivedStatusByStoreSku(parameters);	
		for (DerivedStatus status : response.getReturn().getDerivedStatus()) {
			System.out.println(status.getStoreNumber() + "|" + status.getSkuNumber() + "|" +  status.getDerivedStatusCode());
		}		
		
		context.close();
		System.exit(0);
	}

}
