package com.menards.ssc.message;

import java.util.Locale;

import org.broadleafcommerce.common.util.BroadleafMergeResourceBundleMessageSource;

/**
 *
 * <p>MessageSourceHelper</p>
 * <p>to get localization message</p>
 *
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class MessageSourceHelper {

	private BroadleafMergeResourceBundleMessageSource messageSource;

	public BroadleafMergeResourceBundleMessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(BroadleafMergeResourceBundleMessageSource messageSource) {
		this.messageSource = messageSource;
	}

	/**
	 *
	 * get localization messages
	 * @param code String
	 * @param args Object[]
	 * @param defaultMessage String
	 * @param locale  Locale
	 * @return String
	 */
	public String getMessage(String code, Object[] args, String defaultMessage, Locale locale) {
		String msg = messageSource.getMessage(code, args, defaultMessage, locale);
		if (msg == null) {
			return defaultMessage;
		} else {
			return msg.trim();
		}
	}

	/**
	 *
	 * get localization message
	 * @param code String
	 * @param args Object[]
	 * @param defaultMessage String
	 * @return String
	 */
	public String getMessage(String code, Object[] args, String defaultMessage) {
		return this.getMessage(code, args, defaultMessage, null);
	}

}
