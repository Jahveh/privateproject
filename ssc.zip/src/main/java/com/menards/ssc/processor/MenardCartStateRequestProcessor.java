package com.menards.ssc.processor;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.web.order.security.CartStateRequestProcessor;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.WebRequest;

import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.order.MenardOrderService;

/**
 *
 * <p>MenardCartStateRequestProcessor</p>
 * <p> deal with cart</p>
 * <p>
 * get in progress cart for current customer,
 * if there is no cart, create it
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class MenardCartStateRequestProcessor extends CartStateRequestProcessor {

	private static final Log LOG = LogFactory.getLog(MenardCartStateRequestProcessor.class);

	@Resource(name = "menardOrderService")
	private MenardOrderService menardeOrderService;

	@Override
	public void process(WebRequest request) {
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		if (user != null) {
			String userId = user.getUserId();
			if (user.isYard()) {
				userId += user.getStoreNumber();
			}
			Order cart = menardeOrderService.findCartByUserId(userId);
			if (cart == null) {
				LOG.debug("create new cart for userId:" + userId);
				cart = menardeOrderService.createOrderForNewUser(userId);
			}

			request.setAttribute(cartRequestAttributeName, cart, RequestAttributes.SCOPE_REQUEST);
			request.setAttribute("currentUser", user, RequestAttributes.SCOPE_REQUEST);
		}

	}
}
