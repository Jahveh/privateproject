package com.menards.ssc.processor;

import javax.annotation.Resource;

import org.broadleafcommerce.profile.core.domain.Customer;
import org.broadleafcommerce.profile.core.service.CustomerService;
import org.broadleafcommerce.profile.web.core.security.CustomerStateRequestProcessor;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.WebRequest;

/**
 * <p>MenardCustomerStateRequestProcessor</p>
 * <p>override broadleaf processor</p>
 * <p>
 * override broadleaf processor to adapte menard user
 * user is the same as customer in menard
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class MenardCustomerStateRequestProcessor extends CustomerStateRequestProcessor {

	@Resource(name = "blCustomerService")
	private CustomerService customerService;

	private static final Long CUSTOMER_ID = 10000000L;

	@Override
	public void process(WebRequest request) {
		Customer customer = customerService.readCustomerById(CUSTOMER_ID);
		if (customer == null) {
			customer = customerService.createCustomerFromId(CUSTOMER_ID);
			customer.setUsername(CUSTOMER_ID.toString());
			customer = customerService.saveCustomer(customer);
		}
		request.setAttribute(customerRequestAttributeName, customer, RequestAttributes.SCOPE_REQUEST);
	}

}
