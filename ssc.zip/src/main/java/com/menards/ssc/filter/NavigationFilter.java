package com.menards.ssc.filter;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.context.ApplicationContext;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.access.intercept.DefaultFilterInvocationSecurityMetadataSource;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
import org.springframework.security.web.util.AntPathRequestMatcher;
import org.springframework.security.web.util.RequestMatcher;
import org.springframework.util.Assert;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.menards.ssc.controller.catalog.CategoryController;
import com.menards.ssc.domain.navigation.CategoryTreeNode;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.catalog.CategoryTreeService;
import com.menards.ssc.service.security.MenardSecurityService;

/**
 *
 * <p>NavigationFilter</p>
 * <p>A filter that intercept the url and then find the corresponding the category ID,
 * and then save it into HttpSession </p>
 * <p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class NavigationFilter implements Filter {
	private final Log logger = LogFactory.getLog(NavigationFilter.class);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@SuppressWarnings("unchecked")
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
			ServletException {
		HttpServletRequest servletRequest = (HttpServletRequest) request;
		HttpSession httpSession = servletRequest.getSession();
		ServletContext servletContext = httpSession.getServletContext();
		Map<Long, CategoryTreeNode> categoryTreeDictionary = (Map<Long, CategoryTreeNode>) servletContext
				.getAttribute(CategoryTreeService.CATEGORY_TREE_DICTIONARY_SERVLET_CONTEXT_KEY);
		String requestingUrl = FilterUtils.getCanonicalRequestUrl(servletRequest);

		if (requestingUrl.contains("rest/category")) {
			if (isRefreshingCategoryRequest(((HttpServletRequest) request), (HttpServletResponse) response)) {

				return;
			}
		}

		Long categoryId = lookupCategoryUrlWithRequestingUrl(requestingUrl, categoryTreeDictionary);
		if (categoryId != null) { // category found in the "categoryTreeDictionary"
			httpSession.setAttribute(CategoryController.SELECTED_CATEGORY_ID_SESSION_KEY, categoryId.toString());
		} else { // try to match the most part of the requesting url with the url's in categoryTreeDictionary
			while (requestingUrl.indexOf('/') != -1) {
				requestingUrl = requestingUrl.substring(0, requestingUrl.lastIndexOf('/'));
				categoryId = lookupCategoryUrlWithRequestingUrl(requestingUrl, categoryTreeDictionary);
				if (categoryId != null) {
					httpSession
							.setAttribute(CategoryController.SELECTED_CATEGORY_ID_SESSION_KEY, categoryId.toString());
					break;
				}
			}
		}
		// Get current user's authorities/roles
		if (StringUtils.isNotBlank(requestingUrl)
				&& !(StringUtils.contains(requestingUrl, "/login") || StringUtils
						.contains(requestingUrl, "/loginCheck"))) {

			/**
			 * [START]get role and accessible page mappings 
			 */
			ApplicationContext applicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
			FilterSecurityInterceptor security = applicationContext.getBean(FilterSecurityInterceptor.class);
			DefaultFilterInvocationSecurityMetadataSource source = (DefaultFilterInvocationSecurityMetadataSource) security
					.getSecurityMetadataSource();
			Map<RequestMatcher, ArrayList<SecurityConfig>> requestMap = null;
			Exception ex = null;
			try {
				Field f = source.getClass().getDeclaredField("requestMap");
				f.setAccessible(true);
				requestMap = (Map<RequestMatcher, ArrayList<SecurityConfig>>) f.get(source);
			} catch (Exception e) {
				ex = e;
			}
			Assert.isTrue(ex == null, ex == null ? "" : ex.getMessage());
			Assert.isTrue(requestMap != null, "requestMap should not be null.");
			Map<String, Set<String>> pageAccessMap = new HashMap<String, Set<String>>();
			for (Map.Entry<RequestMatcher, ArrayList<SecurityConfig>> entry : requestMap.entrySet()) {
				AntPathRequestMatcher requestMatcher = (AntPathRequestMatcher) entry.getKey();
				String pattern = requestMatcher.getPattern();
				if (pattern.endsWith("**")) {
					pattern = pattern.substring(0, pattern.lastIndexOf('/'));
				}
				Set<String> roleSet = new HashSet<String>();
				List<SecurityConfig> securityConfigList = entry.getValue();
				for (SecurityConfig securityConfig : securityConfigList) {
					roleSet.add(securityConfig.getAttribute());
				}
				pageAccessMap.put(pattern, roleSet);
			}
			if (logger.isDebugEnabled()) {
				for (Map.Entry<String, Set<String>> entry : pageAccessMap.entrySet()) {
					logger.debug(">>> Request url pattern: " + entry.getKey() + ", authorities needed: " + entry.getValue());
				}
			}
			Set<String> allSecuredUrls = new HashSet<String>();
			allSecuredUrls.addAll(pageAccessMap.keySet());
			/**
			 * [END]get role and accessible page mappings 
			 */

			MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
			if (logger.isDebugEnabled()) {
				logger.debug(">>> User Authories: " + userDetails.getAuthorities());
			}
			Collection<GrantedAuthority> allAuthorities = userDetails.getAuthorities();
			Set<String> accessiblePages = new HashSet<String>();
			for (GrantedAuthority authority : allAuthorities) {
				for (Map.Entry<String, Set<String>> entry : pageAccessMap.entrySet()) {
					logger.debug("Checking user's permission >> USER [" + userDetails.getUsername() + "] HAS ROLE ["
							+ authority.getAuthority() + "].");
					if (entry.getValue().contains(authority.getAuthority())) {
						accessiblePages.add(entry.getKey());
						logger.debug("USER [" + userDetails.getUsername() + "] HAS ACCESS TO PAGE [" + entry.getKey()
								+ "].");
					}
				}
			}
			ObjectMapper mapper = new ObjectMapper();
			Set<String> unaccessiblePages = new HashSet<String>();
			unaccessiblePages.addAll(allSecuredUrls);
			unaccessiblePages.removeAll(accessiblePages);
			unaccessiblePages.add("/cart/orders");
            httpSession.setAttribute("unaccessiblePagesJson", mapper.writeValueAsString(unaccessiblePages));
            httpSession.setAttribute("unaccessiblePages", unaccessiblePages);
		}

		chain.doFilter(request, response);

	}

/*	private Set<String> findUnaccessibleCategoryId() {
		Set<String> unaccessiblePages = new HashSet<String>();
	}*/
	
	/**
	 * 
	 * isRefreshingCategoryRequest
	 * @param request request
	 * @param response response
	 * @return boolean boolean
	 */
	private boolean isRefreshingCategoryRequest(HttpServletRequest request, HttpServletResponse response) {
		String refreshCredential = "8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92";
		String requestCredential = request.getHeader("category-refresh-credential");
		if (refreshCredential.equals(requestCredential) && request.getMethod().equalsIgnoreCase("GET")) {
			ServletContext servletContext = request.getSession().getServletContext();
			ApplicationContext applicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
			CategoryTreeService categoryTreeService = applicationContext.getBean("categoryTreeService",
					CategoryTreeService.class);
			categoryTreeService.loadCategoryTreeToServletContext(servletContext);
			
			MenardSecurityService menardSecurityService = applicationContext.getBean("menardSecurityService",
					MenardSecurityService.class);
			menardSecurityService.loadSecurityConfig();
			
			try {
				response.getWriter().write("OK");
			} catch (IOException e) {
				logger.error(e.getMessage());
			}
			logger.info("GET /rest/category/refresh REQUEST HANDLED ==> CategoryTree in ServletContext is refreshed.");
		}
		return false;

	}

	/**
	 *
	 * Query the requesting URL against the map of the CategoryTreeNode ID and CategoryTreeNode 
	 * which is populated by the CategoryPreloader
	 * @param requestingUrl the requesing URL
	 * @param categoryTreeDictionary map of the CategoryTreeNode ID and CategoryTreeNode 
	 * which is populated by the CategoryPreloader
	 * @return Long Long
	 */
	private Long lookupCategoryUrlWithRequestingUrl(String requestingUrl,
			Map<Long, CategoryTreeNode> categoryTreeDictionary) {
		String reqUrl = requestingUrl;
		if (reqUrl.indexOf("/login") > 0) {
			reqUrl = "/";
		}
		Long categoryId = null;
		for (CategoryTreeNode treeNode : categoryTreeDictionary.values()) {
			if (treeNode.getUrl().equalsIgnoreCase(reqUrl)) {
				categoryId = treeNode.getCategoryId();
				break;
			}
		}
		return categoryId;
	}

	@Override
	public void destroy() {
	}

}
