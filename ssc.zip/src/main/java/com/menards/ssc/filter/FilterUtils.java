package com.menards.ssc.filter;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>FilterUtils</p>
 * <p>Utility class that manipulate filter related stuff such as HttpServletRequest</p>
 * @author frank.peng
 * @version 1.0
 */
public final class FilterUtils {
	/**
	 *
	 * Get the canonical URL by removing the context path and query string. 
	 * @param request request
	 * @return requestURL
	 */
	public static String getCanonicalRequestUrl(HttpServletRequest request) {
		String contextPath = request.getContextPath();
		String url = request.getRequestURI() + "?";
		return url.substring(contextPath.length(), url.indexOf('?'));
	}

	/**
	 *Constructor
	 */
	private FilterUtils() {
	}
}
