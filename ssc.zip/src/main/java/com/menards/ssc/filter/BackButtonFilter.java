/*
 * BackButtonFilter
 * 
 * 2014-04-23
 *
 * Copyright (c) 2014
 * Menard Inc.
 */
package com.menards.ssc.filter;

import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>This filter saves every coming request in a Deque for lateral use as a history for back button.</p>
 * <ul>
 * <li>Maximum size is 20.</li>
 * <li>Static resources are excluded, e.g. css, js, images, fonts.</li>
 * <li>Ajax requests are excluded.</li>
 * <li>Counting request of pagination are excluded.</li>
 * </ul>
 * <p>Please add it in init() method if you have other path to exclude.</p>
 *
 * @author james.ni
 */
public class BackButtonFilter implements Filter {
    private final Log logger = LogFactory.getLog(BackButtonFilter.class);

    private static final int REQUEST_HISTORY_SIZE = 20;
    private static final String BACK_BUTTON_URL = "/back";
    private static final String HOME = "/";
    private Deque<String> requestHistory;
    private Pattern excludePathsPattern;
    private List<String> excludePaths = new ArrayList<>();
    private Pattern staticResourceUrls = Pattern.compile("^.*(css|js|images|png|gif|\\/img\\/|\\/fonts\\/).*$", Pattern.CASE_INSENSITIVE);

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
            throws IOException, ServletException {
        HttpServletRequest servletRequest = (HttpServletRequest) request;
        String servletPath = servletRequest.getServletPath();
        String fullUrl = getFullURL(servletRequest);
        MenardUserDetails user = null;
        try {
            if (!isBackUrl(fullUrl) && !isStaticUrl(servletRequest) && !excludePathsPattern.matcher(fullUrl).matches()) {
                user = MenardSecurityContextHolder.getMenardUserDetails();
                if (user != null) {
                    requestHistory = user.getRequestHistory();
                    if (requestHistory == null) {
                        logger.info("Initializing request history Deque, size " + REQUEST_HISTORY_SIZE);
                        user.setRequestHistory(new ArrayDeque<String>(REQUEST_HISTORY_SIZE));
                        requestHistory = user.getRequestHistory();
                    }
                    logger.info("Pushing request to user request history, current size " + requestHistory.size());
                    String last = requestHistory.peek();
                    String historyUrl = extractHistoryUrl(fullUrl, servletPath);
                    if (StringUtils.isNotBlank(last) && !historyUrl.equalsIgnoreCase(getHistoryUrl(last))) {
                        if (requestHistory.size() == REQUEST_HISTORY_SIZE) {
                            requestHistory.removeLast();
                        }
                    }
                    String method = servletRequest.getMethod();
                    String history = createHistory(method, historyUrl);
                    requestHistory.push(history);
                    logger.info("Pushing request to user request history, new size " + requestHistory.size());
                }
            }
        } catch (Exception unexpectedException) {
            // Catch unexpected NPE, log related info for log analysis
            logger.error("============ START BackButtonFilter Unexpected Exception START ============");
            logger.error("User: " + user);
            logger.error("RequestHistory: " + requestHistory);
            logger.error("URL: " + fullUrl);
            logger.error("Method: " + servletRequest.getMethod());
            logger.error("============ END BackButtonFilter Unexpected Exception END ============");
            unexpectedException.printStackTrace();
        }

        filterChain.doFilter(request, response);
    }

    /**
     * Subtract the protocol and domain from the url
     *
     * @param url         full http request URL. e.g. http://ssc.menards.com/search?type=sign&yardNumber=&query=937
     * @param servletPath /search as in above example url
     * @return servlet path and the parameters e.g. /search?type=sign&yardNumber=&query=937
     */
    private String extractHistoryUrl(String url, String servletPath) {
        String historyUrl = "";
        if (HOME.equals(servletPath)) {
            // return servlet path if it's home page, otherwise "/" will fool the logic in the following "else" block
            historyUrl = servletPath;
        } else {
            int servletPathPosition = url.indexOf(servletPath);
            if (servletPathPosition >= 0) {
                historyUrl = url.substring(servletPathPosition);
            }
        }
        return historyUrl;
    }

    /**
     * Initialize filter.
     * add urls to exclude
     *
     * @param filterConfig
     * @throws ServletException
     */
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        excludePaths.add("\\/orderitem\\/count"); // counting request of pagination
        excludePaths.add("\\/cart\\/placedpage"); // order thank you page
        excludePaths.add("\\/cart\\/information"); // save quote form page
        excludePaths.add("\\/cart\\/options"); // place order options page
        excludePaths.add("\\/add.*Ajax"); // add item/sign to cart on product list page
        excludePaths.add("\\/error"); // error page (exception or timeout)
        excludePaths.add("\\/print");
        excludePaths.add("rest/category"); // category refresh
        excludePathsPattern = Pattern.compile(getExcludeUrlPattern(excludePaths), Pattern.CASE_INSENSITIVE);
    }

    @Override
    public void destroy() {
    }

    /**
     * check if back button is clicked
     *
     * @param url
     * @return
     */
    public boolean isBackUrl(String url) {
        return StringUtils.endsWith(url, BACK_BUTTON_URL);
    }

    /**
     * check if request resource is static
     *
     * @param request
     * @return
     */
    private boolean isStaticUrl(HttpServletRequest request) {
        String url = request.getRequestURI().toString();
        Matcher m = staticResourceUrls.matcher(url);

        return m.matches();
    }

    /**
     * construct a regex pattern to exclude URLs
     * e.g. ajax post request or json get request
     *
     * @param excludePaths
     * @return
     */
    private String getExcludeUrlPattern(List<String> excludePaths) {
        String urls = StringUtils.join(excludePaths, "|");
        return "^.*(" + urls + ").*$";
    }

    /**
     * construct history url
     * e.g. "GET|/cart"
     * "POST|/cart/options"
     *
     * @param method
     * @param url
     * @return
     */
    private String createHistory(String method, String url) {
        return method + "|" + url;
    }

    /**
     * Get url from history string
     * e.g. "GET|/cart"
     * "POST|/cart/options"
     *
     * @param history
     * @return
     */
    private String getHistoryUrl(String history) {
        String[] tokens = history.split("\\|");
        if (tokens != null && tokens.length == 2) {
            return tokens[1];
        }
        return null;
    }

    /**
     * Generate full URL from request, including protocol, domain, servlet path, parameters, etc.
     * e.g. http://ssc.menards.com/search?type=sign&yardNumber=&query=937
     *
     * @param request
     * @return
     */
    private String getFullURL(HttpServletRequest request) {
        StringBuffer requestURL = request.getRequestURL();
        String queryString = request.getQueryString();

        if (queryString == null || queryString.length() == 0) {
            return requestURL.toString();
        } else {
            return requestURL.append('?').append(queryString).toString();
        }
    }
}