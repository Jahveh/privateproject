
package com.menards.ssc.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * <p>ExceptionHandlerFilter</p>
 * <p>
 * Catch all the exceptions that can not been handler by spring handler
 * Such as the before it
 *
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class ExceptionHandlerFilter implements Filter {
	
	public static final Logger LOG = Logger.getLogger(ExceptionHandlerFilter.class);
   
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
            throws IOException, ServletException { 
        try {
        	 filterChain.doFilter(request, response);
		} catch (Exception e) {
			LOG.error(e.getMessage());
			HttpServletResponse httpServletResponse = (HttpServletResponse) response;
			String contextPath= ((HttpServletRequest)request).getContextPath();
			httpServletResponse.sendRedirect(contextPath+"/error");
		}
    }

	@Override
	public void destroy() {	
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	
	}
}