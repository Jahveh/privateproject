package com.menards.ssc.filter;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.AnnotationIntrospector;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.xc.JaxbAnnotationIntrospector;

import com.menards.ssc.domain.breadcrumb.BreadCrumbConfig;
import com.menards.ssc.listener.breadcrumb.BreadCrumbConfigPreLoader;

/**
 * 
 * <p>BreadCrumbFilter</p>
 * <p>A servlet filter that maps the category id based on the request url and set it in HttpRequest.</p>
 * <p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class BreadCrumbFilter implements Filter {

	private static final Log LOGGER = LogFactory.getLog(BreadCrumbFilter.class);

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
			ServletException {
		HttpServletRequest servletRequest = (HttpServletRequest) request;
		String requestingUrl = FilterUtils.getCanonicalRequestUrl(servletRequest);
		@SuppressWarnings("unchecked")
		Map<String, List<BreadCrumbConfig>> breadCrumbConfigMap = (Map<String, List<BreadCrumbConfig>>) servletRequest
				.getSession().getServletContext()
				.getAttribute(BreadCrumbConfigPreLoader.BREAD_CRUMB_CONFIG_MAP_SERVLET_CONTEXT_KEY);
		List<BreadCrumbConfig> configs = breadCrumbConfigMap.get(requestingUrl);
		String configJson = converToJson(configs);
		servletRequest.setAttribute("breadCrumbJson", configJson);
		chain.doFilter(request, response);
	}

	/**
	 * 
	 * convert configuration to jsonf format
	 * @param configs configurations
	 * @return json
	 */
	private String converToJson(List<BreadCrumbConfig> configs) {
		String json = "[]";
		ObjectMapper mapper = new ObjectMapper();
		AnnotationIntrospector introspector = new JaxbAnnotationIntrospector();
		mapper.setAnnotationIntrospector(introspector);
		try {
			json = mapper.writeValueAsString(configs);
		} catch (JsonGenerationException e) {
			LOGGER.error(e.getStackTrace());
		} catch (JsonMappingException e) {
			LOGGER.error(e.getStackTrace());
		} catch (IOException e) {
			LOGGER.error(e.getStackTrace());
		}
		return json;
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void destroy() {
	}

}
