package com.menards.ssc.constants;

/**
 * <p>CommonConstant</p>
 * <p> provide some common constants in order to make it flexible and convenient.</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public interface CommonConstant {

	/**
	 *  Represent a comma
	 */
	public static final String COMMA = ",";

	/**
	 * Represent a semicolon
	 */
	public static final String SEMICOLON = ";";

	/**
	 * Represent one kind of date format
	 */
	public static final String STATUS_DATE_FORMAT = "yyyy/MM/dd";

	/**
	 * Represent one kind of date format
	 */
	public static final String STATUS_DATE_FORMAT_Y = "MM/dd/yyyy";

	/**
	 *
	 * Query type of approval
	 *
	 */
	public static final String QUERY_TYPE_APPROVE = "approve";

	/**
	 * Query type of order item
	 */
	public static final String QUERYTYPE_HISTORY = "history";

	/**
	 * Represent one type of sort of asc
	 */
	public static final String SORT_ASC = "ASC";

	/**
	 * Represent one type of sort of asc
	 */
	public static final String SORT_DESC = "DESC";

	/**
	 * Represent one type of field
	 */
	public static final String MENARDORDER = "menardOrder";

	/**
	 * Represent one type of field
	 */
	public static final String NOTES = "notes";

	/**
	 * Represent PLUS
	 */
	public static final String PLUS = "+";

	/**
	 * Represent ASTERISKd
	 */
	public static final String ASTERISK = "*";

	/**
	 * Represent double quotation marks
	 */
	public static final String DOUBLE_QUOTATION_MARKS = "\"";

	/**
	 * Represent minus
	 */
	public static final String MINUS = "-";

	/**
	 * Represent SPACE
	 */
	public static final String SPACE = " ";

	/**
	 * Represent separator
	 */
	public static final String SEPARATOR = "|";

	/**
	 * Represent backslash
	 */
	public static final String BACKSLASH = "/";

	/**
	 * Represent single quote mark
	 */
	public static final String SINGLE_QUOTE_MARK = "'";

	/**
	 * Represent percent sign
	 */
	public static final String PERCENT_SIGN = "%";

	public static final String SOS_CATALOG = "SOS";

	/**
	 * Represent true
	 */
	public static final String TRUE_STRING = "Y";

	/**
	 * Represent false
	 */
	public static final String FALSE_STRING = "N";

	/**
	 * GO_STORE_NUMBER 0
	 */
	public static final String GO_STORE_NUMBER = "0";

	public static final String UNCHECKED = "unchecked";

	public static final Character ARCHIVED_Y = 'Y';

	public static final String DEFAULT_SKU_CODE = "9000001";

	public static final String ROLE_PREFIX = "ROLE_";

	public static final String DEFAULT_USER_ROLE = "ROLE_SSC";
	public static final String GO_USER_ROLE = "ROLE_X";

	public static final long DEFAULT_SKU_ID_SIGN = 9001L;
	public static final long DEFAULT_PRODUCT_ID_SIGN = 9001L;
	public static final String DEFAULT_OPENSKU_SIGN = "1000000";

	public static final String SIGN_TYPE_SIGN = "sign";
	
	public static final String SIGN_TYPE_COLOR_SIGN = "colorsign";
	
	public static final String ENVIRONMENT = "environment";

	public static final int CART_ITEM_NUMBER_MAX_LIMIT = 250;
}
