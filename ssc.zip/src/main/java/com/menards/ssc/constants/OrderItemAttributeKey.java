package com.menards.ssc.constants;

/**
 * 
 * <p>
 * OrderItemAttributeKey
 * </p>
 * <p>
 * OrderItemAttributeKey
 * </p>
 * <p>
 * Define keys for order item attributes
 * </p>
 * <p>
 * Copyright (c) 2013
 * </p>
 * <p>
 * Menard Inc.
 * </p>
 * 
 * @author bill01.zhang
 * @version 1.0
 */
public interface OrderItemAttributeKey extends AttributeKey {
	
	/**
	 * Represent the promotion number of sale sign
	 */
	public static final String SALE_SIGN_PRO_NBR = "promotionNbr";
	
	/**
	 * Represent the name of sign, color sign or sale sign
	 * 
	 */
	public static final String SIGN_NAME_ATTRIBUTE_NAME = "sign_name";	
	
}