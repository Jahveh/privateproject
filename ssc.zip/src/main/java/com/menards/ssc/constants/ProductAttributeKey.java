package com.menards.ssc.constants;

/**
 *
 * <p>ProductAttributeKeys</p>
 * <p>Product Attribute Keys</p>
 * <p>Define keys for product attributes</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author bill01.zhang
 * @version 1.0
 */
public interface ProductAttributeKey extends AttributeKey {

	/**
	 * Brand_Name
	 */
	String BRAND_NAME = "Brand_Name";

	/**
	 * Product_Name
	 */
	String PRODUCT_NAME = "Product_Name";

	/**
	 * Description_Long
	 */
	String DESCRIPTION_LONG = "Description_Long";

	/**
	 * Description_Short
	 */
	String DESCRIPTION_SHORT = "Description_Short";

	/**
	 * vendor email address
	 */
	String VENDOR_EMAIL = "SOS_Email_Fulfiller_Addrs";

	/**
	 * Bullet_1
	 */
	String BULLET_1 = "Bullet_1";

	/**
	 * Bullet_2
	 */
	String BULLET_2 = "Bullet_2";

	/**
	 * Bullet_3
	 */
	String BULLET_3 = "Bullet_3";

	/**
	 * Bullet_4
	 */
	String BULLET_4 = "Bullet_4";

	/**
	 * Bullet_5
	 */
	String BULLET_5 = "Bullet_5";

	/**
	 * Bullet_6
	 */
	String BULLET_6 = "Bullet_6";

	/**
	 * Bullet_7
	 */
	String BULLET_7 = "Bullet_7";

	/**
	 * Bullet_8
	 */
	String BULLET_8 = "Bullet_8";

	/**
	 * Bullet_9
	 */
	String BULLET_9 = "Bullet_9";

	/**
	 * Bullet_10
	 */
	String BULLET_10 = "Bullet_10";

	/**
	 * Bullet_11
	 */
	String BULLET_11 = "Bullet_11";

	/**
	 * Collection
	 */
	String COLLECTION = "Collection";

	/**
	 * Criteria_1
	 */
	String CRITERIA_1 = "Criteria_1";

	/**
	 * Criteria_2
	 */
	String CRITERIA_2 = "Criteria_2";

	/**
	 * Criteria_3
	 */
	String CRITERIA_3 = "Criteria_3";

	/**
	 * Criteria_4
	 */
	String CRITERIA_4 = "Criteria_4";

	/**
	 * Criteria_5
	 */
	String CRITERIA_5 = "Criteria_5";

	/**
	 * Criteria_6
	 */
	String CRITERIA_6 = "Criteria_6";

	/**
	 * UOM
	 */
	String UOM = "Unit_Of_Measurement";

	/**
	 * Vendor
	 */
	String VENDOR = "Vendor";

	/**
	 * Vendor Name
	 */
	String VENDOR_NAME = "Vendor_Name";

	/**
	 * Vendor_Logo
	 */
	String VENDOR_LOGO = "Vendor_Logo";

	/**
	 * Vendor_Size
	 */
	String VENDOR_SIZE = "Vendor_Size";

	/**
	 * Depth
	 */
	String DEPTH = "Depth";

	/**
	 * Height
	 */
	String HEIGHT = "Height";

	/**
	 * Length
	 */
	String LENGTH = "Length";

	/**
	 * Width
	 */
	String WIDTH = "Width";

	/**
	 * Image_Alternate
	 */
	String IMAGE_ALTERNATE = "Image_Alternate";

	/**
	 * Image_large
	 */
	String IMAGE_LARGE = "Image_Large";

	/**
	 * Image_medium
	 */
	String IMAGE_MEDIUM = "Image_Medium";

	/**
	 * Image_small
	 */
	String IMAGE_SMALL = "Image_Small";

	/**
	 * Pkg_Height
	 */
	String PKG_HEIGHT = "Pkg_Height";

	/**
	 * Pkg_Length
	 */
	String PKG_LENGTH = "Pkg_Length";

	/**
	 * Pkg_Weight
	 */
	String PKG_WEIGHT = "Pkg_Weight";

	/**
	 * Pkg_Width
	 */
	String PKG_WIDTH = "Pkg_Width";

	/**
	 * Price
	 */
	String PRICE = "Price";

	/**
	 * Prod_Tech_Spec
	 */
	String PROD_TECH_SPEC = "Prod_Tech_Spec";

	/**
	 * Install_Instruct
	 */
	String INSTALL_INSTRUCT = "Install_Instruct";

	/**
	 * Request_Type
	 */
	String REQUEST_TYPE = "Request_Type_Cd";
	
	/**
	 * Move this key here because no such property on sku.
	 */
	String FULFILLER_TYPE = "Fulfiller_Type_Cd";

	/**
	 * Square_Footage
	 */
	String SQUARE_FOOTAGE = "Square_Footage";

	/**
	 * Carton_Price_Multiplier
	 */
	String CARTON_PRICE_MULTIPLIRE = "Carton_Price_Multiplier";

	/**
	 * Energy_Star
	 */
	String ENERGY_STAR = "Energy_Star";

	/**
	 * Handicap_Logo
	 */
	String HANDICAP_LOGO = "Handicap_Logo";

	/**
	 * DCM
	 */
	String DCM = "Flag_DCM_Order";

	/**
	 * Size
	 */
	String SIZE = "Size";

	/**
	 * is welcome sign
	 */
	String IS_WELCOME_SIGN = "Flag_Is_Welcome_Sign";

	/**
	 * is business card
	 */
	String IS_BUSINESS_CARD = "Flag_Is_Business_Card";

	/**
	 * FLAG LOCK QUANTITY FOR CART PAGE
	 */
	String FLAG_LOCK_QUANTITY = "Flag_Lock_Quantity";

}