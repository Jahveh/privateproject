package com.menards.ssc.constants;

/**
 * <p>CategoryAttributeKey</p>
 * <p>Category Attribute Key</p>
 * <p>
 * Category Attribute Key
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public interface CategoryAttributeKey extends AttributeKey {

	/**
	 * product detail page
	 * select a variation
	 */
	String USE_COLOR_DROPDOWN = "Use_Color_Dropdown";

	/**
	 * Flag_No_Search_Crit
	 * This attribute is used as a switch for product filter page for the category.
	 * 'Y' -> No product filter page
	 * 'N' -> product filter page available
	 */
	String FLAG_NO_SEARCH_CRIT = "Flag_No_Search_Crit";

	/**
	 * Available product filters for the category
	 * e.g. Style,Size,Vendor
	 */
	String FOLDER_NAV_USED_LIST = "Folder_Nav_Used_List";

	String ATTR_FULFILLER = "Restrict_Asst_To_Fulfiller";
	
	String ATTR_RESTRICT_ASST_TO_DEPT = "Restrict_Asst_To_Dept";
	
	String ATTR_DISPLAY_PRIORITY ="Display_Priority";

}
