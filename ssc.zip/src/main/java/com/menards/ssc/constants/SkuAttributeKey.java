package com.menards.ssc.constants;

/**
 * <p>SkuAttributeKey</p>
 * <p>Sku Attribute Key</p>
 * <p>
 * Sku Attribute Key
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public interface SkuAttributeKey extends AttributeKey {

	/**
	 * UPC
	 */
	String UPC = "UPC";

	/**
	 * Color
	 */
	String COLOR = "Color";

	/**
	 * Swatch img
	 */
	String SWATCH = "Swatch";

	/**
	 * Finish_Family
	 */
	String FINISH_FAMILY = "Finish_Family";

	/**
	 * Color_Image
	 */
	String COLOR_IMAGE = "Color_Image";

	/**
	 * Image_Medium
	 */
	String IMAGE_MEDIUM = "Image_Medium";

	/**
	 * Orderable
	 */
	String ORDERABLE = "Orderable";

	/**
	 * Lead_Time_Days
	 */
	String LEAD_TIME_DAYS = "Lead_Time_Days";

	/**
	 * Shipping
	 */
	String SHIPPING = "Shipping";

	/**
	 * Shipping_Method
	 */
	String SHIPPING_METHOD = "Shipping_Method";

	/**
	 * Max_Quantity
	 */
	String MAX_QUANTITY = "Max_Quantity";

	/**
	 * Price
	 */
	String PRICE = "Price";

	/**
	 * Menards_SKU
	 */
	/*
	 * String MENARDS_SKU = "Menards_SKU";
	 */

	/**
	 * Flag_Hide_Product_Price
	 */
	String FLAG_HIDE_PRODUCT_PRICE = "Flag_Hide_Product_Price";

	/**
	 * Fulfiller_Type
	 */
	//String FULFILLER_TYPE = "Fulfiller_Type_Cd";

	/**
	 * min quantity
	 */
	String MIN_QTY = "Minimum_Qty";

	/**
	 * increment quantity
	 */
	String INCREMENT_QTY = "Increment_Qty";

	/**
	 * max quantity
	 */
	String MAX_QTY = "Maximum_Quantity";
}
