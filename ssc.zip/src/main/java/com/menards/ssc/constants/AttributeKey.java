package com.menards.ssc.constants;

/**
 * <p>AttributeKey</p>
 * <p>adapter between CommonConstant and product/sku/category attribute keys</p>
 * <p>
 * adapter between CommonConstant and product/sku/category attribute keys
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public interface AttributeKey extends CommonConstant {

}
