/**
 * 
 */
package com.menards.ssc.jms;

import javax.annotation.Resource;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

/**
 * <p>JmsQueueSender</p>
 * <p>Send message to destination queue</p>
 * <p>
 *  Sending message to queue using spring jms template
 * 
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Component("jmsQueueSender")
public class JmsQueueSender {

	public static final Logger LOG = Logger.getLogger(JmsQueueSender.class);

	@Resource(name = "jmsTemplate")
	private JmsTemplate jmsTemplate;

	/**
	 * Sending message
	 * @param message String
	 * @return boolean
	 */
	public boolean send(final String message) {
		try {
			this.jmsTemplate.send(new MessageCreator() {
				public Message createMessage(Session session) throws JMSException {
					TextMessage textMessage = session.createTextMessage(message);
					textMessage.setStringProperty("OriginUnit", "1001");
					textMessage.setStringProperty("OriginDept", "IMS");
					textMessage.setStringProperty("OriginSystem", "StoreSuppliesCatalog");
					textMessage.setStringProperty("MessageType", "ClothingOrder");
					return textMessage;
				}
			});
			return true;
		} catch (Exception e) {
			LOG.error(e.getMessage());
			return false;
		}
	}
}
