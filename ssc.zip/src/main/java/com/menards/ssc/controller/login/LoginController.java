package com.menards.ssc.controller.login;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.menards.mymenards.security.HttpAuthentication;
import com.menards.ssc.security.MenardSecurityDelegate;

/**
*
* <p>LoginController</p>
* <p>An Login Controller that provides methods for login processing</p>
* <p>Copyright (c) 2014</p>
* <p>Menard Inc.</p>
* @author frank.shao
* @version 1.0
*/
@Controller(value = "loginController")
@RequestMapping("")
public class LoginController {

	public static final Log LOG = LogFactory.getLog(LoginController.class);
	public static final int INDEX = 3;
	
	@Resource(name="menardSecurityDelegate")
	private MenardSecurityDelegate securityDelegate;

	@Resource
	private UsernamePasswordAuthenticationFilter filter;

	/**
	 * 
	 * login using spring security
	 * @param request request
	 * @return String
	 */
	@RequestMapping("/login")
	public String login(HttpServletRequest request, HttpServletResponse response) {
		filter.setPostOnly(false);
		String userName = this.getUserNameFromContext(request);	
		if (StringUtils.isBlank(userName)) {
			return "redirect:/fail";
		}
		return "redirect:/loginCheck?j_username=" + userName + "&j_password=A";
	}
	
	/**
	 * 
	 * fail to login using user name and password
	 * @param request request
	 * @return String
	 */
	@RequestMapping("/fail")
	public String fail(Model model, HttpServletResponse response) {	
		response.setStatus(HttpServletResponse.SC_FORBIDDEN);
		model.addAttribute("fail", true);
		return "exception/error";
	}

	/**
	 * 
	 * Time out 
	 * @param model Model
	 * @return String
	 */
	@RequestMapping("/timeout")
	public String timeout(Model model) {
		model.addAttribute("timeout", true);
		return "exception/error";
	}

	/**
	 * Determines the user name from the "UN:" registry value,	 
	 * @param request request 
	 * @return String
	 */
	private String getUserNameFromContext(HttpServletRequest request) {
		HttpAuthentication httpAuth = HttpAuthentication.getInstance();
		String userName= httpAuth.getUserName(request);
		LOG.debug("The message from httpAuth.getUserName(request)[" + userName + "]");
		return userName;
	}	
}