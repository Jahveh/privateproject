package com.menards.ssc.controller.search;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.broadleafcommerce.core.web.controller.catalog.BroadleafSearchController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestMapping;

import com.menards.ssc.domain.catalog.SearchCriteria;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.catalog.SkuDTO;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.enums.MenardSearchType;
import com.menards.ssc.service.catalog.MenardSearchService;

/**
 * <p>SearchController</p>
 * <p>Deal with all the request related to search</p>
 * <p>
 * 
 * Process all the requests related to search. User can 
 * search for sku, sign or sale sign according to selected
 * option. 
 * 
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Controller(value = "searchController")
@RequestMapping("/search")
public class SearchController extends BroadleafSearchController {

	private static final String SEARCH_VIEW = "catalog/searchResultPage";
	private static final String SEARCH_RESULT = "searchResult";
	private static final String PRODUCT_DETAIL = "redirect:/product/{id}?type={t}&yardNumber={y}&query={q}";

	@Resource(name = "menardSearchService")
	private MenardSearchService searchService;

	/**
	 * Search for product according to the selected option
	 * @param model model
	 * @param criteria SearchCriteria
	 * @param result BindingResult
	 * @return String
	 */
	@RequestMapping("")
	public String search(Model model, @Valid SearchCriteria criteria, BindingResult result) {
		model.addAttribute("searchTypes", MenardSearchType.values());
		model.addAttribute(SEARCH_RESULT, new SearchResult<SkuDTO>());
		model.addAttribute("criteria", criteria);
		if (criteria == null || StringUtils.isBlank(criteria.getQuery())) {
			return SEARCH_VIEW;
		}
		if (result.hasErrors()) {
			processErrorMessage(result, criteria.getType(), criteria.getQuery());
			return SEARCH_VIEW;
		}

		/* Search for sign; */
		if (MenardSearchType.SIGN.getKey().equals(criteria.getType())) {
			SearchResult<Sign> signResult = searchService.findSignPage(criteria);
			model.addAttribute(SEARCH_RESULT, signResult);
			setPrintWhite(model, signResult);
			if (CollectionUtils.isEmpty(signResult.getResult())) {
				return "catalog/NoSign";
			}
			return SEARCH_VIEW;
		}

		/* Search for sale sign; */
		if (MenardSearchType.SALE_SIGN.getKey().equals(criteria.getType())) {
			SearchResult<Sign> signResult = searchService.findSaleSignPage(criteria);
			model.addAttribute(SEARCH_RESULT, signResult);
			setPrintWhite(model, signResult);
			if (CollectionUtils.isEmpty(signResult.getResult())) {
				return "catalog/NoSaleSign";
			}
			return SEARCH_VIEW;
		}

		/* Search for supplies; */
		if (MenardSearchType.SUPPLIES.getKey().equals(criteria.getType())) {
			SearchResult<SkuDTO> skuResult = searchService.findSkuPage(criteria);
			model.addAttribute(SEARCH_RESULT, skuResult);
			return getSearchResultURL(skuResult, criteria);
		}
		return SEARCH_VIEW;
	}

	/**
	 * 
	 * @param model Model
	 * @param result SearchResult<Sign>
	 */
	private void setPrintWhite(Model model, SearchResult<Sign> result) {
		if (CollectionUtils.isEmpty(result.getResult())) {
			model.addAttribute("printWhite", false);
			return;
		}
		model.addAttribute("printWhite", result.getResult().get(0).isPrintWhite());
	}

	private static final String MAXLENGTH_MESSAGE_KEY = "Max.criteria.query";
	private static final String QUERY_FIELD = "query";

	/**
	 * Since the maximum length of query string is different among different search type
	 * 
	 * @param result BindingResult
	 * @param type String
	 * @param query String
	 */
	private void processErrorMessage(BindingResult result, String type, String query) {
		if (!result.hasFieldErrors(QUERY_FIELD)) {
			return;
		}
		FieldError queryError = result.getFieldError(QUERY_FIELD);
		Object[] arguments = queryError.getArguments();
		String[] codes = queryError.getCodes();

		if ((MenardSearchType.SUPPLIES.getKey().equalsIgnoreCase(type) || MenardSearchType.SIGN.getKey()
				.equalsIgnoreCase(type)) && StringUtils.length(StringUtils.trimToEmpty(query)) > 40) {
			codes[0] = MAXLENGTH_MESSAGE_KEY;
			arguments[1] = "40";
			arguments[2] = MenardSearchType.SUPPLIES.getDescription() + " and "
					+ MenardSearchType.SIGN.getDescription();
		}

		if (MenardSearchType.SALE_SIGN.getKey().equalsIgnoreCase(type)
				&& StringUtils.length(StringUtils.trimToEmpty(query)) > 8) {
			codes[0] = MAXLENGTH_MESSAGE_KEY;
			arguments[1] = "8";
			arguments[2] = MenardSearchType.SALE_SIGN.getDescription();
		}
	}

	private static final String[] PLACE_HOLDERS = new String[] { "{id}", "{t}", "{y}", "{q}" };

	/**
	 * Retrieve the final url according to the result of search
	 * @param result SearchResult<T>
	 * @param criteria SearchCriteria
	 * @param <T> T
	 * @return String
	 */
	private <T> String getSearchResultURL(SearchResult<T> result, SearchCriteria criteria) {
		if (result.getResult().size() != 1) {
			return SEARCH_VIEW;
		}
		Object obj = result.getResult().get(0);
		if (obj instanceof SkuDTO) {
			Long productId = ((SkuDTO) obj).getProductId();
			String[] array = criteria.getQueryArray();
			array[0] = productId.toString();
			return StringUtils.replaceEach(PRODUCT_DETAIL, PLACE_HOLDERS, array);
		}
		return PRODUCT_DETAIL;
	}

	/**
	 * Search for product according to the selected option
	 * @param model model
	 * @param criteria SearchCriteria	
	 * @return String
	 */
	@RequestMapping("/skuclass")
	public String searchSkuClass(Model model, SearchCriteria criteria) {
		model.addAttribute("criteria", criteria);

		SearchResult<SkuDTO> skuResult = searchService.findProductDescPage(criteria);
		model.addAttribute(SEARCH_RESULT, skuResult);
		criteria.setQuery(StringUtils.EMPTY);
		return "catalog/skuClassPage";
	}
}