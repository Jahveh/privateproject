package com.menards.ssc.controller.cart;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.catalog.domain.ProductAttribute;
import org.broadleafcommerce.core.catalog.domain.Sku;
import org.broadleafcommerce.core.order.domain.DiscreteOrderItem;
import org.broadleafcommerce.core.order.domain.NullOrderImpl;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.domain.OrderItem;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.broadleafcommerce.core.web.controller.cart.BroadleafCartController;
import org.broadleafcommerce.core.web.order.CartState;
import org.broadleafcommerce.profile.web.core.CustomerState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.constants.ProductAttributeKey;
import com.menards.ssc.domain.cart.CartItem;
import com.menards.ssc.domain.cart.QuickCart;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.catalog.ColorSignDTO;
import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.catalog.ProductDetailDTO;
import com.menards.ssc.domain.catalog.SignDTO;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardOrderItemType;
import com.menards.ssc.enums.SignSearchType;
import com.menards.ssc.message.MessageSourceHelper;
import com.menards.ssc.service.catalog.CategoryTreeService;
import com.menards.ssc.service.catalog.MenardCatalogService;
import com.menards.ssc.service.catalog.MenardColorSignService;
import com.menards.ssc.service.catalog.MenardSignService;
import com.menards.ssc.service.order.MenardOrderService;
import com.menards.ssc.util.MenardUtil;

/**
 *
 * <p>QuickCartController</p>
 * <p>An MVC controller that handles quick cart related http request.</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
@Controller
@RequestMapping("/quickCart")
public class QuickCartController extends BroadleafCartController {
    public static final Logger LOG = Logger.getLogger(BroadleafCartController.class);
	@Resource(name = "messageSource")
	private MessageSource messageSource;

	@Resource(name = "blCatalogService")
	private MenardCatalogService catalogService;

	@Resource(name = "menardOrderService")
	private MenardOrderService cartService;

	@Resource(name = "signService")
	private MenardSignService signService;

	@Resource(name = "colorSignService")
	private MenardColorSignService colorSignService;
	
	@Autowired
	private CategoryTreeService categoryTreeService;
	
	@Resource(name = "messageSourceHelper")
	private MessageSourceHelper messageSourceHelper;

	private static final String QUICK_CART_VIEW = "cart/quickcart";
	private static final String REDIRECT_QUICK_CART_VIEW = "redirect:/quickCart/showQuickCart";

	/**
	 *
	 * Prepare the form-backing/command object.
	 * @return QuickCart
	 */
	@ModelAttribute("quickCartForm")
	public QuickCart setupSku() {
		QuickCart quickCart = new QuickCart();
		quickCart.setQuantity(1);
		return quickCart;
	}

	/**
	 *
	 * Handle the addToCart post request. The binding result is firstly checked, if everything is ok, and then
	 * continue with normal handling, if not, the error messages will be sent back to the form page.
	 * @param request an instance of HttpServletRequest
	 * @param quickCartForm the form-backing/command object
	 * @param bindingResult an instance of BindingResult which contains Errors object
	 * @param redirectAttributes an instance of RedirectAttributes, use this object to pass the temporary error message
	 * to be displayed on the form page
	 * @param model an Model object used to save page sub title
	 * @return Quick cart page URL
	 * @throws ItemNotFoundException 
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/addToCart")
	public String addToCart(HttpServletRequest request, @Valid QuickCart quickCartForm, BindingResult bindingResult,
			RedirectAttributes redirectAttributes, Model model) throws ItemNotFoundException {
		
		@SuppressWarnings("unchecked")
		int itemCount = ((List<OrderItem>)request.getSession().getAttribute("cartItems")).size();
		if(itemCount>=CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT){
			throw new RuntimeException( messageSourceHelper.getMessage("cart.add.item.reach.max.limit",new Integer[] { CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT }, ""));
		}
		
		Map<String, Object> validationResult = validateBindingAndSkuExistence(bindingResult, quickCartForm);
		if (validationResult.get("ERROR_MESSAGE") != null) {
			redirectAttributes.addFlashAttribute("validationMesssage", validationResult.get("ERROR_MESSAGE"));
		} else {
			MenardSku menardSku = (MenardSku) validationResult.get("SKU");
			if (!menardSku.isActive() || !((MenardProduct) menardSku.getProduct()).isActive()) {
				redirectAttributes.addFlashAttribute("validationMesssage", "SKU or product has been deleted.");
			} else if (iSDcmSku(menardSku)) {
				redirectAttributes.addFlashAttribute("validationMesssage", messageSource.getMessage(
						"DCM.quickCart.sku", new String[] { quickCartForm.getSku().toString() }, null));

			} else {
				addToCart((Sku) validationResult.get("SKU"), quickCartForm.getQuantity(), request);
			}
		}
		model.addAttribute("pageSubTitle", "Quick Cart");
		return REDIRECT_QUICK_CART_VIEW;
	}

	/**
	 *
	 * Check the binding result and save the error message to a map
	 * @param bindingResult an instance of the BindingResult
	 * @param quickCartForm the form-backing/command object
	 * @return validation result
	 */
	private Map<String, Object> validateBindingAndSkuExistence(BindingResult bindingResult, QuickCart quickCartForm) {
		Map<String, Object> validationResult = new HashMap<String, Object>();
		String errorMessage = null;
		Sku sku = null;
		if (bindingResult.getAllErrors().size() > 0) {
			errorMessage = getBindingErrorMessage(bindingResult);
		} else {
			// sku = catalogService.findSkuById(quickCartForm.getSku());
			sku = catalogService.findSkuByMenardSku(quickCartForm.getSku().toString());
			if (sku == null) {
				errorMessage = messageSource.getMessage("NotFound.quickCart.sku", new String[] { quickCartForm.getSku()
						.toString() }, null);
			}
		}
		validationResult.put("ERROR_MESSAGE", errorMessage);
		validationResult.put("SKU", sku);
		return validationResult;
	}

	/**
	 * 
	 * Check whether the SKU is a DCM sku
	 * @param menardSku 
	 * @return isDCM boolean
	 * @throws ItemNotFoundException ItemNotFound
	 */
	private boolean iSDcmSku(MenardSku menardSku) throws ItemNotFoundException {
		Long skuId = menardSku.getId();
		Long productId = menardSku.getProduct().getId();
		ProductDetailDTO productDTO = catalogService.getMenardProductDetail(productId, skuId);
		return productDTO.getIsDcmSku();
	}

	/**
	 *
	 * Get the error message from the BindingResult instance
	 * @param bindingResult an instance of the BindingResult
	 * @return  Error message
	 */
	private String getBindingErrorMessage(BindingResult bindingResult) {
		StringBuilder validationMessage = new StringBuilder();
		for (ObjectError error : bindingResult.getAllErrors()) {
			validationMessage.append(messageSource.getMessage(error, null)).append("<br/>");
		}
		return validationMessage.toString();
	}

	/**
	 *
	 * Add the given sku to the cart.
	 * @param sku an intance of SKU
	 * @param quantity the quantity of the SKU to be added to the cart
	 * @param request an instance of the HttpServletRequest
	 * @throws ItemNotFoundException 
	 */
	private void addToCart(Sku sku, int quantity, HttpServletRequest request) throws ItemNotFoundException {
		Order cart = CartState.getCart();
		if (cart == null || cart instanceof NullOrderImpl) {
			cart = cartService.createNewCartForCustomer(CustomerState.getCustomer(request));
		}

		SkuCartItem cartItem = getCartItem(sku, quantity);
		cart = cartService.addItem(cart, cartItem);
		CartState.setCart(cart);
		List<OrderItem> orderItems = cart.getOrderItems();
		request.getSession().setAttribute("orderItems", orderItems);
	}

	/**
	 *
	 * Build an instance of the MenardOrderItemRequestDTO
	 * @param sku an intance of the SKU
	 * @param quantity the quantity of the SKU to be added to the cart
	 * @return CartItem
	 */
	private SkuCartItem getCartItem(Sku sku, int quantity) {
		SkuCartItem cartItem = new SkuCartItem();
		cartItem.setSkuId(sku.getId());
		cartItem.setProductId(sku.getProduct().getId());
		cartItem.setQuantity(quantity);
		return cartItem;
	}

	/**
	 *
	 * The request handling method that returns the form page with cart items that already get added.
	 * @param request an instance of the HttpServletRequest
	 * @param model an instance of the Model
	 * @return Quick cart page URL
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/showQuickCart")
	public String showQuickCart(HttpServletRequest request, Model model) {
		categoryTreeService.clearBreadCrumb(request);
		model.addAttribute("pageSubTitle", "Quick Cart");
		Order cart = CartState.getCart();
		List<OrderItem> orderItems = cart.getOrderItems();
		List<CartItem> cartItems = new ArrayList<CartItem>();
		for (OrderItem item : orderItems) {
            try{
                MenardOrderItem menardItem = (MenardOrderItem) item;
                CartItem cartItem = new CartItem();
                cartItem.setOrderItemId(item.getId());
                cartItem.setQuantity(item.getQuantity());
                if (MenardOrderItemType.SIGN.getCode().toString().equals(menardItem.getItemType())) {
                    SignDTO sign = signService.findSign(menardItem.getSignId(),
                            Integer.valueOf(menardItem.getSignYardNum()), SignSearchType.Cart);
                    cartItem.setDescriptionShort(sign.getDescriptionShort());
                    cartItem.setModelNum("");
                } else if (MenardOrderItemType.COLOR_SIGN.getCode().toString().equals(menardItem.getItemType())) {
                    ColorSignDTO colorSign = colorSignService.getSign(menardItem.getSignId().toString(),
                            Integer.valueOf(menardItem.getSignYardNum()), SignSearchType.Cart);
                    cartItem.setDescriptionShort(colorSign.getDescriptionShort());
                    cartItem.setModelNum("");
                } else {

                    MenardSku sku = (MenardSku) ((DiscreteOrderItem) item).getSku();
                    Product product = ((DiscreteOrderItem) item).getProduct();
                    ProductAttribute productAttribute = product.getProductAttributes().get(
                            MenardUtil.getMappingKey(ProductAttributeKey.DESCRIPTION_SHORT));
                    cartItem.setDescriptionShort(productAttribute == null ? "" : productAttribute.getValue());
                    cartItem.setModelNum(sku.getMenardSku() == null ? "" : sku.getMenardSku());
                }
                cartItems.add(cartItem);
            } catch(Exception ex){
                LOG.error("Error found in cart >> ", ex);
            }


		}

        // Sort cart items to show up in the order of entered
        sortCartItems(cartItems);

		request.getSession().setAttribute("cartItems", cartItems);
		return QUICK_CART_VIEW;
	}

    /**
     * Sort cart items by date of saving, aka by the input order
     * @param cartItems
     */
    private void sortCartItems(List<CartItem> cartItems) {
        Collections.sort(cartItems, new Comparator<CartItem>() {
            @Override
            public int compare(CartItem o1, CartItem o2) {
                return Long.compare(o1.getOrderItemId(), o2.getOrderItemId());
            }
        });
    }

    /**
	 *
	 * A default request handling method that handles URL with no mapping specified in this controller.
	 * @return Quick cart page URL
	 */
	@RequestMapping
	public String defaultPage() {
		return REDIRECT_QUICK_CART_VIEW;
	}
}
