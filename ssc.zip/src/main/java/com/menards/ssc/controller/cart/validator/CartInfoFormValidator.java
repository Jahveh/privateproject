package com.menards.ssc.controller.cart.validator;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.menards.ssc.domain.order.MenardCartinfoDTO;

/**
 * <p>CartInfoFormValidator</p>
 * <p>validate cart info form</p>
 * <p>
 * validate cart info form, comment/listname
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Component("cartInfoFormValidator")
public class CartInfoFormValidator implements Validator {

	/**
	 * cart info page(save order)
	 * max length of order comment
	 */
	public static final int ORDER_COMMENT_MAX_LENGTH = 250;

	/**
	 * cart info page(save order)
	 * max length of order listname
	 */
	public static final int ORDER_LISTNAME_MAX_LENGTH = 125;

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(MenardCartinfoDTO.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		MenardCartinfoDTO cartinfo = (MenardCartinfoDTO) target;

		if (StringUtils.isNotEmpty(cartinfo.getComment())
				&& !GenericValidator.maxLength(cartinfo.getComment(), ORDER_COMMENT_MAX_LENGTH)) {
			errors.rejectValue("comment", "cart.order.comment.maxlength", new Integer[] { ORDER_COMMENT_MAX_LENGTH },
					null);
		}

		if (StringUtils.isNotEmpty(cartinfo.getListName())
				&& !GenericValidator.maxLength(cartinfo.getListName(), ORDER_LISTNAME_MAX_LENGTH)) {
			errors.rejectValue("listName", "cart.order.listname.maxlength",
					new Integer[] { ORDER_LISTNAME_MAX_LENGTH }, null);
		}

	}

}
