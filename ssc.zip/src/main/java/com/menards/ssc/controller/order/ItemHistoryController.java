package com.menards.ssc.controller.order;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.broadleafcommerce.core.web.controller.account.BroadleafOrderHistoryController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.order.MenardOrderItemDTO;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.enums.MenardOrderItemHistoryStatus;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.catalog.CategoryTreeService;
import com.menards.ssc.service.order.MenardOrderItemService;
import com.menards.ssc.service.yard.MenardYardService;

/**
 *
 * <p>ItemHistoryController</p>
 * Item History Controller that provides methods for item history processing
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
@Controller(value = "menardItemHistoryController")
@RequestMapping("/order")
public class ItemHistoryController extends BroadleafOrderHistoryController {

	public static final Log LOG = LogFactory.getLog(ItemHistoryController.class);

	private static final String ITEM_HISTORY_VIEW = "order/itemHistory";

	@Resource(name = "menardOrderItemService")
	private MenardOrderItemService menardOrderItemService;

	@Resource(name = "menardYardService")
	private MenardYardService yardService;

	@Resource(name = "messageSource")
	private MessageSource messageSource;

	@Autowired
	private CategoryTreeService categoryTreeService;
	
	/**
	 *
	 * search Item By Condition.
	 * @param model model
	 * @param filterDTO filterDTO description
	 * @param bindingResult bindingResult
	 * @param itemHistoryQuery itemHistoryQuery
	 * @return String item history page
	 */
	@RequestMapping(value = "/searchItem", method = RequestMethod.GET)
	public String searchItem(Model model, @Valid @ModelAttribute("filterDTO") MenardOrderItemFilterDTO filterDTO,
			BindingResult bindingResult, String itemHistoryQuery, HttpServletRequest request) {

		if (LOG.isDebugEnabled()) {
			LOG.debug(filterDTO);
		}
		if (filterDTO != null && StringUtils.isNotBlank(filterDTO.getTrackingStatus())) {
			filterDTO.setStatusSet(Arrays.asList(filterDTO.getTrackingStatus()));
		}

		List<MenardOrderItemDTO> list = null;
		String error = null;

		/*
		 * if (filterDTO != null) { filterDTO.setSize(Integer.MAX_VALUE); filterDTO.setSize(200); }
		 */

		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();

		if (StringUtils.isBlank(itemHistoryQuery)) {
			if (user.isGOUser()) {
				filterDTO.setDays(7);
				filterDTO.setTrackingStatus(MenardOrderItemHistoryStatus.COMPLETED.getValue());
			} else {
				filterDTO.setDays(14);
				filterDTO.setTrackingStatus(MenardOrderItemHistoryStatus.PENDING_GM.getValue());
			}
		}
		if (!user.isGOUser()) {
			filterDTO.setStoreId(user.getStoreNumber());
		}

		if (filterDTO != null && !StringUtils.isBlank(filterDTO.getTrackingStatus())) {
			Set<String> set = new HashSet<String>();
			set.addAll(Arrays.asList(StringUtils.split(filterDTO.getTrackingStatus(), CommonConstant.COMMA)));
			filterDTO.setStatusSet(set);
		}

		SearchResult<MenardOrderItemDTO> page = null;
		if (bindingResult.getAllErrors().size() > 0) {
			error = getErrorMessage(bindingResult);
		} 

		// list = menardOrderItemService.findAllOrderItemsForApproval(filterDTO);
		// page = menardOrderItemService.findOrderItemsPageForApproval(filterDTO);
		
		page = menardOrderItemService.findOrderItemsPageForHistory(filterDTO);
		
		model.addAttribute("orderItemList", list);
		model.addAttribute("searchResult", page);

		if (page != null) {
			model.addAttribute("total", page.getTotalResults());
		}

		model.addAttribute("filterData",
				MenardOrderItemFilterData.createInstance(CommonConstant.QUERYTYPE_HISTORY, yardService));
		if (filterDTO != null) {
			model.addAttribute("skuId", filterDTO.getSkuId());
		}
		model.addAttribute("messsage", error);
		model.addAttribute("pageSubTitle", "Item History");
		categoryTreeService.clearBreadCrumb(request);
		return ITEM_HISTORY_VIEW;

	}

	/**
	 *
	 * Get the error message from messageSource
	 * @param bindingResult bindingResult
	 * @return message String
	 */
	private String getErrorMessage(BindingResult bindingResult) {
		StringBuilder message = new StringBuilder();
		for (ObjectError error : bindingResult.getAllErrors()) {
			message.append(messageSource.getMessage(error, null)).append("<br/>");
		}
		return message.toString();
	}

}
