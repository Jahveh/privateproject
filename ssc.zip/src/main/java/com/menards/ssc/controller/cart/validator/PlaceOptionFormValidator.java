package com.menards.ssc.controller.cart.validator;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.menards.ssc.domain.order.MenardOrderOptionsDTO;

/**
 *
 * <p>PlaceOptionFormValidator</p>
 * <p>validate place option form</p>
 * <p>
 *  validate place option form
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Component("placeOptionFormValidator")
public class PlaceOptionFormValidator implements Validator {

	/**
	 * place order page
	 * max length of placed order comment
	 */
	public static final int PLACE_COMMENT_MAX_LENGTH = 250;

	/**
	 * place order page
	 * max length of grouping
	 */
	public static final int PLACE_GROUPING_MAX_LENGTH = 250;

	/**
	 * place order page
	 * max length of request by
	 */
	public static final int PLACE_REQUEST_BY_MAX_LENGTH = 250;

    /**
     * max length of generated note/comment for businesscard and welcome sign item
     */
    public static final int ITEM_CUSTOMIZATION_CONTENT_MAX_LENGTH = 120;

    @Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(MenardOrderOptionsDTO.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		MenardOrderOptionsDTO option = (MenardOrderOptionsDTO) target;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dueDate", "cart.place.due.date.empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "comment", "cart.place.comment.empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "requestBy", "cart.place.request.by.empty");

		if (StringUtils.isNotEmpty(option.getComment())
				&& !GenericValidator.maxLength(option.getComment(), PLACE_COMMENT_MAX_LENGTH)) {
			errors.rejectValue("comment", "cart.place.comment.maxlength", new Integer[] { PLACE_COMMENT_MAX_LENGTH },
					null);
		}

		if (StringUtils.isNotEmpty(option.getGroup())
				&& !GenericValidator.maxLength(option.getGroup(), PLACE_GROUPING_MAX_LENGTH)) {
			errors.rejectValue("group", "cart.place.grouping.maxlength", new Integer[] { PLACE_GROUPING_MAX_LENGTH },
					null);
		}

		if (StringUtils.isNotEmpty(option.getRequestBy())
				&& !GenericValidator.maxLength(option.getRequestBy(), PLACE_REQUEST_BY_MAX_LENGTH)) {
			errors.rejectValue("requestBy", "cart.place.request.by.maxlength",
					new Integer[] { PLACE_REQUEST_BY_MAX_LENGTH }, null);
		}

	}

}
