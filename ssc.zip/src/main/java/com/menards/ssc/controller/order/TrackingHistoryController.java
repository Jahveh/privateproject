package com.menards.ssc.controller.order;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.broadleafcommerce.core.web.controller.account.BroadleafOrderHistoryController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.menards.ssc.domain.order.MenardOrderItemHistory;
import com.menards.ssc.domain.order.MenardOrderItemTrackingHistory;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.service.order.MenardOrderService;

/**
 *
 * <p>TrackingHistoryController</p>
 * <p>
 * Tracking History Controller is to track item's status change record
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
@Controller(value = "menardTrackingHistoryController")
@RequestMapping("/order")
public class TrackingHistoryController extends BroadleafOrderHistoryController {

	public static final Log LOG = LogFactory.getLog(TrackingHistoryController.class);

	private static final String TRACKING_HISTORY_VIEW = "order/trackingHistory";

	@Resource(name = "menardOrderService")
	private MenardOrderService menardOrderService;

	/**
	 *
	 * get Tracking History By orderId & orderItemNumber.
	 * @param orderId  orderId
	 * @param orderItemNumber orderItemNumber
	 * @return ModelAndView modelAndView
	 */
	@RequestMapping(value = "/getTrackingHistory", method = RequestMethod.GET)
	public ModelAndView getTrackingHistory(@RequestParam(value = "orderId") Long orderId,
			@RequestParam(value = "orderItemNumber") Long orderItemNumber) {

		if (LOG.isDebugEnabled()) {
			LOG.debug("orderId : " + orderId);
			LOG.debug("orderItemNumber : " + orderItemNumber);
		}

		ModelAndView modelAndView = new ModelAndView();
		MenardOrderItemHistory item = menardOrderService.getTrackingHistory(orderItemNumber);

		for (MenardOrderItemTrackingHistory history : item.getHistory()) {
			history.setStatus(MenardOrderItemStatus.getDescriptionByValue(history.getStatus()));
		}

		modelAndView.addObject("trackingHistory", item.getHistory());
		modelAndView.addObject("lineNumber", item.getLineNumber());
		modelAndView.setViewName(TRACKING_HISTORY_VIEW);
		modelAndView.addObject("pageSubTitle", "Tracking History");

		return modelAndView;
	}

}
