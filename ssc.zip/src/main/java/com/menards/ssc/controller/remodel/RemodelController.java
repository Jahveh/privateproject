package com.menards.ssc.controller.remodel;

import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

import com.menards.ssc.dao.sign.MenardSignDao;
import com.menards.ssc.domain.setremodel.SetRemodelDTO;
import com.menards.ssc.service.catalog.CategoryTreeService;
import com.menards.ssc.service.yard.MenardYardService;
import com.menards.ssc.util.MenardUtil;

/**
 * <p>RemodelController</p>
 * <p>reset remodel controller</p>
 * <p>
 * reset remodel controller
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Controller("menardRemodelController")
@RequestMapping("/remodel")
public class RemodelController {

	private static final String REMODEL_DATES = "remodel/remodeldates";
	private static final String REMODEL = "remodel";

	private static final String MENARD_DATE_FORMAT_PATTERN = "MM/dd/yyyy";

	@Resource(name = "menardSignDao")
	private MenardSignDao signDao;

	@Resource(name = "menardYardService")
	private MenardYardService menardYardService;

	@Autowired
	private CategoryTreeService categoryTreeService;
	/**
	 * navigate to reset model page
	 * @param remodel remodel
	 * @param model model
	 * @return String String
	 */
	@RequestMapping(value = "/dates", produces = { "text/html", "*/*" })
	public String navigate2RemodelPage(SetRemodelDTO remodel, Model model, HttpServletRequest request) {
		model.addAttribute("stores", menardYardService.getYardForRemodelDates());
		model.addAttribute(REMODEL, remodel);
		categoryTreeService.clearBreadCrumb(request);
		return REMODEL_DATES;
	}

	/**
	 * navigate to reset model page
	 * @param remodel remodel
	 * @param errors BindingResult 
	 * @param model model
	 * @return String String
	 */
	@RequestMapping(value = "/date", produces = { "text/html", "*/*" })
	public String remodelDate(@Valid SetRemodelDTO remodel, BindingResult errors, Model model) {
		model.addAttribute("stores", menardYardService.getYardForRemodelDates());
		if (errors.hasErrors()) {
			model.addAttribute(REMODEL, remodel);
			return REMODEL_DATES;
		}

		SetRemodelDTO result = signDao.getSetRemodelByStoreId(remodel.getStoreId());
		result.setStartDateDisplay(MenardUtil.formatDate(result.getStartDate(), MENARD_DATE_FORMAT_PATTERN));
		result.setEndDateDisplay(MenardUtil.formatDate(result.getEndDate(), MENARD_DATE_FORMAT_PATTERN));
		model.addAttribute(REMODEL, result);
		return REMODEL_DATES;
	}

	/**
	 * set remodel date
	 * @param remodel remodel
	 * @param result  result
	 * @param model model
	 * @return string view
	 */
	@RequestMapping(value = "/updatedate", produces = { "text/html", "*/*" })
	public String updateRemodeDate(@Valid SetRemodelDTO remodel, BindingResult result, Model model) {
		model.addAttribute("remodel", remodel);
		model.addAttribute("stores", menardYardService.getYardForRemodelDates());
		Date startDate = MenardUtil.parseDate(remodel.getStartDateDisplay(), MENARD_DATE_FORMAT_PATTERN);
		Date endDate = MenardUtil.parseDate(remodel.getEndDateDisplay(), MENARD_DATE_FORMAT_PATTERN);
		int count = 0;
		if (startDate != null && endDate != null && startDate.after(new Date()) && startDate.before(endDate)) {
			remodel.setStartDate(startDate);
			remodel.setEndDate(endDate);
			count = signDao.updateRemodelDate(remodel);
		}
		model.addAttribute("updateCount", count);
		return REMODEL_DATES;
	}
}
