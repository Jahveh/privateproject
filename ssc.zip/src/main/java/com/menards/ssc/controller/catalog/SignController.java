package com.menards.ssc.controller.catalog;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.broadleafcommerce.core.catalog.domain.Category;
import org.broadleafcommerce.core.web.controller.catalog.BroadleafProductController;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.catalog.ColorSignDTO;
import com.menards.ssc.domain.catalog.SearchCriteria;
import com.menards.ssc.domain.catalog.SignDTO;
import com.menards.ssc.domain.navigation.CategoryTreeNode;
import com.menards.ssc.enums.MenardOrderItemType;
import com.menards.ssc.enums.SignSearchType;
import com.menards.ssc.service.catalog.CategoryTreeService;
import com.menards.ssc.service.catalog.MenardCatalogService;
import com.menards.ssc.service.catalog.MenardColorSignService;
import com.menards.ssc.service.catalog.MenardSignService;

/**
 *
 * <p>ProductController</p>
 * <p>product controller</p>
 * <p>
 * This class works in combination with the CategoryHandlerMapping which finds a category based upon
 * the passed in URL.
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Controller("signController")
@RequestMapping("/sign")
public class SignController extends BroadleafProductController {

	protected static final String MODEL_ATTRIBUTE_SIGN_NAME = "signDTO";

	@Resource(name = "signService")
	private MenardSignService signService;
	
	@Resource(name = "blCatalogService")
	private MenardCatalogService catalogService;

	@Resource(name = "colorSignService")
	private MenardColorSignService colorSignService;

	@Resource(name = "categoryTreeService")
	private CategoryTreeService categoryTreeService;
	
    /**
     * Application runtime environment
     * e.g. stage, development, production
     */
    @Value("${sigma.environment}")
    private String environment;

    public static final String NO_SIGN_VIEW = "catalog/NoSign";
    public static final String NO_SALESIGN_VIEW = "catalog/NoSaleSign";

	/**
	 * get sign detail
	 * @param signId signId
	 * @param yard yard
	 * @param type type
	 * @param promoNbr Integer
	 * @param model model
	 * @param criteria criteria
	 * @return view view
	 */
	@RequestMapping(value = "/{signId}/{yard}/{type}", produces = { "text/html", "*/*" })
	public String getSignDetail(@PathVariable("signId") Integer signId, @PathVariable("yard") Integer yard,
			@PathVariable("type") String type, @RequestParam(defaultValue = "0") Integer promoNbr,
            Model model, SearchCriteria criteria, HttpServletRequest httpServletRequest) {

        String searchType = httpServletRequest.getParameter("type");
        if (searchType == null || searchType.length() == 0) {
            searchType = httpServletRequest.getParameter("searchType");
        }
		if (MenardOrderItemType.COLOR_SIGN.getCode().equals(type)) {

			ColorSignDTO colorSign = colorSignService.getSign(signId.toString(), yard, SignSearchType.Detail);
            if (colorSign != null) {
                model.addAttribute(MODEL_ATTRIBUTE_SIGN_NAME, colorSign);
                String catalogId = getCategoryIdForColorSign(signId, httpServletRequest);
                categoryTreeService.setUpBreadCrumb(httpServletRequest, Long.parseLong(catalogId));
                httpServletRequest.getSession().setAttribute("selectedCategoryId", catalogId );
            } else {
                return NO_SIGN_VIEW;
            }
		} else if (MenardOrderItemType.SIGN.getCode().equals(type)){
			//Signbase and sku man goes here
			SignDTO sign = signService.findSign(signId, yard, SignSearchType.Detail, promoNbr, type);
            if (sign != null) {
                model.addAttribute(MODEL_ATTRIBUTE_SIGN_NAME, sign);
            } else {
                return NO_SALESIGN_VIEW;
            }
            
            List<Category> list = null;
    		//if (MenardOrderItemType.SIGN.getCode().equals(type)) {
    			list = catalogService.findCategoriesByName("Merchandising Signs and Fact Tags");
    		//} else {
    		//	list = catalogService.findCategoriesByName("Sale Signs");
    		//}
    		if (CollectionUtils.isNotEmpty(list)) {
//    			model.addAttribute("breadCrumb", groupBreadCrumb(list.get(0)));
                httpServletRequest.getSession().setAttribute("selectedCategoryId", list.get(0).getId().toString());
                categoryTreeService.setUpBreadCrumb(httpServletRequest, list.get(0).getId());
    		}
		} else if (MenardOrderItemType.SKU_MAN.getCode().equals(type)){
			SignDTO sign = signService.findPrePrintedFactTagDetail(signId, yard);			
            if (sign != null) {
            	sign.setType(type);        
            	List<Category> list = catalogService.findCategoriesByName("Merchandising Signs and Fact Tags");        		
        		if (CollectionUtils.isNotEmpty(list)) {
//        			model.addAttribute("breadCrumb", groupBreadCrumb(list.get(0)));
                    httpServletRequest.getSession().setAttribute("selectedCategoryId", list.get(0).getId().toString());
                    categoryTreeService.setUpBreadCrumb(httpServletRequest, list.get(0).getId());
        		}
                model.addAttribute(MODEL_ATTRIBUTE_SIGN_NAME, sign);
            } else {
                return NO_SALESIGN_VIEW;
            }
		}
        model.addAttribute("type", type);
		model.addAttribute("promoNbr", promoNbr);
		model.addAttribute("yardNum", yard);
		model.addAttribute("criteria", criteria);
		model.addAttribute("searchType", searchType);
		model.addAttribute("environment", environment);

		return "catalog/sign";
	}

    private String getCategoryIdForColorSign(int signId, HttpServletRequest request) {
        int catalogId = colorSignService.findColorSignCatalogId(signId);
        if (catalogId == -1) {
            Map<Long, CategoryTreeNode> categoryTreeNodeDict =  (Map<Long, CategoryTreeNode>)
                    request.getSession().getServletContext().getAttribute(CategoryTreeService.CATEGORY_TREE_DICTIONARY_SERVLET_CONTEXT_KEY);
            for (CategoryTreeNode categoryTreeNode : categoryTreeNodeDict.values()) {
                if (categoryTreeNode.getCategoryName().equalsIgnoreCase("Permanent Signage")
                        && categoryTreeNode.getUrl().equalsIgnoreCase("/Assortments/Kiosk/UniversalCatalog/SOS/POP/PermanentSignage")
                        ) {
                    return categoryTreeNode.getCategoryId().toString() ;

                }
            }

        } else {
            return "-" + catalogId;
        }
        return "-1";
    }

	/**
	 * Group the bread crumb data
	 * @param category
	 * @return String
	 */
	private String groupBreadCrumb(Category category) {
		StringBuilder sb = new StringBuilder();
		sb.append(category.getName());
		sb.append(CommonConstant.COMMA);
		sb.append(category.getUrl());
		Category parent = category.getDefaultParentCategory();
		if (parent != null) {
			sb.append(CommonConstant.COMMA);
			sb.append(parent.getName());
			sb.append(CommonConstant.COMMA);
			sb.append(parent.getUrl());
		}
		return sb.toString();
	}
}
