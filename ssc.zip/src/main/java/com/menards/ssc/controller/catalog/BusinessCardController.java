package com.menards.ssc.controller.catalog;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;

import com.menards.ssc.controller.cart.validator.PlaceOptionFormValidator;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.catalog.BusinessCardDTO;
import com.menards.ssc.domain.catalog.ProductDetailDTO;
import com.menards.ssc.enums.MenardTitle;
import com.menards.ssc.message.MessageSourceHelper;
import com.menards.ssc.service.catalog.MenardCatalogService;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>BusinessCardController</p>
 * <p>business card controller</p>
 * <p>
 * business card controller
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Controller("businessCardController")
@RequestMapping("/businesscard")
public class BusinessCardController extends ProductController {

	@Resource(name = "messageSourceHelper")
	private MessageSourceHelper messageSourceHelper;

	private static final String MODEL_ATTRIBUTE_NAME = "productDTO";
	private static final String BUSINESS_CARD = "catalog/businesscard";
	private static final String BUSINESS_CARD_CONFIRM = "catalog/businesscardconfirm";

	@Resource(name = "blCatalogService")
	private MenardCatalogService catalogService;

	/**
	 * navigate to business card
	 * @param mainSku CartItem
	 * @param businessCard BusinessCardDTO
	 * @param model Model
	 * @return string view
	 * @throws ItemNotFoundException itemNotFound
	 */
	@RequestMapping(value = "/form", produces = { "text/html", "*/*" })
	public String navigateBusinessCard(@Valid SkuCartItem mainSku, BusinessCardDTO businessCard, Model model)
			throws ItemNotFoundException {
		ProductDetailDTO productDTO = catalogService.getMenardProductDetail(mainSku.getProductId(), mainSku.getSkuId(),
				false);
		model.addAttribute(MODEL_ATTRIBUTE_NAME, productDTO);
		model.addAttribute("mainSku", mainSku);
		model.addAttribute("businessCard", businessCard);
		model.addAttribute("titles", MenardTitle.values());
		return BUSINESS_CARD;
	}

	/**
	 * package comment from business card
	 * @param mainSku CartItem
	 * @param result  BindingResult
	 * @param businessCard BusinessCardDTO
	 * @return ModelAndView view
	 * @throws ItemNotFoundException itemNotFound
	 */
	@RequestMapping(value = "/confirm", produces = { "text/html", "*/*" })
	public ModelAndView confirm(@Valid SkuCartItem mainSku, BindingResult result, @Valid BusinessCardDTO businessCard)
			throws ItemNotFoundException {
		ModelAndView mv = new ModelAndView();
		ProductDetailDTO productDTO = catalogService.getMenardProductDetail(mainSku.getProductId(), mainSku.getSkuId(),
				false);
		mv.addObject(MODEL_ATTRIBUTE_NAME, productDTO);

		if (!StringUtils.isEmpty(businessCard.getTitle())) {
			MenardTitle title = MenardTitle.valueOf(businessCard.getTitle());
			mainSku.setQuantity(title.getQuantity());
			businessCard.setTitle(title.getDesc());
		}
		mainSku.setComment(businessCard.getComment());

		Map<String, String> errorMsg = new HashMap<>();
		if (mainSku.getComment().length() > PlaceOptionFormValidator.ITEM_CUSTOMIZATION_CONTENT_MAX_LENGTH) {
			errorMsg.put("orderItemId", messageSourceHelper.getMessage("item.customization.content.maxLength",
					new Integer[] { PlaceOptionFormValidator.ITEM_CUSTOMIZATION_CONTENT_MAX_LENGTH }, ""));
		}

		if (result.hasErrors() || !errorMsg.isEmpty()) {
			mv.addObject("mainSku", mainSku);
			mv.addObject("businessCard", businessCard);
			mv.addObject("errors", errorMsg);
			mv.addObject("titles", MenardTitle.values());
			mv.setViewName(BUSINESS_CARD);
			return mv;
		}

        mainSku.setBusinessCard(productDTO.isBusinessCard());
		mv.addObject("mainSku", mainSku);
		mv.addObject("businessCard", businessCard);
		mv.setViewName(BUSINESS_CARD_CONFIRM);
		return mv;
	}

}
