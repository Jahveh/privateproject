package com.menards.ssc.controller;

import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

import java.util.Deque;

/**
 *
 * <p>BackButtonController</p>
 * <p>Pick the last GET request, and redirect to the URL</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author james.ni
 * @version 1.0
 */
@Controller("backButtonController")
public class BackButtonController {

    private final Log logger = LogFactory.getLog(BackButtonController.class);

    private static final String HOME = "/";
    private static final String METHOD_GET = "GET";

    /**
     * Restart SSC
     * @param request HttpServletRequest
     * @return URL String
     */
    @RequestMapping("/back")
    public String back(HttpServletRequest request) {
        Deque<String> requestHistory;
        String target = HOME;
        MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
        if (user.getRequestHistory() == null) {
            logger.info("request history is null, returning to Home page");
        } else {
            requestHistory = user.getRequestHistory();
            // this is the page user where user clicks Back button
            // Could be GET or POST request
            String current = requestHistory.pop();
            while (!requestHistory.isEmpty() && !getUrl(current).equalsIgnoreCase(HOME)) {
                String previous = requestHistory.pop();
                logger.info("Popped request from request history, new size " + requestHistory.size()
                        + ", servlet path is " + previous);
                if (!isGetRequest(previous) || previous.equals(current)) {
                    continue;
                } else {
                    target = getUrl(previous);
                    break;
                }
            }
        }

        return "redirect:" + target;
    }

    /**
     * Get request method from history string
     * e.g. "GET|/cart"
     *      "POST|/cart/options"
     * @param history
     * @return
     */
    private boolean isGetRequest(String history) {
        String[] tokens = history.split("\\|");
        if (tokens != null && tokens.length == 2) {
            String method = tokens[0];
            return METHOD_GET.equalsIgnoreCase(method);
        }
        return false;
    }

    /**
     * Get url from history string
     * e.g. "GET|/cart"
     *      "POST|/cart/options"
     * @param history
     * @return
     */
    private String getUrl(String history) {
        String[] tokens = history.split("\\|");
        if (tokens != null && tokens.length == 2) {
            return tokens[1];
        }
        return null;
    }
}