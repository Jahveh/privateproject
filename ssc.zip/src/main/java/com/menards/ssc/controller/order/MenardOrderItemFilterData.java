package com.menards.ssc.controller.order;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.yard.Store;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardOrderItemHistoryStatus;
import com.menards.ssc.enums.MenardOrderItemSort;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.enums.MenardQueryDateInterval;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.yard.MenardYardService;

/**
 * <p>MenardOrderItemFilterData</p>
 * <p>Collection all the meta data for drop down list</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public final class MenardOrderItemFilterData {

	private List<Store> store;
	private List<MenardOrderItemStatus> status;
	private List<MenardOrderItemHistoryStatus> historyStatus;
	private List<MenardQueryDateInterval> interval;
	private Collection<MenardOrderRequestType> requestType;
	private List<MenardOrderItemSort> sortList;

	/**
	 *Constructor
	 */
	private MenardOrderItemFilterData() {
	}

	/**

	 * @return List<MenardOrderItemStatus>
	 */
	public List<MenardOrderItemStatus> getStatus() {
		return status;
	}

	/**

	 * @param status List<MenardOrderItemStatus>
	 */
	public void setStatus(List<MenardOrderItemStatus> status) {
		this.status = status;
	}

	/**

	 * @return List<MenardQueryDateInterval>
	 */
	public List<MenardQueryDateInterval> getInterval() {
		return interval;
	}

	/**

	 * @param interval List<MenardQueryDateInterval>
	 */
	public void setInterval(List<MenardQueryDateInterval> interval) {
		this.interval = interval;
	}

	/**

	 * @return  List<MenardOrderItemSort>
	 */
	public List<MenardOrderItemSort> getSortList() {
		return sortList;
	}

	/**

	 * @param sortList List<MenardOrderItemSort>
	 */
	public void setSortList(List<MenardOrderItemSort> sortList) {
		this.sortList = sortList;
	}

	/**
	 * @return  Collection<MenardOrderRequestType>
	 */
	public Collection<MenardOrderRequestType> getRequestType() {
		return requestType;
	}

	/**
	 *
	 * @param requestType Collection<MenardOrderRequestType>
	 */
	public void setRequestType(Collection<MenardOrderRequestType> requestType) {
		this.requestType = requestType;
	}

	/**
	 * Build the filter data according to different type.
	 *
	 * @param type item history or approve
	 * @param yardService MenardYardService
	 * @return MenardOrderItemFilterData
	 */
	public static MenardOrderItemFilterData createInstance(String type, MenardYardService yardService) {
		MenardOrderItemFilterData data = new MenardOrderItemFilterData();
		data.setInterval(Arrays.asList(MenardQueryDateInterval.values()));
		data.setSortList(Arrays.asList(MenardOrderItemSort.values()));

		if (!(CommonConstant.QUERYTYPE_HISTORY.equals(type) || CommonConstant.QUERY_TYPE_APPROVE.equals(type))) {
			return data;
		}
		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		boolean isYard = userDetails.isYard();
		String role = userDetails.getFulfillerType();
		String storeNumber = userDetails.getStoreNumber();
		String operationType = userDetails.getOperationsType();
		String factTagRequestType = userDetails.getFactTagRequestType();

		//if (StringUtils.isBlank(role) || MenardFulfillerType.GENERAL_MANAGER.getKey().equals(role)) {
		if (isYard) {
			// data.setStore(Arrays.asList(Stores.getStoreByValue(store)));
			Store store = yardService.getStore(StringUtils.trim(storeNumber));
			if (store != null) {
				data.setStore(Arrays.asList(store));
			}			
		} else {
			data.setStore(yardService.getYardNameList());
			// data.setStore(Arrays.asList(Stores.values()));
		}

		// Build the filter data for item history
		if (CommonConstant.QUERYTYPE_HISTORY.equals(type)) {
			data.setHistoryStatus(Arrays.asList(MenardOrderItemHistoryStatus.values()));
			// Put all the request type
			data.setRequestType(MenardOrderRequestType.getAllRequestTypeForOptions());
			return data;
		}
		if (StringUtils.isNotBlank(role)) {
			if (MenardFulfillerType.GENERAL_MANAGER.getKey().equals(role)
					|| MenardFulfillerType.LITERATURE.getKey().equals(role)) {
				data.setStatus(Arrays.asList(MenardOrderItemStatus.PENDING_GM));
			} else if (MenardFulfillerType.SUPER_GO.getKey().equals(role)) {
				data.setStatus(Arrays.asList(MenardOrderItemStatus.PENDING_GM, MenardOrderItemStatus.PENDING_GO,
						MenardOrderItemStatus.BACKORDERED));
			} else {
				data.setStatus(Arrays.asList(MenardOrderItemStatus.PENDING_GO, MenardOrderItemStatus.BACKORDERED));
			}
		}

		// Set the request type according the user's information
		data.setRequestType(MenardOrderRequestType.getReqeustTypeByRoleType(role, operationType, factTagRequestType));

		return data;
	}

	/**
	 * @return historyStatus historyStatus
	 */
	public List<MenardOrderItemHistoryStatus> getHistoryStatus() {
		return historyStatus;
	}

	/**
	 * @param historyStatus historyStatus 
	 */
	public void setHistoryStatus(List<MenardOrderItemHistoryStatus> historyStatus) {
		this.historyStatus = historyStatus;
	}

	public List<Store> getStore() {
		return store;
	}

	public void setStore(List<Store> store) {
		this.store = store;
	}
}
