/**
 * 
 */
package com.menards.ssc.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <p>ErrorController</p>
 * <p>Deal with all the system errors</p>
 * <p>Process all the errors such as 404, 500 and so on</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Controller
@ControllerAdvice
public class ExceptionHandlerController {
	private static final Log LOG = LogFactory.getLog(ExceptionHandler.class);

	/**
	 * 
	 * Deal with all the errors
	 * @param model Model
	 * @return common error page
	 */
	@RequestMapping("/error")
	public String handleRequest(Model model) {
		model.addAttribute("error", true);
		return "exception/error";
	}

	/**
	 * 
	 * Catch all the exceptions happening in the application
	 * @param request HttpServletRequest
	 * @param e exception
	 * @return common error page
	 */
	@ExceptionHandler(Exception.class)
	public String processException(HttpServletRequest request, Exception e) {
		LOG.error(e.getMessage());
		request.setAttribute("error", true);
		return "exception/error";
	}
}
