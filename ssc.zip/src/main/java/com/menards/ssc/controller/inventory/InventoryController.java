package com.menards.ssc.controller.inventory;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.menards.mymenards.security.HttpAuthentication;
import com.menards.ssc.domain.inventory.MenardInventoryDTO;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.catalog.CategoryTreeService;
import com.menards.ssc.service.inventory.MenardInventoryService;

/**
 *
 * <p>InventoryController</p>
 * <p>An Inventory Controller that provides methods for Monthly Inventory Report processing</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
@Controller(value = "menardInventoryController")
@RequestMapping("/inventory")
public class InventoryController {

	public static final Log LOG = LogFactory.getLog(InventoryController.class);

	private static final String PRINT_INVENTORY = "inventory/print";
	private static final String CONFIRM_INVENTORY = "inventory/confirm";
	private static final String MONTHLY_INVENTORY_VIEW = "inventory/monthlySupplyInventory";
	private static final String INVENTORY_DEFAULT_PAGE = "redirect:/inventory/getInvQuantityOnHand";

	@Resource(name = "menardInventoryService")
	private MenardInventoryService inventoryService;

	@Autowired
	private CategoryTreeService categoryTreeService;
	
	@Resource(name = "menardUserDetailsService")
	private UserDetailsManager  userDetailsService;
	
	/**
	 *
	 * get Inventory Quantity On Hand.
	 * @param model model
	 * @return String String
	 */
	@RequestMapping(value = "/getInvQuantityOnHand", method = RequestMethod.GET)
	public String getInvQuantityOnHand(Model model, HttpServletRequest request) {

		boolean updateStatus = true;
		List<MenardInventoryDTO> inventory = inventoryService.getInventory();

		model.addAttribute("inventory", inventory);
		model.addAttribute("pageSubTitle", "Monthly Inventory Report ");
		model.addAttribute("updateStatus", updateStatus);
		categoryTreeService.clearBreadCrumb(request);
		return MONTHLY_INVENTORY_VIEW;
	}

	/**
	 *
	 * update Inventory.
	 * @param model model
	 * @param quantity quantity
	 * @param sku sku	
	 * @return String String
	 */
	@RequestMapping(value = "/updateInventory", method = RequestMethod.POST)
	public String updateInventory(Model model, @RequestParam(value = "skuQuantity") String[] quantity,
			@RequestParam(value = "skuNum") String[] sku) {

		List<MenardInventoryDTO> inventory = inventoryService.updateInventory(sku, quantity);
		// List<MenardInventoryDTO> inventory = inventoryService.getInventory();
		model.addAttribute("inventory", inventory);

		boolean updateStatus = true;
		if (inventory.size() != 0) {
			updateStatus = false;
		}

		model.addAttribute("pageSubTitle", "Monthly Inventory Report ");
		model.addAttribute("updateStatus", updateStatus);

		if (updateStatus) {
			return CONFIRM_INVENTORY;
		} else {
			return MONTHLY_INVENTORY_VIEW;
		}
	}

	/**
	 * 
	 * print inventory
	 * @param model	
	 * @return String String
	 */
	@RequestMapping(value = "/print", method = RequestMethod.GET)
	public String print(Model model, HttpServletRequest request) {
		processUserDetails(request);
		List<MenardInventoryDTO> inventory = inventoryService.getInventory();
		model.addAttribute("inventory", inventory);
		model.addAttribute("pageSubTitle", "Monthly Inventory Report ");
		MenardSecurityContextHolder.setUserDetailsThreadLocal(null);
		return PRINT_INVENTORY;
	}
	
	/**
	 * Because user detail is null when opening a new window we have to retrieve the user
	 * again.
	 * 
	 * @param request
	 * @return MenardUserDetails
	 */
	private void processUserDetails(HttpServletRequest request){
		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		if (userDetails != null) {
			return;
		}
		
		HttpAuthentication httpAuth = HttpAuthentication.getInstance();
		String userName= httpAuth.getUserName(request);
		userDetails = (MenardUserDetails) userDetailsService.loadUserByUsername(userName);
		MenardSecurityContextHolder.setUserDetailsThreadLocal(userDetails);
	}

	/**	
	 * default page for inventory	
	 * @return INVENTORY_DEFAULT_PAGE String 
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String inventory() {
		return INVENTORY_DEFAULT_PAGE;
	}

}
