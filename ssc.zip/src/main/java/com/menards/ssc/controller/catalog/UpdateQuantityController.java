package com.menards.ssc.controller.catalog;

import com.menards.ssc.domain.cart.UpdateQuantityDTO;
import com.menards.ssc.domain.catalog.MenardProductDTO;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.catalog.MenardSkuDTO;
import com.menards.ssc.domain.inventory.MenardInventoryDTO;
import com.menards.ssc.message.MessageSourceHelper;
import com.menards.ssc.service.catalog.MenardCatalogService;
import com.menards.ssc.service.inventory.MenardInventoryService;

import org.apache.commons.lang3.StringUtils;
import org.broadleafcommerce.core.catalog.domain.Sku;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.validation.Valid;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>UpdateQuantityController</p>
 * <p>update quantity controller</p>
 * <p>
 * update quantity controller
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author eason.yu
 * @version 1.0
 */
@Controller("updateQuantityController")
@RequestMapping("/updatequantity")
public class UpdateQuantityController {

	private static final String UPDATE_QUANTITY = "catalog/updatequantity";
	private static final String MODEL_ATTRIBUTE_NAME = "productDTO";

	@Resource(name = "blCatalogService")
	private MenardCatalogService catalogService;

	@Resource(name = "menardInventoryService")
	private MenardInventoryService inventoryService;

	@Resource(name = "messageSourceHelper")
	private MessageSourceHelper messageSourceHelper;

	/**
	 * navigate to update quantity page
	 *
	 * @param updateQuantityDTO UpdateQuantityDTO
	 * @param result            BindingResult
	 * @param model             model
	 * @return string view
	 * @throws ItemNotFoundException product not found
	 */
	@RequestMapping(value = "/form", produces = { "text/html", "*/*" })
	public String navigateUpdateQuantity(@Valid UpdateQuantityDTO updateQuantityDTO, BindingResult result, Model model)
			throws ItemNotFoundException {
		long productId = Long.valueOf(updateQuantityDTO.getProductId());
		MenardProductDTO productDTO = catalogService.getMenardProductById(productId);

		model.addAttribute("updateQuantityDTO", updateQuantityDTO);
		model.addAttribute(MODEL_ATTRIBUTE_NAME, productDTO);
		return UPDATE_QUANTITY;
	}

	/**
	 * update quantity
	 *
	 * @param updateQuantityDTO UpdateQuantityDTO
	 * @param result            BindingResult
	 * @param model Model
	 * @return string view
	 * @throws ItemNotFoundException ItemNotFound
	 */
	@RequestMapping(value = "/update", produces = { "text/html", "*/*" })
	public String updateQuantity(@Valid UpdateQuantityDTO updateQuantityDTO, BindingResult result, Model model)
			throws ItemNotFoundException {
		long productId = Long.valueOf(updateQuantityDTO.getProductId());
        MenardProductDTO productDTO = catalogService.getMenardProductById(productId);

		boolean isQuantityInputValid = validateQuantityInput(updateQuantityDTO.getQuantity());

		MenardInventoryDTO mid = null;
		if (isQuantityInputValid) {
			int quantity = (int) Math.round(Double.parseDouble(updateQuantityDTO.getQuantity()));
			mid = inventoryService.updateInventory(productDTO.getModelNum(), quantity);
		}

		Map<String, String> errorMsg = new HashMap<>();
		if (mid != null) {
            // mid is the one for which failed to update inventory
			// Error updating inventory
			errorMsg.put("error", messageSourceHelper.getMessage("product.updateQuantity.error", null, ""));

			model.addAttribute(MODEL_ATTRIBUTE_NAME, productDTO);
			model.addAttribute("updateQuantityDTO", updateQuantityDTO);
			model.addAttribute("errors", errorMsg);
			return UPDATE_QUANTITY;
		}

		return "redirect:/product/" + productId;
	}

	/**
	 * 
	 * check whether input is numeric
	 * @param quantity String
	 * @return isNumeric boolean
	 */
	private boolean validateQuantityInput(String quantity) {
		return StringUtils.isNumeric(quantity);
	}

}
