package com.menards.ssc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.menards.ssc.controller.catalog.CategoryController;
import com.menards.ssc.filter.BackButtonFilter;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

import java.util.Deque;

/**
 *
 * <p>RestartController</p>
 * <p>Restart SSC, remove certain session attributes</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author james.ni
 * @version 1.0
 */
@Controller("restartController")
public class RestartController {

	/**
	 * Restart SSC
	 * @param request HttpServletRequest
	 * @return URL String
	 */
    @RequestMapping("/restart")
    public String restart(HttpServletRequest request) {
        // remove session data
        HttpSession session = request.getSession();

        // Remove selected category id
        session.removeAttribute(CategoryController.SELECTED_CATEGORY_ID_SESSION_KEY);

        // Clear back request history
        MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
        Deque requestHistory = user.getRequestHistory();
        if (requestHistory != null && !requestHistory.isEmpty()) {
            requestHistory.clear();
        }

        return "redirect:/";
    }
}