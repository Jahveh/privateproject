package com.menards.ssc.controller.catalog;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.menards.ssc.controller.cart.validator.PlaceOptionFormValidator;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.catalog.ProductDetailDTO;
import com.menards.ssc.domain.catalog.WelcomeSignDTO;
import com.menards.ssc.message.MessageSourceHelper;
import com.menards.ssc.service.catalog.MenardCatalogService;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>WelcomeSignController</p>
 * <p>welcome sign controller</p>
 * <p>
 * welcome sign controller
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Controller("welcomeSignController")
@RequestMapping("/welcomesign")
public class WelcomeSignController extends ProductController {

	@Resource(name = "messageSourceHelper")
	private MessageSourceHelper messageSourceHelper;

	private static final String MODEL_ATTRIBUTE_NAME = "productDTO";
	private static final String WELCOME_SIGN = "catalog/welcomesign";
	private static final String WELCOME_SIGN_CONFIRM = "catalog/welcomesignconfirm";

	@Resource(name = "blCatalogService")
	private MenardCatalogService catalogService;

	/**
	 * navigate to welcome sign page
	 * @param mainSku CartItem
	 * @param model model
	 * @param welcomeSign welcomeSign
	 * @return view view
	 * @throws ItemNotFoundException ItemNotFound
	 */
	@RequestMapping(value = "/form", produces = { "text/html", "*/*" })
	public String navigateWelcomeSign(@Valid SkuCartItem mainSku, Model model, @Valid WelcomeSignDTO welcomeSign)
			throws ItemNotFoundException {

		ProductDetailDTO productDTO = catalogService.getMenardProductDetail(mainSku.getProductId(), mainSku.getSkuId(),
				false);
		model.addAttribute(MODEL_ATTRIBUTE_NAME, productDTO);
		model.addAttribute("mainSku", mainSku);
		model.addAttribute("welcomeSign", welcomeSign);
		return WELCOME_SIGN;
	}

	/**
	 * package comment then to welcome sign confirm page
	 * @param mainSku CartItem
	 * @param result BindingResult
	 * @param welcomeSign WelcomeSignDTO
	 * @return ModelAndView ModelAndView
	 * @throws ItemNotFoundException ItemNotFound
	 */
	@RequestMapping(value = "/confirm", produces = { "text/html", "*/*" })
	public ModelAndView confirm(@Valid SkuCartItem mainSku, BindingResult result, @Valid WelcomeSignDTO welcomeSign)
			throws ItemNotFoundException {
		mainSku.setComment(welcomeSign.getComment());

		ModelAndView mv = new ModelAndView();
		ProductDetailDTO productDTO = catalogService.getMenardProductDetail(mainSku.getProductId(), mainSku.getSkuId(),
				false);
		mv.addObject(MODEL_ATTRIBUTE_NAME, productDTO);

		Map<String, String> errorMsg = new HashMap<>();
		if (mainSku.getComment().length() > PlaceOptionFormValidator.ITEM_CUSTOMIZATION_CONTENT_MAX_LENGTH) {
			errorMsg.put("orderItemId", messageSourceHelper.getMessage("item.customization.content.maxLength",
					new Integer[] { PlaceOptionFormValidator.ITEM_CUSTOMIZATION_CONTENT_MAX_LENGTH }, ""));
		}

		if (result.hasErrors() || !errorMsg.isEmpty()) {
			mv.addObject("mainSku", mainSku);
			mv.addObject("welcomeSign", welcomeSign);
			mv.addObject("errors", errorMsg);
			mv.setViewName(WELCOME_SIGN);
			return mv;
		}

		mv.setViewName(WELCOME_SIGN_CONFIRM);
		mv.addObject("mainSku", mainSku);
		mv.addObject("welcomeSign", welcomeSign);

		return mv;
	}

}
