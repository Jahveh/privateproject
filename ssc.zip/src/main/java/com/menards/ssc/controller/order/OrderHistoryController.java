package com.menards.ssc.controller.order;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.broadleafcommerce.core.order.domain.OrderItem;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.broadleafcommerce.core.web.controller.account.BroadleafOrderHistoryController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderDTO;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.order.MenardOrderItemDTO;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.enums.MenardQueryDateInterval;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.catalog.CategoryTreeService;
import com.menards.ssc.service.order.MenardOrderService;
import com.menards.ssc.service.yard.MenardYardService;

/**
 *
 * <p>OrderHistoryController</p>
 * <p>An Order History Controller that provides methods for order history processing</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
@Controller(value = "menardOrderHistoryController")
@RequestMapping("/order")
public class OrderHistoryController extends BroadleafOrderHistoryController {

	public static final Log LOG = LogFactory.getLog(OrderHistoryController.class);

	private static final String ORDER_DETAIL_VIEW = "order/orderDetail";
	private static final String ORDER_HISTORY_VIEW = "order/orderHistory";
	private static final String ORDER_DEFAULT_PAGE = "redirect:/order/searchOrder";

	@Resource(name = "menardOrderService")
	private MenardOrderService orderService;

	@Resource(name = "menardYardService")
	private MenardYardService yardService;

	@Resource(name = "messageSource")
	private MessageSource messageSource;

	@Autowired
	private CategoryTreeService categoryTreeService;
	
	/**
	 *
	 * view Order Detail.
	 * @param orderId orderId
	 * @return ModelAndView modelAndView
	 */
	@RequestMapping(value = "/viewOrderDetail", method = RequestMethod.GET)
	public ModelAndView viewOrderDetail(@RequestParam(value = "orderId") Long orderId) {

		ModelAndView modelAndView = new ModelAndView();
		MenardOrder order = (MenardOrder) orderService.getOrderById(orderId);

		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		List<MenardOrderItemDTO> dtos = new ArrayList<MenardOrderItemDTO>();
		for (OrderItem orderItem : order.getOrderItems()) {
			MenardOrderItem item = (MenardOrderItem) orderItem;
			MenardOrderItemDTO dto = new MenardOrderItemDTO(CommonConstant.ASTERISK, item);
			// dto.setSubmitDate(order.getSubmitDate());
			dtos.add(dto);
		}

		modelAndView.addObject("orderItems", dtos);
		modelAndView.addObject("order", order);
		modelAndView.addObject("items", order.getOrderItems().size());
		modelAndView.setViewName(ORDER_DETAIL_VIEW);
		modelAndView.addObject("pageSubTitle", "Order History");

		return modelAndView;
	}

	/**
	 *
	 * search Order By Composite Condition.
	 * @param model model
	 * @param filterDTO filterDTO
	 * @param bindingResult bindingResult
	 * @param orderHistoryQuery orderHistoryQuery
	 * @return String String
	 */
	@RequestMapping(value = "/searchOrder", method = RequestMethod.GET)
	public String searchOrder(Model model, @Valid @ModelAttribute("filterDTO") MenardOrderItemFilterDTO filterDTO,
			BindingResult bindingResult, String orderHistoryQuery, HttpServletRequest request) {

		if (LOG.isDebugEnabled()) {
			LOG.debug(filterDTO);
		}

		//List<MenardOrderDTO> menardOrder = new ArrayList<MenardOrderDTO>();
		String error = null;

		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		String userId = null;
		if (user != null) {
			userId = user.getUserId();
			if (user.isYard()) {
				userId += user.getStoreNumber();
			}

		}

		if (StringUtils.isBlank(orderHistoryQuery)) {
			if (user.isGOUser()) {
				filterDTO.setDays(14);
			}
		}

		if (!StringUtils.isBlank(filterDTO.getTrackingStatus())) {
			Set<String> set = new HashSet<String>();
			set.add(filterDTO.getTrackingStatus());
			filterDTO.setStatusSet(set);
		}
		
		/*if (bindingResult.getAllErrors().size() > 0) {
			error = getErrorMessage(bindingResult);
		}
*/
		SearchResult<MenardOrderDTO> page = null;

		if (user != null && user.isGOUser()) {
			// menardOrder = orderService.getOrderByFilter(filterDTO);
			page = orderService.getOrderByPagination(filterDTO);

		} else {
			/*
			 * List<MenardOrder> ordersForNonGo = orderService.findOrdersByUserId(userId, OrderStatus.SUBMITTED); for
			 * (MenardOrder order : ordersForNonGo) { menardOrder.add(new MenardOrderDTO(order)); }
			 */
			page = orderService.findOrdersByUserId(filterDTO, userId, OrderStatus.SUBMITTED);
		}

		if (user != null) {
			model.addAttribute("isGOUser", user.isGOUser());
		}
		// model.addAttribute("menardOrder", menardOrder);
		// model.addAttribute("stores", Stores.values());
		model.addAttribute("searchResult", page);

		if (page != null) {
			model.addAttribute("total", page.getTotalResults());
		}
		model.addAttribute("filterData",
				MenardOrderItemFilterData.createInstance(CommonConstant.QUERYTYPE_HISTORY, yardService));
		model.addAttribute("orderId", filterDTO.getOrderId());
		model.addAttribute("intervals", MenardQueryDateInterval.values());
		model.addAttribute("messsage", error);
		model.addAttribute("pageSubTitle", "Order History");
		categoryTreeService.clearBreadCrumb(request);
		return ORDER_HISTORY_VIEW;
	}

	/**
	 *
	 * Get the error message from messageSource
	 * @param bindingResult bindingResult
	 * @return message String
	 */
	private String getErrorMessage(BindingResult bindingResult) {
		StringBuilder message = new StringBuilder();
		for (ObjectError error : bindingResult.getAllErrors()) {
			message.append(messageSource.getMessage(error, null)).append("<br/>");
		}
		return message.toString();
	}

	/**
	 * default page for order
	 * @return ORDER_DEFAULT_PAGE String
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String viewOrderHistory() {
		return ORDER_DEFAULT_PAGE;
	}

}
