package com.menards.ssc.controller.order;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.menards.mymenards.security.HttpAuthentication;
import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.order.MenardOrderItemApproveRequestDTO;
import com.menards.ssc.domain.order.MenardOrderItemDTO;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.domain.yard.Store;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.catalog.CategoryTreeService;
import com.menards.ssc.service.order.MenardOrderItemService;
import com.menards.ssc.service.yard.MenardYardService;

/**
 * <p>MenardOrderApproveController</p>
 * <p>Deal with coming request related to order item approve </p>
 * <p>
 *   Currently, it only processes two types of requests, finding all the
 *   order items being approved and approving, back ordering or declining
 *   order items, meanwhile returning the result.
 *
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Controller(value = "menardOrderApproveController")
@RequestMapping("/orderitem")
public class MenardOrderApproveController {

	public static final Logger LOG = Logger.getLogger(MenardOrderApproveController.class);

	@Resource(name = "menardOrderItemService")
	private MenardOrderItemService menardOrderItemService;

	@Resource(name = "menardYardService")
	private MenardYardService yardService;
	
	@Autowired
	private CategoryTreeService categoryTreeService;	
	
	@Resource(name = "menardUserDetailsService")
	private UserDetailsManager  userDetailsService;

	private final String itemListForApprove = "order/orderItemsForApprove";

	/**
	 * Query the order items according to the input conditions, such as store id,
	 * tracking status and so on.
	 *
	 * @param model Model
	 * @param filter MenardOrderItemFilterDTO
	 * @return String
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String showAllOrderItemsForApproval(Model model, @ModelAttribute("filterDTO") 
			MenardOrderItemFilterDTO filter, HttpServletRequest request) {
		if (LOG.isDebugEnabled()) {
			LOG.debug(filter);
		}
		// Get all the options
		MenardOrderItemFilterData data = MenardOrderItemFilterData.createInstance(CommonConstant.QUERY_TYPE_APPROVE,
				yardService);
		MenardOrderItemFilterDTO dto = filter;
		if (filter == null) {
			dto = new MenardOrderItemFilterDTO();
		}
		
		groupOrderItemStatus(dto, data);
		SearchResult<MenardOrderItemDTO> page = menardOrderItemService.findOrderItemsPageForApproval(dto);
		model.addAttribute("searchResult", page);
		model.addAttribute("filterData", data);
		model.addAttribute("total", page.getTotalResults());
		model.addAttribute("pageSubTitle", MenardItemApproveAction.APPROVED.getKey());
		categoryTreeService.clearBreadCrumb(request);
		return itemListForApprove;
	}

	/**	
	 * Initialize order item status
	 * @param filter MenardOrderItemFilterDTO filter
	 * @param data MenardOrderItemFilterData
	 */
	private void groupOrderItemStatus(MenardOrderItemFilterDTO filter, MenardOrderItemFilterData data) {
		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		if (userDetails.isYard()) {
			filter.setStoreId(userDetails.getStoreNumber());
		}
		if (StringUtils.isBlank(filter.getRequestType())) {
			StringBuilder sb = new StringBuilder();
			for (MenardOrderRequestType type : data.getRequestType()) {
				sb.append(type.getKey());
				sb.append(CommonConstant.COMMA);
			}
			filter.setRequestType(StringUtils.substringBeforeLast(sb.toString(), CommonConstant.COMMA));
		}
		if (StringUtils.isNotBlank(filter.getTrackingStatus())) {
			filter.getStatusSet().add(filter.getTrackingStatus());
			return;
		}

		if (CollectionUtils.isEmpty(data.getStatus())) {
			filter.getStatusSet().add(StringUtils.EMPTY);
			return;
		}

		for (MenardOrderItemStatus status : data.getStatus()) {
			filter.getStatusSet().add(status.getValue());
		}
	}

	private final String approve = "order/orderItemsApproveResult";

	/**
	 * Approve, back order or decline the order items
	 *
	 * @param model Model
	 * @param requestDTO MenardOrderItemApproveRequestDTO
	 * @return String
	 */
	@RequestMapping(value = "/approve", method = RequestMethod.POST)
	public String approveOrderItems(Model model, MenardOrderItemApproveRequestDTO requestDTO) {
		if (LOG.isDebugEnabled()) {
			LOG.debug(requestDTO);
		}
		if (requestDTO == null || CollectionUtils.isEmpty(requestDTO.getItems())) {
			return approve;
		}
		Map<String, List<MenardOrderItemDTO>> map = menardOrderItemService.approveOrderItems(requestDTO.getItems());
		model.addAttribute("approvedOrderItemMap", map);
		model.addAttribute("pageSubTitle", MenardItemApproveAction.APPROVED.getKey());

		return approve;
	}

	/**
	 * Print all the order items that should be approved
	 *
	 * @param model Model
	 * @param filter MenardOrderItemFilterDTO
	 * @return String
	 */
	@RequestMapping(value = "/print", method = RequestMethod.GET)
	public String printAllOrderItems(Model model, @ModelAttribute("filterDTO") MenardOrderItemFilterDTO filter, HttpServletRequest request) {
		if (LOG.isDebugEnabled()) {
			LOG.debug(filter);
		}
		processUserDetails(request);
		// Get all the options
		MenardOrderItemFilterData data = MenardOrderItemFilterData.createInstance(CommonConstant.QUERY_TYPE_APPROVE,
				yardService);
		MenardOrderItemFilterDTO dto = (filter != null ? filter : new MenardOrderItemFilterDTO());
		groupOrderItemStatus(dto, data);
		SearchResult<MenardOrderItemDTO> page = menardOrderItemService.findOrderItemsPageForApproval(dto);
		for (MenardOrderItemDTO element : page.getResult()) {
			Store store = yardService.getStore(element.getStoreId());
			element.setStoreName(StringUtils.EMPTY);
			if (store != null) {
				element.setStoreId(store.getStoreNumber());
				element.setStoreName(store.getStoreName());
			}			
		}
		model.addAttribute("searchResult", page);
		MenardSecurityContextHolder.setUserDetailsThreadLocal(null);
		return "order/orderItemsPrint";
	}
	
	
	/**
	 * Because user detail is null when opening a new window we have to retrieve the user
	 * again.
	 * 
	 * @param request
	 * @return MenardUserDetails
	 */
	private void processUserDetails(HttpServletRequest request){
		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		if (userDetails != null) {
			return;
		}
		
		HttpAuthentication httpAuth = HttpAuthentication.getInstance();
		String userName= httpAuth.getUserName(request);
		userDetails = (MenardUserDetails) userDetailsService.loadUserByUsername(userName);
		MenardSecurityContextHolder.setUserDetailsThreadLocal(userDetails);
	}

	/**
	 * 
	 * Count the order items for approval
	 * @return String totalResults
	 */
	@RequestMapping(value = "/count", method = RequestMethod.GET)
	@ResponseBody
	public String countOrderItemsForApprove() {
		// Get all the options
		MenardOrderItemFilterData data = MenardOrderItemFilterData.createInstance(CommonConstant.QUERY_TYPE_APPROVE,
				yardService);
		MenardOrderItemFilterDTO dto = new MenardOrderItemFilterDTO();
		groupOrderItemStatus(dto, data);
		SearchResult<MenardOrderItemDTO> page = menardOrderItemService.findOrderItemsPageForApproval(dto);
		return "{\"count\":\"" + page.getTotalResults() + "\"}";
	}

    /**
     *
     * Count the order items for approval
     * @return String totalResults
     */
    @RequestMapping(value = "/totalCount", method = RequestMethod.GET)
    @ResponseBody
    public String countTotalOrderItemsForApprove() {
        long count = menardOrderItemService.countOrderItemsForApprove();
        return "{\"count\":\"" + count + "\"}";
    }
}
