package com.menards.ssc.controller.catalog;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.broadleafcommerce.core.catalog.domain.Category;
import org.broadleafcommerce.core.catalog.domain.CategoryImpl;
import org.broadleafcommerce.core.search.domain.ProductSearchCriteria;
import org.broadleafcommerce.core.search.domain.SearchFacetDTO;
import org.broadleafcommerce.core.search.service.SearchService;
import org.broadleafcommerce.core.web.catalog.CategoryHandlerMapping;
import org.broadleafcommerce.core.web.controller.catalog.BroadleafCategoryController;
import org.broadleafcommerce.core.web.service.SearchFacetDTOService;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;

import com.menards.ssc.domain.cart.SignCartItem;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.catalog.ProductFilter;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.navigation.CategoryTreeNode;
import com.menards.ssc.enums.CategoryType;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.catalog.MenardCatalogService;
import com.menards.ssc.service.catalog.MenardColorSignService;

/**
 *
 * <p>CategoryController</p>
 * <p>An MVC controller implementation for the category navigation, the controller either 
 * returns the sub-categories or the category related products based on whether the requesting 
 * category is a leaf category or not. </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
@Controller("blCategoryController")
public class CategoryController extends BroadleafCategoryController {
	public static final Integer PAGE_SIZE = 8;

	public static final String CATEGORY_LIST_VIEW = "layout/home";
	public static final String PRODUCT_LIST_VIEW = "catalog/productlist";
	public static final String PRODUCT_FILTER_VIEW = "catalog/productFilter";
	public static final String COLOR_SIGN_LIST_VIEW = "catalog/colorsignlist";
	public static final String SELECTED_CATEGORY_ID_SESSION_KEY = "selectedCategoryId";
	public static final String SUB_CATEGORIES_MODEL_KEY = "subCategories";
	public static final String CATEGORY_KEY = "category";
	public static final String PAGE_SUB_TITLE = "pageSubTitle";

	public static final String TEMPLATE = "Desktop_Web_Template";

	private static final String FILTERED = "filtered";
	private static final String PRODUCT_FILTERE = "productFilters";
	private static final String CATEGORY_URL = "categoryUrl";

	public static final String NO_SIGN_VIEW = "catalog/NoSign";
	public static final String NO_SALESIGN_VIEW = "catalog/NoSaleSign";
	private static final String STATIC_SALESIGN_CATEGORY_URL = "/Assortments/Kiosk/UniversalCatalog/SOS/POP/SaleSigns";
	private static final String STATIC_SIGN_CATEGORY_URL = "/Assortments/Kiosk/UniversalCatalog/SOS/POP/MerchSigns";

	@Resource(name = "blCatalogService")
	private MenardCatalogService catalogService;

	@Resource(name = "colorSignService")
	private MenardColorSignService colorSignService;

	/**
	 *
	 * Handle in-coming http request.
	 * @param request request
	 * @param response response
	 * @return ModelAndView ModelAndView
	 */
	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv;
		CategoryTreeNode requestingCategory = getRequestingCategory(request);
		markSelectedCategoryTreeNode(request, requestingCategory);

		// forward to static sign/salesign page if URL matches
		mv = getStaticSignOrSaleSignView(requestingCategory.getUrl());
		if (mv != null) {
			return mv;
		}

		if (requestingCategory.isLeafNode()) { // Only leaf node has products
			String filtered = request.getParameter(FILTERED);
            List<ProductFilter> productFilters = null;
            if (requestingCategory.getCategoryType().equals(CategoryType.SSC_CATEGORY)) {
                productFilters = catalogService.getConfiguredProductFilterByCategoryId(requestingCategory
                        .getCategoryId());
            }
			if (!FILTERED.equalsIgnoreCase(filtered) && productFilters != null && !productFilters.isEmpty()) {
				// Found product filters, get filter options and take user to filters page
				mv = getProductFiltersModelAndView(requestingCategory, productFilters);
			} else {
				// No product filters available for this category
				mv = getProductModelAndView(request, requestingCategory, productFilters);
			}
		} else {
			mv = getCategoryModelAndView(request, requestingCategory);
		}
		addSubTitleToModelAndView(requestingCategory, mv);
		return mv;
	}

	/**
	 * Set Sign/SalesSign category URL
	 * @param url String
	 * @return modelview ModelAndView
	 */
	private ModelAndView getStaticSignOrSaleSignView(String url) {
		ModelAndView mv;
		switch (url) {
			case STATIC_SIGN_CATEGORY_URL:
				mv = new ModelAndView();
				mv.addObject("suppressErrorMessage", true);
				mv.setViewName(NO_SIGN_VIEW);
				break;
			case STATIC_SALESIGN_CATEGORY_URL:
				mv = new ModelAndView();
				mv.addObject("suppressErrorMessage", true);
				mv.setViewName(NO_SALESIGN_VIEW);
				break;
			default:
				mv = null;
		}

		return mv;
	}

	/**
	 * 
	 * Check if the category page is accessible
	 * @param requestingCategory CategoryTreeNode
	 * @param request HttpServletRequest
	 * @return accessible boolean
	 */
	@SuppressWarnings("unchecked")
	private boolean checkIfUnaccessible(CategoryTreeNode requestingCategory, HttpServletRequest request) {
		Set<String> accessiblePages = (Set<String>) request.getSession().getAttribute("unaccessiblePages");
		if (CollectionUtils.isEmpty(accessiblePages)) {
			return false;
		}
		for (String accessiblePage : accessiblePages) {
			if (requestingCategory.getUrl().trim().toLowerCase().startsWith(accessiblePage.toLowerCase().trim())) {
				return true;
			}
		}
		return false;
	}

	/**
	 *
	 * Add subtitle to the ModelAndView object for page rendering.
	 * @param requestingCategory requestingCategory
	 * @param mv mv
	 */
	private void addSubTitleToModelAndView(CategoryTreeNode requestingCategory, ModelAndView mv) {
		if (!requestingCategory.getUrl().equals("/")) {
			mv.addObject(PAGE_SUB_TITLE, StringEscapeUtils.escapeHtml(requestingCategory.getCategoryName()));
		}
	}

	/**
	 * 
	 * Get Requesting Category from the HttpServletRequest which is put previously by the MenardCategoryHandlerMapping
	 * @param request request
	 * @return CategoryTreeNode CategoryTreeNode
	 */
	private CategoryTreeNode getRequestingCategory(HttpServletRequest request) {
		return (CategoryTreeNode) request.getAttribute(CategoryHandlerMapping.CURRENT_CATEGORY_ATTRIBUTE_NAME);
	}

	/**
	 * 
	 * Get the requesting category id and put it into HttpSession under the name of "selectedCategoryId" 
	 * @param request request
	 * @param requestingTreeNode requestingTreeNode
	 */
	private void markSelectedCategoryTreeNode(HttpServletRequest request, CategoryTreeNode requestingTreeNode) {
		request.getSession().setAttribute(SELECTED_CATEGORY_ID_SESSION_KEY, requestingTreeNode.getCategoryId());
	}

	/**
	 * 
	 * build Category
	 * @param requestingCategory requestingCategory
	 * @return Category Category
	 */
	private Category buildCategory(CategoryTreeNode requestingCategory) {
		long categoryId = requestingCategory.getCategoryId();
		Category category = new CategoryImpl();
		category.setId(Math.abs(categoryId));
		return category;
	}

	/**
	 * 
	 * Search Products By Cateogry
	 * @param request request
	 * @param category category
	 * @param productFilters ProductFilter
	 * @return ProductSearchResult
	 */
	private SearchResult<SkuCartItem> searchProductsByCateogry(HttpServletRequest request, Category category,
                                                               List<ProductFilter> productFilters) {
		ProductSearchCriteria searchCriteria = facetService.buildSearchCriteria(request,
				new ArrayList<SearchFacetDTO>());
		Long totalResults = catalogService.countProductForCategory(category, productFilters);
		int offset = (searchCriteria.getPage() - 1) * PAGE_SIZE;
		long categoryId = category.getId();
		int pageSize = PAGE_SIZE.intValue();
		List<SkuCartItem> items = catalogService.findProductDTOsByCategoryId(categoryId, pageSize, offset,
				productFilters);
		SearchResult<SkuCartItem> result = new SearchResult<>();
		result.setResult(items);
		result.setPageSize(PAGE_SIZE);
		result.setPage(searchCriteria.getPage());
		result.setTotalResults(totalResults.intValue());
		return result;
	}

	/**
	 * 
	 * Search Products By Cateogry
	 * @param request request
	 * @param category category
	 * @return ProductSearchResult
	 */
	private SearchResult<SignCartItem> searchSignsByCateogry(HttpServletRequest request, Category category) {
		ProductSearchCriteria searchCriteria = facetService.buildSearchCriteria(request,
				new ArrayList<SearchFacetDTO>());
		Long categoryId = category.getId();
		Long totalResults = colorSignService.countByCatalogID(categoryId);
		int offset = (searchCriteria.getPage() - 1) * PAGE_SIZE;
		int pageSize = PAGE_SIZE.intValue();
		List<SignCartItem> items = colorSignService.getSignsByCatalogID(categoryId.intValue(), (offset + pageSize),
				offset);
		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		if (userDetails.isYard()) {
			Integer storeNumber = Integer.parseInt(userDetails.getStoreNumber());
			for (SignCartItem item : items) {
				int leadTime = 14;
				if(StringUtils.equals(item.getPrintLocation(), "0")){
					leadTime = 21;
				}
				int orderedQuantity = colorSignService.getQuantityOrdered(item.getSignId(), storeNumber,leadTime);
				item.setCanOrder((item.getQuantity() > orderedQuantity));

                if (userDetails.isGOUser() || "GM".equalsIgnoreCase(userDetails.getStorePerformRole())) {
                    item.setCanOrder(true);
                }
			}

		} else {
			for (SignCartItem item : items) {
				item.setCanOrder(true);
			}
		}
		
		SearchResult<SignCartItem> result = new SearchResult<SignCartItem>();
		result.setResult(items);
		result.setPageSize(PAGE_SIZE);
		result.setPage(searchCriteria.getPage());
		result.setTotalResults(totalResults.intValue());
		return result;
	}

	/**
	 * 
	 * Get Product ModelAndView
	 * @param request HttpServletRequest
	 * @param productFilters productFilters
	 * @param requestingCategory the instance of the requesting category
	 * @return ModelAndView ModelAndView
	 */
	private ModelAndView getProductModelAndView(HttpServletRequest request, CategoryTreeNode requestingCategory,
                                                List<ProductFilter> productFilters) {
		ModelAndView mv = new ModelAndView();
		Category category = buildCategory(requestingCategory);
		mv.addObject(CATEGORY_KEY, category);
		CategoryTreeNode requestingCategoryTreeNode = (CategoryTreeNode) request.getAttribute("category");
		if (requestingCategoryTreeNode.getCategoryType() == CategoryType.COLOR_SIGN_CATEGORY) {
			SearchResult<SignCartItem> result = searchSignsByCateogry(request, category);
			mv.addObject(PRODUCTS_ATTRIBUTE_NAME, result.getResult());
			mv.addObject(PRODUCT_SEARCH_RESULT_ATTRIBUTE_NAME, result);
			mv.setViewName(COLOR_SIGN_LIST_VIEW);
		} else {
            List<ProductFilter> assembledProductFilters = assembleProductFilters(request, productFilters);
			SearchResult<SkuCartItem> result = searchProductsByCateogry(request, category, assembledProductFilters);
			List<SkuCartItem> resultList = result.getResult();
			if (resultList.size() == 1 && result.getTotalResults() == 1) {
				// Redirect to product detail page if there is ONLY one element returned AND the total result size is 1
				SkuCartItem product = resultList.get(0);
				mv.setViewName("redirect:/product/" + product.getProductId());
			} else {
				mv.addObject(PRODUCTS_ATTRIBUTE_NAME, resultList);
				mv.addObject(PRODUCT_SEARCH_RESULT_ATTRIBUTE_NAME, result);
				mv.setViewName(PRODUCT_LIST_VIEW);
			}
		}
		return mv;
	}

	/**
	 * 
	 * Get the ModelAndView for showing the categories.
	 * @param requestingCategory requestingCategory
	 * @param request request
	 * @return ModelAndView ModelAndView
	 */
	private ModelAndView getCategoryModelAndView(HttpServletRequest request, CategoryTreeNode requestingCategory) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName(CATEGORY_LIST_VIEW);
		Set<String> unaccessibleCategoryUrls = new HashSet<String>();
		for (CategoryTreeNode category : requestingCategory.getSubCategories()) {
			if (checkIfUnaccessible(category, request)) {
				unaccessibleCategoryUrls.add(category.getUrl());
			}
		}
		mv.addObject(SUB_CATEGORIES_MODEL_KEY, requestingCategory.getSubCategories());
		mv.addObject("accessiblePageUrlList", unaccessibleCategoryUrls);

		return mv;
	}

	/**	
	 * get ProductFilters ModelAndView
	 * @param requestingCategory requestingCategory
	 * @param configuredProductFilters configuredProductFilters
	 * @return ModelAndView ModelAndView
	 */
	private ModelAndView getProductFiltersModelAndView(CategoryTreeNode requestingCategory,
                                                       List<ProductFilter> configuredProductFilters) {
		ModelAndView mv = new ModelAndView(PRODUCT_FILTER_VIEW);
        List<ProductFilter> productFilters = catalogService.getProductFilterOptions(configuredProductFilters);
		mv.addObject(PRODUCT_FILTERE, productFilters);
		mv.addObject(CATEGORY_URL, requestingCategory.getUrl());
		return mv;
	}

	/**
	 * 
	 * assemble Product Filter
	 * @param request request
	 * @param productFilters productFilters
	 * @return ProductFilter ProductFilter
	 */
	private List<ProductFilter> assembleProductFilters(HttpServletRequest request, List<ProductFilter> productFilters) {
		if (productFilters != null && !productFilters.isEmpty()) {
			for (ProductFilter productFilter: productFilters) {
                String attributeValue = request.getParameter(productFilter.getAttributeName());
                if (StringUtils.isNotBlank(attributeValue)) {
                    productFilter.setAttributeValue(attributeValue);
                }
            }
			return productFilters;
		}
		return null;
	}

	/**
	 * 
	 * Set the FacetService object
	 * @param facetService facetService
	 */
	public void setFacetService(SearchFacetDTOService facetService) {
		this.facetService = facetService;
	}

	/**
	 * 
	 * Set the SearchService object
	 * @param searchService searchService
	 */
	public void setSearchService(SearchService searchService) {
		this.searchService = searchService;
	}

	/**
	 * 
	 * Set the CatalogService object
	 * @param catalogService catalogService
	 */
	public void setCatalogService(MenardCatalogService catalogService) {
		this.catalogService = catalogService;
	}

}
