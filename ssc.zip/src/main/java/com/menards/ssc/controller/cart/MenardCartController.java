package com.menards.ssc.controller.cart;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.broadleafcommerce.core.catalog.domain.Category;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.catalog.domain.ProductAttribute;
import org.broadleafcommerce.core.catalog.domain.Sku;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.domain.OrderItem;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.broadleafcommerce.core.web.controller.cart.BroadleafCartController;
import org.broadleafcommerce.core.web.order.CartState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.menards.ssc.config.PropertiesConfig;
import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.constants.OrderItemAttributeKey;
import com.menards.ssc.constants.ProductAttributeKey;
import com.menards.ssc.controller.cart.validator.CartInfoFormValidator;
import com.menards.ssc.controller.cart.validator.PlaceOptionFormValidator;
import com.menards.ssc.controller.catalog.CategoryController;
import com.menards.ssc.domain.cart.AddCartRequest;
import com.menards.ssc.domain.cart.AddSignDTO;
import com.menards.ssc.domain.cart.AddSignRequest;
import com.menards.ssc.domain.cart.CartItem;
import com.menards.ssc.domain.cart.SignCartItem;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.catalog.ColorSignDTO;
import com.menards.ssc.domain.catalog.ImageryDTO;
import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardProductDTO;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.catalog.MenardSkuDTO;
import com.menards.ssc.domain.catalog.SignDTO;
import com.menards.ssc.domain.order.MenardCartinfoDTO;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.order.MenardOrderOptionsDTO;
import com.menards.ssc.enums.MenardDepartment;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardOrderItemType;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.enums.SignSearchType;
import com.menards.ssc.enums.SkuVisibility;
import com.menards.ssc.message.MessageSourceHelper;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.catalog.CategoryTreeService;
import com.menards.ssc.service.catalog.MenardCatalogService;
import com.menards.ssc.service.catalog.MenardColorSignService;
import com.menards.ssc.service.catalog.MenardSignService;
import com.menards.ssc.service.order.MenardOrderItemService;
import com.menards.ssc.service.order.MenardOrderService;
import com.menards.ssc.service.yard.MenardYardService;
import com.menards.ssc.state.MenardGetStatus;
import com.menards.ssc.util.MenardUtil;

/**
 *
 * <p>MenardCartController</p>
 * <p>view,add item, remove item, save cart, place cart</p>
 * <p>
 * view,add item, remove item, save cart, place cart
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Controller("menardCartController")
@RequestMapping("/cart")
public class MenardCartController extends BroadleafCartController {

	public static final Logger LOG = Logger.getLogger(MenardCartController.class);

	public static final String X_REAL_IP = "X-Real-IP";

	public static final String X_FORWARDED_FOR = "X-Forwarded-For";

	/**
	 * cart products page
	 * max length of item comment
	 */
	public static final int ITEM_COMMENT_MAX_LENGTH = 120;
	
	
	protected static String cartRequestAttributeName = "cart";
	protected static final String CART_INFO_VIEW = "/cart/cartinfo";
	protected static final String CART_OPTIONS_VIEW = "/cart/options";
	protected static final String CART_VIEW = "cart/cart";
	protected static final String PLACED_PAGE_REDIRECT = "redirect:/cart/placedpage";
	protected static final String PLACED_VIEW = "/cart/placed";
	protected static final String ORDERS_VIEW = "/cart/orders";
	protected static final String PAGE_SUB_TITLE = "pageSubTitle";
	protected static final String REDIRECT = "redirect:";
	protected static final String BUSINESS_CARD_TITLE_PREFIX = "Title:";
	

	@Resource(name = "menardOrderService")
	private MenardOrderService cartService;

	@Resource(name = "blCatalogService")
	private MenardCatalogService catalogService;

	@Resource(name = "messageSourceHelper")
	private MessageSourceHelper messageSourceHelper;

	@Resource(name = "placeOptionFormValidator")
	private PlaceOptionFormValidator placeOptionFormValidator;

	@Resource(name = "cartInfoFormValidator")
	private CartInfoFormValidator cartInfoFormValidator;

	@Resource(name = "signService")
	private MenardSignService signService;

	@Resource(name = "colorSignService")
	private MenardColorSignService colorSignService;

	@Resource(name = "menardYardService")
	private MenardYardService menardYardService;

	@Resource(name = "menardOrderItemService")
	private MenardOrderItemService menardOrderItemService;

	@Autowired
	private CategoryTreeService categoryTreeService;

	/**
	 * navigate to cart page
	 * @param model model
	 * @param request request
	 * @return String view
	 */
	@RequestMapping("")
	public String getCart(Model model, HttpServletRequest request) {

		List<CartItem> cartItems = new ArrayList<CartItem>();
		
		Order cart = CartState.getCart();
		boolean hasUnavailableItem = false;
		Map<Long, String> removeItems = new HashMap<>();
		Map<Long, String> notOrderableItems = new HashMap<>();
		Map<Long, String> missingDataItems = new HashMap<>();
		Map<Long, String> ultraLimitItems = new HashMap<>();
		BigDecimal subTotalPrice = BigDecimal.ZERO;

		int itemNumber = 1;
		// convert to order item for display
		for (OrderItem orderItem : cart.getOrderItems()) {

			MenardOrderItem menardItem = (MenardOrderItem) orderItem;
			CartItem cartItem;
			if (MenardOrderItemType.SIGN.getCode().equals(menardItem.getItemType())
					|| MenardOrderItemType.SKU_MAN.getCode().equals(menardItem.getItemType())) {
				cartItem = this.getSignCartItem(menardItem);
			} else if (MenardOrderItemType.COLOR_SIGN.getCode().toString().equals(menardItem.getItemType())) {
				cartItem = this.getColorSignCartItem(menardItem);
				if (cartItem.isCanOrder()) {
					BigDecimal totalPrice = new BigDecimal(((SignCartItem) cartItem).getTotalPrice());
					subTotalPrice = subTotalPrice.add(totalPrice);
				}
			} else {
				cartItem = this.getSkuCartItem(menardItem);
			}

			if (itemNumber <= CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT) {
				if (!cartItem.isCanOrder()) {
					removeItems.put(menardItem.getId(), cartItem.getModelNum());
				}

				// Remove items that don't have request type and fulfiller type
				if (!validateFulfillerType(menardItem)) {
					missingDataItems.put(menardItem.getId(), cartItem.getModelNum());
				}

				if (!isGOUser() && (cartItem.getMaxQty() != null && cartItem.getMaxQty() <= 0)) {
					notOrderableItems.put(menardItem.getId(), cartItem.getModelNum());
				}

				if (!hasUnavailableItem && !cartItem.getSkuAvailable()) {
					hasUnavailableItem = true;
				}

				cartItems.add(cartItem);
			} else {
				ultraLimitItems.put(menardItem.getId(), cartItem.getModelNum());
			}

			itemNumber++;
		}
		
		//MCR#137533
		// Limit the number of line items that can be added to the cart to 250.
		// If there are any carts with more than 250 items remove any that are over that amount when that cart is
		// loaded.
		if (ultraLimitItems.size() > 0) {
			Long[] removeOrderItemIds = new Long[ultraLimitItems.size()];
			int index = 0;
			for (Map.Entry<Long, String> entry : ultraLimitItems.entrySet()) {
				removeOrderItemIds[index++] = entry.getKey();
			}
			cartService.removeItems(CartState.getCart(), removeOrderItemIds);
			model.addAttribute("errorMsg", messageSourceHelper.getMessage("cart.auto.remove.item.over.limit",new Integer[] { CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT }, ""));
		}

		model.addAttribute("subTotalPrice", subTotalPrice.toString());
		model.addAttribute("cartItems", cartItems);
		model.addAttribute("removeItems", removeItems);
		model.addAttribute("missingDataItems", missingDataItems);
		model.addAttribute("notOrderableItems", notOrderableItems);
		model.addAttribute("itemCount", cart.getItemCount());
		model.addAttribute(PAGE_SUB_TITLE, "Cart");
		model.addAttribute("showPlaceOrderButton", showPlaceOrderButton(cart, request));
		model.addAttribute("showSaveOrderButton", isGOUser());
		model.addAttribute("showSubTotalPrice", isGOUser());
		model.addAttribute("hasUnavailableItem", hasUnavailableItem);
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		model.addAttribute("currentUser", user);
		return getCartView();
	}

	/**
	 * get Sku Cart Item
	 * @param menardItem menardItem
	 * @return SkuCartItem SkuCartItem
	 */
	private SkuCartItem getSkuCartItem(MenardOrderItem menardItem) {
		MenardProduct product = (MenardProduct) menardItem.getProduct();
		MenardSku sku = (MenardSku) menardItem.getSku();
		boolean skuAvailable = true;
		if (!product.isActive() || !sku.isActive()) {
			skuAvailable = false;
		}

		SkuCartItem cartItem = new SkuCartItem();
		cartItem.setSkuAvailable(skuAvailable);
		cartItem.setOrderItemId(menardItem.getId());
		cartItem.setSkuId(sku.getId());
		cartItem.setProductId(product.getId());
		cartItem.setQuantity(menardItem.getQuantity());
		cartItem.setComment(menardItem.getNotes());

		MenardProductDTO menardProductDto = new MenardProductDTO(product, sku);
		cartItem.setProductImgUrl(menardProductDto.getProductImgUrl());
		cartItem.setSeriesNumber(menardProductDto.getSeriesNumber());
		cartItem.setModelNum(menardProductDto.getModelNum());
		cartItem.setSkuNum(menardProductDto.getSkuNum());
		cartItem.setColor(menardProductDto.getColor());
		cartItem.setVendorSize(menardProductDto.getVendorSize());
		cartItem.setLeadTimeMsg(menardProductDto.getLeadTimeMsg());
		cartItem.setDescriptionShort(menardProductDto.getDescriptionShort());
		cartItem.setVendorName(menardProductDto.getVendorName());
		cartItem.setMinQty(menardProductDto.getMinQty());
		cartItem.setIncrementQty(menardProductDto.getIncrementQty());
		cartItem.setMaxQty(menardProductDto.getMaxQty());
		String uom = menardProductDto.getUOM();
		if (!"foot".equals(uom) && !"sqft".equals(uom) && !menardProductDto.getFlagLockQuantity()) {
			cartItem.setQuantityEditable(true);
		} else {
			cartItem.setQuantityEditable(false);
		}
		if (menardProductDto.isBusinessCard() || menardProductDto.isWelcomeSign()) {
			cartItem.setCommentEditable(false);
		} else {
			cartItem.setCommentEditable(true);
		}
		cartItem.setType(MenardOrderItemType.SKU.getCode().toString());

		cartItem.setBusinessCard(menardProductDto.isBusinessCard());
		MenardSkuDTO skuDTO = catalogService.getSkuDTO(sku);
		cartItem.setSkuVisibilityCode(MenardGetStatus.getSkuVisibility(skuDTO).getCode());

		return cartItem;
	}

	/**
	* get sign Cart Item
	* @param menardItem menardItem
	* @return SignCartItem SignCartItem
	*/
	private SignCartItem getSignCartItem(MenardOrderItem menardItem) {
		SignCartItem cartItem = new SignCartItem();
		cartItem.setOrderItemId(menardItem.getId());
		cartItem.setSignId(menardItem.getSignId());
		cartItem.setYardNum(menardItem.getSignYardNum());
		cartItem.setQuantity(menardItem.getQuantity());
		cartItem.setComment(menardItem.getNotes());
		SignDTO sign = null;
		String skuNum = "900-0001";
		if (MenardOrderItemType.SIGN.getCode().equals(menardItem.getItemType())) {
			String promNbrStr = menardOrderItemService.getOrderItemAttrValue(menardItem,
					OrderItemAttributeKey.SALE_SIGN_PRO_NBR);
			Integer promNbr = 0;
			if (StringUtils.isNotBlank(promNbrStr)) {
				promNbr = Integer.valueOf(promNbrStr);
			}
			sign = signService.findSign(cartItem.getSignId(), Integer.valueOf(cartItem.getYardNum()),
					SignSearchType.Cart, promNbr, menardItem.getItemType());
			cartItem.setType(MenardOrderItemType.SIGN.getCode().toString());
			if (sign != null) {
				cartItem.setMaxQty(sign.getOrderableQuantity());
			}
		} else {
			sign = signService
					.findPrePrintedFactTagDetail(cartItem.getSignId(), Integer.valueOf(cartItem.getYardNum()));
			// Here sign name is the same as sign id
			if (sign != null) {
				String signName = sign.getSignVersion().getSignname();
				String email = StringUtils.EMPTY;
				String debug = PropertiesConfig.getValue("debug");
				if (Boolean.parseBoolean(debug)) {
					email = PropertiesConfig.getValue("debugEmail");
				} else {
					email = PropertiesConfig.getValue(signName);
				}
				if (StringUtils.isNotBlank(email)) {
					skuNum = StringUtils.substring(signName, 0, 3) + CommonConstant.MINUS
							+ StringUtils.substring(signName, 3, 100);
				}
			}
			cartItem.setMaxQty(1);
			cartItem.setType(MenardOrderItemType.SKU_MAN.getCode().toString());
		}
		cartItem.setSkuNum(skuNum);
		if (sign == null) {
			cartItem.setCanOrder(false);
			return cartItem;
		}
		ImageryDTO img = null;
		if (sign.getProductImgList() != null && sign.getProductImgList().size() > 0) {
			img = sign.getProductImgList().get(0);
		}
		cartItem.setProductImgUrl(img == null ? null : img.getBig());
		cartItem.setSeriesNumber(sign.getSeriesNumber());
		cartItem.setModelNum(sign.getModelNum());
		cartItem.setDescriptionShort(sign.getDescriptionShort());
		cartItem.setCommentEditable(true);
		cartItem.setVendorSize(sign.getSize());

		cartItem.setColor(sign.getColor());

		if (!sign.isCanOrder() && !StringUtils.equals(MenardOrderItemType.SKU_MAN.getCode(), cartItem.getType())) {
			cartItem.setCanOrder(false);
		}
		String leadTimeMsg = StringUtils.EMPTY;
		if (sign.getShowShipmentDays()) {
			leadTimeMsg = sign.getShipmentMsg();
		} else {
			leadTimeMsg = "This sign will print shortly after the order is placed.";
		}
		cartItem.setLeadTimeMsg(leadTimeMsg);

		cartItem.setMinQty(1);
		cartItem.setIncrementQty(1);
		return cartItem;
	}

	/**
	* get sign Cart Item
	* @param menardItem menardItem
	* @return SignCartItem SignCartItem
	*/
	private SignCartItem getColorSignCartItem(MenardOrderItem menardItem) {
		SignCartItem cartItem = new SignCartItem();
		cartItem.setOrderItemId(menardItem.getId());
		cartItem.setSignId(menardItem.getSignId());
		cartItem.setYardNum(menardItem.getSignYardNum());
		cartItem.setQuantity(menardItem.getQuantity());
		cartItem.setComment(menardItem.getNotes());
		ColorSignDTO colorSign = colorSignService.getSign(cartItem.getSignId().toString(),
				Integer.valueOf(cartItem.getYardNum()), SignSearchType.Cart);
		if (colorSign == null) {
			cartItem.setCanOrder(false);
			return cartItem;
		}
		ImageryDTO img = colorSign.getProductImgList().get(0);
		cartItem.setProductImgUrl(img == null ? null : img.getBig());
		cartItem.setSeriesNumber(colorSign.getSeriesNumber());
		cartItem.setModelNum(colorSign.getModelNum());
		cartItem.setDescriptionShort(colorSign.getDescriptionShort());
		cartItem.setCommentEditable(true);
		cartItem.setVendorSize(colorSign.getSize());
		cartItem.setSkuNum("900-0001");
//		cartItem.setColor(colorSign.getColor());
		String unitPrice = colorSign.getUnitPrice();
		cartItem.setUnitPrice(unitPrice);
		BigDecimal unitPriceBg = new BigDecimal(unitPrice);
		cartItem.setTotalPrice(unitPriceBg.multiply(new BigDecimal(menardItem.getQuantity())).toString());

		cartItem.setType(MenardOrderItemType.COLOR_SIGN.getCode().toString());
		if (!colorSign.isCanOrder()) {
			cartItem.setCanOrder(false);
		}

		cartItem.setLeadTimeMsg(colorSign.getShipmentMsg());

		cartItem.setMinQty(1);
		cartItem.setIncrementQty(1);
		cartItem.setMaxQty(colorSign.getOrderableQuantity());

		return cartItem;
	}

	/**
	 * show place order button
	 * @param cart Order
	 * @param request request
	 * @return boolean place able
	 */
	private boolean showPlaceOrderButton(Order cart, HttpServletRequest request) {
		return cart.getItemCount() > 0 && availableIp(request) && (isGOUser() || availableSku(cart));
	}

	/**
	 * get ip
	 * @param request request
	 * @return ip available
	 */
	private boolean availableIp(HttpServletRequest request) {
		String ip = getIp(request);
		if (StringUtils.isEmpty(ip)) {
			return true;
		}
		String[] sets = ip.split("\\.");
		if (ArrayUtils.isEmpty(sets)) {
			return true;
		}
		return !"92".equals(sets[0]);
	}

	/**
	 * get ip from request
	 * @param request request
	 * @return ip ip
	 */
	private String getIp(HttpServletRequest request) {
		String remoteIp = request.getHeader(X_REAL_IP); // nginx proxy
		if (StringUtils.isNotEmpty(remoteIp)) {
			return remoteIp;
		}

		remoteIp = request.getHeader(X_FORWARDED_FOR); // apache proxy
		if (StringUtils.isNotEmpty(remoteIp)) {
			String[] ips = remoteIp.split(",");
			for (String ip : ips) {
				if (!"null".equalsIgnoreCase(ip)) {
					return ip;
				}
			}
		}
		return request.getRemoteAddr();

	}

	/**
	 * check if sku available
	 * @param cart order
	 * @return available  available
	 */
	private boolean availableSku(Order cart) {
		for (OrderItem orderItem : cart.getOrderItems()) {
			MenardOrderItem item = (MenardOrderItem) orderItem;
			if (MenardOrderItemType.SKU.getCode().toString().equals(item.getItemType())) {
				MenardSkuDTO skuDTO = catalogService.getSkuDTO((MenardSku) item.getSku());
				if (SkuVisibility.SPECIAL_ORDER.equals(skuDTO.getSkuVisibility())
						|| SkuVisibility.STOCK_ORDERABLE.equals(skuDTO.getSkuVisibility())) {
					return true;
				}
			} else {
				return true;
			}
		}

		return false;
	}

	/**
	 * is go user
	 * @return boolean boolean
	 */
	private boolean isGOUser() {
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		return user.isGOUser();
	}

	/**
	 * add skus to cart
	 * @param request AddCartRequest
	 * @return String view\
	 * @throws ItemNotFoundException not found
	 */
	@RequestMapping(value = "/addskus", produces = { "text/html", "*/*" })
	public String addItems(@Valid AddCartRequest request,HttpServletRequest httpReq) throws ItemNotFoundException {

		int itemCount = this.getCartItemCount(httpReq);
		if(itemCount>CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT){
			throw new RuntimeException( messageSourceHelper.getMessage("cart.add.item.reach.max.limit",new Integer[] { CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT }, ""));
		}	
		
		dealAccessories(request);

		boolean isItemInfoValid = true;
		if (request.getMainSku().isBusinessCard()) {
			isItemInfoValid = validateBusinessCardCustomization(request);
		}

		if (isItemInfoValid) {
			cartService.addItems2Cart(CartState.getCart(), request);
		}

		String retUrl = getCartPageRedirect();
		if (request.getMainSku().getCategoryId() != null) {
			Category category = catalogService.findCategoryById(request.getMainSku().getCategoryId());
			retUrl = REDIRECT + category.getUrl();
		}
		return retUrl;
	}

	/**
	 * 
	 * Title is requred for a business card, name is optional
	 * @param request AddCartRequest
	 * @return hasTitle boolean
	 */
	private boolean validateBusinessCardCustomization(AddCartRequest request) {
		String comment = request.getMainSku().getComment();
		return StringUtils.isNotBlank(comment) && StringUtils.containsIgnoreCase(comment, BUSINESS_CARD_TITLE_PREFIX);
	}

	/**
	 * any product of option accessories without skuId means
	 * that product was not selected
	 * @param request request
	 */
	private void dealAccessories(AddCartRequest request) {
		dealAccessories(request.getOptionSkus());
		dealAccessories(request.getRequireSkus());
	}

	/**
	 * any product of option accessories without skuId means
	 * that product was not selected
	 * @param skus skus
	 */
	private void dealAccessories(List<SkuCartItem> skus) {
		if (CollectionUtils.isNotEmpty(skus)) {
			List<SkuCartItem> unselectedOption = new ArrayList<SkuCartItem>();
			for (SkuCartItem item : skus) {
				if (item.getSkuId() == null) {
					unselectedOption.add(item);
				} else {
					Sku sku = catalogService.findSkuById(item.getSkuId());
					MenardSkuDTO skuDTO = new MenardSkuDTO((MenardSku) sku);
					item.setQuantity((skuDTO.getQuantity() == 0) ? 1 : skuDTO.getQuantity());
				}
			}
			skus.removeAll(unselectedOption);
		}
	}

	/**
	 * add sku to cart
	 * @param cartItem SkuCartItem
	 * @return String view
	 * @throws ItemNotFoundException not found
	 */
	@RequestMapping(value = "/addSku", produces = { "text/html", "*/*" })
	public String addItem(@Valid SkuCartItem cartItem,HttpServletRequest request) throws ItemNotFoundException {
		int itemCount = this.getCartItemCount(request);
		if(itemCount>=CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT){
			throw new RuntimeException( messageSourceHelper.getMessage("cart.add.item.reach.max.limit",new Integer[] { CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT }, ""));
		}		
		
		cartService.addItem(CartState.getCart(), cartItem);

		String retUrl = getCartPageRedirect();
		if (cartItem.getCategoryId() != null) {
			Category category = catalogService.findCategoryById(cartItem.getCategoryId());
			retUrl = REDIRECT + category.getUrl();
		}
		return retUrl;
	}

	/**
	 * add sku to cart
	 * @param cartItem SkuCartItem
	 * @return String view
	 * @throws ItemNotFoundException not found
	 */
	@RequestMapping(value = "/addSkuAjax", produces = { "text/plain" })
	@ResponseBody
	public String addSkuAjax(@Valid SkuCartItem cartItem,HttpServletRequest request) throws ItemNotFoundException {
		int itemCount = this.getCartItemCount(request);
		if(itemCount>=CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT){
			throw new RuntimeException( messageSourceHelper.getMessage("cart.add.item.reach.max.limit",new Integer[] { CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT }, ""));
		}	
		cartService.addItem(CartState.getCart(), cartItem);
		return "200";
	}

	/**
	 * add sign to cart
	 * @param cartItem SignCartItem
	 * @return String view
	 * @throws ItemNotFoundException not found
	 */
	@RequestMapping(value = "/addSignAjax", produces = { "text/plain" })
	@ResponseBody
	public String addSignAjax(@Valid SignCartItem cartItem,HttpServletRequest request) throws ItemNotFoundException {
		int itemCount = this.getCartItemCount(request);
		if(itemCount>=CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT){
			throw new RuntimeException( messageSourceHelper.getMessage("cart.add.item.reach.max.limit",new Integer[] { CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT }, ""));
		}	
			
		cartService.addSign2Cart(CartState.getCart(), cartItem);
		
		return "200";
	}

	/**
	 * add sign to cart
	 * @param cartItem cartItem
	 * @return String view
	 * @throws ItemNotFoundException not found
	 */
	@RequestMapping(value = "/addSign")
	public String addSign(@Valid SignCartItem cartItem,HttpServletRequest httpReq) throws ItemNotFoundException {
		int itemCount = this.getCartItemCount(httpReq);
		if(itemCount>=CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT){
			throw new RuntimeException( messageSourceHelper.getMessage("cart.add.item.reach.max.limit",new Integer[] { CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT }, ""));
		}	
		
		cartService.addSign2Cart(CartState.getCart(), cartItem);

		String retUrl = getCartPageRedirect();
		// if (cartItem.getCategoryId() != null) {
		// Category category = catalogService.findCategoryById(cartItem.getCategoryId());
		// retUrl = REDIRECT + category.getUrl();
		// }
		return retUrl;
	}

	/**
	 * Add sign, skuman and colorsign to cart.
	 * item types for them are 2,5 and 3.  
	 * 
	 * add sign to cart
	 * @param signRequest signRequest
	 * @return String view
	 * @throws ItemNotFoundException not found
	 */
	@RequestMapping(value = "/addSigns", produces = { "text/html", "*/*" })
	public String addSigns(AddSignRequest signRequest,HttpServletRequest httpReq) throws ItemNotFoundException {
		int itemCount = this.getCartItemCount(httpReq);
		if(itemCount>CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT){
			throw new RuntimeException( messageSourceHelper.getMessage("cart.add.item.reach.max.limit",new Integer[] { CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT }, ""));
		}	
		
		List<SignCartItem> list = new ArrayList<SignCartItem>();
		for (AddSignDTO dto : signRequest.getSignItems()) {
			if (dto == null || dto.getSignId() == null || StringUtils.isBlank(dto.getType())) {
				continue;
			}
			list.add(new SignCartItem(dto));
		}

		cartService.addSigns2Cart(CartState.getCart(), list);

		String retUrl = getCartPageRedirect();
		// if (cartItem.getCategoryId() != null) {
		// Category category = catalogService.findCategoryById(cartItem.getCategoryId());
		// retUrl = REDIRECT + category.getUrl();
		// }
		return retUrl;
	}

	/**
	 * save order items's quantity and quantity
	 *
	 * @param model model
	 * @param requestDto dto AddCartRequest
	 * @param result BindingResult
	 * @return String return page
	 * @throws ItemNotFoundException not found
	 */
	@RequestMapping("/update")
	public String update(Model model, AddCartRequest requestDto, BindingResult result, HttpServletRequest request)
			throws ItemNotFoundException {

		if (LOG.isDebugEnabled()) {
			LOG.debug("navigation : " + requestDto.getNavigation());
			LOG.debug("cartItems size : " + requestDto.getCartItems().size());
		}

		Order cart = CartState.getCart();
		String navigation = requestDto.getNavigation();
		String url = navigation;
		// the cart is empty, no item in cart
		if (CollectionUtils.isEmpty(requestDto.getCartItems())) {
			if (navigation.startsWith("continueShopping")) {
				url = "/";
			}
			return REDIRECT + url;
		}

		// enter in textarea
		if (navigation == null || navigation.trim().length() == 0) {
			cartService.updateOrderItems(cart, requestDto.getCartItems());
			url = "/cart";
			return REDIRECT + url;
		}

		if (!navigation.startsWith("edit:") && !navigation.startsWith("remove:")) {
			// only validate form when update quantity. No need to validate when removing items
			Map<String, String> errorMsg = validateUpdateCartItems(requestDto.getCartItems());
			if (!errorMsg.isEmpty()) {
				model.addAttribute("errors", errorMsg);
				return getCartView();
			}
		}

		if (navigation.startsWith("edit:") || navigation.startsWith("remove:")) {
			// navigation = edit:0000;/xxx/xxx/xxx
			Long removeItemId = Long
					.valueOf(navigation.substring(navigation.indexOf(':') + 1, navigation.indexOf(';')));
			cartService.updateOrderItems(removeItemId, cart, requestDto.getCartItems());
			url = navigation.substring(navigation.lastIndexOf(';') + 1);
			return REDIRECT + url;
		}

		cart = cartService.updateOrderItems(cart, requestDto.getCartItems());
		if (navigation.startsWith("continueShopping")) {
			// When Continue Shopping is selected in the cart
			// the user should be returned to the same page they were at in the category
			// If not category has been selected or accessed by user by the time user clicks this button,
			// take user to home page
			String selectedCategoryId = request.getSession()
					.getAttribute(CategoryController.SELECTED_CATEGORY_ID_SESSION_KEY).toString();
			url = "/";
			String csUrl = findContinueShoppingUrlFromRequestHistory();
			if (csUrl != null) {
				url = csUrl;
			} else if (!StringUtils.isBlank(selectedCategoryId)) {
				long categoryId = Long.valueOf(selectedCategoryId);
				Category selectedCategory = catalogService.findCategoryById(categoryId);
				if (selectedCategory != null) {
					url = selectedCategory.getUrl();
				}
			}
			return "redirect:" + url;
		}

		return REDIRECT + url;
	}

	private String findContinueShoppingUrlFromRequestHistory() {
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		Deque<String> requestHistory = user.getRequestHistory();
		String[] historyArray = new String[requestHistory.size()];
		requestHistory.toArray(historyArray);
		if (historyArray != null && historyArray.length > 0) {
			for (String history : historyArray) {
				if (history.startsWith("GET")) {
					// category URLs and search queries are GET request
					String url = getUrl(history);
					if (url.startsWith("/Assortments") || url.startsWith("/COLOR_SIGN") || url.startsWith("/search")) {
						return url;
					}
				}

			}
		}
		return null;
	}

	/**
	 * Get url from history string
	 * e.g. "GET|/cart"
	 *      "POST|/cart/options"
	 * @param history
	 * @return
	 */
	private String getUrl(String history) {
		String[] tokens = history.split("\\|");
		if (tokens != null && tokens.length == 2) {
			return tokens[1];
		}
		return null;
	}

	/**
	 * 
	 * remove Items
	 * @param requestDto requestDto
	 * @return String String
	 * @throws ItemNotFoundException ItemNotFoundException
	 */
	@RequestMapping("/removeitems")
	public String removeItems(AddCartRequest requestDto) throws ItemNotFoundException {
		List<SkuCartItem> removeItems = requestDto.getCartItems();
		Long[] removeOrderItemIds = new Long[removeItems.size()];
		int index = 0;
		for (SkuCartItem item : removeItems) {
			removeOrderItemIds[index++] = item.getOrderItemId();
		}
		cartService.removeItems(CartState.getCart(), removeOrderItemIds);
		return REDIRECT + "/cart";
	}

	/**
	 * validate
	 * @param cartItems List<CartItem>
	 * @return Map<String, String> error
	 */
	private Map<String, String> validateUpdateCartItems(List<SkuCartItem> cartItems) {
		Map<String, String> errmsg = new HashMap<String, String>();
		for (SkuCartItem item : cartItems) {
			if (item.getOrderItemId() == null) {
				errmsg.put("orderItemId", messageSourceHelper.getMessage("cart.item.orderitemid.required", null, ""));
			}

			if (item.getQuantity() == null) {
				errmsg.put("quantity", messageSourceHelper.getMessage("cart.item.quantity.error", null, ""));
			}

			if (MenardOrderItemType.SKU.getCode().toString().equals(item.getType())) {
				if (item.getSkuId() == null) {
					errmsg.put("skuId", messageSourceHelper.getMessage("cart.item.skuid.requried", null, ""));
				}

				if (item.getProductId() == null) {
					errmsg.put("productId", messageSourceHelper.getMessage("cart.item.productId.requried", null, ""));
				}
			}

			if (StringUtils.isNotEmpty(item.getComment()) && item.getComment().length() > 120) {
				errmsg.put("comment", messageSourceHelper.getMessage("cart.item.comment.maxlength",
						new Integer[] { ITEM_COMMENT_MAX_LENGTH }, ""));
			}
		}
		return errmsg;
	}

	/**
	 *
	 * navigate to cart info page
	 * @param cartinfoDTO MenardCartinfoDTO
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/information", method = RequestMethod.GET)
	public ModelAndView navigateToCartInfo(@ModelAttribute("cartinfoDTO") MenardCartinfoDTO cartinfoDTO) {
		Order cart = CartState.getCart();
		cartinfoDTO.setListName(((MenardOrder) cart).getListName());
		cartinfoDTO.setComment(((MenardOrder) cart).getCommentSaved());
		ModelAndView mv = new ModelAndView();
		mv.setViewName(CART_INFO_VIEW);
		mv.addObject(PAGE_SUB_TITLE, "Save Cart");
		return mv;
	}

	/**
	 * save card info, list name and comment
	 * @param cartinfoDTO MenardCartinfoDTO
	 * @param result BindingResult
	 * @return String
	 */
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveOrder(@ModelAttribute("cartinfoDTO") MenardCartinfoDTO cartinfoDTO, BindingResult result) {

		cartInfoFormValidator.validate(cartinfoDTO, result);
		if (result.hasErrors()) {
			return CART_INFO_VIEW;
		}

		Order cart = CartState.getCart();
		if (cart.getItemCount() != 0) {
			cartService.saveMenardOrder(cart, cartinfoDTO);
		}
		return this.getCartPageRedirect();
	}

	/**
	 *
	 * navigate to order option page
	 * @param orderOptionsDTO MenardOrderOptionsDTO only for validator
	 * @param errorMsg errorMsg
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/options", method = RequestMethod.GET)
	public ModelAndView naviagteToOrderOptions(
			@ModelAttribute("orderOptionsDTO") MenardOrderOptionsDTO orderOptionsDTO,
			@RequestParam(value = "errorMsg", required = false) String errorMsg) {

		MenardOrder cart = (MenardOrder) CartState.getCart();
		for (OrderItem orderItem : cart.getOrderItems()) {
			MenardOrderItem menardOrderItem = (MenardOrderItem) orderItem;
			menardOrderItemService.populateFulfillerTypeForOrderItem(menardOrderItem);
		}

		ModelAndView mv = new ModelAndView();
		mv.addObject("stores", menardYardService.getYardNameList());
		mv.addObject("depts", MenardDepartment.values());
		mv.addObject(PAGE_SUB_TITLE, "Place Order");
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		mv.addObject("isYard", user.isYard());
		mv.addObject("isStorePlanning", isStorePlanning());
		mv.addObject("user", user);
		mv.addObject("errorMsg", errorMsg);
		mv.setViewName(CART_OPTIONS_VIEW);
		return mv;
	}

	/**
	 * validate requestType and fulfillerType on order item
	 * @param menardOrderItem
	 * @return true if both requestType and fulfillerType are found and not blank
	 *         false if either requestType or fulfillerType are not found or blank
	 */
	private boolean validateFulfillerType(MenardOrderItem menardOrderItem) {
		return menardOrderItemService.validateFulfillerType(menardOrderItem);
	}

	/**
	 * check is store planning
	 * @return boolean boolean
	 */
	private boolean isStorePlanning() {
		Order cart = CartState.getCart();
		for (OrderItem item : cart.getOrderItems()) {
			MenardOrderItem discrete = (MenardOrderItem) item;
			String fulfillerType = "";
			if (MenardOrderItemType.SKU.getCode().toString().equals(discrete.getItemType())) {
				// fulfillerType = this.getSkuAttr(discrete.getSku(), SkuAttributeKey.FULFILLER_TYPE);
				fulfillerType = this.getProductAttr(discrete.getProduct(), ProductAttributeKey.FULFILLER_TYPE);
				if (StringUtils.isBlank(fulfillerType)) {
					String requestType = this.getProductAttr(discrete.getProduct(), ProductAttributeKey.REQUEST_TYPE);
					if (StringUtils.isNotEmpty(requestType)) {
						MenardFulfillerType fulfillerTypeEnum = MenardOrderRequestType
								.getFulfillerByRequestType(requestType);
						if (fulfillerTypeEnum != null) {
							fulfillerType = fulfillerTypeEnum.getKey();
						}
					}
				} else {
					fulfillerType = String.valueOf(fulfillerType.charAt(0));
				}
			} else if (MenardOrderItemType.SIGN.getCode().toString().equals(discrete.getItemType())
					|| MenardOrderItemType.COLOR_SIGN.getCode().toString().equals(discrete.getItemType())) {
				// Sign and colorsign
				fulfillerType = discrete.getFulfillerTypeCode();
			}

			if (MenardFulfillerType.STORE_PLANNING.getKey().equals(fulfillerType)
					|| MenardFulfillerType.SIGN_SHOP.getKey().equals(fulfillerType)) {
				return true;
			}
		}

		return false;
	}

	/**
	 * get product attribute
	 * @param product product
	 * @param key key
	 * @return string string
	 */
	private String getProductAttr(Product product, String key) {
		ProductAttribute attr = product.getProductAttributes().get(MenardUtil.getMappingKey(key));
		if (attr != null) {
			return attr.getValue();
		}
		return null;
	}

	/**
	 *
	 * place order
	 * @param model Model
	 * @param orderOptionsDTO MenardOrderOptionsDTO
	 * @param result BindingResult
	 * @param redirectAttributes redirectAttributes
	 * @return String
	 */
	@RequestMapping(value = "/place", method = RequestMethod.POST)
	public String placeOrder(Model model, @ModelAttribute("orderOptionsDTO") MenardOrderOptionsDTO orderOptionsDTO,
			BindingResult result, RedirectAttributes redirectAttributes) {
		placeOptionFormValidator.validate(orderOptionsDTO, result);
		if (result.hasErrors()) {
			model.addAttribute("stores", menardYardService.getYardNameList());
			model.addAttribute("depts", MenardDepartment.values());
			return CART_OPTIONS_VIEW;
		}

		MenardOrder cart = (MenardOrder) CartState.getCart();
		for (OrderItem item : cart.getOrderItems()) {
			MenardOrderItem discrete = (MenardOrderItem) item;
			if (MenardOrderItemType.SKU.getCode().equals(discrete.getItemType())) {
				Product p = discrete.getProduct();
				Sku sku = discrete.getSku();
				if (!p.isActive() || !sku.isActive()) {
					redirectAttributes.addAttribute("errorMsg",
							"One or more order items are unavailable, Please remove from cart.");
					return "redirect:/cart/options";
				}
			}
		}
		cart = buildMenardOrder(cart, orderOptionsDTO);

		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		List<String> storeIds = orderOptionsDTO.getStoreIds();
		if (user.isYard()) {
			storeIds.clear();
			storeIds.add(user.getStoreNumber());
		}

		cartService.placedOrder(cart, storeIds);

		return PLACED_PAGE_REDIRECT;
	}

	/**
	 *
	 * build manard order according parameters
	 * @param cart Order
	 * @param orderOptionsDTO MenardOrderOptionsDTO
	 * @return MenardOrder
	 */
	private MenardOrder buildMenardOrder(MenardOrder cart, MenardOrderOptionsDTO orderOptionsDTO) {
		cart.setDueDate(orderOptionsDTO.getDueDate());
		cart.setCommentPlaced(orderOptionsDTO.getComment());
		cart.setOrderType(orderOptionsDTO.getOrderType());
		cart.setGrouping(orderOptionsDTO.getGroup());
		cart.setDeptId(orderOptionsDTO.getDeptId());
		cart.setRequestBy(orderOptionsDTO.getRequestBy());
		cart.setOrderCode(orderOptionsDTO.getOrderCode());
		return cart;
	}

	/**
	 *
	 * navigate to placedpage
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/placedpage", method = RequestMethod.GET)
	public ModelAndView naviagteToPlacedpage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName(PLACED_VIEW);
		return mv;
	}

	/**
	 * saved quotes
	 *
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/orders", method = RequestMethod.GET)
	public ModelAndView getOrders(HttpServletRequest request) {
		List<MenardOrder> menardOrders = cartService.findMenardOrderByStatus(OrderStatus.NAMED);
		ModelAndView mv = new ModelAndView();
		mv.setViewName(ORDERS_VIEW);
		mv.addObject("orders", menardOrders);
		mv.addObject(PAGE_SUB_TITLE, "Saved Carts");
		categoryTreeService.clearBreadCrumb(request);

		return mv;
	}

	/**
	 * get order
	 * replace cart with order
	 * @param orderId Long
	 * @return String
	 */
	@RequestMapping(value = "/order", method = RequestMethod.POST)
	public String replaceOrder(Long orderId) {
		Order cart = CartState.getCart();
		cartService.replaceCart(cart, orderId);
		return this.getCartPageRedirect();
	}

	/**
	 *
	 * delete order
	 * @param orderId Long
	 * @return String
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public String delete(Long orderId) {
		Order order = cartService.getOrderById(orderId);
		cartService.deleteOrder(order);
		return REDIRECT + "/cart/orders";
	}
	
	
	
	private int getCartItemCount(HttpServletRequest request){
		int cartItemCount = 0;
		Order cart = (Order)request.getAttribute(cartRequestAttributeName);
		if(null!=cart){
			cartItemCount = cart.getOrderItems().size();
		}
		
		return cartItemCount;
		
		//model.addAttribute("errorMsg", messageSourceHelper.getMessage("cart.add.item.reach.max.limit",new Integer[] { CommonConstant.CART_ITEM_NUMBER_MAX_LIMIT }, ""));
		
	}

}
