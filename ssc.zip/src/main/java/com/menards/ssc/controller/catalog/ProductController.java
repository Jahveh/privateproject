package com.menards.ssc.controller.catalog;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.broadleafcommerce.core.catalog.domain.CategoryProductXref;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.broadleafcommerce.core.web.controller.catalog.BroadleafProductController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.menards.ssc.domain.catalog.MenardProductDTO;
import com.menards.ssc.domain.catalog.ProductDetailDTO;
import com.menards.ssc.domain.catalog.SearchCriteria;
import com.menards.ssc.service.catalog.CategoryTreeService;
import com.menards.ssc.service.catalog.MenardCatalogService;

/**
 *
 * <p>ProductController</p>
 * <p>product controller</p>
 * <p>
 * This class works in combination with the CategoryHandlerMapping which finds a category based upon
 * the passed in URL.
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Controller("blProductController")
@RequestMapping("/product")
public class ProductController extends BroadleafProductController {

	private static final String MODEL_ATTRIBUTE_NAME = "productDTO";
	private static final String PRODUCT_LIST_PAGE = "productList";
	private static final String MONTHLY_INVENTORY_REPORT_CATEGORY_URL = "/inventory/getInvQuantityOnHand";
	private static final String MONTHLY_INVENTORY_REPORT_CATEGORY_NAME = "Monthly Inventory Report";

	@Autowired
	private CategoryTreeService categoryTreeService;
	
	@Resource(name = "blCatalogService")
	private MenardCatalogService catalogService;

	/**
	 * find product by id, if sku id is passed, set the sku as selected sku of the product
	 * @param productId productId
	 * @param skuId skuId
	 * @param from String
	 * @param model model
	 * @param setDefaultSku setDefaultSku
	 * @param criteria SearchCriteria
	 * @param request HttpRequest
	 * @return string view
	 * @throws ItemNotFoundException product not found
	 */
	@RequestMapping(value = "/{productId}", produces = { "text/html", "*/*" })
	public String productDetail(@PathVariable("productId") Long productId,
			@RequestParam(value = "skuId", required = false) Long skuId,
			@RequestParam(value = "setDefaultSku", required = false) Boolean setDefaultSku,
			@RequestParam(value = "from", required = false) String from, Model model, SearchCriteria criteria,
			HttpServletRequest request) throws ItemNotFoundException {
		ProductDetailDTO productDTO = catalogService.getMenardProductDetail(productId, skuId, setDefaultSku);
		if (productDTO == null) {
			return "catalog/productnotfound";
		}

		model.addAttribute(MODEL_ATTRIBUTE_NAME, productDTO);
		model.addAttribute("criteria", criteria);

		// respect the selectedCategoryId in session, don't touch it if request is from product list page
		// otherwise, make it right (remove non-product categories and set another one in the list to the product.)
		if (!StringUtils.equals(from, PRODUCT_LIST_PAGE)) {
			long categoryId = getCategoryIdForBreadcrumb(productDTO);
			request.getSession().setAttribute("selectedCategoryId", categoryId);
			categoryTreeService.setUpBreadCrumb(request, categoryId);
		}

		return getDefaultProductView();

	}

	/**
	 * view accessory product
	 * @param productId productId
	 * @param accessoryId accessoryId
	 * @param model model
	 * @return string view
	 * @throws ItemNotFoundException product not found
	 */
	@RequestMapping(value = "/{productId}/{accessoryId}", produces = { "text/html", "*/*" })
	public String accessoryView(@PathVariable("accessoryId") Long accessoryId,
			@PathVariable("productId") Long productId, Model model) throws ItemNotFoundException {
		ProductDetailDTO productDTO = catalogService.getMenardProductDetail(accessoryId, null, false);
		if (productDTO == null) {
			return "catalog/productnotfound";
		}
		model.addAttribute(MODEL_ATTRIBUTE_NAME, productDTO);
		model.addAttribute("mainProductId", productId);
		MenardProductDTO mainDTO = catalogService.getMenardProductById(productId);
		model.addAttribute("mainProduct", mainDTO);
		return "catalog/accessoryView";
	}

	/**
	 * 
	 * Get category for displaying bread crumb
	 * @param productDTO ProductDetailDTO
	 * @return categoryId long
	 */
	private long getCategoryIdForBreadcrumb(ProductDetailDTO productDTO) {
		long categoryId = productDTO.getCategoryId();
		// make a copy
		List<CategoryProductXref> allCategories = new ArrayList<>(productDTO.getProduct().getAllParentCategoryXrefs());

		// return the default category id of the product if it belongs to only one category
		if (allCategories.size() == 1) {
			return categoryId;

		} else if (allCategories.size() > 1) {
			// Do category filtering if there are more than one categories
			List<CategoryProductXref> specialCategories = new ArrayList<>();
			for (CategoryProductXref cpx : allCategories) {
				// change category when the default one is Monthly Inventory Report which is not a product category
				if (cpx.getCategory().getId().equals(productDTO.getCategoryId())
						&& MONTHLY_INVENTORY_REPORT_CATEGORY_URL.equals(cpx.getCategory().getUrl())
						&& MONTHLY_INVENTORY_REPORT_CATEGORY_NAME.equals(cpx.getCategory().getName())) {
					specialCategories.add(cpx);
				}

				// check and remove other special categories if there are more here ...
			}
			if (!specialCategories.isEmpty()) {
				// found it! remove it!
				allCategories.removeAll(specialCategories);

				// return the first category ID in the list, hope it's a product category :)
				if (!allCategories.isEmpty()) {
					return allCategories.get(0).getCategory().getId();
				}
			}
		}

		return categoryId;
	}
}
