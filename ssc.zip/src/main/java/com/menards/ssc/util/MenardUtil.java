package com.menards.ssc.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.menards.ssc.constants.CommonConstant;

/**
 * <p>MenardUtil</p>
 * <p>menard string util</p>
 * <p>
 * menard string util
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public abstract class MenardUtil {

	public static final Logger LOG = Logger.getLogger(MenardUtil.class);

	/**
	 * mapping key to db key
	 * productattributekey skuattributekey
	 * @param key attribute name
	 * @return string value
	 */
	public static String getMappingKey(String key) {
		// return StringUtils.upperCase(key);
		return key;
	}

	/**
	 * to adapte the string value of boolean
	 * @param str string
	 * @return boolean boolean
	 */
	public static boolean getBooleanValue(String str) {
		return CommonConstant.TRUE_STRING.equalsIgnoreCase(str);
	}

	/**
	 * format date according pattern
	 * @param date date
	 * @param patternSrc pattern
	 * @return string string
	 */
	public static String formatDate(Date date, String patternSrc) {
		if (date == null) {
			return null;
		}
		DateFormat dateFormat = new SimpleDateFormat(patternSrc);
		return dateFormat.format(date);
	}

	/**
	 * parse date, return null if exception
	 * @param dateStr date
	 * @param patternSrc pattern
	 * @return date date
	 */
	public static Date parseDate(String dateStr, String patternSrc) {
		DateFormat dateFormat = new SimpleDateFormat(patternSrc);
		try {
			return dateFormat.parse(dateStr);
		} catch (ParseException e) {
			return null;
		}
	}

}
