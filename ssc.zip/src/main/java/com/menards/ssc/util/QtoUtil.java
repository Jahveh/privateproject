/*
 * Created on Sep 8, 2003
 *
 */
package com.menards.ssc.util;

/**
 * Utility class for Quote To Order
 * 
 * @author Jon Madison, Acquity Group
 *
 */
public class QtoUtil {

	public static String getXmlHeader() {
		return "<?xml version=\"1.0\"?>\n";
	}

	public static String getErrorMessage(String sErrorMsg) {
		String result = getXmlHeader();

		result += getSoResponseBeginElement();
		result += "\t";
		result += "<error>";
		result += sErrorMsg;
		result += "</error>\n";
		result += getSoResponseEndElement();

		return result;
	}

	/**
	 * @return so response message xml end element
	 */
	private static String getSoResponseEndElement() {
		return "</soresponse>\n";
	}

	/**
	 * @return so response message xml begin element
	 */
	private static String getSoResponseBeginElement() {
		return "<soresponse>\n";
	}

	/**
	 * @param kioskServerResponse
	 * @return String representing the kiosk server response in xml format
	 */
	public static String createXmlResponse(StringBuffer sbResponse) {
		String result = getXmlHeader();

		String sServerID = sbResponse.substring(0, 10);
		String sMsgNum = sbResponse.substring(10, 13);
		String sMsgSeq = sbResponse.substring(13, 17);
		String sDateTime = sbResponse.substring(17, 31);
		String sResponse = sbResponse.substring(31, 36);

		result += getSoResponseBeginElement();
		result += "\t";
		result += "<serverID>" + sServerID + "</serverID>\n";
		result += "\t";
		result += "<msgnum>" + sMsgNum + "</msgnum>\n";
		result += "\t";
		result += "<sequence>" + sMsgSeq + "</sequence>\n";
		result += "\t";
		result += "<date>" + sDateTime + "</date>\n";

		String sMessage = sbResponse.substring(36);

		if (sResponse.equals("ERROR"))
			result += getERROR(sMessage);

		if (sResponse.equals("SOCRE"))
			result += getSOCRE(sMessage);

		if (sResponse.equals("ESTRE"))
			result += getESTRE(sMessage);

		result += getSoResponseEndElement();

		return result;
	}

	/**
	 * return the error XML
	 * @param message
	 * @return String representing the error code and error
	 */
	private static String getERROR(String sMessage) {
		String result = new String();
		String sErrorCode = sMessage.substring(0, 3);
		result += "\t<error>\n";
		result += "\t\t<code>" + sErrorCode + "</code>\n";
		result += "\t\t<message>" + getErrorString(sErrorCode) + "</message>\n";
		result += "\t</error>\n";
		return result;
	}

	/**
	 * get the error string associated with the error code
	 * @param errornum
	 * @return String with elaboration of error code
	 */
	private static String getErrorString(String sErrorCode) {
		String result = new String();
		
		if(sErrorCode.equals("100")) {
			return "Invalid message format - msg. length";
		}
		
		if(sErrorCode.equals("100")) {
			return "Invalid message format - msg. type";
		}
		
		if(sErrorCode.equals("10H")) {
			return "Invalid SOCOH Message Length";
		}

		if(sErrorCode.equals("10D")) {
			return "Invalid SOCOD Message Length";
		}
		
		return result;
	}

	/**
	 * @param message
	 * @return
	 */
	private static String getESTRE(String message) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * parses a SOCRE message
	 * @param message
	 * @return
	 */
	private static String getSOCRE(String sMessage) {
		String result = new String();
		result += "\t<storenum>" + sMessage.substring(0, 5) + "</storenum>\n";
		result += "\t<ordernum>" + sMessage.substring(5, 13) + "</ordernum>\n";
		return result;
	}

}
