package com.menards.ssc.enums;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 *
 * <p>MenardOrderRequestType</p>
 * <p>Request types of menards</p>
 * <p>
 * 
 * Request types for the select options
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author bill01.zhang
 * @version 1.0
 */
public enum MenardOrderRequestType {

	CARD_STOCK("C", "Card Stock"),
	Employment_Office("empOffice", "Employment Office"),
	GSS("G", "GSS"),
	GSS_Fixture("F", "GSS Fixture"),
	GSS_Sign("S", "GSS Sign"),
	GSS_Sign_GM("SGM", "GSS Sign GM"),
	GSS_Pallet_Racking("Q", "GSS Pallet Racking"),
	Merch_Sign("M", "Merch Sign"),
	Color_Signbase("CS", "Color Signbase"),
	Color_Signbase_GM("CSGM", "Color Signbase GM"),
	Welcome_Sign("W", "Welcome Sign"),
	Color_Sign("B", "Color Sign"),
	Zoomer("Z", "Zoomer"),
	Contractor("O", "Contractor"),
	Front_End("E", "Front End"),
	Human_Resources("H", "Human Resources"),
	Facilities("A", "Facilities"),
	Scheduling_1("D", "Scheduling 1"),
	Scheduling_2("U", "Scheduling 2"),
	Security("R", "Security"),
	Training("I", "Training"),
	Special_Order("P", "Special Order"),
	Literature("L", "Literature"),
	Clothing("N", "Clothing"),
	Green_3mm("3mmGreen", "3mm Green"),
	Green_6mm("6mmGreen", "6mm Green"),
	White_3mm("3mmWhite", "3mm White"),
	White_6mm("6mmWhite", "6mm White"),
	Styrene_White_020("020styreneWht", "020 Styrene White"),
	Styrene_White_040("040styreneWht", "040 Styrene White"),
	Styrene_White_060("060styreneWht", "060 Styrene White"),
	Styrene_White_118("118styreneWht", "118 Styrene White"),
	White_Steel_10x16("10x16whtStl", "10x16 White Steel"),
	Green_Steel_16x24("16x24grnStl", "16x24 Green Steel"),
	Plywood("plywood", "Plywood"),
	Flexible("flexible", "Flexible"),
	Sign_Shop_Other("signShopOther", "Sign Shop Other"),
	Business_Cards("busCard", "Business Cards"),
	Vendor_Fact_Tag("X", "Vendor Fact Tag"),
	BM_Fact_Tag("1", "BM Fact Tag"),
	Electrical_Fact_Tag("3", "Electrical Fact Tag"),
	Floor_Fact_Tag("7", "Floor Fact Tag"),
	Hardware_Fact_Tag("2", "Hardware Fact Tag"),
	Millwork_Fact_Tag("4", "Millwork Fact Tag"),
	Plumbing_Fact_Tag("6", "Plumbing Fact Tag"),
	Wall_Fact_Tag("5", "Wall Fact Tag"),
	GSS_SIGN_AND_GM("S,SGM", "GSS Sign"),
	COLOR_SIGNBASE_AND_GM("CS,CSGM", "Color Signbase");
	private String key;
	private String description;

	/**
	 * 
	 * @param key String
	 * @return MenardOrderRequestType
	 */
	public static MenardOrderRequestType getInstance(String key) {
		for (MenardOrderRequestType requestType : MenardOrderRequestType.values()) {
			if (requestType.getKey().equals(key)) {
				return requestType;
			}
		}
		return null;
	}

	/**
	 * Retrieve the fulfiller type according to the request type
	 * @param requestType String
	 * @return MenardFulfillerType
	 */
	public static MenardFulfillerType getFulfillerByRequestType(String requestType) {
		MenardOrderRequestType requestTypeEnum = MenardOrderRequestType.getInstance(requestType);
		if (requestTypeEnum == null) {
			return null;
		}
		switch (requestTypeEnum) {
			case CARD_STOCK:
				return MenardFulfillerType.SIGN_PRODUCTION;
			case Contractor:
				return MenardFulfillerType.OPERATIONS;
			case Facilities:
				return MenardFulfillerType.OPERATIONS;
			case Front_End:
				return MenardFulfillerType.OPERATIONS;
			case GSS:
				return MenardFulfillerType.STORE_PLANNING;
			case GSS_Fixture:
				return MenardFulfillerType.STORE_PLANNING;
			case GSS_Sign:
				return MenardFulfillerType.SIGN_SHOP;
			case GSS_Sign_GM:
				return MenardFulfillerType.SIGN_SHOP;
			case Color_Signbase:
				return MenardFulfillerType.SIGN_PRODUCTION;
			case Color_Signbase_GM:
				return MenardFulfillerType.SIGN_PRODUCTION;
			case GSS_Pallet_Racking:
				return MenardFulfillerType.STORE_PLANNING;
			case Human_Resources:
				return MenardFulfillerType.OPERATIONS;
			case Merch_Sign:
				return MenardFulfillerType.SIGN_PRODUCTION;
			case Color_Sign:
				return MenardFulfillerType.SIGN_PRODUCTION;
			case Scheduling_1:
				return MenardFulfillerType.OPERATIONS;
			case Scheduling_2:
				return MenardFulfillerType.OPERATIONS;
			case Security:
				return MenardFulfillerType.OPERATIONS;
			case Special_Order:
				return MenardFulfillerType.OPERATIONS;
			case Training:
				return MenardFulfillerType.OPERATIONS;
			case Welcome_Sign:
				return MenardFulfillerType.SIGN_PRODUCTION;
			case Zoomer:
				return MenardFulfillerType.SIGN_PRODUCTION;
			case Literature:
				return MenardFulfillerType.LITERATURE;
			case Clothing:
				return MenardFulfillerType.PAYROLL;
			case Employment_Office:
				return MenardFulfillerType.EMPLOYMENT_OFFICE;
			case Green_3mm:
				return MenardFulfillerType.SIGN_SHOP;
			case Green_6mm:
				return MenardFulfillerType.SIGN_SHOP;
			case White_3mm:
				return MenardFulfillerType.SIGN_SHOP;
			case White_6mm:
				return MenardFulfillerType.SIGN_SHOP;
			case Styrene_White_020:
				return MenardFulfillerType.SIGN_SHOP;
			case Styrene_White_040:
				return MenardFulfillerType.SIGN_SHOP;
			case Styrene_White_060:
				return MenardFulfillerType.SIGN_SHOP;
			case Styrene_White_118:
				return MenardFulfillerType.SIGN_SHOP;
			case White_Steel_10x16:
				return MenardFulfillerType.SIGN_SHOP;
			case Green_Steel_16x24:
				return MenardFulfillerType.SIGN_SHOP;
			case Plywood:
				return MenardFulfillerType.SIGN_SHOP;
			case Flexible:
				return MenardFulfillerType.SIGN_SHOP;
			case Sign_Shop_Other:
				return MenardFulfillerType.SIGN_SHOP;
			case Business_Cards:
				return MenardFulfillerType.SIGN_PRODUCTION;
			case Vendor_Fact_Tag:
				return MenardFulfillerType.FACT_TAG;
			case BM_Fact_Tag:
				return MenardFulfillerType.FACT_TAG;
			case Hardware_Fact_Tag:
				return MenardFulfillerType.FACT_TAG;
			case Electrical_Fact_Tag:
				return MenardFulfillerType.FACT_TAG;
			case Millwork_Fact_Tag:
				return MenardFulfillerType.FACT_TAG;
			case Wall_Fact_Tag:
				return MenardFulfillerType.FACT_TAG;
			case Plumbing_Fact_Tag:
				return MenardFulfillerType.FACT_TAG;
			case Floor_Fact_Tag:
				return MenardFulfillerType.FACT_TAG;
			default:
		}
		return null;
	}

	/**
	 *
	 *Constructor
	 *@param key key of request type
	 *@param description request type description
	 */
	private MenardOrderRequestType(String key, String description) {
		this.key = key;
		this.description = description;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 *
	 * Get request type by role type
	 * @param role role type
	 * @param operationType operation type
	 * @param factTagRequestType fact tag request type
	 * @return request type list
	 */
	public static Collection<MenardOrderRequestType> getReqeustTypeByRoleType(String role, String operationType,
			String factTagRequestType) {
		if (MenardFulfillerType.OPERATIONS.getKey().equals(role)) {
			if (MenardOperationType.One.getKey().equals(operationType)) {
				return Arrays.asList(MenardOrderRequestType.Contractor);
			}
			if (MenardOperationType.Two.getKey().equals(operationType)) {
				return Arrays.asList(MenardOrderRequestType.Front_End);
			}
			if (MenardOperationType.Three.getKey().equals(operationType)) {
				return Arrays.asList(MenardOrderRequestType.Human_Resources);
			}
			if (MenardOperationType.Four.getKey().equals(operationType)) {
				return Arrays.asList(MenardOrderRequestType.Facilities);
			}
			if (MenardOperationType.Five.getKey().equals(operationType)) {
				return Arrays.asList(MenardOrderRequestType.Scheduling_1);
			}
			if (MenardOperationType.Six.getKey().equals(operationType)) {
				return Arrays.asList(MenardOrderRequestType.Scheduling_2);
			}
			if (MenardOperationType.Seven.getKey().equals(operationType)) {
				return Arrays.asList(MenardOrderRequestType.Security);
			}
			if (MenardOperationType.Eight.getKey().equals(operationType)) {
				return Arrays.asList(MenardOrderRequestType.Training);
			}
			if (MenardOperationType.Nine.getKey().equals(operationType)) {
				return Arrays.asList(MenardOrderRequestType.Special_Order);
			}
			if (MenardOperationType.NINE_HUNDRED_AND_NINETY_NINE.getKey().equals(operationType)) {
				return Arrays.asList(MenardOrderRequestType.Contractor, MenardOrderRequestType.Front_End,
						MenardOrderRequestType.Human_Resources, MenardOrderRequestType.Facilities,
						MenardOrderRequestType.Scheduling_1, MenardOrderRequestType.Scheduling_2,
						MenardOrderRequestType.Security, MenardOrderRequestType.Training,
						MenardOrderRequestType.Special_Order);
			}
		}

		if (MenardFulfillerType.PAYROLL.getKey().equals(role)) {
			return Arrays.asList(MenardOrderRequestType.Clothing);
		}
		if (MenardFulfillerType.EMPLOYMENT_OFFICE.getKey().equals(role)) {
			return Arrays.asList(MenardOrderRequestType.Employment_Office);
		}
		if (MenardFulfillerType.LITERATURE.getKey().equals(role) || MenardFulfillerType.MIDWEST.getKey().equals(role)) {
			return Arrays.asList(MenardOrderRequestType.Literature);
		}

		if (MenardFulfillerType.FACT_TAG.getKey().equals(role)) {
			if (MenardFactTagRequestType.One.getKey().equals(factTagRequestType)) {
				return Arrays.asList(MenardOrderRequestType.BM_Fact_Tag);
			}
			if (MenardFactTagRequestType.Two.getKey().equals(factTagRequestType)) {
				return Arrays.asList(MenardOrderRequestType.Hardware_Fact_Tag);
			}
			if (MenardFactTagRequestType.Three.getKey().equals(factTagRequestType)) {
				return Arrays.asList(MenardOrderRequestType.Electrical_Fact_Tag);
			}
			if (MenardFactTagRequestType.Four.getKey().equals(factTagRequestType)) {
				return Arrays.asList(MenardOrderRequestType.Millwork_Fact_Tag);
			}
			if (MenardFactTagRequestType.Five.getKey().equals(factTagRequestType)) {
				return Arrays.asList(MenardOrderRequestType.Wall_Fact_Tag);
			}
			if (MenardFactTagRequestType.Six.getKey().equals(factTagRequestType)) {
				return Arrays.asList(MenardOrderRequestType.Plumbing_Fact_Tag);
			}
			if (MenardFactTagRequestType.Seven.getKey().equals(factTagRequestType)) {
				return Arrays.asList(MenardOrderRequestType.Floor_Fact_Tag);
			}
		}

		if (MenardFulfillerType.SIGN_SHOP.getKey().equals(role)) {
			return Arrays.asList(MenardOrderRequestType.GSS_SIGN_AND_GM, MenardOrderRequestType.Green_3mm,
					MenardOrderRequestType.Green_6mm, MenardOrderRequestType.White_3mm,
					MenardOrderRequestType.White_6mm, MenardOrderRequestType.Styrene_White_020,
					MenardOrderRequestType.Styrene_White_040, MenardOrderRequestType.Styrene_White_060,
					MenardOrderRequestType.Styrene_White_118, MenardOrderRequestType.White_Steel_10x16,
					MenardOrderRequestType.Green_Steel_16x24, MenardOrderRequestType.Plywood,
					MenardOrderRequestType.Flexible, MenardOrderRequestType.Sign_Shop_Other);
		}
		if (MenardFulfillerType.SIGN_PRODUCTION.getKey().equals(role)) {
			return Arrays.asList(MenardOrderRequestType.CARD_STOCK, MenardOrderRequestType.Merch_Sign,
					MenardOrderRequestType.GSS_SIGN_AND_GM, MenardOrderRequestType.Welcome_Sign,
					MenardOrderRequestType.Business_Cards, MenardOrderRequestType.Color_Sign,
					MenardOrderRequestType.Zoomer);
		}
		if (MenardFulfillerType.STORE_PLANNING.getKey().equals(role)) {
			return Arrays.asList(MenardOrderRequestType.GSS, MenardOrderRequestType.GSS_Fixture,
					MenardOrderRequestType.GSS_Pallet_Racking);
		}

		if (MenardFulfillerType.GENERAL_MANAGER.getKey().equals(role)) {
			return Arrays.asList(MenardOrderRequestType.CARD_STOCK, MenardOrderRequestType.Employment_Office,
					MenardOrderRequestType.GSS, MenardOrderRequestType.GSS_Fixture,
					MenardOrderRequestType.GSS_Pallet_Racking, MenardOrderRequestType.Merch_Sign,
					MenardOrderRequestType.GSS_SIGN_AND_GM, MenardOrderRequestType.Color_Sign,
					MenardOrderRequestType.Welcome_Sign, MenardOrderRequestType.COLOR_SIGNBASE_AND_GM,
					MenardOrderRequestType.Zoomer, MenardOrderRequestType.Contractor, MenardOrderRequestType.Front_End,
					MenardOrderRequestType.Human_Resources, MenardOrderRequestType.Facilities,
					MenardOrderRequestType.Scheduling_1, MenardOrderRequestType.Scheduling_2,
					MenardOrderRequestType.Security, MenardOrderRequestType.Training,
					MenardOrderRequestType.Special_Order, MenardOrderRequestType.Literature,
					MenardOrderRequestType.Clothing, MenardOrderRequestType.Green_3mm,
					MenardOrderRequestType.Green_6mm, MenardOrderRequestType.White_3mm,
					MenardOrderRequestType.White_6mm, MenardOrderRequestType.Styrene_White_020,
					MenardOrderRequestType.Styrene_White_040, MenardOrderRequestType.Styrene_White_060,
					MenardOrderRequestType.Styrene_White_118, MenardOrderRequestType.White_Steel_10x16,
					MenardOrderRequestType.Green_Steel_16x24, MenardOrderRequestType.Plywood,
					MenardOrderRequestType.Flexible, MenardOrderRequestType.Sign_Shop_Other,
					MenardOrderRequestType.Business_Cards, MenardOrderRequestType.Vendor_Fact_Tag);
		}

		if (MenardFulfillerType.SUPER_GO.getKey().equals(role)) {
			return getAllRequestTypeForOptions();
		}
		return new ArrayList<MenardOrderRequestType>();
	}

	/**
	 * Retrieve all the request types for options except some special
	 * @return List<MenardOrderRequestType>
	 */
	public static List<MenardOrderRequestType> getAllRequestTypeForOptions() {
		List<MenardOrderRequestType> list = new ArrayList<MenardOrderRequestType>();
		for (MenardOrderRequestType type : MenardOrderRequestType.values()) {

			if (MenardOrderRequestType.GSS_Sign.getKey().equals(type.getKey())
					|| MenardOrderRequestType.GSS_Sign_GM.getKey().equals(type.getKey())
					|| MenardOrderRequestType.Color_Signbase.getKey().equals(type.getKey())
					|| MenardOrderRequestType.Color_Signbase_GM.getKey().equals(type.getKey())) {
				continue;
			}
			list.add(type);
		}

		return list;
	}
}
