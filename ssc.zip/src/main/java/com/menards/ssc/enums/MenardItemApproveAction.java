package com.menards.ssc.enums;

/**
 * <p>MenardItemApproveAction</p>
 * <p>Sumarry of actions</p>
 * <p>
 *   Represent all the possible actions on order items
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public enum MenardItemApproveAction {

	APPROVED("Approved"), DECLINED("Declined"), BACKORDERED("BackOrdered");

	private String key;

	/**
	 *Constructor 
	 *@param key String
	 */
	private MenardItemApproveAction(String key) {
		this.key = key;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

}
