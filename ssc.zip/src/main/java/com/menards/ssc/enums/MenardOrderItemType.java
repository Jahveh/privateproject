package com.menards.ssc.enums;

/**
 * <p>MenardOrderItemType</p>
 * <p>meanrd order item type</p>
 * <p>
 * meanrd order item type
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public enum MenardOrderItemType {

	SKU("1", "sku"), SIGN("2", "signBase"), COLOR_SIGN("3", "colorSign"), SKU_MAN("5", "skuman");

	private String code;
	private String description;

	/**
	 *Constructor 
	 *@param code code
	 *@param description description
	 */
	private MenardOrderItemType(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

    /**
     * Get MenardOrderItemType enum by code
     *
     * @param code
     * @return
     */
    public static MenardOrderItemType getTypeFromCode(Integer code) {
        MenardOrderItemType[] allTypes = MenardOrderItemType.values();
        for (MenardOrderItemType itemType: allTypes) {
            if (itemType.getCode().equals(code)) {
                return itemType;
            }
        }
        return null;
    }
}
