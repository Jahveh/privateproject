package com.menards.ssc.enums;

/**
 * 
 * <p>SignSearchType</p>
 */
public enum SignSearchType {

	Detail, Cart, Place;

	/**
	 * 
	 *Constructor
	 */
	private SignSearchType() {
	}

}
