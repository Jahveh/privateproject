/**
 * 
 */
package com.menards.ssc.enums;

/**
 * <p>MenardSearchType</p>
 * <p>Enumeration type for header search</p>
 * <p>
 * A list of search types
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public enum MenardSearchType {
	SIGN("sign", "Sign"), SALE_SIGN("saleSign", "Sale sign"), SUPPLIES("supplies", "Supplies");

	/**
	 * 
	 *Constructor 
	 *@param key key
	 *@param description description
	 */
	private MenardSearchType(String key, String description) {
		this.key = key;
		this.description = description;
	}

	private String key;
	private String description;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
