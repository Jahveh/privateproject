package com.menards.ssc.enums;

/**
 * <p>MenardTitle</p>
 * <p>Menard title</p>
 * <p>
 * Menard title
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public enum MenardTitle {

	GM("General Manager", 260), AGM("Assistant General Manager", 260), FEM("Front End Manager", 160), BMM(
			"Building Materials Manager", 160), HM("Hardware Manager", 160), EM("Electrical Manager", 160), CAM(
			"Cabinet and Appliance Manager", 160), MM("Millwork Manager", 160), WM("Wallcoverings Manager", 160), PM(
			"Plumbing Manager", 160), FM("Floorcoverings Manager", 160), RM("Receiving Manager", 100), DC(
			"Delivery Coordinator", 100), IC("Inventory Controller", 100), HRC("Human Resources Coordinator", 300), ES(
			"Estimator/Sales", 260), CCSDM("Commercial/Contractor Service Department Manager", 500), CCASM(
			"Commercial/Contractor Account Service Manager", 500), GS("Guest Service", 60);

	private String desc;
	private int quantity;

	/**
	 * 
	 *Constructor 
	 *@param desc description
	 *@param quantity quantity
	 */
	private MenardTitle(String desc, int quantity) {
		this.desc = desc;
		this.quantity = quantity;
	}

	public String getName() {
		return this.name();
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
