package com.menards.ssc.enums;

import org.apache.commons.lang.StringUtils;

/**
 *
 * <p>MenardOrderItemStatus</p>
 * <p>order item status</p>

 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author bill01.zhang
 * @version 1.0
 */
public enum MenardOrderItemHistoryStatus {

	PENDING_GM("W", "PENDING GM"),
	GM_DECLINED("N", "GM DECLINED"),
	PENDING_GO("A,EA", "PENDING GO"),
	GO_DECLINED("D,ED", "GO DECLINED"),
	BACKORDERED("O,EO", "BACKORDERED"),
	COMPLETED("C,EC", "COMPLETED"),
	BATCHED_FOR_DC("B", "BATCHED FOR DC"),
	PRINTED_AT_STORE("P", "PRINTED AT STORE"),
	IN_THE_MAIL("I", "SENT BY MAIL"),
	REQUEST_SENT("S", "REQUEST SENT"),
	BATCHED_FOR_VENDOR("V", "BATCHED FOR VENDOR"),
	PARTIAL("Z,EZ", "PARTIAL");

	private String value;
	private String description;

	/**
	 *
	 *Constructor
	 *@param value String
	 *@param description String
	 */
	private MenardOrderItemHistoryStatus(String value, String description) {
		this.value = value;
		this.description = description;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 *
	 * get description 
	 * @param value String
	 * @return String
	 */
	public static String getDescriptionByValue(String value) {
		if (StringUtils.isBlank(value)) {
			return StringUtils.EMPTY;
		}
		for (MenardOrderItemHistoryStatus status : MenardOrderItemHistoryStatus.values()) {
			if (StringUtils.equals(value, status.getValue())) {
				return status.description;
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 *
	 * get MenardOrderItemStatus
	 * @param value String
	 * @return MenardOrderItemStatus
	 */
	public static MenardOrderItemHistoryStatus getStatusByValue(String value) {
		if (StringUtils.isBlank(value)) {
			return null;
		}
		for (MenardOrderItemHistoryStatus status : MenardOrderItemHistoryStatus.values()) {
			if (StringUtils.equals(value, status.getValue())) {
				return status;
			}
		}
		return null;
	}
}
