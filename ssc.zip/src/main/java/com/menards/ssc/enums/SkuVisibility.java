package com.menards.ssc.enums;

/**
 * <p>SkuVisibility</p>
 * <p>Sku Visibility</p>
 * <p>
 * Sku Visibility
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public enum SkuVisibility {

	STOCK_NOT_ORDERABLE(0), STOCK_ORDERABLE(1), SPECIAL_ORDER(2), DELETED(3);

	private int code;

	/**
	 * 
	 *Constructor 
	 *@param code code
	 */
	private SkuVisibility(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	/**
	 * 
	 * getSkuVisibilityByCode
	 * @param code code
	 * @return SkuVisibility
	 */
	public static SkuVisibility getSkuVisibilityByCode(int code) {
		for (SkuVisibility sv : SkuVisibility.values()) {
			if (sv.getCode() == code) {
				return sv;
			}
		}
		return null;
	}

}
