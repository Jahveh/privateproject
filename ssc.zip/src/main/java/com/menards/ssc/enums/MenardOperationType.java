package com.menards.ssc.enums;

/**
 * <p>MenardOperationType</p>
 * <p>Operation Type list </p>
 * <p>
 * Represent the operation types of meanrd
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public enum MenardOperationType {
	Zero("0", "0"), One("1", "1"), Two("2", "2"), Three("3", "3"), Four("4", "4"), Five("5", "5"), Six("6", "6"), Seven(
			"7", "7"), Eight("8", "8"), Nine("9", "9"), NINE_HUNDRED_AND_NINETY_NINE("999", "999");
	private String key;
	private String description;

	/**
	 *
	 *Constructor
	 *@param key String
	 *@param description String
	 */
	private MenardOperationType(String key, String description) {
		this.key = key;
		this.description = description;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
