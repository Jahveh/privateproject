package com.menards.ssc.enums;

import org.apache.commons.lang.StringUtils;

/**
 * <p>MenardDepartment</p>
 * <p>Department enum class</p>
 * <p>
 * A list of the departments of meanrds
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public enum MenardDepartment {
	YARD_SHIPPING_RECEIVING("020", "Yard Shipping/Receiving"),
	BUILDING_MATERIALS("100", "Building Materials"),
	HARDWARE("200", "Hardware"),
	ELECTRICAL("300", "Electrical"),
	MILLWORK("400", "Millwork"),
	CABINETS_AND_APPLIANCES("401", "Cabinets and Appliances"),
	WALLCOVERINGS("500", "Wallcoverings"),
	FRONT_END("501", "Front End"),
	PET_AND_WILDLIFE("502", "Pet and Wildlife"),
	PLUMBING("600", "Plumbing"),
	Floorcoverings("700", "Floorcoverings"),
	BACK_OFFICE("900", "Back Office");

	private String key;
	private String name;

	/**
	 * 
	 *Constructor 
	 *@param key key
	 *@param name department name
	 */
	private MenardDepartment(String key, String name) {
		this.key = key;
		this.name = name;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 
	 * Get department name by key
	 * @param key input key
	 * @return depart name
	 */
	public static String getNameByKey(String key) {
		if (StringUtils.isBlank(key)) {
			return StringUtils.EMPTY;
		}
		for (MenardDepartment dept : MenardDepartment.values()) {
			if (StringUtils.equals(dept.getKey(), key)) {
				return dept.getName();
			}
		}
		return StringUtils.EMPTY;
	}

}
