package com.menards.ssc.enums;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.menards.ssc.constants.CommonConstant;

/**
 *
 * <p>MenardOrderItemSort</p>
 * <p>Summary of order sort</p>
 * <p>
 * List all kinds of the sort that is used in the order and
 * order item functionality
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author bill01.zhang
 * @version 1.0
 */
public enum MenardOrderItemSort implements CommonConstant {

	STATUS_DATE_ASC(SORT_ASC, "StatusDateASC", "Status Date ASC", Arrays.asList("statusDate"), Date.class),
	STATUS_DATE_DESC(SORT_DESC, "StatusDateDESC", "Status Date DESC", Arrays.asList("statusDate"), Date.class),
	COMMENT_DESC(SORT_DESC, "CommentDESC", "Comment DESC", Arrays.asList(NOTES), String.class),
	COMMENT_ASC(SORT_ASC, "CommentASC", "Comment ASC", Arrays.asList(NOTES), String.class),
	DESCRIPTION_DESC(SORT_DESC, "DescriptionDESC", "Description DESC", Arrays.asList("description"), String.class),
	DESCRIPTION_ASC(SORT_ASC, "DescriptionASC", "Description ASC", Arrays.asList("description"), String.class),
	ITEM_ID_DESC(SORT_DESC, "ItemIdDESC", "Item Id DESC", Arrays.asList("modelNum"), String.class),
	ITEM_ID_ASC(SORT_ASC, "ItemIdASC", "Item Id ASC", Arrays.asList("modelNum"), String.class),
	ORDER_ID_DESC(SORT_DESC, "OrderIdDESC", "Order Id DESC", Arrays.asList(MENARDORDER, "id"), Long.class),
	ORDER_ID_ASC(SORT_ASC, "OrderIdASC", "Order Id ASC", Arrays.asList(MENARDORDER, "id"), Long.class),
	REQUEST_TYPE_DESC(SORT_DESC, "RequestTypeDESC", "Request Type DESC", Arrays.asList("requestType"), String.class),
	REQUEST_TYPE_ASC(SORT_ASC, "RequestTypeASC", "Request Type ASC", Arrays.asList("requestType"), String.class),
	SKU_DESC(SORT_DESC, "SkuDESC", "Sku DESC", Arrays.asList("menardSku", "skuCode"), String.class),
	SKU_ASC(SORT_ASC, "SkuASC", "Sku ASC", Arrays.asList("menardSku", "skuCode"), String.class),
	YARD_DESC(SORT_DESC, "YardDESC", "Yard DESC", Arrays.asList(MENARDORDER, "storeId"), String.class),
	YARD_ASC(SORT_ASC, "YardASC", "Yard ASC", Arrays.asList(MENARDORDER, "storeId"), String.class);

	private String key;
	private String type;
	private List<String> fields;
	private Class<?> pathType;
	private String description;

	/**
	 *
	 *Constructor
	 *@param type String
	 *@param key String
	 *@param description String
	 */
	private MenardOrderItemSort(String type, String key, String description) {
		this.type = type;
		this.key = key;
		this.description = description;
	}

	/**
	 *
	 *Constructor
	 *@param type String
	 *@param key String
	 *@param description String
	 *@param fields String
	 *@param pathType String
	 */
	private MenardOrderItemSort(String type, String key, String description, List<String> fields, Class<?> pathType) {
		this.key = key;
		this.type = type;
		this.fields = fields;
		this.pathType = pathType;
		this.description = description;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<String> getFields() {
		return fields;
	}

	public void setFields(List<String> fields) {
		this.fields = fields;
	}

	public Class<?> getPathType() {
		return pathType;
	}

	public void setPathType(Class<?> pathType) {
		this.pathType = pathType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * 
	 * Get Order Item sorted by Key
	 * @param key String
	 * @return MenardOrderItemSort
	 */
	public static MenardOrderItemSort getMenardOrderItemSortByKey(String key) {
		if (StringUtils.isBlank(key)) {
			return STATUS_DATE_ASC;
		}
		for (MenardOrderItemSort sort : MenardOrderItemSort.values()) {
			if (sort.key.equals(key)) {
				return sort;
			}
		}
		return STATUS_DATE_ASC;
	}

}
