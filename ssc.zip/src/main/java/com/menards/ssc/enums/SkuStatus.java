package com.menards.ssc.enums;

/**
 * <p>SkuStatus</p>
 * <p>sku status</p>
 * <p>
 * sku status
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public enum SkuStatus {

	STOCK(0, "Stock", "0"),
	DISCONTINUED(1, "ds", "1"),
	SEASONAL(2, "Seasonal", "2"),
	DELETED(3, "Deleted", "3"),
	SPECIAL_ORDER(4, "so", "4"),
	DC_SPECIAL_ORDER(5, "so", "5");

	private int code;
	private String desc;
	private String strCode;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	/**
	 *
	 *Constructor
	 *@param code code
	 *@param desc description
	 */
	private SkuStatus(int code, String desc, String strCode) {
		this.code = code;
		this.desc = desc;
		this.strCode = strCode;
	}

	/**
	 *
	 *Constructor
	 *@param code code
	 */
	private SkuStatus(int code) {
		this.code = code;
	}

	/**
	 *
	 * getSkuStatusByCode
	 * @param code code
	 * @return SkuStatus
	 */
	public static SkuStatus getSkuStatusByCode(int code) {
		for (SkuStatus ss : SkuStatus.values()) {
			if (ss.getCode() == code) {
				return ss;
			}
		}
		return null;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getStrCode() {
		return strCode;
	}

	public void setStrCode(String strCode) {
		this.strCode = strCode;
	}

}
