package com.menards.ssc.enums;

/**
 *
 * <p>MenardFactTagRequestType</p>
 * <p>Request Type of fact tag</p>
 * <p>
 * A list of fact tag type * 
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author bill01.zhang
 * @version 1.0
 */
public enum MenardFactTagRequestType {
	Zero("0", "0"), One("1", "1"), Two("2", "2"), Three("3", "3"), Four("4", "4"), Five("5", "5"), Six("6", "6"), Seven(
			"7", "7");
	private String key;
	private String description;

	/**
	 *
	 *Constructor
	 *@param key String
	 *@param description String
	 */
	private MenardFactTagRequestType(String key, String description) {
		this.key = key;
		this.description = description;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
