package com.menards.ssc.enums;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.menards.ssc.constants.CommonConstant;

/**
 *
 * <p>MenardRole</p>
 * <p>All kinds of roles of meanrds</p>
 * 
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author bill01.zhang
 * @version 1.0
 */
public enum MenardFulfillerType {

	GENERAL_MANAGER("G", "General manager", "1"), SIGN_PRODUCTION("P", "Sign production", "2"), STORE_PLANNING("F",
			"Store planning", "3"), SIGN_SHOP("S", "Sign shop", "4"), OPERATIONS("O", "Operations", "5"), LITERATURE(
			"L", "Literature", "6"), PAYROLL("Y", "Payroll", "7"), MIDWEST("M", "Midwest", "8"), FACT_TAG("T",
			"Fact tag", "9"), EMPLOYMENT_OFFICE("E", "Employment office", "10"), SUPER_GO("A", "Super Go", "999"), NOT_ACCESS_BYGO("U", "not access by Go", "000");

	private String key;
	private String description;
	private String roleKey;

	/**
	 *
	 *Constructor
	 *@param key key
	 *@param description role description
	 *@param roleKey roleKey
	 */
	private MenardFulfillerType(String key, String description, String roleKey) {
		this.key = key;
		this.description = description;
		this.roleKey = roleKey;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * 
	 * getFulfillerTypeByRoleKey
	 * @param value value
	 * @return Fulfiller type
	 */
	public static String getFulfillerTypeByRoleKey(String value) {
		if (StringUtils.isBlank(value)) {
			return null;
		}
		for (MenardFulfillerType type : MenardFulfillerType.values()) {
			if (type.getRoleKey().equals(value)) {
				return type.getKey();
			}
		}
		return null;
	}
	
	
	/**
	 * 
	 * getFulfillerTypeByRoleKey
	 * @param value value
	 * @return Fulfiller type
	 */
	public static Set<String> getFulfillerTypeKeySet() {
		Set<String> set = new HashSet<String>();
		for (MenardFulfillerType type : MenardFulfillerType.values()) {
			set.add(CommonConstant.ROLE_PREFIX + type.getKey());
		}
		return set;
	}

	public String getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(String roleKey) {
		this.roleKey = roleKey;
	}

}
