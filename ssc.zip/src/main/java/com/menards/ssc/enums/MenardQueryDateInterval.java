package com.menards.ssc.enums;

/**
 *
 * <p>MenardQueryDateInterval</p>
 * <p>All kinds of search interval for order and order item</p>
 * <p>
 * List some interval options for order item searching
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author bill01.zhang
 * @version 1.0
 */
public enum MenardQueryDateInterval {
	SEVEN(7), FOURTEEN(14), TWENTY_ONE(21), TWENTY_EIGHT(28);

	private Integer days;

	/**
	 *
	 *Constructor
	 *@param days interval days
	 */
	private MenardQueryDateInterval(Integer days) {
		this.days = days;
	}

	public Integer getDays() {
		return days;
	}

	public void setDays(Integer days) {
		this.days = days;
	}
}
