package com.menards.ssc.enums;

/**
 * 
 * <p>CategoryType</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public enum CategoryType {
	SSC_CATEGORY, COLOR_SIGN_CATEGORY
}
