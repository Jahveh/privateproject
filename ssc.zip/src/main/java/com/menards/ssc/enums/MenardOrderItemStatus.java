package com.menards.ssc.enums;

import org.apache.commons.lang.StringUtils;

/**
 *
 * <p>MenardOrderItemStatus</p>
 * <p>order item status</p>

 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author bill01.zhang
 * @version 1.0
 */
public enum MenardOrderItemStatus {

	PENDING_GM("W", "PENDING GM"),
	GM_DECLINED("N", "GM DECLINED"),
	PENDING_GO("A", "PENDING GO"),
	GO_DECLINED("D", "GO DECLINED"),
	BACKORDERED("O", "BACKORDERED"),
	COMPLETED("C", "COMPLETED"),
	BATCHED_FOR_DC("B", "BATCHED FOR DC"),
	PRINTED_AT_STORE("P", "PRINTED AT STORE"),
	IN_THE_MAIL("I", "SENT BY MAIL"),
	REQUEST_SENT("S", "REQUEST SENT"),
	NO_KIOSK_SERVER("K", "NO KIOSK SERVER"),
	NOT_LITERATURE("L", "NOT LITERATURE"),
	ALREADY_HAS_PO("H", "ALREADY HAS PO"),
	SENDING_EMAIL("E", "SENDING REQUEST EMAIL"),
	BATCHED_FOR_VENDOR("V", "BATCHED FOR VENDOR"),
	PARTIAL("Z", "PARTIAL"),
	E_PENDING_GO("EA", "PENDING GO"),
	E_GO_DECLINED("ED", "GO DECLINED"),
	E_BACKORDERED("EO", "BACKORDERED"),
	E_COMPLETED("EC", "COMPLETED"),
	E_PARTIAL("EZ", "PARTIAL");

	private String value;
	private String description;

	/**
	 *
	 *Constructor
	 *@param value String
	 *@param description String
	 */
	private MenardOrderItemStatus(String value, String description) {
		this.value = value;
		this.description = description;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 *
	 * get description 
	 * @param value String
	 * @return String
	 */
	public static String getDescriptionByValue(String value) {
		if (StringUtils.isBlank(value)) {
			return StringUtils.EMPTY;
		}
		for (MenardOrderItemStatus status : MenardOrderItemStatus.values()) {
			if (StringUtils.equals(value, status.getValue())) {
				return status.description;
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 *
	 * get MenardOrderItemStatus
	 * @param value String
	 * @return MenardOrderItemStatus
	 */
	public static MenardOrderItemStatus getStatusByValue(String value) {
		if (StringUtils.isBlank(value)) {
			return null;
		}
		for (MenardOrderItemStatus status : MenardOrderItemStatus.values()) {
			if (StringUtils.equals(value, status.getValue())) {
				return status;
			}
		}
		return null;
	}
}
