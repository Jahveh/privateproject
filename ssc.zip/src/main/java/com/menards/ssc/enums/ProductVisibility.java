package com.menards.ssc.enums;

/**
 * <p>ProductVisibility</p>
 * <p>Product Visibility</p>
 * <p>
 * Product Visibility
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public enum ProductVisibility {

	STOCK(0), DISCONTINUED(1), SEASONAL(2), DELETED(3), SPECIAL_ORDER(4), DC_SPECIAL_ORDER(4);

	private int code;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	/**
	 * 
	 *Constructor 
	 *@param code code
	 */
	private ProductVisibility(int code) {
		this.code = code;
	}

}
