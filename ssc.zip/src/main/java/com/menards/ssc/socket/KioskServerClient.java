package com.menards.ssc.socket;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.util.QtoUtil;

public class KioskServerClient {

	public static final Log LOG = LogFactory.getLog(KioskServerClient.class);

	private static String clientName = "localhost";
	private static int bufferSize = 1024;
	private static int timeOut = 7000000;
	private static final String ERROR = "ERROR";

	private static final Set<Integer> DEV_STORE = new HashSet<Integer>();
	static {
		DEV_STORE.add(3999);
		DEV_STORE.add(4999);
		DEV_STORE.add(5999);
		DEV_STORE.add(7777);
		DEV_STORE.add(8888);
	}

	private String hostName;
	private Integer portNumber;
	private String responseMsg = null;

	public KioskServerClient(String kioskServerIpStatic, Integer kioskServerPortNumberStatic) {
		LOG.info("Created an instance of KioskServerClient.");
		LOG.info("KoskiServer IP from configuration" + kioskServerIpStatic);
		LOG.info("KoskiServer Port Number from configuration" + kioskServerPortNumberStatic);
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		String kioskServerIp = user.getKioskServerIp();
		Integer storeNumber = Integer.parseInt(user.getStoreNumber());
		Integer kioskServerPortNumber = -1;

		try {
			kioskServerPortNumber = (Integer.parseInt(user.getKioskServerPortNumber()));
		} catch (NumberFormatException nfe) {
			LOG.error(nfe.getMessage());
			LOG.error("Unable to parse kiosk server port number from session");
			kioskServerPortNumber = -1;
		} catch (NullPointerException npe) {
			kioskServerPortNumber = -1;
		}

		if (StringUtils.isNotBlank(kioskServerIp) && kioskServerPortNumber != -1) {
			LOG.info("Kiosk Server connection information found on session");

		} else {
			kioskServerIp = kioskServerIpStatic;
			if (null == kioskServerIp || kioskServerIp.length() == 0) {
				kioskServerIp = "sys1." + storeNumber + (isDevStore(storeNumber) ? "" : ".st") + ".menards.net";
				LOG.info("PRODUCTION ------- UNABLE TO FIND kiosk_server_address in config.properties");
			} else {
				LOG.info("TESTING ------- FOUND kiosk_server_address in config.properties");
			}

			kioskServerPortNumber = kioskServerPortNumberStatic;
			if (null == kioskServerPortNumber) {
				LOG.error("Error retrieving kiosk_server_port_number from config.properties, " + "defaulting to 4777 for store number: " + storeNumber);
				kioskServerPortNumber = 4777;
			}
			user.setKioskServerIp(kioskServerIp);
			user.setKioskServerPortNumber(String.valueOf(kioskServerPortNumber));
		}

		LOG.info("\nstore number: " + storeNumber + "\nIP: " + kioskServerIp + "\n" + "Using port number: " + kioskServerPortNumber);
		hostName = kioskServerIp;
		portNumber = kioskServerPortNumber;
	}

	/**
	 * Send a request to the kiosk server and return the response.
	 * 
	 * @return String response from kiosk server
	 * @throws BrokerFailedException
	 *             if there was an error sending the request
	 */
	private String sendRequest(String message) {

		StringBuffer kioskServerResponse = new StringBuffer("");
		String result = null;
		Socket conn = null;
		BufferedWriter writer = null;
		BufferedInputStream response = null;
		try {
			conn = new Socket(hostName, portNumber);
			// Set the socket timeout to 7 seconds
			conn.setSoTimeout(timeOut);

			writer = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()), bufferSize);

			// request =
			// Make a request to the kiosk server.
			LOG.info(this.getClass().getName() + ".sendRequest(), message\n" + hostName + " " + message);

			writer.write(message);

			// TODO: change back to this, if necessary. the above works with our
			// test stub
			// request.print(message);
			writer.flush();

			response = new BufferedInputStream(conn.getInputStream());

			do {
				int kioskServerResponseBytes = 0;
				kioskServerResponseBytes = response.read();
				kioskServerResponse.append((char) kioskServerResponseBytes);
			} while (response.available() > 0);
			result = kioskServerResponse.toString();
		} catch (InterruptedIOException iioe) {
			LOG.info("ERROR - Socket Timed Out!");
			result = ERROR;
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.info("Kiosk Server connection failed with host " + hostName);
			return QtoUtil.getErrorMessage("Kiosk Server connection Failed");
		} finally {
			try {
				writer.close();
			} catch (IOException e) { // swallow
				e.printStackTrace();
			}
			try {
				response.close();
			} catch (IOException e1) { // swallow
				e1.printStackTrace();
			}
			try {
				conn.close();
			} catch (IOException e2) { // swallow
				e2.printStackTrace();
			}
		}

		LOG.info(this.getClass().getName() + ".sendRequest(): result\n" + hostName + " " + result.trim());

		return result.trim();
	}

	/**
	 * getExtendedSkuInfo Gets extended sku information by sending a PLURQ
	 * message to the kiosk server. This is the same message used by
	 * getVendorFaxNumber() but this returns the entire PLURE message.
	 * 
	 * @param sku
	 *            - menards sku
	 * @return - ERROR or PLURE message
	 * @throws BrokerFailedException
	 */
	public String getExtendedSkuInfo(String sku) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sd = new SimpleDateFormat("yyyyMMddHHmmss");

		String message = StringUtils.rightPad(clientName, 10) + "0010001" + sd.format(cal.getTime()) + "PLURQ" + StringUtils.rightPad(sku, 16) + "EOM";

		responseMsg = sendRequest(message);

		// Check for a valid response.
		int msgLength = responseMsg.length();
		if ((msgLength != 478) || responseMsg.substring(31, 36).equals("ERROR")) {
			LOG.info(this.getClass().getName() + ".getExtendedInfo Request returned an error");
			return "ERROR";
		}

		return responseMsg;
	}

	/**
	 * updateSkuInventory Sends a request to the kiosk server to update the sku
	 * quantity on hand. If POS finds that the entered quantity is less than the
	 * minimum quantity the store should have, an order will be created in DCM.
	 * 
	 * @param sku
	 *            - the Menards SKU
	 * @param qty
	 *            - the quantity of the sku on hand
	 * @return
	 */
	public String updateSkuInventory(String sku, String qty) {
		if (sku == null || sku.length() != 7) {
			return ERROR;
		}

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sd = new SimpleDateFormat("yyyyMMddHHmmss");

		String message = StringUtils.rightPad(clientName, 10) + "0010001" + sd.format(cal.getTime()) + "SSINV" + sku
		/**
		 * Notes from POS regarding quantity: 1. The quantity is 8 digits with
		 * the format 9999.999 because that’s how it’s stored in the database.
		 * This means it will accept decimals, but ‘500 ‘,‘ 500’ or ‘00000500’
		 * are all fine also. 2. Large changes in inventory won’t be allowed. If
		 * the change is greater than a 10,000 qty gain/loss or $5,000 gain/loss
		 * then ERROR311 will be sent back. This is to match the rules for other
		 * inventory adjustment programs.
		 */
		+ StringUtils.rightPad(qty, 8) + "EOM";

		LOG.info("Sending update inventory request " + message);
		responseMsg = sendRequest(message);

		/**
		 * Here is a summary of possible error messages ERROR100 - Wrong length
		 * ERROR308 - Sku is not department 900 ERROR309 - Cannot find sku
		 * ERROR310 - Quantity is negative ERROR311 - Invalid quantity change -
		 * see quantity note
		 * 
		 * Successful Response: PRO9-KIOSK001000120070806141545SSSUCEOM
		 */
		if (responseMsg.indexOf("ERROR") > -1 || responseMsg.indexOf("SSSUC") < 0 || responseMsg.length() != 39) {
			LOG.info("SSINV message received unknown response " + responseMsg);
			return ERROR;
		}

		return responseMsg;
	}

	public String getResponse() {
		return responseMsg;
	}

	/**
	 * 
	 * confirm DevStore
	 * 
	 * @param storeNumber
	 *            storeNumber
	 * @return boolean boolean
	 */
	private static boolean isDevStore(Integer storeNumber) {
		return DEV_STORE.contains(storeNumber);
	}

}
