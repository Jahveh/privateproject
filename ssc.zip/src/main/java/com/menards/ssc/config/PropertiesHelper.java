package com.menards.ssc.config;

import java.util.Properties;

/**
 * <p>PropertiesHelper</p>
 * <p>properties helper</p>
 * <p>
 * properties helper
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class PropertiesHelper {

	private Properties p;

	/**
	 *Constructor with properties
	 */
	public PropertiesHelper() {
	}

	public Properties getProperties() {
		return p;
	}

	/**
	 * set properties
	 * @param props props
	 */
	public void setProperties(Properties props) {
		if (props == null) {
			throw new IllegalArgumentException("properties must be not null");
		}
		this.p = props;
	}

	/**
	 * get properties
	 * @param key key
	 * @return string string
	 */
	public String getProperty(String key) {
		return p.getProperty(key);
	}

	/**
	 * get string from properties
	 * @param key key
	 * @param defaultValue string
	 * @return string string
	 */
	public String getProperty(String key, String defaultValue) {
		String value = p.getProperty(key);
		if (value != null) {
			return value;
		}
		return defaultValue;
	}

}
