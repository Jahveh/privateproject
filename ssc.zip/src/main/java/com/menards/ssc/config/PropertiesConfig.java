package com.menards.ssc.config;

import java.util.Properties;

/**
 * <p>properties config</p>
 * <p> properties config </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class PropertiesConfig {

	private static PropertiesHelper helper = new PropertiesHelper();

	/**
	 * get properties helper
	 * @return PropertiesHelper PropertiesHelper
	 */
	private static PropertiesHelper getPropertiesHelper() {
		return helper;
	}

	/**
	 * set properties via spring config
	 * @param properties properties
	 */
	public void setProperties(Properties properties) {
		helper.setProperties(properties);
	}

	/**
	 * get default store number
	 * @return string string
	 */
	public static String getDefaultStoreNumber() {
		return getPropertiesHelper().getProperty("default_store_number", "3053");
	}

	/**
	 * get value by key
	 * @param key key
	 * @return string string
	 */
	public static String getValue(String key) {
		return getPropertiesHelper().getProperty(key);
	}

}
