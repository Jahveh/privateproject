package com.menards.ssc.listener.navigation;

import javax.annotation.Resource;
import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.menards.ssc.service.catalog.CategoryTreeService;
import com.menards.ssc.service.security.MenardSecurityService;

/**
 *
 * <p>CategoryPreLoader</p>
 * <p>An implementation of Spring ApplicationListener</p>
 * <p>
 * Upon application context get refreshed, the implementation loads categories from the underlying database, 
 * and put the whole category tree into ServletContext in the below three forms for easy future use.
 * 1) Put the whole category tree in the ServletContext under the key "categoryTree" 
 * 2) Put the CategoryId and CategoryTreeNode mapping in the ServletContext under the key "categoryTreeDictionary"
 * 3) Put the HTML representation of the whole category tree in the ServletContext under the key "htmlCategoryTree"
 *  
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
@Component
public class CategoryPreLoader implements ApplicationListener<ContextRefreshedEvent>, Ordered {
	
	public static final Logger LOG = Logger.getLogger(CategoryPreLoader.class);

	@Autowired
	private CategoryTreeService categoryTreeService;
	
	@Resource(name = "menardSecurityService")
	private MenardSecurityService menardSecurityService;

	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		ServletContext servletContext = ((WebApplicationContext) event.getApplicationContext()).getServletContext();
		categoryTreeService.loadCategoryTreeToServletContext(servletContext);
		menardSecurityService.loadSecurityConfig();
	}

	@Override
	public int getOrder() {
		return 10;
	}

}
