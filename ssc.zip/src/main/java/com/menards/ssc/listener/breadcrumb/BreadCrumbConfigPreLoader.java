package com.menards.ssc.listener.breadcrumb;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletContext;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.menards.ssc.domain.breadcrumb.BreadCrumbConfig;
import com.menards.ssc.service.breadcrumb.BreadCrumbConfigService;

/**
 * 
 * <p>BreadCrumbConfigPreLoader</p>
 * <p>A Spring application context listener that load all the bread crumb configs 
 * from the DB on application startup.</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
@Component
public class BreadCrumbConfigPreLoader implements ApplicationListener<ContextRefreshedEvent>, Ordered {
	public static final String BREAD_CRUMB_CONFIG_MAP_SERVLET_CONTEXT_KEY = "breadCrumbConfigList";

	@Resource(name = "breadCrumbConfigService")
	private BreadCrumbConfigService breadCrumbConfigService;

	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		List<BreadCrumbConfig> allConfigs = breadCrumbConfigService.getAllBreadCrumbConfigs();
		Map<String, List<BreadCrumbConfig>> breadCrumbConfigMap = buildBreadCrumbConfigMap(allConfigs);
		ServletContext servletContext = ((WebApplicationContext) event.getApplicationContext()).getServletContext();
		servletContext.setAttribute(BREAD_CRUMB_CONFIG_MAP_SERVLET_CONTEXT_KEY, breadCrumbConfigMap);
	}

	/**
	 * 
	 * build a map to contain configurations
	 * @param allConfigs allConfigs
	 * @return BreadCrumbConfigMap
	 */
	private Map<String, List<BreadCrumbConfig>> buildBreadCrumbConfigMap(List<BreadCrumbConfig> allConfigs) {
		Map<String, List<BreadCrumbConfig>> returnMap = new HashMap<String, List<BreadCrumbConfig>>();
		for (BreadCrumbConfig config : allConfigs) {
			if (returnMap.get(config.getPageUrl()) == null) {
				returnMap.put(config.getPageUrl(), new ArrayList<BreadCrumbConfig>());
			}
			returnMap.get(config.getPageUrl()).add(config);
		}
		for (List<BreadCrumbConfig> list : returnMap.values()) {
			Collections.sort(list);
		}
		return returnMap;
	}

	@Override
	public int getOrder() {
		return 20;
	}

}
