/*
 * Sku
 * 
 * 2014-04-30
 *
 * Copyright (c) 2014
 * Menard Inc.
 */
package com.menards.ssc.webservice.dto;

/**
 * SKU domain class for Web service client
 *
 * @author james.ni
 */
public class Sku {

    private Long id;
    private String skuCode;
    private String menardSku;
    private String description;
    private Boolean isActive;
    private String availability;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSkuCode() {
        return skuCode;
    }

    public void setSkuCode(String skuCode) {
        this.skuCode = skuCode;
    }

    public String getMenardSku() {
        return menardSku;
    }

    public void setMenardSku(String menardSku) {
        this.menardSku = menardSku;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    @Override
    public String toString() {
        return "Sku{" +
                "id=" + id +
                ", skuCode='" + skuCode + '\'' +
                ", menardSku='" + menardSku + '\'' +
                ", description='" + description + '\'' +
                ", isActive=" + isActive +
                ", availability='" + availability + '\'' +
                '}';
    }
}