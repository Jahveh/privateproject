package com.menards.ssc.webservice;

import com.menards.ssc.webservice.dto.Attribute;
import com.menards.ssc.webservice.dto.Category;
import com.menards.ssc.webservice.dto.Product;
import com.menards.ssc.webservice.dto.Sku;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import java.util.ArrayList;

/**
 * Facade of all public web services of Menards SSC
 *
 * @author james.ni
 */
@WebService
public interface MenardsWebService {

    /**
     * get product by product ID
     *
     * @param productId
     * @return
     */
    @WebMethod(operationName = "getProduct")
    @WebResult(name = "product")
    Product getProduct(@WebParam(name = "productId") Long productId, @WebParam(name = "storeNumber") int storeNumber);


    /**
     * get SKUs by product ID
     *
     * @param productId
     * @return
     */
    @WebMethod(operationName = "getSkus")
    @WebResult(name = "skuList")
    ArrayList<Sku> getSkus(@WebParam(name = "productId") Long productId, @WebParam(name = "storeNumber") int storeNumber);

    /**
     * get SKU by SKU ID
     *
     * @param skuId
     * @return
     */
    @WebMethod(operationName = "getSku")
    @WebResult(name = "sku")
    Sku getSku(@WebParam(name = "skuId") Long skuId, @WebParam(name = "storeNumber") int storeNumber);

    /**
     * Get category by ID
     *
     * @param categoryId
     * @return
     */
    @WebMethod(operationName = "getCategoryById")
    @WebResult(name = "category")
    Category getCategoryById(@WebParam(name = "categoryId") Long categoryId);

    /**
     * Get category by URL
     *
     * @param path
     * @return
     */
    @WebMethod(operationName = "getCategoryByPath")
    @WebResult(name = "category")
    Category getCategoryByPath(@WebParam(name = "path") String path);

    /**
     * Get category attributes by category ID
     *
     * @param categoryId
     * @return
     */
    @WebMethod(operationName = "getCategoryAttributesById")
    @WebResult(name = "categoryAttributes")
    ArrayList<Attribute> getCategoryAttributesById(@WebParam(name = "categoryId") Long categoryId);

    /**
     * Get category attributes by category path
     *
     * @param path
     * @return
     */
    @WebMethod(operationName = "getCategoryAttributesByPath")
    @WebResult(name = "categoryAttributes")
    ArrayList<Attribute> getCategoryAttributesByPath(@WebParam(name = "path") String path);

    /**
     * Get product attributes by product ID
     *
     * @param productId
     * @return
     */
    @WebMethod(operationName = "getProductAttributes")
    @WebResult(name = "productAttributes")
    ArrayList<Attribute> getProductAttributes(@WebParam(name = "productId") Long productId);

    /**
     * Get product attributes by SKU ID
     *
     * @param skuId
     * @return
     */
    @WebMethod(operationName = "getSkuAttributes")
    @WebResult(name = "skuAttributes")
    ArrayList<Attribute> getSkuAttributes(@WebParam(name = "skuId") Long skuId);


///////////////////////////////////////////////////////////////////////////////////////////
// TODO: uncomment the following interfaces to add more web services, do not delete
///////////////////////////////////////////////////////////////////////////////////////////
//    /**
//     * get products by category ID
//     *
//     * @param categoryId
//     * @return
//     */
//    @WebMethod(operationName = "getProductsByCategoryId")
//    List<Product> getProductsByCategoryId(Long categoryId, int storeNumber);
//
//    /**
//     * get products by category path
//     *
//     * @param path
//     * @return
//     */
//    @WebMethod(operationName = "getProductsByCategoryPath")
//    List<Product> getProductsByCategoryPath(String path, int storeNumber);
//
//    /**
//     * get subcategories by category ID
//     *
//     * @param categoryId
//     * @return
//     */
//    @WebMethod(operationName = "getSubCategoriesById")
//    List<Category> getSubCategoriesById(Long categoryId);
//
//    /**
//     * get subcategories by category path
//     *
//     * @param path
//     * @return
//     */
//    @WebMethod(operationName = "getSubCategoriesByPath")
//    List<Category> getSubCategoriesByPath(String path);
//
//    /**
//     * Search products by model number
//     *
//     * @param modelNumber
//     * @return
//     */
//    @WebMethod(operationName = "searchProductsByModelNumber")
//    List<Product> searchProductsByModelNumber(String modelNumber);
///////////////////////////////////////////////////////////////////////////////////////////

}
