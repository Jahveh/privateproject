package com.menards.ssc.webservice.adapter;

import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.webservice.dto.Attribute;
import com.menards.ssc.webservice.dto.Sku;

import org.broadleafcommerce.core.catalog.domain.ProductAttribute;
import org.broadleafcommerce.core.catalog.domain.SkuAttribute;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Convert SSC SKU for Web service client
 *
 * @author james.ni
 */
public class SkuAdapter {

    public static Sku convert(org.broadleafcommerce.core.catalog.domain.Sku blSku) {
        if (blSku != null) {
            Sku sku = new Sku();
            MenardSku menardSku = (MenardSku) blSku;
            sku.setId(menardSku.getId());
            sku.setDescription(menardSku.getDescription());
            sku.setIsActive(menardSku.isActive());
            sku.setMenardSku(menardSku.getMenardSku());
            sku.setSkuCode(menardSku.getSkuCode());
            return sku;
        }
        return null;
    }

    public static ArrayList<Sku> convert(List<org.broadleafcommerce.core.catalog.domain.Sku> blSkus) {
        if (blSkus != null && !blSkus.isEmpty()) {
            ArrayList<Sku> skus = new ArrayList<>();
            for (org.broadleafcommerce.core.catalog.domain.Sku blSku : blSkus) {
                skus.add(SkuAdapter.convert(blSku));
            }
            return skus;
        }
        return null;
    }

    public static ArrayList<Attribute> convertAttributes(List<SkuAttribute> attributes) {
        if (attributes != null && !attributes.isEmpty()) {
            ArrayList<Attribute> attributeList = new ArrayList<>(attributes.size());
            for (SkuAttribute pAttr : attributes) {
                Attribute attribute = new Attribute();
                attribute.setName(pAttr.getName());
                attribute.setValue(pAttr.getValue());
                attributeList.add(attribute);
            }
            return attributeList;
        }
        return null;
    }
}