package com.menards.ssc.webservice;

import com.menards.ssc.dao.product.MenardProductDao;
import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardSkuDTO;
import com.menards.ssc.enums.ProductVisibility;
import com.menards.ssc.enums.SkuVisibility;
import com.menards.ssc.service.catalog.MenardCatalogService;
import com.menards.ssc.service.product.MenardProductService;
import com.menards.ssc.state.MenardGetStatus;
import com.menards.ssc.webservice.adapter.CategoryAdapter;
import com.menards.ssc.webservice.adapter.ProductAdapter;
import com.menards.ssc.webservice.adapter.SkuAdapter;
import com.menards.ssc.webservice.dto.Attribute;
import com.menards.ssc.webservice.dto.Category;
import com.menards.ssc.webservice.dto.Product;
import com.menards.ssc.webservice.dto.Sku;

import org.apache.log4j.Logger;
import org.broadleafcommerce.core.catalog.domain.CategoryAttribute;
import org.broadleafcommerce.core.catalog.domain.ProductAttribute;
import org.broadleafcommerce.core.catalog.domain.SkuAttribute;

import javax.annotation.Resource;
import javax.jws.WebService;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Menards public web services
 *
 * @author james.ni
 */
@WebService(
        endpointInterface = "com.menards.ssc.webservice.MenardsWebService",
        serviceName = "MenardsWebService"
)
public class MenardsWebServiceImpl implements MenardsWebService {

    private static final int DEFAULT_STORE_NUMBER = 3053;

    private Logger logger = Logger.getLogger(MenardsWebServiceImpl.class);

    @Resource(name = "blProductDao")
    private MenardProductDao productDao;

    @Resource(name = "blCatalogService")
    private MenardCatalogService catalogService;

    @Resource(name = "menardProductService")
    private MenardProductService menardProductService;

    private int getStoreNumber(int storeNumber) {
        if (storeNumber > 0) {
            return storeNumber;
        }
        return DEFAULT_STORE_NUMBER;
    }

    @Override
    public Product getProduct(Long productId, int storeNumber) {
        Product product = null;
        MenardProduct menardProduct = productDao.getMenardProductById(productId);
        if (menardProduct != null) {
            product = ProductAdapter.convert(menardProduct);

            // get sku status for all SKUs
            Map<String, String> getSkuToStatusCodeMap = catalogService.getSkuToStatusCodeMap(menardProduct, getStoreNumber(storeNumber));

            // set product availability
            ProductVisibility productAvailability = MenardGetStatus.getProductVisibility(menardProduct, getSkuToStatusCodeMap);
            product.setAvailability(productAvailability.name());

        } else {
            logger.error("Product not found, product ID: " + productId);
        }
        return product;
    }

    @Override
    public Sku getSku(Long skuId, int storeNumber) {
        Sku sku = null;
        MenardSkuDTO menardSkuDto = catalogService.getMenardSkuDTOBySkuId(skuId, getStoreNumber(storeNumber));
        if (menardSkuDto != null) {
            sku = SkuAdapter.convert(menardSkuDto.getSku());
            SkuVisibility skuVisibility = MenardGetStatus.getSkuVisibility(menardSkuDto);
            sku.setAvailability(skuVisibility.name());
        } else {
            logger.error("SKU not found, SKU ID: " + skuId);
        }
        return sku;
    }

    @Override
    public ArrayList<Sku> getSkus(Long productId, int storeNumber) {
        ArrayList<Sku> skus = null;
        MenardProduct menardProduct = productDao.getMenardProductById(productId);
        if (menardProduct != null) {
            skus = SkuAdapter.convert(menardProduct.getSkus());

            // get sku status for all SKUs
            Map<String, String> getSkuToStatusCodeMap = catalogService.getSkuToStatusCodeMap(menardProduct, getStoreNumber(storeNumber));

            // set SKU availability
            Map<Long, SkuVisibility> skuToAvailabilityMap = MenardGetStatus.getSkuToVisibilityMap(menardProduct, getSkuToStatusCodeMap);
            for (Sku sku : skus) {
                SkuVisibility skuAvailability = skuToAvailabilityMap.get(sku.getId());
                sku.setAvailability(skuAvailability.name());
            }
        } else {
            logger.error("Product not found, product ID: " + productId);
        }

        return skus;
    }

    @Override
    public Category getCategoryById(Long categoryId) {
        Category category = null;
        org.broadleafcommerce.core.catalog.domain.Category blCategory = catalogService.findCategoryById(categoryId);
        if (blCategory != null) {
            category = CategoryAdapter.convert(blCategory);
        }
        return category;
    }

    @Override
    public Category getCategoryByPath(String categoryPath) {
        Category category = null;
        org.broadleafcommerce.core.catalog.domain.Category blCategory = catalogService.findCategoryByURI(categoryPath);
        if (blCategory != null) {
            category = CategoryAdapter.convert(blCategory);
        }
        return category;
    }

    @Override
    public ArrayList<Attribute> getCategoryAttributesById(Long categoryId) {
        List<CategoryAttribute> categoryAttributes = catalogService.getCategoryAttributes(categoryId);
        return CategoryAdapter.convertAttributes(categoryAttributes);
    }

    @Override
    public ArrayList<Attribute> getCategoryAttributesByPath(String categoryPath) {
        List<CategoryAttribute> categoryAttributes = catalogService.getCategoryAttributes(categoryPath);
        return CategoryAdapter.convertAttributes(categoryAttributes);
    }

    @Override
    public ArrayList<Attribute> getProductAttributes(Long productId) {
        List<ProductAttribute> productAttributes = menardProductService.getProductAttributes(productId);
        return ProductAdapter.convertAttributes(productAttributes);
    }

    @Override
    public ArrayList<Attribute> getSkuAttributes(Long skuId) {
        List<SkuAttribute> skuAttributes = menardProductService.getSkuAttributes(skuId);
        return SkuAdapter.convertAttributes(skuAttributes);
    }


///////////////////////////////////////////////////////////////////////////////////////////
//    TODO: implement the following methods, do not delete
///////////////////////////////////////////////////////////////////////////////////////////
//    @Override
//    public List<Product> getProductsByCategoryId(Long categoryId, int storeNumber) {
//        return null;
//    }
//
//    @Override
//    public List<Product> getProductsByCategoryPath(String path, int storeNumber) {
//        return null;
//    }
//
//    @Override
//    public List<Category> getSubCategoriesById(Long categoryId) {
//        return null;
//    }
//
//    @Override
//    public List<Category> getSubCategoriesByPath(String path) {
//        return null;
//    }
//
//    @Override
//    public List<Product> searchProductsByModelNumber(String modelNumber) {
//        return null;
//    }
//
///////////////////////////////////////////////////////////////////////////////////////////
}
