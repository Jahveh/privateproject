/*
 * CategoryAdapter
 * 
 * 2014-04-30
 *
 * Copyright (c) 2014
 * Menard Inc.
 */
package com.menards.ssc.webservice.adapter;

import com.menards.ssc.webservice.dto.Attribute;
import com.menards.ssc.webservice.dto.Category;

import org.broadleafcommerce.core.catalog.domain.CategoryAttribute;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Convert SSC category for Web service client
 *
 * @author james.ni
 */
public class CategoryAdapter {

    public static Category convert(org.broadleafcommerce.core.catalog.domain.Category blCategory) {
        Category category = null;
        if (blCategory != null) {
            category = new Category();
            category.setId(blCategory.getId());
            category.setArchived(blCategory.isActive());
            category.setName(blCategory.getName());
            category.setUrl(blCategory.getUrl());
            category.setUrlKey(blCategory.getUrlKey());
            category.setDescription(blCategory.getDescription());
            category.setLongDescription(blCategory.getLongDescription());
            category.setDefaultParentCategoryId(blCategory.getDefaultParentCategory().getId());
        }
        return category;
    }

    public static ArrayList<Attribute> convertAttributes(List<CategoryAttribute> attributes) {
        if (attributes != null && !attributes.isEmpty()) {
            ArrayList<Attribute> attributeList = new ArrayList<>(attributes.size());
            for (CategoryAttribute pAttr : attributes) {
                Attribute attribute = new Attribute();
                attribute.setName(pAttr.getName());
                attribute.setValue(pAttr.getValue());
                attributeList.add(attribute);
            }
            return attributeList;
        }
        return null;
    }
}