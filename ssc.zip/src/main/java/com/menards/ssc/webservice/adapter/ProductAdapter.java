package com.menards.ssc.webservice.adapter;

import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.webservice.dto.Attribute;
import com.menards.ssc.webservice.dto.Product;

import org.broadleafcommerce.core.catalog.domain.ProductAttribute;

import java.util.ArrayList;
import java.util.List;

/**
 * Convert SSC product for Web service client
 *
 * @author james.ni
 */
public class ProductAdapter {

    public static Product convert(MenardProduct menardProduct) {
        if (menardProduct != null) {
            Product product = new Product();
            product.setId(menardProduct.getId());
            product.setModelNum(menardProduct.getModelNum());
            product.setUrl(menardProduct.getUrl());
            product.setDefaultCategoryId(menardProduct.getDefaultCategory().getId());
            return product;
        }
        return null;
    }

    public static ArrayList<Attribute> convertAttributes(List<ProductAttribute> attributes) {
        if (attributes != null && !attributes.isEmpty()) {
            ArrayList<Attribute> attributeList = new ArrayList<>(attributes.size());
            for (ProductAttribute pAttr : attributes) {
                Attribute attribute = new Attribute();
                attribute.setName(pAttr.getName());
                attribute.setValue(pAttr.getValue());
                attributeList.add(attribute);
            }
            return attributeList;
        }
        return null;
    }
}