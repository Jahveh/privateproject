/*
 * Category
 * 
 * 2014-04-30
 *
 * Copyright (c) 2014
 * Menard Inc.
 */
package com.menards.ssc.webservice.dto;

/**
 * Category domain for Web service client
 *
 * @author james.ni
 */
public class Category {

    private Long id;
    private String name;
    private String url;
    private String urlKey;
    private String description;
    private String longDescription;
    private Boolean archived;
    private long defaultParentCategoryId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrlKey() {
        return urlKey;
    }

    public void setUrlKey(String urlKey) {
        this.urlKey = urlKey;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLongDescription() {
        return longDescription;
    }

    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    public Boolean getArchived() {
        return archived;
    }

    public void setArchived(Boolean archived) {
        this.archived = archived;
    }

    public long getDefaultParentCategoryId() {
        return defaultParentCategoryId;
    }

    public void setDefaultParentCategoryId(long defaultParentCategoryId) {
        this.defaultParentCategoryId = defaultParentCategoryId;
    }

    @Override
    public String toString() {
        return "Category{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", url='" + url + '\'' +
                ", urlKey='" + urlKey + '\'' +
                ", description='" + description + '\'' +
                ", longDescription='" + longDescription + '\'' +
                ", archived=" + archived +
                ", defaultParentCategoryId=" + defaultParentCategoryId +
                '}';
    }
}