/*
 * Product
 * 
 * 2014-04-30
 *
 * Copyright (c) 2014
 * Menard Inc.
 */
package com.menards.ssc.webservice.dto;

/**
 * Product domain class for Web service client
 *
 * @author james.ni
 */
public class Product {
    private Long id;
    private String modelNum;
    private String url;
    private Long defaultCategoryId;
    private String availability;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getModelNum() {
        return modelNum;
    }

    public void setModelNum(String modelNum) {
        this.modelNum = modelNum;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Long getDefaultCategoryId() {
        return defaultCategoryId;
    }

    public void setDefaultCategoryId(Long defaultCategoryId) {
        this.defaultCategoryId = defaultCategoryId;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", modelNum='" + modelNum + '\'' +
                ", url='" + url + '\'' +
                ", defaultCategoryId=" + defaultCategoryId +
                ", availability='" + availability + '\'' +
                '}';
    }
}