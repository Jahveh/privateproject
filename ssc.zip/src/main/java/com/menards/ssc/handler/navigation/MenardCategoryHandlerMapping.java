package com.menards.ssc.handler.navigation;

import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.broadleafcommerce.common.web.BroadleafRequestContext;
import org.broadleafcommerce.core.web.catalog.CategoryHandlerMapping;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.menards.ssc.domain.navigation.CategoryTreeNode;
import com.menards.ssc.service.catalog.CategoryTreeService;

/**
 *
 * <p>MenardCategoryHandlerMapping</p> 
 * <p>
 * An implementation of the HandlerMapping for category navigation, this implementation 
 * get the requesting category based on the URL and retrieve its corresponding sub-categoryies and 
 * save it into the HttpRequest for page rendering use.
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class MenardCategoryHandlerMapping extends CategoryHandlerMapping {
	private String controllerName = "blCategoryController";

	public static final String CURRENT_CATEGORY_ATTRIBUTE_NAME = "category";

	@Override
	protected Object getHandlerInternal(HttpServletRequest request) {
		BroadleafRequestContext context = BroadleafRequestContext.getBroadleafRequestContext();
		@SuppressWarnings("unchecked")
		Map<Long, CategoryTreeNode> categoryTreeNodeDictionary = (Map<Long, CategoryTreeNode>) request.getSession()
				.getServletContext().getAttribute(CategoryTreeService.CATEGORY_TREE_DICTIONARY_SERVLET_CONTEXT_KEY);
		if (context != null && context.getRequestURIWithoutContext() != null) {
			CategoryTreeNode categoryTreeNode = getCategoryTreeNodeByUri(context.getRequestURIWithoutContext(),
					categoryTreeNodeDictionary);

			if (categoryTreeNode != null) {
				context.getRequest().setAttribute(CURRENT_CATEGORY_ATTRIBUTE_NAME, categoryTreeNode);
				setUpBreadCrumb(request, categoryTreeNode);
				return controllerName;
			}
		}
		return null;
	}

	private void setUpBreadCrumb(HttpServletRequest request, CategoryTreeNode categoryTreeNode) {
		ServletContext servletContext = request.getSession().getServletContext();
		ApplicationContext applicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
		CategoryTreeService categoryTreeService = applicationContext.getBean("categoryTreeService",
				CategoryTreeService.class);
		categoryTreeService.setUpBreadCrumb(request, categoryTreeNode);
	}
	
	/**
	 *
	 * Get Category Tree Node By Uri
	 * @param url url
	 * @param categoryTreeNodeDictionary categoryTreeNodeDictionary
	 * @return CategoryTreeNode CategoryTreeNode
	 */
	private CategoryTreeNode getCategoryTreeNodeByUri(String url, Map<Long, CategoryTreeNode> categoryTreeNodeDictionary) {
		CategoryTreeNode returnNode = null;
		String urlStr = url;
		if (urlStr.indexOf("/login") > 0 || urlStr.indexOf("rest/category") > 0) {
			urlStr = "/";
		}
		for (CategoryTreeNode categoryTreeNode : categoryTreeNodeDictionary.values()) {
			if (urlStr.equals(categoryTreeNode.getUrl())) {
				returnNode = categoryTreeNode;
				break;
			}
		}
		return returnNode;
	}
}
