package com.menards.ssc.state;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.broadleafcommerce.core.catalog.domain.ProductAttribute;

import com.menards.ssc.constants.ProductAttributeKey;
import com.menards.ssc.domain.catalog.BaseProductDTO;
import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.catalog.MenardSkuDTO;
import com.menards.ssc.enums.ProductVisibility;
import com.menards.ssc.enums.SkuStatus;
import com.menards.ssc.enums.SkuVisibility;
import com.menards.ssc.util.MenardUtil;

import org.broadleafcommerce.core.catalog.domain.Sku;

/**
 * <p>MenardGetStatus</p>
 * <p>get sku/product visibility</p>
 * <p>
 * get sku/product visibility
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public abstract class MenardGetStatus {

	/**
	 * get sku visibility according sku status
	 * @param skuDTO skuDTO
	 * @return SkuVisibility SkuVisibility
	 */
	public static SkuVisibility getSkuVisibility(MenardSkuDTO skuDTO) {
		String skuStatusCode = skuDTO.getSkuStatusCode();
		if (StringUtils.isEmpty(skuStatusCode)) {
			return SkuVisibility.DELETED;
		}
		int status = Integer.valueOf(skuStatusCode);
		SkuStatus skuStatus = SkuStatus.getSkuStatusByCode(status);
		SkuVisibility skuVisibility = SkuVisibility.DELETED;
		switch (skuStatus) {
			case SPECIAL_ORDER: // 4
				skuVisibility = SkuVisibility.SPECIAL_ORDER;
				break;
			case DC_SPECIAL_ORDER: // 5
				skuVisibility = SkuVisibility.SPECIAL_ORDER;
				break;
			case SEASONAL: // 2
				if (isStockOrderable(skuDTO)) {
					skuVisibility = SkuVisibility.STOCK_ORDERABLE;
				}
				break;
			case STOCK: // 0
				if (isDcmOrder(skuDTO)) {
					if (isStockOrderable(skuDTO)) {
						skuVisibility = SkuVisibility.STOCK_ORDERABLE;
					} else {
						skuVisibility = SkuVisibility.STOCK_NOT_ORDERABLE;
					}
				} else {
					skuVisibility = SkuVisibility.DELETED;
				}
				break;

			case DISCONTINUED: // 1
				break;
			case DELETED: // 3
				break;
			default:
		}

		return skuVisibility;

	}

	/**
	 * according to product attribute "DCM"
	 * @param skuDTO MenardSkuDTO
	 * @return boolean boolean
	 */
	private static boolean isDcmOrder(MenardSkuDTO skuDTO) {
		BaseProductDTO baseDto = new BaseProductDTO((MenardProduct) skuDTO.getSku().getProduct());
		String dcm = baseDto.getAttrAsString(ProductAttributeKey.DCM);
		return MenardUtil.getBooleanValue(dcm);
	}

	/**
	* determine is stock order able
	* @param skuDTO skuDTO
	* @return boolean boolean
	*/
	public static boolean isStockOrderable(MenardSkuDTO skuDTO) {
		if (skuDTO == null || skuDTO.getSku() == null) {
			return false;
		}

		String menardSku = skuDTO.getMenardSku();
		if (StringUtils.isNotEmpty(skuDTO.getSkuStatusCode()) && StringUtils.isEmpty(menardSku)) {
			// productcode removed, sku code instead
			menardSku = skuDTO.getSku().getSkuCode();
		}

		String vendor = StringUtils.EMPTY;

		MenardProduct product = (MenardProduct) skuDTO.getSku().getProduct();
		ProductAttribute attr = product.getProductAttributes().get(ProductAttributeKey.VENDOR);
		if (attr != null) {
			vendor = attr.getValue();
		}

		if (StringUtils.isNotEmpty(menardSku) && !"00".equals(menardSku.substring(1, 3))
				&& (menardSku.startsWith("7") || menardSku.startsWith("5") || "belwith".equalsIgnoreCase(vendor))) {
			return true;
		}

		return false;

	}

	/**
	* get product visibility
	* @param skuDTOs MenardSkuDTO list
	* @return product visibility
	*/
	public static ProductVisibility getProductVisibility(List<MenardSkuDTO> skuDTOs) {
		if (CollectionUtils.isEmpty(skuDTOs)) {
			return null;
		}
		boolean hasSpecialOrder = false;
		for (MenardSkuDTO skuDTO : skuDTOs) {
			SkuVisibility skuVisibility = MenardGetStatus.getSkuVisibility(skuDTO);
			switch (skuVisibility) {
				case STOCK_NOT_ORDERABLE: // 0
					return ProductVisibility.STOCK;
				case STOCK_ORDERABLE: // 1
					return ProductVisibility.STOCK;
				case SPECIAL_ORDER: // 2
					hasSpecialOrder = true;
					break;
				default:
					break;
			}
		}

		if (hasSpecialOrder) {
			return ProductVisibility.SPECIAL_ORDER;
		}

		return ProductVisibility.DELETED;
	}

    public static ProductVisibility getProductVisibility(MenardProduct menardProduct, Map<String, String> skuToStatusCodeMap) {
        if (CollectionUtils.isEmpty(menardProduct.getSkus())) {
            return null;
        }
        boolean hasSpecialOrder = false;
        for (Sku sku : menardProduct.getSkus()) {
            MenardSku menardSku = (MenardSku) sku;
            String menardSkuCode = menardSku.getMenardSku();
            MenardSkuDTO skuDto = new MenardSkuDTO(menardSku);
            if (StringUtils.isBlank(menardSkuCode)
                    && StringUtils.isNotBlank(menardSku.getSkuCode())
                    && menardSku.getSkuCode().length() >= 7) {
                menardSkuCode = menardSku.getSkuCode().substring(0, 7);
            }
            skuDto.setSkuStatusCode(skuToStatusCodeMap.get(menardSkuCode));
            SkuVisibility skuVisibility = MenardGetStatus.getSkuVisibility(skuDto);
            switch (skuVisibility) {
                case STOCK_NOT_ORDERABLE: // 0
                    return ProductVisibility.STOCK;
                case STOCK_ORDERABLE: // 1
                    return ProductVisibility.STOCK;
                case SPECIAL_ORDER: // 2
                    hasSpecialOrder = true;
                    break;
                default:
                    break;
            }
        }

        if (hasSpecialOrder) {
            return ProductVisibility.SPECIAL_ORDER;
        }

        return ProductVisibility.DELETED;
    }

    public static Map<Long, SkuVisibility> getSkuToVisibilityMap(MenardProduct menardProduct, Map<String, String> skuToStatusCodeMap) {
        if (CollectionUtils.isEmpty(menardProduct.getSkus())) {
            return null;
        }
        Map<Long, SkuVisibility> skuToAvailabilityMap = new HashMap<>();
        for (Sku sku : menardProduct.getSkus()) {
            MenardSku menardSku = (MenardSku) sku;
            String menardSkuCode = menardSku.getMenardSku();
            MenardSkuDTO skuDto = new MenardSkuDTO(menardSku);
            if (StringUtils.isBlank(menardSkuCode)
                    && StringUtils.isNotBlank(menardSku.getSkuCode())
                    && menardSku.getSkuCode().length() >= 7) {
                menardSkuCode = menardSku.getSkuCode().substring(0, 7);
            }
            skuDto.setSkuStatusCode(skuToStatusCodeMap.get(menardSkuCode));
            SkuVisibility skuVisibility = MenardGetStatus.getSkuVisibility(skuDto);
            skuToAvailabilityMap.put(sku.getId(), skuVisibility);
        }

        return skuToAvailabilityMap;
    }

    public static SkuVisibility getSkuVisibility(MenardSku menardSku, String skuStatusCode) {
            if (menardSku == null) {
                return null;
            }
            String menardSkuCode = menardSku.getMenardSku();
            MenardSkuDTO skuDto = new MenardSkuDTO(menardSku);
            if (StringUtils.isBlank(menardSkuCode)
                    && StringUtils.isNotBlank(menardSku.getSkuCode())
                    && menardSku.getSkuCode().length() >= 7) {
                menardSkuCode = menardSku.getSkuCode().substring(0, 7);
            }
            skuDto.setSkuStatusCode(skuStatusCode);
            SkuVisibility skuVisibility = MenardGetStatus.getSkuVisibility(skuDto);

            return skuVisibility;
        }
}
