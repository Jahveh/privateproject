package com.menards.ssc.service.catalog;

import org.apache.log4j.Logger;
import org.broadleafcommerce.core.search.service.SearchService;

import com.menards.ssc.domain.catalog.SearchCriteria;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.catalog.SkuDTO;
import com.menards.ssc.domain.sign.Sign;

/**
 * <p>MenardSearchService</p>
 * <p>Support class for search function</p>
 * <p>
 * Each method is responsible for one type of search
 * , sku search, sign search and sale sign search.
 *
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public interface MenardSearchService extends SearchService {

	public static final Logger LOG = Logger.getLogger(SearchService.class);

	/**
	 * Search for pages of sku according to the criteria.
	 * There are two types of query string one is digital
	 * the other is text. So judgement needs to be make when
	 * search for skus.
	 *
	 * @param criteria SearchCriteria
	 * @return SearchResult<T>
	 */
	public SearchResult<SkuDTO> findSkuPage(SearchCriteria criteria);

	/**
	 * Find the hierarchy product desc
	 * @param criteria SearchCriteria
	 * @return SearchResult<T>
	 */
	public SearchResult<SkuDTO> findProductDescPage(SearchCriteria criteria);

	/**
	 * The result is a combination of sign database and skuman database
	 *
	 * Search sign database for sign
	 * @param criteria SearchCriteria
	 * @return SearchResult<Sign>
	 */
	public SearchResult<Sign> findSignPage(SearchCriteria criteria);

	/**
	 * Search for sale sign
	 * @param criteria SearchCriteria
	 * @return SearchResult<Sign>
	 */
	public SearchResult<Sign> findSaleSignPage(SearchCriteria criteria);

}
