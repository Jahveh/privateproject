package com.menards.ssc.service.skustatus;

/**
 * 
 * <p>MenardDerivedStatus</p>

 */
public class MenardDerivedStatus {

	private Integer storeNumber;
	private Integer skuNumber;
	private String derivedStatusCode;

	/**
	 * 
	 *Constructor
	 */
	MenardDerivedStatus() {
		super();
	}

	/**
	 * 
	 *Constructor 
	 *@param storeNumber storeNumber
	 *@param skuNumber skuNumber
	 *@param derivedStatusCode derivedStatusCode
	 */
	MenardDerivedStatus(Integer storeNumber, Integer skuNumber, String derivedStatusCode) {
		super();
		this.storeNumber = storeNumber;
		this.skuNumber = skuNumber;
		this.derivedStatusCode = derivedStatusCode;
	}

	public Integer getStoreNumber() {
		return storeNumber;
	}

	public void setStoreNumber(Integer storeNumber) {
		this.storeNumber = storeNumber;
	}

	public Integer getSkuNumber() {
		return skuNumber;
	}

	public void setSkuNumber(Integer skuNumber) {
		this.skuNumber = skuNumber;
	}

	public String getDerivedStatusCode() {
		return derivedStatusCode;
	}

	public void setDerivedStatusCode(String derivedStatusCode) {
		this.derivedStatusCode = derivedStatusCode;
	}
}
