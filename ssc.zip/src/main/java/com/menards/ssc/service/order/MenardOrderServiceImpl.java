package com.menards.ssc.service.order;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.catalog.domain.Sku;
import org.broadleafcommerce.core.order.domain.DiscreteOrderItem;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.domain.OrderAttribute;
import org.broadleafcommerce.core.order.domain.OrderAttributeImpl;
import org.broadleafcommerce.core.order.domain.OrderItem;
import org.broadleafcommerce.core.order.domain.OrderItemAttribute;
import org.broadleafcommerce.core.order.domain.OrderItemAttributeImpl;
import org.broadleafcommerce.core.order.service.OrderServiceImpl;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.broadleafcommerce.core.order.service.type.OrderItemType;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.broadleafcommerce.profile.web.core.CustomerState;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.constants.OrderItemAttributeKey;
import com.menards.ssc.dao.order.MenardOrderDao;
import com.menards.ssc.dao.order.MenardOrderItemDao;
import com.menards.ssc.dao.sign.MenardColorSignDao;
import com.menards.ssc.dao.sign.MenardSignDao;
import com.menards.ssc.domain.cart.AddCartRequest;
import com.menards.ssc.domain.cart.CartItem;
import com.menards.ssc.domain.cart.SignCartItem;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.catalog.SignDTO;
import com.menards.ssc.domain.order.MenardCartinfoDTO;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderDTO;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.domain.order.MenardOrderItemHistory;
import com.menards.ssc.domain.order.MenardOrderItemTrackingHistory;
import com.menards.ssc.domain.setremodel.SetRemodelDTO;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.enums.MenardOrderItemType;
import com.menards.ssc.enums.SignSearchType;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.catalog.MenardCatalogService;
import com.menards.ssc.strategy.approve.MenardItemApproveStrategy;

/**
 *
 * <p>MenardOrderServiceImpl</p>
 * <p>An Menard Order Service Impl that provides convenience methods and resource declarations</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
/**
 * <p>MenardOrderServiceImpl</p>
 * <p>operate order</p>
 * <p>
 * add item to cart, update items, remove item, search and so on
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Service("menardOrderService")
public class MenardOrderServiceImpl extends OrderServiceImpl implements MenardOrderService, OrderItemAttributeKey {

	protected static final Logger LOG = Logger.getLogger(MenardOrderServiceImpl.class);

    @Resource(name = "blCatalogService")
   	private MenardCatalogService catalogService;

	@Resource(name = "menardOrderDao")
	private MenardOrderDao orderDao;

	@Resource(name = "menardOrderItemDao")
	private MenardOrderItemDao orderItemDao;

	@Resource(name = "menardOrderItemService")
	private MenardOrderItemService menardOrderItemService;

	@Resource(name = "menardSignDao")
	private MenardSignDao signDao;

	@Resource(name = "menardColorSignDao")
	private MenardColorSignDao colorSignDao;

	private static final boolean AUTOMATICALLY_MERGE_LIKE_ITEMS = false;

	@Override
	public SearchResult<MenardOrderDTO> getOrderByPagination(MenardOrderItemFilterDTO filterDTO) {

		SearchResult<MenardOrder> itemPage = orderDao.getOrderByPagination(filterDTO);
		SearchResult<MenardOrderDTO> result = new SearchResult<MenardOrderDTO>();
		result.setTotalResults(itemPage.getTotalResults());
		result.setPage(itemPage.getPage());
		result.setPageSize(itemPage.getPageSize());

		for (MenardOrder menardOrder : itemPage.getResult()) {
			result.addElement(new MenardOrderDTO(menardOrder));

		}
		return result;

	}

	@Override
	public SearchResult<MenardOrderDTO> findOrdersByUserId(MenardOrderItemFilterDTO filterDTO, String userId,
			OrderStatus status) {

		SearchResult<MenardOrder> itemPage = orderDao.findOrdersByUserId(filterDTO, userId, status);
		SearchResult<MenardOrderDTO> result = new SearchResult<MenardOrderDTO>();
		result.setTotalResults(itemPage.getTotalResults());
		result.setPage(itemPage.getPage());
		result.setPageSize(itemPage.getPageSize());

		for (MenardOrder menardOrder : itemPage.getResult()) {
			result.addElement(new MenardOrderDTO(menardOrder));

		}
		return result;

	}

	/**
	 *
	 * Get Order By Filter
	 * @param filterDTO filterDTO
	 * @return List list
	 */
	@Override
	public List<MenardOrderDTO> getOrderByFilter(MenardOrderItemFilterDTO filterDTO) {

		List<MenardOrder> menardorders = orderDao.getOrderByFilter(filterDTO.getStoreId(), filterDTO.getDays(),
				filterDTO.getOrderId());

		List<MenardOrderDTO> list = new ArrayList<MenardOrderDTO>();
		for (MenardOrder menardOrder : menardorders) {
			list.add(new MenardOrderDTO(menardOrder));
		}
		return list;
	}

	/**
	 * Get Order By Id.
	 * @param orderId orderId
	 * @return Order Order
	 */
	@Override
	public Order getOrderById(Long orderId) {
		return orderDao.readOrderById(orderId);
	}

	/**
	 *
	 * Get Tracking History By orderItemNumber.	
	 * @param orderItemId orderItemId
	 * @return MenardOrderItem MenardOrderItem
	 */
	@Override
	public MenardOrderItemHistory getTrackingHistory(Long orderItemId) {
		return orderDao.getTrackingHistory(orderItemId);
	}

	@Override
	@Transactional("blTransactionManager")
	public Order updateOrderItems(Order order, List<SkuCartItem> cartItems) throws ItemNotFoundException {
		for (SkuCartItem item : cartItems) {
			updateItemQuantity(order, item);
		}
		return order;
	}

	@Override
	@Transactional("blTransactionManager")
	public void placedOrder(Order order, List<String> storeIds) {
		if (CollectionUtils.isEmpty(storeIds)) {
			throw new IllegalArgumentException("store Ids can not be empty!");
		}

		placeOrder(order, storeIds.get(0), false);

		if (storeIds.size() > 1) {
			Order copyOrder = null;
			for (int index = 1; index < storeIds.size(); index++) {
				copyOrder = copyOrder(order);
				placeOrder(copyOrder, storeIds.get(index), true);
			}
		}
		orderDao.flush();
		//Batch up sending the messages
		MenardItemApproveStrategy.executeAndClear();
	}

	/**
	 * place order process
	 * @param order order 
	 * @param storeId string
	 * @param orderItemCommonAttributeReady orderItemCommonAttributeReady
	 */
	@Transactional("blTransactionManager")
	private void placeOrder(Order order, String storeId, boolean orderItemCommonAttributeReady) {
		((MenardOrder) order).setStoreId(storeId);
		processOrderItemDiff(order, storeId);
		// order id is not null, means order item of place attribute have not set yet
		//if (!orderItemCommonAttributeReady) {
			placedOrderItem(order);
			order.setStatus(OrderStatus.SUBMITTED);
			order.setSubmitDate(new Date());
			MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
			((MenardOrder) order).setGeneralOfficeOrder(user.isGOUser() ? CommonConstant.TRUE_STRING
					: CommonConstant.FALSE_STRING);

		//}
		orderDao.save(order);

		// add tracking history
		addDedaultTrackingStatus(order);
	}

	/**
	 * process order item according storeId
	 * @param order order 
	 * @param storeId storeId
	 */
	private void processOrderItemDiff(Order order, String storeId) {
		// STORE_REMODEL calculate from resetmodel date
		SetRemodelDTO remodel = null;
		try {
			remodel = signDao.getSetRemodelByStoreId(storeId);
		} catch (Exception e) {
		}

		String storeRemodel = CommonConstant.FALSE_STRING;
		if (remodel != null) {
			// Calendar today = Calendar.getInstance();

			Date today = new Date();

			boolean setRemodel;
			if (remodel.getStartDate() != null) {
				setRemodel = DateUtils.isSameDay(today, remodel.getEndDate())
						|| DateUtils.isSameDay(today, remodel.getStartDate()) || today.after(remodel.getStartDate())
						&& today.before(remodel.getEndDate());
				storeRemodel = setRemodel ? CommonConstant.TRUE_STRING : CommonConstant.FALSE_STRING;
			}
		}
		for (OrderItem orderItem : order.getOrderItems()) {
			((MenardOrderItem) orderItem).setStoreRemodel(storeRemodel);
		}
	}

	/**
	 * set order item status for approvel
	 * @param order order
	 */
	@Transactional("blTransactionManager")
	private void placedOrderItem(Order order) {
		for (OrderItem orderItem : order.getOrderItems()) {
			MenardOrderItem menardOrderItem = (MenardOrderItem) orderItem;
			// set attribute from product/sku
			/*
			 * if (MenardOrderItemType.SIGN.getCode().toString().equals(menardOrderItem.getItemType())) { // todo-e }
			 * else {
			 */
			menardOrderItemService.populateOrderItemAttributes(menardOrderItem);
			/* } */
		}
	}

	/**
	 *
	 * copy order for place function
	 * @param order Order
	 * @return Order
	 */
	private Order copyOrder(Order order) {
		Order copyOrder = copyMainOrder(order);

		copyOrder = copyOrderAttributes(order, copyOrder);

		copyOrder = copyOrderItemsIncludeItemAttributes(order, copyOrder);

		return copyOrder;
	}

	/**
	 *
	 * copy main order, including menardOrderImpl, orderImpl
	 * @param order Order
	 * @return order
	 */
	private Order copyMainOrder(Order order) {
		Order copyOrder = orderDao.create();
		BeanUtils.copyProperties(order, copyOrder, new String[] { "id", "orderAttributes", "orderItems" });
		return orderDao.save(copyOrder);
	}

	/**
	 *
	 * copy order attributes
	 * @param order Order
	 * @param copyOrder Order
	 * @return order
	 */
	private Order copyOrderAttributes(Order order, Order copyOrder) {
		for (OrderAttribute attr : order.getOrderAttributes().values()) {
			OrderAttribute copyAttr = new OrderAttributeImpl();
			BeanUtils.copyProperties(attr, copyAttr, new String[] { "id", "order" });
			copyAttr.setOrder(copyOrder);
			copyOrder.getOrderAttributes().put(copyAttr.getName(), copyAttr);
		}
		return orderDao.save(copyOrder);
	}

	/**
	 *
	 * copy order item and item attributes
	 * @param order Order
	 * @param copyOrder Order
	 * @return order
	 */
	private Order copyOrderItemsIncludeItemAttributes(Order order, Order copyOrder) {
        for (OrderItem orderItem : order.getOrderItems()) {
            OrderItem copyItem = orderItemDao.create(OrderItemType.DISCRETE);
            BeanUtils.copyProperties(orderItem, copyItem, new String[] { "id", "order", "menardOrder" });
            copyItem.setOrder(copyOrder);
            ((MenardOrderItem) copyItem).setMenardOrder((MenardOrder) copyOrder);
            DiscreteOrderItem discreteOrderItem = (DiscreteOrderItem) orderItem;
            ((MenardOrderItem) copyItem).setMenardSku((MenardSku) discreteOrderItem.getSku());
            ((MenardOrderItem) copyItem).setMenardProduct((MenardProduct) discreteOrderItem.getProduct());
            ((MenardOrderItem) copyItem).setStatus(null);
            copyItem = orderItemDao.saveMenardDiscreateOrderItem((MenardOrderItem) copyItem);

            copyItem = copyOrderItemAttributes(orderItem, copyItem);

            copyOrder.getOrderItems().add(copyItem);
        }
        return orderDao.save(copyOrder);
	}

	/**
	 *
	 * add default tracking history status when place order
	 * @param order Order
	 */
	private void addDedaultTrackingStatus(Order order) {
		for (OrderItem item : order.getOrderItems()) {
			addOrderItemTracking(order, item);
		}
	}

	/**
	 *
	 * copy order item attributes
	 * @param orderItem OrderItem
	 * @param copyItem  OrderItem
	 * @return OrderItem
	 */
	private OrderItem copyOrderItemAttributes(OrderItem orderItem, OrderItem copyItem) {
		for (OrderItemAttribute itemAttr : orderItem.getOrderItemAttributes().values()) {
			OrderItemAttribute copyItemAttr = new OrderItemAttributeImpl();
			BeanUtils.copyProperties(itemAttr, copyItemAttr, new String[] { "id", "orderItem" });
			copyItemAttr.setOrderItem(copyItem);
			copyItem.getOrderItemAttributes().put(copyItemAttr.getName(), copyItemAttr);
		}
		return orderItemDao.save(copyItem);
	}

	/**
	 *
	 * add order item tracking status history
	 * @param order Order
	 * @param item OrderItem
	 */
	private void addOrderItemTracking(Order order, OrderItem item) {
		MenardOrderItemTrackingHistory history = new MenardOrderItemTrackingHistory();
		history.setOrderId(order.getId());
		history.setOrderItemId(item.getId());
		history.setStatus(((MenardOrderItem) item).getStatus());
		history.setCreateDate(new Date());
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		String createBy = "";
		if (user != null) {
			createBy = user.getUserId();
		}
		history.setCreateBy(createBy);
		menardOrderItemService.saveOrderItemTrackingHistory(history);
	}

	@Override
	@Transactional(value = "blTransactionManager")
	public Order removeItem(Order order, Long orderItemId) {
		OrderItem orderItem = orderItemService.readOrderItemById(orderItemId);

		if (order.getOrderItems().indexOf(orderItem) != -1) {
			// Remove the OrderItem from the Order
			OrderItem itemFromOrder = order.getOrderItems().remove(order.getOrderItems().indexOf(orderItem));
			// Delete the OrderItem from the database
			itemFromOrder.setOrder(null);
			orderItemService.delete(itemFromOrder);

			int lineNumber = 1;
			for (OrderItem item : order.getOrderItems()) {
				MenardOrderItem menardItem = (MenardOrderItem) item;
				menardItem.setLineNumber(lineNumber);
				lineNumber++;
			}

			return saveMenardOrder(order);
		}

		return order;
	}

	/**
	 *
	 * save menard order
	 * @param menardOrder Order
	 * @return order Order
	 */
	private Order saveMenardOrder(Order menardOrder) {
		return orderDao.saveMenardOrder(menardOrder);
	}

	@Override
	@Transactional("blTransactionManager")
	public Order saveMenardOrder(Order cart, MenardCartinfoDTO cartinfoDTO) {
		Long fromLoadId = ((MenardOrder) cart).getLoadOrderId();
		/*
		 * if the menard order is loaded from another order, then check if the listname is equals the new name, yes,
		 * delete old one save new one
		 */
		if (fromLoadId != null) {
			MenardOrder fromOrder = (MenardOrder) this.getOrderById(fromLoadId);
			if (fromOrder != null) {
				if (StringUtils.isNotEmpty(fromOrder.getListName())
						&& fromOrder.getListName().equals(cartinfoDTO.getListName())) {
					this.deleteOrder(fromOrder);
				}
			}
		}

		String listName = cartinfoDTO.getListName();
		String comment = cartinfoDTO.getComment();

		MenardOrder newOrder = (MenardOrder) copyOrder(cart);
		newOrder.setListName(listName);
		newOrder.setCommentSaved(comment);
		newOrder.setStatus(OrderStatus.NAMED);

		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		newOrder.setCreatedByUserId(user.getUserId());
		orderDao.saveMenardOrder(newOrder);

		((MenardOrder) cart).setListName(listName);
		((MenardOrder) cart).setCommentSaved(comment);
		((MenardOrder) cart).setLoadOrderId(newOrder.getId());

		return orderDao.saveMenardOrder(cart);
	}

	@Override
	public List<MenardOrder> findMenardOrderByStatus(OrderStatus status) {
		return orderDao.findMenardOrderByStatus(status);
	}

	@Override
	@Transactional(value = "blTransactionManager")
	public Order updateOrderItems(Long removeItemId, Order order, List<SkuCartItem> cartItems)
			throws ItemNotFoundException {
		this.removeItem(order, removeItemId);
		int removedIndex = 0;
		for (SkuCartItem item : cartItems) {
			if (item.getOrderItemId().equals(removeItemId)) {
				removedIndex = cartItems.indexOf(item);
			}
		}
		cartItems.remove(removedIndex);
		return this.updateOrderItems(order, cartItems);
	}

	@Override
	@Transactional(value = "blTransactionManager")
	public Order replaceCart(Order cart, Long orderId) {
		this.deleteOrder(cart);

		Order order = this.getOrderById(orderId);

		Order newCart = copyOrder(order);
		// the status in cart is in progress
		newCart.setStatus(OrderStatus.IN_PROCESS);
		// be aware of the cart copy from which order
		((MenardOrder) newCart).setLoadOrderId(orderId);
		newCart.setCustomer(CustomerState.getCustomer());
		this.saveMenardOrder(newCart);

		return newCart;
	}

	@Override
	@Transactional(value = "blTransactionManager")
	public void addItems2Cart(Order order, AddCartRequest request) throws ItemNotFoundException {
		SkuCartItem main = request.getMainSku();
		this.addItem(order, main);
		for (SkuCartItem cartItem : request.getOptionSkus()) {
			this.addItem(order, cartItem);
		}
		for (SkuCartItem cartItem : request.getRequireSkus()) {
			this.addItem(order, cartItem);
		}
	}

	@Override
	@Transactional(value = "blTransactionManager")
	public Order addItem(Order order, SkuCartItem cartItem) throws ItemNotFoundException {
		if (AUTOMATICALLY_MERGE_LIKE_ITEMS) {
			OrderItem item = findMatchingItem(order, cartItem);
			if (item != null) {
				cartItem.setQuantity(item.getQuantity() + cartItem.getQuantity());
				cartItem.setOrderItemId(item.getId());
				return updateItemQuantity(order, cartItem);
			}
		}

		return this.addItem2Cart(order, cartItem);
	}

	/**
	 * add item to cart
	 * @param order order
	 * @param cartItem SkuCartItem
	 * @return order
	 * @throws ItemNotFoundException 
	 */
	private Order addItem2Cart(Order order, SkuCartItem cartItem) throws ItemNotFoundException {
		OrderItem item = menardOrderItemService.createMenardOrderItem(order, cartItem);
		order.getOrderItems().add(item);
		return saveMenardOrder(order);
	}

	/**
	 * find match item with sku id
	 * @param order order 
	 * @param cartItem cartitem
	 * @return Orderitem
	 */
	protected OrderItem findMatchingItem(Order order, SkuCartItem cartItem) {
		if (order == null) {
			return null;
		}
		for (OrderItem currentItem : order.getOrderItems()) {
			MenardOrderItem orderItem = (MenardOrderItem) currentItem;
			if (orderItem.getSku().getId().equals(cartItem.getSkuId())) {
				return orderItem;
			}
		}
		return null;
	}

	/**
	 * update order item quantity
	 * @param order cart
	 * @param cartItem cartItem
	 * @return order cart
	 * @throws ItemNotFoundException ItemNotFoundException
	 */
	@Transactional(value = "blTransactionManager")
	public Order updateItemQuantity(Order order, CartItem cartItem) throws ItemNotFoundException {
		OrderItem orderItem = null;
		for (OrderItem oi : order.getOrderItems()) {
			if (oi.getId().equals(cartItem.getOrderItemId())) {
				orderItem = oi;
			}
		}

		if (orderItem == null) {
			throw new ItemNotFoundException("order item not found with orderItemId: " + cartItem.getOrderItemId());
		}

		OrderItem itemFromOrder = order.getOrderItems().get(order.getOrderItems().indexOf(orderItem));
		itemFromOrder.setQuantity(cartItem.getQuantity());

		// add comment to order item
		String comment = cartItem.getComment();
		((MenardOrderItem) itemFromOrder).setNotes(comment);

		return saveMenardOrder(order);
	}

	@Override
	@Transactional(value = "blTransactionManager")
	public Order addSign2Cart(Order cart, SignCartItem signItem) throws ItemNotFoundException {
		if (AUTOMATICALLY_MERGE_LIKE_ITEMS) {
			OrderItem item = findMatchingSignItem(cart, signItem);
			if (item != null) {
				signItem.setQuantity(item.getQuantity() + signItem.getQuantity());
				signItem.setOrderItemId(item.getId());
				return updateItemQuantity(cart, signItem);
			}
		}

		MenardOrderItem orderItem = populateSignOrderItem(signItem);
		int lineNumber = 0;
		if (signItem.getLineNumber() != null) {
			lineNumber = signItem.getLineNumber();
		}        
        if (lineNumber == 0) {
            lineNumber = cart.getOrderItems().size() + 1;
        }
        orderItem.setLineNumber(lineNumber);

		// set default status
		// orderItem.setStatus(getInitStatus(orderItem));
		orderItem.setStatusDate(new Date());

		orderItem.setOrder(cart);
		orderItem.setMenardOrder((MenardOrder) cart);
		orderItemService.saveOrderItem(orderItem);
		return cart;
	}

	/**
	 * For sign, skuman and color sign only fill the description 
	 * into the order item
	 *  
	 * populate Order Item from sign item
	 * @param signItem signItem
	 * @return MenardOrderItem MenardOrderItem
	 */
	private MenardOrderItem populateSignOrderItem(SignCartItem signItem) {
		final MenardOrderItem item = (MenardOrderItem) orderItemDao.create(OrderItemType.DISCRETE);
		item.setSignId(signItem.getSignId());
		item.setSignYardNum(signItem.getYardNum());
		item.setQuantity(signItem.getQuantity());
		item.setNotes(signItem.getComment());
		item.setItemType(signItem.getType());

        // save default product
        // set default SKU and product
        Sku sku = catalogService.findSkuById(CommonConstant.DEFAULT_SKU_ID_SIGN);
        Product product = sku.getProduct();
        item.setSku(sku);
        item.setProduct(product);
        item.setMenardSku((MenardSku) sku);
        item.setMenardProduct((MenardProduct) product);

		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		Integer yard = null;
		if (user.isYard()) {
			yard = Integer.valueOf(user.getStoreNumber());
		}

        // description
        String description = null;
		//Integer type = Integer.parseInt(signItem.getType());
		if (MenardOrderItemType.SIGN.getCode().equals(signItem.getType())) {
            SignDTO sign = signDao.findSign(signItem.getSignId(), yard, SignSearchType.Place, signItem.getPromoNumber(), signItem.getType());
            description = sign.getStock().getDesc() + " - " + sign.getDescriptionShort();
            //Sale sign
            if (signItem.getPromoNumber() > 0) {
    			createOrderItemAttr(item, SALE_SIGN_PRO_NBR, String.valueOf(signItem.getPromoNumber()));
    		}
            //Add the sign name    
    		createOrderItemAttr(item, SIGN_NAME_ATTRIBUTE_NAME, sign.getSignVersion().getSignname());    		
		} else if (MenardOrderItemType.COLOR_SIGN.getCode().equals(signItem.getType())) {
			Sign colorsign = colorSignDao.findSignById(signItem.getSignId());
            description = colorsign.getVersionDescription() + " - " + colorsign.getStockDescription(); 
    		createOrderItemAttr(item, SIGN_NAME_ATTRIBUTE_NAME, colorsign.getSignName());            
		} else if (MenardOrderItemType.SKU_MAN.getCode().equals(signItem.getType())) {
			Sign skuMan = signDao.findPrePrintedFactTag(signItem.getSignId());
			createOrderItemAttr(item, SIGN_NAME_ATTRIBUTE_NAME, skuMan.getSignName());  
			description = skuMan.getStockDescription() + " - " + skuMan.getVersionDescription();
		}
		
        // Also, save description to order item table
        item.setDescription(description);

		return item;
	}	
	
	
	/**
	 * 
	 * @param orderItem
	 * @param name
	 * @param value
	 */
	private void createOrderItemAttr(OrderItem orderItem, String name, String value) {	
		if (StringUtils.isBlank(name) || orderItem== null) {
			return;
		}
		OrderItemAttribute signNameAttr = orderItemDao.createOrderItemAttribute();
		signNameAttr.setOrderItem(orderItem);
		signNameAttr.setName(name);
		signNameAttr.setValue(value);
		orderItem.getOrderItemAttributes().put(name, signNameAttr);		
	}

	/**
	 * find match item with sku id
	 * @param order order 
	 * @param cartItem cartitem
	 * @return Orderitem
	 */
	protected OrderItem findMatchingSignItem(Order order, SignCartItem cartItem) {
		if (order == null) {
			return null;
		}
		for (OrderItem currentItem : order.getOrderItems()) {
			MenardOrderItem orderItem = (MenardOrderItem) currentItem;
			if (cartItem.getSignId().equals(orderItem.getSignId())
					&& cartItem.getYardNum().equals(orderItem.getSignYardNum())) {
				return orderItem;
			}
		}
		return null;
	}

	@Override
	public Order findCartByUserId(String userId) {
		List<MenardOrder> orders = orderDao.findOrdersByUserId(userId, OrderStatus.IN_PROCESS);
		if (CollectionUtils.isEmpty(orders)) {
			return null;
		}
		return orders.get(0);
	}

	@Override
	@Transactional(value = "blTransactionManager")
	public Order createOrderForNewUser(String userId) {
		MenardOrder order = (MenardOrder) orderDao.create();
		order.setStatus(OrderStatus.IN_PROCESS);
		order.setCustomer(CustomerState.getCustomer());
		order.setCreatedByUserId(userId);
		return this.saveMenardOrder(order);
	}

	@Override
	public List<MenardOrder> findOrdersByUserId(String userId, OrderStatus status) {
		return orderDao.findOrdersByUserId(userId, status);
	}

	@Override
	@Transactional(value = "blTransactionManager")
	public void addSigns2Cart(Order cart, List<SignCartItem> signItems) throws ItemNotFoundException {
        int currentCount = cart.getOrderItems().size();
        int index = 1;
		for (SignCartItem signItem : signItems) {
            // add order item line number
            signItem.setLineNumber(currentCount + index);
			this.addSign2Cart(cart, signItem);
            index = index + 1;
		}
	}

	@Override
	@Transactional(value = "blTransactionManager")
	public Order removeItems(Order order, Long[] orderItemIds) {
        for (Long orderItemId : orderItemIds) {
            this.removeItem(order, orderItemId);
        }
		return this.saveMenardOrder(order);
	}

}
