package com.menards.ssc.service.skustatus;

import java.util.List;

import com.menards.service.sku.GetStoreAvailabilityBySku;

public class SSCGetStoreAvailabilityBySku extends GetStoreAvailabilityBySku{
	public void setSkuNumbers(List<Integer> skuNumbers){
		 this.skuNumbers =skuNumbers;
	}	
}
