package com.menards.ssc.service.inventory;

import java.util.List;

import com.menards.ssc.domain.inventory.MenardInventoryDTO;

/**
 *
 * <p>MenardInventoryService</p>
 * <p>An Menard Inventory Service that provides convenience methods for monthly inventory report</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public interface MenardInventoryService {

	/**
	 *
	 * Get Inventory	
	 * @return List<MenardInventoryDTO> 
	 */
	public List<MenardInventoryDTO> getInventory();

	/**
	 * Update Inventory.
	 * @param sku sku
	 * @param quantity quantity
	 * @return List<MenardInventoryDTO>
	 */
	public List<MenardInventoryDTO> updateInventory(String[] sku, String[] quantity);


	/**
	 * Update Inventory.
	 * @param modelNum String
	 * @param quantity quantity
	 * @return MenardInventoryDTO MenardInventoryDTO
	 */
	public MenardInventoryDTO updateInventory(String modelNum, Integer quantity);

}
