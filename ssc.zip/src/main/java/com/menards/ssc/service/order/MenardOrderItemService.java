package com.menards.ssc.service.order;

import java.util.List;
import java.util.Map;

import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.service.OrderItemService;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;

import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.order.ItemApproveRequestDTO;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.order.MenardOrderItemDTO;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.domain.order.MenardOrderItemTrackingHistory;

/**
 * <p>MenardOrderItemService</p>
 * <p>Process all the request related to order item approve</p>
 * <p>
 * provide some methods relevant to approval of order item, such as
 * find all the order items according to the filter conditions
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public interface MenardOrderItemService extends OrderItemService {

	/**
	 * Find a list of order items that need to proceed with according to
	 * the filter conditions such as store, request type, tracking status and
	 * so on. Meanwhile sort the result according to the selected options;
	 *
	 * @param filter MenardOrderItemFilterDTO
	 * @return List<MenardOrderItemDTO>
	 */
	public List<MenardOrderItemDTO> findAllOrderItemsForApproval(MenardOrderItemFilterDTO filter);

	/**
	 * Find a page of order item for approval page
	 * @param filter MenardOrderItemFilterDTO
	 * @return SearchResult<MenardOrderItemDTO>
	 */
	public SearchResult<MenardOrderItemDTO> findOrderItemsPageForApproval(MenardOrderItemFilterDTO filter);
	
	
	/**
	 * Find a page of order item for history page
	 * @param filter MenardOrderItemFilterDTO
	 * @return SearchResult<MenardOrderItemDTO>
	 */
	public SearchResult<MenardOrderItemDTO> findOrderItemsPageForHistory(MenardOrderItemFilterDTO filter);

	/**
	 * Approve, back order or deny order item(s). If items get denied the reason should be
	 * passed.
	 *
	 * @param items List<ItemApproveRequestDTO>
	 * @return Map<Long, List<MenardOrderItemDTO>>
	 */
	public Map<String, List<MenardOrderItemDTO>> approveOrderItems(List<ItemApproveRequestDTO> items);

	/**
	 * save order item tracking history
	 *
	 * @param history MenardOrderItemTrackingHistory
	 * @return MenardOrderItemTrackingHistory
	 */
	MenardOrderItemTrackingHistory saveOrderItemTrackingHistory(MenardOrderItemTrackingHistory history);

	/**
	 * create order item with order
	 * @param order order
	 * @param cartItem cartitem
	 * @return MenardOrderItem
	 * @throws ItemNotFoundException 
	 */
	MenardOrderItem createMenardOrderItem(Order order, SkuCartItem cartItem) throws ItemNotFoundException;

	/**
	 * populateOrderItemAttributes
	 * @param orderItem MenardOrderItem
	 */
	void populateOrderItemAttributes(MenardOrderItem orderItem);

    /**
     * This method sets fulfiller type to the passed order item
     *
     * @param menardOrderItem MenardOrderItem
     */
    void populateFulfillerTypeForOrderItem(MenardOrderItem menardOrderItem);

    /**
     * Checks requesttype and fulfillertype on the orderitem.
     * Will pass validation only when both requesttype and fulfillertype are not blank
     * @param orderItem
     * @return true if requesttype and fulfillertype can be found or calculated
     *         false if requesttype and fulfillertype  cannot be found or calculated
     */
    boolean validateFulfillerType(MenardOrderItem menardOrderItem);

    /**
     * count the total number of all order items awaiting approval
     *
     * @return count long
     */
    long countOrderItemsForApprove();
    
    /**
     * @param item
     * @param name
     * @return
     */
    String getOrderItemAttrValue(MenardOrderItem item, String name);
}
