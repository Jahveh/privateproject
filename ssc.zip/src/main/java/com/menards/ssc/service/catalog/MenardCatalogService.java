package com.menards.ssc.service.catalog;

import java.util.List;
import java.util.Map;

import org.broadleafcommerce.core.catalog.domain.Category;
import org.broadleafcommerce.core.catalog.domain.CategoryAttribute;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.catalog.domain.Sku;
import org.broadleafcommerce.core.catalog.service.CatalogService;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;

import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.catalog.*;

/**
 *
 * <p>MenardCatalogService</p>
 * <p>Menard Catalog Service</p> *
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public interface MenardCatalogService extends CatalogService {

	/**
	 *
	 * count Product For Category
	 * @param category category
	 * @param productFilters productFilters
	 * @return Long Long
	 */
	Long countProductForCategory(Category category, List<ProductFilter> productFilters);

	/**
	 * get menard product by product id
	 * @param productId Long
	 * @return ProductDTO
	 * @throws ItemNotFoundException not found
	 */
	MenardProductDTO getMenardProductById(Long productId) throws ItemNotFoundException;

	/**
	 * get menard product by product id, sku id
	 * @param productId Long
	 * @param skuId Long
	 * @return ProductDTO
	 * @throws ItemNotFoundException not found
	 */
	ProductDetailDTO getMenardProductDetail(Long productId, Long skuId) throws ItemNotFoundException;

	/**
	 * get menard product by product id, sku id
	 * @param productId Long
	 * @param skuId Long
	 * @param setDefaultSku setDefaultSku
	 * @return ProductDTO
	 * @throws ItemNotFoundException not found
	 */
	ProductDetailDTO getMenardProductDetail(Long productId, Long skuId, Boolean setDefaultSku)
			throws ItemNotFoundException;

	/**
	 * find products by category Id with pagenation
	 * @param categoryId category id
	 * @param limit start
	 * @param offset size
	 * @return list products
	 */
	List<Product> findProductsByCategoryId(Long categoryId, int limit, int offset);

	/**
	 * find product dtos by category Id with pagenation
	 * @param categoryId category id
	 * @param limit start
	 * @param offset size
	 * @param productFilters productFilters
	 * @return list products
	 */
	List<SkuCartItem> findProductDTOsByCategoryId(Long categoryId, int limit, int offset,
			List<ProductFilter> productFilters);

	/**
	 * get sku DTO from sku
	 * set sku status and sku visibility
	 * @param sku MenardSku
	 * @return MenardSkuDTO
	 */
	MenardSkuDTO getSkuDTO(MenardSku sku);

    /**
     * Get sku DTO by SKU ID. This method will call SKU status web service to get the status for the SKU
     *
     * @param skuId
     * @return
     */
    MenardSkuDTO getMenardSkuDTOBySkuId(Long skuId, int storeNumber);

	/**
	 * find menard sku by menard sku
	 * @param menardSku menardSku
	 * @return menardSku
	 */
	MenardSku findSkuByMenardSku(String menardSku);

	/**
	 * 
	 * getConfiguredProductFilterByCategoryId
	 * @param categoryId categoryId
	 * @return ProductFilter ProductFilter
	 */
	List<ProductFilter> getConfiguredProductFilterByCategoryId(Long categoryId);

	/**
	 * 
	 * getProductFilterOptions
	 * @param configuredProductFilter configuredProductFilter
	 * @return ProductFilter ProductFilter
	 */
	List<ProductFilter> getProductFilterOptions(List<ProductFilter> configuredProductFilter);

	/**
	 * Group the category security data such as which category could be 
	 * open to some fulfiller or department
	 * @return Map<Long, CategoryAuth>
	 */
	public Map<Long, CategoryAuth> groupCategorySecurityData();

	
    /**
     * get skus DTO from sku list
     *
     * @param skus MenardSkus
     * @return MenardSkuDTO
     */
	public List<MenardSkuDTO> getSkuDTOs(List<Sku> skus);

    /**
     * Get SKU status for a product in a specified store
     * @param product
     * @param storeNumber
     * @return
     */
    public Map<String, String> getSkuToStatusCodeMap(Product product, int storeNumber);

    /**
     * Get category attribute by category ID
     *
     * @param categoryId
     * @return
     */
    List<CategoryAttribute> getCategoryAttributes(Long categoryId);

    /**
     * Get category attribute by category path
     *
     * @param categoryPath
     * @return
     */
    List<CategoryAttribute> getCategoryAttributes(String categoryPath);
}
