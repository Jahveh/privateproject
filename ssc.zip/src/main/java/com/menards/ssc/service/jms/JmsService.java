package com.menards.ssc.service.jms;

import java.util.Collection;

public interface JmsService {
	
	public boolean sendClothingMessage(Collection<String> messages);

}
