/**
 *
 */
package com.menards.ssc.service.catalog;

import com.menards.ssc.dao.sign.MenardColorSignDao;
import com.menards.ssc.domain.cart.SignCartItem;
import com.menards.ssc.domain.catalog.ColorSignDTO;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.enums.MenardOrderItemType;
import com.menards.ssc.enums.SignSearchType;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>MenardColorSignService</p>
 * <p>Color sign service</p>
 * <p>
 *  Provide some common methods such as,
 *  retrieve the sign list, save a sign and so on.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Service("colorSignService")
public class MenardColorSignServiceImpl implements MenardColorSignService {

	@Resource(name = "menardColorSignDao")
	private MenardColorSignDao colorSignDao;

	@Override
	@Transactional("colorSignTransactionManager")
	public Boolean saveSignOrder(MenardOrderItem item) {
		List<String> yardList = colorSignDao.getYardList(item.getSignId());
		String storeId = item.getMenardOrder().getStoreId();
		Sign sign = colorSignDao.findSignById(item.getSignId());
		if (!yardList.contains(storeId)) {
			return false;
		}

		sign.setOrderedQuantity(item.getQuantity());
		sign.setYard(Integer.parseInt(storeId));
		try {
			colorSignDao.insertSignOrder(sign, item);
		} catch (Exception e) {
			LOG.error(e.getMessage());
			return false;
		}
		return true;
	}

    @Override
    public int findColorSignCatalogId(Integer signId) {
        return colorSignDao.findColorSignCatalogId(signId);
    }

	@Override
	public ColorSignDTO getSign(String signId, Integer yard, SignSearchType type) {
		return colorSignDao.getSign(signId, yard, type);
	}

	@Override
	public List<SignCartItem> getSignsByCatalogID(long catalogID, int limit, int offset) {
		List<Sign> signs = colorSignDao.getSignsByCatalogID(catalogID, limit, offset);
		List<SignCartItem> cartItems = new ArrayList<SignCartItem>();
		for (Sign sign : signs) {
			cartItems.add(this.getConvert2CartItem(sign));
		}
		return cartItems;
	}
	
	public int getQuantityOrdered(int signId, int locationId, int leadTime) {
		return colorSignDao.getQuantityOrdered(signId, locationId, leadTime);
	}

	/**
	 * 
	 * getConvert2CartItem
	 * @param sign sign
	 * @return SignCartItem SignCartItem
	 */
	private SignCartItem getConvert2CartItem(Sign sign) {
		SignCartItem item = new SignCartItem();
		item.setSignName(sign.getSignName());
		item.setSignId(sign.getSignID());
		item.setStockSize(sign.getStockWidth() + "X" + sign.getStockHeight());
		String descriptionShort = sign.getVersionDescription();
		if (StringUtils.isNotEmpty(descriptionShort) && descriptionShort.length() > 75) {
			descriptionShort = descriptionShort.substring(0, 72) + "...";
		}
		item.setDescriptionShort(descriptionShort);
		item.setUnitPrice(sign.getSignPrice());
        item.setPreviewImagePath(sign.getPreviewPath());
        item.setLargerImagePath(sign.getLargeImagePath());
		item.setProductImgUrl(sign.getImagePath());
		item.setPrintLocation(sign.getPrintLocation());
		item.setType(MenardOrderItemType.COLOR_SIGN.getCode().toString());
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		item.setYardNum(user.getStoreNumber());
		item.setQuantity(sign.getOrderableQuantity());
		return item;
	}

	@Override
	public long countByCatalogID(long catalogID) {
		return colorSignDao.countByCatalogID(catalogID);
	}
}
