/**
 *
 */
package com.menards.ssc.service.catalog;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.menards.ssc.domain.catalog.SignDTO;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.enums.SignSearchType;

/**
 * <p>MenardSignService</p>
 * <p>sign service</p>
 * <p>
 *  Provide some common methods such as,
 *  retrieve the sign list, save a sign and so on.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public interface MenardSignService {

	public static final Log LOG = LogFactory.getLog(MenardSignService.class);

	/**
	 * Save the sign to database
	 * @param item OrderItem
	 */
	public void insertSignOrder(MenardOrderItem item);

	/**
	 * find sign according sing version id and yard
	 * @param signVersionId Integer
	 * @param yard yard
	 * @param type type
	 * @return SignDTO sign dto
	 */
	SignDTO findSign(Integer signVersionId, Integer yard, SignSearchType type);

    /**
	 * find sign according sing version id and yard
	 * @param signVersionId Integer
     * @param yard yard
     * @param searchType type
     * @param promoNbr int
     * @param type String
	 * @return SignDTO sign dto
	 */
	SignDTO findSign(Integer signVersionId, Integer yard, SignSearchType searchType, int promoNbr, String type);
	
	 /**
	  * Find the pre printed Fact tag from sku man
	  * 
	 * @param signId
	 * @return Sign
	 */
	public Sign findPrePrintedFactTag(Integer signId);
	
	public SignDTO findPrePrintedFactTagDetail(Integer signId, Integer yard);
}
