/**
 *
 */
package com.menards.ssc.service.security;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.access.SecurityMetadataSource;
import org.springframework.security.web.access.intercept.DefaultFilterInvocationSecurityMetadataSource;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
import org.springframework.security.web.util.AntPathRequestMatcher;
import org.springframework.security.web.util.RequestMatcher;
import org.springframework.stereotype.Service;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.catalog.CategoryAuth;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.service.catalog.MenardCatalogService;

/**
 * <p>MenardSecurityService</p>
 * <p>security service</p> 
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Service("menardSecurityService")
public class MenardSecurityServiceImpl implements MenardSecurityService {

	@Autowired
	private FilterSecurityInterceptor security;
	
	@Resource(name = "blCatalogService")
	private MenardCatalogService catalogService;

	@Override
	public void loadSecurityConfig() {
        Map<RequestMatcher, Collection<ConfigAttribute>> map = new HashMap<RequestMatcher, 
        		Collection<ConfigAttribute>>();
        Map<Long, CategoryAuth> authMap = catalogService.groupCategorySecurityData();
        Set<String> fulfillerKeySet = MenardFulfillerType.getFulfillerTypeKeySet();
        ConfigAttribute config = new SecurityConfig("ROLE_V");
		for (Map.Entry<Long, CategoryAuth> authEntry : authMap.entrySet()) {
			String url = authEntry.getValue().getUrl();			
			RequestMatcher matcher = new AntPathRequestMatcher(url);
			List<ConfigAttribute> roles = new ArrayList<ConfigAttribute>();
			boolean flag = false;
			for (String role : authEntry.getValue().getAuthoriseSet()) {
				roles.add(new SecurityConfig(role));
				if (!flag) {
					flag = fulfillerKeySet.contains(role);
				}				
				if (LOG.isDebugEnabled()) {
					LOG.debug("url[" + url + "]role[" + role + "]");
				}
			}		
			
			//Make some unnecessary category(s) invisible
			if (roles.contains(config)) {
				map.put(matcher , roles);
				continue;
			}			
			
			if (roles.size() > 0) {
				roles.add(new SecurityConfig(CommonConstant.ROLE_PREFIX + MenardFulfillerType.SUPER_GO.getKey()));
				map.put(matcher , roles);
				if (!flag) {
					roles.add(new SecurityConfig(CommonConstant.GO_USER_ROLE));
				}
			}
		}		
		appendDefaultUser(map);
		try {
			SecurityMetadataSource source = security.obtainSecurityMetadataSource();
			Field field = DefaultFilterInvocationSecurityMetadataSource.class.getDeclaredField("requestMap");
			field.setAccessible(true);
			@SuppressWarnings("unchecked")
			Map<RequestMatcher, Collection<ConfigAttribute>> orig = (Map<RequestMatcher, Collection<ConfigAttribute>>) 
				field.get(source);
			orig.clear();
			orig.putAll(map);
		} catch (Exception e) {
			LOG.error("When loading category security data" + e.getMessage());
		}
	}
	
	/**
	 * Add default user role for each user
	 * @param map Map<RequestMatcher, Collection<ConfigAttribute>>
	 */
	private void appendDefaultUser(Map<RequestMatcher, Collection<ConfigAttribute>> map) {
		RequestMatcher matcher = new AntPathRequestMatcher("/");
		List<ConfigAttribute> roles = new ArrayList<ConfigAttribute>();
		roles.add(new SecurityConfig(CommonConstant.DEFAULT_USER_ROLE));
		map.put(matcher, roles);
	}
}
