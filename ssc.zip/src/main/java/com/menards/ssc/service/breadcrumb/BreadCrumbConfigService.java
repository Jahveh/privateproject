package com.menards.ssc.service.breadcrumb;

import java.util.List;

import com.menards.ssc.domain.breadcrumb.BreadCrumbConfig;

/**
 * 
 * <p>BreadCrumbConfigService</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public interface BreadCrumbConfigService {

	/**
	 * 
	 * Read BreadCrumb configuration
	 * @return List<BreadCrumbConfig>
	 */
	List<BreadCrumbConfig> getAllBreadCrumbConfigs();

}
