/**
 *
 */
package com.menards.ssc.service.skustatus;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <p>MenardSkuStatusService</p>
 * <p>MenardSkuStatusService</p>
 * <p>
 * Call menard web service to get information on sku status 
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public interface MenardSkuStatusService {

	public static final Log LOG = LogFactory.getLog(MenardSkuStatusService.class);

	/**
	 * Retrieve the sku status of every store
	 * @param skuNumbers List<Integer> 
	 * @return Map<Integer, String>
	 */
	public Map<Integer, String> getStoreAvailabilityBySku(List<Integer> skuNumbers);

	/**
	* Retrieve sku status and 
	* @param skuNumbers List<Integer>
	* @param storeNumber Integer
	* @return List<MenardDerivedStatus>
	*/
	public List<MenardDerivedStatus> getDerivedStatusByStoreSku(List<Integer> skuNumbers, Integer storeNumber);

	
	/**
	 * Retrieve sku codes by taking in store number as parameter
	 * @param skuNumbers List<Integer>
	 * @param storeNumber Integer
	 * @return Map<String, String>
	 */
	public Map<String, String> getDerivedStatusMapByStoreSku(List<Integer> skuNumbers, Integer storeNumber);
}
