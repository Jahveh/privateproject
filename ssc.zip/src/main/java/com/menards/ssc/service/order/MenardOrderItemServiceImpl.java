/**
 *
 */
package com.menards.ssc.service.order;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.annotation.Resource;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.broadleafcommerce.core.catalog.domain.Category;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.catalog.domain.ProductAttribute;
import org.broadleafcommerce.core.catalog.domain.Sku;
import org.broadleafcommerce.core.catalog.domain.SkuAttribute;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.domain.OrderItem;
import org.broadleafcommerce.core.order.domain.OrderItemAttribute;
import org.broadleafcommerce.core.order.service.OrderItemServiceImpl;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.broadleafcommerce.core.order.service.type.OrderItemType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.constants.ProductAttributeKey;
import com.menards.ssc.dao.order.MenardOrderItemDao;
import com.menards.ssc.dao.sign.MenardColorSignDao;
import com.menards.ssc.dao.vendor.MenardVendorDao;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.catalog.ColorSignDTO;
import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.catalog.MenardSkuDTO;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.catalog.SignDTO;
import com.menards.ssc.domain.order.ItemApproveRequestDTO;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.order.MenardOrderItemDTO;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.domain.order.MenardOrderItemHistory;
import com.menards.ssc.domain.order.MenardOrderItemTrackingHistory;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.domain.sign.SignVersion;
import com.menards.ssc.domain.vendor.MenardVendor;
import com.menards.ssc.domain.yard.Store;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderItemType;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.enums.SignSearchType;
import com.menards.ssc.enums.SkuStatus;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.catalog.MenardCatalogService;
import com.menards.ssc.service.catalog.MenardColorSignService;
import com.menards.ssc.service.catalog.MenardSignService;
import com.menards.ssc.service.skustatus.MenardDerivedStatus;
import com.menards.ssc.service.skustatus.MenardSkuStatusService;
import com.menards.ssc.service.yard.MenardYardService;
import com.menards.ssc.strategy.approve.MenardItemApproveStrategy;
import com.menards.ssc.util.MenardUtil;

/**
 * @author leo.yang
 *
 */
@Service("menardOrderItemService")
public class MenardOrderItemServiceImpl extends OrderItemServiceImpl implements MenardOrderItemService, CommonConstant {

	private static final Log LOG = LogFactory.getLog(MenardOrderItemService.class);

	@Resource(name = "menardSkuStatusService")
	private MenardSkuStatusService menardSkuStatusService;

	@Resource(name = "menardOrderItemDao")
	private MenardOrderItemDao orderItemDao;

	@Resource(name = "blCatalogService")
	private MenardCatalogService catalogService;

	@Resource(name = "signService")
	private MenardSignService meanrdSignService;

	@Resource(name = "colorSignService")
	private MenardColorSignService colorSignService;
	
	@Resource(name = "menardYardService")
	private MenardYardService yardService;
	
	@Resource(name = "menardVendorDao")
	private MenardVendorDao menardVendorDao;

	@Resource(name = "menardColorSignDao")
	private MenardColorSignDao menardColorSignDao;

	private static final String TM = "blTransactionManager";

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.menards.ssc.service.order.MenardOrderItemService#findAllOrderItemsForApproval
	 * (com.menards.ssc.domain.order.MenardOrderItemFilterDTO)
	 */
	@Override
	@Transactional(TM)
	public List<MenardOrderItemDTO> findAllOrderItemsForApproval(MenardOrderItemFilterDTO filter) {

		List<MenardOrderItem> orderItems = orderItemDao.findOrderItems(filter);
		List<MenardOrderItemDTO> list = new ArrayList<MenardOrderItemDTO>();
		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		for (MenardOrderItem orderItem : orderItems) {
			list.add(new MenardOrderItemDTO(orderItem, userDetails.isGOUser(), null));
		}
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(TM)
	public Map<String, List<MenardOrderItemDTO>> approveOrderItems(List<ItemApproveRequestDTO> items) {
		if (CollectionUtils.isEmpty(items)) {
			return MapUtils.EMPTY_MAP;
		}
		
		Map<String, String> storeMap = new HashMap<String, String>();
		List<Store> stores = yardService.getYardNameList();
		for (Store store : stores) {
			storeMap.put(store.getStoreNumber(), store.getStoreName());
		}
		
		Map<String, List<MenardOrderItemDTO>> map = new TreeMap<String, List<MenardOrderItemDTO>>();
		for (ItemApproveRequestDTO item : items) {
			if (StringUtils.isBlank(item.getStatus())) {
				continue;
			}
			MenardOrderItem orderItem = orderItemDao.readMenardOrderItemById(item.getId());
			String preStatus = orderItem.getStatus();

			// Make sure that all the items must be valid by checking the product or sku status
			/*if ((orderItem.getSku() != null && !orderItem.getSku().isActive() || orderItem.getProduct() != null
					&& !orderItem.getProduct().isActive())
					&& !StringUtils.equals(item.getStatus(), MenardItemApproveAction.DECLINED.getKey())) {
				LOG.error("Invalid Item with item Id[" + orderItem.getId() + "], product Id["
						+ orderItem.getProduct().getId() + "], sku Id[" + orderItem.getSku().getId() + "]");
				throw new MenardItemApproveStrategyException("Items of inactive product or sku will only be declined");
			}*/

			// Get the next status of order item and update the status of current order item
			String nextStatus = getNextStatusByProduct(orderItem, item.getStatus());
			orderItem.setStatus(nextStatus);
			orderItem.setStatusDate(new Date());
			orderItemDao.saveOrderItem(orderItem);

			MenardOrder order = orderItem.getMenardOrder();

			// The last field will be filled after getting user info
			MenardOrderItemTrackingHistory tracking = new MenardOrderItemTrackingHistory(order.getId(),
					orderItem.getId(), item.getReason(), nextStatus, StringUtils.EMPTY);
			tracking.setCreateDate(new Date());
			orderItemDao.saveOrderItemTrackingHistory(tracking);

			// Add order item to result map
			putOrderItemToMap(map, order.getStoreId(), orderItem, item.getStatus(), preStatus, storeMap.get(order.getStoreId()));
		}
		
		//Batch up sending the messages
		orderItemDao.flush();
		MenardItemApproveStrategy.executeAndClear();
		return map;
	}

	/**
	 * Get the next status of order item according to the product
	 * info, current user and so on. But here is mock data
	 * @param item MenardOrderItem
	 * @param result String
	 * @return String
	 */
	private String getNextStatusByProduct(MenardOrderItem item, String result) {
		MenardItemApproveStrategy strategy = MenardItemApproveStrategy.getStrategy(item.getFulfillerTypeCode());
		/*MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		if (userDetails.isGOUser() && MenardItemApproveAction.BACKORDERED.getKey().equals(result)
				&& MenardOrderItemStatus.PENDING_GM.getValue().equals(item.getStatus())) {
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
		}*/
		String status = strategy.nextStage(item, result);
		if (LOG.isDebugEnabled()) {
			LOG.debug("Approve process: previous status[" + item.getStatus() + "], result[" + result
					+ "] and final status[" + status + "]");
		}
		return status;
	}

	/**
	 * Group the order item data back to front end.
	 * @param map Map<Long, List<MenardOrderItemDTO>>
	 * @param storeId Long
	 * @param orderItem MenardOrderItem
	 * @param result String
	 * @param preStatus String
	 * @param storeName String
	 */
	private void putOrderItemToMap(Map<String, List<MenardOrderItemDTO>> map, String storeId,
			MenardOrderItem orderItem, String result, String preStatus, String storeName) {
		List<MenardOrderItemDTO> list = null;
		if (map.containsKey(storeId)) {
			list = map.get(storeId);
		} else {
			list = new ArrayList<MenardOrderItemDTO>();
			map.put(storeId, list);
		}
		MenardOrderItemDTO dto = new MenardOrderItemDTO(orderItem);
		dto.setStoreName(storeName);
		dto.setPreStatus(MenardOrderItemStatus.getDescriptionByValue(preStatus));
		dto.setResult(result);
		list.add(dto);
	}

	@Override
	@Transactional(TM)
	public MenardOrderItemTrackingHistory saveOrderItemTrackingHistory(MenardOrderItemTrackingHistory history) {
		return orderItemDao.saveOrderItemTrackingHistory(history);
	}

	@Override
	public SearchResult<MenardOrderItemDTO> findOrderItemsPageForApproval(MenardOrderItemFilterDTO filter) {
		SearchResult<MenardOrderItem> itemPage = orderItemDao.findOrderItemsPage(filter);
		SearchResult<MenardOrderItemDTO> result = new SearchResult<MenardOrderItemDTO>();
		result.setTotalResults(itemPage.getTotalResults());
		result.setPage(itemPage.getPage());
		result.setPageSize(itemPage.getPageSize());
		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();

		Map<Integer, MenardOrderItem> orderItemMap = new HashMap<Integer, MenardOrderItem>();
		for (MenardOrderItem orderItem : itemPage.getResult()) {
			if (StringUtils.equals(MenardOrderItemType.COLOR_SIGN.getCode().toString(), orderItem.getItemType())) {
				orderItemMap.put(orderItem.getSignId(), orderItem);
			}
		}

		// Retrieve related color sign information
		Map<Integer, Sign> map = menardColorSignDao.findSignListById(orderItemMap.keySet());

		for (MenardOrderItem orderItem : itemPage.getResult()) {
			result.addElement(new MenardOrderItemDTO(orderItem, userDetails.isGOUser(), map.get(orderItem.getSignId())));

		}
		return result;
	}

	@Override
	@Transactional(TM)
	public MenardOrderItem createMenardOrderItem(Order order, SkuCartItem cartItem) throws ItemNotFoundException {
		final MenardOrderItem item = (MenardOrderItem) orderItemDao.create(OrderItemType.DISCRETE);
		populateOrderItem(item, cartItem);

		// add order item line number
		int size = order.getOrderItems().size();
		item.setLineNumber(size + 1);

		item.setOrder(order);
		item.setMenardOrder((MenardOrder) order);
		return (MenardOrderItem) saveOrderItem(item);
	}

	/**
	 *
	 * create menard discrete order item
	 * @param item MenardOrderItem
	 * @param cartItem SkuCartItem
	 * @return cartItem SkuCartItem
	 * @throws ItemNotFoundException ItemNotFoundException
	 */
	private OrderItem populateOrderItem(MenardOrderItem item, SkuCartItem cartItem) throws ItemNotFoundException {
		Sku sku = catalogService.findSkuById(cartItem.getSkuId());
		Product product = sku.getProduct();

		item.setSku(sku);
		item.setProduct(product);
		item.setMenardSku((MenardSku) sku);
		item.setMenardProduct((MenardProduct) product);

		Category category = product.getDefaultCategory();
		item.setCategory(category);
		item.setQuantity(cartItem.getQuantity());
		item.setNotes(cartItem.getComment());
		item.setItemType(MenardOrderItemType.SKU.getCode().toString());

		return item;
	}

	/**
	 * set OrderItem Attributes from product  & sku
	 * @param orderItem MenardOrderItem
	 */
	@Override
	@Transactional(TM)
	public void populateOrderItemAttributes(MenardOrderItem orderItem) {
		if (MenardOrderItemType.SIGN.getCode().equals(orderItem.getItemType())) {
			this.populateSignItemAttributes(orderItem);
		} else if (MenardOrderItemType.SKU_MAN.getCode().equals(orderItem.getItemType())) {
			populateSkumanItemAttributes(orderItem);
		} else if (MenardOrderItemType.COLOR_SIGN.getCode().equals(orderItem.getItemType())) {
			this.populateColorSignItemAttributes(orderItem);
		} else {
			this.populateSkuItemAttributes(orderItem);
		}
	}

	@Override
	public void populateFulfillerTypeForOrderItem(MenardOrderItem orderItem) {
		if (MenardOrderItemType.SIGN.getCode().toString().equals(orderItem.getItemType())) {
			SignDTO sign = meanrdSignService.findSign(orderItem.getSignId(),
					Integer.valueOf(orderItem.getSignYardNum()), SignSearchType.Place);

			// Request_Type_Cd product
			orderItem.setRequestType(sign.getRequestType().getKey());

			// Fulfiller_Type_Cd product
			orderItem.setFulfillerTypeCode(sign.getFulfillerType().getKey());

		} else if (MenardOrderItemType.COLOR_SIGN.getCode().toString().equals(orderItem.getItemType())) {
			ColorSignDTO colorSign = colorSignService.getSign(orderItem.getSignId().toString(),
					Integer.valueOf(orderItem.getSignYardNum()), SignSearchType.Place);

			// Request_Type_Cd product
			orderItem.setRequestType(colorSign.getRequestType().getKey());

			// Fulfiller_Type_Cd product
			orderItem.setFulfillerTypeCode(colorSign.getFulfillerType().getKey());
		} else if (MenardOrderItemType.SKU_MAN.getCode().equals(orderItem.getItemType())){
			SignDTO sign = meanrdSignService.findPrePrintedFactTagDetail(orderItem.getSignId(), Integer.valueOf(orderItem.getSignYardNum()));

			// Request_Type_Cd product
			orderItem.setRequestType(sign.getRequestType().getKey());

			// Fulfiller_Type_Cd product
			orderItem.setFulfillerTypeCode(sign.getFulfillerType().getKey());
			
		} else {
			//MenardSku sku = (MenardSku) orderItem.getSku();
			//Map<String, SkuAttribute> sAttrs = sku.getSkuAttributes();
			Map<String, ProductAttribute> pAttrs = orderItem.getProduct().getProductAttributes();
			// Request_Type_Cd product
			String requestType = this.getProductAttrStr(pAttrs, ProductAttributeKey.REQUEST_TYPE);
			orderItem.setRequestType(requestType);
			// Fulfiller_Type_Cd product
			//String fulfillerType = this.getSkuAttrStr(sAttrs, SkuAttributeKey.FULFILLER_TYPE);
			String fulfillerType = this.getProductAttrStr(pAttrs, ProductAttributeKey.FULFILLER_TYPE);
			if (StringUtils.isBlank(fulfillerType)) {
				MenardFulfillerType fulfillerTypeEnum = MenardOrderRequestType.getFulfillerByRequestType(requestType);
				if (fulfillerTypeEnum == null) {
					throw new IllegalArgumentException("can not get fulfillertype by request type: " + requestType);
				}
				fulfillerType = fulfillerTypeEnum.getKey();
			}
			orderItem.setFulfillerTypeCode(fulfillerType);
		}
	}

    /**
     * Checks requesttype and fulfillertype on the orderitem.
     * Will pass validation only when both requesttype and fulfillertype are not blank
     * @param orderItem
     * @return true if requesttype and fulfillertype can be found or calculated
     *         false if requesttype and fulfillertype  cannot be found or calculated
     */
    @Override
    public boolean validateFulfillerType(MenardOrderItem orderItem) {
        boolean isValid;
        if (MenardOrderItemType.SIGN.getCode().equals(orderItem.getItemType())) {
            SignDTO sign = meanrdSignService.findSign(orderItem.getSignId(),
                    Integer.valueOf(orderItem.getSignYardNum()), SignSearchType.Place);
            isValid = sign != null && StringUtils.isNotBlank(sign.getRequestType().getKey())
                    && StringUtils.isNotBlank(sign.getFulfillerType().getKey());

        } else if (MenardOrderItemType.COLOR_SIGN.getCode().equals(orderItem.getItemType())) {        	
            ColorSignDTO colorSign = colorSignService.getSign(orderItem.getSignId().toString(),
                    Integer.valueOf(orderItem.getSignYardNum()), SignSearchType.Place);
            isValid = colorSign !=null && StringUtils.isNotBlank(colorSign.getRequestType().getKey())
                                && StringUtils.isNotBlank(colorSign.getFulfillerType().getKey()); 
        } else if (MenardOrderItemType.SKU_MAN.getCode().equals(orderItem.getItemType()))  {
        	SignDTO dto = meanrdSignService.findPrePrintedFactTagDetail(orderItem.getSignId(), 
        			Integer.valueOf(orderItem.getSignYardNum()));        	
        	isValid = dto != null && dto.getFulfillerType() != null && dto.getRequestType() != null;
        } else {
           // MenardSku sku = (MenardSku) orderItem.getSku();
           // Map<String, SkuAttribute> sAttrs = sku.getSkuAttributes();
            Map<String, ProductAttribute> pAttrs = orderItem.getProduct().getProductAttributes();
            // Request_Type_Cd product
            String requestType = this.getProductAttrStr(pAttrs, ProductAttributeKey.REQUEST_TYPE);
            // Fulfiller_Type_Cd product
           // String fulfillerType = this.getSkuAttrStr(sAttrs, SkuAttributeKey.FULFILLER_TYPE);
            String fulfillerType = this.getProductAttrStr(pAttrs, ProductAttributeKey.FULFILLER_TYPE);
            if (StringUtils.isBlank(fulfillerType)) {
                MenardFulfillerType fulfillerTypeEnum = MenardOrderRequestType.getFulfillerByRequestType(requestType);
                if (fulfillerTypeEnum != null) {
                    fulfillerType = fulfillerTypeEnum.getKey();
                }
            }
            isValid = StringUtils.isNotBlank(requestType) && StringUtils.isNotBlank(fulfillerType);
            LOG.info("RequestType[" + requestType + "]FulfillerType[" + fulfillerType + "]IsValid[" + isValid + "]");
        }
        return isValid;
    }

    /**
	 * set OrderItem Attributes from product  & sku
	 * @param orderItem MenardOrderItem
	 */
	@Transactional(TM)
	private void populateSkuItemAttributes(MenardOrderItem orderItem) {
		MenardSku sku = (MenardSku) orderItem.getSku();
		//Map<String, SkuAttribute> sAttrs = sku.getSkuAttributes();
		Map<String, ProductAttribute> pAttrs = orderItem.getProduct().getProductAttributes();

		SkuStatus skuStatus = SkuStatus.DELETED;
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		
		// This is GO order, get the status from all stores
		String menardSku = sku.getRealMenardSku();	
		if (user.isGOUser()) {
			skuStatus = this.getSkuStatusFOrGOUser((MenardSku) sku, orderItem.getMenardOrder().getStoreId());
		} else {
			MenardSkuDTO skuDTO = catalogService.getSkuDTO((MenardSku) sku);
			String menardSkuStatus = skuDTO.getSkuStatusCode();
			if (menardSkuStatus != null) {
				skuStatus = SkuStatus.getSkuStatusByCode(Integer.valueOf(menardSkuStatus));
			}
		}
		// flag_DCM_Order product
		String dcm = CommonConstant.FALSE_STRING;
		if (menardSku != null) {
			dcm = SkuStatus.DC_SPECIAL_ORDER.equals(skuStatus) ? CommonConstant.TRUE_STRING
					: CommonConstant.FALSE_STRING;
		}
		orderItem.setDcItem(dcm);
		menardSku = sku.getMenardSku();
		
		//Request_Type_Cd product
		String requestType = this.getProductAttrStr(pAttrs, ProductAttributeKey.REQUEST_TYPE);
		orderItem.setRequestType(requestType);
		// Fulfiller_Type_Cd product
		//String fulfillerType = this.getSkuAttrStr(sAttrs, SkuAttributeKey.FULFILLER_TYPE);
		String fulfillerType = this.getProductAttrStr(pAttrs, ProductAttributeKey.FULFILLER_TYPE);
		if (StringUtils.isBlank(fulfillerType)) {
			MenardFulfillerType fulfillerTypeEnum = MenardOrderRequestType.getFulfillerByRequestType(requestType);
			if (fulfillerTypeEnum == null) {
				throw new IllegalArgumentException("can not get fulfillertype by request type: " + requestType);
			}
			fulfillerType = fulfillerTypeEnum.getKey();
		}
		orderItem.setFulfillerTypeCode(fulfillerType);

		// STORE_PRINT
		orderItem.setStorePrint(CommonConstant.FALSE_STRING);

		// set default status
		//orderItem.setStatus(getInitStatus(orderItem));
		orderItem.setStatusDate(new Date());

        if (menardSku != null) {
            orderItem.setMenardSkuStr(menardSku);
        }

        Product product = orderItem.getProduct();
        String description = StringUtils.EMPTY;
        if (product != null) {
            ProductAttribute longDesc = pAttrs.get(MenardUtil.getMappingKey(ProductAttributeKey.DESCRIPTION_LONG));
            if (longDesc != null && StringUtils.isNotBlank(longDesc.getValue())) {
                description = StringUtils.trimToEmpty(longDesc.getValue());
            }
            ProductAttribute shortDesc = pAttrs.get(MenardUtil.getMappingKey(ProductAttributeKey.DESCRIPTION_SHORT));
            if (shortDesc != null && StringUtils.isNotBlank(shortDesc.getValue())) {
                if (StringUtils.isNotBlank(description)) {
                    String separator = CommonConstant.SPACE + CommonConstant.MINUS + CommonConstant.SPACE;
                    description = description + separator + shortDesc.getValue();
                } else {
                    description = StringUtils.trimToEmpty(shortDesc.getValue());
                }
            }
            
            //Build the bm sku for SSC sku
            ProductAttribute vendorAttr = pAttrs.get(ProductAttributeKey.VENDOR); 
            String openSku = CommonConstant.DEFAULT_SKU_CODE;
            if (vendorAttr != null && !StringUtils.equals("menards_sos", vendorAttr.getValue())) {            
            	MenardVendor vendor = menardVendorDao.getMenardVendorByVendorId(StringUtils.trim(vendorAttr.getValue()));
            	openSku = StringUtils.isBlank(vendor.getProductCode()) ? openSku : vendor.getProductCode();            	
            }            
            orderItem.setBmSku(openSku + ((MenardProduct)product).getModelNum());
        }
        orderItem.setDescription(description);
        orderItem.setStatus(getInitStatus(orderItem));
	}

	/**
	 * set OrderItem Attributes from sign
	 * @param orderItem MenardOrderItem
	 */
	@Transactional(TM)
	public void populateSignItemAttributes(MenardOrderItem orderItem) {
		orderItem.setDcItem(CommonConstant.FALSE_STRING);

		SignDTO sign = meanrdSignService.findSign(orderItem.getSignId(), Integer.valueOf(orderItem.getSignYardNum()),
				SignSearchType.Place);

		// Request_Type_Cd product
		orderItem.setRequestType(sign.getRequestType().getKey());

		// Fulfiller_Type_Cd product
		orderItem.setFulfillerTypeCode(sign.getFulfillerType().getKey());

		orderItem.setStatusDate(new Date());

		// STORE_PRINT
		orderItem.setStorePrint(sign.getStorePrint());

		// set default SKU and product
		Sku sku = catalogService.findSkuById(CommonConstant.DEFAULT_SKU_ID_SIGN);
		Product product = sku.getProduct();
		//product.setDescription(sign.getDescriptionShort());

		orderItem.setSku(sku);
		orderItem.setProduct(product);
		orderItem.setMenardSku((MenardSku) sku);
		orderItem.setMenardProduct((MenardProduct) product);
        orderItem.setMenardSkuStr(((MenardSku) sku).getMenardSku());

		/*// set item attributes
		OrderItemAttribute signNameAttr = orderItemDao.createOrderItemAttribute();
		signNameAttr.setOrderItem(orderItem);
		signNameAttr.setName(OrderItemAttributeKey.SIGN_NAME_ATTRIBUTE_NAME);
		signNameAttr.setValue(sign.getSignVersion().getSignname());
		orderItem.getOrderItemAttributes().put(OrderItemAttributeKey.SIGN_NAME_ATTRIBUTE_NAME, signNameAttr);		
		*/
		//Add 9000001 plus sign id as sign's bm sku
		orderItem.setBmSku(DEFAULT_OPENSKU_SIGN + sign.getSignVersion().getSignname());

		//Set default status
		orderItem.setStatus(getInitStatus(orderItem));
	}
	
	public void populateSkumanItemAttributes(MenardOrderItem orderItem) {
		orderItem.setDcItem(CommonConstant.FALSE_STRING);
		Sign sign = meanrdSignService.findPrePrintedFactTag(orderItem.getSignId());
		
		//Only in order to take advantage of getting FulfillerType from dto
		SignDTO dto = new SignDTO();
		SignVersion signVersion = new SignVersion();
		signVersion.setSignId(sign.getSignID());
		signVersion.setSignname(sign.getSignName());
		signVersion.setDept(sign.getDept());
		dto.setSignVersion(signVersion);
		dto.setFactTagType(sign.getFactTagType());
		orderItem.setRequestType(dto.getRequestType().getKey());
		orderItem.setFulfillerTypeCode(MenardFulfillerType.FACT_TAG.getKey());
		orderItem.setStatusDate(new Date());
		orderItem.setStorePrint(null);
		
		Sku sku = catalogService.findSkuById(CommonConstant.DEFAULT_SKU_ID_SIGN);
		Product product = sku.getProduct();		
		orderItem.setSku(sku);
		orderItem.setProduct(product);
		orderItem.setMenardSku((MenardSku) sku);
		orderItem.setMenardProduct((MenardProduct) product);
        orderItem.setMenardSkuStr(((MenardSku) sku).getMenardSku());

		// set item attributes
		/*OrderItemAttribute signNameAttr = orderItemDao.createOrderItemAttribute();
		signNameAttr.setOrderItem(orderItem);
		signNameAttr.setName(OrderItemAttributeKey.SIGN_NAME_ATTRIBUTE_NAME);
		signNameAttr.setValue(sign.getSignName());
		orderItem.getOrderItemAttributes().put(OrderItemAttributeKey.SIGN_NAME_ATTRIBUTE_NAME, signNameAttr);	*/	
		
		//Add 9000001 plus sign id as sign's bm sku
		orderItem.setBmSku(DEFAULT_OPENSKU_SIGN + sign.getSignName());
		orderItem.setStatus(getInitStatus(orderItem));
	}

	/**
	 * set OrderItem Attributes from sign
	 * @param orderItem MenardOrderItem
	 */
	@Transactional("blTransactionManager")
	public void populateColorSignItemAttributes(MenardOrderItem orderItem) {
		orderItem.setDcItem(CommonConstant.FALSE_STRING);

		ColorSignDTO colorSign = colorSignService.getSign(orderItem.getSignId().toString(),
				Integer.valueOf(orderItem.getSignYardNum()), SignSearchType.Place);

		// Request_Type_Cd product
		orderItem.setRequestType(colorSign.getRequestType().getKey());

		// Fulfiller_Type_Cd product
		orderItem.setFulfillerTypeCode(colorSign.getFulfillerType().getKey());

		// STORE_PRINT
		orderItem.setStorePrint(colorSign.getStorePrint());
		// set default status
		orderItem.setStatus(getInitStatus(orderItem));
		orderItem.setStatusDate(new Date());

		// set default SKU and product
		Sku sku = catalogService.findSkuById(CommonConstant.DEFAULT_SKU_ID_SIGN);
		Product product = sku.getProduct();
		//product.setDescription(colorSign.getDescriptionLong() + " - " + colorSign.getDescriptionShort());

		orderItem.setSku(sku);
		orderItem.setProduct(product);
		orderItem.setMenardSku((MenardSku) sku);
		orderItem.setMenardProduct((MenardProduct) product);
        orderItem.setMenardSkuStr(((MenardSku) sku).getMenardSku());

		// set item attributes
		/*OrderItemAttribute signNameAttr = orderItemDao.createOrderItemAttribute();
		signNameAttr.setOrderItem(orderItem);
		signNameAttr.setName(OrderItemAttributeKey.SIGN_NAME_ATTRIBUTE_NAME);
		signNameAttr.setValue(colorSign.getSign().getSignName());
		orderItem.getOrderItemAttributes().put(OrderItemAttributeKey.SIGN_NAME_ATTRIBUTE_NAME, signNameAttr);*/
		
		//Add 9000001 plus sign id as color sign's bm sku
		orderItem.setBmSku(DEFAULT_OPENSKU_SIGN + colorSign.getSign().getSignName());
	}

	/**
	 *
	 * get default status for order item status
	 * @param item MenardOrderItem
	 * @return String String
	 */
	private String getInitStatus(MenardOrderItem item) {
		MenardItemApproveStrategy strategy = MenardItemApproveStrategy.getStrategy(item.getFulfillerTypeCode());
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		return strategy.getInitStatus(item, user.isGOUser(), user.getFulfillerType());
	}

	/**
	 * get go user sku status for order item dcm 
	 * @param sku sku
	 * @param storeId storeId
	 * @return skuStatus sku status
	 */
	private SkuStatus getSkuStatusFOrGOUser(MenardSku sku, String storeId) {
		String menardSku = sku.getMenardSku();
		if (menardSku == null || StringUtils.isBlank(sku.getRealMenardSku())) {
			return SkuStatus.SPECIAL_ORDER;
		}
		List<Integer> menardSkuList = new ArrayList<Integer>();
		menardSkuList.add(Integer.valueOf(menardSku));

		List<MenardDerivedStatus> skuStatusList = menardSkuStatusService.getDerivedStatusByStoreSku(menardSkuList,
				Integer.valueOf(storeId));
		if (CollectionUtils.isEmpty(skuStatusList)) {
			return SkuStatus.SPECIAL_ORDER;
		}

		for (MenardDerivedStatus derivedStatus : skuStatusList) {
			if (String.valueOf(SkuStatus.DC_SPECIAL_ORDER.getCode()).equals(derivedStatus.getDerivedStatusCode())) {
				return SkuStatus.DC_SPECIAL_ORDER;
			}
		}

		return SkuStatus.SPECIAL_ORDER;
	}

	/**
	 * get string value from product attribute with key
	 * @param pAttrs  pAttrs
	 * @param key key
	 * @return value
	 */
	@Transactional(TM)
	private String getProductAttrStr(Map<String, ProductAttribute> pAttrs, String key) {
		if (CollectionUtils.isEmpty(pAttrs)) {
			return null;
		}
		ProductAttribute pAttr = pAttrs.get(MenardUtil.getMappingKey(key));
		return pAttr == null ? null : pAttr.getValue();
	}

	/**
	 * get string value from sku attribute with key
	 * @param sAttrs  sAttrs
	 * @param key key
	 * @return value
	 */
	@Transactional(TM)
	private String getSkuAttrStr(Map<String, SkuAttribute> sAttrs, String key) {
		if (CollectionUtils.isEmpty(sAttrs)) {
			return null;
		}
		SkuAttribute sAttr = sAttrs.get(MenardUtil.getMappingKey(key));
		return sAttr == null ? null : sAttr.getValue();
	}

	@Override
	public SearchResult<MenardOrderItemDTO> findOrderItemsPageForHistory(MenardOrderItemFilterDTO filter) {
		SearchResult<MenardOrderItemHistory> itemPage = orderItemDao.findItemHistoryPage(filter);
		SearchResult<MenardOrderItemDTO> result = new SearchResult<MenardOrderItemDTO>();
		result.setTotalResults(itemPage.getTotalResults());
		result.setPage(itemPage.getPage());
		result.setPageSize(itemPage.getPageSize());		
		for (MenardOrderItemHistory orderItem : itemPage.getResult()) {
			result.addElement(new MenardOrderItemDTO(orderItem));

		}
		return result;
	}
	
	@Override
	public String getOrderItemAttrValue(MenardOrderItem item, String name) {
		if (item == null || StringUtils.isBlank(name)) {
			return null;
		}		
		if (item.getOrderItemAttributes() == null) {
			return null;
		}
		OrderItemAttribute promNbr = item.getOrderItemAttributes().get(name);
		if (promNbr == null) {
			return null;
		}
		return promNbr.getValue();
	}

    /**
     * count the total number of all order items awaiting approval
     *
     * @return count long
     */
    @Override
    public long countOrderItemsForApprove() {
        return orderItemDao.countOrderItemsForApprove();
    }

}
