package com.menards.ssc.service.skustatus;

import java.util.List;

import com.menards.service.sku.GetDerivedStatusByStoreSku;

public class SSCGetDerivedStatusByStoreSku extends GetDerivedStatusByStoreSku {
	public void setSkuNumbers(List<Integer> skuNumbers){
		 this.skuNumbers =skuNumbers;
	}
}
