/**
 *
 */
package com.menards.ssc.service.catalog;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.broadleafcommerce.core.order.domain.OrderItemAttribute;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.menards.ssc.constants.OrderItemAttributeKey;
import com.menards.ssc.dao.sign.MenardSignDao;
import com.menards.ssc.domain.catalog.SignDTO;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.domain.sign.SignHistory;
import com.menards.ssc.domain.sign.SignVersion;
import com.menards.ssc.domain.sign.Stock;
import com.menards.ssc.enums.SignSearchType;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

/**
 * <p>MenardSignService</p>
 * <p>sign service</p>
 * <p>
 *  Provide some common methods such as,
 *  retrieve the sign list, save a sign and so on.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Service("signService")
public class MenardSignServiceImpl implements MenardSignService {

	@Resource(name = "menardSignDao")
	private MenardSignDao menardSignDao;

	@Override
	@Transactional("signTransactionManager")
	public void insertSignOrder(MenardOrderItem item) {		
		Integer proNbr = 0;
		String proNbrStr = getOrderItemAttrValue(item, OrderItemAttributeKey.SALE_SIGN_PRO_NBR);
		if (proNbrStr != null) {
			proNbr = Integer.valueOf(proNbrStr);
		}
		
		SignDTO signDTO = menardSignDao.findSign(item.getSignId(), Integer.parseInt(item.getSignYardNum()),
				SignSearchType.Detail, proNbr, null);
		signDTO.setYard(item.getMenardOrder().getStoreId());
		Stock stock = signDTO.getStock();
		
		if (signDTO.getSaleSign() != null) {
			signDTO.getSignVersion().setPromonbr(Integer.valueOf(signDTO.getSaleSign().getPromoNbr()));
		}		
		
		if (stock.getStorePlan() != 1 || stock.getStorePlan() != -1) {
			Map<Integer, String> result = menardSignDao.insertSignOrder(signDTO);
			if (LOG.isDebugEnabled()) {
				LOG.debug(result);
			}

			// 0 represents a success;
			if (StringUtils.isBlank(result.get(0))) {
				LOG.error(result);
			}
		}
	}
	
	private String getOrderItemAttrValue(MenardOrderItem item, String name) {
		if (item == null || StringUtils.isBlank(name)) {
			return null;
		}		
		if (item.getOrderItemAttributes() == null) {
			return null;
		}
		OrderItemAttribute promNbr = item.getOrderItemAttributes().get(name);
		if (promNbr == null) {
			return null;
		}
		return promNbr.getValue();
	}

	@Override
	public SignDTO findSign(Integer signVersionId, Integer yard, SignSearchType type) {
		return menardSignDao.findSign(signVersionId, yard, type);
	}

    @Override
    public SignDTO findSign(Integer signVersionId, Integer yard, SignSearchType searchType, int promoNbr, String type) {
        return menardSignDao.findSign(signVersionId, yard, searchType, promoNbr, type);
    }
    
    public Sign findPrePrintedFactTag(Integer signId) {
    	return menardSignDao.findPrePrintedFactTag(signId);
    }

	@Override
	public SignDTO findPrePrintedFactTagDetail(Integer signId, Integer yard) {		
		//MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		//String locationId = user.getStoreNumber();
		SignDTO sign = new SignDTO();		
		Sign factTag = menardSignDao.findPrePrintedFactTag(signId);	
		if (factTag == null) {
			return null;
		}
		sign.setFactTagType(factTag.getFactTagType());		
		sign.setPrintAt(factTag.getPrintAt());
		sign.setPrintLocation(factTag.getPrintLocation());
		
		SignVersion signVersion = new SignVersion();
		Stock stock = new Stock();
		stock.setDesc(factTag.getStockDescription());
		
		stock.setWidth(new BigDecimal("0"));
		stock.setHeight(new BigDecimal("0"));
		stock.setStorePlan(-99);
		signVersion.setSignId(factTag.getSignID());
		signVersion.setSignname(factTag.getSignName());
		signVersion.setDept(factTag.getDept());
		signVersion.setDesc(factTag.getVersionDescription());
		sign.setSignVersion(signVersion);
		sign.setStock(stock);

		//List<SignHistory> signHistoryList = null;

		//if (user.isGOUser()) {
			//factTag.setCanOrder(true);
			sign.setYardList(menardSignDao.getYardList(String.valueOf(signId)));
		//} else {
          //  signHistoryList = menardSignDao.getSignHistory(factTag.getSignName(), Integer.valueOf(locationId), null);
        //	int processingCount = menardSignDao.getProcessingCount(sign, signHistoryList);
        //	sign.setProcessingCount(processingCount);
        	/*if(user.getStorePerformRole().equalsIgnoreCase("GM") || processingCount < factTag.getOrderableQuantity()){
        		factTag.setCanOrder(true);
			}*/
	    //}	
		return sign;
	}

}
