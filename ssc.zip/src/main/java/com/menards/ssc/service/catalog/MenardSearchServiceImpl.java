package com.menards.ssc.service.catalog;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.broadleafcommerce.core.search.service.DatabaseSearchServiceImpl;
import org.springframework.stereotype.Service;

import com.menards.ssc.dao.product.MenardProductDescDao;
import com.menards.ssc.dao.sign.MenardColorSignDao;
import com.menards.ssc.dao.sign.MenardSignDao;
import com.menards.ssc.domain.catalog.MenardProductDesc;
import com.menards.ssc.domain.catalog.SearchCriteria;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.catalog.SkuDTO;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.domain.sign.SignSaleInfo;
import com.menards.ssc.enums.SkuStatus;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.skustatus.MenardSkuStatusService;

/**
 * <p>MenardSearchServiceImpl</p>
 * <p>Serve the search features</p>
 * <p>
 *  Search different database for supplies, sale sign and sign;
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Service("menardSearchService")
public class MenardSearchServiceImpl extends DatabaseSearchServiceImpl implements MenardSearchService {

	@Resource(name = "menardProductDescDao")
	private MenardProductDescDao productDescDao;

	@Resource(name = "menardSignDao")
	private MenardSignDao signDao;

	@Resource(name = "menardColorSignDao")
	private MenardColorSignDao colorSignDao;

	@Resource(name = "menardSkuStatusService")
	private MenardSkuStatusService skuStatusService;

	@Override
	public SearchResult<SkuDTO> findSkuPage(SearchCriteria criteria) {
		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		String storeNumber = StringUtils.EMPTY;
		Map<String, String> skuCodeMap = null;
		if (!userDetails.isGOUser()) {
			storeNumber = userDetails.getStoreNumber();
			List<Integer> skucodeCol = productDescDao.fulltextSearchSkuCode(criteria.getQuery());
			skuCodeMap = skuStatusService.getDerivedStatusMapByStoreSku(skucodeCol, Integer.parseInt(storeNumber));
		}
		criteria.setYardNumber(storeNumber);
		SearchResult<MenardProductDesc> skuResult = productDescDao.findDescPage(criteria.getPage(),
				criteria.getPageSize(), criteria.getQuery(), retrieveValidSkucode(skuCodeMap));
		SearchResult<SkuDTO> result = new SearchResult<SkuDTO>();
		Set<Long> skuCodeSet = new HashSet<Long>();
		Map<String, MenardProductDesc> map = new HashMap<String, MenardProductDesc>();
		for (MenardProductDesc desc : skuResult.getResult()) {
			skuCodeSet.add(Long.valueOf(desc.getId().getSkuCode()));
			map.put(String.valueOf(desc.getId().getSkuCode()), desc);
		}

		for (MenardProductDesc desc : skuResult.getResult()) {
			String status = StringUtils.EMPTY;
			if (skuCodeMap != null) {
				status = skuCodeMap.get(desc.getId().getSkuCode());
			}
			result.addElement(new SkuDTO(desc, status));
		}

		result.setPage(skuResult.getPage());
		result.setPageSize(skuResult.getPageSize());
		result.setTotalResults(skuResult.getTotalResults());
		return result;
	}

	/**
	 * Filter all the invalid sku code
	 * @param skuCodeMap Map<String, String>
	 * @return Collection<String>
	 */
	@SuppressWarnings("unchecked")
	private Collection<String> retrieveValidSkucode(Map<String, String> skuCodeMap) {
		if (skuCodeMap == null) {
			return null;
		}
		if (MapUtils.isEmpty(skuCodeMap)) {
			return CollectionUtils.EMPTY_COLLECTION;
		}
		Set<String> set = new HashSet<String>();
		for (Map.Entry<String, String> entry : skuCodeMap.entrySet()) {
			if (SkuStatus.DELETED.getCode() != Integer.parseInt(entry.getValue())) {
				set.add(entry.getKey());
			}
		}
		return set;
	}

	@Override
	public SearchResult<Sign> findSignPage(SearchCriteria criteria) {

		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		Integer yardNum = null;

		if (userDetails.isYard()) {
			yardNum = Integer.valueOf(userDetails.getStoreNumber());
		}

		// Get the total rows of sign
		String text = StringUtils.upperCase(StringUtils.trimToEmpty(criteria.getQuery()));
		int signCount = signDao.findSignTotalCount(text, yardNum, false);
		int signTotalPage = getTotalPage(signCount, criteria.getPageSize());

		// Get the total rows of color sign
		int colorSignCount = colorSignDao.findColorSignCount(text, yardNum);
		int colorSignTotalPage = getTotalPage(colorSignCount, criteria.getPageSize());

		// Get the total rows of fact tag
		int factTagCount = signDao.getPrePrintedFactTags(criteria.getQuery(), Integer.MAX_VALUE, 0).size();
		int factTagTotalPage = getTotalPage(factTagCount, criteria.getPageSize());

		int total = signCount + colorSignCount + factTagTotalPage;
		int totalPage = getTotalPage(total, criteria.getPageSize());
		// int shift = signCount;//getShift(signCount, criteria.getPageSize(), signTotalPage);

		if (LOG.isDebugEnabled()) {
			LOG.debug("signCount[" + signCount + "]signTotalPage[" + signTotalPage + "]colorSignCount["
					+ colorSignCount + "]colorSignTotalPage[" + colorSignTotalPage + "]total[" + total + "]totalPage["
					+ totalPage + "]");
		}

		SearchResult<Sign> result = new SearchResult<Sign>();
		result.setPage(criteria.getPage());
		result.setPageSize(criteria.getPageSize());
		result.setTotalResults(total);

		if (total == 0) {
			return result;
		}

		int pageSize = criteria.getPageSize();

		// All the signs is in the same page
		if (totalPage == 1 && criteria.getPage() == 1) {
			SearchResult<Sign> signResult = signDao.findSignPage(1, pageSize, text);
			result.setResult(signResult.getResult());
			signResult = colorSignDao.findColorSignPageWithIndex(0, pageSize, text, yardNum);
			result.addAllElements(signResult.getResult());
			List<Sign> list = signDao.getPrePrintedFactTags(text, pageSize, 0);
			result.addAllElements(list);
			return result;
		}

		if (LOG.isDebugEnabled()) {
			LOG.debug("Current page [" + criteria.getPage() + "]");
		}
		boolean emptyColorAndFact = (colorSignTotalPage == 0 && factTagTotalPage == 0);
		boolean wholePage = (signTotalPage * pageSize == signCount);
		// Only search sign database
		if (criteria.getPage() < signTotalPage
				|| (criteria.getPage() == signTotalPage && (emptyColorAndFact || wholePage))) {
			SearchResult<Sign> signResult = signDao.findSignPage(criteria.getPage(), pageSize, text);
			result.setResult(signResult.getResult());
			return result;
		}

		// Get the total page of sign and color
		int signAndColorPage = getTotalPage(signCount + colorSignCount, pageSize);

		// Only search color sign database
		if (criteria.getPage() > signTotalPage && criteria.getPage() <= signAndColorPage) {
			int beginIndex = getBeginIndex(criteria.getPage(), pageSize, signCount);
			int endIndex = beginIndex + criteria.getPageSize();
			if (LOG.isDebugEnabled()) {
				LOG.debug("Only ColorSign beginPage[" + criteria.getPage() + "]beginIndex[" + beginIndex + "]endIndex["
						+ endIndex + "]");
			}
			SearchResult<Sign> signResult = colorSignDao
					.findColorSignPageWithIndex(beginIndex, endIndex, text, yardNum);
			result.setResult(signResult.getResult());
			return result;
		}

		// Only search factTag
		if (criteria.getPage() > signAndColorPage) {
			int beginIndex = getBeginIndex(criteria.getPage(), criteria.getPageSize(), signCount + colorSignCount);
			int endIndex = beginIndex + criteria.getPageSize();
			if (LOG.isDebugEnabled()) {
				LOG.debug("Only FactTag beginPage[" + criteria.getPage() + "]beginIndex[" + beginIndex + "]endIndex["
						+ endIndex + "]");
			}
			List<Sign> list = signDao.getPrePrintedFactTags(text, criteria.getPageSize(), beginIndex);
			result.setResult(list);
			return result;
		}

		// Span sign and color database search
		boolean span = (criteria.getPage() == signTotalPage)
				&& ((signTotalPage + colorSignTotalPage) >= signAndColorPage);
		if (span) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("Span sign beginPage[" + criteria.getPage() + "]");
			}
			SearchResult<Sign> signResult = signDao.findSignPage(criteria.getPage(), criteria.getPageSize(), text);
			result.setResult(signResult.getResult());

			// int beginIndex = getBeginIndex(1, criteria.getPageSize(), shift);
			int endIndex = criteria.getPageSize() - (signCount - (signTotalPage - 1) * criteria.getPageSize());
			if (LOG.isDebugEnabled()) {
				LOG.debug("Span ColorSign beginIndex[" + 1 + "]endIndex[" + endIndex + "]");
			}
			signResult = colorSignDao.findColorSignPageWithIndex(1, endIndex, text, yardNum);
			result.addAllElements(signResult.getResult());
			return result;
		}

		// Span factTag and color database search
		span = (criteria.getPage() == signAndColorPage);
		if (span) {
			int beginIndex = signCount + colorSignCount - (signAndColorPage - 1) * criteria.getPageSize();
			int endIndex = beginIndex + criteria.getPageSize();
			if (LOG.isDebugEnabled()) {
				LOG.debug("Span ColorSign beginPage[" + beginIndex + "]");
			}
			SearchResult<Sign> signResult = colorSignDao
					.findColorSignPageWithIndex(beginIndex, endIndex, text, yardNum);
			result.setResult(signResult.getResult());

			endIndex = criteria.getPageSize() - signResult.getResult().size();
			if (LOG.isDebugEnabled()) {
				LOG.debug("Span FactTag beginIndex[" + 0 + "]endIndex[" + endIndex + "]");
			}
			List<Sign> list = signDao.getPrePrintedFactTags(text, endIndex, 0);
			result.addAllElements(list);
			return result;
		}

		// Span sign and factTagTotalPage database search
		int signFactTagPage = getTotalPage(signCount + factTagCount, criteria.getPageSize());
		span = colorSignCount == 0 && (criteria.getPage() == signTotalPage)
				&& ((signTotalPage + factTagTotalPage) >= signFactTagPage);
		if (span) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("Span sign beginPage[" + criteria.getPage() + "]");
			}
			SearchResult<Sign> signResult = signDao.findSignPage(criteria.getPage(), criteria.getPageSize(), text);
			result.setResult(signResult.getResult());

			int endIndex = criteria.getPageSize() - signResult.getResult().size();
			if (LOG.isDebugEnabled()) {
				LOG.debug("Span FactTag beginIndex[" + 0 + "]endIndex[" + endIndex + "]");
			}
			List<Sign> list = signDao.getPrePrintedFactTags(text, endIndex, 0);
			result.addAllElements(list);
			return result;
		}
		return null;
	}

	/**
	 * 
	 * @param page int
	 * @param size int
	 * @param shift int
	 * @return int
	 */
	private int getBeginIndex(int page, int size, int shift) {
		return (page - 1) * size - shift;
	}

	/**
	 * 
	 * @param total int
	 * @param pageSize int
	 * @return int
	 */
	private int getTotalPage(int total, int pageSize) {
		return (int) Math.ceil(total * 1.0 / pageSize);
	}

	@Override
	public SearchResult<Sign> findSaleSignPage(SearchCriteria criteria) {
		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		Integer locationId = null;

		if (userDetails.isYard()) {
			locationId = Integer.parseInt(userDetails.getStoreNumber());
		} else {
			locationId = Integer.valueOf(criteria.getYardNumber());
		}
		String text = StringUtils.upperCase(StringUtils.trimToEmpty(criteria.getQuery()));
		SearchResult<Sign> signResult = signDao.findSaleSignPage(criteria.getPage(), criteria.getPageSize(), text,
				locationId);
		List<Sign> result = new ArrayList<Sign>();

		for (Sign sign : signResult.getResult()) {
			List<SignSaleInfo> saleSignList = signDao.getSaleSigns(sign.getSignID(), sign.getYard());
			for (SignSaleInfo signSaleInfo : saleSignList) {
				Sign tmp = new Sign();
				try {
					BeanUtils.copyProperties(tmp, sign);
				} catch (Exception e) {
					LOG.error("When copying property " + e.getMessage());
				}
				tmp.setSaleSignInfo(signSaleInfo);
				result.add(tmp);
			}
		}
		signResult.setResult(result);
		return signResult;
	}

	@Override
	public SearchResult<SkuDTO> findProductDescPage(SearchCriteria criteria) {
		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		String storeNumber = StringUtils.EMPTY;
		Map<String, String> skuCodeMap = null;
		if (!userDetails.isGOUser()) {
			storeNumber = userDetails.getStoreNumber();
			if (StringUtils.length(criteria.getQuery()) >= 3) {
				List<Integer> list = productDescDao.findSkuCodesForSkuClass(criteria.getQuery());
				skuCodeMap = skuStatusService.getDerivedStatusMapByStoreSku(list, Integer.parseInt(storeNumber));
			}
		}

		SearchResult<MenardProductDesc> skuResult = productDescDao.findProductDescPage(criteria.getPage(),
				criteria.getPageSize(), criteria.getQuery(), retrieveValidSkucode(skuCodeMap));
		SearchResult<SkuDTO> result = new SearchResult<SkuDTO>();
		Set<Long> skuCodeSet = new HashSet<Long>();
		Map<String, MenardProductDesc> map = new HashMap<String, MenardProductDesc>();
		for (MenardProductDesc desc : skuResult.getResult()) {
			skuCodeSet.add(Long.valueOf(desc.getId().getSkuCode()));
			map.put(String.valueOf(desc.getId().getSkuCode()), desc);
		}

		for (MenardProductDesc desc : skuResult.getResult()) {
			String status = StringUtils.EMPTY;
			if (skuCodeMap != null) {
				status = skuCodeMap.get(desc.getId().getSkuCode());
			}
			result.addElement(new SkuDTO(desc, status));
		}

		result.setPage(skuResult.getPage());
		result.setPageSize(skuResult.getPageSize());
		result.setTotalResults(skuResult.getTotalResults());
		return result;
	}
}
