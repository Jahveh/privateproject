package com.menards.ssc.service.order;

import java.util.List;

import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.service.OrderService;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.broadleafcommerce.core.order.service.exception.RemoveFromCartException;
import org.broadleafcommerce.core.order.service.exception.UpdateCartException;
import org.broadleafcommerce.core.order.service.type.OrderStatus;

import com.menards.ssc.domain.cart.AddCartRequest;
import com.menards.ssc.domain.cart.SignCartItem;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.order.MenardCartinfoDTO;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderDTO;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.domain.order.MenardOrderItemHistory;

/**
 *
 * <p>MenardOrderService</p>
 * <p>An Menard Order Service that provides convenience methods and resource declarations</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public interface MenardOrderService extends OrderService {
	
	/**
	 *
	 * Get Order By Pagination
	 * @param filterDTO filterDTO
	 * @return List list
	 */
	public SearchResult<MenardOrderDTO> getOrderByPagination(MenardOrderItemFilterDTO filterDTO);	
	
	/**
	 *
	 * Get Order By UserId with Pagination
	 * @param filterDTO filterDTO
	 * @param userId userId
	 * @param status status
	 * @return List list
	 */
	public SearchResult<MenardOrderDTO> findOrdersByUserId(MenardOrderItemFilterDTO filterDTO, String userId,
			OrderStatus status);

	/**
	 *
	 * Get Order By Filter
	 * @param filterDTO filterDTO
	 * @return List list
	 */
	public List<MenardOrderDTO> getOrderByFilter(MenardOrderItemFilterDTO filterDTO);

	/**
	 * Get Order By Id.
	 * @param orderId orderId
	 * @return Order Order
	 */
	public Order getOrderById(Long orderId);

	/**
	 *
	 * Get Tracking History By orderItemId.	
	 * @param orderItemId orderItemId
	 * @return MenardOrderItem MenardOrderItem
	 */
	public MenardOrderItemHistory getTrackingHistory(Long orderItemId);

	/**
	 * update order items
	 *
	 * @param cartItems cartItems
	 * @param order order
	 * @return Order Order
	 * @throws ItemNotFoundException 
	 * @throws RemoveFromCartException
	 * @throws UpdateCartException
	 */
	public Order updateOrderItems(Order order, List<SkuCartItem> cartItems) throws ItemNotFoundException;

	/**
	 * place order
	 *
	 * @param order order
	 * @param storeIds storeIds
	 * @return 
	 */
	public void placedOrder(Order order, List<String> storeIds);

	/**
	 * remove item from order
	 *
	 * @param orderItemId orderItemId
	 * @param order order
	 * @return Order Order
	 */
	public Order removeItem(Order order, Long orderItemId);

	/**
	 * remove item from order
	 *
	 * @param orderItemIds orderItemIds
	 * @param order order
	 * @return Order Order
	 */
	public Order removeItems(Order order, Long[] orderItemIds);

	/**
	 * save order
	 * 
	 *
	 * @param menardOrder menardOrder
	 * @param cartinfoDTO MenardCartinfoDTO
	 * @return Order order
	 */
	public Order saveMenardOrder(Order menardOrder, MenardCartinfoDTO cartinfoDTO);

	/** 
	 * @param cart cart
	 * @param cartItem cartItem
	 * @return Order Order
	 * @throws ItemNotFoundException 
	 */
	public Order addItem(Order cart, SkuCartItem cartItem) throws ItemNotFoundException;

	/**
	 * find MenardOrder By Status
	 * @param status status
	 * @return List list
	 */
	public List<MenardOrder> findMenardOrderByStatus(OrderStatus status);

	/**
	 * first, remove order item
	 * second, update rest order items
	 * @param removeItemId removeItemId
	 * @param order order
	 * @param cartItems cartItems
	 * @return Order Order
	 * @throws ItemNotFoundException 
	 */
	public Order updateOrderItems(Long removeItemId, Order order, List<SkuCartItem> cartItems)
			throws ItemNotFoundException;

	/**
	 * load order to cart
	 * @param cart cart
	 * @param orderId Long
	 * @return Order Order
	 */
	public Order replaceCart(Order cart, Long orderId);

	/**
	 * add items to cart, main sku, option skus, require skus
	 * @param order order
	 * @param request request
	 * @return
	 * @throws ItemNotFoundException 
	 */
	public void addItems2Cart(Order order, AddCartRequest request) throws ItemNotFoundException;

	/** 
	 * @param cart cart
	 * @param signItem signItem
	 * @return Order Order
	 * @throws ItemNotFoundException 
	 */
	public Order addSign2Cart(Order cart, SignCartItem signItem) throws ItemNotFoundException;

	/** 
	 * @param cart cart
	 * @param signItems signItems	
	 * @throws ItemNotFoundException 
	 */
	public void addSigns2Cart(Order cart, List<SignCartItem> signItems) throws ItemNotFoundException;

	/**
	 * find cart by user Id
	 * @param userId String
	 * @return order cart
	 */
	public Order findCartByUserId(String userId);

	/**
	 * create order for new user
	 * @param userId userId
	 * @return Order order
	 */
	public Order createOrderForNewUser(String userId);

	/**
	 * find Orders By UserId
	 * @param userId userId
	 * @param status status
	 * @return Order order
	 */
	public List<MenardOrder> findOrdersByUserId(String userId, OrderStatus status);

}
