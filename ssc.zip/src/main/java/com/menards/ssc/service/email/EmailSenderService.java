/**
 * 
 */
package com.menards.ssc.service.email;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.mail.SimpleMailMessage;

/**
 * <p>EmailSenderService</p>
 * <p>EmailSenderService</p>
 * <p>  
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public interface EmailSenderService {

	public static final Logger LOG = Logger.getLogger(EmailSenderService.class);

	/**
	 * Sending text email
	 * @param message SimpleMailMessage
	 * @return boolean
	 */
	public boolean sendTextEmail(SimpleMailMessage message);

	/**
	 * Sending email by parsing the template and then replace placeholder
	 * @param message  SimpleMailMessage
	 * @param name String
	 * @param model Map<String, Object>
	 * @return boolean
	 */
	public boolean sendEmailWithTemplate(SimpleMailMessage message, final String name, final Map<String, Object> model);

}
