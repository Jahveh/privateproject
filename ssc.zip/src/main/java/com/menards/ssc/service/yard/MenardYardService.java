package com.menards.ssc.service.yard;

import java.util.List;

import com.menards.ssc.domain.yard.Store;

/**
 * 
 * <p>MenardYardService</p>
 * <p>Menard Yard Service is about to get yard information from rights DB</p> 
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public interface MenardYardService {

	/**
	 * 
	 * get store by store Number
	 * @param storeNumber storeNumber
	 * @return Store
	 */
	public Store getStore(String storeNumber);

	/**
	 * 
	 * get all stores for Item History, Approval, and Order Options
	 * @return List<Store>
	 */
	public List<Store> getYardNameList();

	/**
	 * 
	 * get all stores For Remodel Dates
	 * @return List<Store>
	 */
	public List<Store> getYardForRemodelDates();

}
