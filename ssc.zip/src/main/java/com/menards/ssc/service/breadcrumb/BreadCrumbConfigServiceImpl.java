package com.menards.ssc.service.breadcrumb;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.menards.ssc.dao.breadcrumb.BreadCrumbConfigDao;
import com.menards.ssc.domain.breadcrumb.BreadCrumbConfig;

/**
 * 
 * <p>BreadCrumbConfigServiceImpl</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
@Service("breadCrumbConfigService")
public class BreadCrumbConfigServiceImpl implements BreadCrumbConfigService {
	@Resource(name = "breadCrumbConfigDao")
	private BreadCrumbConfigDao breadCrumbConfigDao;

	@Override
	public List<BreadCrumbConfig> getAllBreadCrumbConfigs() {
		return breadCrumbConfigDao.readAllBreadCrumbConfigs();

	}

}
