/**
 *
 */
package com.menards.ssc.service.catalog;

import java.util.List;

import org.apache.log4j.Logger;

import com.menards.ssc.domain.cart.SignCartItem;
import com.menards.ssc.domain.catalog.ColorSignDTO;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.SignSearchType;

/**
 * <p>MenardColorSignService</p>
 * <p>Color sign service</p>
 * <p>
 *  Provide some common methods such as,
 *  retrieve the sign list, save a sign and so on.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public interface MenardColorSignService {

	public static final Logger LOG = Logger.getLogger(MenardColorSignService.class);

    public int findColorSignCatalogId(Integer signId);

	/**
	 * Save color sign to data base
	 * @param item OrderItem
	 * @return Boolean
	 */
	public Boolean saveSignOrder(MenardOrderItem item);

	/**
	 * get sign by sign Id
	 * @param signId signId
	 * @param yard yard
	 * @param type type
	 * @return ColorSignDTO ColorSignDTO
	 */
	public ColorSignDTO getSign(final String signId, Integer yard, SignSearchType type);

	/**
	 * get sign by catalog Id
	 * @param catalogID catalogID
	 * @param limit limit
	 * @param offset offset
	 * @return List List
	 */
	public List<SignCartItem> getSignsByCatalogID(long catalogID, int limit, int offset);
	
	/**
	 * Get quality of  Color sign 
	 * @param signId int
	 * @param locationId int
	 * @param leadTime int
	 * @return int
	 */
	public int getQuantityOrdered(int signId, int locationId, int leadTime);

	/**
	 * get sign by catalog Id
	 * @param catalogID catalogID
	 * @return long long
	 */
	long countByCatalogID(long catalogID);

}
