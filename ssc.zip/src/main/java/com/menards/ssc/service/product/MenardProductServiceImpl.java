/*
 * ProductServiceImpl
 * 
 * 2014-04-30
 *
 * Copyright (c) 2014
 * Menard Inc.
 */
package com.menards.ssc.service.product;

import com.menards.ssc.dao.product.MenardProductDao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.broadleafcommerce.core.catalog.domain.ProductAttribute;
import org.broadleafcommerce.core.catalog.domain.SkuAttribute;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import java.util.List;

/**
 * Menard product service.
 * User this to query product and SKU information.
 *
 * @author james.ni
 */
@Service("menardProductService")
public class MenardProductServiceImpl implements MenardProductService {

    private static final Log LOG = LogFactory.getLog(MenardProductServiceImpl.class);

    @Resource(name = "blProductDao")
    private MenardProductDao productDao;

    @Override
    public List<ProductAttribute> getProductAttributes(Long productId) {
        return productDao.getProductAttributes(productId);
    }

    @Override
    public List<SkuAttribute> getSkuAttributes(Long skuId) {
        return productDao.getSkuAttributes(skuId);
    }
}