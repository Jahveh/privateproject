/*
 * ProductServiceImpl
 *
 * 2014-04-30
 *
 * Copyright (c) 2014
 * Menard Inc.
 */
package com.menards.ssc.service.product;

import org.broadleafcommerce.core.catalog.domain.ProductAttribute;
import org.broadleafcommerce.core.catalog.domain.SkuAttribute;

import java.util.List;

/**
 * Menard product service, also acts as SKU service
 *
 * @author james.ni
 */
public interface MenardProductService {

    /**
     * Get product attribute by product ID
     *
     * @param productId
     * @return
     */
    List<ProductAttribute> getProductAttributes(Long productId);

    /**
     * Get SKU attribute by SKU ID
     *
     * @param skuId
     * @return
     */
    List<SkuAttribute> getSkuAttributes(Long skuId);
}
