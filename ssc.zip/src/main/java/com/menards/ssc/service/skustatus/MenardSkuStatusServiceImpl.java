package com.menards.ssc.service.skustatus;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.menards.service.sku.DerivedStatus;
import com.menards.service.sku.GetStoreAvailabilityBySkuResponse;
import com.menards.service.sku.SkuService;
import com.menards.service.sku.StoreAvailability;
import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.enums.SkuStatus;

/**
 * <p>MenardSkuStatusServiceImpl</p>
 * <p>MenardSkuStatusService</p>
 * <p>
 * The wrapper service around Sku service of meanrd in order to be convenient
 * to invoking
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Service("menardSkuStatusService")
public class MenardSkuStatusServiceImpl implements MenardSkuStatusService, CommonConstant {
	
	private static final int TESTSTORE_THRESHOLD = 3998;
	
	@Value("${test.store}")
	private Integer testStore;
	
	@Resource(name = "skuService")
	private SkuService skuService;

	@Override
	public Map<Integer, String> getStoreAvailabilityBySku(List<Integer> skuNumbers) {

		SSCGetStoreAvailabilityBySku parameters = new SSCGetStoreAvailabilityBySku();
		parameters.setSkuNumbers(skuNumbers);
		GetStoreAvailabilityBySkuResponse response = skuService.getStoreAvailabilityBySku(parameters);
		List<StoreAvailability> list = response.getReturn().getStoreAvailability();

		Map<Integer, String> map = new HashMap<Integer, String>();
		for (StoreAvailability availability : list) {
			boolean flag = availability.isStoreAvailabilityFlag();
			if (LOG.isDebugEnabled()) {
				LOG.debug("StoreAvailability[" + availability.getSkuNumber() + "][" + flag + "]");
			}
			map.put(availability.getSkuNumber(), TRUE_STRING);
			if (!flag) {
				map.put(availability.getSkuNumber(), FALSE_STRING);
			}
		}
		return map;
	}

	@Override
	public List<MenardDerivedStatus> getDerivedStatusByStoreSku(List<Integer> skuNumbers, Integer storeId) {
		Integer storeNumber= processTestStore(storeId);
		
		SSCGetDerivedStatusByStoreSku parameters = new SSCGetDerivedStatusByStoreSku();
		parameters.setStoreNumber(storeNumber);
		Set<Integer> set = new HashSet<Integer>();
		Set<Integer> allSkuNumbers = new HashSet<Integer>();
		Set<DerivedStatus> response = new HashSet<DerivedStatus>();
		List<MenardDerivedStatus> list = new ArrayList<MenardDerivedStatus>();
		for (Integer skucode : skuNumbers) {
			set.add(skucode);
			if (set.size() >= CALL_BATCH) {
				response.addAll(callSkustatusService(parameters, set));
				set.clear();
			}
		}		
		if (CollectionUtils.isNotEmpty(set)) {
			response.addAll(callSkustatusService(parameters, set));
		}	
		allSkuNumbers.addAll(skuNumbers);
		for (DerivedStatus status : response) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("DerivedStatusByStoreSku[" + status.getStoreNumber() + "][" + status.getSkuNumber() + "]["
						+ status.getDerivedStatusCode() + "]");
			}
			allSkuNumbers.remove(status.getSkuNumber());
			list.add(new MenardDerivedStatus(status.getStoreNumber(), status.getSkuNumber(), status
					.getDerivedStatusCode()));
		}
		
		if (CollectionUtils.isNotEmpty(allSkuNumbers)) {
			for (Integer skucode : allSkuNumbers) {
				list.add(new MenardDerivedStatus(storeNumber, skucode, SkuStatus.DELETED.getStrCode()));
			}
		}
		return list;
	}
	
	private static final int CALL_BATCH = 450;
	
	/**
	 * Batchly call the sku status service
	 * @param parameter GetDerivedStatusByStoreSku
	 * @param col Collection<Integer>
	 * @return List<DerivedStatus>
	 */
	private List<DerivedStatus> callSkustatusService(SSCGetDerivedStatusByStoreSku parameter, Collection<Integer> col) {
		List<Integer> skuCodeList = new ArrayList<Integer>(CALL_BATCH);
		skuCodeList.addAll(col);
		parameter.setSkuNumbers(skuCodeList);
		return skuService.getDerivedStatusByStoreSku(parameter).getReturn().getDerivedStatus();
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, String> getDerivedStatusMapByStoreSku(List<Integer> skuNumbers, Integer storeNumber) {
		List<MenardDerivedStatus> list = getDerivedStatusByStoreSku(skuNumbers, storeNumber);
		if (CollectionUtils.isEmpty(list)) {
			return MapUtils.EMPTY_MAP;
		}
		Map<String, String> map = new HashMap<String, String>();
		for (MenardDerivedStatus menardDerivedStatus : list) {
			map.put(menardDerivedStatus.getSkuNumber().toString(), menardDerivedStatus.getDerivedStatusCode());
		}
		return map;
	}
	
	private Integer processTestStore(Integer storeNumber){
		if (storeNumber >= TESTSTORE_THRESHOLD) {
			return testStore;
		}
		return storeNumber;
	}
}
