package com.menards.ssc.service.catalog;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import org.broadleafcommerce.common.media.domain.Media;

import org.apache.commons.lang.math.NumberUtils;

import org.broadleafcommerce.core.catalog.domain.Category;
import org.broadleafcommerce.core.catalog.domain.CategoryAttribute;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.catalog.domain.ProductAttribute;
import org.broadleafcommerce.core.catalog.domain.Sku;
import org.broadleafcommerce.core.catalog.service.CatalogServiceImpl;
import org.broadleafcommerce.core.order.service.exception.ItemNotFoundException;
import org.springframework.transaction.annotation.Transactional;

import com.menards.ssc.constants.CategoryAttributeKey;
import com.menards.ssc.constants.ProductAttributeKey;
import com.menards.ssc.dao.order.MenardOrderItemDao;
import com.menards.ssc.dao.product.MenardProductDao;
import com.menards.ssc.dao.vendor.MenardVendorDao;
import com.menards.ssc.domain.cart.SkuCartItem;
import com.menards.ssc.domain.catalog.*;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.vendor.MenardVendor;
import com.menards.ssc.enums.ProductVisibility;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.skustatus.MenardDerivedStatus;
import com.menards.ssc.service.skustatus.MenardSkuStatusService;
import com.menards.ssc.state.MenardGetStatus;

/**
 * <p>MenardCatalogServiceImpl</p>
 * <p>extend from broadleaf catalog service</p>
 * <p/>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 *
 * @author bill01.zhang
 * @version 1.0
 */
public class MenardCatalogServiceImpl extends CatalogServiceImpl implements MenardCatalogService {

    @Resource(name = "menardSkuStatusService")
    private MenardSkuStatusService menardSkuStatusService;

    @Resource(name = "blProductDao")
    private MenardProductDao productDao;

    @Resource(name = "menardOrderItemDao")
    private MenardOrderItemDao orderItemDao;

    @Resource(name = "menardVendorDao")
    private MenardVendorDao menardVendorDao;

    @Override
    public Long countProductForCategory(Category category, List<ProductFilter> productFilters) {
        MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
        if (user.isGOUser()) {
            // If a GO user has rights to see a specific product family in the Store Supplies Catalog,
            // then all products there are visible to him/her.
            // SKU status and guest orderable values do not hinder the visibility of these products.
            Long totalResults = productDao.countProductForCategory(category, productFilters);
            return totalResults;
        } else {
            List<Product> products = productDao.findAllProductsByCategoryId(category.getId(), productFilters);
            List<String> productIdList = getFilteredProductIdsByVisibility(products);
            return Long.valueOf(productIdList.size());
        }
    }

    @Override
    @Transactional("blTransactionManager")
    public List<Category> findAllCategories() {
        List<Category> categories = categoryDao.readAllCategories();
        for (Category category : categories) {
            if (category.getCategoryMedia() != null && category.getCategoryMedia().get("primary") != null) {
                category.getCategoryMedia().get("primary").getUrl();
            }
            CategoryAttribute categoryAttribute = category.getCategoryAttributeByName("Display_Priority");
            if (categoryAttribute != null) {
                String displayPriority = categoryAttribute.getValue();
                if (!StringUtils.isEmpty(displayPriority)) {
                    if (NumberUtils.isNumber(displayPriority)) {
                        CategoryTreeService.categoryOrderDict.put(category.getId(), Long.parseLong(displayPriority));
                    }
                }
            }
        }
        return categoryDao.readAllCategories();
    }

    @Override
    public MenardProductDTO getMenardProductById(Long productId) throws ItemNotFoundException {
        MenardProduct product = productDao.getMenardProductById(productId);
        if (product == null) {
            throw new ItemNotFoundException("product not found, productId: " + productId);
        }
        return new MenardProductDTO(product, (MenardSku) product.getDefaultSku());
    }

    @Override
    public ProductDetailDTO getMenardProductDetail(Long productId, Long skuId) throws ItemNotFoundException {
        return this.getMenardProductDetail(productId, skuId, true);
    }

    /**
     * package product dto
     *
     * @param product       product
     * @param skuId         sku id
     * @param setDefaultSku setDefaultSku
     * @return product dto
     * @throws ItemNotFoundException not found
     */
    private ProductDetailDTO getProductDetailDTO(MenardProduct product, Long skuId, boolean setDefaultSku)
            throws ItemNotFoundException {
        ProductDetailDTO productDTO = new ProductDetailDTO(product);
        List<Sku> skus = product.getSkus();
        List<MenardSkuDTO> skuDTOs = this.getSkuDTOs(skus);
        productDTO.setSkuDTOs(skuDTOs);
        if (skuId != null) {
            MenardSkuDTO selectedSkuDTO = getSelectedSkuDTO(skuDTOs, skuId);
            productDTO.setSelectedSkuDTO(selectedSkuDTO);
        }
        productDTO.setSetDefaultSku(setDefaultSku);
        return productDTO;
    }

    /**
     * if skuId is not null, set the sku as selected sku
     * else if there is only one sku which is set as default sku
     *
     * @param skuDTOs list
     * @param skuId   sku id
     * @return menard sku dto
     * @throws ItemNotFoundException not found
     */
    private MenardSkuDTO getSelectedSkuDTO(List<MenardSkuDTO> skuDTOs, Long skuId) throws ItemNotFoundException {
        if (skuId != null) {
            for (MenardSkuDTO dto : skuDTOs) {
                if (skuId.equals(dto.getSku().getId())) {
                    return dto;
                }
            }
            throw new ItemNotFoundException("sku not found of the assign product, sku id:" + skuId);
        }
        return null;
    }

    /**
     *
     * Get SkuDTO, the skustatus is set from calling web service , the param of skuToStatusCodeMap is
     * to reduce the times of calling webservice
     * @param sku MenardSku
     * @param skuToStatusCodeMap skuToStatusCodeMap
     * @return MenardSkuDTO MenardSkuDTO
     */
    private MenardSkuDTO getSkuDTO(MenardSku sku, Map<String, String> skuToStatusCodeMap) {
        MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
        MenardSkuDTO skuDTO = new MenardSkuDTO(sku);
        String menardSku = skuDTO.getMenardSku();
        Integer storeNumber = Integer.valueOf(user.getStoreNumber());
        String skuStatusCode = null;
        if (StringUtils.isBlank(menardSku)
                && StringUtils.isNotBlank(sku.getSkuCode())
                && sku.getSkuCode().length() >= 7) {
            menardSku = sku.getSkuCode().substring(0, 7);
        }
        if (!user.isGOUser()) {
            // Skip setting Sku status code for GO user
            if (skuToStatusCodeMap == null) {
                List<Integer> menardSkus = Arrays.asList(Integer.valueOf(menardSku));
                List<MenardDerivedStatus> menardSkuStatuses =
                        menardSkuStatusService.getDerivedStatusByStoreSku(menardSkus, storeNumber);
                if (!CollectionUtils.isEmpty(menardSkuStatuses)) {
                    skuStatusCode = menardSkuStatuses.get(0).getDerivedStatusCode();
                }
            } else if (!skuToStatusCodeMap.isEmpty()) {
                skuStatusCode = skuToStatusCodeMap.get(menardSku);
            }
        }

        skuDTO.setSkuStatusCode(skuStatusCode);
        skuDTO.setSkuVisibility(MenardGetStatus.getSkuVisibility(skuDTO));
        return skuDTO;

    }

    /**
     * Get SkuDTO, the skustatus is set from calling web service
     *
     * This method is called by public webservice
     *
     * @param sku
     * @return
     */
    private MenardSkuDTO getMenardSkuDTOWithSkuStatus(MenardSku sku, int storeNumber) {
        MenardSkuDTO skuDTO = new MenardSkuDTO(sku);
        String menardSku = skuDTO.getMenardSku();
        String skuStatusCode = null;
        if (StringUtils.isBlank(menardSku)
                && StringUtils.isNotBlank(sku.getSkuCode())
                && sku.getSkuCode().length() >= 7) {
            menardSku = sku.getSkuCode().substring(0, 7);
        }
        List<Integer> menardSkus = Arrays.asList(Integer.valueOf(menardSku));
        List<MenardDerivedStatus> menardSkuStatuses =
                menardSkuStatusService.getDerivedStatusByStoreSku(menardSkus, storeNumber);
        if (!CollectionUtils.isEmpty(menardSkuStatuses)) {
            skuStatusCode = menardSkuStatuses.get(0).getDerivedStatusCode();
        }

        skuDTO.setSkuStatusCode(skuStatusCode);
        skuDTO.setSkuVisibility(MenardGetStatus.getSkuVisibility(skuDTO));
        return skuDTO;

    }

    /**
     * get sku DTO from sku
     * set sku status and sku visibility
     *
     * @param sku MenardSku
     * @return MenardSkuDTO
     */
    @Override
    public MenardSkuDTO getSkuDTO(MenardSku sku) {
        return getSkuDTO(sku, null);
    }

    public MenardSkuDTO getMenardSkuDTOBySkuId(Long skuId, int storeNumber) {
        Sku sku = findSkuById(skuId);
        return getMenardSkuDTOWithSkuStatus((MenardSku) sku, storeNumber);
    }


    @Override
	public List<MenardSkuDTO> getSkuDTOs(List<Sku> skus) {
        List<MenardSkuDTO> skuDTOs = new ArrayList<MenardSkuDTO>();
        for (Sku sku : skus) {
            MenardSkuDTO skuDTO = getSkuDTO((MenardSku) sku);
            skuDTOs.add(skuDTO);
        }
        return skuDTOs;
    }

    @Override
    public List<Product> findProductsByCategoryId(Long categoryId, int limit, int offset) {
        return productDao.findProductsByCategoryId(categoryId, limit, offset, null, null);
    }

    @SuppressWarnings("unchecked")
	@Override
    @Transactional("blTransactionManager")
    public List<SkuCartItem> findProductDTOsByCategoryId(Long categoryId, int limit, int offset,
                                                         List<ProductFilter> productFilters) {
        MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
        List<Product> filteredProducts;
        if (user.isGOUser()) {
            List<Product> products = productDao.findProductsByCategoryId(categoryId, limit, offset, productFilters, null);
            filteredProducts = products;
        } else {
            // If a GO user has rights to see a specific product family in the Store Supplies Catalog,
            // then all products there are visible to him/her.
            // SKU status and guest orderable values do not hinder the visibility of these products.
            List<Product> products = productDao.findAllProductsByCategoryId(categoryId, productFilters);
            List<String> productIdList = getFilteredProductIdsByVisibility(products);
            filteredProducts = Collections.EMPTY_LIST;
            if (productIdList.size() > 0) {
                // if no product ids in the list after filtering, then skip this query as the query will ignore the
                // restriction of product Id if productIdList is empty which will pollute the pagination
                filteredProducts = productDao.findProductsByCategoryId(categoryId, limit, offset, productFilters, productIdList);
            }
        }
        return this.populateCartItems(filteredProducts, categoryId);
    }

    /**
     *
     * Get Sku status
     * @param products List<Product>
     * @return SkuStatus Map Map<String, String>
     */
    @SuppressWarnings("unchecked")
	private Map<String, String> getSkuToStatusCodeMap(List<Product> products) {
        Set<Integer> skuIdSet = new HashSet<>();
        for (Product product : products) {
            for (Sku sku : product.getSkus()) {
                MenardSku mSku = (MenardSku) sku;
                MenardSkuDTO menardSkuDto = new MenardSkuDTO(mSku);
                String menardSku = menardSkuDto.getMenardSku();
                if (StringUtils.isBlank(menardSku) && StringUtils.isNotBlank(mSku.getSkuCode())
                        && mSku.getSkuCode().length() >= 7) {
                    menardSku = mSku.getSkuCode().substring(0, 7);
                }
                if (StringUtils.isNotBlank(menardSku) && StringUtils.isNumeric(menardSku)) {
                    skuIdSet.add(Integer.valueOf(menardSku));
                }
            }
        }

        MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
        Map<String, String> skuToStatusCodeMap =
                menardSkuStatusService.getDerivedStatusMapByStoreSku(new ArrayList<>(skuIdSet), Integer.valueOf(user.getStoreNumber()));
		return skuToStatusCodeMap == null ? Collections.EMPTY_MAP : skuToStatusCodeMap;
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> getSkuToStatusCodeMap(Product product, int storeNumber) {
        Map<String, String> skuToStatusCodeMap = null;
        if (product != null) {
            Set<Integer> skuIdSet = new HashSet<>();
            for (Sku sku : product.getSkus()) {
                MenardSku mSku = (MenardSku) sku;
                MenardSkuDTO menardSkuDto = new MenardSkuDTO(mSku);
                String menardSku = menardSkuDto.getMenardSku();
                if (StringUtils.isBlank(menardSku) && StringUtils.isNotBlank(mSku.getSkuCode())
                        && mSku.getSkuCode().length() >= 7) {
                    menardSku = mSku.getSkuCode().substring(0, 7);
                }
                if (StringUtils.isNotBlank(menardSku) && StringUtils.isNumeric(menardSku)) {
                    skuIdSet.add(Integer.valueOf(menardSku));
                }
            }
            skuToStatusCodeMap = menardSkuStatusService.getDerivedStatusMapByStoreSku(
                    new ArrayList<>(skuIdSet), storeNumber);
        }
        return skuToStatusCodeMap == null ? Collections.EMPTY_MAP : skuToStatusCodeMap;
    }

    /**
     * filter out displayable products for store user
     * @param products List<Product>
     * @return productIds List<String>
     */
    private List<String> getFilteredProductIdsByVisibility(List<Product> products) {
        Map<String, String> skuToStatusCodeMap = getSkuToStatusCodeMap(products);
        List<String> productIds = new ArrayList<>();
        List<Product> productsToRemove = new ArrayList<>();
        for (Product product : products) {
            // construct ProductDetailDTO
            ProductDetailDTO dto = new ProductDetailDTO((MenardProduct) product);
            List<Sku> skus = product.getSkus();

            List<MenardSkuDTO> skuDTOs = new ArrayList<>();
            for (Sku sku : skus) {
                MenardSkuDTO skuDTO = getSkuDTO((MenardSku) sku, skuToStatusCodeMap);
                if (skuDTO != null) {
                    skuDTOs.add(skuDTO);
                }
            }

            dto.setSkuDTOs(skuDTOs);
            dto.setSetDefaultSku(true);

            if (dto.getProductVisibility() == null) {
                // remove product from list if there is no SKU
                productsToRemove.add(product);
                continue;

            } else {
                // Filter if it's store user
                switch (dto.getProductVisibility()) {
                    case DELETED:
                    case DISCONTINUED:
                        productsToRemove.add(product);
                        break;
                    case STOCK:
                        if (!dto.getIsDcmSku()) {
                            productsToRemove.add(product);
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        products.removeAll(productsToRemove);

        for (Product product : products) {
            productIds.add(String.valueOf(product.getId()));
        }
        return productIds;
    }

    /**
     * Search Products By Cateogry
     *
     * @param products   products
     * @param categoryId categoryId
     * @return List<CartItem> CartItems
     */
    private List<SkuCartItem> populateCartItems(List<Product> products, Long categoryId) {
        Map<String, String> skuToStatusCodeMap = getSkuToStatusCodeMap(products);
        List<SkuCartItem> cart = new ArrayList<SkuCartItem>();
        for (Product p : products) {
            SkuCartItem item = new SkuCartItem();
            item.setProductId(p.getId());
            item.setCategoryId(categoryId);
            item.setQuantity(1);

            // construct ProductDetailDTO
            ProductDetailDTO dto = new ProductDetailDTO((MenardProduct) p);
            List<Sku> skus = p.getSkus();

            List<MenardSkuDTO> skuDTOs = new ArrayList<MenardSkuDTO>();
            for (Sku sku : skus) {
                MenardSkuDTO skuDTO = getSkuDTO((MenardSku) sku, skuToStatusCodeMap);
                skuDTOs.add(skuDTO);
            }

            dto.setSkuDTOs(skuDTOs);
            dto.setSetDefaultSku(true);


            String status = "";
            if (ProductVisibility.STOCK.equals(dto.getProductVisibility())) {
                status = "0";
            } else if (dto.getSelectedSkuAvailable() && !dto.getIsDcmSku() && !dto.getIsBusinessCard()
                    && !dto.getIsWelcomeSign()) {
                status = "500";
                item.setSkuId(dto.getSelectedSku().getId());
            }
            item.setStatus(status);
            item.setBrandName(dto.getBrandName());
            item.setSeriesNumber(dto.getSeriesNumber());
            item.setVendorSize(dto.getVendorSize());
            String descriptionShort = dto.getDescriptionShort();
            if (StringUtils.isNotEmpty(descriptionShort) && descriptionShort.length() > 75) {
                descriptionShort = descriptionShort.substring(0, 72) + "...";
            }
            item.setDescriptionShort(descriptionShort);
            item.setProductImgUrl(dto.getProductListImgUrl());
            item.setQuantity(dto.getQuantity());
            cart.add(item);
        }
        return cart;
    }

    @Override
    public ProductDetailDTO getMenardProductDetail(Long productId, Long skuId, Boolean setDefaultSku)
            throws ItemNotFoundException {
        boolean defaultSku = false;
        if (setDefaultSku == null) {
            defaultSku = true;
        } else {
            defaultSku = setDefaultSku;
        }
        MenardProduct product = productDao.getMenardProductById(productId);
        if (product == null) {
            throw new ItemNotFoundException("product not found, productId: " + productId);
        }

        if (!product.isActive()) {
            return null;
        }

        ProductDetailDTO productDto = this.getProductDetailDTO(product, skuId, defaultSku);

        List<MenardProductOption> accessories = productDao.getAccessoriesByProduct(product);
        List<ProductDetailDTO> optionAccessories = new ArrayList<ProductDetailDTO>();
        List<ProductDetailDTO> requireAccessories = new ArrayList<ProductDetailDTO>();
        for (MenardProductOption option : accessories) {
            MenardProduct mp = option.getMenardProductOptionPK().getAccessory();
            ProductDetailDTO dto = this.getProductDetailDTO(mp, null, false);
            if (option.getIsMandatory()) {
                requireAccessories.add(dto);
            } else {
                optionAccessories.add(dto);
            }
        }
        productDto.setOptionAccessories(optionAccessories);
        productDto.setRequireAccessories(requireAccessories);

        MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
        // if (CommonConstant.SOS_CATALOG.equals(user.getSelectedDepartment()) && productDto.getSelectedSku() != null) {
        if (productDto.getSelectedSku() != null) {
            Long selectSkuId = productDto.getSelectedSku().getId();
            List<MenardOrderItem> last5OrderItems = orderItemDao.findOrderItems(selectSkuId, user.getStoreNumber());
            productDto.setLast5OrderItems(last5OrderItems);
        }

        ProductAttribute vendorAttr = product.getProductAttributes().get(ProductAttributeKey.VENDOR);
        if (vendorAttr != null) {
            String vendor = vendorAttr.getValue();
            if (StringUtils.isNotEmpty(vendor)) {
            	MenardVendor menardVendor = menardVendorDao.getMenardVendorByVendorId(vendor);
            	String vendorLogoUrl = null;
				if (null != menardVendor) {
	            	 Map<String, Media> mediaMap = menardVendor.getMenardVendorMedia();
	            	 if(null!=mediaMap){
	            		 Media media = mediaMap.get("primary");
	            		 if(null!=media){
	            			 vendorLogoUrl=  media.getUrl();
	            		 }
	            	 }
	            	
	            	
					// eg:/media/UC/kiosk/Flooring/images/vendor/Creston/Logo/creston.jpg
					productDto.setVendorLogoUrl(vendorLogoUrl);
				}
            }
        }

        return productDto;
    }

    @Override
    public MenardSku findSkuByMenardSku(String menardSku) {
        List<MenardSku> skus = productDao.findSkuByMenardSku(menardSku);
        if (CollectionUtils.isNotEmpty(skus)) {
            for (MenardSku mSku : skus) {
                // productDao.findSkuByMenardSku(menardSku) will get all SKUs regardless active status
                // Iterate to find the active one
                if (mSku.isActive()) {
                    return mSku;
                }
            }
        }
        return null;
    }

    /**
     * getConfiguredProductFilterByCategoryId
     *
     * @param categoryId categoryId
     * @return ProductFilter ProductFilter
     */
    @Override
	public List<ProductFilter> getConfiguredProductFilterByCategoryId(Long categoryId) {
        Category category = this.findCategoryById(categoryId);
        boolean isSearchEnabled = false;
        List<String> filterNames = new ArrayList<>();
        Map<String, String> attributeNames = new HashMap<>();
        Map<String, String> attributeValues = new HashMap<>();

        if (category != null) {
            // Fisrt, iterate to find out the filter flag and names. Example: Style, Size, Vendor
            for (CategoryAttribute attribute : category.getCategoryAttributes()) {
                if (CategoryAttributeKey.FLAG_NO_SEARCH_CRIT.equalsIgnoreCase(attribute.getName())) {
                    isSearchEnabled = ProductFilterEnum.FILTER_FLAG_N.getValue().equalsIgnoreCase(attribute.getValue());
                } else if (CategoryAttributeKey.FOLDER_NAV_USED_LIST.equalsIgnoreCase(attribute.getName())) {
                    // Example: Size,Style
                    String navList = attribute.getValue();
                    if (StringUtils.isNotBlank(navList)) {
                        String[] attrValues = navList.split(ProductFilterEnum.FILTER_SEPARATOR.getValue());
                        filterNames.addAll(Arrays.asList(attrValues));
                    }
                }
            }
        }

        // Check if search is enabled, stop here if not
        if (isSearchEnabled && !filterNames.isEmpty()) {
            // Seach is enabled, and we have the filter names, we can proceed to construct the filter options
            for (String filterName: filterNames) {
                String searchableAttrName = getProductFilterAttributeName(filterName, ProductFilterEnum.FILTER_SEARCHABLE_PREFIX.getValue());
                String searchAttrName = getProductFilterAttributeName(filterName, ProductFilterEnum.FILTER_SEARCH_PREFIX.getValue());
                for (CategoryAttribute attribute: category.getCategoryAttributes()) {
                    if (attribute.getName().equalsIgnoreCase(searchableAttrName)) {
                        // Entry example: Style -> Criteria1
                        attributeNames.put(filterName, attribute.getValue());
                    } else if (attribute.getName().equalsIgnoreCase(searchAttrName)) {
                        // Entry example: Stile -> oval,round,rectangular
                        attributeValues.put(filterName, attribute.getValue());
                    }
                }
            }
            // skip if data is missing. There must be the same number of filter options with filter names
            if (filterNames.size() == attributeNames.size() && filterNames.size() == attributeValues.size()) {
                return generateProductFilter(filterNames, attributeNames, attributeValues, categoryId);
            }
        }
        return null;
    }

    /**
     * concatenate attribute name
     *
     * @param filterName
     * @param prefix
     * @return
     */
    private String getProductFilterAttributeName(String filterName, String prefix) {
        return prefix + filterName + ProductFilterEnum.FILTER_ATR_SUFFIX.getValue();
    }

    /**
     * Generate product filter list from category attributes
     *
     * @param filterNames
     * @param attributeNames
     * @param attributeValues
     * @param categoryId
     * @return
     */
    private List<ProductFilter> generateProductFilter(List<String> filterNames,
                                                      Map<String, String> attributeNames,
                                                      Map<String, String> attributeValues,
                                                      Long categoryId) {
        List<ProductFilter> productFilters = new ArrayList<>(filterNames.size());
        for (String filterName: filterNames) {
            ProductFilter productFilter = new ProductFilter(filterName);
            productFilter.setCategoryId(categoryId);
            productFilter.setAttributeName(attributeNames.get(filterName)); // e.g. Criteria1
            String optionValuesJoined = attributeValues.get(filterName); // e.g. oval,round,rectangular
            productFilter.setOptionsJoined(optionValuesJoined);
            for (String optionValue: optionValuesJoined.split(ProductFilterEnum.FILTER_SEPARATOR.getValue())) {
                // IMPORTANT! name and value are identical
                // Additional string handling for displayable name should be done when rendering the page
                productFilter.addOption(optionValue, optionValue);
            }
            productFilters.add(productFilter);
        }
        return productFilters;
    }

    /**
     * Get product filter options by configured product filters and then merge with configured product filters to
     * return a final product filter list
     *
     * @param configuredProductFilters
     * @return
     */
    @SuppressWarnings("unchecked")
	@Override
    public List<ProductFilter> getProductFilterOptions(List<ProductFilter> configuredProductFilters) {
        if (configuredProductFilters != null && !configuredProductFilters.isEmpty()) {
            Long categoryId = getCategoryIdFromConfiguredProductFilters(configuredProductFilters);
            String attrNames = getAttributeNamesFromConfiguredProductFilters(configuredProductFilters);
            List<ProductFilter.Option> filterOptions = productDao.getProductFilterOptions(categoryId, attrNames);

            // check if we have Vendor filter, get full vendor to vendor full name map
            Map<String, String> vendorToFullNameMap = null;
            if (attrNames.contains(ProductFilterEnum.FILTER_VENDOR.getValue())) {
                // Example: (vedor as key, full name as value which might be empty)
                // "legendvalve_POP" -> ""
                // "nibco" -> "Nibco"
                // "prier" -> ""
                vendorToFullNameMap = productDao.getVendorToFullNameMap(categoryId);
            }

            for (ProductFilter configuredProductFilter : configuredProductFilters) {
                List<String> optionsValueList = configuredProductFilter.getOptionsValueAsList();
                List<String> productAttrOptions =
                        getProductAttrOptions(configuredProductFilter.getAttributeName(), filterOptions);
                List<String> finalOptionValueList = (List<String>) CollectionUtils.intersection(optionsValueList,
                        productAttrOptions);

                boolean filterByVendor = configuredProductFilter.getAttributeName().equalsIgnoreCase(
                        ProductFilterEnum.FILTER_VENDOR.getValue());

                // clear productFilter and repopulate from finalOptionValueList
                configuredProductFilter.getOptions().clear();
                for (String optionValue : finalOptionValueList) {
                    // check if we have Vendor filter, get full vendor name if yes
                    // Display vendor as its full name if we can't find it
                    String optionName = optionValue;
                    if (filterByVendor && vendorToFullNameMap != null) {
                        String vendorName = vendorToFullNameMap.get(optionValue);
                        if (StringUtils.isNotBlank(vendorName)) {
                            // Found vendor full name by vendor and it's not empty
                            optionName = vendorName;
                        }
                    }
                    configuredProductFilter.addOption(optionName, optionValue);
                }
            }
            return configuredProductFilters;
        }
        return null;
    }

	@Override
	@Transactional("blTransactionManager")
    public Map<Long, CategoryAuth> groupCategorySecurityData() {
		List<Category> list = categoryDao.readAllCategories();
		Map<Long, CategoryAuth> categoryAuthMap = new HashMap<Long, CategoryAuth>();
		for (Category category : list) {
			category.getCategoryAttributes();
			CategoryAttribute fulfiller = category.getCategoryAttributeByName(CategoryAttributeKey.ATTR_FULFILLER);
			CategoryAttribute depts = category.getCategoryAttributeByName(CategoryAttributeKey.ATTR_RESTRICT_ASST_TO_DEPT);
			Long parentId = category.getDefaultParentCategory().getId();
			categoryAuthMap.put(category.getId(), new CategoryAuth(getAttrValue(fulfiller),
					getAttrValue(depts), category.getUrl(), category.getId(), parentId));
		}
		for (Map.Entry<Long, CategoryAuth> entry : categoryAuthMap.entrySet()) {
			CategoryAuth auth = entry.getValue();
			CategoryAuth parent = categoryAuthMap.get(auth.getParentId());
			if (auth.getParentId().longValue() == auth.getCategoryId().longValue()) {
				continue;
			}
			entry.getValue().setParent(parent);
		}
		return categoryAuthMap;
	}

	private String getAttrValue(CategoryAttribute categoryAttribute) {
		if (categoryAttribute == null) {
			return StringUtils.EMPTY;
		}
		return categoryAttribute.getValue();
	}

    /**
     * Get option value list from a list of ProductFilter.Option
     *
     * @param attributeName
     * @param filterOptions
     * @return
     */
    private List<String> getProductAttrOptions(String attributeName, List<ProductFilter.Option> filterOptions) {
        List<String> optionsValueList = new ArrayList<>();
        for (ProductFilter.Option attrOption: filterOptions) {
            if (attributeName.equalsIgnoreCase(attrOption.getName())) {
                optionsValueList.add(attrOption.getValue());
            }
        }
        return optionsValueList;
    }

    /**
     * Get attribute names from configured product filter list
     *
     * @param configuredProductFilters
     * @return
     */
    private String getAttributeNamesFromConfiguredProductFilters(List<ProductFilter> configuredProductFilters) {
        if (configuredProductFilters != null && !configuredProductFilters.isEmpty()) {
            List<String> attrNames = new ArrayList<>(configuredProductFilters.size());
            for (ProductFilter filter: configuredProductFilters) {
                attrNames.add(filter.getAttributeName());
            }
            return StringUtils.join(attrNames, ProductFilterEnum.FILTER_SEPARATOR.getValue());
        }
        return null;
    }

    /**
     * get categoryId from the first element of configuredProductFilters list
     *
     * @param configuredProductFilters
     * @return
     */
    private Long getCategoryIdFromConfiguredProductFilters(List<ProductFilter> configuredProductFilters) {
        if (configuredProductFilters != null && !configuredProductFilters.isEmpty()) {
            return configuredProductFilters.get(0).getCategoryId();
        }
        return 0L;
    }

    /**
     * Get category attribute by category ID
     *
     * @param categoryId
     * @return
     */
    public List<CategoryAttribute> getCategoryAttributes(Long categoryId) {
        return productDao.getCategoryAttributes(categoryId);
    }

    /**
     * Get category attribute by category path
     *
     * @param categoryPath
     * @return
     */
    public List<CategoryAttribute> getCategoryAttributes(String categoryPath) {
        return productDao.getCategoryAttributes(categoryPath);
    }

}
