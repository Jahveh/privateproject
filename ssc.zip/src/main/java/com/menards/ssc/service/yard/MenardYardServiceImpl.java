package com.menards.ssc.service.yard;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.menards.ssc.dao.yard.MenardYardDao;
import com.menards.ssc.domain.yard.Store;

/**
 * @author frank.shao
 */

@Service("menardYardService")
public class MenardYardServiceImpl implements MenardYardService {

	@Resource(name = "menardYardDao")
	private MenardYardDao yardDao;

	@Override
	public Store getStore(String storeNumber) {

		return yardDao.getStore(storeNumber);
	}

	@Override
	public List<Store> getYardNameList() {

		return yardDao.getYardNameList();
	}

	@Override
	public List<Store> getYardForRemodelDates() {

		return yardDao.getYardForRemodelDates();
	}

}
