package com.menards.ssc.service.inventory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.broadleafcommerce.core.catalog.domain.Product;
import org.broadleafcommerce.core.catalog.domain.Sku;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.menards.ssc.dao.inventory.MenardInventoryDao;
import com.menards.ssc.dao.product.MenardProductDao;
import com.menards.ssc.domain.catalog.MenardSkuDTO;
import com.menards.ssc.domain.inventory.MenardInventoryDTO;
import com.menards.ssc.enums.ProductVisibility;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.service.catalog.MenardCatalogService;
import com.menards.ssc.service.skustatus.MenardSkuStatusService;
import com.menards.ssc.socket.KioskServerClient;
import com.menards.ssc.state.MenardGetStatus;

/**
 * @author frank.shao
 */

@Service("menardInventoryService")
public class MenardInventoryServiceImpl implements MenardInventoryService {

	public static final Log LOG = LogFactory.getLog(MenardInventoryServiceImpl.class);
	private static final String ERROR = "ERROR";

	@Resource(name = "menardInventoryDao")
	private MenardInventoryDao inventoryDao;

	@Resource(name = "blProductDao")
	private MenardProductDao productDao;

	@Resource(name = "menardSkuStatusService")
	private MenardSkuStatusService menardSkuStatusService;

	@Resource(name = "blCatalogService")
	private MenardCatalogService catalogService;

	@Value("${kiosk.server.ip:}")
	private String kioskServerIpStatic;

	@Value("${kiosk.server.port.number}")
	private Integer kioskServerPortNumberStatic;

	private static ThreadLocal<KioskServerClient> ksc = new ThreadLocal<KioskServerClient>();

	@Override
	public List<MenardInventoryDTO> getInventory() {

		List<MenardInventoryDTO> productSelectionList = inventoryDao.getInventory();
		List<MenardInventoryDTO> validadProductSelectionList;

		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		if (user.isGOUser()) {
			validadProductSelectionList = productSelectionList;
		} else {
			validadProductSelectionList = getValidProductSelectionList(productSelectionList);
		}

		List<MenardInventoryDTO> inventoryList = new ArrayList<MenardInventoryDTO>();

		setupKioskServerClient();
		if (ksc != null) {
			for (int i = 0; i < validadProductSelectionList.size(); i++) {
				MenardInventoryDTO inventory = validadProductSelectionList.get(i);
				poplulateInventoryList(inventory, inventoryList);
			}

			Collections.sort(inventoryList, new Comparator<MenardInventoryDTO>() {
				@Override
				public int compare(MenardInventoryDTO inventoryA, MenardInventoryDTO inventoryB) {
					MenardInventoryDTO a = inventoryA;
					MenardInventoryDTO b = inventoryB;
					int modelNumber1 = Integer.parseInt(a.getModelNumber());
					int modelNumber2 = Integer.parseInt(b.getModelNumber());
					if (modelNumber1 == modelNumber2) {
						return 0;
					}
					if (modelNumber1 > modelNumber2) {
						return 1;
					}
					return -1;
				}
			});

		}
		return inventoryList;

	}

	private void poplulateInventoryList(MenardInventoryDTO inventory, List<MenardInventoryDTO> inventoryList) {

		String responseMsg = ksc.get().getExtendedSkuInfo(inventory.getModelNumber());
		if (responseMsg != null && !responseMsg.equals("ERROR")) {
			String qtyOnHand = responseMsg.substring(288, 296).trim();
			// Trim off leading zeros
			while (qtyOnHand.startsWith("0") && qtyOnHand.length() > 1) {
				qtyOnHand = qtyOnHand.substring(1);
			}
			inventory.setQtyOnHand(qtyOnHand);

			// Override the UOM with that from the kiosk server. Most
			// products are setup as each in the catalog, so the kiosk
			// server value will be slightly more descriptive
			String ksUom = responseMsg.substring(137, 141).trim();
			if (ksUom.length() > 0) {
				inventory.setUom(ksUom);
			}

			inventoryList.add(inventory);

		}

	}

	/**
	 * 
	 * Select out the visible products from the original productSelectionList
	 * 
	 * @param productSelectionList
	 *            List<MenardInventoryDTO>
	 * @return ProductSelectionList visible(valid) ProductSelectionList
	 */
	private List<MenardInventoryDTO> getValidProductSelectionList(List<MenardInventoryDTO> productSelectionList) {

		// Read all productIds from Product_Selection View
		List<Long> productIds = new ArrayList<Long>();
		Map<Long, MenardInventoryDTO> productSelectionMap = new HashMap<Long, MenardInventoryDTO>();
		productSelectionMap = new HashMap<Long, MenardInventoryDTO>();
		for (MenardInventoryDTO productSelection : productSelectionList) {
			productIds.add(productSelection.getProductId());
			productSelectionMap.put(productSelection.getProductId(), productSelection);

		}

		// Get all products from product Ids
		List<Product> products = productDao.readProductsByIds(productIds);
		List<MenardInventoryDTO> availableProductSelectionList = new ArrayList<MenardInventoryDTO>();
		for (Product product : products) {
			List<Sku> skus = product.getSkus();
			List<MenardSkuDTO> skuDTOs = catalogService.getSkuDTOs(skus);
			ProductVisibility productVisibility = MenardGetStatus.getProductVisibility(skuDTOs);
			if (productVisibility != null && !ProductVisibility.DELETED.equals(productVisibility)) {
				availableProductSelectionList.add(productSelectionMap.get(product.getId()));
			}
		}

		return availableProductSelectionList;

	}

	@Override
	@Transactional("blTransactionManager")
	public List<MenardInventoryDTO> updateInventory(String[] sku, String[] quantity) {

		setupKioskServerClient();

		List<MenardInventoryDTO> inventoryList = new ArrayList<MenardInventoryDTO>();
		boolean allQtyValid = true;
		if (null != ksc) {
			for (int i = 0; i < quantity.length; i++) {

				String responseMsg =  ksc.get().updateSkuInventory(sku[i], quantity[i]);
				responseMsg = responseMsg.trim();
				if (responseMsg.equals(ERROR)) {
					allQtyValid = false;
					MenardInventoryDTO inventory = new MenardInventoryDTO();
					responseMsg = ksc.get().getExtendedSkuInfo(sku[i]);
					if (responseMsg != null && !responseMsg.equals(ERROR)) {
						String qtyOnHand = responseMsg.substring(288, 296).trim();
						// Trim off leading zeros
						while (qtyOnHand.startsWith("0") && qtyOnHand.length() > 1) {
							qtyOnHand = qtyOnHand.substring(1);
						}
						inventory.setQtyOnHand(qtyOnHand);

						// Override the UOM with that from the kiosk server.
						// Most
						// products are setup as each in the catalog, so the
						// kiosk
						// server value will be slightly more descriptive
						String ksUom = responseMsg.substring(137, 141).trim();
						if (ksUom.length() > 0) {
							inventory.setUom(ksUom);
						}
					}

					inventory.setActualQty(quantity[i]);
					inventory.setModelNumber(sku[i]);
					List<MenardInventoryDTO> inventoryBySKU = inventoryDao.getInventoryBySku(sku[i]);
					inventory.setDescriptionShort(inventoryBySKU.get(0).getDescriptionShort());
					inventory.setImagePath(inventoryBySKU.get(0).getImagePath());
					inventoryList.add(inventory);

				}

			}
			if (allQtyValid) {
				inventoryDao.logEvent(MenardSecurityContextHolder.getMenardUserDetails().getStoreNumber(), "900", 903);
			}
		}
		return inventoryList;

	}

	@Override
	public MenardInventoryDTO updateInventory(String modelNum, Integer quantity) {

		setupKioskServerClient();
		if (null != ksc) {
			String responseStrUpd =  ksc.get().updateSkuInventory(modelNum, quantity.toString());
			if (ERROR.equals(responseStrUpd)) {
				MenardInventoryDTO inventory = new MenardInventoryDTO();
				String responseStrGet =  ksc.get().getExtendedSkuInfo(modelNum);
				if (responseStrGet != null && !responseStrGet.equals(ERROR)) {
					String qty = responseStrGet.substring(288, 296).trim();
					// Trim off leading zeros
					while (qty.startsWith("0") && qty.length() > 1) {
						qty = qty.substring(1);
					}
					inventory.setQtyOnHand(qty);

					// Override the UOM with that from the kiosk server. Most
					// products are setup as each in the catalog, so the kiosk
					// server value will be slightly more descriptive
					String uom = responseStrGet.substring(137, 141).trim();
					inventory.setUom(uom);
				}
				return inventory;
			}
		}

		return null;

	}

	/**
	 * setupKioskServerClient Creates a Kiosk Server Client for the specified
	 * store
	 * 
	 * @param storeNumber
	 *            - store number
	 */
	private void setupKioskServerClient() {
		// Setup the request
		try {
			KioskServerClient kioskServerClient = new KioskServerClient(kioskServerIpStatic, kioskServerPortNumberStatic);
			ksc.set(kioskServerClient); 
		} catch (Exception bme) {
			LOG.info(this.getClass() + ":setupKioskServerClient: " + "Error creating KioskServerClient");
		}
	}
}
