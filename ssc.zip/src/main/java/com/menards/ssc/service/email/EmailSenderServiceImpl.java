/**
 * 
 */
package com.menards.ssc.service.email;

import java.util.Map;

import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

/**
 * <p>EmailSenderServiceImpl</p>
 * <p>Email Sending Service</p>
 * <p>
 * Group the email message and send it 
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Service("emailSenderService")
public class EmailSenderServiceImpl implements EmailSenderService {

	@Resource(name = "mailSender")
	private JavaMailSender mailSender;

	@Resource(name = "templateMessage")
	private SimpleMailMessage templateMessage;

	@Resource(name = "velocityEngine")
	private VelocityEngine velocityEngine;

	@Override
	public boolean sendEmailWithTemplate(final SimpleMailMessage message, final String name,
			final Map<String, Object> model) {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {
			public void prepare(MimeMessage mimeMessage) throws MessagingException {
				MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage);
				mimeMessageHelper.setTo(message.getTo());
				mimeMessageHelper.setFrom(message.getFrom());
				if (message.getCc() != null && message.getCc().length > 1) {
					mimeMessageHelper.setCc(message.getCc());
				}
				mimeMessageHelper.setSubject(message.getSubject());

				String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, name, "UTF-8", model);
				mimeMessageHelper.setText(text, false);
			}
		};
		try {
			mailSender.send(preparator);
		} catch (MailException e) {
			LOG.error("SendEmailWithTemplate \n [" + e.getMessage() + "]");
			return false;
		}
		return true;
	}

	@Override
	public boolean sendTextEmail(SimpleMailMessage message) {
		try {
			SimpleMailMessage msg = new SimpleMailMessage(templateMessage);
			msg.setTo(message.getTo());
			msg.setBcc(message.getBcc());
			msg.setText(message.getText());
			mailSender.send(msg);
		} catch (MailException e) {
			LOG.error("ERROR with sending email \n [" + e.getMessage() + "]\n " + message.getText());
			return false;
		}
		return true;
	}
}
