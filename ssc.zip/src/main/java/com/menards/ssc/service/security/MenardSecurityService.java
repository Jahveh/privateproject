/**
 *
 */
package com.menards.ssc.service.security;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <p>MenardSecurityService</p>
 * <p>security service</p> 
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public interface MenardSecurityService {

	public static final Log LOG = LogFactory.getLog(MenardSecurityService.class);

	/**
	 * Load an refresh the security information
	 * @param item OrderItem
	 */
	public void loadSecurityConfig();
}
