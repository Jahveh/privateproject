package com.menards.ssc.service.catalog;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.broadleafcommerce.core.catalog.domain.Category;
import org.broadleafcommerce.core.catalog.domain.CategoryImpl;
import org.broadleafcommerce.core.catalog.service.CatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.dao.order.BlcCategoryAttributeDao;
import com.menards.ssc.dao.sign.MenardColorSignDao;
import com.menards.ssc.domain.navigation.CategoryTreeNode;
import com.menards.ssc.enums.CategoryType;

/**
*
* <p>CategoryTreeService</p>
* 
* <p>
* Loads categories from the underlying database, 
* and put the whole category tree into ServletContext in the below three forms for easy future use.
* 1) Put the whole category tree in the ServletContext under the key "categoryTree" 
* 2) Put the CategoryId and CategoryTreeNode mapping in the ServletContext under the key "categoryTreeDictionary"
* 3) Put the HTML representation of the whole category tree in the ServletContext under the key "htmlCategoryTree"
*  
* </p>
* <p>Copyright (c) 2014</p>
* <p>Menard Inc.</p>
* @author frank.peng
* @version 1.0
*/
@Service
public class CategoryTreeService {
	public static final Log LOGGER = LogFactory.getLog(CategoryTreeService.class);
	public static final String CATEGORY_TREE_SERVLET_CONTEXT_KEY = "categoryTree";
	public static final String CATEGORY_TREE_DICTIONARY_SERVLET_CONTEXT_KEY = "categoryTreeDictionary";
	public static final String HTML_CATEGORY_TREE_SERVLET_CONTEXT_KEY = "htmlCategoryTree";
    public static Map<Long, Long> categoryOrderDict = new HashMap<Long, Long>();
	private StringBuilder htmlTree;

	@Resource(name = "blCatalogService")
	private CatalogService catalogService;

	@Autowired
	private MenardColorSignDao menardColorSignDao;

	@Autowired
	private BlcCategoryAttributeDao blcCategoryAttributeDao;
	
	@Value("${environment}")
	private String environment;

	/**
	 * 
	 * loadCategoryTreeToServletContext
	 * @param servletContext servletContext
	 */
	public synchronized void loadCategoryTreeToServletContext(ServletContext servletContext) {
		List<Category> tempList = catalogService.findAllCategories();
		List<Category> list = removeArchieved(tempList);
		Map<Long, CategoryTreeNode> categoryTreeDictionary = createCategoryTreeDictionary(list);
		addColorSignCategoriesToDictionary(categoryTreeDictionary);
		removeOrphanTreeNode(categoryTreeDictionary);
		CategoryTreeNode root = getRootCatetoryTreeNode(categoryTreeDictionary);
        sortCategoryTree(root);
		cascadeParentImageAndDescriptionToChildNodes(root);
		putCategoryTreeIntoServletContext(root, categoryTreeDictionary, servletContext);
		markLeafNodes(categoryTreeDictionary);
		convertToHTMLTreeAndPutIntoServletContext(root, servletContext);
		LOGGER.info("Category Tree is Loaded, the root category ID is " + root.getCategoryId()
				+ ", the total number of the tree nodes is " + categoryTreeDictionary.entrySet().size());
	}

    private void sortCategoryTree(CategoryTreeNode treeNode) {
        if (!treeNode.getSubCategories().isEmpty()) {
            Collections.sort(treeNode.getSubCategories(), new Comparator<CategoryTreeNode>() {
                @Override
                public int compare(CategoryTreeNode catA, CategoryTreeNode catB) {
                    setPriority(catA);
                    setPriority(catB);
                    if (!catA.getPriority().equals(catB)) {
                        return catA.getPriority().intValue() - catB.getPriority().intValue();
                    } else {
                        return catA.getCategoryName().compareTo(catB.getCategoryName());
                    }
                }
            });
            for (CategoryTreeNode subCategory : treeNode.getSubCategories()) {
                sortCategoryTree(subCategory);
            }
        }
    }

    private void setPriority(CategoryTreeNode treeNode) {
        Long priority = categoryOrderDict.get(treeNode.getCategoryId());
        if (priority == null) {
            treeNode.setPriority(9999999L);
        } else {
            treeNode.setPriority(priority);
        }
    }

	/**
	 * copy parent node image url and description to its child node if the child node has no image url or no description
	 * @param root
	 */
	private void cascadeParentImageAndDescriptionToChildNodes(CategoryTreeNode root) {
		for (CategoryTreeNode subCategory : root.getSubCategories()) {
			if (StringUtils.isEmpty(subCategory.getCategoryImgUrl())) {
				subCategory.setCategoryImgUrl(root.getCategoryImgUrl());
			}
			if (StringUtils.isEmpty(subCategory.getCategoryDesc())) {
				subCategory.setCategoryDesc(root.getCategoryDesc());
			}
			cascadeParentImageAndDescriptionToChildNodes(subCategory);
		}
	}
	
	/**
	 * 
	 * addColorSignCategoriesToDictionary
	 * @param categoryTreeDictionary categoryTreeDictionary
	 */
	@SuppressWarnings("rawtypes")
	private void addColorSignCategoriesToDictionary(Map<Long, CategoryTreeNode> categoryTreeDictionary) {
		List categoryIdList = blcCategoryAttributeDao.getColorSignCategoryIdList();
		for (Object hasColorSignCategoryId : categoryIdList) {
			for (CategoryTreeNode category : categoryTreeDictionary.values()) {
				if (category.getCategoryId().longValue() == ((BigInteger) hasColorSignCategoryId).longValue()) {
					LOGGER.info("Retrieving color sign categories...");
					List<CategoryTreeNode> colorSignCategoryList = menardColorSignDao.getColorSignCategorList();
					LOGGER.info(colorSignCategoryList.size() + " color sign categories have been retrieved.");
					for (CategoryTreeNode categoryTreeNode : colorSignCategoryList) {
						if (categoryTreeNode.getParentCategoryId() == 0) {
							categoryTreeNode.setParentCategoryId(((BigInteger) hasColorSignCategoryId).longValue());
						}
						categoryTreeDictionary.put(categoryTreeNode.getCategoryId(), categoryTreeNode);
					}
					return;
				}
			}
		}
	}

	/**
	 * 
	 * Convert the whole CategoryTreeNode tree to a HTML markup and then put it into ServletContext
	 * @param node the root of the CategoryTreeNode tree
	 * @param servletContext a instance of ServletContext
	 */
	private void convertToHTMLTreeAndPutIntoServletContext(CategoryTreeNode node, ServletContext servletContext) {
		htmlTree = new StringBuilder();
		htmlTree.append("<div class='menuBG'></div>  ");
		htmlTree.append("<h1><span>Main Menu</span> <a title='Slide Back Home' href='#' class='sliding-menu-home'>Slide Back Home</a></h1>");
		htmlTree.append("<ul>");
		for (CategoryTreeNode subNode : node.getSubCategories()) {
			parseATreeNode(subNode, 1);
		}
		htmlTree.append("</ul>");
		servletContext.setAttribute(HTML_CATEGORY_TREE_SERVLET_CONTEXT_KEY, htmlTree.toString());
	}

	/**
	 * 
	 * A helper method that recursively builds an HTML markup from the given CategoryTreeNode instance
	 * @param node an instance of the CategoryTreeNode
	 */
	private void parseATreeNode(CategoryTreeNode node, int level) {
		htmlTree.append("<li><a href='#' nodeId='").append(node.getCategoryId()).append("' url='")
				.append(node.getUrl()).append("'>");
		appendCategoryName(node, htmlTree);
		htmlTree.append("</a>");
		if (node.getSubCategories().size() > 0) {
			htmlTree.append("<ul>");
			int subLevel = level + 1;
			if (subLevel > 2) {
				for (CategoryTreeNode treeNode : node.getSubCategories()) {
					htmlTree.append("<li><a href='#' nodeId='").append(treeNode.getCategoryId()).append("' url='").append(treeNode.getUrl()).append("'>");
					htmlTree.append(StringEscapeUtils.escapeHtml(treeNode.getCategoryName()));
					htmlTree.append("</a></li>");
				}
			} else {
				for (CategoryTreeNode treeNode : node.getSubCategories()) {
					parseATreeNode(treeNode, subLevel);
				}
			}
			htmlTree.append("</ul>");
		}
		htmlTree.append("</li>");
		
	}

	/**
	 * 
	 * A helper method that append Category name to the generated HTML markup and get called by the parseATreeNode 
	 * @param node node
	 * @param htmlTree htmlTree
	 */
	private void appendCategoryName(CategoryTreeNode node, StringBuilder htmlTree) {
		if (node.getSubCategories().size() > 0) {
			htmlTree.append("<span>").append(StringEscapeUtils.escapeHtml(node.getCategoryName())).append("</span>");
		} else {
			htmlTree.append(StringEscapeUtils.escapeHtml(node.getCategoryName()));
		}
	}

	/**
	 * 
	 * Mark the leaf of the pass-in map of the CategoryTreeNode Id and CategoryTreeNode
	 * @param categoryTreeDictionary a map of CategoryTreeNode Id and CategoryTreeNode
	 */
	private void markLeafNodes(Map<Long, CategoryTreeNode> categoryTreeDictionary) {
		for (CategoryTreeNode node : categoryTreeDictionary.values()) {
			if (node.getSubCategories().size() == 0) {
				node.setLeafNode(true);
			} else {
				node.setLeafNode(false);
			}
		}
	}

	/**
	 * Put the both CategoryTreeNode root and the category map into the ServletContext
	 * @param root the whole CategoryTreeNode tree
	 * @param categoryTreeDictionary a map of CategoryTreeNode Id and CategoryTreeNode
	 * @param servletContext a ServletContext instance
	 */
	private void putCategoryTreeIntoServletContext(CategoryTreeNode root,
			Map<Long, CategoryTreeNode> categoryTreeDictionary, ServletContext servletContext) {
		servletContext.setAttribute(CATEGORY_TREE_SERVLET_CONTEXT_KEY, root);
		servletContext.setAttribute(CATEGORY_TREE_DICTIONARY_SERVLET_CONTEXT_KEY, categoryTreeDictionary);
		servletContext.setAttribute(CommonConstant.ENVIRONMENT, environment);
	}

	/**
	 * 
	 * Get the root CategoryTreeNode from a map of CategoryTreeNode Id and CategoryTreeNode 
	 * @param categoryTreeDictionary a map of CategoryTreeNode Id and CategoryTreeNode 
	 * @return root
	 */
	private CategoryTreeNode getRootCatetoryTreeNode(Map<Long, CategoryTreeNode> categoryTreeDictionary) {

		CategoryTreeNode root = null;
		for (Map.Entry<Long, CategoryTreeNode> entry : categoryTreeDictionary.entrySet()) {
			CategoryTreeNode currentCategory = entry.getValue();
			CategoryTreeNode parentCategory = categoryTreeDictionary.get(currentCategory.getParentCategoryId());
			currentCategory.setParentCategory(parentCategory);
			if (parentCategory.getCategoryId().equals(currentCategory.getCategoryId())) {
				root = currentCategory;
			} else {
				parentCategory.getSubCategories().add(currentCategory);
			}
		}
		sortCategoryByCategoryName(root);
		return root;
	}

	/**
	 * 
	 * removeOrphanTreeNode
	 * @param categoryTreeDictionary categoryTreeDictionary
	 */
	private void removeOrphanTreeNode(Map<Long, CategoryTreeNode> categoryTreeDictionary) {
		while (true) {
			boolean hasOrphanNode = false;
			for (CategoryTreeNode categoryTreeNode : categoryTreeDictionary.values()) {
				if (!categoryTreeDictionary.containsKey(categoryTreeNode.getParentCategoryId())) {
					CategoryTreeNode orphanNode = categoryTreeDictionary.remove(categoryTreeNode.getCategoryId());
					LOGGER.info("Found orphan node and removed: [Category_ID: " + orphanNode.getCategoryId()
							+ ", Category_Name:" + orphanNode.getCategoryName() + "]");
					hasOrphanNode = true;
					break;
				}
			}
			if (!hasOrphanNode) {
				break;
			}
		}
	}

	/**
	 * 
	 * Recursively sort the sub Categories by their names
	 * @param node a CategoryTreeNode instance
	 */
	private void sortCategoryByCategoryName(CategoryTreeNode node) {
		Collections.sort(node.getSubCategories(), new Comparator<CategoryTreeNode>() {
			@Override
			public int compare(CategoryTreeNode node1, CategoryTreeNode node2) {
				return node1.getCategoryName().compareToIgnoreCase(node2.getCategoryName());
			}
		});
		for (CategoryTreeNode categoryTreeNode : node.getSubCategories()) {
			sortCategoryByCategoryName(categoryTreeNode);
		}
	}

	/**
	 * 
	 * Transform a list of the Categories into a map of CategoryTreeNode Id and CategoryTreeNode,
	 * in the mean while, build the parent-child relationships between those CategoryTreeNodes.
	 * @param list a list of the Categories
	 * @return categoryTreeDictionary
	 */
	private Map<Long, CategoryTreeNode> createCategoryTreeDictionary(List<Category> list) {
		Map<Long, CategoryTreeNode> categoryTreeDictionary = new LinkedHashMap<Long, CategoryTreeNode>();
		for (Category category : list) {
			CategoryTreeNode treeNode = new CategoryTreeNode();
			treeNode.setCategoryId(category.getId());
			treeNode.setCategoryName(category.getName());
			treeNode.setParentCategoryId(category.getDefaultParentCategory().getId());
			treeNode.setUrl(category.getUrl());
			treeNode.setCategoryDesc(category.getLongDescription());
			treeNode.setCategoryType(CategoryType.SSC_CATEGORY);
			if (category.getCategoryMedia() != null && category.getCategoryMedia().get("primary") != null) {
				treeNode.setCategoryImgUrl(category.getCategoryMedia().get("primary").getUrl());
			}
			categoryTreeDictionary.put(category.getId(), treeNode);
		}
		return categoryTreeDictionary;
	}


	/**
	 * 
	 * removeArchieved
	 * @param tempList tempList
	 * @return List List
	 */
	private List<Category> removeArchieved(List<Category> tempList) {
		List<Category> list = new ArrayList<Category>();
		for (Category category : tempList) {
			Character achieved = ((CategoryImpl) category).getArchived();
			if (achieved == null || Character.toUpperCase(achieved) == 'N') {
				list.add(category);
			}
		}
		return list;
	}

	public void setUpBreadCrumb(HttpServletRequest request, CategoryTreeNode currentNodeParam) {
		CategoryTreeNode currentNode = currentNodeParam;
		if (currentNode.getCategoryId().equals(currentNode.getParentCategoryId())) {
			request.getSession().setAttribute("breadCrumbHtml", "");
			return;
		}
		String contextPath = request.getContextPath();
		StringBuffer breadCrumbSB = new StringBuffer();
		breadCrumbSB.append("<a href='").append(contextPath).append(currentNode.getUrl()).append("'>").append(HtmlUtils.htmlEscape(currentNode.getCategoryName())).append("</a>");
		currentNode = currentNode.getParentCategory();
		while (!currentNode.getCategoryId().equals(currentNode.getParentCategoryId())) {
			breadCrumbSB.insert(0, "&nbsp;&nbsp;>&nbsp;&nbsp;").insert(0, "</a>").insert(0, HtmlUtils.htmlEscape(currentNode.getCategoryName())).insert(0, "'>").insert(0, currentNode.getUrl()).insert(0, contextPath).insert(0, "<a href='");
			currentNode = currentNode.getParentCategory();
		}
		breadCrumbSB.insert(0, "&nbsp;&nbsp;>&nbsp;&nbsp;");
		request.getSession().setAttribute("breadCrumbHtml", breadCrumbSB.toString());
		
	}
	
	public void setUpBreadCrumb(HttpServletRequest request, Long categoryId) {
		ServletContext servletContext = request.getSession().getServletContext();
		Map<Long, CategoryTreeNode> categoryTreeDictionary = (Map<Long, CategoryTreeNode>)servletContext.getAttribute(CATEGORY_TREE_DICTIONARY_SERVLET_CONTEXT_KEY);
		CategoryTreeNode categoryTreeNode = categoryTreeDictionary.get(categoryId);
		if (categoryTreeNode == null) {
			request.getSession().setAttribute("breadCrumbHtml", "");
			return;
		}
		this.setUpBreadCrumb(request, categoryTreeNode);
	}
	
	public void clearBreadCrumb(HttpServletRequest request) {
		request.getSession().setAttribute("breadCrumbHtml", "");
	}
}
