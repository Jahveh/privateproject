/**
 * 
 */
package com.menards.ssc.service.jms;

import java.util.Collection;

import javax.annotation.Resource;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>JmsServiceImpl</p>
 * <p>Provide some method to send message</p>
 * <p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Service("jmsService")
public class JmsServiceImpl implements JmsService {

	public static final Logger LOG = Logger.getLogger(JmsService.class);

	@Resource(name = "jmsTemplate")
	private JmsTemplate jmsTemplate;

	@Override
	@Transactional(value="jmsTransactionManager", rollbackFor={Throwable.class})
	public boolean sendClothingMessage(Collection<String> messages) {
		if (CollectionUtils.isEmpty(messages)) {
			return false;
		}
		for (final String message : messages) {
			jmsTemplate.send(new MessageCreator() {
				public Message createMessage(Session session) throws JMSException {
					TextMessage textMessage = session.createTextMessage(message);
					textMessage.setStringProperty("OriginUnit", "1001");
					textMessage.setStringProperty("OriginDept", "IMS");
					textMessage.setStringProperty("OriginSystem", "StoreSuppliesCatalog");
					textMessage.setStringProperty("MessageType", "ClothingOrder");
					return textMessage;
				}
			});
		}
		return true;
	}
}
