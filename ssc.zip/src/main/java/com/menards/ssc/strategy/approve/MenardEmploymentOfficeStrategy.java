/**
 * 
 */
package com.menards.ssc.strategy.approve;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;

/**
 * <p>MenardSignShopStrategy</p>
 * <p>Item approve Strategy for sign shop </p>
 * <p>
 * Calculate and return the next status according to the current status and
 * the action.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Component
public class MenardEmploymentOfficeStrategy extends MenardItemApproveStrategy {

	@Override
	public String nextStage(MenardOrderItem item, String action) {
		boolean validRequest = isValidRequest(item, action)
				|| (!MenardOrderRequestType.Employment_Office.getKey().equals(item.getRequestType()));
		if (validRequest) {
			invalidException(item.getFulfillerTypeCode(), item.getRequestType());
		}

		boolean isInit = StringUtils.isEmpty(item.getStatus());
		boolean isPendingGM = isPendingGM(item.getStatus());

		if (isInit) {
			return MenardOrderItemStatus.PENDING_GM.getValue();
		}

		if (isApprovePM(isPendingGM, action)) {
			return MenardOrderItemStatus.PENDING_GO.getValue();
		}
		if (isDeclinePM(isPendingGM, action)) {
			return MenardOrderItemStatus.GM_DECLINED.getValue();
		}

		boolean isPendingGO = isPendingGO(item.getStatus());
		boolean isBackOrdered = MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());
		boolean isGOOrBackOrdered = isPendingGO || isBackOrdered;

		if (isApproveGO(isGOOrBackOrdered, action)) {
			return MenardOrderItemStatus.COMPLETED.getValue();
		}

		if (isDeclinePGO(isGOOrBackOrdered, action)) {
			return MenardOrderItemStatus.GO_DECLINED.getValue();
		}

		if (isBackorderedPGO(isPendingGO, action)) {
			return MenardOrderItemStatus.BACKORDERED.getValue();
		}
		invalidStatus(item.getStatus(), action);
		return StringUtils.EMPTY;
	}

	/**
	 *Constructor 
	 */
	public MenardEmploymentOfficeStrategy() {
		registerStrategy(MenardFulfillerType.EMPLOYMENT_OFFICE.getKey(), this);
	}
}
