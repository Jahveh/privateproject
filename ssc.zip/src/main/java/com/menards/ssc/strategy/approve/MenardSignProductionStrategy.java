/**
 * 
 */
package com.menards.ssc.strategy.approve;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.service.catalog.MenardColorSignService;
import com.menards.ssc.service.catalog.MenardSignService;

/**
 * <p>MenardSignProductionStrategy</p>
 * <p>Item approve Strategy for sign production </p>
 * <p>
 * Calculate and return the next status according to the current status and
 * the action.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Component
public class MenardSignProductionStrategy extends MenardItemApproveStrategy {

	@Resource(name = "colorSignService")
	private MenardColorSignService colorSignService;

	@Resource(name = "signService")
	private MenardSignService signService;

	/**
	 * 
	 *Constructor
	 */
	public MenardSignProductionStrategy() {
		registerStrategy(MenardFulfillerType.SIGN_PRODUCTION.getKey(), this);
	}

	@Override
	public String nextStage(MenardOrderItem item, String action) {

		if (isValidRequest(item, action)) {
			invalidException(item.getFulfillerTypeCode(), item.getRequestType());
		}
		boolean isInit = StringUtils.isEmpty(item.getStatus());
		String requestType = item.getRequestType();
		boolean isPendingGM = isPendingGM(item.getStatus());
		boolean isPendingGO = isPendingGO(item.getStatus());
		boolean isBackOrder = MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());

		if (MenardOrderRequestType.Merch_Sign.getKey().equals(requestType)
				|| MenardOrderRequestType.Zoomer.getKey().equals(requestType)
				|| MenardOrderRequestType.Color_Signbase.getKey().equals(requestType)
				|| MenardOrderRequestType.Color_Signbase_GM.getKey().equals(requestType)) {
			return processSignType(item, isInit, isPendingGM, isPendingGO, isBackOrder, action);
		}

		if (MenardOrderRequestType.Welcome_Sign.getKey().equals(requestType)
				|| MenardOrderRequestType.Color_Sign.getKey().equals(requestType)
				|| MenardOrderRequestType.Business_Cards.getKey().equals(requestType)) {
			return processOtherSign(isInit, isPendingGM, isPendingGO, isBackOrder, action);
		}

		boolean isDcItem = item.isDcItem();
		if (MenardOrderRequestType.CARD_STOCK.getKey().equals(requestType)) {
			return processCardStock(isInit, isPendingGM, isPendingGO, isDcItem, action);
		}
		invalidException(item.getFulfillerTypeCode(), item.getRequestType());
		return StringUtils.EMPTY;
	}

	/**
	 * Mainly deal with some other types of sign
	 * @param isInit boolean
	 * @param isPGM boolean
	 * @param isPGO boolean
	 * @param isBackOrder boolean
	 * @param action String
	 * @return String
	 */
	private String processOtherSign(boolean isInit, boolean isPGM, boolean isPGO, boolean isBackOrder, String action) {

		if (isInit) {
			return MenardOrderItemStatus.PENDING_GM.getValue();
		}

		if (isApprovePM(isPGM, action)) {
			return MenardOrderItemStatus.PENDING_GO.getValue();
		}
		if (isDeclinePM(isPGM, action)) {
			return MenardOrderItemStatus.GM_DECLINED.getValue();
		}

		boolean goInTheMail = (isPGO || isBackOrder) && MenardItemApproveAction.APPROVED.getKey().equals(action);

		if (goInTheMail) {
			return MenardOrderItemStatus.IN_THE_MAIL.getValue();
		}
		if (isDeclinePGO((isPGO || isBackOrder), action)) {
			return MenardOrderItemStatus.GO_DECLINED.getValue();
		}
		if (isBackorderedPGO(isPGO, action)) {
			return MenardOrderItemStatus.BACKORDERED.getValue();
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Intended to deal with the sign type production
	 * @param item MenardOrderItem
	 * @param isInit boolean
	 * @param isPGM boolean
	 * @param isPGO boolean
	 * @param isBO boolean
	 * @param action String
	 * @return String
	 */
	private String processSignType(MenardOrderItem item, boolean isInit, boolean isPGM, boolean isPGO, boolean isBO,
			String action) {
		String requestType = item.getRequestType();
		boolean isStorePrint = item.isStorePrint();
		if (isInit && isStorePrint) {
			return processMerchSignAndZoomer(item, true);
		}

		boolean initAndNotStore = isInit && (!isStorePrint);

		if (initAndNotStore && MenardOrderRequestType.Color_Signbase_GM.getKey().equals(requestType)) {
			return MenardOrderItemStatus.PENDING_GM.getValue();
		}

		if (initAndNotStore) {
			return processMerchSignAndZoomer(item, false);
		}

		// Pending GM
		String approvedKey = MenardItemApproveAction.APPROVED.getKey();
		String merchSignKey = MenardOrderRequestType.Merch_Sign.getKey();
		String zoomerKey = MenardOrderRequestType.Zoomer.getKey();
		boolean goPrintAtStore = isPGM && isStorePrint && approvedKey.equals(action)
				&& (merchSignKey.equals(requestType) || zoomerKey.equals(requestType));
		if (goPrintAtStore) {
			signService.insertSignOrder(item);
			return MenardOrderItemStatus.PRINTED_AT_STORE.getValue();
		}

		if ((isPGM || isPGO || isBO) && MenardItemApproveAction.APPROVED.getKey().equals(action)) {
			return processMerchSignAndZoomer(item, false);
		}

		if (isDeclinePM(isPGM, action)) {
			return MenardOrderItemStatus.GM_DECLINED.getValue();
		}

		if (isDeclinePGO((isPGO || isBO), action)) {
			return MenardOrderItemStatus.GO_DECLINED.getValue();
		}

		if (isBackorderedPGO(isPGO, action)) {
			return MenardOrderItemStatus.BACKORDERED.getValue();
		}
		invalidStatus(item.getStatus(), action);
		return StringUtils.EMPTY;
	}

	/**
	 * Deal with card stock
	 * @param isInit boolean
	 * @param isPGM boolean
	 * @param isPGO boolean
	 * @param isDc  boolean
	 * @param action String
	 * @return String
	 */
	private String processCardStock(boolean isInit, boolean isPGM, boolean isPGO, boolean isDc, String action) {
		if (isInit) {
			return MenardOrderItemStatus.PENDING_GM.getValue();
		}
		if ((isPGM || isPGO) && MenardItemApproveAction.APPROVED.getKey().equals(action)) {
			return processDcitem(isDc, isPGO);
		}
		if (isPGM && MenardItemApproveAction.DECLINED.getKey().equals(action)) {
			return MenardOrderItemStatus.GM_DECLINED.getValue();
		}
		invalidStatus(null, action);
		return StringUtils.EMPTY;
	}

	/**
	 * 
	 * @param isDcItem boolean
	 * @param isPendingGO boolean
	 * @return String
	 */
	private String processDcitem(boolean isDcItem, boolean isPendingGO) {
		if (isDcItem) {
			return MenardOrderItemStatus.BATCHED_FOR_DC.getValue();
		}
		if (isPendingGO) {
			return MenardOrderItemStatus.IN_THE_MAIL.getValue();
		}
		return MenardOrderItemStatus.PENDING_GO.getValue();
	}

	/**
	 * 
	 * @param item MenardOrderItem
	 * @param isStorePrint boolean
	 * @return String
	 */
	private String processMerchSignAndZoomer(MenardOrderItem item, boolean isStorePrint) {
		String requestType = item.getRequestType();
		if (MenardOrderRequestType.Merch_Sign.getKey().equals(requestType)
				|| MenardOrderRequestType.Zoomer.getKey().equals(requestType)) {
			signService.insertSignOrder(item);
			if (isStorePrint) {
				return MenardOrderItemStatus.PRINTED_AT_STORE.getValue();
			} else {
				return MenardOrderItemStatus.REQUEST_SENT.getValue();
			}
		}
		return insertSignOrder(item);
	}

	/**
	 * Generate a new order to sign database 
	 * @param item MenardOrderItem
	 * @return String
	 */
	private String insertSignOrder(MenardOrderItem item) {
		boolean success = colorSignService.saveSignOrder(item);
		if (success) {
			return MenardOrderItemStatus.REQUEST_SENT.getValue();
		}
		return MenardOrderItemStatus.GO_DECLINED.getValue();
	}

}
