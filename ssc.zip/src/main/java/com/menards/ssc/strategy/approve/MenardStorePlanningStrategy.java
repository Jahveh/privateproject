/**
 * 
 */
package com.menards.ssc.strategy.approve;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;

/**
 * <p>MenardStorePlanningStrategy</p>
 * <p>Item approve Strategy for sign shop </p>
 * <p>
 * Calculate and return the next status according to the current status and
 * the action.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Component
public class MenardStorePlanningStrategy extends MenardItemApproveStrategy {

	private Set<String> requestTypes = new HashSet<String>();

	@Override
	public String nextStage(MenardOrderItem item, String action) {
		boolean isValidRequest = isValidRequest(item, action);
		boolean isContainedRequestType = requestTypes.contains(item.getRequestType());
		boolean validRequest = isValidRequest || (!isContainedRequestType);
		if (validRequest) {
			invalidException(item.getFulfillerTypeCode(), item.getRequestType());
		}
		boolean isStoreRemodel = item.isStoreRemodel();
		boolean isInit = StringUtils.isEmpty(item.getStatus());
		boolean isPendingGM = isPendingGM(item.getStatus());

		if (isInit) {
			return MenardOrderItemStatus.PENDING_GM.getValue();
		}

		if (isApprovePM(isPendingGM, action)) {
			boolean goPengdingGO = isStoreRemodel || !item.isDcItem();
			if (goPengdingGO) {
				return MenardOrderItemStatus.PENDING_GO.getValue();
			}
			return MenardOrderItemStatus.BATCHED_FOR_DC.getValue();
		}
		if (isDeclinePM(isPendingGM, action)) {
			return MenardOrderItemStatus.GM_DECLINED.getValue();
		}

		boolean isPendingGO = isPendingGO(item.getStatus());
		boolean isBackOrdered = MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());
		boolean isGoOrBackorder = isPendingGO || isBackOrdered;

		if (isApproveGO(isGoOrBackorder, action)) {
			return processDcitem(item.isDcItem());
		}

		if (isDeclinePGO(isGoOrBackorder, action)) {
			return MenardOrderItemStatus.GO_DECLINED.getValue();
		}

		if (isBackorderedPGO(isPendingGO, action)) {
			return MenardOrderItemStatus.BACKORDERED.getValue();
		}
		invalidStatus(item.getStatus(), action);
		return StringUtils.EMPTY;
	}

	/**
	 * Deal with the specific case
	 * @param isDcItem boolean
	 * @return String
	 */
	private String processDcitem(boolean isDcItem) {
		if (isDcItem) {
			return MenardOrderItemStatus.BATCHED_FOR_DC.getValue();
		}
		return MenardOrderItemStatus.COMPLETED.getValue();
	}

	/**
	 *Constructor 
	 */
	public MenardStorePlanningStrategy() {
		requestTypes.add(MenardOrderRequestType.GSS.getKey());
		requestTypes.add(MenardOrderRequestType.GSS_Fixture.getKey());
		requestTypes.add(MenardOrderRequestType.GSS_Pallet_Racking.getKey());
		registerStrategy(MenardFulfillerType.STORE_PLANNING.getKey(), this);
	}
}
