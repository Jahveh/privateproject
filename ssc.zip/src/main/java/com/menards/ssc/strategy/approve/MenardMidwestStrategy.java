/**
 * 
 */
package com.menards.ssc.strategy.approve;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;

/**
 * <p>MenardMidwestStrategy</p>
 * <p>Item approve Strategy for midwest </p>
 * <p>
 * Calculate and return the next status according to the current status and
 * the action.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Component
public class MenardMidwestStrategy extends MenardItemApproveStrategy {

	@Override
	public String nextStage(MenardOrderItem item, String action) {

		boolean validRequest = isValidRequest(item, action)
				|| !MenardOrderRequestType.Literature.getKey().equals(item.getRequestType());
		if (validRequest) {
			invalidException(item.getFulfillerTypeCode(), item.getRequestType());
		}

		boolean isInit = StringUtils.isEmpty(item.getStatus());
		boolean isPendingGM = isPendingGM(item.getStatus());
		boolean isPendingGO = isPendingGO(item.getStatus());
		boolean isBackOrdered = isBackOrdered(item.getStatus());

		if (isInit) {
			return MenardOrderItemStatus.PENDING_GM.getValue();
		}
		boolean isGOOrBackOrder = isPendingGO || isBackOrdered;

		if (isApprovePM((isPendingGM || isGOOrBackOrder), action)) {
			return processDcitem(item.isDcItem(), isGOOrBackOrder);
		}
		if (isDeclinePM(isPendingGM, action)) {
			return MenardOrderItemStatus.GM_DECLINED.getValue();
		}

		if (isDeclinePGO(isGOOrBackOrder, action)) {
			return MenardOrderItemStatus.GO_DECLINED.getValue();
		}

		if (isBackorderedPGO(isPendingGO, action)) {
			return MenardOrderItemStatus.BACKORDERED.getValue();
		}
		invalidStatus(item.getStatus(), action);
		return StringUtils.EMPTY;
	}

	/**
	 * Deal with the specific case
	 * @param isDcItem Boolean
	 * @param isPendingGO Boolean
	 * @return String
	 */
	private String processDcitem(Boolean isDcItem, Boolean isPendingGO) {
		if (isDcItem) {
			return MenardOrderItemStatus.BATCHED_FOR_DC.getValue();
		}
		if (isPendingGO) {
			return MenardOrderItemStatus.COMPLETED.getValue();
		}
		return MenardOrderItemStatus.PENDING_GO.getValue();
	}

	/**
	 * 
	 *Constructor
	 */
	public MenardMidwestStrategy() {
		registerStrategy(MenardFulfillerType.MIDWEST.getKey(), this);
	}
}
