/**
 * 
 */
package com.menards.ssc.strategy.approve;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;

/**
 * <p>MenardOperationsStrategy</p>
 * <p>Item approve Strategy for operations </p>
 * <p>
 * Calculate and return the next status according to the current status and
 * the action.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Component
public class MenardOperationsStrategy extends MenardItemApproveStrategy {

	private Set<String> requestTypes = new HashSet<String>();
	private Set<String> allRequestTypes = new HashSet<String>();

	@Override
	public String nextStage(MenardOrderItem item, String action) {
		boolean validRequest = isValidRequest(item, action) || !allRequestTypes.contains(item.getRequestType());
		if (validRequest) {
			invalidException(item.getFulfillerTypeCode(), item.getRequestType());
		}
		String requestType = item.getRequestType();
		boolean isInit = StringUtils.isEmpty(item.getStatus());
		boolean isPendingGM = isPendingGM(item.getStatus());
		boolean isPendingGO = isPendingGO(item.getStatus());
		boolean isBackOrdered = isBackOrdered(item.getStatus());

		if (isInit) {
			return MenardOrderItemStatus.PENDING_GM.getValue();
		}

		if (isBackorderedPGO(isPendingGO, action)) {
			return MenardOrderItemStatus.BACKORDERED.getValue();
		}

		if (requestTypes.contains(requestType)) {
			return processOtherRequest(isPendingGM, isPendingGO, isBackOrdered, action);
		}

		boolean goSpecialOrder = MenardOrderRequestType.Special_Order.getKey().equals(requestType)
				|| MenardOrderRequestType.Facilities.getKey().equals(requestType);
		if (goSpecialOrder) {
			return processSpecialOrder(item, isPendingGO, isPendingGM, isBackOrdered, action);
		}
		invalidStatus(item.getStatus(), action);
		return StringUtils.EMPTY;
	}

	/**
	 *
	 * @param isPendingGM boolean
	 * @param isPendingGO boolean
	 * @param isBackOrdered boolean
	 * @param action String
	 * @return String
	 */
	private String processOtherRequest(boolean isPendingGM, boolean isPendingGO, boolean isBackOrdered, String action) {

		if (isApprovePM(isPendingGM, action)) {
			return MenardOrderItemStatus.PENDING_GO.getValue();
		}
		if (isDeclinePM(isPendingGM, action)) {
			return MenardOrderItemStatus.GM_DECLINED.getValue();
		}

		if (isApproveGO(isPendingGO || isBackOrdered, action)) {
			return MenardOrderItemStatus.IN_THE_MAIL.getValue();
		}

		if (isDeclinePGO((isPendingGO || isBackOrdered), action)) {
			return MenardOrderItemStatus.GO_DECLINED.getValue();
		}
		invalidStatus(StringUtils.EMPTY, action);
		return StringUtils.EMPTY;
	}

	/**
	 *
	 * @param item MenardOrderItem
	 * @param isPendingGO boolean
	 * @param isPendingGM boolean
	 * @param isBackOrdered boolean
	 * @param action String
	 * @return String
	 */
	private String processSpecialOrder(MenardOrderItem item, boolean isPendingGO, boolean isPendingGM,
			boolean isBackOrdered, String action) {

		if (isApprovePM(isPendingGM, action)) {
			return processDcitem(item.isDcItem(), isPendingGO);
		}
		if (isDeclinePM(isPendingGM, action)) {
			return MenardOrderItemStatus.GM_DECLINED.getValue();
		}

		if ((isPendingGO || isBackOrdered) && MenardItemApproveAction.APPROVED.getKey().equals(action)) {
			return processDcitem(item.isDcItem(), (isPendingGO || isBackOrdered));
		}

		if (isDeclinePGO((isPendingGO || isBackOrdered), action)) {
			return MenardOrderItemStatus.GO_DECLINED.getValue();
		}
		return StringUtils.EMPTY;
	}

	/**
	 * 
	 * @param isDcItem Boolean
	 * @param isPendingGO Boolean
	 * @return String
	 */
	private String processDcitem(boolean isDcItem, boolean isPendingGO) {
		if (isDcItem) {
			return MenardOrderItemStatus.BATCHED_FOR_DC.getValue();
		}
		if (isPendingGO) {
			return MenardOrderItemStatus.IN_THE_MAIL.getValue();
		}
		return MenardOrderItemStatus.PENDING_GO.getValue();
	}

	/**
	 *Constructor 
	 */
	public MenardOperationsStrategy() {
		requestTypes.add(MenardOrderRequestType.Contractor.getKey());
		requestTypes.add(MenardOrderRequestType.Front_End.getKey());
		requestTypes.add(MenardOrderRequestType.Human_Resources.getKey());
		requestTypes.add(MenardOrderRequestType.Scheduling_1.getKey());
		requestTypes.add(MenardOrderRequestType.Scheduling_2.getKey());
		requestTypes.add(MenardOrderRequestType.Security.getKey());
		requestTypes.add(MenardOrderRequestType.Training.getKey());
		allRequestTypes.addAll(requestTypes);
		allRequestTypes.add(MenardOrderRequestType.Special_Order.getKey());
		allRequestTypes.add(MenardOrderRequestType.Facilities.getKey());
		registerStrategy(MenardFulfillerType.OPERATIONS.getKey(), this);
	}
}
