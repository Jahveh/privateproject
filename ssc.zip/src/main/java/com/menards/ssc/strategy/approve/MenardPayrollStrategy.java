/**
 * 
 */
package com.menards.ssc.strategy.approve;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.xml.XMLConstants;
import javax.xml.bind.*;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import com.menards.order.clothing.ClothingOrder;
import com.menards.order.clothing.ClothingOrderValidationHandler;
import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.geronimo.mail.util.StringBufferOutputStream;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlValidationError;
import org.broadleafcommerce.profile.core.domain.Customer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import com.menards.order.clothing.OrderLine;
import com.menards.order.clothing.OrderStatus;
import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.yard.Store;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.service.jms.JmsService;
import com.menards.ssc.service.yard.MenardYardService;

import org.xml.sax.SAXException;

/**
 * <p>MenardPayrollStrategy</p>
 * <p>Item approve Strategy for payroll </p>
 * <p>
 * Calculate and return the next status according to the current status and
 * the action.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Component
public class MenardPayrollStrategy extends MenardItemApproveStrategy {

	@Resource(name = "menardYardService")
	private MenardYardService yardService;
	
	@Resource(name = "jmsService")
	private JmsService jmsService;

	/*@Resource(name = "jmsQueueSender")
	private JmsQueueSender jmsQueueSender;*/

	@Override
	public String nextStage(MenardOrderItem item, String action) {
		if (isValidRequest(item, action) || (!MenardOrderRequestType.Clothing.getKey().equals(item.getRequestType()))) {
			invalidException(item.getFulfillerTypeCode(), item.getRequestType());
		}
		boolean isInit = StringUtils.isEmpty(item.getStatus());
		boolean isPendingGM = isPendingGM(item.getStatus());
		boolean isPendingGO = isPendingGO(item.getStatus());
		if (isInit) {
			return MenardOrderItemStatus.PENDING_GM.getValue();
		}

		if ((isPendingGM || isPendingGO) && MenardItemApproveAction.APPROVED.getKey().equals(action)) {
			sendClothingOrder(item);
			return MenardOrderItemStatus.REQUEST_SENT.getValue();
		}
		if (isPendingGM && MenardItemApproveAction.DECLINED.getKey().equals(action)) {
			return MenardOrderItemStatus.GM_DECLINED.getValue();
		}
		invalidStatus(item.getStatus(), action);
		return StringUtils.EMPTY;
	}

	/**
	 * 
	 * @param item MenardOrderItem
	 */
	private void sendClothingOrder(MenardOrderItem item) {
		List<MenardOrderItem> orderItems = new ArrayList<MenardOrderItem>();
		orderItems.add(item);
		String storeId = item.getMenardOrder().getStoreId();
		Store store = yardService.getStore(storeId);
		String message = generateMessage(item.getMenardOrder(), orderItems, store);
		if (LOG.isDebugEnabled()) {
			LOG.debug("Clothing message[" + message + "]");
		}
		addMessage(message);
	   /*boolean result = jmsQueueSender.send(message);
		if (!result) {
			throw new MenardItemApproveStrategyException("Fail to send message for clothing order");
		}*/
	}

    private ClothingOrder convertToClothingOrder(MenardOrder menardOrder, List<MenardOrderItem> orderItems, Store store) {
        ClothingOrder clothingOrder = new ClothingOrder();
        ClothingOrder.Order order = new ClothingOrder.Order();
        clothingOrder.setOrder(order);
        long orderNumber = Long.valueOf(menardOrder.getId());
        order.setOrderNumber(orderNumber);
        order.setPosOrderNumber(0L);
        order.setTimestamp(new XMLGregorianCalendarImpl(new GregorianCalendar()));
        order.setShipToNumber(Integer.parseInt(store.getStoreNumber()));
        order.setShipToDepartment(escapeString(menardOrder.getDeptId()));
        order.setBillToName(escapeString(store.getStoreName()));
        order.setBillToNumber(Integer.valueOf(store.getStoreNumber()));
        order.setOrderDescription("Store Clothing Order");
        order.setPostalCode(store.getZip());
        for (MenardOrderItem item : orderItems) {
            OrderLine line = new OrderLine();
            line.setOrderNumber(orderNumber);
            line.setSequenceNumber(item.getLineNumber());
            line.setSku(Integer.parseInt(item.getMenardSkuCode()));
            line.setItemQuantity(item.getQuantity());
            /*if (StringUtils.isEmpty(item.getNotes())) {
                line.setItemDescription(CommonConstant.SPACE);
            } else {
                line.setItemDescription(item.getNotes());
            }*/
            if (StringUtils.isNotBlank(item.getDescription())) {
               line.setItemDescription(escapeString(item.getDescription()));
            }
            
            line.setStatus(OrderStatus.PENDING);
            order.getItem().add(line);
        }
        return clothingOrder;
    }
    
    private String escapeString(String inputString){
        if (inputString != null){
           inputString = inputString.replace("&", "&amp;");
        }        
        return inputString;
    }


    private String serializeClothingOrder(ClothingOrder clothingOrder) {
        StringBuffer stringBuffer = new StringBuffer("");
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new StringBufferOutputStream(stringBuffer));
        SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        try {
            Schema schema = schemaFactory.newSchema(new ClassPathResource("/com/menards/order/clothing/order-clothing-1.0.xsd").getFile());
            JAXBContext jaxbContext = JAXBContext.newInstance(ClothingOrder.class);
            Marshaller marshaller = jaxbContext.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.setSchema(schema);
            marshaller.setEventHandler(new ClothingOrderValidationHandler());
            marshaller.marshal(clothingOrder, bufferedOutputStream);
            bufferedOutputStream.flush();
            bufferedOutputStream.close();
        } catch (MarshalException marshalException) {
//            LOG.error(marshalException.getLinkedException().getMessage());
            throw new MenardItemApproveStrategyException(marshalException.getLinkedException().getMessage());
        } catch (Exception ex) {
//            LOG.error(ex.getMessage());
            throw new MenardItemApproveStrategyException(ex.getMessage());
        }
        return stringBuffer.toString();
    }

	/**
	 * @param menardOrder MenardOrder
	 * @param orderItems List<MenardOrderItem>
	 * @param store Store
	 * @return String
	 */
	public String generateMessage(MenardOrder menardOrder, List<MenardOrderItem> orderItems, Store store) {
        ClothingOrder clothingOrder = convertToClothingOrder(menardOrder, orderItems, store);
        return serializeClothingOrder(clothingOrder);

        /*ClothingOrderDocument doc = ClothingOrderDocument.Factory.newInstance();
		ClothingOrder clothingOrder = doc.addNewClothingOrder();
		Order order = clothingOrder.addNewOrder();
		long orderNum = Long.valueOf(menardOrder.getId());
		order.setOrderNumber(orderNum);
		order.setPosOrderNumber(0L);
		order.setTimestamp(new GregorianCalendar());
		order.setShipToNumber(Integer.parseInt(store.getStoreNumber()));
		order.setShipToDepartment(menardOrder.getDeptId());
		order.setBillToName(store.getStoreName());
		order.setBillToNumber(Integer.valueOf(store.getStoreNumber()));
		order.setOrderDescription("Store Clothing Order");
		order.setPostalCode(store.getZip());
		for (MenardOrderItem item : orderItems) {
			OrderLine line = order.addNewItem();
			line.setOrderNumber(orderNum);
			line.setSequenceNumber(item.getLineNumber());
			line.setSku(Integer.parseInt(item.getMenardSkuCode()));
			line.setItemQuantity(item.getQuantity());
			if (StringUtils.isEmpty(item.getNotes())) {
				line.setItemDescription(CommonConstant.SPACE);
			} else {
				line.setItemDescription(item.getNotes());
			}
			line.setStatus(OrderStatus.PENDING);
		}

		XmlOptions options = new XmlOptions();
		List<XmlValidationError> list = new ArrayList<XmlValidationError>();
		options.setErrorListener(list);
		boolean flag = false;
		if (!doc.validate(options)) {
			for (XmlValidationError error : list) {
				if (error.getErrorType() != 3) {
					flag = true;
					LOG.error(error.toString());
				}
			}
			if (flag) {
				throw new MenardItemApproveStrategyException(doc.toString());
			}
		}
		StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		XmlOptions outOptions = new XmlOptions();
		outOptions.setUseDefaultNamespace();
		sb.append(doc.xmlText(outOptions));
		if (LOG.isDebugEnabled()) {
			LOG.debug(sb.toString());
		}
		return StringUtils
				.replace(sb.toString(), "><order>",
						" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><order xmlns=\"http://order.menards.com/clothing/\">");*/
	}
	
	@PostConstruct
	public void init() throws Exception {		
		registerStrategy(MenardFulfillerType.PAYROLL.getKey(), this);
		MenardItemApproveStrategy.JMSSERVICE = jmsService;
	}
}
