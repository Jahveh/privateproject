package com.menards.ssc.strategy.approve;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.service.jms.JmsService;

/**
 * <p>MenardItemApproveStrategy</p>
 * <p>Approve strategy</p>
 * <p>
 * Only provide an implementation method to retrieve the
 * initial status of order item according to order item's
 * fulfiller type and current user's fulfiller type. In
 * addition, each fulfiller type has different next stage 
 * workflow. 
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public abstract class MenardItemApproveStrategy {

	private static final Map<String, MenardItemApproveStrategy> MAP = new HashMap<String, MenardItemApproveStrategy>();

	protected static final Log LOG = LogFactory.getLog(MenardItemApproveStrategy.class);
	
	private static final ThreadLocal<Set<String>> MESSAGES = new ThreadLocal<Set<String>>();
	
	protected static JmsService JMSSERVICE;

	/**
	 * Retrieve the initial status of order item.
	 * If order is Go order and its fulfiller type is equal to current 
	 * user's or the current user is Super go it's unnecessary to get approval
	 * of Go.
	 * 
	 * @param item MenardOrderItem
	 * @param isGoOrder Boolean
	 * @param userfulfiller String
	 * @return String
	 */
	public String getInitStatus(MenardOrderItem item, boolean isGoOrder, String userfulfiller) {
		if (item == null) {
			invalidStatus(null, null);
			return null;
		}

		LOG.debug("Init Status parameters: isGoOrder[" + isGoOrder + "], userfulfiller[" + userfulfiller
				+ "], item id [" + item.getId() + "]");

		String status = StringUtils.EMPTY;

		boolean sameFulfillerOrSuperGo = (StringUtils.equals(item.getFulfillerTypeCode(), userfulfiller) || MenardFulfillerType.SUPER_GO
				.getKey().equals(userfulfiller));

		// Not Go order goes to the common work flow
		boolean factTag = isGoOrder && !sameFulfillerOrSuperGo
				&& MenardFulfillerType.FACT_TAG.getKey().equals(item.getFulfillerTypeCode());
		if (!isGoOrder || factTag) {
			status = nextStage(item, null);
			LOG.debug("Retrun status[" + status + "]");
			return status;
		}

		boolean goOrderSameFulfillerOrSuperGo = isGoOrder && sameFulfillerOrSuperGo;

		if (goOrderSameFulfillerOrSuperGo) {
			item.setStatus(MenardOrderItemStatus.PENDING_GO.getValue());
			status = nextStage(item, MenardItemApproveAction.APPROVED.getKey());
			LOG.debug("Retrun status[" + status + "]");
			return status;
		}

		boolean goOrderNotFactTag = isGoOrder
				&& (!MenardFulfillerType.FACT_TAG.getKey().equals(item.getFulfillerTypeCode()));

		if (goOrderNotFactTag) {
			item.setStatus(MenardOrderItemStatus.PENDING_GM.getValue());
			status = nextStage(item, MenardItemApproveAction.APPROVED.getKey());
			LOG.debug("Retrun status[" + status + "]");
			return status;
		}
		invalidStatus(item.getStatus(), null);
		return StringUtils.EMPTY;
	}

	/**
	 * Calculate the next status of order item according to
	 * its current status, its request type and user's action, approve
	 * decline and back order.
	 * 
	 * @param item MenardOrderItem
	 * @param action String
	 * @return String
	 */
	public abstract String nextStage(MenardOrderItem item, String action);

	/**
	 * Make sure that the request for next status is valid
	 * @param item MenardOrderItem
	 * @param action String
	 * @return Boolean
	 */
	protected Boolean isValidRequest(MenardOrderItem item, String action) {
		return (item == null || StringUtils.isNotEmpty(item.getStatus()) && StringUtils.isEmpty(action));
	}

	/**
	 * @param status String
	 * @return Boolean
	 */
	protected Boolean isPendingGM(String status) {
		return MenardOrderItemStatus.PENDING_GM.getValue().equals(status);
	}

	/**
	 * @param status String
	 * @return Boolean
	 */
	protected Boolean isPendingGO(String status) {
		return MenardOrderItemStatus.PENDING_GO.getValue().equals(status);
	}

	/**
	 * @param status String
	 * @return Boolean
	 */
	protected Boolean isBackOrdered(String status) {
		return MenardOrderItemStatus.BACKORDERED.getValue().equals(status);
	}

	/**
	 * 
	 * @param isPendingGM boolean
	 * @param action String
	 * @return boolean
	 */
	protected boolean isDeclinePM(boolean isPendingGM, String action) {
		return isPendingGM && MenardItemApproveAction.DECLINED.getKey().equals(action);
	}

	/**
	 * 
	 * @param isPendingGO boolean
	 * @param action String
	 * @return boolean
	 */
	protected boolean isDeclinePGO(boolean isPendingGO, String action) {
		return isPendingGO && MenardItemApproveAction.DECLINED.getKey().equals(action);
	}

	/**
	 * 
	 * @param isPendingGO boolean
	 * @param action String 
	 * @return boolean
	 */
	protected boolean isBackorderedPGO(boolean isPendingGO, String action) {
		return isPendingGO && MenardItemApproveAction.BACKORDERED.getKey().equals(action);
	}

	/**
	 * 
	 * @param  isPendingGM boolean
	 * @param  action String
	 * @return boolean
	 */
	protected boolean isApprovePM(boolean isPendingGM, String action) {
		return isPendingGM && MenardItemApproveAction.APPROVED.getKey().equals(action);
	}

	/**
	 * 
	 * @param  isPendingGO boolean
	 * @param  action String
	 * @return boolean
	 */
	protected boolean isApproveGO(boolean isPendingGO, String action) {
		return isPendingGO && MenardItemApproveAction.APPROVED.getKey().equals(action);
	}

	/**
	 *
	 * @param type String
	 * @param strategy MenardItemApproveStrategy
	 */
	protected void registerStrategy(String type, MenardItemApproveStrategy strategy) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Strategy register type [" + type + "]");
		}
		MenardItemApproveStrategy.MAP.put(type, strategy);
	}

	private static final String MESSAGE = "Request type does not match fulfiller type";

	/**
	 * 	
	 * @param fulfillerType String
	 * @param requestType String
	 */
	protected void invalidException(String fulfillerType, String requestType) {
		StringBuilder sb = new StringBuilder(MESSAGE);
		sb.append(":fulfillerType[");
		sb.append(fulfillerType);
		sb.append("] and RequestType[");
		sb.append(requestType);
		sb.append("]");
		LOG.error(sb.toString());
		throw new MenardItemApproveStrategyException(sb.toString());
	}

	private static final String INVALID_STATUS_MESSAGE = "Current status does not support specific action";

	/**
	 * 	
	 * @param status String
	 * @param action String
	 */
	protected void invalidStatus(String status, String action) {
		StringBuilder sb = new StringBuilder(INVALID_STATUS_MESSAGE);
		sb.append(":Status[");
		sb.append(status);
		sb.append("] and Action[");
		sb.append(action);
		sb.append("]");
		LOG.error(sb.toString());
		throw new MenardItemApproveStrategyException(sb.toString());
	}
	
	/**
	 * Add message to collection
	 * @param message String
	 */
	public void addMessage(String message) {
		if (CollectionUtils.isEmpty(MESSAGES.get())) {
			MESSAGES.set(new HashSet<String>());
		}
		MESSAGES.get().add(message);
	}

	/**
	 * Execute all the related task and clear information
	 */
	public static void executeAndClear() {
		if (CollectionUtils.isNotEmpty(MESSAGES.get())) {
			JMSSERVICE.sendClothingMessage(MESSAGES.get());
			MESSAGES.set(null);
		}
	}

	/**
	 * 
	 * @param fulfillerType String
	 * @return MenardItemApproveStrategy
	 */
	public static MenardItemApproveStrategy getStrategy(String fulfillerType) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("fulfillerType that Approve Strategy received is [" + fulfillerType + "]");
		}
		return MAP.get(fulfillerType);
	}

	/**
	 * <p>MenardItemApproveStrategyException</p>	
	 * <p>	
	 * </p>
	 * <p>Copyright (c) 2014</p>
	 * <p>Menard Inc.</p>
	 * @author leo.yang
	 * @version 1.0
	 */
	public static class MenardItemApproveStrategyException extends RuntimeException {

		private static final long serialVersionUID = 574040476385659703L;

		/**
		 *Constructor 
		 *@param message String
		 */
		public MenardItemApproveStrategyException(String message) {
			super(message);
		}
	}
}