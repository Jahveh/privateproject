/**
 * 
 */
package com.menards.ssc.strategy.approve;

import java.util.HashSet;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.service.catalog.MenardColorSignService;

/**
 * <p>MenardSignShopStrategy</p>
 * <p>Item approve Strategy for sign shop </p>
 * <p>
 * Calculate and return the next status according to the current status and
 * the action.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Component
public class MenardSignShopStrategy extends MenardItemApproveStrategy {

	@Resource(name = "colorSignService")
	private MenardColorSignService colorSignService;

	private final Set<String> otherSignTypes = new HashSet<String>();

	@Override
	public String nextStage(MenardOrderItem item, String action) {

		if (isValidRequest(item, action)) {
			invalidException(item.getFulfillerTypeCode(), item.getRequestType());
		}

		String requestCode = item.getRequestType();
		boolean isInit = StringUtils.isEmpty(item.getStatus());
		boolean isPendingGM = isPendingGM(item.getStatus());
		boolean isPendingGO = isPendingGO(item.getStatus());
		boolean isBackOrdered = MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());
		if (MenardOrderRequestType.GSS_Sign_GM.getKey().equals(requestCode)
				|| MenardOrderRequestType.GSS_Sign.getKey().equals(requestCode)) {
			boolean goPGM = isInit && MenardOrderRequestType.GSS_Sign_GM.getKey().equals(requestCode);
			if (goPGM) {
				return MenardOrderItemStatus.PENDING_GM.getValue();
			}
			if (isInit && MenardOrderRequestType.GSS_Sign.getKey().equals(requestCode)) {
				return insertSignOrder(item);
			}
			boolean goInsertSign = isPendingGM || isBackOrdered || isPendingGO;
			if (goInsertSign && MenardItemApproveAction.APPROVED.getKey().equals(action)) {
				return insertSignOrder(item);
			}
			if (isDeclinePM(isPendingGM, action)) {
				return MenardOrderItemStatus.GM_DECLINED.getValue();
			}

			if (isDeclinePGO(isBackOrdered, action)) {
				return MenardOrderItemStatus.GO_DECLINED.getValue();
			}
		}
		if (otherSignTypes.contains(requestCode)) {
			return processOtherSignType(isInit, isPendingGM, isBackOrdered, isPendingGO, action);
		}
		invalidException(item.getFulfillerTypeCode(), item.getRequestType());
		return StringUtils.EMPTY;
	}

	/**
	 * 
	 * @param isInit boolean
	 * @param isPGM boolean
	 * @param isBO boolean
	 * @param isPGO boolean
	 * @param action String 
	 * @return String
	 */
	private String processOtherSignType(boolean isInit, boolean isPGM, boolean isBO, boolean isPGO, String action) {
		if (isInit) {
			return MenardOrderItemStatus.PENDING_GM.getValue();
		}

		if (isApprovePM(isPGM, action)) {
			return MenardOrderItemStatus.PENDING_GO.getValue();
		}
		if (isDeclinePM(isPGM, action)) {
			return MenardOrderItemStatus.GM_DECLINED.getValue();
		}

		if ((isPGO || isBO) && MenardItemApproveAction.APPROVED.getKey().equals(action)) {
			return MenardOrderItemStatus.IN_THE_MAIL.getValue();
		}
		if (isDeclinePGO((isPGO || isBO), action)) {
			return MenardOrderItemStatus.GO_DECLINED.getValue();
		}

		if (isBackorderedPGO(isPGO, action)) {
			return MenardOrderItemStatus.BACKORDERED.getValue();
		}
		invalidStatus(null, action);
		return StringUtils.EMPTY;
	}

	/**
	 *Constructor 
	 */
	public MenardSignShopStrategy() {
		otherSignTypes.add(MenardOrderRequestType.Green_6mm.getKey());
		otherSignTypes.add(MenardOrderRequestType.Green_3mm.getKey());
		otherSignTypes.add(MenardOrderRequestType.White_6mm.getKey());
		otherSignTypes.add(MenardOrderRequestType.White_3mm.getKey());
		otherSignTypes.add(MenardOrderRequestType.Styrene_White_020.getKey());
		otherSignTypes.add(MenardOrderRequestType.Styrene_White_040.getKey());
		otherSignTypes.add(MenardOrderRequestType.Styrene_White_060.getKey());
		otherSignTypes.add(MenardOrderRequestType.Styrene_White_118.getKey());
		otherSignTypes.add(MenardOrderRequestType.White_Steel_10x16.getKey());
		otherSignTypes.add(MenardOrderRequestType.Green_Steel_16x24.getKey());
		otherSignTypes.add(MenardOrderRequestType.Plywood.getKey());
		otherSignTypes.add(MenardOrderRequestType.Flexible.getKey());
		otherSignTypes.add(MenardOrderRequestType.Sign_Shop_Other.getKey());
		registerStrategy(MenardFulfillerType.SIGN_SHOP.getKey(), this);
	}

	/**
	 * Generate a new order to sign database 
	 * @param item MenardOrderItem
	 * @return String
	 */
	private String insertSignOrder(MenardOrderItem item) {
		boolean success = colorSignService.saveSignOrder(item);
		if (success) {
			return MenardOrderItemStatus.REQUEST_SENT.getValue();
		}
		return MenardOrderItemStatus.GO_DECLINED.getValue();
	}
}
