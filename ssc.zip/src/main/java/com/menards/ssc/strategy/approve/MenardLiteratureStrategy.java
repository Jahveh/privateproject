/**
 * 
 */
package com.menards.ssc.strategy.approve;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;

/**
 * <p>MenardLiteratureStrategy</p>
 * <p>Item approve Strategy for Literature </p>
 * <p>
 * Calculate and return the next status according to the current status and
 * the action.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Component
public class MenardLiteratureStrategy extends MenardItemApproveStrategy {

	@Override
	public String nextStage(MenardOrderItem item, String action) {

		if (isValidRequest(item, action) || !MenardOrderRequestType.Literature.getKey().equals(item.getRequestType())) {
			invalidException(item.getFulfillerTypeCode(), item.getRequestType());
		}
		boolean isInit = StringUtils.isEmpty(item.getStatus());
		boolean isPendingGM = isPendingGM(item.getStatus());
		boolean isPendingGO = isPendingGO(item.getStatus());
		if (isInit) {
			return MenardOrderItemStatus.PENDING_GM.getValue();
		}

		if (isApprovePM((isPendingGM || isPendingGO), action)) {
			return processDcitem(item.isDcItem());
		}
		if (isDeclinePM(isPendingGM, action)) {
			return MenardOrderItemStatus.GM_DECLINED.getValue();
		}

		if (isDeclinePGO(isPendingGO, action)) {
			return MenardOrderItemStatus.GO_DECLINED.getValue();
		}
		invalidStatus(item.getStatus(), action);
		return StringUtils.EMPTY;
	}

	/**
	 * 
	 * @param isDcItem Boolean
	 * @return String
	 */
	private String processDcitem(boolean isDcItem) {
		if (isDcItem) {
			return MenardOrderItemStatus.BATCHED_FOR_DC.getValue();
		}
		return MenardOrderItemStatus.BATCHED_FOR_VENDOR.getValue();
	}

	/**
	 * 
	 *Constructor
	 */
	public MenardLiteratureStrategy() {
		registerStrategy(MenardFulfillerType.LITERATURE.getKey(), this);
	}
}
