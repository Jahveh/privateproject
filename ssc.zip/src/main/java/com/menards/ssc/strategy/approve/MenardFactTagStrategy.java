/**
 * 
 */
package com.menards.ssc.strategy.approve;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Component;

import com.menards.ssc.config.PropertiesConfig;
import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.yard.Store;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardItemApproveAction;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.service.email.EmailSenderService;
import com.menards.ssc.service.yard.MenardYardService;

/**
 * <p>MenardFactTagStrategy</p>
 * <p>Item approve Strategy for fact tag</p>
 * <p>
 * Calculate and return the next status according to the current status and
 * the action.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Component
public class MenardFactTagStrategy extends MenardItemApproveStrategy {

	@Resource(name = "menardYardService")
	private MenardYardService yardService;

	@Resource(name = "emailSenderService")
	private EmailSenderService emailSenderService;

	private Set<String> requestTypes = new HashSet<String>();
	
	private static final String FILE_PATH = "com/menards/ssc/strategy/approve/factTagEmail.vm";

	@Override
	public String nextStage(MenardOrderItem item, String action) {

		if (isValidRequest(item, action) || (!requestTypes.contains(item.getRequestType()))) {
			invalidException(item.getFulfillerTypeCode(), item.getRequestType());
		}

		boolean isInit = StringUtils.isEmpty(item.getStatus());
		boolean isPendingGM = isPendingGM(item.getStatus());
		boolean isPendingGO = isPendingGO(item.getStatus());

		if (MenardOrderRequestType.Vendor_Fact_Tag.getKey().equals(item.getRequestType())) {
			if (isInit) {
				return MenardOrderItemStatus.PENDING_GM.getValue();
			}
			boolean goSendEmail = (isPendingGM || isPendingGO)
					&& MenardItemApproveAction.APPROVED.getKey().equals(action);
			if (goSendEmail) {
				if (!sendFactTagEmail(item)) {
					throw new MenardItemApproveStrategyException(item.toString());
				}
				return MenardOrderItemStatus.SENDING_EMAIL.getValue();
			}

			if (isDeclinePM(isPendingGM, action)) {
				return MenardOrderItemStatus.GM_DECLINED.getValue();
			}
		}

		if (isInit) {
			return MenardOrderItemStatus.PENDING_GO.getValue();
		}

		boolean isBackOrdered = MenardOrderItemStatus.BACKORDERED.getValue().equals(item.getStatus());
		boolean goInTheMail = (isPendingGO || isBackOrdered)
				&& MenardItemApproveAction.APPROVED.getKey().equals(action);
		if (goInTheMail) {
			return MenardOrderItemStatus.IN_THE_MAIL.getValue();
		}
		boolean goDeclined = (isPendingGO || isBackOrdered) && MenardItemApproveAction.DECLINED.getKey().equals(action);
		if (goDeclined) {
			return MenardOrderItemStatus.GO_DECLINED.getValue();
		}

		if (isBackorderedPGO(isPendingGO, action)) {
			return MenardOrderItemStatus.BACKORDERED.getValue();
		}
		invalidStatus(item.getStatus(), action);
		return StringUtils.EMPTY;
	}

	/**
	 * 
	 * @param item requestTypes
	 * @return Boolean
	 */
	private boolean sendFactTagEmail(MenardOrderItem item) {
		String debug = PropertiesConfig.getValue("debug");
		String toAddress = StringUtils.EMPTY;
		if (Boolean.parseBoolean(debug)) {
			toAddress = PropertiesConfig.getValue("debugEmail");
		} else {
			toAddress = PropertiesConfig.getValue(String.valueOf(item.getSignId()));
		}

		String emailSubject = PropertiesConfig.getValue("SOS_FT_EMAIL_SUBJECT");
		String fromAddress = PropertiesConfig.getValue("SOS_FT_EMAIL_FROM_ADDRESS");
		String ccAddress = PropertiesConfig.getValue("SOS_FT_EMAIL_CC_ADDRESS");

		String storeId = item.getMenardOrder().getStoreId();
		Store store = yardService.getStore(storeId);

		SimpleMailMessage message = new SimpleMailMessage();
		Map<String, Object> model = new HashMap<String, Object>();

		model.put("storeNumber", storeId);
		model.put("menardsSku", item.getMenardSkuCode());
		model.put("factTagName", item.getProductName());
		model.put("quantity", item.getQuantity());
		model.put("orderItemLineNumber", item.getLineNumber());
		model.put("orderId", item.getMenardOrder().getId());
		model.put("attentionName", "General Manager");

		model.put("storeName", store.getStoreName());
		model.put("storeCity", store.getCity());
		model.put("storeState", store.getState());
		model.put("storeZip", store.getZip());
		model.put("storePhone", store.getPhoneNumber());
		model.put("storeAddress", store.getAddress1());
		
		MenardProduct product = (MenardProduct) item.getProduct();
		model.put("modelNum", product.getModelNum());
		model.put("description", item.getProductLongDesc());	
		model.put("storeEmail", "GeneralManager@menards.com");

		message.setTo(toAddress);
		if (StringUtils.isNotBlank(ccAddress)) {
			message.setCc(ccAddress);
		}
		message.setFrom(fromAddress);
		message.setSubject(emailSubject);
		return emailSenderService.sendEmailWithTemplate(message, FILE_PATH, model);
	}

	/**
	 *Constructor 
	 */
	public MenardFactTagStrategy() {
		requestTypes.add(MenardOrderRequestType.Vendor_Fact_Tag.getKey());
		requestTypes.add(MenardOrderRequestType.BM_Fact_Tag.getKey());
		requestTypes.add(MenardOrderRequestType.Hardware_Fact_Tag.getKey());
		requestTypes.add(MenardOrderRequestType.Electrical_Fact_Tag.getKey());
		requestTypes.add(MenardOrderRequestType.Millwork_Fact_Tag.getKey());
		requestTypes.add(MenardOrderRequestType.Plumbing_Fact_Tag.getKey());
		requestTypes.add(MenardOrderRequestType.Floor_Fact_Tag.getKey());
		requestTypes.add(MenardOrderRequestType.Wall_Fact_Tag.getKey());
		registerStrategy(MenardFulfillerType.FACT_TAG.getKey(), this);
	}
}
