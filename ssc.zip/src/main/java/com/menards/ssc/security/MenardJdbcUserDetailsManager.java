/**
 *
 */
package com.menards.ssc.security;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.JdbcUserDetailsManager;

import com.menards.mymenards.integration.vo.SecureUser;
import com.menards.mymenards.integration.vo.Systems;
import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.enums.MenardFulfillerType;

/**
 * <p>MenardJdbcUserDetailsManager</p>
 * <p>Retrieve user information from both databases</p>
 * <p>
 *
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class MenardJdbcUserDetailsManager extends JdbcUserDetailsManager {

	private static final Log LOG = LogFactory.getLog(MenardJdbcUserDetailsManager.class);

	private MenardSecurityDelegate securityDelegate;

	private static ThreadLocal<String> userNameThreadLocal = new ThreadLocal<String>();
	
	private static final String USER_DEPT_KEY = "AVAILABLE_PRODUCTS";

	@Override
	protected UserDetails createUserDetails(String username, UserDetails userFromUserQuery,
			List<GrantedAuthority> combinedAuthorities) {
		String returnUsername = userFromUserQuery.getUsername();

		if (!isUsernameBasedPrimaryKey()) {
			returnUsername = username;
		}
		SecureUser secureUser = retrieveSecurityUser(userNameThreadLocal.get());
		userNameThreadLocal.set(null);
		
		//Append the department
		String deptId = secureUser.getRightsValue(USER_DEPT_KEY);
		if (StringUtils.isNotBlank(deptId)) {
			LOG.info("current user dept[" + deptId + "]");
			combinedAuthorities.add(new SimpleGrantedAuthority(getRole(StringUtils.trim(deptId))));
		}
	
		//Append the fulfiller type
		String fulfillerRole = secureUser.getRightsValue("FULFILLER_ROLE");
		String type = MenardFulfillerType.getFulfillerTypeByRoleKey(fulfillerRole);
		if (StringUtils.isNotBlank(type)) {
			LOG.info("current user FulfillerType[" + type + "]");
			combinedAuthorities.add(new SimpleGrantedAuthority(getRole(type)));
		}
		
//		if (StringUtils.equals(secureUser.getUserId(), "GUEST")) {		
//			throw new DisabledException("GUEST is forbidden.");
//		}
		
		if (!(secureUser.isYard())) {
			combinedAuthorities.add(new SimpleGrantedAuthority(CommonConstant.GO_USER_ROLE));
		}
		
		//Add a role can access the root path
		combinedAuthorities.add(new SimpleGrantedAuthority(CommonConstant.DEFAULT_USER_ROLE));
		return new MenardUserDetails(returnUsername, userFromUserQuery.getPassword(), userFromUserQuery.isEnabled(),
				true, true, true, combinedAuthorities, secureUser);
	}
	
	/**
	 * Group the full role name 
	 * @param name
	 * @return String
	 */
	private String getRole(String name) {
		return getRolePrefix() + name;
	}

	@Override
	public UserDetails loadUserByUsername(String username) {
		userNameThreadLocal.set(username);
		/*int length = StringUtils.length(username);
		if (length < 5) {
			return super.loadUserByUsername(username);
		}
		String storeId = StringUtils.substring(username, length - 4, length);
		if (!StringUtils.isNumeric(storeId)) {
			return super.loadUserByUsername(username);
		}*/
		//return super.loadUserByUsername(StringUtils.substring(username, 0, length - 4));
		
	    Set<GrantedAuthority> dbAuthsSet = new HashSet<GrantedAuthority>();
        List<GrantedAuthority> dbAuths = new ArrayList<GrantedAuthority>(dbAuthsSet);
        dbAuthsSet.addAll(loadUserAuthorities(username));
        UserDetails detail = new User(username, "A", true, true, true, true, AuthorityUtils.NO_AUTHORITIES);
		return createUserDetails(username, detail, dbAuths);
	}

	@Override
	protected List<GrantedAuthority> loadUserAuthorities(String username) {
		final String rolePrefix = this.getRolePrefix();
		String roleName = rolePrefix + "STORE";
		List<GrantedAuthority> list = new ArrayList<GrantedAuthority>();
		list.add(new SimpleGrantedAuthority(roleName));
		return list;
	}

	/**
	 * Get security User from outside database
	 * @param userName String
	 * @return SecureUserIF
	 */
	private SecureUser retrieveSecurityUser(String userName) {
		SecureUser secureUser = securityDelegate.getUser(userName, Systems.CATALOGS);
		SecureUser user = securityDelegate.getUser(userName, Systems.FORMSREQUEST);
		if (LOG.isDebugEnabled()) {
			LOG.debug(secureUser);
		}
		secureUser.getRoles().addAll(user.getRoles());
		return secureUser;
	}

	public MenardSecurityDelegate getSecurityDelegate() {
		return securityDelegate;
	}

	public void setSecurityDelegate(MenardSecurityDelegate securityDelegate) {
		this.securityDelegate = securityDelegate;
	}
}
