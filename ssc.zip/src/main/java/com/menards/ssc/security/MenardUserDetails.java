package com.menards.ssc.security;

import java.util.Collection;
import java.util.Deque;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import com.menards.mymenards.integration.vo.SecureUser;
import com.menards.ssc.config.PropertiesConfig;
import com.menards.ssc.enums.MenardFulfillerType;

/**
 * <p>MenardUserDetails</p>
 * <p>MenardUserDetails include inform from outside database and ssc database</p>
 * <p>
 *  Extend the broadleaf user concept and get security user involved;
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class MenardUserDetails extends User {

	private static final Log LOG = LogFactory.getLog(MenardUserDetails.class);

	private static final long serialVersionUID = 2646664841249365098L;

	private SecureUser secureUser;
	private String kioskServerIp;
	private String kioskServerPortNumber;

    private Deque<String> requestHistory;

	/**
	 *Constructor 
	 *@param username String
	 *@param password String
	 *@param authorities Collection<? extends GrantedAuthority>
	 */
	public MenardUserDetails(String username, String password, Collection<? extends GrantedAuthority> authorities) {
		super(username, password, authorities);
	}

	/**
	 *Constructor 
	 *@param username String
	 *@param password String
	 *@param enabled boolean
	 *@param accountNonExpired boolean
	 *@param nonExpired boolean
	 *@param accountNonLocked boolean
	 *@param authorities Collection<? extends GrantedAuthority>
	 */
	public MenardUserDetails(String username, String password, boolean enabled, boolean accountNonExpired,
			boolean nonExpired, boolean accountNonLocked, Collection<? extends GrantedAuthority> authorities) {
		super(username, password, enabled, accountNonExpired, nonExpired, accountNonLocked, authorities);
	}

	/**
	 *Constructor 
	 *@param username String
	 *@param password String
	 *@param enabled boolean
	 *@param accountNonExpired boolean
	 *@param credentialsNonExpired boolean
	 *@param accountNonLocked boolean
	 *@param authorities Collection<? extends GrantedAuthority>
	 *@param secureUser secureUser
	 */
	public MenardUserDetails(String username, String password, boolean enabled, boolean accountNonExpired,
			boolean credentialsNonExpired, boolean accountNonLocked,
			Collection<? extends GrantedAuthority> authorities, SecureUser secureUser) {
		super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);

		//kioskServerIp = PropertiesConfig.getValue("kioskServerIp");
		//kioskServerPortNumber = PropertiesConfig.getValue("kioskServerPortNumber");
		this.secureUser = secureUser;
	}

	/**
	 * Retrieve the fulfiller type according to the role information
	 * @return String
	 */
	public String getFulfillerType() {
		String fulfillerRole = secureUser.getRightsValue("FULFILLER_ROLE");
		String type = MenardFulfillerType.getFulfillerTypeByRoleKey(fulfillerRole);
		if (LOG.isDebugEnabled()) {
			LOG.debug("fulfillerRole[" + fulfillerRole + "], type[" + type + "]");
		}
		return type;
	}

	public String getOperationsType() {		
		 return secureUser.getRightsValue("OPERATIONS_TYPE");	
	}

	public String getFactTagRequestType() {		
		return secureUser.getRightsValue("FACTFULLFILLER");
	}

	public String getSelectedDepartment() {
		return secureUser.getDepartmentName();
	}

	/**
	 * is yard
	 * @return boolean boolean
	 */
	public boolean isYard() {
		return secureUser.isYard();
	}

	/**
	 * is go user
	 * @return boolean boolean
	 */
	public boolean isGOUser() {
		return !isYard();
	}

	/**
	 * get store number
	 * @return store number
	 */
	public String getStoreNumber() {
		if (this.isGOUser()) {
			return PropertiesConfig.getDefaultStoreNumber();
		}
		return secureUser.getStoreNumber();
	}

	/**
	 * get user id
	 * @return userid userid
	 */
	public String getUserId() {
		return secureUser.getUserId();
	}

	public String getStorePerformRole() {
		return secureUser.getStorePerformRole();
	}

	/**
	 * get KioskServerIP
	 * @return kioskServerIp 
	 */
	public String getKioskServerIp() {
		return kioskServerIp;
	}

	/**
	 * set KioskServerIP
	 *@param kioskServerIp String 
	 */
	public void setKioskServerIp(String kioskServerIp) {
		this.kioskServerIp = kioskServerIp;
	}

	/**
	 * get kioskServerPortNumber
	 * @return kioskServerPortNumber 
	 */
	public String getKioskServerPortNumber() {
		return kioskServerPortNumber;
	}

	/**
	 * set kioskServerPortNumber
	 *@param kioskServerPortNumber String 
	 */
	public void setKioskServerPortNumber(String kioskServerPortNumber) {
		this.kioskServerPortNumber = kioskServerPortNumber;
	}

    /**
     * Get request history
     * @return
     */
    public Deque<String> getRequestHistory() {
        return requestHistory;
    }

    /**
     * Set request history
     * @param requestHistory
     */
    public void setRequestHistory(Deque<String> requestHistory) {
        this.requestHistory = requestHistory;
    }
}
