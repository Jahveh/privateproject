/**
 * 
 */
package com.menards.ssc.security;

import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * <p>MenardSecurityContextHolder</p>
 * <p>Holder a utility class to get user information from spring security</p>
 * <p> 
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public abstract class MenardSecurityContextHolder {
	
	private static ThreadLocal<MenardUserDetails> userDetailsThreadLocal = new ThreadLocal<MenardUserDetails>();

	/**
	 * Utility method to retrieve the information on user
	 * @return MenardUserDetails
	 */
	public static MenardUserDetails getMenardUserDetails() {
		SecurityContext context = SecurityContextHolder.getContext();
		if (context.getAuthentication().getPrincipal() instanceof MenardUserDetails) {
			return (MenardUserDetails) context.getAuthentication().getPrincipal();
		}
		return userDetailsThreadLocal.get();
	}
	
	/**
	 * @param UserDetails
	 */
	public static void setUserDetailsThreadLocal(MenardUserDetails UserDetails) {
		userDetailsThreadLocal.set(UserDetails);
	}
}
