package com.menards.ssc.security;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.menards.mymenards.integration.dao.SecurityDAO;

/**
 * <p>MenardConcreteMySQLSecurityDAO</p>
 * <p></p>
 * <p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class MenardConcreteMySQLSecurityDAO extends SecurityDAO {

	private DataSource ds;

	@Override
	public Connection getConnection() throws SQLException {
		return ds.getConnection();
	}

	public void setDs(DataSource ds) {
		this.ds = ds;
	}

}
