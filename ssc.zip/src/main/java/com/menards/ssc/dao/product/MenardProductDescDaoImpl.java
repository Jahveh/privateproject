/**
 *
 */
package com.menards.ssc.dao.product;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.catalog.MenardProductDesc;
import com.menards.ssc.domain.catalog.SearchResult;

/**
 * <p>MenardSkuDaoImpl</p>
 * <p>Provide the database access related to search supplies</p>
 * <p>
 *    This search is divided into two steps: one is using full text to find
 *    all the matched sku's id and then retrieve these skus.
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Repository("menardProductDescDao")
public class MenardProductDescDaoImpl implements MenardProductDescDao, CommonConstant {

	public static final Logger LOG = Logger.getLogger(MenardProductDescDao.class);

	@PersistenceContext(unitName = "blPU")
	private EntityManager em;

	@Override
	public SearchResult<MenardProductDesc> findDescPage(Integer page, Integer size, String text,
			Collection<String> skucodes) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardProductDesc> criteria = builder.createQuery(MenardProductDesc.class);

		Root<MenardProductDesc> desc = criteria.from(MenardProductDesc.class);
		Path<MenardProductDesc.MenardProductDescPK> id = desc.get("id");

		criteria.select(desc);
		Predicate finalPredicate = builder.conjunction();

		SearchResult<MenardProductDesc> result = new SearchResult<MenardProductDesc>();
		result.setPage(page);
		result.setPageSize(size);
		if (StringUtils.isBlank(text) || StringUtils.length(text.trim()) < 3) {
			return result;
		}
		Query q = em.createNativeQuery(getFulltextQuerySql(skucodes));
		String searchText = processSearchInput(text);

		if (LOG.isDebugEnabled()) {
			LOG.debug("The final search text is " + searchText);
		}

		q.setParameter(1, searchText);

		@SuppressWarnings("unchecked")
		List<Object[]> list = q.getResultList();
		Predicate idPredicate = builder.disjunction();
		if (CollectionUtils.isEmpty(list)) {
			return result;
		}
		result.setTotalResults(list.size());

		if (CollectionUtils.isEmpty(list)) {
			return result;
		}

		// Take the skuId as a query parameter
		for (Object[] array : list) {
			idPredicate.getExpressions()
					.add(builder.and(builder.equal(id.get("skuId"), array[0]),
							builder.equal(id.get("productId"), array[1])));
		}
		finalPredicate.getExpressions().add(idPredicate);
		finalPredicate.getExpressions().add(builder.and(builder.equal(desc.get("skuType"), "single")));
		criteria.where(finalPredicate);

		criteria.orderBy(Arrays.asList(builder.asc(id.get("skuCode")), builder.asc(desc.get("productDesc")),
				builder.asc(desc.get("skuDesc"))));

		TypedQuery<MenardProductDesc> query = em.createQuery(criteria);
		Integer begin = (page - 1) * size;
		begin = (begin > 0 ? begin : 0);
		query.setFirstResult(begin);
		query.setMaxResults(size);
		result.setResult(query.getResultList());
		return result;
	}

	@Override
	public List<Integer> fulltextSearchSkuCode(String text) {
		Query q = em.createNativeQuery(getFulltextQuerySql(null));
		String searchText = processSearchInput(text);
		if (LOG.isDebugEnabled()) {
			LOG.debug("The final search text is " + searchText);
		}
		q.setParameter(1, searchText);
		@SuppressWarnings("unchecked")
		List<Object[]> list = q.getResultList();
		List<Integer> skuSet = new ArrayList<Integer>();
		for (Object[] array : list) {
			skuSet.add(Integer.parseInt((String) array[2]));
		}
		return skuSet;
	}

	/**
	 * Group the search sql 
	 * @param skucodes Collection<String>
	 * @return String
	 */
	private String getFulltextQuerySql(Collection<String> skucodes) {
		// Select all the skus that include the typed text
		StringBuilder sql = new StringBuilder("SELECT SKU_ID, PRODUCT_ID, SKU_CODE FROM MENARD_DESCRIPTIONS A WHERE"
				+ " MATCH(SKU_CODE, DESCRIPTION1, DESCRIPTION2, PRD_DESCRIPTION, SKU_DESCRIPTION, KEYWORD1,"
				+ " KEYWORD2)AGAINST(? IN BOOLEAN MODE) and SKU_TYPE='single'");

		if (skucodes != null) {
			sql.append(" AND (SKU_CODE ='");
			sql.append(StringUtils.join(skucodes, "' OR SKU_CODE ='"));
			sql.append("')");
		}
		return sql.toString();
	}

	/**
	 * Process the input text
	 * @param text String
	 * @return String
	 */
	private String processSearchInput(String text) {
		String searchText = StringUtils.replace(text, MINUS, SPACE);
		searchText = StringUtils.replace(searchText, PERCENT_SIGN, SPACE);
		searchText = StringUtils.replace(searchText, DOUBLE_QUOTATION_MARKS, "\\\"");
		if (StringUtils.split(searchText).length == 1) {
			return searchText.trim() + ASTERISK;
		}

		return PLUS + StringUtils.join(StringUtils.split(searchText), ASTERISK + SPACE + PLUS) + ASTERISK;
	}

	@Override
	public MenardProductDesc saveMenardProductDesc(MenardProductDesc menardProductDesc) {
		em.persist(menardProductDesc);
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MenardProductDesc> findDescList(Collection<String> keyCol, Collection<String> createdBy) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardProductDesc> criteria = builder.createQuery(MenardProductDesc.class);

		Root<MenardProductDesc> desc = criteria.from(MenardProductDesc.class);

		Predicate idPredicate = builder.disjunction();
		Predicate finalPredicate = builder.conjunction();

		// Apply the sku code constrains
		if (CollectionUtils.isNotEmpty(keyCol)) {
			for (String skucode : keyCol) {
				idPredicate.getExpressions().add(builder.equal(desc.get("id").get("skuCode"), skucode));
			}
			finalPredicate.getExpressions().add(idPredicate);
		}

		Predicate cbPredicate = builder.disjunction();
		if (CollectionUtils.isNotEmpty(createdBy)) {
			for (String str : createdBy) {
				cbPredicate.getExpressions().add(builder.equal(desc.get("createdBy"), str));
			}
			finalPredicate.getExpressions().add(cbPredicate);
		}

		criteria.where(finalPredicate);
		Query query = em.createQuery(criteria);
		return query.getResultList();
	}

	/**
	 *Reset description table opensku status
	 *@param createdBy String
	 *@return int
	 */
	public int resetOpenSkuProductDesc(String createdBy) {
		if (StringUtils.isBlank(createdBy)) {
			return 0;
		}
		String sql = null; // "ALTER TABLE MENARD_DESCRIPTIONS ENGINE = INNODB";
		// em.createNativeQuery(sql);
		sql = "UPDATE MENARD_DESCRIPTIONS SET OPENSKU = -2 WHERE CREATED_BY = ?";
		Query query = em.createNativeQuery(sql);
		query.setParameter(1, createdBy);
		query.executeUpdate();
		sql = "DELETE FROM MENARD_DESCRIPTIONS WHERE CREATED_BY='bm'";
		return em.createNativeQuery(sql).executeUpdate();
	}

	private static final Map<Integer, Integer> OPENSKU_SHIFT = new HashMap<Integer, Integer>();
	static {
		OPENSKU_SHIFT.put(-99, 3);
		OPENSKU_SHIFT.put(-100, 1);
	}

	@Override
	public int postUpdateDescSkuType() {
		String insertSql = "INSERT INTO MENARD_DESCRIPTIONS(SKU_CODE,OPENSKU,SKU_ID,PRODUCT_ID,CATEGORY_ID,"
				+ "DESCRIPTION1,DESCRIPTION2,SKU_DESCRIPTION,PRD_DESCRIPTION) SELECT DISTINCT LEFT (SKU_CODE,";

		String selectSql = " AS OPENSKU,0 AS SKU_ID, 0 AS PRODUCT_ID, 0 AS CATEGORY_ID,DESCRIPTION1, DESCRIPTION2,"
				+ " SKU_DESCRIPTION, PRD_DESCRIPTION FROM MENARD_DESCRIPTIONS WHERE SKU_STATUS = 'Y'"
				+ "AND SKU_CODE like '_______'";
		int count = 0;
		for (Integer openSku : OPENSKU_SHIFT.keySet()) {
			String sql = insertSql + OPENSKU_SHIFT.get(openSku) + ") AS SKU_CODE," + openSku + selectSql;
			count += em.createNativeQuery(sql).executeUpdate();
		}

		// em.createQuery("ALTER TABLE MENARD_DESCRIPTIONS ENGINE = MyISAM").executeUpdate();
		return count;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MenardProductDesc> findSkuProductInfo() {
		String sql = "SELECT * FROM MENARD_DESCRIPTION_V";
		Query query = em.createNativeQuery(sql, MenardProductDesc.class);
		List<MenardProductDesc> list = query.getResultList();
		for (MenardProductDesc menardProductDesc : list) {
			em.detach(menardProductDesc);
		}
		return list;
	}

	@Override
	public SearchResult<MenardProductDesc> findProductDescPage(Integer page, Integer size, String text,
			Collection<String> skucodes) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardProductDesc> criteria = builder.createQuery(MenardProductDesc.class);
		Root<MenardProductDesc> desc = criteria.from(MenardProductDesc.class);

		Predicate finalPredicate = groupCondition(builder, desc, text, skucodes);

		// Get the total records count
		Long count = findDescCount(text, skucodes);

		criteria.where(finalPredicate);
		TypedQuery<MenardProductDesc> query = em.createQuery(criteria);
		SearchResult<MenardProductDesc> result = new SearchResult<MenardProductDesc>();
		Integer begin = (page - 1) * size;
		begin = (begin > 0 ? begin : 0);
		query.setFirstResult(begin);
		query.setMaxResults(size);
		result.setPage(page);
		result.setPageSize(size);
		result.setResult(query.getResultList());
		result.setTotalResults(count.intValue());
		return result;
	}

	@Override
	public List<Integer> findSkuCodesForSkuClass(String text) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<String> criteria = builder.createQuery(String.class);
		Root<MenardProductDesc> desc = criteria.from(MenardProductDesc.class);
		Path<String> skucodePath = desc.get("id").get("skuCode");
		criteria.select(skucodePath);
		Predicate finalPredicate = groupCondition(builder, desc, text, null);

		criteria.where(finalPredicate);
		List<String> skucodeList = em.createQuery(criteria).getResultList();

		List<Integer> list = new ArrayList<Integer>(skucodeList.size());
		for (String code : skucodeList) {
			list.add(Integer.parseInt(code));
		}
		return list;
	}

	/**
	 * Group the condition
	 * @param builder CriteriaBuilder
	 * @param desc Root<MenardProductDesc> 
	 * @param text String
	 * @param skucodes Collection<String>
	 * @return Predicate
	 */
	private Predicate groupCondition(CriteriaBuilder builder, Root<MenardProductDesc> desc, String text,
			Collection<String> skucodes) {
		Path<MenardProductDesc.MenardProductDescPK> id = desc.get("id");
		Predicate finalPredicate = builder.conjunction();
		// The first level sku
		if (StringUtils.isBlank(text)) {
			finalPredicate.getExpressions().add(builder.equal(id.get("opensku"), -100));
		}

		// The second level sku
		if (StringUtils.isNotBlank(text) && StringUtils.length(text) < 3) {
			finalPredicate.getExpressions().add(builder.equal(id.get("opensku"), -99));
			Expression<String> skuCode = id.get("skuCode");
			String underline = text + StringUtils.substring("___", StringUtils.length(text));
			finalPredicate.getExpressions().add(builder.like(skuCode, underline));
		}

		if (StringUtils.isNotBlank(text) && StringUtils.length(text) > 2) {
			Expression<String> skuCodeExp = id.get("skuCode");
			finalPredicate.getExpressions().add(builder.like(skuCodeExp, StringUtils.trimToEmpty(text) + "%"));
			Expression<String> skuType = desc.get("skuType");
			finalPredicate.getExpressions().add(builder.like(skuType, "sing%"));
			if (skucodes != null) {
				Predicate skucodePredicate = builder.disjunction();
				for (String skucode : skucodes) {
					skucodePredicate.getExpressions().add(builder.equal(skuCodeExp, skucode));
				}
				finalPredicate.getExpressions().add(skucodePredicate);
			}
		}
		return finalPredicate;
	}

	/**
	 * Retrieve the total count of product description
	 * @param text String
	 * @param skucodes Collection<String>
	 * @return Long
	 */
	private Long findDescCount(String text, Collection<String> skucodes) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<MenardProductDesc> desc = criteria.from(MenardProductDesc.class);

		Predicate finalPredicate = groupCondition(builder, desc, text, skucodes);

		criteria.select(builder.count(desc));
		criteria.where(finalPredicate);
		return em.createQuery(criteria).getSingleResult();
	}

	@Override
	public void removeMenardProductDesc(MenardProductDesc menardProductDesc) {
		em.remove(menardProductDesc);
	}

	@Override
	public void detachMenardProductDesc(MenardProductDesc menardProductDesc) {
		em.detach(menardProductDesc);
	}
}
