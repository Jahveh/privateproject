package com.menards.ssc.dao.sign;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.sql.DataSource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.constants.OrderItemAttributeKey;
import com.menards.ssc.dao.order.MenardOrderItemDao;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.catalog.SignDTO;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.setremodel.SetRemodelDTO;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.domain.sign.SignHistory;
import com.menards.ssc.domain.sign.SignSaleInfo;
import com.menards.ssc.domain.sign.SignVersion;
import com.menards.ssc.domain.sign.Stock;
import com.menards.ssc.domain.sign.Yard;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.SignSearchType;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

/**
 * <p>
 * MenardSignDaoImpl
 * </p>
 * <p>
 * Process the data access to external sign database
 * </p>
 * <p>
 * Retrieve the sign information from sign base database
 * </p>
 * <p>
 * Copyright (c) 2013
 * </p>
 * <p>
 * Menard Inc.
 * </p>
 *
 * @author leo.yang
 * @version 1.0
 */
@Repository("menardSignDao")
public class MenardSignDaoImpl implements MenardSignDao, CommonConstant {

	public static final Logger LOG = Logger.getLogger(MenardSignDao.class);

	@PersistenceContext(unitName = "signPU")
	private EntityManager em;

	private JdbcTemplate jdbcTemplate;

	@Resource(name = "menardOrderItemDao")
	private MenardOrderItemDao orderItemDao;
	
	@Value("${signbase.media.path}")
	private String signPath;

	private static final String signIdLogStr = "Sign id[";
	
	private static Date DEFAULT_DATE = null;
	
	static {
		try {
			DEFAULT_DATE = (new SimpleDateFormat("yyyy-MM-dd")).parse("1899-12-30");
		} catch (ParseException e) {
			LOG.error(e.getMessage());
		}
	}

	@Override
	public SearchResult<Sign> findSignPage(Integer page, Integer size, String text) {
		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		Integer locationId = null;
		if (userDetails.isYard()) {
			locationId = Integer.valueOf(userDetails.getStoreNumber());
		}
		return signPage(page, size, text, false, locationId);
	}

	/**
	 * Find all the valid sign id whose quantity is greater than 0; and then
	 * pass all these sign id to query method to retrieve only one page of sign
	 *
	 * @param param	String
	 * @param yardnum int
	 * @param isSaleSign boolean
	 * @return Map<Integer, Integer>
	 */
	private Map<Integer, Integer> validSign(String param, Integer yardnum, boolean isSaleSign) {
		return validSign(param, null, null, yardnum, isSaleSign);
	}

	@Override
	public int findSignTotalCount(String param, Integer yardnum, boolean isSaleSign) {
		return validSign(param, null, null, yardnum, isSaleSign).size();
	}

	/**
	 * Find all the signs that meet the constrains on sign
	 * @param signName String
	 * @param versionId Integer
	 * @param department Integer
	 * @param yardnum Integer
	 * @param isSaleSign boolean
	 * @return Map<Integer, Integer>
	 */
	@SuppressWarnings(UNCHECKED)
	private Map<Integer, Integer> validSign(String signName, Integer versionId, Integer department, Integer yardnum,
			boolean isSaleSign) {

		Query query = em.createNativeQuery(getQuery2WithDept(signName, versionId, department, yardnum, isSaleSign));

		List<Object[]> objectArray = query.getResultList();
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();

		for (Object[] object : objectArray) {
			if (LOG.isDebugEnabled()) {
				LOG.debug(signIdLogStr + object[1] + "],quantity[" + ((BigDecimal) object[0]).intValue() + "]");
			}
			Integer signId = (Integer) object[1];
			if (map.containsKey(signId)) {
				int quantity = map.get(signId) + ((BigDecimal) object[0]).intValue();
				map.put(signId, quantity);
				continue;
			}
			map.put((Integer) object[1], ((BigDecimal) object[0]).intValue());
		}

		MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
		if (userDetails.isGOUser() && (!isSaleSign)) {
			Set<Integer> key = new HashSet<Integer>();
			key.addAll(map.keySet());
			for (Integer signId : key) {
				/*int quantity = map.get(signId) + 1;
				if (quantity > 0) {
					map.put(signId, quantity);
				} else {
					map.remove(signId);
				}*/
				map.put(signId, 1);
			}
			return map;
		}

		query = em.createNativeQuery(getSignsQuery1WithDept(signName, versionId, department, yardnum, isSaleSign));

		objectArray = query.getResultList();
		for (Object[] object : objectArray) {
			int signId = (Integer) object[1];
			int quantity = ((BigDecimal) object[0]).intValue();
			if (LOG.isDebugEnabled()) {
				LOG.debug("signId[" + signId + "], quantity[" + quantity + "]");
			}
			if (quantity <= 0) {
				continue;
			}
			if (!map.containsKey(signId)) {
				map.put(signId, quantity);
				continue;
			}
			quantity = quantity + map.get(signId);
			if (quantity > 0) {
				map.put(signId, quantity);
				continue;
			}
			map.remove(signId);
		}
		return map;
	}

	/**
	 * Retrieve a page of sign according to criteria
	 * @param locationId int
	 * @param page int
	 * @param size int
	 * @param text String
	 * @param signList Collection<Integer>
	 * @return Collection<Integer>
	 */
	private SearchResult<SignVersion> getSignPage(Integer locationId, int page, int size, String text,
			Collection<Integer> signList) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<SignVersion> criteria = builder.createQuery(SignVersion.class);

		Root<SignVersion> signVersion = criteria.from(SignVersion.class);
		Join<SignVersion, Stock> stock = signVersion.join("stock", JoinType.LEFT);
		//Path<Stock> stock = signVersion.get("stock");
		//signVersion.fetch("stock");
		criteria.select(signVersion);

		Predicate finalPredicate = builder.conjunction();
		SearchResult<SignVersion> result = new SearchResult<SignVersion>();
		result.setPage(page);
		result.setPageSize(size);
		if (StringUtils.isBlank(text) || StringUtils.length(text.trim()) < 3) {
			return result;
		}		
		Integer begin = (page - 1) * size;
		begin = begin > 0 ? begin : 0;		
		if (signList.size() > 2000) {
			List<SignVersion> list = new ArrayList<SignVersion>(signList.size());
			Set<Integer> set = new HashSet<Integer>();
			for (Integer signId : signList) {
				set.add(signId);				
				if (set.size() > 2000) {
					list.addAll(getSignPage(set));
					set.clear();
				}
			}
			if (set.size() > 0) {
				list.addAll(getSignPage(set));
			}	
			int end = begin + size;				
			if (end > list.size()) {
				end = list.size(); 
			}
			Collections.sort(list);
			result.setResult(list.subList(begin, end));
			return result;
		}
		Predicate predicate = builder.disjunction();	
		for (Integer signId : signList) {
			predicate.getExpressions().add(builder.equal(signVersion.get("signId"), signId));
		}
		finalPredicate.getExpressions().add(predicate);
		
		// Make sure the storePlanning is not equal to 0
		finalPredicate.getExpressions().add(
				builder.or(builder.notEqual(stock.get("storePlan"), Integer.valueOf(0)),
						builder.notEqual(signVersion.get("flyerpoint"), Integer.valueOf(0))));

		// Add predicate for start date and stop date
		finalPredicate.getExpressions().add(
				builder.or(getDatePredicate(builder, signVersion, stock, true),
						getDatePredicate(builder, signVersion, stock, false)));
		criteria.orderBy(getOrders(builder, signVersion));

		if (LOG.isDebugEnabled()) {
			LOG.debug("[" + locationId + "][" + text + "]");
		}

		criteria.where(finalPredicate);
		TypedQuery<SignVersion> query = em.createQuery(criteria);
		
		query.setFirstResult(begin);
		query.setMaxResults(size);
		result.setResult(query.getResultList());
		return result;
	}
	
	/**
	 * Retrieve a page of sign according to criteria
	 * @param locationId int
	 * @param page int
	 * @param size int
	 * @param text String
	 * @param signList Collection<Integer>
	 * @return Collection<Integer>
	 */
	private List<SignVersion> getSignPage(Collection<Integer> signList) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<SignVersion> criteria = builder.createQuery(SignVersion.class);
		Root<SignVersion> signVersion = criteria.from(SignVersion.class);
		Join<SignVersion, Stock> stock = signVersion.join("stock", JoinType.LEFT);		
		criteria.select(signVersion);
		Predicate finalPredicate = builder.conjunction();		
		Predicate predicate = builder.disjunction();		
		for (Integer signId : signList) {
			predicate.getExpressions().add(builder.equal(signVersion.get("signId"), signId));
		}
		finalPredicate.getExpressions().add(predicate);
		
		// Make sure the storePlanning is not equal to 0
		finalPredicate.getExpressions().add(
				builder.or(builder.notEqual(stock.get("storePlan"), Integer.valueOf(0)),
						builder.notEqual(signVersion.get("flyerpoint"), Integer.valueOf(0))));

		//Add predicate for start date and stop date
		finalPredicate.getExpressions().add(
				builder.or(getDatePredicate(builder, signVersion, stock, true),
						getDatePredicate(builder, signVersion, stock, false)));	
		criteria.where(finalPredicate);
		TypedQuery<SignVersion> query = em.createQuery(criteria);
		return query.getResultList();
	}
	
	/**
	 * Build a date constraint on stock
	 * @param builder CriteriaBuilder
	 * @param signVersion Root<SignVersion>
	 * @param stock Path<Stock>
	 * @param isStore boolean
	 * @return Predicate
	 */
	private Predicate getDatePredicate(CriteriaBuilder builder, Root<SignVersion> signVersion, Path<Stock> stock,
			boolean isStore) {
	
		Path<Date> startDate = null;
		Path<Date> stopDate = null;
		if (isStore) {
			startDate = signVersion.get("storeStartDate");
			stopDate = signVersion.get("storeStopDate");
		} else {
			startDate = signVersion.get("startDate");
			stopDate = signVersion.get("stopDate");
		}	
		Expression<Date> date = builder.literal(new Date());
		Predicate start = builder.or(builder.isNull(startDate), builder.greaterThanOrEqualTo(startDate, DEFAULT_DATE), builder.greaterThanOrEqualTo(date, startDate));
		Predicate stop = builder.or(builder.isNull(stopDate), builder.greaterThanOrEqualTo(stopDate, DEFAULT_DATE), builder.greaterThanOrEqualTo(stopDate, date));
		Path<Integer> printable = stock.get("storePrintable");
		Path<Integer> laminate = signVersion.get("laminate");
		if (isStore) {
			return builder.and(builder.equal(printable, -1), builder.equal(laminate, 0), start, stop);
		}
		return builder.and(builder.or(builder.notEqual(printable, -1), builder.notEqual(laminate, 0)), start, stop);
	}

	/**
	 * Group the orders for sign search
	 *
	 * @param builder CriteriaBuilder
	 * @param signVersion Root<SignVersion>
	 * @return List<Order>
	 */
	private List<Order> getOrders(CriteriaBuilder builder, Root<SignVersion> signVersion) {
		List<Order> list = new ArrayList<Order>();
		list.add(builder.desc(signVersion.get("laminate")));
		list.add(builder.desc(signVersion.get("stock").get("storePrintable")));
		list.add(builder.desc(signVersion.get("desc")));
		return list;
	}

	/**
	 *
	 * @param signList List<Sign>
	 * @param yardNumber Integer
	 */
	private void setYardAndColorForSignList(List<Sign> signList, Integer yardNumber) {
		if (CollectionUtils.isEmpty(signList)) {
			return;
		}
		for (Sign sign : signList) {
			if (LOG.isDebugEnabled()) {
				LOG.debug(signIdLogStr + sign.getSignID() + "], stock desc[" + sign.getStockDescription()
						+ "], whiteSign[" + sign.getWhiteSign() + "]");
			}
			if (!StringUtils.containsIgnoreCase(sign.getStockDescription(), "yellow")) {
				sign.setWhiteSign(Sign.NOT_WHITE);
			}
			if (sign.getWhiteSign() == Sign.WHITE_BY_YARD) {
				sign.setStockDescription(replaceFirst(sign.getStockDescription(), "yellow", "white"));
			}
			if (sign.getWhiteSign() == Sign.WHITE_BY_DEPT) {
				if (!isYardWhite(yardNumber, sign.getDept())) {
					sign.setWhiteSign(Sign.NOT_WHITE);
				}
			}
		}
	}

	/**
	 * Retrieve one yard through yardid
	 * @param yardId Integer
	 * @return Yard
	 */
	private Yard getYard(Integer yardId) {
		return em.find(Yard.class, yardId);
	}

	/**
	 *
	 * @param yard int
	 * @param departmentNumber int
	 * @return boolean
	 */
	private boolean isYardWhite(int yard, int departmentNumber) {
		Query query = em.createNativeQuery(" SELECT white_signs FROM yards WHERE yard_no=" + yard);
		int whiteFlag = (Integer) query.getSingleResult();
		if (whiteFlag == 1) {
			return true;
		}
		if (whiteFlag == 2 && departmentNumber > 0) {
			int flag = (Integer) em.createNativeQuery(
					" SELECT white_flag FROM white_depts WHERE store = '" + yard + "' AND dept=" + departmentNumber)
					.getSingleResult();
			return flag != 0;
		}
		return false;
	}

	/**
	 *
	 * @param haystack String
	 * @param needle String
	 * @param replacement  String
	 * @return String
	 */
	public static String replaceFirst(String haystack, final String needle, final String replacement) {
		int index = haystack.indexOf(needle.toLowerCase());
		if (index < 0) {
			index = haystack.indexOf(needle.toUpperCase());
		}
		if (index < 0) {
			index = haystack.indexOf(("" + needle.charAt(0)).toUpperCase() + needle.substring(1).toLowerCase());
		}
		if (index < 0) {
			return haystack;
		} else {
			return haystack.substring(0, index) + replacement
					+ haystack.substring(index + needle.length(), haystack.length());
		}
	}

	/**
	 *
	 * @param page Integer
	 * @param size Integer
	 * @param text String
	 * @param isSaleSign boolean
	 * @param yardNum Integer
	 * @return SearchResult<Sign>
	 */
	private SearchResult<Sign> signPage(Integer page, Integer size, String text, boolean isSaleSign, Integer yardNum) {

		Map<Integer, Integer> map = validSign(text, yardNum, isSaleSign);
		SearchResult<SignVersion> result = getSignPage(yardNum, page, size, StringUtils.upperCase(text), map.keySet());

		SearchResult<Sign> signResult = new SearchResult<Sign>(map.size(), page, size);
		int whiteSigns = 0;

		if (yardNum != null) {
			Yard yard = getYard(yardNum);
			if (yard != null) {
				whiteSigns = yard.getWhiteSigns();
			}
		}

		for (SignVersion sv : result.getResult()) {
			if (LOG.isDebugEnabled()) {
				LOG.debug(signIdLogStr + sv.getSignId() + "], sign name[" + sv.getSignname() + "]");
			}
			signResult.addElement(new Sign(sv, map.get(sv.getSignId()), whiteSigns, yardNum, signPath));
		}

		setYardAndColorForSignList(signResult.getResult(), yardNum);
		return signResult;

	}

	@Override
	public SearchResult<Sign> findSaleSignPage(Integer page, Integer size, String text, Integer yardNum) {
		return signPage(page, size, text, true, yardNum);
	}

	/**
	 *
	 * @param signName String
	 * @param versionId Integer
	 * @param department Integer
	 * @param yardnum Integer
	 * @param isSaleSign boolean
	 * @return String
	 */
	private String getSignsQuery1WithDept(String signName, Integer versionId, Integer department, Integer yardnum,
			boolean isSaleSign) {
		String result = "SELECT sum(qty) as qty, sign_versions.sign_id  FROM sign_dist, yard_sets, sign_versions inner join stocks on stocks.stock_id=sign_versions.stock_id"
				+ " where yard_sets.group_id = sign_dist.yard_grp and sign_versions.sign_id = sign_dist.sign_id"
				+ " and yard_sets.dept_id = sign_versions.dept and yard_id=" + yardnum
				+ " and sign_versions.disabled = 0 and (sign_versions.signname "
				+ groupSignCondition(signName, versionId, department, isSaleSign)
				+ getDateConstraint()
				+ " group by sign_id";
		return result;
	}
	
	/**
	 * Group the valid date and some other condition or constrains
	 * @return String
	 */
	private String getDateConstraint(){		
	 return  " and (stocks.store_plan<>0 or sign_versions.flyerpoint<>0)" 
			 + " and (stocks.store_printable=-1 and sign_versions.laminate=0 and (sign_versions.store_start_date is null "
			 + " or sign_versions.store_start_date='1899-12-30' or CURRENT>sign_versions.store_start_date) "
			 + " and (sign_versions.store_stop_date is null or sign_versions.store_stop_date='1899-12-30'"
			 + " or sign_versions.store_stop_date>=CURRENT)" 
			 + " or (stocks.store_printable<>-1 or sign_versions.laminate<>0)and (sign_versions.start_date is null"
			 + " or sign_versions.start_date='1899-12-30' or CURRENT>sign_versions.start_date) "
			 + " and (sign_versions.stop_date is null or sign_versions.stop_date='1899-12-30'"
			 + " or sign_versions.stop_date>=CURRENT))";
	}

	/**
	 *
	 * @param signName String
	 * @param versionId Integer
	 * @param department Integer
	 * @param isSaleSign boolean
	 * @return String
	 */
	private String groupSignCondition(String signName, Integer versionId, Integer department, boolean isSaleSign) {
		String tmpSignName = signName;
		String flyerpoint = isSaleSign ? "sign_versions.flyerpoint >= 4" : "sign_versions.flyerpoint != 4";
		boolean containMinus = (tmpSignName.length() > 7 && tmpSignName.charAt(3) == '-');
		if (containMinus) {
			tmpSignName = tmpSignName.substring(0, 3) + tmpSignName.substring(4, tmpSignName.length());
		}

		boolean numberAndSale = StringUtils.isNumeric(signName) && isSaleSign;
		if (numberAndSale) {
			return " = '" + signName + "' or exists (SELECT sign_id FROM sign_skus WHERE sign_skus.sku=" + signName
					+ " and sign_skus.sign_id = sign_versions.sign_id)) and " + flyerpoint;
		}

		boolean numberAndSeven = StringUtils.isNumeric(tmpSignName) && (StringUtils.length(tmpSignName) == 7);
		if (numberAndSeven) {
			return " = '" + tmpSignName + "' or exists (SELECT sign_id FROM sign_skus WHERE sign_skus.sku="
					+ tmpSignName + " and sign_skus.sign_id = sign_versions.sign_id)) and " + flyerpoint;
		}

		if (StringUtils.isNumeric(signName)) {			
			if (isSaleSign) {
				return " = '" + signName + "') and " + flyerpoint;
			}
			return " like '" + signName + "%' or sign_versions.signname like '%" + signName
					+ "' or sign_versions.sign_id BETWEEN " + (signName + "0000").substring(0, 7) + " AND "
					+ (signName + "9999").substring(0, 7) + ") and " + flyerpoint;
		}
		boolean verAndDep = (versionId != null && department != null);
		if (verAndDep) {
			return " = '" + signName + "') AND dept = '" + department + "' " + "AND ver_id = '" + versionId + "'";
		}
		
		if (isSaleSign) {
			return " like '" + signName + "') and " + flyerpoint;	
		}

		return " like '" + signName + "%' or sign_versions.signname like '%" + signName + "') and " + flyerpoint;
	}

	/**
	 *
	 * @param signName String
	 * @param versionId Integer
	 * @param department Integer
	 * @param yardnum Integer
	 * @param isSaleSign boolean
	 * @return String
	 */
	private String getQuery2WithDept(String signName, Integer versionId, Integer department, Integer yardnum,
			boolean isSaleSign) {
		String result = "SELECT sum(sign_dist.qty) as qty, sign_dist.sign_id from  sign_dist, sign_versions inner join stocks on stocks.stock_id=sign_versions.stock_id"
				+ " where sign_versions.sign_id = sign_dist.sign_id "
				+ (yardnum == null && !isSaleSign ? StringUtils.EMPTY : " and yard_grp =" + yardnum)
				+ " and sign_versions.disabled = 0 " + " and (sign_versions.signname "
				+ groupSignCondition(signName, versionId, department, isSaleSign)
				+ getDateConstraint()
				+ " group by yard_grp,sign_id";
		return result;
	}

	@Override
	public List<SignSaleInfo> getSaleSigns(int signId, int yard) {
		String sql = "{call GetSalesPerVersionId(" + signId + "," + yard + ")}";
		SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql);
		return transform2SignSaleInfo(rowSet);
	}

	/**
	 * 
	 * @param rowSet SqlRowSet
	 * @return List<SignSaleInfo>
	 */
	private List<SignSaleInfo> transform2SignSaleInfo(SqlRowSet rowSet) {
		List<SignSaleInfo> list = new ArrayList<SignSaleInfo>();
		while (rowSet.next()) {
			list.add(new SignSaleInfo(rowSet.getInt(1), rowSet.getString(2), rowSet.getString(3), rowSet.getString(6),
					rowSet.getString(7)));
		}
		return list;
	}

	/**
	 *
	 * @param signId int
	 * @return Sign
	 */
	public Sign getSign(int signId) {
		String sql = "WHERE sd.sku = '" + signId + "' ";
		sql = getPrePrintedFactTagQuery(sql);

		Query query = em.createNativeQuery(sql);
		Object[] obj;
		try {
			obj = (Object[]) query.getSingleResult();
		} catch (javax.persistence.NoResultException e) {
			return null;
		}
		return mapSku2Sign(obj);
	}

	/**
	 * getPrePrintedFactTags Gets a list of preprinted fact tags that match the
	 * specified sign
	 *
	 * @param signName - name of sign (menards sku)
	 * @return List - list of signs
	 */
	@Override
	@SuppressWarnings(UNCHECKED)
	public List<Sign> getPrePrintedFactTags(String signName, int limit, int offset) {
		List<Sign> results = new ArrayList<Sign>();
		String tempSignName = StringUtils.remove(signName, '-');

		if (StringUtils.isEmpty(tempSignName) || (!StringUtils.isNumeric(tempSignName))
				|| StringUtils.length(tempSignName) != 7) {
			return results;
		}

		String whereParam = " where sd.sku = " + signName + CommonConstant.SPACE;
		Query query = em.createNativeQuery(getPrePrintedFactTagQuery(whereParam, limit, offset));
		List<Object[]> objectArray = query.getResultList();

		for (Object[] objects : objectArray) {
			results.add(mapSku2Sign(objects));
		}
		return results;
	}

	/**
	 *
	 * @param rs Object[]
	 * @return Sign
	 */
	private Sign mapSku2Sign(Object[] rs) {
		Sign vendorFactTag = new Sign();
		vendorFactTag.setSignName(String.valueOf((Integer) rs[0]));
		vendorFactTag.setSignID((Integer) rs[0]);
		vendorFactTag.setDept((Integer) rs[4]);
		vendorFactTag.setVersionDescription(StringUtils.trimToEmpty((String) rs[1]));
		vendorFactTag.setPrintAt(Sign.PRINT_AT_SPR);

		vendorFactTag.setSkuman(true);
		vendorFactTag.setOriginSystem("/Products/UC/sos/Skuman");

		// Default image for fact tag.
		vendorFactTag.setPreviewPath("img/no-product-available.jpg");
		
		vendorFactTag.setOrderableQuantity(1);
		int factTagType = (Short) rs[3];
		vendorFactTag.setFactTagType(factTagType);
		if (factTagType == Sign.VENDOR_FACT_TAG || factTagType == Sign.MENARDS_FACT_TAG) {
			vendorFactTag.setStockDescription("Fact Tag");
		} else if (factTagType == Sign.VENDOR_POD || factTagType == Sign.MENARDS_POD) {
			vendorFactTag.setStockDescription("pod label");
		}
		// Just in case somebody changes the fact_tag parameters in
		// getPrePrintedFactTagQuery()
		// and forgets to update this
		else {
			vendorFactTag.setStockDescription(StringUtils.EMPTY);
		}

		return vendorFactTag;

	}

	/**
	 * getPrePrintedFactTagsByKey Gets the list of preprinted fact tags in the
	 * key array
	 *
	 * @param keys
	 *            - array of sign skus
	 * @return - list of signs
	 */
	@SuppressWarnings(UNCHECKED)
	public List<Sign> getPrePrintedFactTagsByKey(int[] keys) {
		List<Sign> results = new ArrayList<Sign>();
		StringBuilder sb = new StringBuilder(" where sku in (");
		for (int i = 0; i < keys.length; i++) {
			sb.append(" " + keys[i] + CommonConstant.COMMA);

		}
		// Remove final comma
		String whereParam = sb.toString();
		whereParam = whereParam.substring(0, whereParam.length() - 1);
		whereParam += ") ";
		Query query = em.createNativeQuery(getPrePrintedFactTagQuery(whereParam));
		List<Object[]> objectArray = query.getResultList();

		for (Object[] objects : objectArray) {
			results.add(mapSku2Sign(objects));
		}
		if (results.size() > 0 && results.get(0) != null) {
			return results;
		} else {
			return new ArrayList<Sign>();
		}
	}

	/**
	 * getPrePrintedFactTagQuery Returns a preprinted fact tag (Menards and
	 * Vendor fact tags)query template Fact tag definitions, 0:None, 1:Menards
	 * FT, 2:Vendor FT, 3:Menards POD (faucet pod), 4:Vendor POD Merch Manager
	 * IDs, 1:BM , 2:HW, 3:EL, 4:ML 5:WC, 6:PL, 7:FC, 502: Grocery and Pet Note:
	 * POD labels are now found under permanent signs and have been excluded
	 * from this query
	 *
	 * @param whereParam String fact tag sku (partial or complete)
	 * @return String
	 */
	private static String getPrePrintedFactTagQuery(String whereParam) {
		return "select sd.sku, sd.description1, sd.description2, " + "sd.fact_tag, f.merch_manager_id "
				+ "from skuman_db\\:descrip sd, skuman_db\\:family f, "
				+ "skuman_db\\:department d, skuman_db\\:item_category c, " + "skuman_db\\:item_subcategory sc "
				+ whereParam + "and f.family_id = d.family_id and d.department_id = c.department_id "
				+ "and c.item_category_id = sc.item_category_id " + "and sc.item_subcategory_id = sd.subcat_id and "
				+ "sd.fact_tag in (1,2)";
	}

	private static String getPrePrintedFactTagQuery(String whereParam, int limit, int offset) {
		return "select " + " SKIP " + offset + " FIRST " + limit + " sd.sku, sd.description1, sd.description2, "
				+ "sd.fact_tag, f.merch_manager_id " + "from skuman_db\\:descrip sd, skuman_db\\:family f, "
				+ "skuman_db\\:department d, skuman_db\\:item_category c, " + "skuman_db\\:item_subcategory sc "
				+ whereParam + "and f.family_id = d.family_id and d.department_id = c.department_id "
				+ "and c.item_category_id = sc.item_category_id " + "and sc.item_subcategory_id = sd.subcat_id and "
				+ "sd.fact_tag in (1,2)";
	}

	@Override
	public Sign findSign(String signName, Integer versionId, Integer department, Integer yardnum) {
		return findSign(signName, versionId, department, yardnum, false);
	}
	
	public Sign findSign(String signName, Integer versionId, Integer department, Integer yardnum, boolean isSaleSign) {

		Map<Integer, Integer> map = validSign(signName, versionId, department, yardnum, false);
		SearchResult<SignVersion> result = getSignPage(0, 1, 10, StringUtils.upperCase(signName), map.keySet());

		if (CollectionUtils.isEmpty(result.getResult())) {
			return null;
		}
		SignVersion sv = result.getResult().get(0);
		if (sv.getPromonbr() == null) {
			sv.setPromonbr(0);
		}
		Sign sign = new Sign(sv, map.get(sv.getSignId()), 0, 0, signPath);

		if (LOG.isDebugEnabled()) {
			LOG.debug(signIdLogStr + sv.getSignId() + "], sign name[" + sv.getSignname() + "]");
		}
		return sign;
	}
	
	@Override
	public Sign findSaleSign(String signName, Integer versionId, Integer department, Integer yardnum) {
		return findSign(signName, versionId, department, yardnum, true);
	}

	@Override
	public SetRemodelDTO getSetRemodelByStoreId(String storeId) {
		String sql = "SELECT remodel_start, remodel_end from skuman_db@skuman_on\\:yardship where yard = :storeId";
		Query query = this.em.createNativeQuery(sql);
		query.setParameter("storeId", storeId);
		Object[] objs = (Object[]) query.getSingleResult();
		SetRemodelDTO remodel = new SetRemodelDTO();
		if (objs[0] != null) {
			remodel.setStartDate((Date) objs[0]);
		}
		if (objs[1] != null) {
			remodel.setEndDate((Date) objs[1]);
		}
		remodel.setStoreId(storeId);
		return remodel;
	}

	@Override
	@Transactional("signTransactionManager")
	public int updateRemodelDate(SetRemodelDTO remodel) {
		LOG.info("update skuman_db@skuman_on:yardship, remodel_start:" + remodel.getStartDate() + ";remodel_end:"
				+ remodel.getEndDate() + ";yard:" + remodel.getStoreId());
		String sql = "UPDATE skuman_db@skuman_on\\:yardship SET remodel_start = :startDate, remodel_end = :endDate WHERE yard = :storeId ";
		Query query = this.em.createNativeQuery(sql);
		query.setParameter("startDate", remodel.getStartDate());
		query.setParameter("endDate", remodel.getEndDate());
		query.setParameter("storeId", remodel.getStoreId());
		return query.executeUpdate();
	}

    @Override
    public SignDTO findSign(Integer signVersionId, Integer yard, SignSearchType type) {
        return this.findSign(signVersionId, yard, type, 0, null);
    }

	@Override
	public SignDTO findSign(Integer signVersionId, Integer yard, SignSearchType type, int promoNbr, String itemType) {
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		String locationId = user.getStoreNumber();
		SignDTO sign = new SignDTO();
		sign.setType(itemType);
		SignVersion signVersion = em.find(SignVersion.class, signVersionId);

		if (signVersion == null) {
			LOG.error("Can't find sign, signId -> " + signVersionId + ", User -> " + user.getUserId());
			return null;
		}

		Stock stock = signVersion.getStock();
		sign.setSignVersion(signVersion);
		sign.setStock(stock);

		sign.setIsColorSignBase(false);

		int printAt;
		String printLocation = "";
		int storePrintable = stock.getStorePrintable();
		int laminate = signVersion.getLaminate();
		if (storePrintable == -1 && laminate == 0) {
			printAt = Sign.PRINT_AT_STORE;
		} else {
			printAt = Sign.PRINT_AT_SPR;
			printLocation = "1";
		}
		sign.setPrintAt(printAt);
		sign.setPrintLocation(printLocation);

		String signName = "";
		List<SignHistory> signHistoryList = new ArrayList<SignHistory>();

		Integer yardNum = yard;
		if (SignSearchType.Detail.equals(type)) {
			//Sign factTagTypeSign = this.getSign(signVersion.getSignId());
			//sign.setFactTagType(factTagTypeSign.getFactTagType());

			
			if (user.isGOUser()) {
				yardNum = null;
				sign.setYardList(this.getYardList(String.valueOf(signVersionId)));
			} else {
                if (printAt == 1) {
                    signName = signVersion.getSignname();
                    signHistoryList = getSignHistory(signName, Integer.valueOf(locationId), String.valueOf(stock.getStockId()));
                } else {
                    signHistoryList = getSignHistory(sign.getSignId(), locationId, OrderItemAttributeKey.SIGN_TYPE_SIGN);
                }
			}
			
			int processingCount = this.getProcessingCount(sign, signHistoryList);
			sign.setProcessingCount(processingCount);
		}
		Sign qtySign = null;
		if (promoNbr > 0) {
			qtySign = findSaleSign(signVersion.getSignname(), signVersion.getVersionId(), signVersion.getDept(), yardNum);
		} else {
			qtySign = findSign(signVersion.getSignname(), signVersion.getVersionId(), signVersion.getDept(), yardNum);
		}

		int orderableQuantity = 0;
		if (qtySign != null) {
			orderableQuantity = qtySign.getOrderableQuantity();
		}
		sign.setOrderableQuantity(orderableQuantity);

		sign.setHistories(signHistoryList);
		
		if (promoNbr > 0) {		
			List<SignSaleInfo> saleSigns = getSaleSigns(signVersionId, Integer.parseInt(user.getStoreNumber()));
			if (CollectionUtils.isNotEmpty(saleSigns)) {
				String promoNbrStr = String.valueOf(promoNbr);
	            // to display correct description, iterate to find the correct info by promoNbr which is passed from search result page	           
                for (SignSaleInfo info : saleSigns) {
                    if (StringUtils.equals(promoNbrStr, info.getPromoNbr())) {
                        sign.setSaleSign(info);
                    }
                }
			}
		}
		return sign;
	}

	/**
	 * get yard list
	 * @param signId sign Id
	 * @return List<String> yard list
	 */
	public List<String> getYardList(String signId) {
		List<String> tempResults = new ArrayList<String>();
		String sql = "select * from (SELECT y.yard_no, NVL((" + "	SELECT SUM(sd.qty) "
				+ "	FROM sign_versions AS s, sign_dist AS sd, yard_sets AS ys " + "	WHERE sd.sign_id = s.sign_id "
				+ "	AND s.sign_id = '" + signId + "' " + "	AND ys.group_id = sd.yard_grp "
				+ "	AND ys.dept_id = s.dept " + "	AND ys.yard_id = y.yard_no" + "	AND s.disabled = 0 " + "),0) "
				+ "+ NVL((" + "	SELECT SUM(sd.qty) " + "	FROM sign_versions AS s, stocks, sign_dist AS sd  "
				+ "	WHERE stocks.stock_id = s.stock_id " + "	AND sd.sign_id = s.sign_id  " + "	AND s.sign_id = '"
				+ signId + "' " + "	AND sd.yard_grp =y.yard_no" + "	AND s.disabled = 0 " + "),0) AS qty_count "
				+ "FROM yards AS y " + "ORDER BY y.yard_no) where qty_count > 0";
		Query query = em.createNativeQuery(sql);
		@SuppressWarnings("unchecked")
		List<Object[]> lst = query.getResultList();
		for (Object[] objs : lst) {
			tempResults.add(objs[0].toString());
		}

		return tempResults;
	}

	/**
	 * get processing count
	 * @param sign sign
	 * @param signHistoryList List<SignHistory>
	 * @return count count
	 */
	public int getProcessingCount(SignDTO sign, List<SignHistory> signHistoryList) {
		int processingCount = 0;
		int leadTime = 14;

		if (sign.getStock().getStorePlan() == -1 || sign.getStock().getStorePlan() == 1) {
			leadTime = 21;
		}

		for (SignHistory signHistory : signHistoryList) {
			Calendar limit = Calendar.getInstance();
			limit.add(Calendar.DAY_OF_YEAR, -leadTime);
			String[] datePieces = signHistory.getProcessDate().split(" ");
			datePieces = datePieces[0].split("/");
			Calendar orderDate = Calendar.getInstance();
			orderDate.set(Integer.valueOf(datePieces[2]), Integer.valueOf(datePieces[0]) - 1, Integer.valueOf(datePieces[1]));

			if (orderDate.after(limit)) {
				String processCode = signHistory.getProcessCode();
				if (sign.getPrintAt() == 1) {
					if ("BP".equalsIgnoreCase(processCode)) {
						processingCount++;
					}
				} else {
					processingCount++;
				}
			}
		}

		return processingCount;
	}

	/**
	 * get sign history according singName, yard, stockId
	 * @param signName singName
	 * @param yard yard
	 * @param stockId stockId
	 * @return List<SignHistory> histories
	 *//*
	@SuppressWarnings(UNCHECKED)
	public List<SignHistory> getSignHistory(String signName, Integer yard, String stockId) {
		Query query = em.createNativeQuery("call WebProcessLogs(?,?,?)", SignHistory.class);
		String localStockId = stockId;
		if (localStockId == null) {
			localStockId = "0";
		}
		query.setParameter(1, signName);
		query.setParameter(2, yard);
		query.setParameter(3, localStockId);
		return query.getResultList();
	}*/
	
	public List<SignHistory> getSignHistory(String signName, Integer yard, String stockId) {		
		String localStockId = stockId;
		if (localStockId == null) {
			localStockId = "0";
		}		
		String sql = "{call WebProcessLogs('" + StringUtils.trim(signName) + "','" + yard + "','" + localStockId+ "')}";
		SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql);
		return transform2SignHistory(rowSet);
	}
	
	private List<SignHistory> transform2SignHistory(SqlRowSet rowSet) {
		List<SignHistory> list = new ArrayList<SignHistory>();
		while (rowSet.next()) {
			list.add(new SignHistory(
					rowSet.getInt(1), 
					rowSet.getString(2),
					rowSet.getInt(3), 
					rowSet.getString(4), 
					rowSet.getString(5),
					rowSet.getInt(6),
					rowSet.getBigDecimal(7),
					rowSet.getBigDecimal(8),
					rowSet.getString(9),
					rowSet.getInt(10), 
					rowSet.getInt(11), 
					rowSet.getString(12),
					rowSet.getDate(13)));
		}
		return list;
	}

	public List<SignHistory> getSignHistory(int signId, String storeNum, String signType) {
		List<SignHistory> signHistory = new ArrayList<>();
		List<MenardOrderItem> orderItems = orderItemDao.findOrderItems(signId, storeNum, signType);
		signHistory.addAll(convertOrderItemsToColorSignHistory(orderItems));
		return signHistory;
	}

	private List<SignHistory> convertOrderItemsToColorSignHistory(List<MenardOrderItem> orderItems) {
		List<SignHistory> signHistory = new ArrayList<>(orderItems.size());
		for (MenardOrderItem orderItem : orderItems) {
			SignHistory history = new SignHistory();
			SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
			history.setProcessDate(format.format(orderItem.getMenardOrder().getSubmitDate()));
			history.setDescription(MenardOrderItemStatus.getDescriptionByValue(orderItem.getStatus()));
			history.setYard(orderItem.getMenardOrder().getCreatedByUserId());
			signHistory.add(history);
		}
		return signHistory;
	}

	/**
	 * @param sign sign
	 * @return Map Map
	 */
	public Map<Integer, String> insertSignOrder(SignDTO sign) {
		StringBuilder sb = new StringBuilder("{call requests('");
		SignVersion signVersion = sign.getSignVersion();
		sb.append(StringUtils.trim(signVersion.getSignname()));
		sb.append(CommonConstant.SINGLE_QUOTE_MARK);
		sb.append(CommonConstant.COMMA);
		sb.append(StringUtils.trim(sign.getYard()));
		sb.append(CommonConstant.COMMA);
		sb.append(sign.getStock().getStockId());
		sb.append(CommonConstant.COMMA);
		sb.append(signVersion.getDept());
		sb.append(CommonConstant.COMMA);
		sb.append(signVersion.getLaminate());

		sb.append(CommonConstant.COMMA);
		sb.append(sign.getPrintAt());
		sb.append(CommonConstant.COMMA);
		sb.append(CommonConstant.SINGLE_QUOTE_MARK);
		sb.append(sign.getEmail());
		sb.append(CommonConstant.SINGLE_QUOTE_MARK);
		sb.append(CommonConstant.COMMA);
		sb.append(sign.getOrderableQuantity());

		sb.append(CommonConstant.COMMA);
		sb.append(signVersion.getVersionId());
		sb.append(CommonConstant.COMMA);
		sb.append(sign.getPrintWhite());
		sb.append(CommonConstant.COMMA);
		sb.append(signVersion.getPromonbr());
		sb.append(")}");

		SqlRowSet result = jdbcTemplate.queryForRowSet(sb.toString());
		Map<Integer, String> map = new HashMap<Integer, String>();
		while (result.next()) {
			map.put(result.getInt(1), result.getString(2));
			if (LOG.isDebugEnabled()) {
				LOG.debug("{call requests}[" + result.getInt(1) + "][" + result.getString(2) + "]");
			}
		}
		return map;
	}

	@Resource(name = "signDS")
	public void setSignDS(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public Sign findPrePrintedFactTag(int signId) {
		return getSign(signId);
	}
}
