/**
 * 
 */
package com.menards.ssc.dao.sign;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.constants.OrderItemAttributeKey;
import com.menards.ssc.dao.order.MenardOrderItemDao;
import com.menards.ssc.domain.catalog.ColorSignDTO;
import com.menards.ssc.domain.catalog.ColorSignHistory;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.navigation.CategoryTreeNode;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.enums.CategoryType;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.SignSearchType;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

/**
 * <p>MenardColorSignDao</p>
 * <p></p>
 * <p>
 * Provide some method to color sign database
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Repository("menardColorSignDao")
public class MenardColorSignDaoImpl implements MenardColorSignDao, CommonConstant {

	private final Log logger = LogFactory.getLog(MenardColorSignDaoImpl.class.getName());

	@PersistenceContext(unitName = "colorSignPU")
	private EntityManager em;

	@Resource(name = "menardOrderItemDao")
	private MenardOrderItemDao orderItemDao;
	
	@Value("${colorsignbase.media.path}")
	private String colorSignPath;

	@Value("${colorsignbase.category.media.path}")
	private String colorSignCategoryPath;
	
	@Override
	public void insertSignOrder(Sign sign, MenardOrderItem item) {
		String sql = "INSERT INTO sign.sign_order(sign_order_id,processing_status_id,"
				+ "order_status_id,quantity,location_id,sign_order_dt,info_log_txt,sign_id,"
				+ "user_name,order_type_id,dept_id,web_order_id, cost_amt) "
				+ "VALUES(sign.seq_sign_order_id.nextval, 1, 1," + item.getQuantity() + COMMA + sign.getYard()
				+ ", CURRENT_DATE,'" + item.getNotes() + "'," + sign.getSignID() + ",'"
				+ item.getMenardOrder().getCreatedByUserId() + "',1," + item.getMenardOrder().getDeptId() + COMMA
				+ item.getMenardOrder().getId() + COMMA + sign.getSignPrice() + ")";

		Query query = em.createNativeQuery(sql);
		query.executeUpdate();
	}

	@Override
	public SearchResult<Sign> findColorSignPage(Integer page, Integer size, String text, Integer yardNum) {
		Query query = this.em.createNativeQuery(groupQuerySql(text, 0));
		@SuppressWarnings("unchecked")
		List<Object[]> objectArray = query.getResultList();
		List<Sign> signList = new ArrayList<Sign>();
		for (int i = 0; i < objectArray.size(); i++) {
			signList.add(mappingSign(objectArray.get(i)));
		}
		SearchResult<Sign> result = new SearchResult<Sign>();
		result.setResult(signList);
		return result;
	}

	@Override
	public SearchResult<Sign> findColorSignPageWithIndex(int beignIndex, int endIndex, String text, Integer yardNum) {		
		int begin = beignIndex > 1 ? beignIndex : beignIndex - 1;
		String sql = "SELECT * FROM ( SELECT A.*, ROWNUM RN FROM (" + groupQuerySql(text, yardNum)
				+ ") A ) B  WHERE RN >" + begin + " AND RN <= " + endIndex;
		Query query = em.createNativeQuery(sql);
		@SuppressWarnings("unchecked")
		List<Object[]> objectArray = query.getResultList();
		List<Sign> signList = new ArrayList<Sign>();
		for (int i = 0; i < objectArray.size(); i++) {
			signList.add(mappingSign(objectArray.get(i)));
		}
		SearchResult<Sign> result = new SearchResult<Sign>();
		result.setResult(signList);
		return result;
	}

	@Override
	public int findColorSignCount(String text, Integer yardNum) {
		Query query = this.em.createNativeQuery(groupCountSql(groupQuerySql(text, yardNum)));
		Object count = query.getSingleResult();
		return ((BigDecimal) count).intValue();
	}

    @Override
    public int findColorSignCatalogId(Integer signId) {
        String sql = "select catalog_item_id from sign.sign_catalog_item where sign_id = " + signId;
        Query query = this.em.createNativeQuery(sql);
        Object catalogId = null;
        try {
            catalogId = query.getSingleResult();
        } catch (Exception ex) {
            return -1;
        }
        return ((BigDecimal) catalogId).intValue();
    }

	/**
	 * Group the query string
	 * @param sql String
	 * @return String
	 */
	private String groupCountSql(String sql) {
		return "SELECT  COUNT(*) from (" + sql + ") A";
	}

	/**
	 * 
	 * @param signName String
	 * @param yardNum Integer
	 * @return String
	 */
	private String groupQuerySql(String signName, Integer yardNum) {
		String sql = StringUtils.EMPTY;
		String tempSignName = StringUtils.remove(signName, MINUS);

		if (StringUtils.isNumeric(tempSignName)) {
			sql = processNumericSignName(tempSignName);
		} else {
			tempSignName = StringUtils.replace(signName, SINGLE_QUOTE_MARK, "''");
			tempSignName = StringUtils.replace(signName, PERCENT_SIGN, "\\%");
			sql = getKeywordArguments(tempSignName);

		}
		if (yardNum != null) {
			return getSignsQuery(sql, yardNum);
		}
		return getSignsQuery(sql);
	}

	/**
	 * process sign name
	 * @param signName String
	 * @return String
	 */
	private String processNumericSignName(String signName) {
		if (StringUtils.length(signName) == 7) {
			return getSkuArguments(signName);
		}
		return getNumericKeywordArguments(signName);
	}

	/**
	 * 
	 * @param para String
	 * @param yardNum Integer
	 * @return String
	 */
	public String getSignsQuery(String para, Integer yardNum) {
		String result = "SELECT sign.sign_id AS myid, \n" + "color.color_name as mycolor, \n"
				+ "COALESCE(sign.description,'') AS des, \n" + "COALESCE(sign.special_notes_txt,'') AS spec, \n"
				+ "COALESCE(substrate.material_desc,'') AS des2, \n" + "sign.repository_file_path AS rpath, \n"
				+ "sign.preview_image_file_path AS ppath, \n" + "COALESCE(sign.backside_file_name,'') AS backFile, \n"
				+ "sign.print_doc_hgt AS hgt, \n" + "sign.print_doc_wdt AS wdt, \n"
				+ "sign.print_location_id AS ploc, \n" + "SUM(distribute.quantity) AS availQty, \n"
				+ "sign.dept_id AS dept, \n" + "sign.GM_approval_flg AS gmFlag, \n" + "sign.cost_amt \n"
				+ "FROM sign.sign \n" + "INNER JOIN sign.substrate ON sign.substrate_id = substrate.substrate_id \n"
				+ "INNER JOIN sign.color ON sign.color_id = color.color_id \n"
				+ "INNER JOIN sign.distribute ON sign.sign_id = distribute.sign_id \n" + para
				+ "AND(distribute.location_or_group_id = " + yardNum + " \n"
				+ "	OR distribute.location_or_group_id IN ( \n" + "		SELECT dg.distribute_group_id \n"
				+ "		FROM sign.distribute_group dg \n"
				+ "		JOIN sign.location_group lg on dg.distribute_group_id = lg.distribute_group_id \n"
				+ "		WHERE lg.location_id = " + yardNum + " \n" + "	) \n" + ") \n"
				+ "AND sign.availability_status_id < 1 \n"
				+ "GROUP BY sign.sign_id,color.color_name,sign.description,sign.special_notes_txt, \n"
				+ "	substrate.material_desc,sign.repository_file_path,sign.preview_image_file_path, \n"
				+ "	sign.backside_file_name,sign.print_doc_hgt,sign.print_doc_wdt,sign.print_location_id, \n"
				+ "	sign.dept_id,sign.GM_approval_flg, sign.cost_amt \n" + "ORDER BY sign.print_location_id ASC";

		return result;
	}

	/**
	 * @param signName signName	
	 * @return SQL WHERE full sku is supplied.
	 */
	private String getSkuArguments(final String signName) {
		return "WHERE (\n" + "	sign.sign_id IN( \n" + "		SELECT sign_sku.sign_id \n" + "		FROM sign.sign_sku \n"
				+ "		JOIN sign.sku on sign_sku.sku_id = sku.sku_id \n"
				+ "		JOIN sign.sign on sign.sign_id = sign_sku.sign_id \n" + "		WHERE sku.sku = " + signName + " \n"
				+ "	   UNION \n" + "		SELECT sign_id \n" + "		FROM sign.sign \n" + "		WHERE legacy_sku = " + signName
				+ " \n" + "	) \n" + ") \n";
	}

	/**
	 * 
	 * getKeywordArguments
	 * @param signName signName
	 * @return String String
	 */
	private String getKeywordArguments(final String signName) {
		return "JOIN ( \n" + "	SELECT sk.sign_id \n" + "	FROM  sign.sign_keyword sk \n"
				+ "	JOIN sign.keyword k ON sk.keyword_id = k.keyword_id \n" + "	WHERE LOWER(keyword_txt) LIKE '%"
				+ signName.toLowerCase() + "%' \n" + "  UNION \n" + "	SELECT sign_id \n" + "	FROM sign.sign \n"
				+ "	WHERE LOWER(description) LIKE '%" + signName.toLowerCase() + "%' \n" + "  UNION \n"
				+ "	SELECT sign_id \n" + "	FROM skuman.skuman_keyword \n" + "	WHERE LOWER(skuman_keyword_txt) LIKE '%"
				+ signName.toLowerCase() + "%' \n" + ") dt_l ON sign.sign_id = dt_l.sign_id \n";
	}

	/**
	 * @param signName signName	
	 * @return SQL WHERE for a partial sku and keywords.
	 */
	private String getNumericKeywordArguments(final String signName) {
		String highSku = (signName + "9999").substring(0, 7);
		String lowSku = (signName + "0000").substring(0, 7);

		return "JOIN (\n" + "	SELECT ss.sign_id \n" + "	FROM sign.sign_sku ss \n"
				+ "	JOIN sign.sku ON sku.sku_id = ss.sku_id \n" + "	WHERE sku BETWEEN "
				+ lowSku
				+ " AND "
				+ highSku
				+ " \n"
				+ "  UNION \n"
				+ "	SELECT sk.sign_id \n"
				+ "	FROM sign.sign_keyword sk \n"
				+ "	JOIN sign.keyword k ON sk.keyword_id = k.keyword_id \n"
				+ "	WHERE keyword_txt LIKE '%"
				+ signName
				+ "%' \n"
				+ "  UNION \n"
				+ "	SELECT s.sign_id \n"
				+ "	FROM sign.sign s \n"
				+ "	WHERE s.description LIKE '%"
				+ signName
				+ "%' \n"
				+ "  UNION \n"
				+ "	SELECT s.sign_id \n"
				+ "	FROM sign.sign s \n"
				+ "	WHERE s.sign_id = "
				+ signName
				+ " \n"
				+ "  UNION \n"
				+ "	SELECT s.sign_id \n"
				+ "	FROM sign.sign s \n"
				+ "	WHERE s.legacy_sku BETWEEN "
				+ lowSku + " AND " + highSku + " \n" + ") sign_dt ON sign_dt.sign_id = sign.sign_id \n";
	}

	/**
	 * Query formatted to retrieve signs without a yard specified.
	 * @param param WHERE clause parameter
	 * @return filled in sign template
	 */
	private static String getSignsQuery(String param) {
		String result = "SELECT DISTINCT sign.sign_id AS myid, \n" + "color.color_name as mycolor, \n"
				+ "COALESCE(sign.description,'') AS des, \n" + "COALESCE(sign.special_notes_txt,'') AS spec, \n"
				+ "COALESCE(substrate.material_desc,'') AS des2, \n" + "sign.repository_file_path AS rpath, \n"
				+ "sign.preview_image_file_path AS ppath, \n" + "COALESCE(sign.backside_file_name,'') AS backFile, \n"
				+ "sign.print_doc_hgt AS hgt, \n" + "sign.print_doc_wdt AS wdt, \n"
				+ "sign.print_location_id AS ploc, \n" + "0 AS availQty, \n" + "sign.dept_id AS dept, \n"
				+ "sign.GM_approval_flg AS gmFlag, \n" + "sign.cost_amt \n" + "FROM sign.sign \n"
				+ "INNER JOIN sign.substrate ON sign.substrate_id = substrate.substrate_id \n"
				+ "INNER JOIN sign.color ON sign.color_id = color.color_id \n" + param
				+ "AND sign.availability_status_id < 1 \n" + "ORDER BY sign.print_location_id ASC";
		return result;
	}

	/**
	 * 
	 * mappingSign
	 * @param objectArray objectArray
	 * @return Sign Sign
	 */
	public Sign mappingSign(Object[] objectArray) {
		Sign currentSign = new Sign();
		currentSign.setOriginSystem("/Products/UC/sos/ColorSignBase");
		currentSign.setSignName(((BigDecimal) objectArray[0]).toString());
		currentSign.setSignID(((BigDecimal) objectArray[0]).intValue());
		currentSign.setSignColor((String) objectArray[1]);
		currentSign.setVersionDescription((String) objectArray[2]);
		currentSign.setStockDescription((String) objectArray[4]);

		currentSign.setCloseImagePath((String) objectArray[7]);

		// Format the image path to work with the web server and resemble a Blue Martini path.
		String pPath = (String) objectArray[6];
		String ipValue = StringUtils.EMPTY;
		/*
		 * if(com.menards.uc.util.UCUtil.getList("application").getBoolean("useImageIP",false)){ ipValue =
		 * com.menards.uc.util.UCUtil.getList("application").getString("imageIP"); }
		 */

		String imageName = "CSB_" + pPath.substring(0, pPath.indexOf('.'));
		if (imageName.contains("#")) {
			imageName = imageName.replace("#", "%23");
		}
		if (imageName.contains("&")) {
			imageName = imageName.replace("&", "%26");
		}

		//String prevPath = ipValue + "/media/uc/kiosk/sos/images/colorsignbase/signs/" + imageName + "/thumb_" + pPath;
		String prevPath = ipValue + colorSignPath + imageName + "/thumb_" + pPath;
		currentSign.setPreviewPath(prevPath);
		String imagePath = ipValue + colorSignPath + imageName + "/" + pPath;
		currentSign.setImagePath(imagePath);
		String largeImagePath = ipValue + colorSignPath + imageName + "/larger_"
				+ pPath;
		currentSign.setLargeImagePath(largeImagePath);

		currentSign.setPrintLocation(((BigDecimal) objectArray[10]).toString());

		float hh = ((BigDecimal) objectArray[8]).floatValue();
		currentSign.setStockHeight(hh);
		float ww = ((BigDecimal) objectArray[9]).floatValue();
		currentSign.setStockWidth(ww);

		currentSign.setOrderableQuantity(((BigDecimal) objectArray[11]).intValue());
		currentSign.setDept(((BigDecimal) objectArray[12]).intValue());

		currentSign.setRequiresGMApproval(true);
		String gmFlag = ((Character) objectArray[13]).toString();
		if (gmFlag.equalsIgnoreCase("F")) {
			currentSign.setRequiresGMApproval(false);
		}

		BigDecimal price = (BigDecimal) objectArray[14];
		NumberFormat nf = new DecimalFormat("0.00");
		String signPrice = nf.format(price);
		currentSign.setSignPrice(signPrice);

		currentSign.setColorSignBase(true);

		return currentSign;
	}

	/**
	 * getSign
	 * @param signId signId
	 * @param yard yard
	 * @param type type
	 * @return ColorSignDTO ColorSignDTO
	 */
	@SuppressWarnings("unchecked")
	public ColorSignDTO getSign(final String signId, Integer yard, SignSearchType type) {
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		String locationId = user.getStoreNumber();

		String sql = "WHERE sign.sign_id = '" + signId + "' ";
		if (user.isGOUser()) {
			sql = getSignsQuery(sql);
		} else {
			sql = getSignsQuery(sql, Integer.parseInt(user.getStoreNumber()));
		}
		Query query = em.createNativeQuery(sql);
		List<Object[]> objectArray = query.getResultList();

		ColorSignDTO colorSign = null;
		if (objectArray.size() == 1) {
			Sign sign = mappingSign(objectArray.get(0));

			colorSign = new ColorSignDTO();
			colorSign.setSign(sign);
			if (SignSearchType.Detail.equals(type)) {
				if (user.isGOUser()) {
					List<String> yardList = this.getYardList(Integer.valueOf(signId));
					colorSign.setYardList(yardList);
				} else {
					colorSign.setHistories(this.getSignHistory(Integer.parseInt(signId), locationId,
							OrderItemAttributeKey.SIGN_TYPE_COLOR_SIGN));
				}
			}
			// Get the quantity of signs that have been ordered in the past XX days.
			int leadTime = 14;
			if (colorSign.getPrintLocation().equals("0")) {
				leadTime = 21;
			}
			int orderedQuantity = this.getQuantityOrdered(Integer.valueOf(signId), Integer.valueOf(locationId),
					leadTime);
			// colorSign.setProcessingCount(orderedQuantity);

			colorSign.setCanOrder(colorSign.getOrderableQuantity() > orderedQuantity);

			if (user.isGOUser() || "GM".equalsIgnoreCase(user.getStorePerformRole())) {
				colorSign.setCanOrder(true);
			}
		} else {
			logger.error("Color sign not found! signId -> " + signId + ", User -> " + user.getUserId());
		}

		return colorSign;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Sign findSignById(Integer signId) {
		String sql = "WHERE sign.sign_id = '" + signId + "' ";
		sql = getSignsQuery(sql);
		Query query = em.createNativeQuery(sql);
		List<Object[]> objectArray = query.getResultList();
		return mappingSign(objectArray.get(0));
	}

	@Override
	@SuppressWarnings("unchecked")
	public Map<Integer, Sign> findSignListById(Collection<Integer> signIdCol) {
		if (CollectionUtils.isEmpty(signIdCol)) {
			return MapUtils.EMPTY_MAP;
		}

		String sql = "WHERE sign.sign_id in (" + StringUtils.join(signIdCol, COMMA) + ")";
		sql = getSignsQuery(sql);
		Query query = em.createNativeQuery(sql);
		List<Object[]> objectArray = query.getResultList();
		Map<Integer, Sign> map = new HashMap<Integer, Sign>();
		for (Object[] objects : objectArray) {
			Sign sign = mappingSign(objects);
			map.put(Integer.valueOf(sign.getSignID()), sign);
		}
		return map;
	}

	/**
	 * Formatted query returns a list of all yards and the qty count for each one.
	 * @param signId signId
	 * @return List of yard IDs as string
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<String> getYardList(int signId) {
		List<String> tempResults = new ArrayList<String>();
		String sql = "SELECT location.location_id, COALESCE((" + "	SELECT SUM(distribute.quantity) "
				+ "	FROM sign.sign sign, sign.distribute distribute, sign.location_group location_group "
				+ "	WHERE distribute.sign_id = sign.sign_id " + "	AND sign.sign_id = " + signId + " "
				+ "	AND location_group.dept_id = sign.dept_id "
				+ "	AND location_group.distribute_group_id = distribute.location_or_group_id "
				+ "	AND location_group.location_id = location.location_id" + ") , 0) " + "+ COALESCE(("
				+ "	SELECT SUM(distribute.quantity) " + "	FROM sign.sign sign, sign.distribute distribute "
				+ "	WHERE distribute.sign_id = sign.sign_id " + "	AND sign.sign_id = " + signId + " "
				+ "	AND distribute.location_or_group_id = location.location_id" + "),0) AS qty_count "
				+ "FROM sign.location location " + "ORDER BY location.location_id";

		Query query = em.createNativeQuery(sql);
		List<Object[]> objectArray = query.getResultList();
		for (Object[] obj : objectArray) {
			if (((BigDecimal) obj[1]).intValue() > 0) {
				tempResults.add(obj[0].toString());
			}
		}
		return tempResults;
	}

	/**
	 * 
	 * Get colorSign history
	 * @param signId int
	 * @param storeNum String
	 * @param signType String
	 * @return colorSignHistory List<ColorSignHistory>
	 */
	private List<ColorSignHistory> getSignHistory(int signId, String storeNum, String signType) {
		List<ColorSignHistory> colorSignHistory = new ArrayList<>();
		List<MenardOrderItem> orderItems = orderItemDao.findOrderItems(signId, storeNum, signType);
		colorSignHistory.addAll(convertOrderItemsToColorSignHistory(orderItems));
		colorSignHistory.addAll(this.getSignHistory(signId, Integer.parseInt(storeNum)));
		return colorSignHistory;
	}

	/**
	 * 
	 * Convert order items to ColorSign Histories
	 * @param orderItems List<MenardOrderItem>
	 * @return colorSignHistory List<ColorSignHistory> 
	 */
	private List<ColorSignHistory> convertOrderItemsToColorSignHistory(List<MenardOrderItem> orderItems) {
		List<ColorSignHistory> colorSignHistory = new ArrayList<>(orderItems.size());
		for (MenardOrderItem orderItem : orderItems) {
			ColorSignHistory history = new ColorSignHistory();
			SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
			history.setDateStr(format.format(orderItem.getMenardOrder().getSubmitDate()));
			history.setDescription(MenardOrderItemStatus.getDescriptionByValue(orderItem.getStatus()));
			history.setUserName(orderItem.getMenardOrder().getCreatedByUserId());
			colorSignHistory.add(history);
		}
		return colorSignHistory;
	}

	/**
	 * @param signId signId
	 * @param locationId locationId
	 *
	 * @return List
	 */
	@SuppressWarnings("unchecked")
	public List<ColorSignHistory> getSignHistory(final int signId, int locationId) {
		String sql = "SELECT * \n"
				+ "FROM ( \n"
				+ "	SELECT so.user_name, TO_CHAR(NVL(osl.insert_dt, so.sign_order_dt), 'MM/DD/YYYY') as sign_order_dt, description AS status_description \n"
				+ "	FROM sign.sign_order so \n"
				+ "	LEFT JOIN sign.order_status os on os.order_status_id = so.order_status_id \n" + "	LEFT JOIN ( \n"
				+ "		SELECT sign_order_id, MAX(order_status_log_id) as tracking_status \n"
				+ "		FROM sign.order_status_log \n" + "		WHERE sign_id = " + signId + " \n";
		if (locationId > 0) {
			sql += "		AND location_id = " + locationId + " \n";
		}
		sql += "		GROUP BY sign_order_id \n" + "	) mosl on so.sign_order_id = mosl.sign_order_id \n"
				+ "	LEFT JOIN sign.order_status_log osl ON mosl.tracking_status = osl.order_status_log_id \n"
				+ "	WHERE so.sign_id = " + signId + " \n";
		if (locationId > 0) {
			sql += "		AND so.location_id = " + locationId + " \n";
		}
		sql += "	AND NVL(osl.insert_dt, so.sign_order_dt) > (current_date - 60) \n" + ") \n"
				+ "ORDER BY sign_order_dt DESC";

		Query query = em.createNativeQuery(sql);
		List<Object[]> objectArray = query.getResultList();
		List<ColorSignHistory> tempResults = new ArrayList<ColorSignHistory>();
		for (Object[] obj : objectArray) {
			ColorSignHistory his = new ColorSignHistory();
			his.setUserName(obj[0].toString());
			his.setDateStr(obj[1].toString());
			his.setDescription(obj[2].toString());
			tempResults.add(his);
		}
		return tempResults;
	}

	/**
	 * Uses the sign ID and the location ID to get the ordered history for the passed in sign ID.
	 * @param signId signId
	 * @param locationId locationId
	 * @param leadTime leadTime
	 * @return int int
	 */
	public int getQuantityOrdered(int signId, int locationId, int leadTime) {
		int quantityOrdered = 0;
		String sql = "SELECT SUM(so.quantity) \n" + "FROM sign.sign_order so \n" + "LEFT JOIN ( \n"
				+ "	SELECT sign_order_id, MAX(order_status_log_id) as tracking_status \n"
				+ "	FROM sign.order_status_log \n" + "	WHERE sign_id = " + signId + " \n";
		if (locationId > 0) {
			sql += "	AND location_id = " + locationId + " \n";
		}
		sql += "	GROUP BY sign_order_id \n" + ") mosl ON so.sign_order_id = mosl.sign_order_id \n"
				+ "LEFT JOIN sign.order_status_log osl ON mosl.tracking_status = osl.order_status_log_id \n"
				+ "WHERE so.sign_id = " + signId + " \n";
		if (locationId > 0) {
			sql += "AND so.location_id = " + locationId + " \n";
		}
		sql += "AND NVL(osl.insert_dt, sign_order_dt) > (current_date - " + leadTime + ") \n"
				+ "AND NVL(osl.order_status_id, so.order_status_id) <> 6";

		Query query = em.createNativeQuery(sql);
        Object result = query.getSingleResult();
        if (result != null) {
            quantityOrdered = Integer.valueOf(result.toString());
        }
		return quantityOrdered;
	}

	/**
	 * for color sign product list
	 * Retrieve all signs set up for the selected catalog/yard combination
	 * @param catalogID catalogID
	 * @param limit limit
	 * @param offset offset
	 * @return list list
	 */
	@SuppressWarnings("unchecked")
	public List<Sign> getSignsByCatalogID(long catalogID, int limit, int offset) {
		String sql = "JOIN sign.sign_catalog_item sci ON sign.sign_id = sci.sign_id \n"
				+ "WHERE sci.catalog_item_id = " + catalogID + " \n";
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		if (!user.isGOUser()) {
			sql = getSignsQuery(sql, Integer.valueOf(user.getStoreNumber()));
		} else {
			sql = getSignsQuery(sql);
		}

		sql = "select rownum rn,a.* from (" + sql + ") a where rownum<=" + limit;
		sql = "select b.* from (" + sql + ") b where rn>" + offset;

		Query query = em.createNativeQuery(sql);
		List<Object[]> objectArray = query.getResultList();
		List<Sign> signs = new ArrayList<Sign>();
		for (Object[] obj : objectArray) {
			Object[] newObj = Arrays.copyOfRange(obj, 1, obj.length);
			Sign sign = mappingSign(newObj);
			signs.add(sign);
		}
		return signs;
	}

	@SuppressWarnings("unchecked")
	@Override
	public long countByCatalogID(long catalogID) {
		String sql = "JOIN sign.sign_catalog_item sci ON sign.sign_id = sci.sign_id \n"
				+ "WHERE sci.catalog_item_id = " + catalogID + " \n";
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		if (!user.isGOUser()) {
			sql = getSignsQuery(sql, Integer.valueOf(user.getStoreNumber()));
		} else {
			sql = getSignsQuery(sql);
		}
		Query query = em.createNativeQuery(sql);
		List<Object[]> objectArray = query.getResultList();
		return objectArray.size();
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List<CategoryTreeNode> getColorSignCategorList() {
		List categoryList = null;
		String query = "SELECT " + "  -1*catalog_item_id category_id, " + "  name category_name, "
				+ "  -1*level_assoc_nbr parent_category_id, " + "  description category_desc, "
				+ "  image_file_path category_img_url " + "FROM " + "  sign.catalog_item " + "WHERE "
				+ "  catalog_item_id != -1 ";
		categoryList = em.createNativeQuery(query).getResultList();
		List<CategoryTreeNode> categoryTreeNodeList = new ArrayList<CategoryTreeNode>(categoryList.size());
		for (Object colorSignCategory : categoryList) {
			Long categoryId = ((BigDecimal) (((Object[]) colorSignCategory)[0])).longValue();
			String categoryName = ((Object[]) colorSignCategory)[1].toString();
			Long parentCategoryId = ((BigDecimal) (((Object[]) colorSignCategory)[2])).longValue();
			String categoryDesc = ((Object[]) colorSignCategory)[3].toString();
			String categoryImgUrl = ((Object[]) colorSignCategory)[4].toString();
			if (categoryImgUrl.startsWith("/") || categoryImgUrl.startsWith("\\")) {
				categoryImgUrl = categoryImgUrl.substring(1);
			}
			CategoryTreeNode categoryTreeNode = new CategoryTreeNode();
			categoryTreeNode.setCategoryId(categoryId);
			categoryTreeNode.setCategoryName(categoryName);
			categoryTreeNode.setParentCategoryId(parentCategoryId);
			categoryTreeNode.setCategoryDesc(categoryDesc);
			categoryTreeNode.setCategoryImgUrl(colorSignCategoryPath + categoryImgUrl);
			categoryTreeNode.setUrl("/COLOR_SIGN_CATEGORY_" + categoryId);
			categoryTreeNode.setCategoryType(CategoryType.COLOR_SIGN_CATEGORY);
			categoryTreeNodeList.add(categoryTreeNode);
		}
		return categoryTreeNodeList;
	}

}
