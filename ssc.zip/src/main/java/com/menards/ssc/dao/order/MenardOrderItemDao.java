package com.menards.ssc.dao.order;

import java.util.List;

import org.broadleafcommerce.core.order.dao.OrderItemDao;
import org.broadleafcommerce.core.order.domain.OrderItemAttribute;

import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.domain.order.MenardOrderItemHistory;
import com.menards.ssc.domain.order.MenardOrderItemTrackingHistory;

/**
 * <p>MenardOrderItemDao</p>
 * <p>repository layer object</p>
 * <p>
 *   Provide methods such as, find order item(s) or save order
 *   item.
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public interface MenardOrderItemDao extends OrderItemDao {

	/**
	 * @param orderItemId Long
	 * @return MenardOrderItem
	 */
	public MenardOrderItem readMenardOrderItemById(Long orderItemId);

	/**
	 *
	 * Query the order items according to the conditions
	 * @param filter MenardOrderItemFilterDTO
	 * @return List<MenardOrderItem>
	 */
	public List<MenardOrderItem> findOrderItems(MenardOrderItemFilterDTO filter);

	/**
	 * Find order item according to the text
	 * @param filter String
	 * @return SearchResult<MenardProductDesc>
	 */
	public SearchResult<MenardOrderItem> findOrderItemsPage(MenardOrderItemFilterDTO filter);
	
	/**
	 * Retrieve one page of order items history. Parameters passed to query could be
	 * menards sku, item status, store and so on.
	 * @param filter MenardOrderItemFilterDTO
	 * @return SearchResult<MenardOrderItem>
	 */
	public SearchResult<MenardOrderItemHistory> findItemHistoryPage(MenardOrderItemFilterDTO filter);

	/**
	 * save order item tracking history
	 *
	 * @param history MenardOrderItemTrackingHistory
	 * @return MenardOrderItemTrackingHistory
	 */
	public MenardOrderItemTrackingHistory saveOrderItemTrackingHistory(MenardOrderItemTrackingHistory history);

	/**
	 * save menard order item
	 *
	 * @param menardOrderItem MenardOrderItem
	 * @return MenardOrderItem
	 */
	public MenardOrderItem saveMenardDiscreateOrderItem(MenardOrderItem menardOrderItem);

	/**
	 *
	 * Query the order items according to the conditions
	 * @param skuId Long
	 * @param storeNum String
	 * @return List<MenardOrderItem> list
	 */
	public List<MenardOrderItem> findOrderItems(Long skuId, String storeNum);


    /**
     * Create an instance of type OrderItemAttribute (@org.broadleafcommerce.core.order.domain.OrderItemAttribute)
     *
     * @return a JPA managed entity of type OrderItemAttribute
     */
    public OrderItemAttribute createOrderItemAttribute();

    /**
     * Find sign/colorsign order items by sku, store, and sign type.
     *
     * @param signId int
     * @param storeNum String
     * @param signType String
     * @return List<MenardOrderItem>
     */
    public List<MenardOrderItem> findOrderItems(int signId, String storeNum, String signType);
    
    /**
	 * Flush all the previous update
	 */
	public void flush();


    /**
     * count the total number of all order items awaiting approval
     *
     * @return count long
     */
    long countOrderItemsForApprove();
}
