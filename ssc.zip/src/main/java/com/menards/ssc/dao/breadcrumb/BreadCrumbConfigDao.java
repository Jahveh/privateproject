package com.menards.ssc.dao.breadcrumb;

import java.util.List;

import com.menards.ssc.domain.breadcrumb.BreadCrumbConfig;

/**
 * 
 * <p>BreadCrumbConfigDao</p>
 * <p>Dao class for manipulating BREAD_CRUMB_CONFIG table</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public interface BreadCrumbConfigDao {

	/**
	 * 
	 * Read BreadCrumb configuration
	 * @return List<BreadCrumbConfig>
	 */
	List<BreadCrumbConfig> readAllBreadCrumbConfigs();

}
