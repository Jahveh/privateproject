/**
 *
 */
package com.menards.ssc.dao.sign;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.catalog.SignDTO;
import com.menards.ssc.domain.setremodel.SetRemodelDTO;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.domain.sign.SignHistory;
import com.menards.ssc.domain.sign.SignSaleInfo;
import com.menards.ssc.enums.SignSearchType;

/**
 * <p>MenardSignDao</p>
 * <p>Search sign from outside sign database </p>
 * <p>
 *  Provide some methods to access sign data
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public interface MenardSignDao {

	public static final Logger LOG = Logger.getLogger(MenardSignDao.class);

	/**
	 * Retrieve a page of sign data from informix database
	 * @param page Integer
	 * @param size Integer
	 * @param text String
	 * @return SearchResult<Sign>
	 */
	public SearchResult<Sign> findSignPage(Integer page, Integer size, String text);

	/**
	 * 
	 * Retrieve the total page of sign
	 * @param param String
	 * @param yardnum Integer
	 * @param isSaleSign boolean
	 * @return int
	 */
	public int findSignTotalCount(String param, Integer yardnum, boolean isSaleSign);

	/**
	 * Retrieve a page of sale sign data from informix database
	 * @param page Integer
	 * @param size Integer
	 * @param text  String
	 * @param yardNum Integer
	 * @return SearchResult<Sign>
	 */
	public SearchResult<Sign> findSaleSignPage(Integer page, Integer size, String text, Integer yardNum);

	/**
	 * get SetRemodel by store Id
	 * @param storeId storeId
	 * @return SetRemodelDTO SetRemodelDTO
	 */
	public SetRemodelDTO getSetRemodelByStoreId(String storeId);

	/**
	 * @param signName String
	 * @param versionId Integer
	 * @param department Integer
	 * @param yardnum Integer
	 * @return Sign
	 */
	public Sign findSign(String signName, Integer versionId, Integer department, Integer yardnum);
	
	/**
	 * Retrieve the sale sign information
	 * 
	 * @param signName
	 * @param versionId
	 * @param department
	 * @param yardnum
	 * @return Sign
	 */
	public Sign findSaleSign(String signName, Integer versionId, Integer department, Integer yardnum);

	/**
	 * @param signId int
	 * @param yard int
	 * @return List<SignSaleInfo>
	 */
	public List<SignSaleInfo> getSaleSigns(int signId, int yard);

	/**
	 * @param signName String
	 * @param limit int
	 * @param offset int
	 * @return List<Sign>
	 */
	public List<Sign> getPrePrintedFactTags(String signName, int limit, int offset);

	/**
	 * update remodel date
	 * date format yyyy-MM-dd
	 * @param remodel remodel
	 * @return int update count
	 */
	public int updateRemodelDate(SetRemodelDTO remodel);

	/**
	 * find sign according sing version id and yard
	 * @param signVersionId Integer
	 * @param yard yard
	 * @param type type
	 * @return SignDTO sign dto
	 */
	public SignDTO findSign(Integer signVersionId, Integer yard, SignSearchType type);

    /**
     * find sign according sing version id and yard
     * @param signVersionId Integer
     * @param yard yard
     * @param type type
     * @param promoNbr int
     * @param itemType String
     * @return SignDTO sign dto
     */
    public SignDTO findSign(Integer signVersionId, Integer yard, SignSearchType type, int promoNbr, String itemType);
    
    /**
     * @param signId
     * @return Sign
     */
    public Sign findPrePrintedFactTag(int signId);

	/**
	 * Save a sign order by calling stored procedure
	 * @param sign Sign
	 * @return Map<Integer, String>
	 */
	public Map<Integer, String> insertSignOrder(SignDTO sign);
	
	
	/**
	 * @param signId
	 * @param storeNum
	 * @param signType
	 * @return
	 */
	public List<SignHistory> getSignHistory(int signId, String storeNum, String signType);
	
	/**
	 * @param signName
	 * @param yard
	 * @param stockId
	 * @return
	 */
	public List<SignHistory> getSignHistory(String signName, Integer yard, String stockId);
	
	/**
	 * Calculate the processing count according to the history data
	 * 
	 * @param sign
	 * @param signHistoryList
	 * @return
	 */
	public int getProcessingCount(SignDTO sign, List<SignHistory> signHistoryList);
	
	/**
	 * Retrieve all the yards for sign
	 * @param signId String
	 * @return List<String>
	 */
	public List<String> getYardList(String signId);
}
