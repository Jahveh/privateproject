package com.menards.ssc.dao.inventory;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.menards.ssc.domain.inventory.MenardInventoryDTO;
import com.menards.ssc.domain.yard.Store;

/**
 * @author frank.shao
 */
@Repository("menardInventoryDao")
public class MenardInventoryDaoImpl implements MenardInventoryDao {

	public static final Log LOG = LogFactory.getLog(MenardInventoryDaoImpl.class);
	private static final int SEQUENCE_ZERO = 0;
	private static final int SEQUENCE_ONE = 1;
	private static final int SEQUENCE_TWO = 2;
	private static final int SEQUENCE_THREE = 3;

	@PersistenceContext(unitName = "blPU")
	private EntityManager em;

	@Override
	public List<MenardInventoryDTO> getInventory() {

		// String sql = "SELECT model_number,description_short,image_path FROM menards_product_selection";
		String sql = "SELECT details.PRD_ID,details.MODEL_NUMBER,details.DESCRIPTION_SHORT,details.IMAGE_PATH "
				+ "FROM BLC_CATEGORY_PRODUCT_XREF as t left join MENARDS_PRODUCT_SELECTION as details "
				+ "on t.PRODUCT_ID = details.PRD_ID where CATEGORY_ID=2534374302025982 and MODEL_NUMBER is not null ";

		Query query = this.em.createNativeQuery(sql);
		@SuppressWarnings("unchecked")
		List<Object[]> objecArraytList = query.getResultList();
		List<MenardInventoryDTO> inventoryList = new ArrayList<MenardInventoryDTO>();

		for (int i = 0; i < objecArraytList.size(); i++) {
			MenardInventoryDTO inventory = new MenardInventoryDTO();
			Object[] obj = objecArraytList.get(i);

			if (obj[SEQUENCE_ZERO] != null) {
				inventory.setProductId(Long.valueOf(obj[SEQUENCE_ZERO].toString()));
			}
			
			if (obj[SEQUENCE_ONE] != null) {
				inventory.setModelNumber(obj[SEQUENCE_ONE].toString());
			}

			if (obj[SEQUENCE_TWO] != null) {
				inventory.setDescriptionShort(obj[SEQUENCE_TWO].toString());
			}

			if (obj[SEQUENCE_THREE] != null) {
				inventory.setImagePath(obj[SEQUENCE_THREE].toString());
			}

			inventoryList.add(inventory);

		}

		return inventoryList;

	}

	@Override
	public List<MenardInventoryDTO> getInventoryBySku(String sku) {
		String sql = "SELECT PRD_ID, model_number,description_short,image_path FROM MENARDS_PRODUCT_SELECTION "
				+ "where model_number=" + sku + "";
		Query query = this.em.createNativeQuery(sql);
		@SuppressWarnings("unchecked")
		List<Object[]> objecArraytList = query.getResultList();
		List<MenardInventoryDTO> inventoryList = new ArrayList<MenardInventoryDTO>();

		for (int i = 0; i < objecArraytList.size(); i++) {
			MenardInventoryDTO inventory = new MenardInventoryDTO();
			Object[] obj = objecArraytList.get(i);

            if (obj[SEQUENCE_ZERO] != null) {
                inventory.setProductId(Long.valueOf(obj[SEQUENCE_ZERO].toString()));
            }

            if (obj[SEQUENCE_ONE] != null) {
                inventory.setModelNumber(obj[SEQUENCE_ONE].toString());
            }

            if (obj[SEQUENCE_TWO] != null) {
                inventory.setDescriptionShort(obj[SEQUENCE_TWO].toString());
            }

            if (obj[SEQUENCE_THREE] != null) {
                inventory.setImagePath(obj[SEQUENCE_THREE].toString());
            }

			inventoryList.add(inventory);

		}

		return inventoryList;

	}

	@Override
	public void logEvent(String storeNumber, String application, int messageCode) {
		int iResult = -2;
		try {

			String sql = "INSERT INTO MENARD_BM_USAGE (STORE_NUMBER, CREATE_DATE, "
					+ "CLIENT_LAST_OCTET, PROGRAM_CODE, MESSAGE_CODE) values(" + storeNumber + ",now(),1,"
					+ application + "," + messageCode + ")";
			Query query = em.createNativeQuery(sql);
			iResult = query.executeUpdate();

			if (iResult <= 0) {
				LOG.info("ERROR inserting event - Store:" + storeNumber + " Program Code: " + application
						+ " Message Code: " + messageCode);
			} else {
				LOG.info("Inserted Store:" + storeNumber + " Program Code: " + application + " Message Code: "
						+ messageCode);
			}
		} catch (Exception e) {
			LOG.error("ERROR exception inserting event - Store:" + storeNumber + " Program Code: " + application
					+ " Message Code: " + messageCode + e.toString());
		}

	}

	@Override
	public List<Store> getIncomplete903Inventory() {

		Calendar cal = Calendar.getInstance();
		int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
		GregorianCalendar gCal = new GregorianCalendar();
		// Set the start date to the first day of the month
		gCal.add(Calendar.DATE, -dayOfMonth + 1);
		Date dStartDate = gCal.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		// Get all the stores that have not completed their inventory yet.
		String sql = "SELECT DISTINCT MO.STORE_ID AS STORE_ID FROM BLC_ORDER O,MENARD_ORDER MO "
				+ "WHERE O.ORDER_ID=MO.ORDER_ID AND STORE_ID IS NOT NULL AND STORE_ID NOT IN "
				+ "(SELECT DISTINCT STORE_NUMBER FROM MENARD_BM_USAGE WHERE CREATE_DATE>=" + sdf.format(dStartDate)
				+ " AND CREATE_DATE<now()" + " AND PROGRAM_CODE=900 AND MESSAGE_CODE=903 ) ORDER BY STORE_ID";
		Query query = this.em.createNativeQuery(sql);
		@SuppressWarnings("unchecked")
		List<Object[]> objecArraytList = query.getResultList();
		List<Store> storeList = new ArrayList<Store>();

		for (int i = 0; i < objecArraytList.size(); i++) {
			Store store = new Store();
			Object obj = objecArraytList.get(i);

			if (obj != null) {
				store.setStoreNumber(obj.toString());
			}

			storeList.add(store);
		}
		return storeList;
	}

}
