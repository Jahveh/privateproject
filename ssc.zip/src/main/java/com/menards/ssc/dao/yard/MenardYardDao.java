package com.menards.ssc.dao.yard;

import java.util.List;

import com.menards.ssc.domain.yard.Store;

/**
 * 
 * <p>MenardYardDao</p>
 * <p>Menard Yard Dao is to provide methods to get  information for all stores or individual store</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public interface MenardYardDao {

	/**
	 * 
	 * get store by store Number
	 * @param storeNumber storeNumber
	 * @return Store
	 */
	public Store getStore(String storeNumber);

	/**
	 * 
	 * get all stores for Item History, Approval, and Order Options 
	 * @return List<Store>
	 */
	public List<Store> getYardNameList();

	/**
	 * 
	 * get all stores For Remodel Dates
	 * @return List<Store>
	 */
	public List<Store> getYardForRemodelDates();

}
