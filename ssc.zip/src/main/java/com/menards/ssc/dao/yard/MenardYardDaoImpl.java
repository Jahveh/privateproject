package com.menards.ssc.dao.yard;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.menards.ssc.domain.yard.Store;

/**
 * @author frank.shao
 */
@Repository("menardYardDao")
public class MenardYardDaoImpl implements MenardYardDao {

	public static final Log LOG = LogFactory.getLog(MenardYardDaoImpl.class);
	private static final int SEQUENCE_ZERO = 0;
	private static final int SEQUENCE_ONE = 1;
	private static final int SEQUENCE_TWO = 2;

	@PersistenceContext(unitName = "rightsPU")
	private EntityManager em;

	@PersistenceContext(unitName = "signPU")
	private EntityManager signPU;

	@Override
	public Store getStore(String storeNumber) {

		String sql = "select yard, abbr, yard_name, address1, address2, "
				+ "city, state, zip, phone, fax, net_id from rights.yardship_all where yard =" + storeNumber
				+ " order by yard";
		Query query = this.em.createNativeQuery(sql);
		@SuppressWarnings("unchecked")
		List<Object[]> objecArraytList = query.getResultList();
		Store store = null;

		if (objecArraytList.size() > 0) {
			store = new Store();

			Object[] obj = objecArraytList.get(0);

			if (obj[SEQUENCE_ZERO] != null) {
				store.setStoreNumber(obj[SEQUENCE_ZERO].toString());
			}

			if (obj[SEQUENCE_ONE] != null) {
				store.setStoreAbbreviation(obj[SEQUENCE_ONE].toString());
			}

			if (obj[SEQUENCE_TWO] != null) {
				store.setStoreName(obj[SEQUENCE_TWO].toString());
			}
			if (obj[3] != null) {
				store.setAddress1(obj[3].toString());
			}
			if (obj[4] != null) {
				store.setAddress2(obj[4].toString());
			}
			if (obj[5] != null) {
				store.setCity(obj[5].toString());
			}
			if (obj[6] != null) {
				store.setState(obj[6].toString());
			}
			if (obj[7] != null) {
				store.setZip(obj[7].toString());
			}
			if (obj[8] != null) {
				store.setPhoneNumber(obj[8].toString());
			}
			if (obj[9] != null) {
				store.setFaxNumber(obj[9].toString());
			}
			if (obj[10] != null) {
				store.setNetId(obj[10].toString());
			}
		}

		return store;
	}

	@Override
	public List<Store> getYardNameList() {

		String sql = "select yard,abbr, yard_name from rights.yardship_all "
				+ "where yard not in('9696','4444','3598','5555','7777','3100','4999','3238') order by yard";
		Query query = this.em.createNativeQuery(sql);
		@SuppressWarnings("unchecked")
		List<Object[]> objecArraytList = query.getResultList();
		List<Store> storeList = new ArrayList<Store>();

		for (int i = 0; i < objecArraytList.size(); i++) {
			Store store = new Store();
			Object[] obj = objecArraytList.get(i);

			if (obj[SEQUENCE_ZERO] != null) {
				store.setStoreNumber(obj[SEQUENCE_ZERO].toString());
			}

			if (obj[SEQUENCE_ONE] != null) {
				store.setStoreAbbreviation(obj[SEQUENCE_ONE].toString());
			}

			if (obj[SEQUENCE_TWO] != null) {
				store.setStoreName(obj[SEQUENCE_TWO].toString());
			}

			storeList.add(store);

		}

		return storeList;

	}

	@Override
	public List<Store> getYardForRemodelDates() {

		String sql = "SELECT yard,yard_name FROM skuman_db@skuman_on\\:yardship order by yard";
		Query query = this.signPU.createNativeQuery(sql);
		@SuppressWarnings("unchecked")
		List<Object[]> objecArraytList = query.getResultList();
		List<Store> storeList = new ArrayList<Store>();

		for (int i = 0; i < objecArraytList.size(); i++) {
			Store store = new Store();
			Object[] obj = objecArraytList.get(i);

			if (obj[SEQUENCE_ZERO] != null) {
				store.setStoreNumber(obj[SEQUENCE_ZERO].toString());
			}

			if (obj[SEQUENCE_ONE] != null) {
				store.setStoreName(obj[SEQUENCE_ONE].toString());
			}

			storeList.add(store);

		}

		return storeList;
	}

}
