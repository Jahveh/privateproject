package com.menards.ssc.dao.order;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

/**
 * 
 * <p>BlcCategoryAttributeDao</p>
 * <p>BlcCategoryAttributeDao</p> 
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Repository
public class BlcCategoryAttributeDao {
	@PersistenceContext(unitName = "blPU")
	private EntityManager em;

	/**
	 * 
	 * Get ColorSign CategoryIds
	 * @return CategoryIds List
	 */
	@SuppressWarnings("rawtypes")
	public List getColorSignCategoryIdList() {
		String query = "select category_id from BLC_CATEGORY_ATTRIBUTE where name = 'Form_Continue' and value = 'signbase_catalog'";
		return em.createNativeQuery(query).getResultList();
	}

}
