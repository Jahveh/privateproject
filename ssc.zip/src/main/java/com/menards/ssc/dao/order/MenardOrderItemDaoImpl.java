package com.menards.ssc.dao.order;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.broadleafcommerce.core.catalog.domain.Sku;
import org.broadleafcommerce.core.order.dao.OrderItemDaoImpl;
import org.broadleafcommerce.core.order.domain.OrderItemAttribute;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.joda.time.DateTime;
import org.springframework.stereotype.Repository;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.catalog.MenardProductImpl;
import com.menards.ssc.domain.catalog.MenardSkuImpl;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.order.MenardDiscreteOrderItemImpl;
import com.menards.ssc.domain.order.MenardOrderImpl;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.domain.order.MenardOrderItemHistory;
import com.menards.ssc.domain.order.MenardOrderItemTrackingHistory;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardOrderItemSort;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

/**
 * <p>MenardOrderItemDaoImpl</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Repository("menardOrderItemDao")
public class MenardOrderItemDaoImpl extends OrderItemDaoImpl implements MenardOrderItemDao, CommonConstant {

	@Override
	public List<MenardOrderItem> findOrderItems(MenardOrderItemFilterDTO filter) {
		return findOrderItemsPage(filter).getResult();
	}

	/**
	 * Group the order clause for order item sort
	 *
	 * @param sort String
	 * @param builder CriteriaBuilder
	 * @param orderItem Root<MenardDiscreteOrderItemImpl>
	 * @param skuJoin Join<MenardDiscreteOrderItemImpl, MenardSkuImpl>
	 * @param productJoin Join<MenardDiscreteOrderItemImpl, MenardProductImpl>
	 * @return Order
	 */
	private List<Order> getOrder(String sort, CriteriaBuilder builder, Root<MenardDiscreteOrderItemImpl> orderItem,
			Join<MenardDiscreteOrderItemImpl, MenardSkuImpl> skuJoin,
			Join<MenardDiscreteOrderItemImpl, MenardProductImpl> productJoin) {
		List<Order> list = new ArrayList<Order>();
		MenardOrderItemSort menardSort = MenardOrderItemSort.getMenardOrderItemSortByKey(sort);
		if (menardSort.getPathType().equals(String.class)) {
			// Since there are sku code and menard sku, it's special
			if (MenardOrderItemSort.SKU_DESC.equals(menardSort) || MenardOrderItemSort.SKU_ASC.equals(menardSort)) {
				for (String field : menardSort.getFields()) {
					list.add(getSortOrderResult(builder, menardSort.getType(), skuJoin.get(field)));
				}
			} else if (MenardOrderItemSort.ITEM_ID_DESC.equals(menardSort)
					|| MenardOrderItemSort.ITEM_ID_ASC.equals(menardSort)) {
				for (String field : menardSort.getFields()) {
					list.add(getSortOrderResult(builder, menardSort.getType(), productJoin.get(field)));
				}				
				if (MenardOrderItemSort.ITEM_ID_DESC.equals(menardSort)) {
					list.add(getSortOrderResult(builder, MenardOrderItemSort.ITEM_ID_DESC.getType(), orderItem.get("signId")));
				} else {
					list.add(getSortOrderResult(builder, MenardOrderItemSort.ITEM_ID_ASC.getType(), orderItem.get("signId")));
				}

			} else {
				Path<String> path = getPath(menardSort.getFields(), orderItem);
				list.add(getSortOrderResult(builder, menardSort.getType(), path));
			}
		}

		if (menardSort.getPathType().equals(Long.class)) {
			Path<Long> path = getPath(menardSort.getFields(), orderItem);
			list.add(getSortOrderResult(builder, menardSort.getType(), path));
		}

		if (menardSort.getPathType().equals(Date.class)) {
			Path<Date> path = getPath(menardSort.getFields(), orderItem);
			list.add(getSortOrderResult(builder, menardSort.getType(), path));
		}
		return list;
	}
	
	
	/**
	 * Group the order clause for order item history search. Since now 
	 * description, menards sku and bm sku(open sku plus model number) are 
	 * filled into the table columns the sort can be implemented directly.
	 *
	 * @param sort String
	 * @param builder CriteriaBuilder
	 * @param orderItem Root<MenardOrderItemHistory>
	 * @return Order
	 */
	private List<Order> getItemHistoryOrder(String sort, CriteriaBuilder builder, Root<MenardOrderItemHistory> orderItem) {
		List<Order> list = new ArrayList<Order>();
		MenardOrderItemSort menardSort = MenardOrderItemSort.getMenardOrderItemSortByKey(sort);
		if (menardSort.getPathType().equals(String.class)) {
			if (MenardOrderItemSort.SKU_DESC.equals(menardSort) || MenardOrderItemSort.SKU_ASC.equals(menardSort)) {
				list.add(getSortOrderResult(builder, menardSort.getType(), orderItem.get("menardSkuStr")));				
			} else if (MenardOrderItemSort.ITEM_ID_DESC.equals(menardSort)
					|| MenardOrderItemSort.ITEM_ID_ASC.equals(menardSort)) {
				list.add(getSortOrderResult(builder, menardSort.getType(), orderItem.get("bmSku")));
				list.add(getSortOrderResult(builder, menardSort.getType(), orderItem.get("signId")));				
			} else {
				Path<String> path = getItemHistoryPath(menardSort.getFields(), orderItem);
				list.add(getSortOrderResult(builder, menardSort.getType(), path));
			}
		}

		if (menardSort.getPathType().equals(Long.class)) {
			Path<Long> path = getItemHistoryPath(menardSort.getFields(), orderItem);
			list.add(getSortOrderResult(builder, menardSort.getType(), path));
		}

		if (menardSort.getPathType().equals(Date.class)) {
			Path<Date> path = getItemHistoryPath(menardSort.getFields(), orderItem);
			list.add(getSortOrderResult(builder, menardSort.getType(), path));
		}
		return list;
	}

	/**
	 * Group the sort type
	 * @param builder CriteriaBuilder
	 * @param sortType String
	 * @param path Path<T>
	 * @param <T> T
	 * @return Order <T>
	 */
	private <T> Order getSortOrderResult(CriteriaBuilder builder, String sortType, Path<T> path) {
		if (SORT_DESC.equals(sortType)) {
			return builder.desc(path);
		}
		return builder.asc(path);

	}

	/**
	 * Group the path according to the type of sort
	 *
	 * @param fields Order
	 * @param orderItem Root<MenardDiscreteOrderItemImpl>
	 * @param <T> T
	 * @return Path<T>
	 */
	private <T> Path<T> getPath(Collection<String> fields, Root<MenardDiscreteOrderItemImpl> orderItem) {
		Path<T> path = null;
		for (String field : fields) {
			if (path == null) {
				path = orderItem.get(field);
				continue;
			}
			path = path.get(field);
		}

		return path;
	}
	
	/**
	 * Group the path according to the type of sort and sort fields
	 *
	 * @param fields Order
	 * @param orderItem Root<MenardDiscreteOrderItemImpl>
	 * @param <T> T
	 * @return Path<T>
	 */
	private <T> Path<T> getItemHistoryPath(Collection<String> fields, Root<MenardOrderItemHistory> orderItem) {
		Path<T> path = null;
		for (String field : fields) {
			if (path == null) {
				path = orderItem.get(field);
				continue;
			}
			path = path.get(field);
		}

		return path;
	}

	@Override
	public MenardOrderItemTrackingHistory saveOrderItemTrackingHistory(MenardOrderItemTrackingHistory history) {
		return em.merge(history);
	}

	@Override
	public MenardOrderItem readMenardOrderItemById(Long orderItemId) {
		return em.find(MenardDiscreteOrderItemImpl.class, orderItemId);
	}

	@Override
	public MenardOrderItem saveMenardDiscreateOrderItem(MenardOrderItem menardOrderItem) {
		return em.merge(menardOrderItem);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MenardOrderItem> findOrderItems(Long skuId, String storeNum) {
		Sku sku = em.find(MenardSkuImpl.class, skuId);
		if (sku == null) {
			return new ArrayList<MenardOrderItem>();
		}

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardOrderItem> criteria = builder.createQuery(MenardOrderItem.class);
		Root<MenardDiscreteOrderItemImpl> menardOrderItem = criteria.from(MenardDiscreteOrderItemImpl.class);

		criteria.select(menardOrderItem);

		Predicate finalPredicate = builder.conjunction();
		finalPredicate.getExpressions().add(builder.equal(menardOrderItem.get("sku"), sku));
		finalPredicate.getExpressions().add(builder.equal(menardOrderItem.get("menardOrder").get("storeId"), storeNum));
		finalPredicate.getExpressions().add(
				builder.equal(menardOrderItem.get("order").get("status"), OrderStatus.SUBMITTED.getType()));

		criteria.where(finalPredicate);
		criteria.orderBy(builder.desc(menardOrderItem.get("statusDate")));

		Query query = em.createQuery(criteria);
		query.setFirstResult(0);
		query.setMaxResults(5);

		return query.getResultList();
	}

	@Override
	public SearchResult<MenardOrderItem> findOrderItemsPage(MenardOrderItemFilterDTO filter) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardOrderItem> criteria = builder.createQuery(MenardOrderItem.class);
		Root<MenardDiscreteOrderItemImpl> orderItem = criteria.from(MenardDiscreteOrderItemImpl.class);

		Join<MenardDiscreteOrderItemImpl, MenardSkuImpl> skuJoin = orderItem.join("menardSku", JoinType.LEFT);
		Join<MenardDiscreteOrderItemImpl, MenardProductImpl> productJoin = orderItem.join("menardProduct",
				JoinType.LEFT);

		criteria.select(orderItem);

		// Append the order clause
		criteria.orderBy(getOrder(filter.getSort(), builder, orderItem, skuJoin, productJoin));

		Predicate finalPredicate = builder.conjunction();

		// Append conditions for order, first only get submitted order
		Join<MenardDiscreteOrderItemImpl, MenardOrderImpl> menardOrderJoin = orderItem.join("menardOrder");

		// Path<MenardOrderImpl> menardOrderJoin = orderItem.get("menardOrder");
		finalPredicate.getExpressions().add(
				builder.equal(menardOrderJoin.get("status"), OrderStatus.SUBMITTED.getType()));
		// if (StringUtils.isNotBlank(filter.getStoreId()) || filter.getDays() != null) {
		if (StringUtils.isNotBlank(filter.getStoreId())) {
			finalPredicate.getExpressions().add(builder.equal(menardOrderJoin.get("storeId"), filter.getStoreId()));
		}

		if (filter.getDays() != null) {
			Path<Date> dateCreatedPath = menardOrderJoin.get("submitDate");
			finalPredicate.getExpressions()
					.add(builder.greaterThanOrEqualTo(dateCreatedPath, (new DateTime()).minusDays(filter.getDays())
							.toDate()));
		}
		// }

		// Append condition from the order item
		if (StringUtils.isNotBlank(filter.getRequestType())) {
			String[] typeArray = StringUtils.split(filter.getRequestType(), CommonConstant.COMMA);
			Predicate typePredicate = builder.disjunction();
			for (String type : typeArray) {
				typePredicate.getExpressions().add(builder.equal(orderItem.get("requestType"), type));
			}
			finalPredicate.getExpressions().add(typePredicate);
		} else {
			finalPredicate.getExpressions().add(builder.isNull(orderItem.get("requestType")));
		}

		if (CollectionUtils.isNotEmpty(filter.getStatusSet())) {
			Predicate orderItemStatusPredicate = builder.disjunction();
			for (String status : filter.getStatusSet()) {
				orderItemStatusPredicate.getExpressions().add(builder.equal(orderItem.get("status"), status));
			}
			finalPredicate.getExpressions().add(orderItemStatusPredicate);
		}

		if (filter.getSkuId() != null) {
			Join<MenardDiscreteOrderItemImpl, MenardSkuImpl> skuIdJoin = orderItem.join("menardSku");
			Expression<String> menardSku = skuIdJoin.get("menardSku");
			Expression<String> skuCode = skuIdJoin.get("skuCode");
			String code = filter.getSkuId().toString();
			Predicate skucodePredicate = builder.and(builder.equal(skuCode, code), builder.isNull(menardSku));
			finalPredicate.getExpressions().add(builder.or(builder.equal(menardSku, code), skucodePredicate));
		}
		criteria.where(finalPredicate);
		TypedQuery<MenardOrderItem> query = em.createQuery(criteria);

		SearchResult<MenardOrderItem> result = new SearchResult<MenardOrderItem>();
		// Append the pagination information
		if (filter.getPage() != null && filter.getSize() != null) {
			result.setPage(filter.getPage());
			result.setPageSize(filter.getSize());
			result.setTotalResults(getTotalCount(builder, orderItem, finalPredicate).intValue());
			query.setFirstResult(getBeginningIndex(filter.getPage(), filter.getSize()));
			query.setMaxResults(filter.getSize());
		}

		List<MenardOrderItem> list = query.getResultList();
		result.setResult(list);
		return result;
	}
	
	@Override
	public SearchResult<MenardOrderItemHistory> findItemHistoryPage(MenardOrderItemFilterDTO filter) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardOrderItemHistory> criteria = builder.createQuery(MenardOrderItemHistory.class);
		Root<MenardOrderItemHistory> orderItem = criteria.from(MenardOrderItemHistory.class);
		
		criteria.select(orderItem);

		// Append the order clause
		criteria.orderBy(getItemHistoryOrder(filter.getSort(), builder, orderItem));

		Predicate finalPredicate = builder.conjunction();

		// Append conditions for order, first only get submitted order
		Join<MenardDiscreteOrderItemImpl, MenardOrderImpl> menardOrderJoin = orderItem.join("menardOrder");
		
		finalPredicate.getExpressions().add(
				builder.equal(menardOrderJoin.get("status"), OrderStatus.SUBMITTED.getType()));
		
		if (StringUtils.isNotBlank(filter.getStoreId())) {
			finalPredicate.getExpressions().add(builder.equal(menardOrderJoin.get("storeId"), filter.getStoreId()));
		}

		if (filter.getDays() != null) {
			Path<Date> dateCreatedPath = menardOrderJoin.get("submitDate");
			finalPredicate.getExpressions()
					.add(builder.greaterThanOrEqualTo(dateCreatedPath, (new DateTime()).minusDays(filter.getDays())
							.toDate()));
		}		

		// Append condition from the order item
		if (StringUtils.isNotBlank(filter.getRequestType())) {
			String[] typeArray = StringUtils.split(filter.getRequestType(), CommonConstant.COMMA);
			Predicate typePredicate = builder.disjunction();
			for (String type : typeArray) {
				typePredicate.getExpressions().add(builder.equal(orderItem.get("requestType"), type));
			}
			finalPredicate.getExpressions().add(typePredicate);
		}

		if (CollectionUtils.isNotEmpty(filter.getStatusSet())) {
			Predicate orderItemStatusPredicate = builder.disjunction();
			for (String status : filter.getStatusSet()) {
				orderItemStatusPredicate.getExpressions().add(builder.equal(orderItem.get("status"), status));
			}
			finalPredicate.getExpressions().add(orderItemStatusPredicate);
		}

		if (filter.getSkuId() != null) {		
			finalPredicate.getExpressions().add(builder.equal(orderItem.get("menardSkuStr"), filter.getSkuId()));
		}
		criteria.where(finalPredicate);
		TypedQuery<MenardOrderItemHistory> query = em.createQuery(criteria);

		SearchResult<MenardOrderItemHistory> result = new SearchResult<MenardOrderItemHistory>();
		// Append the pagination information
		if (filter.getPage() != null && filter.getSize() != null) {
			result.setPage(filter.getPage());
			result.setPageSize(filter.getSize());
			result.setTotalResults(getItemHistoryTotalCount(builder, orderItem, finalPredicate).intValue());
			query.setFirstResult(getBeginningIndex(filter.getPage(), filter.getSize()));
			query.setMaxResults(filter.getSize());
		}

		List<MenardOrderItemHistory> list = query.getResultList();
		result.setResult(list);
		return result;
	}
	
	/**
	 * Retrieve the total number of item history by the same constrains as
	 * search page
	 *
	 * @param builder CriteriaBuilder
	 * @param orderItem Root<MenardOrderItemHistory>
	 * @param finalPredicate Predicate
	 * @return Long
	 */
	private Long getItemHistoryTotalCount(CriteriaBuilder builder, Root<MenardOrderItemHistory> orderItem,
			Predicate finalPredicate) {
		CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
		countCriteria.getRoots().add(orderItem);
		countCriteria.select(builder.count(orderItem));
		countCriteria.where(finalPredicate);
		return em.createQuery(countCriteria).getSingleResult();
	}

	@Override
	public OrderItemAttribute createOrderItemAttribute() {
		return (OrderItemAttribute) entityConfiguration
				.createEntityInstance("org.broadleafcommerce.core.order.domain.OrderItemAttribute");
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MenardOrderItem> findOrderItems(int signId, String storeNum, String signType) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardOrderItem> criteria = builder.createQuery(MenardOrderItem.class);
		Root<MenardDiscreteOrderItemImpl> menardOrderItem = criteria.from(MenardDiscreteOrderItemImpl.class);

		criteria.select(menardOrderItem);

		Predicate finalPredicate = builder.conjunction();
		finalPredicate.getExpressions().add(builder.equal(menardOrderItem.get("signId"), signId));
		finalPredicate.getExpressions().add(builder.equal(menardOrderItem.get("menardOrder").get("storeId"), storeNum));

		Path<Date> dateCreatedPath = menardOrderItem.get("menardOrder").get("submitDate");
		finalPredicate.getExpressions().add(
				builder.greaterThanOrEqualTo(dateCreatedPath, (new DateTime()).minusDays(60).toDate()));

		if (StringUtils.equals(signType, SIGN_TYPE_SIGN)) {
			finalPredicate.getExpressions().add(
					menardOrderItem.get("status").in(MenardOrderItemStatus.IN_THE_MAIL.getValue(),
							MenardOrderItemStatus.PENDING_GM.getValue(), MenardOrderItemStatus.BACKORDERED.getValue()));

		} else if (StringUtils.equals(signType, SIGN_TYPE_COLOR_SIGN)) {
			finalPredicate.getExpressions().add(
					builder.equal(menardOrderItem.get("status"), MenardOrderItemStatus.PENDING_GM.getValue()));
		}

		criteria.where(finalPredicate);
		criteria.orderBy(builder.desc(menardOrderItem.get("statusDate")));

		Query query = em.createQuery(criteria);
		query.setFirstResult(0);
		query.setMaxResults(10);

		return query.getResultList();
	}

	/**
	 *
	 * @param builder CriteriaBuilder
	 * @param orderItem MenardDiscreteOrderItem
	 * @param finalPredicate Predicate
	 * @return Long
	 */
	private Long getTotalCount(CriteriaBuilder builder, Root<MenardDiscreteOrderItemImpl> orderItem,
			Predicate finalPredicate) {
		CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
		countCriteria.getRoots().add(orderItem);
		countCriteria.select(builder.count(orderItem));
		countCriteria.where(finalPredicate);
		return em.createQuery(countCriteria).getSingleResult();
	}

	/**
	 *
	 * @param page Integer
	 * @param size Integer
	 * @return Integer
	 */
	private Integer getBeginningIndex(Integer page, Integer size) {
		Integer begin = (page - 1) * size;
		begin = begin > 0 ? begin : 0;
		return begin;
	}
	
	@Override
	public void flush() {
		em.flush();
	}

    /**
     * count the total number of all order items awaiting approval
     *
     * @return count long
     */
    @Override
    public long countOrderItemsForApprove() {
        MenardUserDetails userDetails = MenardSecurityContextHolder.getMenardUserDetails();
        String role = userDetails.getFulfillerType();
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("SELECT Count(*) ");
        sqlBuilder.append("FROM   MENARD_DISCRETE_ORDER_ITEM oi, ");
        sqlBuilder.append("       MENARD_ORDER mo, ");
        sqlBuilder.append("       BLC_ORDER bo ");
        sqlBuilder.append("WHERE  oi.ORDER_ID = mo.ORDER_ID ");
        sqlBuilder.append("       AND bo.ORDER_ID = mo.ORDER_ID ");
        sqlBuilder.append("       AND bo.ORDER_STATUS = 'SUBMITTED' ");
        if (MenardFulfillerType.GENERAL_MANAGER.getKey().equalsIgnoreCase(role)) {
            sqlBuilder.append(" AND mo.STORE_ID = " + userDetails.getStoreNumber());
        } else if (StringUtils.isNotBlank(role) 
        		&& !MenardFulfillerType.SUPER_GO.getKey().equalsIgnoreCase(role)) {
            // not Super GO and not store user
            sqlBuilder.append(" AND oi.FULFILLER_TYPE = '" + role + SINGLE_QUOTE_MARK);
        }
        if (StringUtils.isNotBlank(role)) {
            List<String> statusList;
            if (MenardFulfillerType.GENERAL_MANAGER.getKey().equals(role)) {
                statusList = Arrays.asList(MenardOrderItemStatus.PENDING_GM.getValue());
            } else {
                statusList = Arrays.asList(MenardOrderItemStatus.PENDING_GO.getValue());
            }
            String inClauseParams = SINGLE_QUOTE_MARK + StringUtils.join(statusList, "','") + SINGLE_QUOTE_MARK;
            sqlBuilder.append(" AND oi.STATUS in (" + inClauseParams + ")"); 
            
            Set<String> set = getRequestTypeCodes(userDetails);
            sqlBuilder.append(" AND oi.REQUEST_TYPE in ('" + StringUtils.join(set, "','") + "')");
        }
        Query query = em.createNativeQuery(sqlBuilder.toString());
        Object count = query.getSingleResult();
        return count != null ? Long.valueOf(count.toString()) : 0;
    }
    
    private Set<String> getRequestTypeCodes(MenardUserDetails userDetails) {
    	String operationType = userDetails.getOperationsType();
		String factTagRequestType = userDetails.getFactTagRequestType();
		String role = userDetails.getFulfillerType();
        Collection<MenardOrderRequestType> list = MenardOrderRequestType.getReqeustTypeByRoleType(role, operationType, factTagRequestType);
        Set<String> set = new HashSet<String>();
        for (MenardOrderRequestType menardOrderRequestType : list) {
        	set.add(menardOrderRequestType.getKey());
		}
        return set;
    }
}
