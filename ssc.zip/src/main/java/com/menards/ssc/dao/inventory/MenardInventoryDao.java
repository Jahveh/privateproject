package com.menards.ssc.dao.inventory;

import java.util.List;

import com.menards.ssc.domain.inventory.MenardInventoryDTO;
import com.menards.ssc.domain.yard.Store;

/**
 *
 * <p>MenardInventoryDao</p>
 * <p>An Menard Inventory Dao that provides convenience methods and resource declarations for database access.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public interface MenardInventoryDao {

	/**
	 *
	 * Get Inventory
	 * @return List list
	 */
	public List<MenardInventoryDTO> getInventory();

	/**
	 *
	 * Get Inventory by SKU
	 * @param sku sku
	 * @return MenardInventoryDTO MenardInventoryDTO
	 */
	public List<MenardInventoryDTO> getInventoryBySku(String sku);

	/**
	 * 
	 * Logs the inventory event in the database
	 * @param storeNumber storeNumber
	 * @param application application
	 * @param messageCode messageCode
	 */
	public void logEvent(String storeNumber, String application, int messageCode);

	/**
	 * getIncomplete903Inventory()
	 * Gets a list of stores that have not completed their 903/933
	 * inventory this month.
	 * Note: This was intended to be run once a month between midnight and 1 am.
	 * Should this be run manually, results from the current day will be ignored.
	 * current day.
	 * @return - list of stores that did not complete inventory, but have orders in Store Supplies
	 */
	public List<Store> getIncomplete903Inventory();

}
