package com.menards.ssc.dao.product;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.broadleafcommerce.core.catalog.dao.ProductDaoImpl;
import org.broadleafcommerce.core.catalog.domain.*;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardProductImpl;
import com.menards.ssc.domain.catalog.MenardProductOption;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.catalog.MenardSkuImpl;
import com.menards.ssc.domain.catalog.ProductFilter;

/**
 *
 * <p>MenardProductDao</p>
 * <p>operation of product</p>
 * <p>
 * search products
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class MenardProductDaoImpl extends ProductDaoImpl implements MenardProductDao {

	public static final String CATEGORY_PRODUCT_XREF = "categoryProductXref";

	@Override
	public Long countProductForCategory(Category category, List<ProductFilter> productFilters) {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);

		Root<CategoryProductXrefImpl> productXref = criteria.from(CategoryProductXrefImpl.class);

		criteria.select(builder.count(productXref));

		Predicate finalPredicate = builder.conjunction();

		finalPredicate.getExpressions().add(
				builder.equal(productXref.get(CATEGORY_PRODUCT_XREF).get("category"), category));

		finalPredicate.getExpressions().add(
				builder.notEqual(
						productXref.get(CATEGORY_PRODUCT_XREF).get("product").get("archiveStatus").get("archived"),
						CommonConstant.ARCHIVED_Y));

        if (productFilters != null && !productFilters.isEmpty()) {
            for (ProductFilter productFilter: productFilters) {
                if (StringUtils.isNotBlank(productFilter.getAttributeName())
                        && StringUtils.isNotBlank(productFilter.getAttributeValue())) {
                    Root<ProductAttributeImpl> productAttribute = criteria.from(ProductAttributeImpl.class);
                    finalPredicate.getExpressions().add(
                            builder.equal(productXref.get(CATEGORY_PRODUCT_XREF).get("product"),
                                    productAttribute.get("product"))
                    );
                    finalPredicate.getExpressions().add(
                            builder.equal(productAttribute.get("name"), productFilter.getAttributeName()));
                    finalPredicate.getExpressions().add(
                            builder.equal(productAttribute.get("value"), productFilter.getAttributeValue()));
                }
            }
        }
        criteria.where(finalPredicate);

		TypedQuery<Long> query = em.createQuery(criteria);

		return query.getSingleResult();

	}

	@Override
	public List<Product> findProductsByCategoryId(Long categoryId, int limit, int offset, List<ProductFilter> productFilters,
			List<String> productIds) {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<CategoryProductXref> criteria = builder.createQuery(CategoryProductXref.class);

		Root<CategoryProductXrefImpl> productXref = criteria.from(CategoryProductXrefImpl.class);

		criteria.select(productXref);

		Category category = new CategoryImpl();
		category.setId(categoryId);

		Predicate finalPredicate = builder.conjunction();

		finalPredicate.getExpressions().add(
				builder.equal(productXref.get(CATEGORY_PRODUCT_XREF).get("category"), category));

		if (productIds != null && !productIds.isEmpty()) {
			finalPredicate.getExpressions().add(
					productXref.get(CATEGORY_PRODUCT_XREF).get("product").get("id").in(productIds));
		}

		finalPredicate.getExpressions().add(
				builder.notEqual(
						productXref.get(CATEGORY_PRODUCT_XREF).get("product").get("archiveStatus").get("archived"),
						CommonConstant.ARCHIVED_Y));

        if (productFilters != null && !productFilters.isEmpty()) {
            for (ProductFilter productFilter : productFilters) {
                if (StringUtils.isNotBlank(productFilter.getAttributeName())
                        && StringUtils.isNotBlank(productFilter.getAttributeValue())) {
                    Root<ProductAttributeImpl> productAttribute = criteria.from(ProductAttributeImpl.class);
                    finalPredicate.getExpressions().add(
                            builder.equal(productXref.get(CATEGORY_PRODUCT_XREF).get("product"),
                                    productAttribute.get("product"))
                    );
                    finalPredicate.getExpressions().add(
                            builder.equal(productAttribute.get("name"), productFilter.getAttributeName()));
                    finalPredicate.getExpressions().add(
                            builder.equal(productAttribute.get("value"), productFilter.getAttributeValue()));
                }
            }
        }

		criteria.where(finalPredicate);

		TypedQuery<CategoryProductXref> query = em.createQuery(criteria);
		query.setFirstResult(offset);
		query.setMaxResults(limit);

		List<Product> products = new ArrayList<Product>();
		List<CategoryProductXref> xrefs = query.getResultList();
		for (CategoryProductXref xref : xrefs) {
			products.add(xref.getProduct());
		}

		return products;
	}

	@Override
	public List<Product> findAllProductsByCategoryId(Long categoryId, List<ProductFilter> productFilters) {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<CategoryProductXref> criteria = builder.createQuery(CategoryProductXref.class);

		Root<CategoryProductXrefImpl> productXref = criteria.from(CategoryProductXrefImpl.class);

		criteria.select(productXref);

		Category category = new CategoryImpl();
		category.setId(categoryId);

		Predicate finalPredicate = builder.conjunction();

		finalPredicate.getExpressions().add(
				builder.equal(productXref.get(CATEGORY_PRODUCT_XREF).get("category"), category));

		finalPredicate.getExpressions().add(
				builder.notEqual(
						productXref.get(CATEGORY_PRODUCT_XREF).get("product").get("archiveStatus").get("archived"),
						CommonConstant.ARCHIVED_Y));

        if (productFilters != null && !productFilters.isEmpty()) {
            for (ProductFilter productFilter : productFilters) {
                if (StringUtils.isNotBlank(productFilter.getAttributeName())
                        && StringUtils.isNotBlank(productFilter.getAttributeValue())) {
                    Root<ProductAttributeImpl> productAttribute = criteria.from(ProductAttributeImpl.class);
                    finalPredicate.getExpressions().add(
                            builder.equal(productXref.get(CATEGORY_PRODUCT_XREF).get("product"),
                                    productAttribute.get("product"))
                    );
                    finalPredicate.getExpressions().add(
                            builder.equal(productAttribute.get("name"), productFilter.getAttributeName()));
                    finalPredicate.getExpressions().add(
                            builder.equal(productAttribute.get("value"), productFilter.getAttributeValue()));
                }
            }
        }

		criteria.where(finalPredicate);

		TypedQuery<CategoryProductXref> query = em.createQuery(criteria);

		List<Product> products = new ArrayList<>();
		List<CategoryProductXref> xrefs = query.getResultList();
		for (CategoryProductXref xref : xrefs) {
			products.add(xref.getProduct());
		}

		return products;
	}


    @Override
   	public List<Product> findAllProductsByCategoryId(Long categoryId) {
   		CriteriaBuilder builder = em.getCriteriaBuilder();
   		CriteriaQuery<CategoryProductXref> criteria = builder.createQuery(CategoryProductXref.class);
   		Root<CategoryProductXrefImpl> productXref = criteria.from(CategoryProductXrefImpl.class);
   		criteria.select(productXref);

   		Category category = new CategoryImpl();
   		category.setId(categoryId);

   		Predicate finalPredicate = builder.conjunction();
   		finalPredicate.getExpressions().add(
   				builder.equal(productXref.get(CATEGORY_PRODUCT_XREF).get("category"), category));
   		finalPredicate.getExpressions().add(
   				builder.notEqual(
   						productXref.get(CATEGORY_PRODUCT_XREF).get("product").get("archiveStatus").get("archived"),
   						CommonConstant.ARCHIVED_Y));
   		criteria.where(finalPredicate);

        List<Product> products = new ArrayList<>();
   		TypedQuery<CategoryProductXref> query = em.createQuery(criteria);
   		List<CategoryProductXref> xrefs = query.getResultList();
   		for (CategoryProductXref xref : xrefs) {
   			products.add(xref.getProduct());
   		}

   		return products;
   	}

	@Override
	public MenardProduct getMenardProductById(Long productId) {
		return em.find(MenardProductImpl.class, productId);
	}

	@Override
	public List<MenardProductOption> getAccessoriesByProduct(MenardProduct product) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardProductOption> criteria = builder.createQuery(MenardProductOption.class);

		Root<MenardProductOption> productOption = criteria.from(MenardProductOption.class);

		criteria.select(productOption);

		Predicate finalPredicate = builder.equal(productOption.get("menardProductOptionPK").get("baseMenardProduct"),
				product);

		criteria.where(finalPredicate);

		TypedQuery<MenardProductOption> query = em.createQuery(criteria);

		return query.getResultList();
	}

	public static final int SKU_STATUS_DELETED = 3;

	@Override
	public List<MenardSku> findSkuByMenardSku(String menardSku) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardSku> criteria = builder.createQuery(MenardSku.class);

		Root<MenardSkuImpl> menardSkuImpl = criteria.from(MenardSkuImpl.class);

		criteria.select(menardSkuImpl);
		Predicate finalPredicate = builder.equal(menardSkuImpl.get("menardSku"), menardSku);

		criteria.where(finalPredicate);

		TypedQuery<MenardSku> query = em.createQuery(criteria);
		return query.getResultList();
	}

	@Override
	public String getProductVendorLogoByKey(String vendor) {
		Query query = em.createNativeQuery("select vendor_logo from MENARD_VENDOR where vendor='" + vendor + "'");
		@SuppressWarnings("unchecked")
		List<String> objectArray = query.getResultList();
		if (CollectionUtils.isNotEmpty(objectArray)) {
			if (StringUtils.isNotEmpty(objectArray.get(0))) {
				return objectArray.get(0);
			}
		}
		return null;
	}

//	/**
//	 * find ProductFilter By CategoryId
//	 * @param categoryId categoryId
//	 * @return ProductFilter ProductFilter
//	 */
//	@SuppressWarnings("unchecked")
//	public ProductFilter findProductFilterByCategoryId(Long categoryId) {
//		StringBuilder builder = new StringBuilder().append("SELECT c.name, ").append("       c.value ")
//				.append("  FROM BLC_CATEGORY_ATTRIBUTE c ").append(" WHERE category_id = :categoryId ")
//				.append("       AND c.name IN ( :filterFlag, :filterAttr, :filterName, :filterOptions )")
//				.append(" ORDER BY c.name ");
//		Query query = em.createNativeQuery(builder.toString());
//		query.setParameter("categoryId", categoryId);
//		query.setParameter("filterFlag", ProductFilterEnum.FILTER_FLAG.getColumnName());
//		query.setParameter("filterAttr", ProductFilterEnum.FILTER_ATTRIBUTE.getColumnName());
//		query.setParameter("filterName", ProductFilterEnum.FILTER_NAME.getColumnName());
//		query.setParameter("filterOptions", ProductFilterEnum.FILTER_OPTIONS.getColumnName());
//		List<Object[]> resultList = query.getResultList();
//		ProductFilter productFilter = null;
//		if (resultList != null && resultList.size() == 4) { // all of the above 4 attributes are required to make
//															// category filter functional
//			productFilter = new ProductFilter();
//			productFilter.setCategoryId(categoryId);
//			for (Object[] row : resultList) {
//				if (ProductFilterEnum.FILTER_FLAG.getColumnName().equalsIgnoreCase((String) row[0])) {
//					String filterFlag = (String) row[1];
//					productFilter.setEnabled("N".equalsIgnoreCase(filterFlag));
//
//				} else if (ProductFilterEnum.FILTER_ATTRIBUTE.getColumnName().equalsIgnoreCase((String) row[0])) {
//					String filterAttr = (String) row[1];
//					productFilter.setAttributeName(filterAttr);
//
//				} else if (ProductFilterEnum.FILTER_NAME.getColumnName().equalsIgnoreCase((String) row[0])) {
//					String filterName = (String) row[1];
//					productFilter.setName(filterName);
//
//				} else if (ProductFilterEnum.FILTER_OPTIONS.getColumnName().equalsIgnoreCase((String) row[0])) {
//					String filterOptionsString = (String) row[1];
//					productFilter.setOptionsJoined(filterOptionsString);
//				}
//			}
//		}
//		return productFilter;
//	}

	/**
	 * 
	 * Get full name of vendor from menard_vendor table by category ID
	 * @param categoryId categoryId
	 * @return Map Map
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getVendorToFullNameMap(Long categoryId) {
        StringBuilder builder = new StringBuilder();
        builder.append("SELECT pa.value, ");
        builder.append("       IFNULL(v.full_name, '') AS name ");
        builder.append("FROM   BLC_PRODUCT p, ");
        builder.append("       BLC_CATEGORY_PRODUCT_XREF ref, ");
        builder.append("       BLC_PRODUCT_ATTRIBUTE pa ");
        builder.append("       LEFT JOIN MENARD_VENDOR v ");
        builder.append("              ON v.vendor = pa.value ");
        builder.append("WHERE  p.archived = 'N' ");
        builder.append("       AND ref.category_id = :categoryId ");
        builder.append("       AND pa.name = 'Vendor' ");
        builder.append("       AND p.product_id = ref.product_id ");
        builder.append("       AND pa.product_id = p.product_id ");
        builder.append("GROUP  BY pa.value ");
        builder.append("ORDER  BY pa.value ASC ");
		Query query = em.createNativeQuery(builder.toString());
		query.setParameter("categoryId", categoryId);
		List<Object[]> resultList = query.getResultList();
        Map<String, String> filterOptionsMap = null;
		if (resultList != null && !resultList.isEmpty()) {
            filterOptionsMap = new LinkedHashMap<>(resultList.size());
			for (Object[] option : resultList) {
				if (option.length == 2) {
					String vendorValue = (String) option[0];
					String fullName = (String) option[1];
					filterOptionsMap.put(vendorValue, fullName);
				}
			}
		}
		return filterOptionsMap;
	}

	/**
	 *
     * Get product filter options map by category Id and attribute names
     *
	 * @param categoryId categoryId
	 * @param attributeNames attributeNames
	 * @return Map
	 */
	@SuppressWarnings("unchecked")
	public List<ProductFilter.Option> getProductFilterOptions(Long categoryId, String attributeNames) {
        String attrNamesParamStr = "'" + attributeNames.replaceAll(",", "','") + "'";
		StringBuilder builder = new StringBuilder().append("SELECT pa.name, pa.value ").append("  FROM BLC_PRODUCT p, ")
				.append("       BLC_CATEGORY_PRODUCT_XREF ref, ").append("       BLC_PRODUCT_ATTRIBUTE pa ")
				.append(" WHERE ref.category_id = :categoryId ").append("       AND p.archived = 'N' ")
				.append("       AND pa.name in (" + attrNamesParamStr + ")").append("       AND p.product_id = ref.product_id ")
				.append("       AND pa.product_id = p.product_id ").append(" GROUP BY pa.value ")
				.append(" ORDER BY pa.name, pa.value ");
		Query query = em.createNativeQuery(builder.toString());
		query.setParameter("categoryId", categoryId);
        List<Object[]> filtersList = query.getResultList();
        List<ProductFilter.Option> filterOptions = new ArrayList<>(filtersList.size());
        if (!filtersList.isEmpty()) {
            for (Object[] row : filtersList) {
                if (row.length == 2) {
                    String attrName = (String) row[0];
                    String optionValue = (String) row[1];
                    ProductFilter.Option option = new ProductFilter.Option(attrName, optionValue);
                    filterOptions.add(option);
                }
            }
        }
        return filterOptions;
	}

    @Override
    public List<CategoryAttribute> getCategoryAttributes(Long categoryId) {
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<CategoryAttribute> criteria = builder.createQuery(CategoryAttribute.class);
        Root<CategoryAttributeImpl> categoryAttribute = criteria.from(CategoryAttributeImpl.class);

        criteria.select(categoryAttribute);

        Category category = new CategoryImpl();
        category.setId(categoryId);
        Predicate finalPredicate = builder.conjunction();
        finalPredicate.getExpressions().add(builder.equal(categoryAttribute.get("category"), category));

        criteria.where(finalPredicate);

        List<CategoryAttribute> attributes = em.createQuery(criteria).getResultList();
        return attributes;
    }

    @Override
        public List<CategoryAttribute> getCategoryAttributes(String path) {
            CriteriaBuilder builder = em.getCriteriaBuilder();
            CriteriaQuery<CategoryAttribute> criteria = builder.createQuery(CategoryAttribute.class);
            Root<CategoryAttributeImpl> categoryAttribute = criteria.from(CategoryAttributeImpl.class);

            criteria.select(categoryAttribute);

            Predicate finalPredicate = builder.conjunction();
            finalPredicate.getExpressions().add(builder.equal(categoryAttribute.get("category").get("url"), path));

            criteria.where(finalPredicate);

            List<CategoryAttribute> attributes = em.createQuery(criteria).getResultList();
            return attributes;
        }

    @Override
    public List<ProductAttribute> getProductAttributes(Long productId) {
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<ProductAttribute> criteria = builder.createQuery(ProductAttribute.class);
        Root<ProductAttributeImpl> productAttribute = criteria.from(ProductAttributeImpl.class);

        criteria.select(productAttribute);

        Product product = new ProductImpl();
        product.setId(productId);
        Predicate finalPredicate = builder.conjunction();
        finalPredicate.getExpressions().add(builder.equal(productAttribute.get("product"), product));

        criteria.where(finalPredicate);

        List<ProductAttribute> attributes = em.createQuery(criteria).getResultList();
        return attributes;
    }

    @Override
    public List<SkuAttribute> getSkuAttributes(Long skuId) {
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<SkuAttribute> criteria = builder.createQuery(SkuAttribute.class);
        Root<SkuAttributeImpl> skuAttribute = criteria.from(SkuAttributeImpl.class);

        criteria.select(skuAttribute);

        Sku sku = new SkuImpl();
        sku.setId(skuId);
        Predicate finalPredicate = builder.conjunction();
        finalPredicate.getExpressions().add(builder.equal(skuAttribute.get("sku"), sku));

        criteria.where(finalPredicate);

        List<SkuAttribute> attributes = em.createQuery(criteria).getResultList();
        return attributes;
    }
}
