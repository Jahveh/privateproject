/**
 *
 */
package com.menards.ssc.dao.product;

import java.util.Collection;
import java.util.List;

import com.menards.ssc.domain.catalog.MenardProductDesc;
import com.menards.ssc.domain.catalog.SearchResult;

/**
 * <p>MenardSkuDaoImpl</p>
 * <p>Provide the database access related to search supplies</p>
 * <p>
 *    This search is divided into two steps: one is using full text to find
 *    all the matched sku's id and then retrieve these skus.
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public interface MenardProductDescDao {
	
	/**
	 * Retrieve the sku codes by full text search
	 * @param text String
	 * @return List<Integer>
	 */
	public List<Integer> fulltextSearchSkuCode(String text);

	/**
	 * Find all skus according to the text
	 * @param page Integer
	 * @param size Integer
	 * @param text String
	 * @param skucodes Collection<Integer>
	 * @return SearchResult<MenardProductDesc>
	 */
	public SearchResult<MenardProductDesc> findDescPage(Integer page, Integer size, String text,
			Collection<String> skucodes);

	
	/**
	 * Retrieve the skucode for sku class feature
	 * @param text String
	 * @return List<Integer>
	 */
	public List<Integer> findSkuCodesForSkuClass(String text);
	
	/**
	 * Find all product description according to the sku code
	 * @param page Integer
	 * @param size Integer
	 * @param text String
	 * @param skucodes Collection<String>
	 * @return SearchResult<MenardProductDesc>
	 */
	public SearchResult<MenardProductDesc> findProductDescPage(Integer page, Integer size, String text,
			Collection<String> skucodes);

	/**
	 * @param menardProductDesc MenardProductDesc
	 * @return MenardProductDesc MenardProductDesc
	 */
	public MenardProductDesc saveMenardProductDesc(MenardProductDesc menardProductDesc);

	/**
	 * Remove product desc from database
	 * @param menardProductDesc MenardProductDesc
	 */
	public void removeMenardProductDesc(MenardProductDesc menardProductDesc);

	/**
	 * Find product description list according to sku code and createdby. 
	 * @param keyCol Collection<String>
	 * @param createdBy Collection<String>
	 * @return List<MenardProductDesc>
	 */
	public List<MenardProductDesc> findDescList(Collection<String> keyCol, Collection<String> createdBy);

	/**
	 * Batchly update the product description 
	 * @param createdBy String
	 * @return int
	 */
	public int resetOpenSkuProductDesc(String createdBy);

	/**
	 * Post deal with some relevant data	
	 * @return int
	 */
	public int postUpdateDescSkuType();

	/**
	 * Find all product description according to specific sql
	 * 
	 * @return List<MenardProductDesc>
	 */
	public List<MenardProductDesc> findSkuProductInfo();

	/**
	 * detachMenardProductDesc
	 * @param menardProductDesc detachMenardProductDesc
	 */
	public void detachMenardProductDesc(MenardProductDesc menardProductDesc);

}
