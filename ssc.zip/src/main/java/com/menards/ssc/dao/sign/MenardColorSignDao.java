/**
 * 
 */
package com.menards.ssc.dao.sign;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.menards.ssc.domain.catalog.ColorSignDTO;
import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.navigation.CategoryTreeNode;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.enums.SignSearchType;

/**
 * <p>MenardColorSignDao</p>
 * <p></p>
 * <p>
 * Provide some method to color sign database
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public interface MenardColorSignDao {

	/**
	 * 
	 * @param sign Sign
	 * @param item OrderItem
	 */
	public void insertSignOrder(Sign sign, MenardOrderItem item);

	/**
	 * Get the total page of color sign
	 * @param text text
	 * @param yardNum yardNum
	 * @return colorSignCount
	 */
	public int findColorSignCount(String text, Integer yardNum);

    public int findColorSignCatalogId(Integer signId);

	/**
	 * search color sign and display in one page
	 * @param page Integer
	 * @param size Integer
	 * @param text String
	 * @param yardNum Integer
	 * @return SearchResult<Sign>
	 */
	public SearchResult<Sign> findColorSignPage(Integer page, Integer size, String text, Integer yardNum);

	/**
	 * 
	 * search color sign and display in one page with specified index
	 * @param beignIndex beignIndex
	 * @param endIndex endIndex
	 * @param text text
	 * @param yardNum yardNum
	 * @return Sign
	 */
	public SearchResult<Sign> findColorSignPageWithIndex(int beignIndex, int endIndex, String text, Integer yardNum);

	/**
	 * get sign by sign Id
	 * @param signId signId
	 * @param yard yard
	 * @param type type
	 * @return  ColorSignDTO ColorSignDTO
	 */
	public ColorSignDTO getSign(final String signId, Integer yard, SignSearchType type);

	/**
	 * Retrieve all the yard
	 * @param signId int
	 * @return List<String>
	 */
	public List<String> getYardList(int signId);

	/**
	 * Retrieve specific sign by its id
	 * @param signId String
	 * @return Sign
	 */
	public Sign findSignById(Integer signId);

	/**
	 * Retrieve a collection of signs with sign ids
	 * @param signIdCol Collection<Integer>
	 * @return List<Sign>
	 */
	public Map<Integer, Sign> findSignListById(Collection<Integer> signIdCol);

	/**
	 * get sign by catalog Id
	 * @param catalogID catalogID
	 * @param limit limit
	 * @param offset offset
	 * @return List List
	 */
	List<Sign> getSignsByCatalogID(long catalogID, int limit, int offset);
	
	/**
	 * Get the quantity of color sign
	 * @param signId int
	 * @param locationId int
	 * @param leadTime int
	 * @return int
	 */
	public int getQuantityOrdered(int signId, int locationId, int leadTime);

	/**
	 * get sign by catalog Id
	 * @param catalogID catalogID
	 * @return long long
	 */ 
	long countByCatalogID(long catalogID);

	/**
	 * 
	 * @return List List
	 */
	List<CategoryTreeNode> getColorSignCategorList();

}
