package com.menards.ssc.dao.breadcrumb;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.menards.ssc.domain.breadcrumb.BreadCrumbConfig;

/**
 * 
 * <p>BreadCrumbConfigDao</p>
 * <p>Dao class for manipulating BREAD_CRUMB_CONFIG table</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
@Repository("breadCrumbConfigDao")
public class BreadCrumbConfigDaoImpl implements BreadCrumbConfigDao {

	@PersistenceContext(unitName = "blPU")
	private EntityManager em;

	@Override
	public List<BreadCrumbConfig> readAllBreadCrumbConfigs() {
		return em.createQuery("from BreadCrumbConfig", BreadCrumbConfig.class).getResultList();

	}

}
