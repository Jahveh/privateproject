package com.menards.ssc.dao.product;

import java.util.List;
import java.util.Map;

import org.broadleafcommerce.core.catalog.dao.ProductDao;
import org.broadleafcommerce.core.catalog.domain.*;

import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardProductOption;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.catalog.ProductFilter;

/**
 *
 * <p>MenardProductDao</p>
 * <p>operation of product</p>
 * <p>
 * search products
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public interface MenardProductDao extends ProductDao {

	/**
	 * return  the number of product for category
	 *
	 * @param category Category
	 * @param productFilters productFilter
	 * @return Long
	 */
	Long countProductForCategory(Category category, List<ProductFilter> productFilters);

	/**
	 * get menard product by product id
	 * @param productId Long
	 * @return MenardProduct
	 */
	MenardProduct getMenardProductById(Long productId);

	/**
	 * get accessories by product including optional and require
	 * @param product MenardProduct
	 * @return  List<MenardProductOption> List<MenardProduct>
	 */
	List<MenardProductOption> getAccessoriesByProduct(MenardProduct product);

	/**
	 * get menard sku status by storeId and skuCode
	 * @param storeId storeId
	 * @param skuCode skuCode
	 * @return MenardSkuStatus MenardSkuStatus
	 */
	// MenardSkuStatus getMenardSkuStatus(String storeId, String skuCode);

	/**
	 * get menard sku status by skuCode for GO User
	 * @param skuCode skuCode
	 * @return String MenardSkuStatus
	 */
	// List<String> getMenardSkuStatus(String skuCode);

	/**
	 * find products by category Id with pagenation
	 * @param categoryId categoryId
	 * @param limit start
	 * @param offset size
	 * @param productFilters productFilter
	 * @param productIds List<String>
	 * @return List<MenardProduct> list
	 */
	List<Product> findProductsByCategoryId(Long categoryId, int limit, int offset, List<ProductFilter> productFilters,
			List<String> productIds);

	/**
	 *
	 * @param storeId String
	 * @param skuCode Collection<Long>
	 * @return List<MenardSkuStatus>
	 */
	// List<MenardSkuStatus> findMenardSkuStatus(String storeId, Collection<Long> skuCode);

	/**
	 * find menard sku by menard sku
	 * @param menardSku menardSku
	 * @return menardSku
	 */
	List<MenardSku> findSkuByMenardSku(String menardSku);

	/**
	 * Find menard sku status according to its' pk list
	 * @param pkCol Collection<MenardSkuStatus.Pk>
	 * @return List<MenardSkuStatus>
	 */
	// public List<MenardSkuStatus> findMenardSkuStatus(Collection<MenardSkuStatus.Pk> pkCol);

	/**
	 * Persistent menard sku status
	 * @param menardSkuStatus MenardSkuStatus
	 * @return MenardSkuStatus
	 */
	// public void saveMenardSkuStatus(MenardSkuStatus menardSkuStatus);

	/**
	 *get logo url
	 * @param key key
	 * @return logo logo
	 */
	public String getProductVendorLogoByKey(String key);

    /**
     * Get vendor and vendor_name attribute of all the products under a category and put vendor
     * value as key and vendor_name value as value into a map.
     * @param categoryId
     * @return
     */
    Map<String, String> getVendorToFullNameMap(Long categoryId);

	/**
	 * 
	 * get Product Filter Options
	 * @param categoryId categoryId
	 * @param attributeNames attribute
	 * @return Map Map
	 */
    List<ProductFilter.Option> getProductFilterOptions(Long categoryId, String attributeNames);

	/**
	 * get all products under a category
	 * @param id Long
	 * @param productFilters ProductFilter
	 * @return products List<Product>
	 */
	List<Product> findAllProductsByCategoryId(Long id, List<ProductFilter> productFilters);

    /**
     * Get all products under a category
     *
     * @param categoryId
     * @return
     */
    List<Product> findAllProductsByCategoryId(Long categoryId);

    /**
     * Get category attribute by category ID
     *
     * @param categoryId
     * @return
     */
    List<CategoryAttribute> getCategoryAttributes(Long categoryId);

    /**
     * Get category attribute by category path
     *
     * @param categoryPath
     * @return
     */
    List<CategoryAttribute> getCategoryAttributes(String categoryPath);

    /**
     * Get product attribute by product ID
     *
     * @param productId
     * @return
     */
    List<ProductAttribute> getProductAttributes(Long productId);

    /**
     * Get SKU attribute by SKU ID
     *
     * @param skuId
     * @return
     */
    List<SkuAttribute> getSkuAttributes(Long skuId);
}
