package com.menards.ssc.dao.order;

import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang.StringUtils;
import org.broadleafcommerce.core.order.dao.OrderDaoImpl;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.service.type.OrderStatus;
import org.joda.time.DateTime;
import org.springframework.stereotype.Repository;

import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderImpl;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.domain.order.MenardOrderItemHistory;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

/**
 *
 * <p>MenardOrderDaoImpl</p>
 * <p>Menard OrderDao Impl is documented with database access logic</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
@Repository("menardOrderDao")
public class MenardOrderDaoImpl extends OrderDaoImpl implements MenardOrderDao {

	@Override
	public SearchResult<MenardOrder> getOrderByPagination(MenardOrderItemFilterDTO filter) {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardOrder> criteria = builder.createQuery(MenardOrder.class);
		Root<MenardOrderImpl> menardOrder = criteria.from(MenardOrderImpl.class);

		criteria.select(menardOrder);

		Predicate finalPredicate = builder.conjunction();

		finalPredicate.getExpressions().add(builder.equal(menardOrder.get("status"), OrderStatus.SUBMITTED.getType()));

		if (StringUtils.isNotBlank(filter.getStoreId())) {

			finalPredicate.getExpressions().add(builder.equal(menardOrder.get("storeId"), filter.getStoreId()));
		}

		Path<Date> dateCreatedPath = menardOrder.get("submitDate");

		if (filter.getDays() != null) {
			// Path<Date> dateCreatedPath = menardOrder.get("submitDate");
			finalPredicate.getExpressions()
					.add(builder.greaterThanOrEqualTo(dateCreatedPath, (new DateTime()).minusDays(filter.getDays())
							.toDate()));
		}

		if (filter.getOrderId() != null) {
			finalPredicate.getExpressions().add(builder.equal(menardOrder.get("id"), filter.getOrderId()));
		}

		criteria.orderBy(builder.desc(dateCreatedPath));

		criteria.where(finalPredicate);
		TypedQuery<MenardOrder> query = em.createQuery(criteria);
		SearchResult<MenardOrder> result = new SearchResult<MenardOrder>();
		if (filter.getPage() != null && filter.getSize() != null) {
			result.setPage(filter.getPage());
			result.setPageSize(filter.getSize());
			result.setTotalResults(getTotalCount(builder, menardOrder, finalPredicate).intValue());
			query.setFirstResult(getBeginningIndex(filter.getPage(), filter.getSize()));
			query.setMaxResults(filter.getSize());
		}

		List<MenardOrder> list = query.getResultList();
		result.setResult(list);
		return result;

	}
	
	
	@Override
	public SearchResult<MenardOrder> findOrdersByUserId(MenardOrderItemFilterDTO filter,String userId, OrderStatus status) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardOrder> criteria = builder.createQuery(MenardOrder.class);
		Root<MenardOrderImpl> menardOrder = criteria.from(MenardOrderImpl.class);

		criteria.select(menardOrder);

		Predicate finalPredicate = builder.conjunction();
		finalPredicate.getExpressions().add(builder.equal(menardOrder.get("status"), status.getType()));
		finalPredicate.getExpressions().add(builder.equal(menardOrder.get("createdByUserId"), userId));

		criteria.where(finalPredicate);
		criteria.orderBy(builder.desc(menardOrder.get("auditable").get("dateUpdated")));
		
		TypedQuery<MenardOrder> query = em.createQuery(criteria);
		SearchResult<MenardOrder> result = new SearchResult<MenardOrder>();
		if (filter.getPage() != null && filter.getSize() != null) {
			result.setPage(filter.getPage());
			result.setPageSize(filter.getSize());
			result.setTotalResults(getTotalCount(builder, menardOrder, finalPredicate).intValue());
			query.setFirstResult(getBeginningIndex(filter.getPage(), filter.getSize()));
			query.setMaxResults(filter.getSize());
		}

		List<MenardOrder> list = query.getResultList();
		result.setResult(list);
		return result;
		
	}

	/**
	 *
	 * @param builder CriteriaBuilder
	 * @param menardOrder MenardDiscreteOrderItem
	 * @param finalPredicate Predicate
	 * @return Long
	 */
	private Long getTotalCount(CriteriaBuilder builder, Root<MenardOrderImpl> menardOrder, Predicate finalPredicate) {
		CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
		countCriteria.getRoots().add(menardOrder);
		countCriteria.select(builder.count(menardOrder));
		countCriteria.where(finalPredicate);
		return em.createQuery(countCriteria).getSingleResult();
	}

	/**
	 *
	 * @param page Integer
	 * @param size Integer
	 * @return Integer
	 */
	private Integer getBeginningIndex(Integer page, Integer size) {
		Integer begin = (page - 1) * size;
		begin = begin > 0 ? begin : 0;
		return begin;
	}

	/**
	 *
	 * Get Order By Filter
	 * @param storeId storeId
	 * @param days days
	 * @param orderId orderId
	 * @return List list
	 */
	@Override
	public List<MenardOrder> getOrderByFilter(String storeId, Integer days, Long orderId) {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardOrder> criteria = builder.createQuery(MenardOrder.class);
		Root<MenardOrderImpl> menardOrder = criteria.from(MenardOrderImpl.class);

		criteria.select(menardOrder);

		Predicate finalPredicate = builder.conjunction();

		finalPredicate.getExpressions().add(builder.equal(menardOrder.get("status"), OrderStatus.SUBMITTED.getType()));

		if (StringUtils.isNotBlank(storeId)) {

			finalPredicate.getExpressions().add(builder.equal(menardOrder.get("storeId"), storeId));
		}

		Path<Date> dateCreatedPath = menardOrder.get("submitDate");

		if (days != null) {
			// Path<Date> dateCreatedPath = menardOrder.get("submitDate");
			finalPredicate.getExpressions().add(
					builder.greaterThanOrEqualTo(dateCreatedPath, (new DateTime()).minusDays(days).toDate()));
		}

		if (orderId != null) {
			finalPredicate.getExpressions().add(builder.equal(menardOrder.get("id"), orderId));
		}

		criteria.orderBy(builder.desc(dateCreatedPath));

		criteria.where(finalPredicate);
		return em.createQuery(criteria).getResultList();

	}

	/**
	 *
	 * Get Tracking History By orderItemId.
	 * @param orderItemId orderItemId
	 * @return MenardOrderItem MenardOrderItem
	 */
	@Override
	public MenardOrderItemHistory getTrackingHistory(Long orderItemId) {
		return em.find(MenardOrderItemHistory.class, orderItemId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.menards.ssc.dao.order.MenardOrderDao#saveMenardOrder(com.menards.ssc.domain.order.MenardOrder)
	 */
	@Override
	public Order saveMenardOrder(Order menardOrder) {
		return em.merge(menardOrder);
	}

	/**
	 *  find MenardOrder By Status
	 * @param status OrderStatus
	 * @return List<MenardOrder> list
	 */
	@Override
	public List<MenardOrder> findMenardOrderByStatus(OrderStatus status) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardOrder> criteria = builder.createQuery(MenardOrder.class);
		Root<MenardOrderImpl> menardOrder = criteria.from(MenardOrderImpl.class);

		criteria.select(menardOrder);

		Predicate finalPredicate = builder.conjunction();
		finalPredicate.getExpressions().add(builder.equal(menardOrder.get("status"), status.getType()));
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		finalPredicate.getExpressions().add(builder.equal(menardOrder.get("createdByUserId"), user.getUserId()));

		criteria.where(finalPredicate);
		criteria.orderBy(builder.desc(menardOrder.get("auditable").get("dateUpdated")));

		return em.createQuery(criteria).getResultList();
	}

	@Override
	public List<MenardOrder> findOrdersByUserId(String userId, OrderStatus status) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MenardOrder> criteria = builder.createQuery(MenardOrder.class);
		Root<MenardOrderImpl> menardOrder = criteria.from(MenardOrderImpl.class);

		criteria.select(menardOrder);

		Predicate finalPredicate = builder.conjunction();
		finalPredicate.getExpressions().add(builder.equal(menardOrder.get("status"), status.getType()));
		finalPredicate.getExpressions().add(builder.equal(menardOrder.get("createdByUserId"), userId));

		criteria.where(finalPredicate);
		criteria.orderBy(builder.desc(menardOrder.get("auditable").get("dateUpdated")));

		return em.createQuery(criteria).getResultList();
	}	

	@Override
	public void flush() {
		em.flush();
	}
}
