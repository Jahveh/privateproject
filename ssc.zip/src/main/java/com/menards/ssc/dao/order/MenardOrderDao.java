package com.menards.ssc.dao.order;

import java.util.List;

import org.broadleafcommerce.core.order.dao.OrderDao;
import org.broadleafcommerce.core.order.domain.Order;
import org.broadleafcommerce.core.order.service.type.OrderStatus;

import com.menards.ssc.domain.catalog.SearchResult;
import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderItemFilterDTO;
import com.menards.ssc.domain.order.MenardOrderItemHistory;

/**
 *
 * <p>MenardOrderDao</p>
 * <p>An Menard Order Dao that provides convenience methods and resource declarations for database access.</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public interface MenardOrderDao extends OrderDao {
	
	/**
	 *
	 * Get Order By Pagination
	 * @param filter filter	
	 * @return List list
	 */
	public SearchResult<MenardOrder> getOrderByPagination(MenardOrderItemFilterDTO filter);
	
	/**
	 *
	 * Get Order By UserId with Pagination
	 * @param filter filter
	 * @param status status
	 * @param userId userId
	 * @return List list
	 */
	public SearchResult<MenardOrder> findOrdersByUserId(MenardOrderItemFilterDTO filter, String userId,
			OrderStatus status);

	/**
	 *
	 * Get Order By Filter
	 * @param storeId storeId
	 * @param days days
	 * @param orderId orderId
	 * @return List list
	 */
	public List<MenardOrder> getOrderByFilter(String storeId, Integer days, Long orderId);

	/**
	 *
	 * Get Tracking History By orderItemId.
	 * @param orderItemId orderItemId
	 * @return MenardOrderItem MenardOrderItem
	 */
	public MenardOrderItemHistory getTrackingHistory(Long orderItemId);

	/**
	 * save menard order
	 *
	 * @param menardOrder Order
	 * @return Order
	 */
	public Order saveMenardOrder(Order menardOrder);

	/**
	 *  find MenardOrder By Status
	 * @param status OrderStatus
	 * @return List<MenardOrder> list
	 */
	public List<MenardOrder> findMenardOrderByStatus(OrderStatus status);

	/**
	 * find cart by user Id
	 * @param userId String
	 * @param status OrderStatus
	 * @return List<MenardOrder> orders
	 */
	public List<MenardOrder> findOrdersByUserId(String userId, OrderStatus status);
	
	/**
	 * Flush all the previous update
	 */
	public void flush();

}
