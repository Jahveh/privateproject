package com.menards.ssc.domain.catalog;

import org.broadleafcommerce.core.catalog.domain.Sku;

/**
 * <p>MenardSku</p>
 * <p>menard sku entity</p>
 * <p>
 * menard sku entity
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public interface MenardSku extends Sku {

	/**
	 * get sku code
	 * @return string sku code
	 */
	public String getSkuCode();

	/**
	 * set sku code
	 * @param skuCode skuCode
	 */
	public void setSkuCode(String skuCode);

	/**
	 * get menard sku
	 * @return string menard sku
	 */
	public String getMenardSku();

	/**
	 * set menard sku
	 * @param menardSku menardSku
	 */
	public void setMenardSku(String menardSku);
	
	/**
	 * Return the real menard sku
	 * @return
	 */
	public String getRealMenardSku();
}
