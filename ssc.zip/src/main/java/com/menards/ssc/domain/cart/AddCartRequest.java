package com.menards.ssc.domain.cart;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>AddCartRequest</p>
 * <p>add to cart request dto</p>
 * <p>
 * add to cart request dto
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class AddCartRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -679652175962373454L;

	/**
	 * options accessories sku
	 */
	private List<SkuCartItem> optionSkus = new ArrayList<SkuCartItem>();

	/**
	 * require accessories sku
	 */
	private List<SkuCartItem> requireSkus = new ArrayList<SkuCartItem>();

	/**
	 * main product sku
	 */
	private SkuCartItem mainSku;

	/**
	 * items in cart
	 */
	private List<SkuCartItem> cartItems = new ArrayList<SkuCartItem>();

	private String navigation;

	public List<SkuCartItem> getOptionSkus() {
		return optionSkus;
	}

	public void setOptionSkus(List<SkuCartItem> optionSkus) {
		this.optionSkus = optionSkus;
	}

	public List<SkuCartItem> getRequireSkus() {
		return requireSkus;
	}

	public void setRequireSkus(List<SkuCartItem> requireSkus) {
		this.requireSkus = requireSkus;
	}

	public SkuCartItem getMainSku() {
		return mainSku;
	}

	public void setMainSku(SkuCartItem mainSku) {
		this.mainSku = mainSku;
	}

	public List<SkuCartItem> getCartItems() {
		return cartItems;
	}

	public void setCartItems(List<SkuCartItem> cartItems) {
		this.cartItems = cartItems;
	}

	public String getNavigation() {
		return navigation;
	}

	public void setNavigation(String navigation) {
		this.navigation = navigation;
	}

}
