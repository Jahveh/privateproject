package com.menards.ssc.domain.order;

import java.util.Date;

import org.broadleafcommerce.core.order.domain.Order;

/**
 *
 * <p>MenardOrder</p> *
 * <p>
 * An Extended Order Domain interface that provides methods for entity extension.
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public interface MenardOrder extends Order {

	/**
	 *
	 * get StoreId
	 * @return String String
	 */
	public String getStoreId();

	/**
	 *
	 * set StoreId
	 * @param storeId storeId
	 */
	public void setStoreId(String storeId);

	/**
	 *
	 * get DueDate
	 * @return Date Date
	 */
	public Date getDueDate();

	/**
	 *
	 * set DueDate
	 * @param dueDate dueDate
	 */
	public void setDueDate(Date dueDate);

	/**
	 *
	 * get CommentSaved
	 * @return String String
	 */
	public String getCommentSaved();

	/**
	 *
	 * set CommentSaved
	 * @param commentSaved commentSaved
	 */
	public void setCommentSaved(String commentSaved);

	/**
	 *
	 * get CommentPlaced
	 * @return String String
	 */
	public String getCommentPlaced();

	/**
	 *
	 * set CommentPlaced
	 * @param commentPlaced commentPlaced
	 */
	public void setCommentPlaced(String commentPlaced);

	/**
	 *
	 * get OrderType
	 * @return String String
	 */
	public String getOrderType();

	/**
	 *
	 * set OrderType
	 * @param orderType orderType
	 */
	public void setOrderType(String orderType);

	/**
	 *
	 * get Grouping
	 * @return String String
	 */
	public String getGrouping();

	/**
	 *
	 * set Grouping
	 * @param grouping grouping
	 */
	public void setGrouping(String grouping);

	/**
	 *
	 * get DeptId
	 * @return String String
	 */
	public String getDeptId();

	/**
	 *
	 * set DeptId
	 * @param deptId deptId
	 */
	public void setDeptId(String deptId);

	/**
	 *
	 * get RequestBy
	 * @return String String
	 */
	public String getRequestBy();

	/**
	 *
	 * set RequestBy
	 * @param requestBy requestBy
	 */
	public void setRequestBy(String requestBy);

	/**
	 *
	 * get OrderCode
	 * @return String String
	 */
	public String getOrderCode();

	/**
	 *
	 * set OrderCode
	 * @param orderCode orderCode
	 */
	public void setOrderCode(String orderCode);

	/**
	 *
	 * get ListName
	 * @return String String
	 */
	public String getListName();

	/**
	 *
	 * set ListName
	 * @param listName listName
	 */
	public void setListName(String listName);

	/**
	 *
	 * loaded from order Id
	 * @return Long Long
	 */
	public Long getLoadOrderId();

	/**
	 *
	 * loaded from order Id
	 * @param loadOrderId Long
	 */
	public void setLoadOrderId(Long loadOrderId);

	/**
	 * created by menard user id
	 * @return userId String
	 */
	public String getCreatedByUserId();

	/**
	 * set menard user Id 
	 * @param createdByUserId String
	 */
	public void setCreatedByUserId(String createdByUserId);

	/**
	 * is go user order
	 * @return GOOrder String
	 */
	public String getGeneralOfficeOrder();

	/**
	 * set go user order
	 * @param generalOfficeOrder String
	 */
	public void setGeneralOfficeOrder(String generalOfficeOrder);
}
