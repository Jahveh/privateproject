package com.menards.ssc.domain.order;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

/**
 * 
 * <p>MenardOrderItemTrackingHistory</p>
 * <p>menard order item tracking history</p>
 *
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "MENARD_ORDER_ITEM_TRACKING_HISTORY")
public class MenardOrderItemTrackingHistory implements Serializable {

	private static final long serialVersionUID = 4063524912100294635L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;

	@Column(name = "ORDER_ID", nullable = false)
	private Long orderId;

	@Column(name = "ORDER_ITEM_ID", nullable = false)
	private Long orderItemId;

	@Column(name = "DECLINED_COMMENT", nullable = true, length = 255)
	private String comment;

	@Column(name = "TRACKING_STATUS", nullable = false, length = 100)
	private String status;

	@Column(name = "CREATE_DATE", nullable = false)
	private Date createDate;

	@Column(name = "CREATE_BY", nullable = false, length = 100)
	private String createBy;

	/**
	 *
	 *Constructor
	 */
	public MenardOrderItemTrackingHistory() {
		super();
	}

	/**
	 *
	 *Constructor
	 *@param orderId Long
	 *@param orderItemId Long
	 *@param comment String
	 *@param status String
	 *@param createBy String
	 */
	public MenardOrderItemTrackingHistory(Long orderId, Long orderItemId, String comment, String status, String createBy) {
		super();
		this.orderId = orderId;
		this.orderItemId = orderItemId;
		this.comment = comment;
		this.status = status;
		this.createBy = createBy;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Long getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(Long orderItemId) {
		this.orderItemId = orderItemId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

}
