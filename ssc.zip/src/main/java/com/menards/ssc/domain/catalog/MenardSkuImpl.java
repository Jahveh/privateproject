package com.menards.ssc.domain.catalog;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;

import org.apache.commons.lang.StringUtils;
import org.broadleafcommerce.core.catalog.domain.SkuImpl;

/**
 * <p>MenardSkuImpl</p>
 * <p>menard sku entity</p>
 * <p>
 * menard sku entity
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Entity
@javax.persistence.Table(name = "MENARD_SKU")
public class MenardSkuImpl extends SkuImpl implements Serializable, MenardSku {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "SKU_CODE")
	private String skuCode;

	@Column(name = "MENARD_SKU")
	private String menardSku;

	@Override
	public String getSkuCode() {
		return skuCode;
	}

	@Override
	public void setSkuCode(String skuCode) {
		this.skuCode = skuCode;
	}

	@Override
	public String getMenardSku() {
		if (StringUtils.isNotBlank(menardSku)) {
			return menardSku;
		}
		return skuCode;
	}
	
	@Override
	public String getRealMenardSku() {		
		return menardSku;
	}

	@Override
	public void setMenardSku(String menardSku) {
		this.menardSku = menardSku;
	}

	@Override
	public boolean isActive() {
		return 'Y' == available;
	}

}
