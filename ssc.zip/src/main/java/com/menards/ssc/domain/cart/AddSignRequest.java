package com.menards.ssc.domain.cart;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>Add Sign Request</p>
 * <p>add to Sign request dto</p>
 * <p>
 * add to cart request dto
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class AddSignRequest implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5058448891976997974L;
	private List<AddSignDTO> signItems = new ArrayList<AddSignDTO>();

	public List<AddSignDTO> getSignItems() {
		return signItems;
	}

	public void setSignItems(List<AddSignDTO> signItems) {
		this.signItems = signItems;
	}

	/**
	 * SignCartItem
	 */
	/*private List<SignCartItem> signItems = new ArrayList<SignCartItem>();*/

	/*public List<SignCartItem> getSignItems() {
		if (CollectionUtils.isEmpty(signItems)) {
			return signItems;
		}

		List<SignCartItem> list = new ArrayList<SignCartItem>();
		for (SignCartItem signCartItem : signItems) {
			if (signCartItem == null || signCartItem.getSignId() == null) {
				continue;
			}
			list.add(signCartItem);
		}
		return list;
	}

	public void setSignItems(List<SignCartItem> signItems) {
		this.signItems = signItems;
	}
*/
}
