package com.menards.ssc.domain.catalog;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

import com.menards.ssc.util.MenardUtil;

/**
 * <p>MenardProductOption</p>
 * <p>menard product accessories products</p>
 * <p>
 * menard product accessories products
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Entity
@javax.persistence.Table(name = "MENARD_PRODUCT_OPTION")
public class MenardProductOption implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * pk
	 */
	@Embeddable
	public static class MenardProductOptionPK implements Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = 1L;

		@ManyToOne(optional = true, targetEntity = MenardProductImpl.class)
		@JoinColumn(name = "BASE_PRODUCT_ID")
		private MenardProduct baseMenardProduct;

		@ManyToOne(optional = true, targetEntity = MenardProductImpl.class)
		@JoinColumn(name = "OPTION_PRODUCT_ID")
		private MenardProduct accessory;

		public MenardProduct getBaseMenardProduct() {
			return baseMenardProduct;
		}

		public void setBaseMenardProduct(MenardProduct baseMenardProduct) {
			this.baseMenardProduct = baseMenardProduct;
		}

		public MenardProduct getAccessory() {
			return accessory;
		}

		public void setAccessory(MenardProduct accessory) {
			this.accessory = accessory;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((accessory == null) ? 0 : accessory.hashCode());
			result = prime * result + ((baseMenardProduct == null) ? 0 : baseMenardProduct.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			MenardProductOptionPK other = (MenardProductOptionPK) obj;
			if (accessory == null) {
				if (other.accessory != null) {
					return false;
				}
			} else if (!accessory.equals(other.accessory)) {
				return false;
			}
			if (baseMenardProduct == null) {
				if (other.baseMenardProduct != null) {
					return false;
				}
			} else if (!baseMenardProduct.equals(other.baseMenardProduct)) {
				return false;
			}

			return true;

		}
	}

	@EmbeddedId
	private MenardProductOptionPK menardProductOptionPK;

	@Column(name = "MANDATORY")
	private String mandatory;

	public String getMandatory() {
		return mandatory;
	}

	public void setMandatory(String mandatory) {
		this.mandatory = mandatory;
	}

	public MenardProductOptionPK getMenardProductOptionPK() {
		return menardProductOptionPK;
	}

	public void setMenardProductOptionPK(MenardProductOptionPK menardProductOptionPK) {
		this.menardProductOptionPK = menardProductOptionPK;
	}

	@Transient
	public boolean getIsMandatory() {
		return MenardUtil.getBooleanValue(mandatory);
	}

}
