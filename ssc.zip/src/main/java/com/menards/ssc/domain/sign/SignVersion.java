/**
 * 
 */
package com.menards.ssc.domain.sign;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * <p>SignVersion</p> 
 * <p>Sign Version</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Entity
@Table(name = "sign_versions")
public class SignVersion implements Serializable, Comparable<SignVersion> {
	
	private static final long serialVersionUID = 8637347043077840843L;

	@Id
	@Column(name = "sign_id")
	private Integer signId;

	@Column(name = "dept")
	private Integer dept;

	@Column(name = "signname")
	private String signname;

	@Column(name = "desc")
	private String desc;

	@Column(name = "disabled")
	private Integer disabled;

	@Column(name = "start_date")
	private Date startDate;

	@Column(name = "stop_date")
	private Date stopDate;

	@Column(name = "store_start_date")
	private Date storeStartDate;

	@Column(name = "store_stop_date")
	private Date storeStopDate;

	@Column(name = "flyerpoint")
	private Integer flyerpoint;

	@Column(name = "ver_id")
	private Integer versionId;

	@Column(name = "laminate")
	private Integer laminate;

	@Column(name = "last_update")
	private Date lastUpdate;

	@Column(name = "flyer_date_cd")
	private Integer flyerDateCode;

	@Column(name = "promonbr")
	private Integer promonbr;

	@Column(name = "keyword_txt")
	private String keyword;

	@ManyToOne(targetEntity = Stock.class)
	@JoinColumn(name = "stock_id")
	private Stock stock;

	public Integer getSignId() {
		return signId;
	}

	public void setSignId(Integer signId) {
		this.signId = signId;
	}

	public Integer getDept() {
		return dept;
	}

	public void setDept(Integer dept) {
		this.dept = dept;
	}

	public String getSignname() {
		return signname;
	}

	public void setSignname(String signname) {
		this.signname = signname;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getStopDate() {
		return stopDate;
	}

	public void setStopDate(Date stopDate) {
		this.stopDate = stopDate;
	}

	public Date getStoreStartDate() {
		return storeStartDate;
	}

	public void setStoreStartDate(Date storeStartDate) {
		this.storeStartDate = storeStartDate;
	}

	public Date getStoreStopDate() {
		return storeStopDate;
	}

	public void setStoreStopDate(Date storeStopDate) {
		this.storeStopDate = storeStopDate;
	}

	public Integer getFlyerpoint() {
		return flyerpoint;
	}

	public void setFlyerpoint(Integer flyerpoint) {
		this.flyerpoint = flyerpoint;
	}

	public Integer getVersionId() {
		return versionId;
	}

	public void setVersionId(Integer versionId) {
		this.versionId = versionId;
	}

	public Integer getLaminate() {
		return laminate;
	}

	public void setLaminate(Integer laminate) {
		this.laminate = laminate;
	}

	public Integer getFlyerDateCode() {
		return flyerDateCode;
	}

	public void setFlyerDateCode(Integer flyerDateCode) {
		this.flyerDateCode = flyerDateCode;
	}

	public Integer getPromonbr() {
		return promonbr;
	}

	public void setPromonbr(Integer promonbr) {
		this.promonbr = promonbr;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}

	@Override
	public int compareTo(SignVersion o) {
		if (o == null) {
			return 1;
		}		
		if (this.laminate != o.laminate) {
			return this.laminate - o.laminate;
		}		
		if (o.getStock() != null) {
			if (this.getStock().getStorePrintable() != o.getStock().getStorePrintable()) {
				return this.getStock().getStorePrintable() - o.getStock().getStorePrintable();
			}
		}		
		return this.getDesc().compareTo(o.getDesc());
	}
}
