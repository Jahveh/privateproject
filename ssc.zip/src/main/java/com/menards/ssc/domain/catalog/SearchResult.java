package com.menards.ssc.domain.catalog;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * <p>SearchResult</p>
 * <p>Page result holder</p>
 * <p>
 * Hold the information about page size, total page and
 * result of search
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @param <T> This describes my type parameter
 * @author leo.yang
 * @version 1.0
 */
public class SearchResult<T>  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5502625385577269354L;
	private List<T> result = new ArrayList<T>();
	private Integer totalResults;
	private Integer page;
	private Integer pageSize;

	/**
	 * 
	 *Constructor
	 */
	public SearchResult() {
		super();
	}

	/**
	 * 
	 *Constructor 
	 *@param totalResults Integer
	 *@param page Integer
	 *@param pageSize Integer
	 */
	public SearchResult(Integer totalResults, Integer page, Integer pageSize) {
		super();
		this.totalResults = totalResults;
		this.page = page;
		this.pageSize = pageSize;
	}

	public Integer getTotalResults() {
		return totalResults;
	}

	public void setTotalResults(Integer totalResults) {
		this.totalResults = totalResults;
	}

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getStartResult() {
		return (result == null || result.size() == 0) ? 0 : ((page - 1) * pageSize) + 1;
	}

	public Integer getEndResult() {
		return Math.min(page * pageSize, totalResults);
	}

	public Integer getTotalPages() {
		return (result == null || result.size() == 0) ? 1 : (int) Math.ceil(totalResults * 1.0 / pageSize);
	}

	public List<T> getResult() {
		return result;
	}

	public void setResult(List<T> result) {
		this.result = result;
	}

	/**
	 * 
	 * addElement
	 * @param t t
	 */
	public void addElement(T t) {
		result.add(t);
	}

	/**
	 * 
	 * addAllElements
	 * @param col col
	 */
	public void addAllElements(Collection<T> col) {
		result.addAll(col);
	}
}