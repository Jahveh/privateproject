package com.menards.ssc.domain.order;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>MenardOrderDTO</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public class MenardOrderDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -954120768944070444L;
	private int items;
	private Long orderId;
	private String comment;
	private String group;
	private String requestBy;
	private Date creationDate;

	/**
	 *
	 *Constructor
	 *@param menardOrder menardOrder
	 */
	public MenardOrderDTO(MenardOrder menardOrder) {

		this.items = menardOrder.getOrderItems().size();
		// this.items = menardOrder.getItemCount();
		this.orderId = menardOrder.getId();
		this.comment = menardOrder.getCommentPlaced();
		// this.group = menardOrder.getGrouping();
		this.group = menardOrder.getOrderCode();
		this.requestBy = menardOrder.getRequestBy();
		this.creationDate = menardOrder.getSubmitDate();

	}

	public int getItems() {
		return items;
	}

	public void setItems(int items) {
		this.items = items;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getRequestBy() {
		return requestBy;
	}

	public void setRequestBy(String requestBy) {
		this.requestBy = requestBy;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

}
