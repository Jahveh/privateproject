package com.menards.ssc.domain.order;

import java.io.Serializable;

/**
 * <p>ItemApproveRequestDTO</p>
 *
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class ItemApproveRequestDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -132383073298742190L;
	private Long id;
	private String status;
	private String reason;

	/**
	 *Constructor 
	 */
	public ItemApproveRequestDTO() {
		super();
	}

	/**
	 *Constructor 
	 *@param id Long
	 *@param status String
	 */
	public ItemApproveRequestDTO(Long id, String status) {
		super();
		this.id = id;
		this.status = status;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
}
