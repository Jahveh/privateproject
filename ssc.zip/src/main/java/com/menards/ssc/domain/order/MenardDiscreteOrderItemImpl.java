package com.menards.ssc.domain.order;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.broadleafcommerce.common.presentation.AdminPresentation;
import org.broadleafcommerce.core.catalog.domain.ProductAttribute;
import org.broadleafcommerce.core.order.domain.DiscreteOrderItem;
import org.broadleafcommerce.core.order.domain.DiscreteOrderItemFeePrice;
import org.broadleafcommerce.core.order.domain.DiscreteOrderItemImpl;
import org.broadleafcommerce.core.order.domain.OrderItem;
import org.hibernate.annotations.Index;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.constants.ProductAttributeKey;
import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardProductImpl;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.catalog.MenardSkuImpl;

/**
 *
 * <p>MenardDiscreteOrderItemImpl</p>
 * <p>An Extended OrderImpl that extends OrderImpl for entity implementation.</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author bill01.zhang
 * @version 1.0
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "MENARD_DISCRETE_ORDER_ITEM")
public class MenardDiscreteOrderItemImpl extends DiscreteOrderItemImpl implements Serializable, MenardOrderItem {

	private static final long serialVersionUID = 800971203020655684L;

	@Column(name = "NOTES")
	private String notes;

	@Column(name = "LINE_NUMBER")
	private Integer lineNumber;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "STATUS_DATE")
	private Date statusDate;

	@Column(name = "REQUEST_TYPE")
	private String requestType;

	@ManyToOne(targetEntity = MenardOrderImpl.class)
	@JoinColumn(name = "ORDER_ID")
	@Index(name = "ORDERITEM_ORDER_INDEX", columnNames = { "ORDER_ID" })
	@AdminPresentation(excluded = true)
	private MenardOrder menardOrder;

	@ManyToOne(targetEntity = MenardProductImpl.class)
	@JoinColumn(name = "PRODUCT_ID")
	@Index(name = "DISCRETE_PRODUCT_INDEX", columnNames = { "PRODUCT_ID" })
	private MenardProduct menardProduct;

	@ManyToOne(targetEntity = MenardSkuImpl.class, optional = false)
	@JoinColumn(name = "SKU_ID", nullable = false)
	@Index(name = "DISCRETE_SKU_INDEX", columnNames = { "SKU_ID" })
	private MenardSku menardSku;

	@OneToMany(targetEntity = MenardOrderItemTrackingHistory.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ITEM_ID")
	private List<MenardOrderItemTrackingHistory> history = new ArrayList<MenardOrderItemTrackingHistory>();

	@Column(name = "DCITEM")
	private String dcItem;

	@Column(name = "STORE_REMODEL")
	private String storeRemodel;

	@Column(name = "FULFILLER_TYPE")
	private String fulfillerTypeCode;

	@Column(name = "STORE_PRINT")
	private String storePrint;

	@Column(name = "SIGN_ID")
	private Integer signId;

	@Column(name = "SIGN_YARD_NUM")
	private String signYardNum;

	@Column(name = "ITEM_TYPE")
	private String itemType;

    @Column(name = "BM_SKU")
    private String bmSku;

    @Column(name = "MENARD_SKU")
    private String menardSkuStr;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "POS_ORDER_NUMBER")
    private Long posOrderNumber;

	@Override
	public String getNotes() {
		return notes;
	}

	@Override
	public void setNotes(String notes) {
		this.notes = notes;
	}

	@Override
	public Integer getLineNumber() {
		return lineNumber;
	}

	@Override
	public void setLineNumber(Integer lineNumber) {
		this.lineNumber = lineNumber;
	}

	@Override
	public String getStatus() {
		return status;
	}

	@Override
	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public Date getStatusDate() {
		return statusDate;
	}

	@Override
	public void setStatusDate(Date statusDate) {
		this.statusDate = statusDate;
	}

	@Override
	public String getRequestType() {
		return requestType;
	}

	@Override
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	@Override
	public MenardOrder getMenardOrder() {
		return menardOrder;
	}

	@Override
	public void setMenardOrder(MenardOrder menardOrder) {
		this.menardOrder = menardOrder;
	}

	@Override
	public List<MenardOrderItemTrackingHistory> getHistory() {
		return history;
	}

	@Override
	public void setHistory(List<MenardOrderItemTrackingHistory> history) {
		this.history = history;
	}

	@Override
	public String getDcItem() {
		return dcItem;
	}

	@Override
	public void setDcItem(String dcItem) {
		this.dcItem = dcItem;
	}

	@Override
	public String getStoreRemodel() {
		return storeRemodel;
	}

	@Override
	public void setStoreRemodel(String storeRemodel) {
		this.storeRemodel = storeRemodel;
	}

	@Override
	public String getFulfillerTypeCode() {
		return fulfillerTypeCode;
	}

	@Override
	public void setFulfillerTypeCode(String fulfillerTypeCode) {
		this.fulfillerTypeCode = fulfillerTypeCode;
	}

	@Override
	public String getStorePrint() {
		return storePrint;
	}

	@Override
	public void setStorePrint(String storePrint) {
		this.storePrint = storePrint;
	}

	@Override
	public Boolean isDcItem() {
		return CommonConstant.TRUE_STRING.equals(this.dcItem);
	}

	@Override
	public Boolean isStoreRemodel() {
		return CommonConstant.TRUE_STRING.equals(this.storeRemodel);
	}

	@Override
	public Boolean isStorePrint() {
		return CommonConstant.TRUE_STRING.equals(this.storePrint);
	}

	public Integer getSignId() {
		return signId;
	}

	public void setSignId(Integer signId) {
		this.signId = signId;
	}

	public String getSignYardNum() {
		return signYardNum;
	}

	public void setSignYardNum(String signYardNum) {
		this.signYardNum = signYardNum;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

    public String getBmSku() {
        return bmSku;
    }

    public void setBmSku(String bmSku) {
        this.bmSku = bmSku;
    }

    public String getMenardSkuStr() {
        return menardSkuStr;
    }

    public void setMenardSkuStr(String menardSku) {
        this.menardSkuStr = menardSku;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getPosOrderNumber() {
        return posOrderNumber;
    }

    public void setPosOrderNumber(Long posOrderNumber) {
        this.posOrderNumber = posOrderNumber;
    }

    @Override
	public String getMenardSkuCode() {
		MenardSku sku = (MenardSku) getSku();
		if (sku == null) {
			return StringUtils.EMPTY;
		}
		String menardSkuTemp = sku.getMenardSku();
		if (StringUtils.isNotEmpty(menardSkuTemp)) {
			return menardSkuTemp;
		}
		return sku.getSkuCode();
	}

	@Override
	public String getProductLongDesc() {
		return getProductAttr(ProductAttributeKey.DESCRIPTION_LONG);
	}

	@Override
	public String getProductName() {
		return getProductAttr(ProductAttributeKey.PRODUCT_NAME);
	}

	/**
	 * 
	 * get product attribute
	 * @param key String
	 * @return attibuteValue  String
	 */
	private String getProductAttr(String key) {
		Map<String, ProductAttribute> productAttr = product.getProductAttributes();
		if (MapUtils.isEmpty(productAttr) || !productAttr.containsKey(key)) {
			return StringUtils.EMPTY;
		}
		ProductAttribute attr = productAttr.get(key);
		if (attr == null) {
			return StringUtils.EMPTY;
		}
		return attr.getValue();
	}

	@Override
	public String getName() {
		if (name == null && sku != null) {
			return sku.getName();
		}
		return name;
	}

	@SuppressWarnings("deprecation")
	@Override
	public OrderItem clone() {
		DiscreteOrderItem orderItem = (DiscreteOrderItem) super.clone();
		if (discreteOrderItemFeePrices != null) {
			for (DiscreteOrderItemFeePrice feePrice : discreteOrderItemFeePrices) {
				DiscreteOrderItemFeePrice cloneFeePrice = feePrice.clone();
				cloneFeePrice.setDiscreteOrderItem(orderItem);
				orderItem.getDiscreteOrderItemFeePrices().add(cloneFeePrice);
			}
		}
		if (additionalAttributes != null) {
			orderItem.getAdditionalAttributes().putAll(additionalAttributes);
		}
		orderItem.setBaseRetailPrice(null);
		orderItem.setBaseSalePrice(null);
		orderItem.setBundleOrderItem(bundleOrderItem);
		orderItem.setProduct(product);
		orderItem.setSku(sku);

		if (orderItem.getOrder() == null) {
			throw new IllegalStateException("Either an Order or a BundleOrderItem must be set on the DiscreteOrderItem");
		}

		return orderItem;
	}

	public void setMenardProduct(MenardProduct menardProduct) {
		this.menardProduct = menardProduct;
	}

	public void setMenardSku(MenardSku menardSku) {
		this.menardSku = menardSku;
	}
}
