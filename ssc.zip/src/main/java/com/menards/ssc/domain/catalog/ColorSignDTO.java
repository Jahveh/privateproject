package com.menards.ssc.domain.catalog;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardOrderItemType;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

import org.apache.commons.collections.CollectionUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * <p>ColorSignDTO</p> 
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public class ColorSignDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4507539101210618474L;
	private MenardUserDetails user;
	private Sign sign;
	private List<String> yardList;
	private List<ColorSignHistory> histories;
	private boolean canOrder = false;

	/**
	 * 
	 *Constructor
	 */
	public ColorSignDTO() {
		this.user = MenardSecurityContextHolder.getMenardUserDetails();
	}

	/**
	 * get product image url
	 * @return img url
	 */
	public List<ImageryDTO> getProductImgList() {
		List<ImageryDTO> lst = new ArrayList<ImageryDTO>();
		ImageryDTO img = new ImageryDTO();
		String largeImagePath = sign.getLargeImagePath();
		img.setThumb(largeImagePath);
		img.setSmall(largeImagePath);
		img.setBig(largeImagePath);
		lst.add(img);
		return lst;

	}

	public String getType() {
		return MenardOrderItemType.COLOR_SIGN.getCode().toString();
	}

	public boolean isRequiresGMApproval() {
		return sign.isRequiresGMApproval();
	}

	/**
	 * get description short
	 * @return string short description
	 */
	public String getDescriptionShort() {
		return sign.getVersionDescription();
	}

	/**
	 *  get description long
	 * @return string long description
	 */
	public String getDescriptionLong() {
		return sign.getStockDescription();
	}

	/**
	 * get yard list
	 * @return sign yard list
	 */
	public String getYardList() {
		if (user.isGOUser()) {
			StringBuffer yardString = new StringBuffer();

			if (yardList.size() > 0) {
				for (int i = 0; i <= yardList.size() - 1; i++) {
					if (!yardList.get(i).equals("0")) {
						yardString.append(yardList.get(i).toString()).append(",");
						if (i != 0 && i % 7 == 0) {
							yardString.append("\n");
						}
					}
				}
			}
			String string = yardString.toString();
			if (string.length() > 2) {
				string = string.substring(0, yardString.length() - 1);
			}
			return string;
		}
		return null;
	}

	/**
	 * get price
	 * @return price price
	 */
	public String getPrice() {
		return "Price: $" + sign.getSignPrice().toString();
	}

	/**
	 * get price
	 * @return price price
	 */
	public String getUnitPrice() {
		return sign.getSignPrice();
	}

	/**
	 * determine to show add to cart button
	 * @return boolean boolean
	 */
	public boolean getShowAdd2CartBtn() {
		return this.isCanOrder();
	}

    /**
     * show or hide not orderable message
     *
     * @return orderable boolean
     */
    public boolean getDisplayNotOrderableMsg() {
        return !user.isGOUser() && !getShowAdd2CartBtn();
    }

	/**
	 * get shipment message
	 * @return message message
	 */
	public String getShipmentMsg() {
		int leadTime = getShipmentDays();
		return "Available for shipment in approximately " + leadTime + " days.";
	}

	/**
	 * not orderable message
	 * @return message message
	 */
	public String getNotOrderableMsg() {
		int days = this.getShipmentDays();
		return "This sign can not be reordered at this time - the last ordered date is less than the " + days
				+ "days allowed.";
	}

	/**
	 * determine to show the message
	 * Available for shipment in approximately <%=delayInDays %> days.
	 * @return boolean boolean
	 */
	public boolean getShowShipmentDays() {
		return true;
	}

	/**
	 * 
	 * Get shipment days
	 * @return days shippment days
	 */
	private int getShipmentDays() {
		int leadTime = 14;
		//if (sign.getPrintLocation().equals("0")) {
		if ("0".equals(sign.getPrintLocation())) {
			leadTime = 21;
		}
		return leadTime;
	}

	/**
	 * run program Open Sigma Application
	 * @return boolean boolean
	 */
	public boolean getRunOpenSigmaApplication() {
		return user.isGOUser();
	}

	/**
	 * determine to show last orders
	 * @return boolean boolean
	 */
	public boolean getShowLastOrders() {
		return !user.isGOUser();
	}

	/**
	 * get last orders
	 *
	 * @return list orders
	 */
    public List<String> getLastOrders() {
        List<String> orders = new ArrayList<String>();
        if (CollectionUtils.isEmpty(histories)) {
            orders.add("No orders recorded in the last 60 days.");
        } else {
            int limit = (histories.size() >= 10 ? 10 : histories.size());
            int i = 0;
            for (ColorSignHistory history : histories) {
                if (i < limit) {
                    orders.add("Requested by " + history.getUserName() + " on " + history.getDateStr() + " | "
                            + history.getDescription());
                } else {
                    break;
                }
                i++;
            }
        }
        return orders;
    }

	/**
	 * get Series Numbe
	 * @return SeriesNumber
	 */
	public String getSeriesNumber() {
		return sign.getSignName();
	}

	/**
	 * stock width X stock height
	 * @return string string
	 */
	public String getSize() {
		return sign.getStockWidth() + "X" + sign.getStockHeight();
	}

	/**
	 * return skuCode
	 * @return string string
	 */
	public String getModelNum() {
		return String.valueOf(sign.getSignID());
	}

	public String getPrintLocation() {
		return sign.getPrintLocation();
	}

	public int getOrderableQuantity() {
		return sign.getOrderableQuantity();
	}

	public int getSignId() {
		return sign.getSignID();
	}

	public Sign getSign() {
		return sign;
	}

	public void setSign(Sign sign) {
		this.sign = sign;
	}

	public List<ColorSignHistory> getHistories() {
		return histories;
	}

	public void setHistories(List<ColorSignHistory> histories) {
		this.histories = histories;
	}

	public void setYardList(List<String> yardList) {
		this.yardList = yardList;
	}

	public boolean isCanOrder() {
		return canOrder;
	}

	public void setCanOrder(boolean canOrder) {
		this.canOrder = canOrder;
	}

	/**
	 *
	 * Get request type
	 * @return request request
	 */
	public MenardOrderRequestType getRequestType() {
		MenardOrderRequestType requestType = MenardOrderRequestType.Color_Signbase;
		if ("0".equals(sign.getPrintLocation())) {
			requestType = MenardOrderRequestType.GSS_Sign;
			if (isRequiresGMApproval()) {
				requestType = MenardOrderRequestType.GSS_Sign_GM;
			}
		} else {
			if (isRequiresGMApproval()) {
				requestType = MenardOrderRequestType.Color_Signbase_GM;
			}
		}
		return requestType;
	}

	/**
	 *
	 * Get Fulfiller type
	 * @return MenardFulfillerType MenardFulfillerType
	 */
	public MenardFulfillerType getFulfillerType() {
		MenardFulfillerType fulfillerType = MenardFulfillerType.SIGN_PRODUCTION;
		// 0 = sign shop, 1 = sign production
		if ("0".equals(getPrintLocation())) {
			fulfillerType = MenardFulfillerType.SIGN_SHOP;
		}

		return fulfillerType;
	}

	public String getStorePrint() {
		return CommonConstant.FALSE_STRING;
	}

	public String getColor() {
		return sign.getSignColor();
	}
}
