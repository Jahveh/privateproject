package com.menards.ssc.domain.sign;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.enums.MenardOrderItemType;

/**
 * <p>Sign</p> 
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class Sign implements Serializable {

	/**
	 * Comment for <code>serialVersionUID</code>.
	 */
	private static final long serialVersionUID = 3392748383923680003L;

	// Color Signbase project variables.
	private List<String> yardList = new ArrayList<String>();
	private String originSystem = "";
	private String previewPath = "";
	private String imagePath = "";
	private String largeImagePath = "";
	private String closeImagePath = "";
	private String printLocation = "";
	private boolean isColorSignBase = false;
	private boolean isSignBase = false;
	private boolean isSkuman = false;
	private int orderableQuantity = 0;
	private int processingCount = 0;
	private boolean canOrder = false;
	private String signColor = "N/A";
	private List<String> orderHistory = new ArrayList<String>();
	private boolean requiresGMApproval = true;

	public static final int NOT_WHITE = 0;

	public static final int WHITE_BY_YARD = 1;

	public static final int WHITE_BY_DEPT = 2;

	public static final int PRINT_AT_STORE = 1;

	public static final int PRINT_AT_SPR = 0;

	public static final int NONE_FACT_TAG = 0;

	public static final int MENARDS_FACT_TAG = 1;

	public static final int VENDOR_FACT_TAG = 2;

	public static final int MENARDS_POD = 3;

	public static final int VENDOR_POD = 4;

	private transient Log log = LogFactory.getLog(Sign.class);

	private int dept = 0;

	private String signName = "";

	private String versionDescription = "";

	private String stockDescription = "";

	private float stockHeight = 0.0f;

	private float stockWidth = 0.0f;

	private int stockID = 0;

	private int signID = 0;

	private int yard = 0;

	private static final String ZERO_DATE = "1899-12-30";

	private String generalMgr = "";

	private String assistmgr1 = "";

	private String assistmgr2 = "";

	private String assistmgr3 = "";

	private String frontendmgr = "";

	private String receivingmgr = "";

	private int storePlanning = -99;

	private int versionId = 0;

	private int laminate = 0;

	private int promonbr = 0;

	private String promoName = "";

	private String promoDescription = "";

	private int printAt = PRINT_AT_SPR;

	private String email = "";

	private int flyerPoint;

	private String startDate = "";

	private String stopDate = "";

	private String storeStartDate = "";

	private String storeStopDate = "";

	private int whiteSign = 0;

	private int printWhite = 0;

	private int orderedQuantity = 0;

	// private List<SignSaleInfo> saleSignInfo = new ArrayList<SignSaleInfo>();

	private boolean canPrintWhite = false;

	// private Currency signPrice = new Currency("0.00");

	private String signPrice;
	
	private String signPath;

	public boolean isSignBase() {
		return isSignBase;
	}

	public void setSignBase(boolean isSignBase) {
		this.isSignBase = isSignBase;
	}

	public boolean isSkuman() {
		return isSkuman;
	}

	public void setSkuman(boolean isSkuman) {
		this.isSkuman = isSkuman;
	}

	public boolean isCanOrder() {
		return canOrder;
	}

	public void setCanOrder(boolean canOrder) {
		this.canOrder = canOrder;
	}

	public List<String> getOrderHistory() {
		return orderHistory;
	}

	public void setOrderHistory(List<String> orderHistory) {
		this.orderHistory = orderHistory;
	}

	public String getSignColor() {
		return signColor;
	}

	public void setSignColor(String signColor) {
		this.signColor = signColor;
	}

	public String getColorSignBase() {
		return isColorSignBase ? CommonConstant.TRUE_STRING : CommonConstant.FALSE_STRING;
	}

	public boolean isColorSignBase() {
		return isColorSignBase;
	}

	public void setColorSignBase(boolean isColorSignBase) {
		this.isColorSignBase = isColorSignBase;
	}

	/**
	 * 
	 * Get Preview image path
	 * @return previewPath String
	 */
	public String getPreviewPath() {
		if (isColorSignBase || isSkuman) {
			return previewPath;
		}
		String ipValue = StringUtils.EMPTY;
		String imageName = signName;
		if (StringUtils.contains(imageName, "#")) {
			imageName = StringUtils.replace(imageName, "#", "%23");
		}
		if (StringUtils.contains(imageName, "&")) {
			imageName = StringUtils.replace(imageName, "&", "%26");
		}

		StringBuilder sb = new StringBuilder();
		sb.append(ipValue);
		//sb.append("/media/uc/kiosk/sos/images/signbase/");
		sb.append(signPath);
		sb.append(getDept());
		sb.append("/");
		sb.append(getDept());
		sb.append("_");
		sb.append(StringUtils.trim(imageName));
		sb.append("_");
		sb.append(versionId);
		sb.append("_Reg.gif");
		previewPath = sb.toString();
		imagePath = sb.toString();
		largeImagePath = sb.toString();
		return previewPath;
	}

	public void setPreviewPath(String previewPath) {
		this.previewPath = previewPath;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getLargeImagePath() {
		return largeImagePath;
	}

	public void setLargeImagePath(String largeImagePath) {
		this.largeImagePath = largeImagePath;
	}

	public String getCloseImagePath() {
		return closeImagePath;
	}

	public void setCloseImagePath(String closeImagePath) {
		this.closeImagePath = closeImagePath;
	}

	public String getPrintLocation() {
		return printLocation;
	}

	public void setPrintLocation(String printLocation) {
		this.printLocation = printLocation;
	}

	/**
	 * 
	 * @return String
	 */
	public String getOriginSystem() {
		if (StringUtils.isBlank(originSystem)) {
			return "/Products/UC/SOS/SignBase";
		} else {
			return originSystem;
		}
	}

	public void setOriginSystem(String originSystem) {
		this.originSystem = originSystem;
	}

	/*
	 * public Currency getSignPrice(){ return signPrice; }
	 * 
	 * public void setSignPrice(Currency signPrice){ this.signPrice = signPrice; }
	 */

	// 0: None/Printed At Store, 1: Menards FT (stocked at GO), 2: Vendor FT
	// 3: Menards POD, 4:Vendor POD
	private int factTagType = 0;

	/**
	 *Constructor 
	 */
	public Sign() {
	}

	/**
	 * 
	 *Constructor 
	 *@param signID signID
	 */
	public Sign(int signID) {
		super();
		this.signID = signID;
	}

	/**
	 * 
	 *Constructor 
	 *@param signID signID
	 *@param yard yard
	 */
	public Sign(int signID, int yard) {
		super();
		this.signID = signID;
		this.yard = yard;
	}

	/**
	 *Constructor 
	 *@param signVersion SignVersion
	 *@param quantity int
	 *@param whiteSign int
	 *@param yard int
	 */
	public Sign(SignVersion signVersion, int quantity, int whiteSign, Integer yard, String signPath) {
		// this.assistmgr1 = sign.assistmgr1;
		// this.assistmgr2 = sign.assistmgr2;
		// this.assistmgr3 = sign.assistmgr3;
		// this.blueMartiniSign = sign.blueMartiniSign;
		// this.canOrder = sign.canOrder;
		// this.canPrintWhite = sign.canPrintWhite;
		// this.closeImagePath = sign.closeImagePath;
		this.dept = signVersion.getDept();
		// this.email = sign.email;
		// this.factTagType = sign.factTagType;
		this.flyerPoint = signVersion.getFlyerpoint();
		// this.frontendmgr = sign.frontendmgr;
		// this.generalMgr = sign.generalMgr;
		// this.imagePath = sign.imagePath;
		// this.isColorSignBase = sign.isColorSignBase;
		// this.isSignBase = sign.isSignBase;
		// this.isSkuman = sign.isSkuman;
		this.laminate = signVersion.getLaminate();
		// this.largeImagePath = sign.largeImagePath;
		// this.logicString = sign.logicString;
		// this.promoDescription = sign.promoDescription;
		this.orderableQuantity = quantity;
		// this.orderedQuantity = sign.orderedQuantity;
		// this.orderHistory = sign.orderHistory;
		// this.originSystem = sign.originSystem;
		// this.previewPath = sign.previewPath;
		// this.printAt = sign.printAt;
		// this.printLocation = sign.printLocation;
		// this.printWhite = sign.printWhite;
		// this.processingCount = sign.processingCount;
		// this.promoDesc = sign.promoDesc;
		// this.promoName = sign.promoName;
		this.promonbr = signVersion.getPromonbr() != null ? signVersion.getPromonbr() : 0;
		// this.receivingmgr = sign.receivingmgr;
		// this.requiresGMApproval = sign.requiresGMApproval;
		// this.saleSignInfo = sign.saleSignInfo;
		// this.signColor = sign.signColor;
		this.signID = signVersion.getSignId();
		this.signName = signVersion.getSignname();
		this.startDate = signVersion.getStartDate().toString();
		Stock stock = signVersion.getStock();
		this.stockDescription = stock.getDesc();
		this.stockHeight = stock.getHeight().floatValue();
		this.stockID = stock.getStockId();
		this.stockWidth = stock.getWidth().floatValue();
		this.stopDate = signVersion.getStopDate().toString();
		this.storePlanning = stock.getStorePlan();
		this.storeStartDate = signVersion.getStoreStartDate().toString();
		this.storeStopDate = signVersion.getStoreStopDate().toString();
		this.versionDescription = signVersion.getDesc();
		this.versionId = signVersion.getVersionId();
		this.whiteSign = whiteSign;
		this.yard = yard != null ? yard : 0;
		this.yardList = null;
		if (stock.getStorePrintable() == -1 && laminate == 0) {
			this.printAt = Sign.PRINT_AT_STORE;
		} else {
			this.printLocation = "1";
		}
		this.signPath = signPath;
	}

	public int getDept() {
		return dept;
	}

	public void setDept(int dept) {
		this.dept = dept;
	}

	public String getSignName() {
		return signName.trim();
	}

	public void setSignName(String signName) {
		this.signName = signName.trim();
	}

	public String getVersionDescription() {
		return versionDescription;
	}

	public void setVersionDescription(String versionDescription) {
		this.versionDescription = versionDescription.trim();
	}

	public String getStockDescription() {
		return stockDescription;
	}

	public void setStockDescription(String stockDescription) {
		this.stockDescription = stockDescription.trim();
	}

	public float getStockHeight() {
		return stockHeight;
	}

	public void setStockHeight(float stockHeight) {
		this.stockHeight = stockHeight;
	}

	public float getStockWidth() {
		return stockWidth;
	}

	public void setStockWidth(float stockWidth) {
		this.stockWidth = stockWidth;
	}

	public int getStockID() {
		return stockID;
	}

	public void setStockID(int stockID) {
		this.stockID = stockID;
	}

	public int getPromonbr() {
		return promonbr;
	}

	public void setPromonbr(int promonbr) {
		this.promonbr = promonbr;
	}

	public String getPromoName() {
		return promoName;
	}

	public void setPromoName(String promoName) {
		this.promoName = promoName;
	}

	public String getPromoDescription() {
		return promoDescription;
	}

	public void setPromoDescription(String promoDescription) {
		this.promoDescription = promoDescription;
	}

	public int getSignID() {
		return signID;
	}

	public void setSignID(int signID) {
		this.signID = signID;
	}

	/**
	 * 
	 * @param otherSign Sign
	 * @return boolean
	 */
	public boolean isTheSameAs(Sign otherSign) {
		boolean isTheSame = false;
		if (otherSign.getSignID() == this.getSignID()) {
			isTheSame = true;
		}
		return isTheSame;
	}

	/**
	 * 
	 * @return String
	 */
	public String getStockHeightDesc() {
		String desc = "";
		java.text.NumberFormat nF = java.text.NumberFormat.getInstance();
		nF.setMinimumFractionDigits(2);
		nF.setMaximumFractionDigits(2);
		desc = nF.format(new Float(stockHeight));
		return desc;
	}

	/**
	 * 
	 * @return String
	 */
	public String getStockWidthDesc() {
		String desc = "";
		java.text.NumberFormat nF = java.text.NumberFormat.getInstance();
		nF.setMinimumFractionDigits(2);
		nF.setMaximumFractionDigits(2);
		desc = nF.format(new Float(stockWidth));
		return desc;
	}

	public String getCost() {
		return "";
	}

	public String getAssistmgr2() {
		return assistmgr2;
	}

	public String getAssistmgr1() {
		return assistmgr1;
	}

	public String getAssistmgr3() {
		return assistmgr3;
	}

	public void setAssistmgr2(String assistmgr2) {
		this.assistmgr2 = assistmgr2;
	}

	public void setAssistmgr1(String assistmgr1) {
		this.assistmgr1 = assistmgr1;
	}

	public void setAssistmgr3(String assistmgr3) {
		this.assistmgr3 = assistmgr3;
	}

	public String getFrontendmgr() {
		return frontendmgr;
	}

	public String getGeneralmgr() {
		return generalMgr;
	}

	public void setGeneralmgr(String generalMgr) {
		this.generalMgr = generalMgr;
	}

	public void setFrontendmgr(String frontendmgr) {
		this.frontendmgr = frontendmgr;
	}

	public String getReceivingmgr() {
		return receivingmgr;
	}

	public void setReceivingmgr(String receivingmgr) {
		this.receivingmgr = receivingmgr;
	}

	public int getStorePlanning() {
		return storePlanning;
	}

	public void setStorePlanning(int storePlanning) {
		this.storePlanning = storePlanning;
	}

	public int getYard() {
		return this.yard;
	}

	public void setYard(int yard) {
		this.yard = yard;
	}

	public int getVersionId() {
		return this.versionId;
	}

	public void setVersionId(int vId) {
		this.versionId = vId;
	}

	public int getPrintAt() {
		return this.printAt;
	}

	public void setPrintAt(int at) {
		this.printAt = at;
	}

	public int getLaminated() {
		return this.laminate;
	}

	public void setLaminated(int laminate) {
		this.laminate = laminate;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getFlyerPoint() {
		return flyerPoint;
	}

	public void setFlyerPoint(int flyerPoint) {
		this.flyerPoint = flyerPoint;
	}

	public String getStartDate() {
		return startDate;
	}

	/**
	 * 
	 * @param startDate String
	 */
	public void setStartDate(String startDate) {
		if (startDate != null) {
			this.startDate = startDate.trim();
			if (startDate.length() > 0) {
				if (startDate.compareTo(ZERO_DATE) == 0) {
					this.startDate = "";
				} else {
					this.startDate = startDate;
				}
			}
		}
	}

	public String getStopDate() {
		return stopDate;
	}

	/**
	 * 
	 * @param stopDate String
	 */
	public void setStopDate(String stopDate) {
		if (stopDate != null) {
			this.stopDate = stopDate.trim();
			if (stopDate.length() > 0) {
				if (stopDate.compareTo(ZERO_DATE) == 0) {
					this.stopDate = "";
				} else {
					this.stopDate = stopDate;
				}
			}
		}
	}

	/**
	 * 
	 * @param date String
	 * @return Date
	 */
	public Date translateSignDate(String date) {
		SimpleDateFormat sD = new SimpleDateFormat();
		Date newDate = null;
		if (date == null || date.trim().length() == 0 || date.trim().compareTo(ZERO_DATE) == 0) {
			return null;
		}
		sD.applyPattern("yyyy-MM-dd");
		try {
			newDate = sD.parse(date);
		} catch (ParseException ex) {
			log.error("cant parse date " + date + " in Sign");
			// throw new RuntimeException("cant parse date " + date + " in Sign" + ex.getMessage());
		}
		return newDate;
	}

	public String getStoreStartDate() {
		return storeStartDate;
	}

	public String getStoreStopDate() {
		return storeStopDate;
	}

	/**
	 * 
	 * @param ssDate String
	 */
	public void setStoreStopDate(String ssDate) {
		if (ssDate != null) {
			this.storeStopDate = ssDate.trim();
			if (ssDate.length() > 0) {
				if (ssDate.compareTo(ZERO_DATE) == 0) {
					this.storeStopDate = "";
				} else {
					this.storeStopDate = ssDate;
				}
			}
		}
	}

	/**
	 * 
	 * @param stDate String
	 */
	public void setStoreStartDate(String stDate) {
		if (stDate != null) {
			this.storeStartDate = stDate.trim();
			if (stDate.length() > 0) {
				if (stDate.compareTo(ZERO_DATE) == 0) {
					this.storeStartDate = "";
				} else {
					this.storeStartDate = stDate;
				}
			}
		}
	}

	/**
	 * 
	 * @return boolean
	 */
	public boolean isOkayToView() {
		boolean isExpired = checkExpireDate();
		boolean storePlanCheck = checkStorePlanShow();
		return !isExpired && storePlanCheck;
	}

	/**
	 * 
	 * @return boolean
	 */
	private boolean checkStorePlanShow() {
		boolean isOkay = false;
		if (this.storePlanning != 0) {
			isOkay = true;
		} else {
			if (this.flyerPoint != 0) {
				isOkay = true;
			}
		}
		return isOkay;
	}

	/**
	 * 
	 * @return boolean
	 */
	private boolean checkExpireDate() {
		boolean isExpired = false;
		Date today = new Date();
		String logicString = "";
		if (getStopDateX().length() == 0 && getStartDateX().length() == 0) {
			logicString = logicString + "A-";
			return false; // not expired if dates not given
		}
		if (getStartDateX().length() == 0) {
			Date dEnd = translateSignDate(getStopDateX());
			isExpired = (today.after(dEnd));
			logicString = logicString + "B-";
			return isExpired;
		}
		if (getStopDateX().length() == 0) {
			Date dEnd = translateSignDate(getStartDateX());
			isExpired = (today.before(dEnd));
			logicString = logicString + "C-";
			return isExpired;
		}
		Date sDate = translateSignDate(getStartDateX());
		Date eDate = translateSignDate(getStopDateX());
		if (sDate.after(eDate)) {
			isExpired = isExpired(sDate, eDate, today);
			logicString = logicString + "D- eDate " + eDate + " startDate " + sDate;
		} else {
			boolean beforeToday = eDate.before(today) && sDate.before(today);
			isExpired = today.before(sDate) || (today.after(eDate) || today.compareTo(eDate) == 0) || beforeToday;
			logicString = logicString + "E-";
		}
		return isExpired;
	}

	/**
	 * 
	 * Check expiration
	 * @param sDate sDate
	 * @param eDate eDate
	 * @param today today
	 * @return isExpired
	 */
	private boolean isExpired(Date sDate, Date eDate, Date today) {
		return today.before(sDate) && (today.after(eDate) || today.compareTo(eDate) == 0);
	}

	/**
	 *
	 * @return String
	 */
	private String getStartDateX() {
		String sDate = null;
		if (getPrintAt() == PRINT_AT_STORE) {
			sDate = getStoreStartDate();
		} else {
			sDate = getStartDate();
		}
		return sDate;
	}

	/**
	 * 
	 * @return String
	 */
	private String getStopDateX() {
		String sDate = null;
		if (getPrintAt() == PRINT_AT_STORE) {
			sDate = getStoreStopDate();
		} else {
			sDate = getStopDate();
		}
		return sDate;
	}

	public int getWhiteSign() {
		return whiteSign;
	}

	public void setWhiteSign(int whiteSign) {
		this.whiteSign = whiteSign;
	}

	public int getOrderedQuantity() {
		return this.orderedQuantity;
	}

	public void setOrderedQuantity(int argOrderedQuantity) {
		this.orderedQuantity = argOrderedQuantity;
	}

	public int getProcessingCount() {
		return this.processingCount;
	}

	public void setProcessingCount(int processingCount) {
		this.processingCount = processingCount;
	}

	public int getPrintWhite() {
		return this.printWhite;
	}

	public void setPrintWhite(int argPrintWhite) {
		this.printWhite = argPrintWhite;
	}

	public int getFactTagType() {
		return this.factTagType;
	}

	public void setFactTagType(int argFactTag) {
		this.factTagType = argFactTag;
	}

	/*
	 * public List<SignSaleInfo> getSaleSignInfo() { return saleSignInfo; }
	 */

	public boolean getCanPrintWhite() {
		return canPrintWhite;
	}

	public void setCanPrintWhite(boolean canPrintWhite) {
		this.canPrintWhite = canPrintWhite;
	}

	/**
	 * 
	 * @param saleSignInfo SignSaleInfo
	 */
	public void setSaleSignInfo(SignSaleInfo saleSignInfo) {
		this.promonbr = Integer.parseInt(saleSignInfo.getPromoNbr());
		this.promoName = saleSignInfo.getPromoName().trim();
		this.promoDescription = saleSignInfo.getPromoDesc().trim();
		this.stockDescription = saleSignInfo.getColor().trim();
	}

	public void setOrderableQuantity(int orderableQuantity) {
		this.orderableQuantity = orderableQuantity;
	}

	public int getOrderableQuantity() {
		return orderableQuantity;
	}

	public boolean isRequiresGMApproval() {
		return requiresGMApproval;
	}

	public void setRequiresGMApproval(boolean requiresGMApproval) {
		this.requiresGMApproval = requiresGMApproval;
	}

	public void setYardList(List<String> yardList) {
		this.yardList = yardList;
	}

	public List<String> getYardList() {
		return yardList;
	}

	/**
	 * @return comma seperated String of yard IDs.
	 */
	public String getYardListString() {
		if (CollectionUtils.isEmpty(yardList)) {
			return StringUtils.EMPTY;
		}
		StringBuilder sb = new StringBuilder();
		for (String yardName : yardList) {
			if (StringUtils.equals(yardName, CommonConstant.GO_STORE_NUMBER)) {
				continue;
			}
			sb.append(yardName);
			sb.append(CommonConstant.COMMA);
		}
		return StringUtils.substringBeforeLast(sb.toString(), CommonConstant.COMMA);
	}

	/**
	 * 
	 * @return String
	 */
	public String getPrintablePath() {
		if (printAt == 1 && !isColorSignBase) {
			return "printStore";
		}
		return "printSign";
	}

	public boolean isPrintWhite() {
		return whiteSign == WHITE_BY_DEPT;
	}

	public String getCapacity() {
		if (factTagType == NONE_FACT_TAG) {
			return stockWidth + "X" + stockHeight;
		}
		return StringUtils.EMPTY;
	}

	public String getSignPrice() {
		return signPrice;
	}

	public void setSignPrice(String signPrice) {
		this.signPrice = signPrice;
	}

	public String getSignPath() {
		return signPath;
	}

	public void setSignPath(String signPath) {
		this.signPath = signPath;
	}
	
	public String getItemType() {
		if (isColorSignBase) {
			return MenardOrderItemType.COLOR_SIGN.getCode();
		}
		if (isSkuman) {
			return MenardOrderItemType.SKU_MAN.getCode();
		}
		return MenardOrderItemType.SIGN.getCode();
	}
}
