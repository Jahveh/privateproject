package com.menards.ssc.domain.order;

import java.io.Serializable;

/**
 * 
 * <p>MenardCartinfoDTO</p>
 * <p>menard cart info dto</p>
 *
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class MenardCartinfoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1404316460057680610L;

	private String listName;

	private String comment;

	public String getListName() {
		return listName;
	}

	public void setListName(String listName) {
		this.listName = listName;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

}
