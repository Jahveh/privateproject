package com.menards.ssc.domain.order;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.menards.ssc.constants.CommonConstant;

/**
 * <p>MenardOrderItemApproveRequestDTO</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class MenardOrderItemApproveRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7763300651068387793L;
	private List<ItemApproveRequestDTO> items;

	/**
	 * @return List<ItemApproveRequestDTO>
	 */
	public List<ItemApproveRequestDTO> getItems() {
		return items;
	}

	/**
	 * @param items List<ItemApproveRequestDTO>
	 */
	public void setItems(List<ItemApproveRequestDTO> items) {
		this.items = items;
	}

	/**
	 * @return String
	 */
	@Override
	public String toString() {
		if (CollectionUtils.isEmpty(items)) {
			return StringUtils.EMPTY;
		}
		StringBuilder sb = new StringBuilder();
		for (ItemApproveRequestDTO item : items) {
			if (StringUtils.isBlank(item.getStatus())) {
				continue;
			}
			sb.append(item.getId());
			sb.append(CommonConstant.COMMA);
			sb.append(item.getStatus());
			sb.append(CommonConstant.COMMA);
			sb.append(item.getReason());
			sb.append(CommonConstant.COMMA);
		}
		return sb.toString();
	}

}
