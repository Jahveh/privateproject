package com.menards.ssc.domain.sign;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;

/**
 * 
 * <p>SignSaleInfo</p>
 * <p>SignSaleInfo table</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author bill01.zhang
 * @version 1.0
 */
@Entity
public class SignSaleInfo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4500498233110578167L;

	@Id
	@Column(name = "iSignId")
	private Integer signId;
	
	@Transient
	private String promoNbr;
	@Transient
	private String promoDesc;
	@Transient
	private String startDate;
	@Transient
	private String stopDate;
	@Transient
	private String promoName;
	@Transient
	private String color;

	/**
	 * 
	 *Constructor
	 */
	public SignSaleInfo() {
		super();
	}

	/**
	 * 
	 *Constructor 
	 *@param signId signId
	 */
	public SignSaleInfo(Integer signId) {
		super();
		this.signId = signId;
	}

	/**
	 * 
	 *Constructor 
	 *@param signId signId
	 *@param promoNbr promoNbr
	 *@param promoDesc promoDesc
	 *@param promoName promoName
	 *@param color color
	 */
	public SignSaleInfo(Integer signId, String promoNbr, String promoDesc, String promoName, String color) {
		super();
		this.signId = signId;
		this.promoNbr = StringUtils.trimToEmpty(promoNbr);
		this.promoDesc = StringUtils.trimToEmpty(promoDesc);
		this.promoName = StringUtils.trimToEmpty(promoName);
		this.color = StringUtils.trimToEmpty(color);
	}

	public String getPromoNbr() {
		return promoNbr;
	}

	public void setPromoNbr(String promoNbr) {
		this.promoNbr = promoNbr;
	}

	public String getPromoDesc() {
		return promoDesc;
	}

	public void setPromoDesc(String promoDesc) {
		this.promoDesc = promoDesc;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getStopDate() {
		return stopDate;
	}

	public void setStopDate(String stopDate) {
		this.stopDate = stopDate;
	}

	public String getPromoName() {
		return promoName;
	}

	public void setPromoName(String promoName) {
		this.promoName = promoName;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
}
