package com.menards.ssc.domain.catalog;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.menards.ssc.config.PropertiesConfig;
import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.domain.sign.SignHistory;
import com.menards.ssc.domain.sign.SignSaleInfo;
import com.menards.ssc.domain.sign.SignVersion;
import com.menards.ssc.domain.sign.Stock;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardOrderItemType;
import com.menards.ssc.enums.MenardOrderRequestType;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

/**
 * <p>SignDTO</p>
 * <p>sign dto</p>
 * <p>
 *  convert attributes from sign
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class SignDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4606613365236557800L;
	private MenardUserDetails user;
	private SignVersion signVersion;
	private Stock stock;
	private List<String> yardList;
	private List<SignHistory> histories;
	private int processingCount;
	private int orderableQuantity;
	private int printAt;
	private String printLocation;
	private int factTagType = -99;
	private Boolean isColorSignBase = false;
	private String yard;
	private int printWhite = 0;
	private String email;
	private SignSaleInfo saleSign;
	private String type;

	/**
	 *Constructor
	 */
	public SignDTO() {
		this.user = MenardSecurityContextHolder.getMenardUserDetails();
	}

	public String getType() {
		return type;
	}

	public SignVersion getSignVersion() {
		return signVersion;
	}

	public void setSignVersion(SignVersion signVersion) {
		this.signVersion = signVersion;
	}

	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}

	public void setYardList(List<String> yardList) {
		this.yardList = yardList;
	}

	public int getPrintAt() {
		return printAt;
	}

	public void setPrintAt(int printAt) {
		this.printAt = printAt;
	}

	public String getPrintLocation() {
		return printLocation;
	}

	public void setPrintLocation(String printLocation) {
		this.printLocation = printLocation;
	}

	public int getProcessingCount() {
		return processingCount;
	}

	public void setProcessingCount(int processingCount) {
		this.processingCount = processingCount;
	}

	public int getOrderableQuantity() {
		return orderableQuantity;
	}

	public void setOrderableQuantity(int orderableQuantity) {
		this.orderableQuantity = orderableQuantity;
	}

	public int getFactTagType() {
		return factTagType;
	}

	public void setFactTagType(int factTagType) {
		this.factTagType = factTagType;
	}

	public Boolean getIsColorSignBase() {
		return isColorSignBase;
	}

	public void setIsColorSignBase(Boolean isColorSignBase) {
		this.isColorSignBase = isColorSignBase;
	}

	public List<SignHistory> getHistories() {
		return histories;
	}

	public void setHistories(List<SignHistory> histories) {
		this.histories = histories;
	}

	/**
	 * get sign Id
	 * @return int
	 */
	public int getSignId() {
		return signVersion.getSignId();
	}

	/**
	 * get description short
	 * @return string short description
	 */
	public String getDescriptionShort() {
		return signVersion.getDesc();
	}

	/**
	 *  get description long
	 * @return string long description
	 */
	public String getDescriptionLong() {
		if (saleSign != null) {
			boolean other = factTagType == Sign.MENARDS_FACT_TAG || factTagType == Sign.MENARDS_POD
					|| factTagType == Sign.VENDOR_FACT_TAG || factTagType == Sign.VENDOR_POD;
			if (!other) {
				if (Integer.valueOf(saleSign.getPromoNbr()) > 0) {
					return saleSign.getPromoName() + " / " + saleSign.getPromoDesc();
				}
			}
		}
		return stock.getDesc();
	}

	/**
	 * get yard list
	 * @return sign yard list
	 */
	public String getYardList() {
		if (user.isGOUser()) {
			StringBuffer yardString = new StringBuffer();

			if (yardList.size() > 0) {
				for (int i = 0; i <= yardList.size() - 1; i++) {
					if (!yardList.get(i).equals("0")) {
						yardString.append(yardList.get(i).toString()).append(",");
						if (i != 0 && i % 7 == 0) {
							yardString.append("\n");
						}
					}
				}
			}
			String string = yardString.toString();
			if (string.length() > 2) {
				string = string.substring(0, yardString.length() - 1);
			}
			return string;
		}
		return null;
	}

	/**
	 * get price
	 * @return price price
	 */
	public String getPrice() {
		return null;
	}

	/**
	 * determine to show add to cart button
	 * @return boolean boolean
	 */
	public boolean getShowAdd2CartBtn() {
		return isCanOrder();
	}


    /**
     * show or hide not orderable message
     * @return
     */
    public boolean getDisplayNotOrderableMsg() {
        return !user.isGOUser() && !getShowAdd2CartBtn();
    }

	/**
	 * is can order
	 * @return boolean
	 */
	public boolean isCanOrder() {
		if (StringUtils.equals(MenardOrderItemType.SKU_MAN.getCode(), type)) {
			return true;
		}
		boolean orderable = false;
		if (user.isGOUser()) {
			orderable = true;
		} else {
			orderable = this.getCanOrder();
		}

		return orderable;
	}

	private boolean isColorSignBase() {
		return isColorSignBase;
	}

	/**
	 * if the user is not a GM and there are still requests being processed do not allow them to
	 * @return boolean orderable
	 */
	private boolean getCanOrder() {
		String storeRole = user.getStorePerformRole();
		boolean result = true;
		if (!"GM".equalsIgnoreCase(storeRole) && getProcessingCount() >= getOrderableQuantity()) {
			result = false;
		}
		return result;
	}

	/**
	 * determine to show the message
	 * Available for shipment in approximately <%=delayInDays %> days.
	 * @return boolean boolean
	 */
	public boolean getShowShipmentDays() {
		return getPrintAt() != 1 || isColorSignBase();
	}

	/**
	 * get shipment message
	 * @return message message
	 */
	public String getShipmentMsg() {
		int days = this.getShipmentDays();
		return "Available for shipment in approximately " + days + " days.";
	}

	/**
	 *
	 * Get Fulfiller type
	 * @return MenardFulfillerType MenardFulfillerType
	 */
	public MenardFulfillerType getFulfillerType() {
		MenardFulfillerType fulfillerType = MenardFulfillerType.SIGN_PRODUCTION;

		boolean other = factTagType == Sign.MENARDS_FACT_TAG || factTagType == Sign.MENARDS_POD
				|| factTagType == Sign.VENDOR_FACT_TAG || factTagType == Sign.VENDOR_POD;
		if (!other) {
			if (stock.getStorePlan() == 1 || stock.getStorePlan() == -1) {
				fulfillerType = MenardFulfillerType.SIGN_SHOP;
			}
		}
		return fulfillerType;
	}

	private int getStorePlanning() {
		return stock.getStorePlan();
	}

	private int getStockID() {
		return stock.getStockId();
	}

	/**
	 *
	 * Get request type
	 * @return request request
	 */
	public MenardOrderRequestType getRequestType() {
		MenardOrderRequestType requestType = MenardOrderRequestType.Color_Signbase;
		if (factTagType == Sign.MENARDS_FACT_TAG || factTagType == Sign.MENARDS_POD) {
			int dept = signVersion.getDept();
			switch (dept) {
				case 1:
					requestType = MenardOrderRequestType.BM_Fact_Tag;
					break;
				case 2:
					requestType = MenardOrderRequestType.Hardware_Fact_Tag;
					break;
				case 3:
					requestType = MenardOrderRequestType.Electrical_Fact_Tag;
					break;
				case 4:
					requestType = MenardOrderRequestType.Millwork_Fact_Tag;
					break;
				case 5:
					requestType = MenardOrderRequestType.Wall_Fact_Tag;
					break;
				case 6:
					requestType = MenardOrderRequestType.Plumbing_Fact_Tag;
					break;
				case 7:
					requestType = MenardOrderRequestType.Floor_Fact_Tag;
					break;
				default:
					break;
			}
		} else if (factTagType == Sign.VENDOR_FACT_TAG || factTagType == Sign.VENDOR_POD) {
			String factTagEmail = null;
			String debug = PropertiesConfig.getValue("debug");
			if (Boolean.parseBoolean(debug)) {
				factTagEmail = PropertiesConfig.getValue("debugEmail");
			} else {
				factTagEmail = PropertiesConfig.getValue(this.getSignVersion().getSignname().trim());
			}

			if (factTagEmail != null) {
				requestType = MenardOrderRequestType.Vendor_Fact_Tag;
			} else {
				int dept = signVersion.getDept();
				switch (dept) {
					case 1:
						requestType = MenardOrderRequestType.BM_Fact_Tag;
						break;
					case 2:
						requestType = MenardOrderRequestType.Hardware_Fact_Tag;
						break;
					case 3:
						requestType = MenardOrderRequestType.Electrical_Fact_Tag;
						break;
					case 4:
						requestType = MenardOrderRequestType.Millwork_Fact_Tag;
						break;
					case 5:
						requestType = MenardOrderRequestType.Wall_Fact_Tag;
						break;
					case 6:
						requestType = MenardOrderRequestType.Plumbing_Fact_Tag;
						break;
					case 7:
						requestType = MenardOrderRequestType.Floor_Fact_Tag;
						break;
					default:
						break;
				}
			}

		}
		// Merch sign or fact tag printed at store
		else {
			requestType = MenardOrderRequestType.Merch_Sign; // default
			if (getStorePlanning() == 2) {
				// Sign Production Zoomer
				requestType = MenardOrderRequestType.Zoomer;
			}
			if (getStorePlanning() == -1 || getStorePlanning() == 1) {

				if (getStockID() == 1007) {
					// 16x24 sign
					requestType = MenardOrderRequestType.Green_Steel_16x24;
				} else if (getStockID() == 1040) {
					// 10x16 sign
					requestType = MenardOrderRequestType.White_Steel_10x16;
				} else {
					// Default to Sign Shop GSS
					requestType = MenardOrderRequestType.GSS_Sign;
				}
			}
		} // end else Merch sign or fact tag printed at store

		return requestType;
	}

	public String getStorePrint() {
		return this.getPrintAt() > 0 ? CommonConstant.TRUE_STRING : CommonConstant.FALSE_STRING;
	}

	/**
	 *
	 * Get shipment days
	 * @return days shippment days
	 */
	private int getShipmentDays() {
		int days = 0;
		if (MenardFulfillerType.SIGN_SHOP.equals(getFulfillerType())) {
			days = 21;
		} else {
			days = 14;
		}
		return days;
	}

	/**
	 * not orderable message
	 * @return message message
	 */
	public String getNotOrderableMsg() {
		int days = this.getShipmentDays();
		return "This sign can not be reordered at this time - the last ordered date is less than the " + days
				+ "days allowed.";
	}

	/**
	 * run program Open Sigma Application
	 * @return boolean boolean
	 */
	public boolean getRunOpenSigmaApplication() {
		return user.isGOUser() && isColorSignBase();
	}

	/**
	 * determine to show last orders
	 * @return boolean boolean
	 */
	public boolean getShowLastOrders() {
		return !user.isGOUser();
	}

	/**
	 * get last orders
	 * @return list orders
	 */
    public List<String> getLastOrders() {
        List<String> orders = new ArrayList<String>();
        if (CollectionUtils.isEmpty(histories)) {
            orders.add("No orders recorded in the last 60 days.");
        } else {
            int limit = (histories.size() >= 10 ? 10 : histories.size());
            int i = 0;
            for (SignHistory history : histories) {
                if (i < limit) {
                    orders.add("Requested by " + history.getYard() + " on " + history.getProcessDate() + " | "
                            + history.getDescription());
                } else {
                    break;
                }
                i++;
            }
        }
        return orders;
    }

	/**
	 * return skuCode
	 * @return string string
	 */
	public String getModelNum() {
		if (isColorSignBase()) {
			return signVersion.getSignId().toString();
		} else {
			return signVersion.getSignname();
		}
	}

	/**
	 * get Series Numbe
	 * @return SeriesNumber
	 */
	public String getSeriesNumber() {
		return signVersion.getSignname();
	}

	/**
	 * stock width X stock height
	 * @return string string
	 */
	public String getSize() {
		if (stock == null) {
			return StringUtils.EMPTY;
		}
		return stock.getWidth().doubleValue() + "X" + stock.getHeight().doubleValue();
	}

	/**
	 * get product image url
	 * @return img url
	 */
	public List<ImageryDTO> getProductImgList() {
		// todo-e
		List<ImageryDTO> lst = new ArrayList<ImageryDTO>();
		
		// String ipValue = "";
		// if(com.menards.uc.util.UCUtil.getList("application").getBoolean("useImageIP",false)){
		// ipValue = com.menards.uc.util.UCUtil.getList("application").getString("imageIP");
		// }
		if (signVersion != null) {
			
			String imageName = signVersion.getSignname();
			// In case, someone changes the imageName in code.
			if (imageName != null) {
				if (imageName.contains("#")) {
					imageName = imageName.replace("#", "%23");
				}
				if (imageName.contains("&")) {
					imageName = imageName.replace("&", "%26");
				}
				
				imageName = imageName.replaceAll(" ", "");
			}
			
			
			if (signVersion.getDept() != null
					&& signVersion.getVersionId() != null
					&& StringUtils.isNotEmpty(imageName)) {
				
				// String sSignbasePath = ipValue + "/media/uc/kiosk/sos/images/signbase/"
				String sSignbasePath = "/media/uc/kiosk/sos/images/signbase/" + signVersion.getDept() + "/"
						+ signVersion.getDept() + "_" + imageName + "_" + signVersion.getVersionId() + "_Reg.gif";
				
				ImageryDTO img = new ImageryDTO();
				img.setThumb(sSignbasePath);
				img.setSmall(sSignbasePath);
				img.setBig(sSignbasePath);
				lst.add(img);
			}
		}
		
		return lst;

	}

	/**
	 * getColor
	 * @return String String
	 */
	public String getColor() {
		if (factTagType > -99) {
			return "Fact Tag";
		}		
		
		if (saleSign == null && stock == null) {
			return StringUtils.EMPTY;
		}
		if (saleSign == null) {
			return stock.getDesc();
		}
		return saleSign.getColor();
	}

	public String getYard() {
		return yard;
	}

	public void setYard(String yard) {
		this.yard = yard;
	}

	public int getPrintWhite() {
		return printWhite;
	}

	public void setPrintWhite(int printWhite) {
		this.printWhite = printWhite;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public SignSaleInfo getSaleSign() {
		return saleSign;
	}

	public void setSaleSign(SignSaleInfo saleSign) {
		this.saleSign = saleSign;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
