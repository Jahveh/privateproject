package com.menards.ssc.domain.sign;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * <p>SignDist</p> 
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Entity
@Table(name = "sign_dist")
public class SignDist implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4678944424327516659L;

	@Id
	@Column(name = "dist_id")
	private Integer distId;

	@Column(name = "sign_id")
	private Integer signId;

	/*
	 * @ManyToOne(targetEntity = SignVersion.class, fetch=FetchType.EAGER)
	 * 
	 * @JoinColumn(name = "sign_id") private SignVersion signVersion;
	 */

	@Column(name = "yard_grp")
	private Integer yardGroup;

	@Column(name = "qty")
	private Integer quanity;

	public Integer getDistId() {
		return distId;
	}

	public void setDistId(Integer distId) {
		this.distId = distId;
	}

	public Integer getYardGroup() {
		return yardGroup;
	}

	public void setYardGroup(Integer yardGroup) {
		this.yardGroup = yardGroup;
	}

	public Integer getQuanity() {
		return quanity;
	}

	public void setQuanity(Integer quanity) {
		this.quanity = quanity;
	}

	public Integer getSignId() {
		return signId;
	}

	public void setSignId(Integer signId) {
		this.signId = signId;
	}
}
