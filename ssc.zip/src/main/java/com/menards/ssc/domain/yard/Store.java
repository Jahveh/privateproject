package com.menards.ssc.domain.yard;

import java.io.Serializable;

/**
 * 
 * <p>Store</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public class Store implements Serializable {

	private static final long serialVersionUID = 7940231357435790429L;
	private String storeNumber;
	private String storeAbbreviation;
	private String storeName;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zip;
	private String phoneNumber;
	private String faxNumber;
	private String netId;

	/**
	 * 
	 *Constructor
	 */
	public Store() {
		storeNumber = null;
		storeAbbreviation = null;
		storeName = null;
		address1 = null;
		address2 = null;
		city = null;
		state = null;
		zip = null;
		phoneNumber = null;
		faxNumber = null;
		netId = null;
	}

	/**
	 * @param storeNumber the storeNumber to set
	 */
	public void setStoreNumber(String storeNumber) {
		this.storeNumber = storeNumber;
	}

	/**
	 * @return the storeNumber
	 */
	public String getStoreNumber() {
		return storeNumber;
	}

	/**
	 * @param storeAbbreviation the storeAbbreviation to set
	 */
	public void setStoreAbbreviation(String storeAbbreviation) {
		this.storeAbbreviation = storeAbbreviation;
	}

	/**
	 * @return the storeAbbreviation
	 */
	public String getStoreAbbreviation() {
		return storeAbbreviation;
	}

	/**
	 * @param storeName the storeName to set
	 */
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	/**
	 * @return the storeName
	 */
	public String getStoreName() {
		return storeName;
	}

	/**
	 * @param address1 the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	/**
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}

	/**
	 * @param address2 the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	/**
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param zip the zip to set
	 */
	public void setZip(String zip) {
		this.zip = zip;
	}

	/**
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}

	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param faxNumber the faxNumber to set
	 */
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	/**
	 * @return the faxNumber
	 */
	public String getFaxNumber() {
		return faxNumber;
	}

	/**
	 * @param netId the netId to set
	 */
	public void setNetId(String netId) {
		this.netId = netId;
	}

	/**
	 * @return the netId
	 */
	public String getNetId() {
		return netId;
	}

	@Override
	public String toString() {
		String toString = "storeNumber: " + storeNumber + "\nstoreName: " + storeName + "\naddress1: " + address1
				+ "\naddress2: " + address2 + "\ncity: " + city + "\nstate: " + state + "\nzip: " + zip
				+ "\nphoneNumber: " + phoneNumber + "\nfaxNumber: " + faxNumber + "\nnetId: " + netId;
		return toString;
	}
}
