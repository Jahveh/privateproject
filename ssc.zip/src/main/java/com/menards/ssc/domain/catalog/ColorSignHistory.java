package com.menards.ssc.domain.catalog;

import java.io.Serializable;

/**
 * 
 * <p>ColorSignHistory</p> 
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public class ColorSignHistory implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1805315138750977767L;
	private String userName;
	private String dateStr;
	private String description;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getDateStr() {
		return dateStr;
	}

	public void setDateStr(String dateStr) {
		this.dateStr = dateStr;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
