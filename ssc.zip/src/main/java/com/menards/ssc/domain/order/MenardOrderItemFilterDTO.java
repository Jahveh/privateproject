/**
 *
 */
package com.menards.ssc.domain.order;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.enums.MenardQueryDateInterval;

/**
 * <p>MenardOrderItemFilterDTO</p>
 *
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class MenardOrderItemFilterDTO implements Serializable {

	private static final long serialVersionUID = 4622987146896956610L;
	private String storeId;
	private String trackingStatus;
	private String requestType;
	private Integer days = MenardQueryDateInterval.FOURTEEN.getDays();
	private String sort;

	/*@Min(1)
	@Max(999999999)*/
	private Long skuId;

	@Min(1)
	@Max(999999999)
	private Long orderId;
	private Collection<String> statusSet = new HashSet<String>();

	private Integer page = 1;
	private Integer size = 200;

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getTrackingStatus() {
		return trackingStatus;
	}

	public void setTrackingStatus(String trackingStatus) {
		this.trackingStatus = trackingStatus;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public Integer getDays() {
		return days;
	}

	public void setDays(Integer days) {
		this.days = days;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(storeId);
		sb.append(CommonConstant.COMMA);
		sb.append(trackingStatus);
		sb.append(CommonConstant.COMMA);
		sb.append(requestType);
		sb.append(CommonConstant.COMMA);
		sb.append(days);
		sb.append(CommonConstant.COMMA);
		sb.append(sort);
		sb.append(CommonConstant.COMMA);
		sb.append(orderId);
		sb.append(CommonConstant.COMMA);
		return sb.toString();
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public Long getSkuId() {
		return skuId;
	}

	public void setSkuId(Long skuId) {
		this.skuId = skuId;
	}

	public Collection<String> getStatusSet() {
		return statusSet;
	}

	public void setStatusSet(Collection<String> statusSet) {
		this.statusSet = statusSet;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getSize() {
		return size;
	}

	public void setSize(Integer size) {
		this.size = size;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((days == null) ? 0 : days.hashCode());
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		result = prime * result + ((page == null) ? 0 : page.hashCode());
		result = prime * result + ((requestType == null) ? 0 : requestType.hashCode());
		result = prime * result + ((size == null) ? 0 : size.hashCode());
		result = prime * result + ((skuId == null) ? 0 : skuId.hashCode());
		result = prime * result + ((sort == null) ? 0 : sort.hashCode());
		result = prime * result + ((statusSet == null) ? 0 : statusSet.hashCode());
		result = prime * result + ((storeId == null) ? 0 : storeId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		MenardOrderItemFilterDTO other = (MenardOrderItemFilterDTO) obj;
		if (days == null) {
			if (other.days != null) {
				return false;
			}
		} else if (!days.equals(other.days)) {
			return false;
		}
		if (orderId == null) {
			if (other.orderId != null) {
				return false;
			}
		} else if (!orderId.equals(other.orderId)) {
			return false;
		}
		if (page == null) {
			if (other.page != null) {
				return false;
			}
		} else if (!page.equals(other.page)) {
			return false;
		}
		if (requestType == null) {
			if (other.requestType != null) {
				return false;
			}
		} else if (!requestType.equals(other.requestType)) {
			return false;
		}
		if (size == null) {
			if (other.size != null) {
				return false;
			}
		} else if (!size.equals(other.size)) {
			return false;
		}
		if (skuId == null) {
			if (other.skuId != null) {
				return false;
			}
		} else if (!skuId.equals(other.skuId)) {
			return false;
		}
		if (sort == null) {
			if (other.sort != null) {
				return false;
			}
		} else if (!sort.equals(other.sort)) {
			return false;
		}
		if (statusSet == null) {
			if (other.statusSet != null) {
				return false;
			}
		} else if (!statusSet.equals(other.statusSet)) {
			return false;
		}
		if (storeId == null) {
			if (other.storeId != null) {
				return false;
			}
		} else if (!storeId.equals(other.storeId)) {
			return false;
		}
		return true;
	}

}
