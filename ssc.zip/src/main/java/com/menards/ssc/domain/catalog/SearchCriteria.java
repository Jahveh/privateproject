/**
 *
 */
package com.menards.ssc.domain.catalog;

import java.io.Serializable;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * <p>SearchCriteria</p>
 * <p>All the info related to search</p>
 * <p>
 * Hold all the parameters relevant to search functionality
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */

public class SearchCriteria implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5504393884717972153L;

	@Min(1)
	private Integer page = 1;

	@Min(1)
	@NotNull
	private Integer pageSize = 200;

	private String sortQuery;

	@NotNull
	@Size(min = 3, max = 40)
	private String query;

	@NotNull
	private String type;

	private String yardNumber;

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getSortQuery() {
		return sortQuery;
	}

	public void setSortQuery(String sortQuery) {
		this.sortQuery = sortQuery;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getYardNumber() {
		return yardNumber;
	}

	public void setYardNumber(String yardNumber) {
		this.yardNumber = yardNumber;
	}

	public String[] getQueryArray() {
		return new String[] { "", type, yardNumber, query };
	}
}
