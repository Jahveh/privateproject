/**
 *
 */
package com.menards.ssc.domain.order;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.broadleafcommerce.core.catalog.domain.Product;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.constants.OrderItemAttributeKey;
import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardSku;
import com.menards.ssc.domain.sign.Sign;
import com.menards.ssc.enums.MenardDepartment;
import com.menards.ssc.enums.MenardFulfillerType;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.MenardOrderItemType;
import com.menards.ssc.enums.MenardOrderRequestType;

/**
 * <p>MenardOrderItemDTO</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class MenardOrderItemDTO implements Serializable {

	private static final long serialVersionUID = -6998505951641317253L;
	private String storeId;
	private String storeName;
	private String dept;
	private String requestor;
	private Long orderId;
	private Long orderItemId;
	private String hist;
	private String skucode;
	private String prodcutId;
	private Integer quantity;
	private String cost;
	private String description;
	private String comments;
	private String status;
	private String statusCode;
	private String statusDate;
	private String result;
	private String orderComments;
	private String preStatus;
	private Boolean enableBackOrder;
	private Date submitDate;
	private Boolean enableApprove = true;

	/**
	 *Constructor
	 */
	public MenardOrderItemDTO() {
	}

	/**
	 *Constructor
	 *@param orderItem MenardOrderItem
	 */
	public MenardOrderItemDTO(MenardOrderItem orderItem) {
		this(orderItem, null);
	}

	/**
	 *Constructor
	 *@param orderItem MenardOrderItem
	 *@param sign sign
	 */
	public MenardOrderItemDTO(MenardOrderItem orderItem, Sign sign) {

		MenardOrder order = (MenardOrder) orderItem.getMenardOrder();

		this.storeId = order.getStoreId();
		this.dept = MenardDepartment.getNameByKey(order.getDeptId());
		this.requestor = order.getRequestBy();

		this.orderId = orderItem.getMenardOrder().getId();
		this.orderItemId = orderItem.getId();
		this.hist = orderItem.getName();
		this.statusCode = orderItem.getStatus();

		MenardSku sku = (MenardSku) orderItem.getSku();

		// Color sign order item, the sku is null
		if (sku != null) {
			skucode = sku.getSkuCode();
			String menardSku = sku.getMenardSku();
			if (StringUtils.isNotEmpty(menardSku)) {
				skucode = menardSku;
			}
		}

		Product product = orderItem.getProduct();
		//description = StringUtils.EMPTY;
		if (product != null) {
			/*Map<String, ProductAttribute> map = product.getProductAttributes();
			ProductAttribute longDesc = map.get(MenardUtil.getMappingKey(ProductAttributeKey.DESCRIPTION_LONG));
			if (longDesc != null && StringUtils.isNotBlank(longDesc.getValue())) {
				description = StringUtils.trimToEmpty(longDesc.getValue());
			}
			ProductAttribute shortDesc = map.get(MenardUtil.getMappingKey(ProductAttributeKey.DESCRIPTION_SHORT));
			if (shortDesc != null && StringUtils.isNotBlank(shortDesc.getValue())) {
				if (StringUtils.isNotBlank(description)) {
					description = description + SEPARATOR + shortDesc.getValue();
				} else {
					description = StringUtils.trimToEmpty(shortDesc.getValue());
				}
			}

			prodcutId = product.getId().toString();*/
			if (product instanceof MenardProduct) {
				this.prodcutId = ((MenardProduct) product).getModelNum();
			}
		}

		if (StringUtils.equals(MenardOrderItemType.COLOR_SIGN.getCode(), orderItem.getItemType())) {
			/*if (orderItem.getOrderItemAttributes().get("description") != null) {
				description = orderItem.getOrderItemAttributes().get("description").toString();
			}*/
			if (sign != null) {
				cost = sign.getSignPrice();
			}

			if (orderItem.getOrderItemAttributes().get(OrderItemAttributeKey.SIGN_NAME_ATTRIBUTE_NAME) != null) {
				prodcutId = orderItem.getOrderItemAttributes().get(OrderItemAttributeKey.SIGN_NAME_ATTRIBUTE_NAME).toString();
			}
			skucode = CommonConstant.DEFAULT_SKU_CODE;
		}

		// sign = null
		if (StringUtils.equals(MenardOrderItemType.SIGN.getCode(), orderItem.getItemType())
				|| StringUtils.equals(MenardOrderItemType.SKU_MAN.getCode(), orderItem.getItemType())) {
			/*if (orderItem.getOrderItemAttributes().get("description") != null) {
				description = orderItem.getOrderItemAttributes().get("description").toString();
			}*/

			/* prodcutId = orderItem.getSignId().toString(); */
			if (orderItem.getOrderItemAttributes().get(OrderItemAttributeKey.SIGN_NAME_ATTRIBUTE_NAME) != null) {
				prodcutId = orderItem.getOrderItemAttributes().get(OrderItemAttributeKey.SIGN_NAME_ATTRIBUTE_NAME).toString();
			}
			skucode = CommonConstant.DEFAULT_SKU_CODE;
		}

		/*
		 * Setting the approve radio, only when both of product and sku both are active enable the approve radio
		 */
		/*if (sku != null && !sku.isActive() || product != null && !product.isActive()) {
			enableApprove = false;
		}*/
		this.quantity = orderItem.getQuantity();
		this.enableBackOrder = MenardOrderItemStatus.PENDING_GO.getValue().equals(orderItem.getStatus())
				&& enableApprove;
		this.status = MenardOrderItemStatus.getDescriptionByValue(orderItem.getStatus());
		if (orderItem.getStatusDate() != null) {
			this.statusDate = (new SimpleDateFormat(CommonConstant.STATUS_DATE_FORMAT)).format(orderItem
					.getStatusDate());
		}

		this.comments = orderItem.getNotes();
        this.description = orderItem.getDescription();
		for (MenardOrderItemTrackingHistory history : orderItem.getHistory()) {
			if (StringUtils.isNotBlank(history.getComment())) {
				this.comments = history.getComment();
			}
		}
	}
	
	
	/**
	 *Constructor
	 *@param orderItem MenardOrderItem
	 *@param sign sign
	 */
	public MenardOrderItemDTO(String history, MenardOrderItem orderItem) {

		MenardOrder order = (MenardOrder) orderItem.getMenardOrder();
		this.storeId = order.getStoreId();
		this.dept = MenardDepartment.getNameByKey(order.getDeptId());
		this.requestor = order.getRequestBy();
		this.orderId = orderItem.getMenardOrder().getId();
		this.orderItemId = orderItem.getId();
		this.statusCode = orderItem.getStatus();		
		String bmSku = orderItem.getBmSku();
		prodcutId = StringUtils.substring(bmSku, 7, StringUtils.length(bmSku));
		description = orderItem.getDescription();
		skucode = orderItem.getMenardSkuStr();
		this.quantity = orderItem.getQuantity();		
		this.status = MenardOrderItemStatus.getDescriptionByValue(orderItem.getStatus());
		if (orderItem.getStatusDate() != null) {
			this.statusDate = (new SimpleDateFormat(CommonConstant.STATUS_DATE_FORMAT)).format(orderItem
					.getStatusDate());
		}
		for (MenardOrderItemTrackingHistory item : orderItem.getHistory()) {
			if (StringUtils.isNotBlank(item.getComment())) {
				this.comments = item.getComment();
			}
		}		
		if (StringUtils.isBlank(this.comments)) {
			this.comments = orderItem.getNotes();
		}
		if (StringUtils.isBlank(this.comments) 
				&& orderItem.getPosOrderNumber() != null) {
			this.comments = String.valueOf(orderItem.getPosOrderNumber());
		}
		
	}

	/**
	 *Constructor
	 *@param orderItem MenardOrderItem
	 * @param isGoUser boolean
	 * @param sign Sign
	 */
	public MenardOrderItemDTO(MenardOrderItem orderItem, boolean isGoUser, Sign sign) {
		this(orderItem, sign);
		boolean canBackOrder = isGoUser && MenardOrderItemStatus.PENDING_GM.getValue().equals(orderItem.getStatus());
		this.enableBackOrder = enableBackOrder || canBackOrder;
		this.enableBackOrder = enableApprove
				&& enableBackOrder && belongBackOrder(orderItem.getFulfillerTypeCode(), orderItem.getRequestType());				
	}
	
	private boolean belongBackOrder(String FulfillerType, String requestType) {		
		if (MenardFulfillerType.LITERATURE.getKey().equals(FulfillerType)
				|| MenardFulfillerType.PAYROLL.getKey().equals(FulfillerType)) {
			return false;
		}		
		if (MenardOrderRequestType.GSS_Sign_GM.getKey().equals(requestType)
				|| MenardOrderRequestType.GSS_Sign.getKey().equals(requestType)) {
			return false;
		}		
		return true;
	}
	

	/**
	 * Constructor for item history
	 *@param orderItem MenardOrderItem
	 */
	public MenardOrderItemDTO(MenardOrderItemHistory orderItem) {
		MenardOrder order = (MenardOrder) orderItem.getMenardOrder();
		this.storeId = order.getStoreId();
		this.dept = MenardDepartment.getNameByKey(order.getDeptId());
		this.requestor = order.getRequestBy();
		this.orderId = orderItem.getMenardOrder().getId();
		this.orderItemId = orderItem.getId();
		this.statusCode = orderItem.getStatus();		
		String bmSku = orderItem.getBmSku();
		prodcutId = StringUtils.substring(bmSku, 7, StringUtils.length(bmSku));
		description = orderItem.getDescription();
		skucode = orderItem.getMenardSkuStr();
		this.quantity = orderItem.getQuantity();		
		this.status = MenardOrderItemStatus.getDescriptionByValue(orderItem.getStatus());
		if (orderItem.getStatusDate() != null) {
			this.statusDate = (new SimpleDateFormat(CommonConstant.STATUS_DATE_FORMAT)).format(orderItem
					.getStatusDate());
		}
		
		//First try to get decline comment, then get notes and final get pos order number
		for (MenardOrderItemTrackingHistory history : orderItem.getHistory()) {
			if (StringUtils.isNotBlank(history.getComment())) {
				this.comments = history.getComment();
			}
		}		
		if (StringUtils.isBlank(this.comments)) {
			this.comments = orderItem.getNotes();
		}				
		if (StringUtils.isBlank(this.comments) 
				&& orderItem.getPosOrderNumber() != null) {
			this.comments = String.valueOf(orderItem.getPosOrderNumber());
		}
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	/**
	 *
	 * get department
	 * @return String
	 */
	public String getDept() {
		if (StringUtils.isBlank(dept)) {
			return StringUtils.EMPTY;
		}
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	/**
	 *
	 * get requestor
	 * @return String
	 */
	public String getRequestor() {
		if (StringUtils.isBlank(requestor)) {
			return StringUtils.EMPTY;
		}
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Long getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(Long orderItemId) {
		this.orderItemId = orderItemId;
	}

	public String getHist() {
		return hist;
	}

	public void setHist(String hist) {
		this.hist = hist;
	}

	/**
	 *
	 * get sku code
	 * @return String
	 */
	public String getSkucode() {
		if (StringUtils.isBlank(skucode)) {
			return StringUtils.EMPTY;
		}
		return skucode;
	}

	public void setSkucode(String skucode) {
		this.skucode = skucode;
	}

	/**
	 *
	 * get quantity
	 * @return Integer
	 */
	public Integer getQuantity() {
		return quantity == null ? 0 : quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(String statusDate) {
		this.statusDate = statusDate;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getOrderComments() {
		return orderComments;
	}

	public void setOrderComments(String orderComments) {
		this.orderComments = orderComments;
	}

	public String getProdcutId() {
		return prodcutId;
	}

	public void setProdcutId(String prodcutId) {
		this.prodcutId = prodcutId;
	}

	public String getPreStatus() {
		return preStatus;
	}

	public void setPreStatus(String preStatus) {
		this.preStatus = preStatus;
	}

	public Boolean getEnableBackOrder() {
		return enableBackOrder;
	}

	public Date getSubmitDate() {
		return submitDate;
	}

	public void setSubmitDate(Date submitDate) {
		this.submitDate = submitDate;
	}

	public Boolean getEnableApprove() {
		return enableApprove;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

}
