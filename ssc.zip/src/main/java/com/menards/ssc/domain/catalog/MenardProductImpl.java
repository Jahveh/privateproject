package com.menards.ssc.domain.catalog;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;

import org.broadleafcommerce.core.catalog.domain.ProductImpl;

/**
 * <p>MenardProductImpl</p>
 * <p>MenardProductImpl</p>
 * <p>
 * MenardProductImpl
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Entity
@javax.persistence.Table(name = "MENARD_PRODUCT")
public class MenardProductImpl extends ProductImpl implements Serializable, MenardProduct {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "MODEL_NUM")
	private String modelNum;

	@Override
	public String getModelNum() {
		return modelNum;
	}

	@Override
	public void setModelNum(String modelNum) {
		this.modelNum = modelNum;
	}

	@Override
	public boolean isActive() {
		return 'Y' != getArchived();
	}

}
