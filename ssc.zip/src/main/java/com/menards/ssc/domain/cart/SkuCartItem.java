package com.menards.ssc.domain.cart;

import java.io.Serializable;

/**
 * <p>CartItem</p>
 * <p>cart item dto</p>
 * <p>
 * cart item dto
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class SkuCartItem extends CartItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5655843053720832766L;

	private Long skuId;

	private Long productId;

	private Long categoryId;

	private String vendorSize;

	private String vendorName;

	private String status;

	private String skuNum;

	private Integer skuVisibilityCode;

    private boolean isBusinessCard;

    private Integer lineNumber;

	public String getSkuNum() {
		return skuNum;
	}

	public void setSkuNum(String skuNum) {
		this.skuNum = skuNum;
	}

	public Long getSkuId() {
		return skuId;
	}

	public void setSkuId(Long skuId) {
		this.skuId = skuId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getVendorSize() {
		return vendorSize;
	}

	public void setVendorSize(String vendorSize) {
		this.vendorSize = vendorSize;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public Integer getSkuVisibilityCode() {
		return skuVisibilityCode;
	}

	public void setSkuVisibilityCode(Integer skuVisibilityCode) {
		this.skuVisibilityCode = skuVisibilityCode;
	}

    public boolean isBusinessCard() {
        return isBusinessCard;
    }

    public void setBusinessCard(boolean isBussinessCard) {
        this.isBusinessCard = isBussinessCard;
    }

    public Integer getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(Integer lineNumber) {
        this.lineNumber = lineNumber;
    }
}
