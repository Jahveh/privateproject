package com.menards.ssc.domain.order;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.broadleafcommerce.core.order.domain.OrderImpl;

/**
 * 
 * <p>MenardOrderImpl</p>
 * <p>An Extended OrderImpl that extends OrderImpl for entity implementation.</p>
 * <p>
 *  An Extended OrderImpl that extends OrderImpl for entity implementation.
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "MENARD_ORDER")
public class MenardOrderImpl extends OrderImpl implements Serializable, MenardOrder {

	private static final long serialVersionUID = 1L;

	@Column(name = "STORE_ID")
	private String storeId;

	@Column(name = "DUE_DATE")
	private Date dueDate;

	@Column(name = "COMMENT_SAVED")
	private String commentSaved;

	@Column(name = "COMMENT_PLACED")
	private String commentPlaced;

	@Column(name = "ORDER_TYPE")
	private String orderType;

	@Column(name = "GROUPING")
	private String grouping;

	@Column(name = "DEPT_ID")
	private String deptId;

	@Column(name = "RQUEST_BY")
	private String requestBy;

	@Column(name = "ORDER_CODE")
	private String orderCode;

	@Column(name = "LIST_NAME")
	private String listName;

	@Column(name = "CREATED_BY_USER_ID")
	private String createdByUserId;

	@Column(name = "LOAD_FROM_ORDER_ID")
	private Long loadOrderId;

	@Column(name = "IS_GO_ORDER")
	private String generalOfficeOrder;

	@Override
	public String getStoreId() {
		return storeId;
	}

	@Override
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	@Override
	public Date getDueDate() {
		return dueDate;
	}

	@Override
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	@Override
	public String getCommentSaved() {
		return commentSaved;
	}

	@Override
	public void setCommentSaved(String commentSaved) {
		this.commentSaved = commentSaved;
	}

	@Override
	public String getCommentPlaced() {
		return commentPlaced;
	}

	@Override
	public void setCommentPlaced(String commentPlaced) {
		this.commentPlaced = commentPlaced;
	}

	@Override
	public String getOrderType() {
		return orderType;
	}

	@Override
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	@Override
	public String getGrouping() {
		return grouping;
	}

	@Override
	public void setGrouping(String grouping) {
		this.grouping = grouping;
	}

	@Override
	public String getDeptId() {
		return deptId;
	}

	@Override
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	@Override
	public String getRequestBy() {
		return requestBy;
	}

	@Override
	public void setRequestBy(String requestBy) {
		this.requestBy = requestBy;
	}

	@Override
	public String getOrderCode() {
		return orderCode;
	}

	@Override
	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	@Override
	public String getListName() {
		return listName;
	}

	@Override
	public void setListName(String listName) {
		this.listName = listName;
	}

	@Override
	public int getItemCount() {
		return this.getOrderItems().size();
	}

	@Override
	public Long getLoadOrderId() {
		return loadOrderId;
	}

	@Override
	public void setLoadOrderId(Long loadOrderId) {
		this.loadOrderId = loadOrderId;
	}

	public String getCreatedByUserId() {
		return createdByUserId;
	}

	public void setCreatedByUserId(String createdByUserId) {
		this.createdByUserId = createdByUserId;
	}

	public String getGeneralOfficeOrder() {
		return generalOfficeOrder;
	}

	public void setGeneralOfficeOrder(String generalOfficeOrder) {
		this.generalOfficeOrder = generalOfficeOrder;
	}

}