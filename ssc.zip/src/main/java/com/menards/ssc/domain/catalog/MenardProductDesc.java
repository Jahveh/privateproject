package com.menards.ssc.domain.catalog;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

/**
 * 
 * <p>MenardProductDesc</p>
 * <p>Menard Product Descriptions</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author Leo.Yang
 * @version 1.0
 */
@Entity
@javax.persistence.Table(name = "MENARD_DESCRIPTIONS")
public class MenardProductDesc  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 715003045050338784L;

	@EmbeddedId
	private MenardProductDescPK id;

	@Column(name = "SKU_STATUS")
	private String skuStatus;

	@Column(name = "DESCRIPTION1")
	private String description1;

	@Column(name = "DESCRIPTION2")
	private String description2;

	@Column(name = "PRD_DESCRIPTION")
	private String productDesc;

	@Column(name = "SKU_DESCRIPTION")
	private String skuDesc;

	@Column(name = "KEYWORD1")
	private String keywordOne;

	@Column(name = "KEYWORD2")
	private String keywordTwo;

	@Column(name = "PRICE", precision = 19, scale = 5)
	private BigDecimal salePrice = new BigDecimal("0.0");

	@Column(name = "UOM")
	private String uom;

	@Column(name = "SKU_TYPE")
	private String skuType;

	@Column(name = "CREATED_BY")
	private String createdBy;

	/**
	 * 
	 *Constructor
	 */
	public MenardProductDesc() {
		super();
	}

	public String getSkuStatus() {
		return skuStatus;
	}

	public void setSkuStatus(String skuStatus) {
		this.skuStatus = skuStatus;
	}

	public String getSkuDesc() {
		return skuDesc;
	}

	public void setSkuDesc(String skuDesc) {
		this.skuDesc = skuDesc;
	}

	public String getKeywordOne() {
		return keywordOne;
	}

	public void setKeywordOne(String keywordOne) {
		this.keywordOne = keywordOne;
	}

	public String getKeywordTwo() {
		return keywordTwo;
	}

	public void setKeywordTwo(String keywordTwo) {
		this.keywordTwo = keywordTwo;
	}

	public BigDecimal getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(BigDecimal salePrice) {
		this.salePrice = salePrice;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getSkuType() {
		return skuType;
	}

	public void setSkuType(String skuType) {
		this.skuType = skuType;
	}

	/**
	 * 
	 * <p>MenardProductDescPK</p>
	 * <p>MenardProductDescPK</p>
	 * <p>Copyright (c) 2014</p>
	 * <p>Menard Inc.</p>
	 * @author bill01.zhang
	 * @version 1.0
	 */
	@Embeddable
	public static class MenardProductDescPK implements Serializable {

		private static final long serialVersionUID = 12412341341234123L;

		@Column(name = "SKU_CODE")
		private String skuCode;

		@Column(name = "OPENSKU")
		private Long opensku = -2L;

		@Column(name = "SKU_ID")
		private Long skuId = -1L;

		@Column(name = "PRODUCT_ID")
		private Long productId = -1L;

		@Column(name = "CATEGORY_ID")
		private Long categoryId = -1L;

		/**
		 * 
		 *Constructor
		 */
		public MenardProductDescPK() {
			super();
		}

		public Long getOpensku() {
			return opensku;
		}

		public void setOpensku(Long opensku) {
			this.opensku = opensku;
		}

		public String getSkuCode() {
			return skuCode;
		}

		public void setSkuCode(String skuCode) {
			this.skuCode = skuCode;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((categoryId == null) ? 0 : categoryId.hashCode());
			result = prime * result + ((opensku == null) ? 0 : opensku.hashCode());
			result = prime * result + ((productId == null) ? 0 : productId.hashCode());
			result = prime * result + ((skuCode == null) ? 0 : skuCode.hashCode());
			result = prime * result + ((skuId == null) ? 0 : skuId.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			MenardProductDescPK other = (MenardProductDescPK) obj;
			if (categoryId == null) {
				if (other.categoryId != null) {
					return false;
				}
			} else if (!categoryId.equals(other.categoryId)) {
				return false;
			}
			if (opensku == null) {
				if (other.opensku != null) {
					return false;
				}
			} else if (!opensku.equals(other.opensku)) {
				return false;
			}
			if (productId == null) {
				if (other.productId != null) {
					return false;
				}
			} else if (!productId.equals(other.productId)) {
				return false;
			}
			if (skuCode == null) {
				if (other.skuCode != null) {
					return false;
				}
			} else if (!skuCode.equals(other.skuCode)) {
				return false;
			}
			if (skuId == null) {
				if (other.skuId != null) {
					return false;
				}
			} else if (!skuId.equals(other.skuId)) {
				return false;
			}
			return true;
		}

		public Long getSkuId() {
			return skuId;
		}

		public void setSkuId(Long skuId) {
			this.skuId = skuId;
		}

		public Long getProductId() {
			return productId;
		}

		public void setProductId(Long productId) {
			this.productId = productId;
		}

		public Long getCategoryId() {
			return categoryId;
		}

		public void setCategoryId(Long categoryId) {
			this.categoryId = categoryId;
		}

		public boolean isDefaultProductDesc() {
			return -1 == getCategoryId() && -1 == getProductId() && -1 == getSkuId();
		}
	}

	public MenardProductDescPK getId() {
		return id;
	}

	public void setId(MenardProductDescPK id) {
		this.id = id;
	}

	public String getDescription1() {
		return description1;
	}

	public void setDescription1(String description1) {
		this.description1 = description1;
	}

	public String getDescription2() {
		return description2;
	}

	public void setDescription2(String description2) {
		this.description2 = description2;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

}