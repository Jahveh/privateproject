package com.menards.ssc.domain.inventory;

import java.io.Serializable;

/**
 *
 * <p>MenardInventoryDTO</p>  
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.shao
 * @version 1.0
 */
public class MenardInventoryDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2598194511581933699L;
	private String modelNumber;
	private String descriptionShort;
	private String imagePath;
	private String qtyOnHand;
	private String uom;
	private String actualQty;
	private Long productId;

	public String getModelNumber() {
		return modelNumber;
	}

	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	public String getDescriptionShort() {
		return descriptionShort;
	}

	public void setDescriptionShort(String descriptionShort) {
		this.descriptionShort = descriptionShort;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getQtyOnHand() {
		return qtyOnHand;
	}

	public void setQtyOnHand(String qtyOnHand) {
		this.qtyOnHand = qtyOnHand;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getActualQty() {
		return actualQty;
	}

	public void setActualQty(String actualQty) {
		this.actualQty = actualQty;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

}
