package com.menards.ssc.domain.sign;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * <p>Yard</p>
 * <p>Yard table</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Entity
@Table(name = "yards")
public class Yard implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6525787180789278110L;

	@Id
	@Column(name = "yard_no")
	private Integer yardId;

	@Column(name = "yard_abbr")
	private String address;

	@Column(name = "yard_name")
	private String yardName;

	@Column(name = "open_date")
	private Date openDate;

	@Column(name = "header_suppress")
	private Integer headerSuppress;

	@Column(name = "white_signs")
	private Integer whiteSigns;

	public Integer getYardId() {
		return yardId;
	}

	public void setYardId(Integer yardId) {
		this.yardId = yardId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getYardName() {
		return yardName;
	}

	public void setYardName(String yardName) {
		this.yardName = yardName;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public Integer getHeaderSuppress() {
		return headerSuppress;
	}

	public void setHeaderSuppress(Integer headerSuppress) {
		this.headerSuppress = headerSuppress;
	}

	public Integer getWhiteSigns() {
		return whiteSigns;
	}

	public void setWhiteSigns(Integer whiteSigns) {
		this.whiteSigns = whiteSigns;
	}
}
