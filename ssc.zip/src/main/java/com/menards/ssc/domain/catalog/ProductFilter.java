package com.menards.ssc.domain.catalog;

import java.io.Serializable;
import java.util.*;


/**
 * 
 * <p>ProductFilter</p>
 * <p>Filter the product by specifying filte options like vendor,style size </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author James.Ni
 * @version 1.0
 */
public class ProductFilter implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -163445021084561220L;
	private Long categoryId;
	private String attributeName;
	private String attributeValue;
	private String name;
	private List<Option> options;
	private String optionsJoined;

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public String getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Option> getOptions() {
		return options;
	}

	public void setOptions(List<Option> options) {
		this.options = options;
	}

	/**
	 * 
	 * hasOptions
	 * @return boolean boolean
	 */
	public boolean hasOptions() {
		return (getOptionsJoined() != null && getOptionsJoined().length() > 0)
				|| (getOptions() != null && getOptions().size() > 0);
	}

	public String getOptionsJoined() {
		return optionsJoined;
	}

	public void setOptionsJoined(String optionsJoined) {
		this.optionsJoined = optionsJoined;
	}

	/**
	 * 
	 *Constructor 
	 *@param name name
	 */
	public ProductFilter(String name) {
		this.name = name;
		options = new ArrayList<>();
	}

	/**
	 * 
	 *Constructor
	 */
	public ProductFilter() {
		options = new ArrayList<>();
	}

	/**
	 * 
	 * addOption
	 * @param name name
	 * @param value value
	 */
	public void addOption(String name, String value) {
		if (options != null) {
			options.add(new Option(name, value));
		}
	}

    /**
     * getOptionsAsMap
     *
     * @return map map
     */
    public Map<String, String> getOptionsAsMap() {
        if (options == null || options.isEmpty()) {
            return null;
        }
        Map<String, String> map = new LinkedHashMap<>(options.size());
        for (Option option : options) {
            map.put(option.getName(), option.getValue());
        }
        return map;
    }

    /**
     *
     * get all options value as a set
     * @return map map
     */
    public List<String> getOptionsValueAsList() {
        if (options == null || options.isEmpty()) {
            return null;
        }
        List<String> list = new ArrayList<>(options.size());
        for (Option option : options) {
            list.add(option.getValue());
        }
        return list;
    }

	/**
	 * 
	 * <p>Option</p>	
	 */
	public static class Option {
		private String name;
		private String value;

		/**
		 * 
		 *Constructor 
		 *@param name name
		 *@param value value
		 */
		public Option(String name, String value) {
			this.name = name;
			this.value = value;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}

		@Override
		public boolean equals(Object o) {
			if (this == o) {
				return true;
			}
			if (!(o instanceof Option)) {
				return false;
			}

			Option option = (Option) o;

			if (!name.equals(option.name)) {
				return false;
			}
			if (!value.equals(option.value)) {
				return false;
			}

			return true;
		}

		@Override
		public int hashCode() {
			int result = name.hashCode();
			result = 31 * result + value.hashCode();
			return result;
		}
	}
}