package com.menards.ssc.domain.cart;

import java.io.Serializable;

/**
 * <p>SignCartItem</p>
 * <p>sign cart item</p>
 * <p>
 * sign cart item
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class AddSignDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7740946986524710015L;
	private Integer signId;
	private String yardNum;
	private String type;
    private Integer promoNumber;
    private String criteriaType;

	public Integer getSignId() {
		return signId;
	}

	public void setSignId(Integer signId) {
		this.signId = signId;
	}

	public String getYardNum() {
		return yardNum;
	}

	public void setYardNum(String yardNum) {
		this.yardNum = yardNum;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

    public Integer getPromoNumber() {
        return promoNumber;
    }

    public void setPromoNumber(Integer promoNumber) {
        this.promoNumber = promoNumber;
    }

    public String getCriteriaType() {
        return criteriaType;
    }

    public void setCriteriaType(String criteriaType) {
        this.criteriaType = criteriaType;
    }
}
