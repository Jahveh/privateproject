package com.menards.ssc.domain.sign;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * <p>Stock</p> 
 * <p> Stock Table</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
@Entity
@Table(name = "stocks")
public class Stock implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3479227870351939194L;

	@Id
	@Column(name = "stock_id")
	private Integer stockId;

	@Column(name = "desc")
	private String desc;

	@Column(name = "height", precision = 19, scale = 5)
	private BigDecimal height;

	@Column(name = "width", precision = 19, scale = 5)
	private BigDecimal width;

	@Column(name = "req_blank")
	private String reqBlank;

	@Column(name = "req_sheets")
	private Integer reqSheets;

	@Column(name = "store_plan")
	private Integer storePlan;

	@Column(name = "store_printable")
	private Integer storePrintable;

	@Column(name = "store_visible")
	private Integer storeVisible;

	@Column(name = "base_cost_amt", precision = 19, scale = 5)
	private BigDecimal costAmt;

	@Column(name = "laminate_cost_amt", precision = 19, scale = 5)
	private BigDecimal laminateCostAmt;
	
	@OneToMany(mappedBy = "stock", targetEntity = SignVersion.class)
	private List<SignVersion> signVersionList = new ArrayList<SignVersion>();

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public BigDecimal getHeight() {
		return height;
	}

	public void setHeight(BigDecimal height) {
		this.height = height;
	}

	public BigDecimal getWidth() {
		return width;
	}

	public void setWidth(BigDecimal width) {
		this.width = width;
	}

	public String getReqBlank() {
		return reqBlank;
	}

	public void setReqBlank(String reqBlank) {
		this.reqBlank = reqBlank;
	}

	public Integer getReqSheets() {
		return reqSheets;
	}

	public void setReqSheets(Integer reqSheets) {
		this.reqSheets = reqSheets;
	}

	public Integer getStorePlan() {
		return storePlan;
	}

	public void setStorePlan(Integer storePlan) {
		this.storePlan = storePlan;
	}

	public Integer getStorePrintable() {
		return storePrintable;
	}

	public void setStorePrintable(Integer storePrintable) {
		this.storePrintable = storePrintable;
	}

	public Integer getStoreVisible() {
		return storeVisible;
	}

	public void setStoreVisible(Integer storeVisible) {
		this.storeVisible = storeVisible;
	}

	public BigDecimal getCostAmt() {
		return costAmt;
	}

	public void setCostAmt(BigDecimal costAmt) {
		this.costAmt = costAmt;
	}

	public BigDecimal getLaminateCostAmt() {
		return laminateCostAmt;
	}

	public void setLaminateCostAmt(BigDecimal laminateCostAmt) {
		this.laminateCostAmt = laminateCostAmt;
	}

	public Integer getStockId() {
		return stockId;
	}

	public void setStockId(Integer stockId) {
		this.stockId = stockId;
	}

	public List<SignVersion> getSignVersionList() {
		return signVersionList;
	}

	public void setSignVersionList(List<SignVersion> signVersionList) {
		this.signVersionList = signVersionList;
	}
}
