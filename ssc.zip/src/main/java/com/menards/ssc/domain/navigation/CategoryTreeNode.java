package com.menards.ssc.domain.navigation;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;

import com.menards.ssc.enums.CategoryType;

/**
*
* <p>QuickCart</p>
* <p>Model object of the category tree node.</p>
* <p>Copyright (c) 2013</p>
* <p>Menard Inc.</p>
* @author frank.peng
* @version 1.0
*/
public class CategoryTreeNode implements Serializable {
	private static final long serialVersionUID = 4036297881412880598L;
	private String categoryName;
	private Long categoryId;
	private List<CategoryTreeNode> subCategories = new ArrayList<CategoryTreeNode>();
	private CategoryTreeNode parentCategory;
	private Long parentCategoryId;
	private String url;
	private boolean isLeafNode;
	private String categoryDesc;
	private String categoryImgUrl;
	private boolean isAccessible;
	private CategoryType categoryType;
    private Long priority;

	public String getCategoryName() {
		return categoryName;
	}	
	
	public String getCategoryDescHtml() {
		if (categoryId < 0) {
			return StringEscapeUtils.escapeHtml(categoryDesc);
		} else {
			return categoryDesc;
		}
		
	}
	
	public String getCategoryNameHtml() {
		return StringEscapeUtils.escapeHtml(categoryName);
	}	

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<CategoryTreeNode> getSubCategories() {
		return subCategories;
	}

	public void setSubCategories(List<CategoryTreeNode> subCategories) {
		this.subCategories = subCategories;
	}

	public CategoryTreeNode getParentCategory() {
		return parentCategory;
	}

	public void setParentCategory(CategoryTreeNode parentCategory) {
		this.parentCategory = parentCategory;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public Long getParentCategoryId() {
		return parentCategoryId;
	}

	public void setParentCategoryId(Long parentCategoryId) {
		this.parentCategoryId = parentCategoryId;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public boolean isLeafNode() {
		return isLeafNode;
	}

	public void setLeafNode(boolean isLeafNode) {
		this.isLeafNode = isLeafNode;
	}

	public String getCategoryDesc() {
		return categoryDesc;
	}

	public void setCategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}

	public String getCategoryImgUrl() {
		return categoryImgUrl;
	}

	public void setCategoryImgUrl(String categoryImgUrl) {
		this.categoryImgUrl = categoryImgUrl;
	}

	public boolean isAccessible() {
		return isAccessible;
	}

	public void setAccessible(boolean isAccessible) {
		this.isAccessible = isAccessible;
	}

	public CategoryType getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(CategoryType categoryType) {
		this.categoryType = categoryType;
	}

    public Long getPriority() {
        return priority;
    }

    public void setPriority(Long priority) {
        this.priority = priority;
    }
}
