package com.menards.ssc.domain.setremodel;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotNull;

/**
 * <p>SetRemodelDTO</p>
 * <p>set remodel date dto</p>
 * <p>
 * set remodel date dto
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class SetRemodelDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8208113591073785017L;

	@NotNull
	private String storeId;

	private Date startDate;

	private Date endDate;

	private String startDateDisplay;
	private String endDateDisplay;

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getStartDateDisplay() {
		return startDateDisplay;
	}

	public void setStartDateDisplay(String startDateDisplay) {
		this.startDateDisplay = startDateDisplay;
	}

	public String getEndDateDisplay() {
		return endDateDisplay;
	}

	public void setEndDateDisplay(String endDateDisplay) {
		this.endDateDisplay = endDateDisplay;
	}

}
