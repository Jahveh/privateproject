package com.menards.ssc.domain.breadcrumb;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * <p>BreadCrumbConfig</p>
 * <p>Entity class for bread crumb.</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "BREAD_CRUMB_CONFIG")
public class BreadCrumbConfig implements Serializable, Comparable<BreadCrumbConfig> {

	private static final long serialVersionUID = 6420760634465613988L;

	@XmlElement
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@XmlElement
	@Column(name = "PAGE_URL")
	private String pageUrl;

	@XmlElement
	@Column(name = "CRUMB_NAME")
	private String crumbName;

	@XmlElement
	@Column(name = "CRUMB_LINK")
	private String crumbLink;

	@XmlElement
	@Column(name = "CRUMB_ORDER")
	private int crumbOrder;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPageUrl() {
		return pageUrl;
	}

	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}

	public String getCrumbName() {
		return crumbName;
	}

	public void setCrumbName(String crumbName) {
		this.crumbName = crumbName;
	}

	public String getCrumbLink() {
		return crumbLink;
	}

	public void setCrumbLink(String crumbLink) {
		this.crumbLink = crumbLink;
	}

	public int getCrumbOrder() {
		return crumbOrder;
	}

	public void setCrumbOrder(int crumbOrder) {
		this.crumbOrder = crumbOrder;
	}

	@Override
	public int compareTo(BreadCrumbConfig object) {
		if (this.crumbOrder > object.crumbOrder) {
			return 1;
		}
		if (this.crumbOrder < object.crumbOrder) {
			return -1;
		}
		return 0;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof BreadCrumbConfig)) {
			return false;
		}
		BreadCrumbConfig config = (BreadCrumbConfig) object;
		return this.id.equals(config.id) && this.pageUrl.equals(config.pageUrl)
				&& this.crumbName.equals(config.crumbName) && this.crumbLink.equals(config.crumbLink)
				&& this.crumbOrder == config.crumbOrder;
	}

	@Override
	public int hashCode() {
		return this.id.hashCode() + this.pageUrl.hashCode() + this.crumbLink.hashCode() + this.crumbName.hashCode()
				+ this.crumbOrder;

	}
}
