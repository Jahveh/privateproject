package com.menards.ssc.domain.cart;

import java.io.Serializable;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 *
 * <p>QuickCart</p>
 * <p>Command object of the quick cart page.</p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class QuickCart implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6202788451733601143L;

	@NotNull
	private Long sku;

	@NotNull
	@Min(1)
	@Max(9999)
	private Integer quantity;

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Long getSku() {
		return sku;
	}

	public void setSku(Long sku) {
		this.sku = sku;
	}

}
