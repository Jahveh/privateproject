package com.menards.ssc.domain.catalog;

import com.menards.ssc.domain.order.MenardOrder;
import com.menards.ssc.domain.order.MenardOrderItem;
import com.menards.ssc.enums.MenardOrderItemStatus;
import com.menards.ssc.enums.ProductVisibility;
import com.menards.ssc.enums.SkuVisibility;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;
import com.menards.ssc.state.MenardGetStatus;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>ProductDTO</p>
 * <p>convert attributes from product</p>
 * <p>
 *  convert attributes from product
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class ProductDetailDTO extends MenardProductDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1629028246193772978L;
	private MenardUserDetails user;
	private List<ProductDetailDTO> optionAccessories;
	private List<ProductDetailDTO> requireAccessories;
	private List<MenardSkuDTO> skuDTOs;
	private MenardSkuDTO selectedSkuDTO;
	private List<MenardOrderItem> last5OrderItems;
	private Boolean setDefaultSku;
	private String vendorLogoUrl;
	public static final String STATUS_DATE_FORMAT = "MM-dd-yyyy";

	/**
	 *Constructor
	 *@param product product
	 */
	public ProductDetailDTO(MenardProduct product) {
		super(product, null);
		this.user = MenardSecurityContextHolder.getMenardUserDetails();
	}

	@Override
	public MenardSku getSelectedSku() {
		if (getSelectedSkuDTO() != null) {
			return getSelectedSkuDTO().getSku();
		}
		return null;
	}

	/**
	 * get option accessories product detail dto
	 * @return List<ProductDetailDTO>
	 */
	public List<ProductDetailDTO> getOptionAccessories() {
		List<ProductDetailDTO> options = new ArrayList<ProductDetailDTO>();
		for (ProductDetailDTO dto : optionAccessories) {
			if (dto.getProductAvailable()) {
				options.add(dto);
			}
		}
		return options;
	}

	public void setOptionAccessories(List<ProductDetailDTO> optionAccessories) {
		this.optionAccessories = optionAccessories;
	}

	/**
	 * get require accessories product detail dto
	 * @return List<ProductDetailDTO>
	 */
	public List<ProductDetailDTO> getRequireAccessories() {
		List<ProductDetailDTO> requires = new ArrayList<ProductDetailDTO>();
		for (ProductDetailDTO dto : requireAccessories) {
			if (dto.getProductAvailable()) {
				requires.add(dto);
			}
		}
		return requires;
	}

	public void setRequireAccessories(List<ProductDetailDTO> requireAccessories) {
		this.requireAccessories = requireAccessories;
	}

	public List<MenardSkuDTO> getSkuDTOs() {
		return skuDTOs;
	}

	public void setSkuDTOs(List<MenardSkuDTO> skuDTOs) {
		this.skuDTOs = skuDTOs;
	}

	public void setSelectedSkuDTO(MenardSkuDTO selectedSkuDTO) {
		this.selectedSkuDTO = selectedSkuDTO;
	}

	public ProductVisibility getProductVisibility() {
		return MenardGetStatus.getProductVisibility(skuDTOs);
	}

	public List<MenardOrderItem> getLast5OrderItems() {
		return last5OrderItems;
	}

	public void setLast5OrderItems(List<MenardOrderItem> last5OrderItems) {
		this.last5OrderItems = last5OrderItems;
	}

	public Boolean getSetDefaultSku() {
		return setDefaultSku;
	}

	public void setSetDefaultSku(Boolean setDefaultSku) {
		this.setDefaultSku = setDefaultSku;
	}

	/**
	 * check is product available
	 * @return boolean boolean
	 */
	public boolean getProductAvailable() {
		// (!user.isYard() && CommonConstant.SOS_CATALOG.equalsIgnoreCase(user.getSelectedDepartment()))
		if (getIsGOUser()) {
			return true;
		}
		ProductVisibility productVisibility = MenardGetStatus.getProductVisibility(skuDTOs);
		if (productVisibility == null || ProductVisibility.DELETED.equals(productVisibility)) {
			return false;
		}
		return true;
	}

	/**
	 * set Selected Sku DTO
	 * @return MenardSkuDTO MenardSkuDTO
	 */
	public MenardSkuDTO getSelectedSkuDTO() {
		if (selectedSkuDTO != null) {
			return selectedSkuDTO;
		}
		if (setDefaultSku) {
			if (CollectionUtils.isEmpty(skuDTOs)) {
				return null;
			}
			int count = 0;
			MenardSkuDTO selectedSkuDto = null;
			for (MenardSkuDTO dto : skuDTOs) {
				if (dto.isVisibility() || getIsGOUser()) {
					selectedSkuDto = dto;
					count++;
				}
			}

			if (count == 1) {
				return selectedSkuDto;
			}
		}
		return null;
	}

	/**
	 * does product has sub workflow
	 * @return boolean has sub workflow
	 */
	public boolean getSelectedSkuAvailable() {
		if (getSelectedSku() != null && getIsGOUser()) {
			return true;
		}
		if (getSelectedSku() != null && getSelectedSkuDTO().isVisibility()) {
			if (!(SkuVisibility.STOCK_NOT_ORDERABLE.equals(getSelectedSkuDTO().getSkuVisibility()) && !getAttrAsBoolean(DCM))) {
				return true;
			}
		}
		return false;
	}

	/**
	 * get boolean of category
	 * @return boolean booelan
	 */
	public boolean getHasUseColorDropdown() {
		return this.getCategoryAttrAsBoolean(USE_COLOR_DROPDOWN);
	}

	/**
	 * ATR_Use_Color_Dropdown
	 * @return Map<Long, String>
	 */
	public Map<Long, String> getUserColorDropdownSkus() {
		Map<Long, String> skus = new HashMap<Long, String>();
		String dash;
		String color;
		String vendor = this.getAttrAsString(VENDOR);
		String colorAttr = "Pri_Col_Fin_" + vendor;
		for (MenardSkuDTO skuDTO : skuDTOs) {
			if (!skuDTO.isVisibility() && getIsYard()) {
				continue;
			}
			// dash = "-";
			dash = "";
			color = skuDTO.getSkuAttrAsString(colorAttr);
			if (StringUtils.isEmpty(color)) {
				dash = StringUtils.EMPTY;
				color = this.getAttrAsString(DESCRIPTION_SHORT);
				if (StringUtils.isEmpty(color)) {
					color = "";
				}
			}
			String salePrice = "";
			SkuVisibility skuVisibility = MenardGetStatus.getSkuVisibility(skuDTO);
			if (SkuVisibility.STOCK_ORDERABLE.equals(skuVisibility)) { // 1
				salePrice = "(ST/SO)";
			} else if (SkuVisibility.STOCK_NOT_ORDERABLE.equals(skuVisibility)) { // 0
				salePrice = "(ST)";
			} else {
				salePrice = "(SO)";
			}

			skus.put(skuDTO.getSku().getId(), new StringBuffer(color).append(dash).append(salePrice).toString());
		}
		return skus;
	}

	/**
	 * MenardsUCConstants.SKU_VISIBILITY_STOCK_ORDERABLE
	 * @return boolean  SKU_VISIBILITY_STOCK_ORDERABLE
	 */
	public boolean getSkuVisiblityStockOrderable() {
		if (getSelectedSku() != null) {
			if (SkuVisibility.STOCK_ORDERABLE.equals(getSelectedSkuDTO().getSkuVisibility())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * SkuVisibility.STOCK_NOT_ORDERABLE
	 * @return boolean
	 */
	public boolean getSkuVisiblityStockNotOrderable() {
		if (getSelectedSku() != null) {
			if (SkuVisibility.STOCK_NOT_ORDERABLE.equals(getSelectedSkuDTO().getSkuVisibility())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * check is welcome sign
	 * @return boolean booleanboolean
	 */
	public boolean getIsWelcomeSign() {
		return "Y".equalsIgnoreCase(getAttrAsString(IS_WELCOME_SIGN));
	}

	/**
	 * check is business card
	 * @return boolean boolean
	 */
	public boolean getIsBusinessCard() {
		return "Y".equalsIgnoreCase(getAttrAsString(IS_BUSINESS_CARD));
	}

	/**
	 * check is dcm sku
	 * @return boolean boolean
	 */
	public boolean getIsDcmSku() {
		return getAttrAsBoolean(DCM);
	}

	/**
	 * Flag used to display or hide update quantity on hand button on item detail page.
	 * If user can get to product details page, that means the product is in STOCK status.
	 * All the DISCONTINUED, DELETED products are not displayed on product list page.
	 * Unless you know the exact product ID and access it by URL
	 *
	 * @return
	 */
	public boolean getShowUpdateQuantityOnHandButton() {
		return getIsDcmSku();
	}

	/**
	 * check is show add to cart button
	 * @return boolean boolean
	 */
	public boolean getIsShowAdd2CartBtn() {
		boolean isSpecialItem = getIsWelcomeSign() || getIsBusinessCard() || getIsDcmSku();
		if (!isSpecialItem) {
			return getIsGOUser() || getSelectedSkuAvailable();
		}
		return false;
	}

	/**
	 * show or hide not orderable message
	 * @return
	 */
	public boolean getDisplayNotOrderableMsg() {
		return !getIsGOUser() && !getIsShowAdd2CartBtn();
	}

	/**
	 * last 5 orders
	 * @return List<String> order string
	 * submit date + by requestor + status
	 */
	public List<String> getLast5Orders() {
		List<String> historys = new ArrayList<String>();
		// if (CommonConstant.SOS_CATALOG.equals(user.getSelectedDepartment()) && getSelectedSku() != null) {
		if (getSelectedSku() != null) {
			for (MenardOrderItem item : last5OrderItems) {
				StringBuffer sb = new StringBuffer();
				sb.append(
						new SimpleDateFormat(STATUS_DATE_FORMAT)
								.format(item.getOrder().getAuditable().getDateCreated())).append(" by ")
						.append(((MenardOrder) item.getOrder()).getRequestBy()).append(" ")
						.append(MenardOrderItemStatus.getDescriptionByValue(item.getStatus())).append("\n");
				historys.add(sb.toString());
			}
		}
		return historys;
	}

	/**
	 * only additional tab
	 * @return boolean boolean
	 */
	public boolean getIsAdditionalTabActive() {
		if (CollectionUtils.isEmpty(getOptionAccessories()) && CollectionUtils.isEmpty(getRequireAccessories())) {
			return true;
		}
		return false;
	}

	/**
	 * options accessories is not empty & require accessories is empty
	 * @return boolean boolean
	 */
	public boolean getIsOptionAccessoriesTabActive() {
		if (CollectionUtils.isNotEmpty(getOptionAccessories()) && CollectionUtils.isEmpty(getRequireAccessories())) {
			return true;
		}
		return false;
	}

	/**
	 * require accessories is not empty
	 * @return boolean boolean
	 */
	public boolean getIsRequireAccessoriesTabActive() {
		if (CollectionUtils.isNotEmpty(getRequireAccessories())) {
			return true;
		}
		return false;
	}

	/**
	 * get product image url
	 * @return img url
	 */
	public List<ImageryDTO> getProductImgList() {
		List<ImageryDTO> lst = new ArrayList<ImageryDTO>();
		String productMainImg = getProductImgUrl();
		if (StringUtils.isNotEmpty(productMainImg)) {
			ImageryDTO img = new ImageryDTO();
			img.setThumb(productMainImg);
			img.setSmall(productMainImg);
			img.setBig(productMainImg);
			lst.add(img);
		}

		String key = IMAGE_ALTERNATE;
		for (int i = 0; i < 6; i++) {
			if (i > 0) {
				key = IMAGE_ALTERNATE + "_" + i;
			}
			ImageryDTO d = this.getImageryDTO(key);
			if (d != null) {
				lst.add(d);
			}
		}

		return lst;

	}

	/**
	 * get product image url
	 * @param key key
	 * @return img url
	 */
	private ImageryDTO getImageryDTO(String key) {
		String imgAttr = this.getAttrAsString(key);
		ImageryDTO d = null;
		if (StringUtils.isNotEmpty(imgAttr)) {
			d = new ImageryDTO();
			d.setThumb(imgAttr);
			d.setSmall(imgAttr);
			d.setBig(imgAttr);
		}
		return d;
	}

	/**
	 * adapt go user
	 * @return boolean boolean
	 */
	public boolean getIsGOUser() {
		return user.isGOUser();
	}

	/**
	 * adapt is yard
	 * @return boolean
	 */
	public boolean getIsYard() {
		return user.isYard();
	}

	public void setVendorLogoUrl(String vendorLogoUrl) {
		this.vendorLogoUrl = vendorLogoUrl;
	}

	/**
	 * vendor logo img url
	 * @return img url
	 */
	public String getVendorLogoUrl() {
		if (StringUtils.isEmpty(vendorLogoUrl)) {
			return null;
		}
		return vendorLogoUrl;
	}

}
