/*
 * UpdateQuantityDTO
 * 
 * 2014-04-18
 *
 * Copyright (c) 2014
 * Menard Inc.
 */
package com.menards.ssc.domain.cart;

import java.io.Serializable;

/**
 * This class acts as a form bean on update quantity on hand page.
 * Notice the type of quantity is String as the legacy system allows
 * user input of decimal.
 */
public class UpdateQuantityDTO implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -3761990063244269464L;
	private String skuId;
    private String productId;
    private String quantity;

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
}