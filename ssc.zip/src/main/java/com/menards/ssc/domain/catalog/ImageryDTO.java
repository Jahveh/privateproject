package com.menards.ssc.domain.catalog;

import java.io.Serializable;

/**
 * <p>ImageryDTO</p>
 * <p>imagery dto</p>
 * <p>
 * imagery dto
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class ImageryDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7658709444803281936L;
	private String thumb;
	private String small;
	private String big;

	public String getThumb() {
		return thumb;
	}

	public void setThumb(String thumb) {
		this.thumb = thumb;
	}

	public String getSmall() {
		return small;
	}

	public void setSmall(String small) {
		this.small = small;
	}

	public String getBig() {
		return big;
	}

	public void setBig(String big) {
		this.big = big;
	}
}