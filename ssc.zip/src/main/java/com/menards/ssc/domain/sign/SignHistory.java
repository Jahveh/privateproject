package com.menards.ssc.domain.sign;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * <p>SignHistory</p>
 * <p>sign history for sign db</p>
 * <p>
 * sign history for sign db
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
@Entity
public class SignHistory implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5747224534745067379L;
	@Id
	private String logId;
	private String logType;
	private String processGroup;
	private String signName;
	private String description;
	private String stock;
	private String height;
	private String width;
	private String stockDescription;
	private String yard;
	private String processCode;
	private String message;
	private String processDate;
	private static SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
	
	public SignHistory() {
		super();
	}
	
	public SignHistory(int logId, String logType, int processGroup,
			String signName, String description, int stock, BigDecimal height,
			BigDecimal width, String stockDescription, int yard,
			int processCode, String message, Date processDate) {
		super();		
		this.logId = String.valueOf(logId);
		this.logType = logType;
		this.processGroup = String.valueOf(processGroup);
		this.signName = signName;
		this.description = description;
		this.stock = String.valueOf(stock);		
		this.height = String.valueOf(height);
		this.width = String.valueOf(width);
		this.stockDescription = stockDescription;
		this.yard = String.valueOf(yard);
		this.processCode = String.valueOf(processCode);
		this.message = message;
		this.processDate = format.format(processDate);	
	}

	public String getLogId() {
		return logId;
	}

	public void setLogId(String logId) {
		this.logId = logId;
	}

	public String getLogType() {
		return logType;
	}

	public void setLogType(String logType) {
		this.logType = logType;
	}

	public String getProcessGroup() {
		return processGroup;
	}

	public void setProcessGroup(String processGroup) {
		this.processGroup = processGroup;
	}

	public String getSignName() {
		return signName;
	}

	public void setSignName(String signName) {
		this.signName = signName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public String getStockDescription() {
		return stockDescription;
	}

	public void setStockDescription(String stockDescription) {
		this.stockDescription = stockDescription;
	}

	public String getYard() {
		return yard;
	}

	public void setYard(String yard) {
		this.yard = yard;
	}

	public String getProcessCode() {
		return processCode;
	}

	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getProcessDate() {
		return processDate;
	}

	public void setProcessDate(String processDate) {
		this.processDate = processDate;
	}

}
