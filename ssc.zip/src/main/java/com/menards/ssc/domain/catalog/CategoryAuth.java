/**
 * 
 */
package com.menards.ssc.domain.catalog;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.menards.ssc.constants.CommonConstant;

/**
 * <p>CategoryAuth</p>
 * <p>Group all the authorization informaiton for specific category </p>
 * <p>
 * Including department information, fullfiller type and so on.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class CategoryAuth {
	private String fulfiller;
	private String depts;
	private String url;
	private Long categoryId;
	private Long parentId;
	private CategoryAuth parent;
	private Set<String> set = new HashSet<String>();
	
	/**
	 *Constructor 
	 */
	public CategoryAuth() {
	}
	
	/**
	 *Constructor 
	 *@param fulfiller String
	 *@param depts String
	 *@param url String
	 */
	public CategoryAuth(String fulfiller, String depts, String url) {
		this.fulfiller = fulfiller;
		this.depts = depts;
		this.url = url;
	}
	
	/**
	 *Constructor 
	 *@param fulfiller String
	 *@param depts String
	 *@param url String
	 *@param categoryId Long
	 *@param parentId Long
	 */
	public CategoryAuth(String fulfiller, String depts, String url, Long categoryId, Long parentId) {
		super();
		this.fulfiller = fulfiller;
		this.depts = depts;
		this.url = url;
		this.categoryId = categoryId;
		this.parentId = parentId;
	}

	/**
	 * Retrieve all the authorization token which could be a department id or 
	 * fullfiller type.
	 * @return Set<String>
	 */
	public Set<String> getAuthoriseSet() {
		if (StringUtils.isNotEmpty(fulfiller)) {
			String[] array = StringUtils.split(fulfiller, CommonConstant.COMMA);
			for (String fulfiller : array) {
				set.add(CommonConstant.ROLE_PREFIX + fulfiller);
			}
		}
		if (StringUtils.isNotEmpty(depts)) {
			int length = depts.length();
			for (int i = 0; i < length;) {
				set.add(CommonConstant.ROLE_PREFIX + StringUtils.substring(depts, i, i + 3));
				i = i + 3;
			}
		}
		if (parent != null) {
			set.addAll(parent.getAuthoriseSet());
		}
		return set;
	}

	public CategoryAuth getParent() {
		return parent;
	}

	public void setParent(CategoryAuth parent) {
		this.parent = parent;
	}

	public String getFulfiller() {
		return fulfiller;
	}

	public void setFulfiller(String fulfiller) {
		this.fulfiller = fulfiller;
	}

	public String getDepts() {
		return depts;
	}

	public void setDepts(String depts) {
		this.depts = depts;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public Long getCategoryId() {
		return categoryId;
	}


	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}


	public Long getParentId() {
		return parentId;
	}


	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
}
