package com.menards.ssc.domain.catalog;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;
import org.broadleafcommerce.core.catalog.domain.SkuAttribute;

import com.menards.ssc.constants.ProductAttributeKey;
import com.menards.ssc.constants.SkuAttributeKey;
import com.menards.ssc.enums.SkuVisibility;
import com.menards.ssc.util.MenardUtil;

/**
 * <p>MenardSkuDTO</p>
 * <p>menard sku dto</p>
 * <p>
 * menard sku dto
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class MenardSkuDTO implements SkuAttributeKey, Serializable {

	private static final long serialVersionUID = 4380497104214576200L;

	private static final String DEFAULT_LEAD_TIME = "14";

	private MenardSku sku;

	/* private MenardSkuStatus skuStatus; */

	private String skuStatusCode;

	private SkuVisibility skuVisibility;

	/**
	 *Constructor 
	 *@param sku sku
	 */
	public MenardSkuDTO(MenardSku sku) {
		this.sku = sku;
	}

	public MenardSku getSku() {
		return sku;
	}

	public void setSku(MenardSku sku) {
		this.sku = sku;
	}

	/*
	 * public MenardSkuStatus getSkuStatus() { return skuStatus; }
	 * 
	 * public void setSkuStatus(MenardSkuStatus skuStatus) { this.skuStatus = skuStatus; }
	 */

	public SkuVisibility getSkuVisibility() {
		return skuVisibility;
	}

	public void setSkuVisibility(SkuVisibility skuVisibility) {
		this.skuVisibility = skuVisibility;
	}

	public String getSkuStatusCode() {
		return skuStatusCode;
	}

	public void setSkuStatusCode(String skuStatusCode) {
		this.skuStatusCode = skuStatusCode;
	}

	/**
	 * check if sku is visibility
	 * @return boolean boolean
	 */
	public boolean isVisibility() {
		if (skuVisibility == null || SkuVisibility.DELETED.equals(skuVisibility)) {
			return false;
		}
		return true;
	}

	/**
	 * get min quantity
	 * @return quantity integer
	 */
	public Integer getMinQty() {
		if (getSku() != null) {
			Integer minQty = this.getSkuAttrAsInteger(MIN_QTY);
			if (minQty != null) {
				return minQty;
			}
		}
		return 0;
	}

	/**
	 * get min quantity
	 * @return quantity integer
	 */
	public Integer getMaxQty() {
		if (getSku() != null) {
			return this.getSkuAttrAsInteger(MAX_QTY);
		}
		return null;
	}

	/**
	 * get min quantity
	 * @return quantity integer
	 */
	public Integer getIncrementQty() {
		if (getSku() != null) {
			Integer incrementQty = this.getSkuAttrAsInteger(INCREMENT_QTY);
			if (incrementQty != null) {
				return incrementQty;
			}
		}
		return 1;
	}

	/**
	 * get default quantity
	 * @return quantity quantity
	 */
	public int getQuantity() {
		return this.getMinQty();
	}

	/**
	 *
	 * get sku attribute by uppercase key
	 * @param key key
	 * @return string attribute string value
	 */
	public String getSkuAttrAsString(String key) {
		if (getSku() != null) {
			String mappingKey = MenardUtil.getMappingKey(key);
			SkuAttribute sa = getSku().getSkuAttributes().get(mappingKey);
			if (sa != null) {
				return sa.getValue();
			}
		}
		return null;
	}

	/**
	 *
	 * get sku attribute by uppercase key
	 * @param key key
	 * @return integer value
	 */
	public Integer getSkuAttrAsInteger(String key) {
		String value = this.getSkuAttrAsString(key);
		try {
			return Integer.valueOf(value);
		} catch (Exception e) {
			e.getMessage();
		}
		return null;
	}

	/**
	 * get sku number
	 * @return string sku num
	 */
	public String getSkuNum() {
		if (getSku() != null) {
			String skuNum = this.getSku().getMenardSku();
			if (StringUtils.isEmpty(skuNum)) {
				skuNum = getSku().getSkuCode();
			}
			if (StringUtils.isNotEmpty(skuNum) && skuNum.length() >= 7) {
				skuNum = skuNum.substring(0, 3) + "-" + skuNum.substring(3, 7);
			}
			return skuNum;
		}
		return null;
	}

	/**
	 * 
	 * getMenardSku
	 * @return String String
	 */
	public String getMenardSku() {
		if (getSku() != null) {
			return this.getSku().getMenardSku();
		}
		return null;
	}

	/**
	 * lead time message
	 * @return string message
	 */
	public String getLeadTimeMsg() {
		String defaultLeadTime = DEFAULT_LEAD_TIME;
		if (getSku() != null) {
			String leadTime = this.getSkuAttrAsString(LEAD_TIME_DAYS);
			BaseProductDTO baseDto = new BaseProductDTO((MenardProduct) this.getSku().getProduct());
			String dcm = baseDto.getAttrAsString(ProductAttributeKey.DCM);
			boolean isDcm = MenardUtil.getBooleanValue(dcm);
            // suppress stock item message as update quantity button is displayed whenever item is DCM item
            // and if update quantity button is displayed, this message should not be displayed
//			if (SkuVisibility.STOCK_NOT_ORDERABLE.equals(this.getSkuVisibility())) {
//				return "Stock item at this store.";
//			} else
            if (!isDcm) {
				if (StringUtils.isEmpty(leadTime) || "0".equals(leadTime)) {
					leadTime = defaultLeadTime;
				}
				return "Available for shipment in approximately " + leadTime + " days.";
			}
		}
		return null;
	}

	/**
	 * get price
	 * @return string price
	 */
	public String getPrice() {
		if (getSku() != null) {
			String price = this.getSkuAttrAsString(SkuAttributeKey.PRICE);
			if (StringUtils.isNotEmpty(price)) {
				return "Price: $" + price;
			}
		}
		return null;
	}

	/**
	 * sku color , the product only has single one default sku show sku color
	 * @return color
	 */
	public String getColor() {
		if (getSku() == null) {
			String color = this.getSkuAttrAsString(COLOR);
			if (StringUtils.isNotEmpty(color)) {
				return color;
			} else {
				return "N/A";
			}
		}
		return null;
	}

	/**
	 * get sku image url
	 * @return img url
	 */
	public String getSkuImgUrl() {
		String imgUrl = null;
		if (getSku() != null) {
			imgUrl = this.getSkuAttrAsString(COLOR_IMAGE);
			if (StringUtils.isEmpty(imgUrl)) {
				imgUrl = this.getSkuAttrAsString(SkuAttributeKey.IMAGE_MEDIUM);
			}
			if (StringUtils.isEmpty(imgUrl)) {
				imgUrl = this.getSkuAttrAsString(SWATCH);
			}
		}
		return imgUrl;

	}

}
