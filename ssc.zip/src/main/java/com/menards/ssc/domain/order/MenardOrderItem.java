package com.menards.ssc.domain.order;

import java.util.Date;
import java.util.List;

import org.broadleafcommerce.core.order.domain.DiscreteOrderItem;

import com.menards.ssc.domain.catalog.MenardProduct;
import com.menards.ssc.domain.catalog.MenardSku;

/**
 * An Extended Order Domain interface that provides methods for entity extension.
 * @author Frank Shao
 */
public interface MenardOrderItem extends DiscreteOrderItem {

	/**
	 *
	 * @return String
	 */
	public String getNotes();

	/**
	 *
	 * @param notes String
	 */
	public void setNotes(String notes);

	/**
	 *
	 * @return Integer
	 */
	public Integer getLineNumber();

	/**
	 *
	 * @param lineNumber Integer
	 */
	public void setLineNumber(Integer lineNumber);

	/**
	 *
	 * @return String
	 */
	public String getStatus();

	/**
	 *
	 * @param status String
	 */
	public void setStatus(String status);

	/**
	 *
	 * @return Date
	 */
	public Date getStatusDate();

	/**
	 *
	 * @param statusDate Date
	 */
	public void setStatusDate(Date statusDate);

	/**
	 *
	 * @return String
	 */
	public String getRequestType();

	/**
	 *
	 * @param requestType String
	 */
	public void setRequestType(String requestType);

	/**
	 *
	 * @return MenardOrder
	 */
	public MenardOrder getMenardOrder();

	/**
	 *
	 * @param menardOrder MenardOrder
	 */
	public void setMenardOrder(MenardOrder menardOrder);

	/**
	 *
	 * @return List<MenardOrderItemTrackingHistory>
	 */
	public List<MenardOrderItemTrackingHistory> getHistory();

	/**
	 *
	 * @param history List<MenardOrderItemTrackingHistory>
	 */
	public void setHistory(List<MenardOrderItemTrackingHistory> history);

	/**
	 *
	 * @return String
	 */
	public String getDcItem();

	/**
	 *
	 * @param dcItem  String
	 */
	public void setDcItem(String dcItem);

	/**
	 *
	 * @return String
	 */
	public String getStoreRemodel();

	/**
	 *
	 * @param storeRemodel String
	 */
	public void setStoreRemodel(String storeRemodel);

	/**
	 *
	 * @return String
	 */
	public String getFulfillerTypeCode();

	/**
	 *
	 * @param fulfillerTypeCode String
	 */
	public void setFulfillerTypeCode(String fulfillerTypeCode);

	/**
	 *
	 * @return String
	 */
	public String getStorePrint();

	/**
	 *
	 * @param storePrint String
	 */
	public void setStorePrint(String storePrint);

	/**
	 *
	 * @return Boolean
	 */
	public Boolean isDcItem();

	/**
	 *
	 * @return Boolean
	 */
	public Boolean isStoreRemodel();

	/**
	 *
	 * @return Boolean
	 */
	public Boolean isStorePrint();

	/**
	 * sign Id
	 * @return Integer
	 */
	public Integer getSignId();

	/**
	 * sign Id Integer
	 * @param signId Integer
	 */
	public void setSignId(Integer signId);

	/**
	 * sign yard number
	 * @return String
	 */
	public String getSignYardNum();

	/**
	 * sign yard number
	 * @param signYardNum String
	 */
	public void setSignYardNum(String signYardNum);

	/**
	 * order item type
	 * @return String
	 */
	public String getItemType();

	/**
	 * order item type
	 * @param itemType String
	 */
	public void setItemType(String itemType);

    /**
     * BM SKU
     * @return
     */
    public String getBmSku();

    /**
     * BM SKU
     * @param bmSku
     */
    public void setBmSku(String bmSku);

    /**
     * Menard SKU
     * @return
     */
    public String getMenardSkuStr();

    /**
     * Menard SKU
     * @param menardSku
     */
    public void setMenardSkuStr(String menardSku);

    /**
     * description
     * @return
     */
    public String getDescription();

    /**
     * description
     * @param description
     */
    public void setDescription(String description);

    /**
     * Pos order number
     * @return
     */
    public Long getPosOrderNumber();

    /**
     * Pos order number
     * @param posOrderNumber
     */
    public void setPosOrderNumber(Long posOrderNumber);

	/**
	 * retrieve menard sku
	 * @return String String
	 */
	public String getMenardSkuCode();

	/**
	 *
	 * setMenardProduct
	 * @param menardProduct menardProduct
	 */
	public void setMenardProduct(MenardProduct menardProduct);

	/**
	 *
	 * setMenardSku
	 * @param menardSku menardSku
	 */
	public void setMenardSku(MenardSku menardSku);

	 /**
	 * Retrieve product long description
	 * @return productLongDesc String
	 */
	public String getProductLongDesc();

	/**
	 * Retrieve product name
	 * @return productName String
	 */
	public String getProductName();
}
