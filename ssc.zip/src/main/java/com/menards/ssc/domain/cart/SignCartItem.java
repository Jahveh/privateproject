package com.menards.ssc.domain.cart;

import java.io.Serializable;

/**
 * <p>SignCartItem</p>
 * <p>sign cart item</p>
 * <p>
 * sign cart item
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class SignCartItem extends SkuCartItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5230373173012111180L;
	private Integer signId;
	private String yardNum;
	private String signName;
	private String unitPrice;
	private String totalPrice;
	private String stockSize;
    private int promoNumber;
    private String criteriaType;
	private String printLocation;

    private String previewImagePath;
    private String largerImagePath;

	/**
	 * 
	 *Constructor
	 */
	public SignCartItem() {
	}

	/**
	 * 
	 *Constructor 
	 *@param dto AddSignDTO
	 */
	public SignCartItem(AddSignDTO dto) {
		this.signId = dto.getSignId();
		this.yardNum = dto.getYardNum();
		this.setType(dto.getType());
		if (dto.getPromoNumber() != null) {
			this.promoNumber = dto.getPromoNumber();		
		}
       
        this.criteriaType = dto.getCriteriaType();
	}

	public Integer getSignId() {
		return signId;
	}

	public void setSignId(Integer signId) {
		this.signId = signId;
	}

	public String getYardNum() {
		return yardNum;
	}

	public void setYardNum(String yardNum) {
		this.yardNum = yardNum;
	}

	public String getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getSignName() {
		return signName;
	}

	public void setSignName(String signName) {
		this.signName = signName;
	}

	public String getStockSize() {
		return stockSize;
	}

	public void setStockSize(String stockSize) {
		this.stockSize = stockSize;
	}

	public String getPrintLocation() {
		return printLocation;
	}

	public void setPrintLocation(String printLocation) {
		this.printLocation = printLocation;
	}

    public int getPromoNumber() {
        return promoNumber;
    }

    public void setPromoNumber(int promoNumber) {
        this.promoNumber = promoNumber;
    }

    public String getCriteriaType() {
        return criteriaType;
    }

    public void setCriteriaType(String criteriaType) {
        this.criteriaType = criteriaType;
    }

    public String getPreviewImagePath() {
        return previewImagePath;
    }

    public void setPreviewImagePath(String previewImagePath) {
        this.previewImagePath = previewImagePath;
    }

    public String getLargerImagePath() {
        return largerImagePath;
    }

    public void setLargerImagePath(String largerImagePath) {
        this.largerImagePath = largerImagePath;
    }
}
