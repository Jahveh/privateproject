package com.menards.ssc.domain.catalog;

import java.io.Serializable;

import javax.validation.constraints.Size;

import org.apache.commons.lang.StringUtils;

/**
 * <p>BusinessCardDTO</p>
 * <p>Business Card DTO</p>
 * <p>
 * Business Card DTO
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class BusinessCardDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6630421066824596538L;

	@Size(max = 100)
	private String title;

	@Size(max = 120)
	private String name;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * get comment from business card
	 * @return String comment
	 */
	public String getComment() {
		StringBuffer sb = new StringBuffer();
		if (StringUtils.isNotEmpty(name)) {
			sb.append("Name: ").append(name).append("; ");
		}
		if (StringUtils.isNotEmpty(title)) {
			sb.append("Title: ").append(title);
		}
		return sb.toString();
	}

}
