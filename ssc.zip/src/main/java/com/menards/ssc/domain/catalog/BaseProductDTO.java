package com.menards.ssc.domain.catalog;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.broadleafcommerce.core.catalog.domain.Category;
import org.broadleafcommerce.core.catalog.domain.CategoryAttribute;
import org.broadleafcommerce.core.catalog.domain.ProductAttribute;

import com.menards.ssc.constants.CategoryAttributeKey;
import com.menards.ssc.constants.ProductAttributeKey;
import com.menards.ssc.constants.SkuAttributeKey;
import com.menards.ssc.util.MenardUtil;

/**
 * <p>BaseProductDTO</p>
 * <p>base product dto</p>
 * <p>
 * base product dto without sku
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class BaseProductDTO implements Serializable, ProductAttributeKey, SkuAttributeKey, CategoryAttributeKey {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8830292777381141068L;
	private MenardProduct product;

	/**
	 *Constructor
	 *@param product product
	 */
	public BaseProductDTO(MenardProduct product) {
		this.product = product;
	}

	public MenardProduct getProduct() {
		return product;
	}

	/**
	 *
	 * get product attribute by uppercase key
	 * @param key eky
	 * @return string attribute value of product
	 */
	public String getAttrAsString(String key) {
		String mappingKey = MenardUtil.getMappingKey(key);
		ProductAttribute pa = product.getProductAttributes().get(mappingKey);
		if (pa != null) {
			return pa.getValue();
		}
		return null;
	}

	/**
	 *
	 * get product attribute by uppercase key
	 * @param key key
	 * @return boolean booelan
	 */
	public boolean getAttrAsBoolean(String key) {
		String val = this.getAttrAsString(key);
		return this.convert2Boolean(val);
	}

	/**
	 * convert string to boolean value
	 * @param val string of boolean
	 * @return boolean booelan
	 */
	private boolean convert2Boolean(String val) {
		if (TRUE_STRING.equalsIgnoreCase(val)) {
			return true;
		}
		return false;
	}

	/**
	 *
	 * get category attribute by uppercase key
	 * @param key key
	 * @return string value of category
	 */
	private String getCategoryAttrAsString(String key) {
		Category category = product.getDefaultCategory();
		if (category != null) {
			String mappingKey = MenardUtil.getMappingKey(key);
			CategoryAttribute ca = category.getCategoryAttributeByName(mappingKey);
			return ca == null ? null : ca.getValue();
		}
		return null;
	}

	/**
	 *
	 * get category attribute by uppercase key
	 * @param key key
	 * @return boolean booelan
	 */
	protected boolean getCategoryAttrAsBoolean(String key) {
		String mappingKey = MenardUtil.getMappingKey(key);
		String val = this.getCategoryAttrAsString(mappingKey);
		return this.convert2Boolean(val);
	}

	/**
	 * get product image url
	 * @return img url
	 */
	public String getProductListImgUrl() {
		String imgUrl = this.getAttrAsString(ProductAttributeKey.IMAGE_MEDIUM);
		if (StringUtils.isEmpty(imgUrl)) {
			imgUrl = this.getAttrAsString(IMAGE_LARGE);
		}
		return imgUrl;

	}

	/**
	 * get product small image url
	 * @return img url
	 */
	public String getProductSmallImgUrl() {
		return this.getAttrAsString(IMAGE_SMALL);

	}

	public String getSize() {
		return this.getAttrAsString(SIZE);
	}

	public String getBrandName() {
		return this.getAttrAsString(BRAND_NAME);
	}

	public String getDescriptionShort() {
		return this.getAttrAsString(DESCRIPTION_SHORT);
	}

	public String getDescriptionLong() {
		return this.getAttrAsString(DESCRIPTION_LONG);
	}

	public String getUOM() {
		return this.getAttrAsString(UOM);
	}

	/**
	 * bullets
	 * @return bullets list
	 */
	public List<String> getBullets() {
		List<String> bullets = new ArrayList<String>();
		String bullet = BULLET_1.substring(0, BULLET_1.length() - 1);
		String key;
		String value;
		for (int i = 1; i <= 11; i++) {
			key = bullet + i;
			value = this.getAttrAsString(key);
			if (StringUtils.isNotEmpty(value)) {
				bullets.add(value);
			}
		}
		return bullets;
	}

	/**
	 * currently are not used
	 * @return boolean booelan
	 */
	public boolean getSelectColorOrMeasurement() {
		return false;
	}

	/**
	 * currently are not used
	 * isFlagMesBeforeColor
	 * @return boolean booelan
	 */
	public boolean getIsFlagMesBeforeColor() {
		return true;
	}

	/**
	 * FLAG LOCK QUANTITY CHANGEABLE
	 * @return boolean
	 */
	public boolean getFlagLockQuantity() {
		return this.getAttrAsBoolean(FLAG_LOCK_QUANTITY);
	}

	/**
	 * currently are not used
	 * boMeasurement type && boMeasurement
	 * @return boolean booelan
	 */
	public boolean getMeasurementable() {
		return false;
	}

	/**
	 * currently are not used
	 * carton quantity able
	 * @return boolean booelan
	 */
	public boolean getCartonQuantity() {
		return false;
	}

	/**
	 * get series number
	 * @return string product model num
	 */
	public String getSeriesNumber() {
		return product.getModelNum();
	}

	/**
	 * collection
	 * @return List<MenardProduct> products
	 */
	public List<MenardProduct> getCollection() {
		return new ArrayList<MenardProduct>();
	}

	/**
	 * for additional tab
	 * @return Map<String, String> measurements
	 */
	public Map<String, String> getMeasurements() {
		return new HashMap<String, String>();
	}

	public String getVendorSize() {
		return this.getAttrAsString(VENDOR_SIZE);
	}

	/**
	 * check is welcome sign
	 * @return boolean booleanboolean
	 */
	public boolean isWelcomeSign() {
		return getAttrAsString(IS_WELCOME_SIGN) == null ? false : true;
	}

	/**
	 * check is business card
	 * @return boolean boolean
	 */
	public boolean isBusinessCard() {
		return getAttrAsString(IS_BUSINESS_CARD) == null ? false : true;
	}

	/**
	 * product vendor
	 * @return vendor
	 */
	public String getVendorName() {
		return this.getAttrAsString(VENDOR_NAME);
	}

	/**
	 * get category Id
	 * @return id id
	 */
	public Long getCategoryId() {
		return product.getDefaultCategory().getId();
	}

}
