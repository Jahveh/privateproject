package com.menards.ssc.domain.catalog;

import java.io.Serializable;

import javax.validation.constraints.Size;

import org.apache.commons.lang3.StringUtils;

/**
 * <p>WelcomeSignDTO</p>
 * <p>Welcome Sign DTO</p>
 * <p>
 * Welcome Sign DTO
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class WelcomeSignDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1431021644482334817L;

	@Size(max = 35)
	private String generalManager;

	@Size(max = 35)
	private String assistantManager1;

	@Size(max = 35)
	private String assistantManager2;

	@Size(max = 35)
	private String assistantManager3;

	@Size(max = 35)
	private String frontEndManager;

	@Size(max = 35)
	private String yardReceivingManager;

	public String getGeneralManager() {
		return generalManager;
	}

	public void setGeneralManager(String generalManager) {
		this.generalManager = generalManager;
	}

	public String getAssistantManager1() {
		return assistantManager1;
	}

	public void setAssistantManager1(String assistantManager1) {
		this.assistantManager1 = assistantManager1;
	}

	public String getAssistantManager2() {
		return assistantManager2;
	}

	public void setAssistantManager2(String assistantManager2) {
		this.assistantManager2 = assistantManager2;
	}

	public String getAssistantManager3() {
		return assistantManager3;
	}

	public void setAssistantManager3(String assistantManager3) {
		this.assistantManager3 = assistantManager3;
	}

	public String getFrontEndManager() {
		return frontEndManager;
	}

	public void setFrontEndManager(String frontEndManager) {
		this.frontEndManager = frontEndManager;
	}

	public String getYardReceivingManager() {
		return yardReceivingManager;
	}

	public void setYardReceivingManager(String yardReceivingManager) {
		this.yardReceivingManager = yardReceivingManager;
	}

	/**
	 * get comment from welcome sign dto
	 * @return  string comment
	 */
	public String getComment() {
		StringBuffer sb = new StringBuffer();
		String strGeneralManager = getGeneralManager();
		if (StringUtils.isNotEmpty(strGeneralManager)) {
			sb.append("GM: ").append(strGeneralManager);
		}

		String strAssistantManager1 = getAssistantManager1();
		String strAssistantManager2 = getAssistantManager2();
		String strAssistantManager3 = getAssistantManager3();

		if (StringUtils.isNotEmpty(strAssistantManager1) || StringUtils.isNotEmpty(strAssistantManager2)
				|| StringUtils.isNotEmpty(strAssistantManager3)) {
			if (sb.length() > 0) {
				sb.append("; ");
			}
			sb.append("AGM:");
			if (StringUtils.isNotEmpty(strAssistantManager1)) {
				sb.append(strAssistantManager1);
			}
			if (StringUtils.isNotEmpty(strAssistantManager2)) {
				if (!sb.toString().endsWith(":")) {
					sb.append(",");
				}
				sb.append(strAssistantManager2);
			}
			if (StringUtils.isNotEmpty(strAssistantManager3)) {
				if (!sb.toString().endsWith(":")) {
					sb.append(",");
				}
				sb.append(strAssistantManager3);
			}
		}

		String strFrondEndManager = getFrontEndManager();
		if (StringUtils.isNotEmpty(strFrondEndManager)) {
			if (sb.length() > 0) {
				sb.append("; ");
			}
			sb.append("FEM:").append(strFrondEndManager);
		}

		String strYardReceivingManager = getYardReceivingManager();
		if (StringUtils.isNotEmpty(strYardReceivingManager)) {
			if (sb.length() > 0) {
				sb.append("; ");
			}
			sb.append("YRS:").append(strYardReceivingManager);
		}

		return sb.toString();
	}

}
