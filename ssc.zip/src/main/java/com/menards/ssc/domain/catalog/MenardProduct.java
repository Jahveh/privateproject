package com.menards.ssc.domain.catalog;

import java.io.Serializable;

import org.broadleafcommerce.core.catalog.domain.Product;

/**
 * <p>MenardProduct</p>
 * <p>menard product</p>
 * <p>
 * menard product extends product
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public interface MenardProduct extends Product, Serializable {

	/**
	 * get product model number
	 * @return model number
	 */
	public String getModelNum();

	/**
	 * set product model number
	 * @param modelNum model number
	 */
	public void setModelNum(String modelNum);

}
