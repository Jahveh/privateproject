/**
 *
 */
package com.menards.ssc.domain.catalog;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

import com.menards.ssc.constants.CommonConstant;
import com.menards.ssc.enums.SkuStatus;

/**
 * <p>SkuDTO</p>
 * <p></p>
 * <p> 
 * </p>
 * <p>Copyright (c) 2013</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class SkuDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5119295115580270851L;
	private Long skuId;
	private Long productId;
	private String name;
	private String status;
	private String unit;
	private Boolean isInCatalog;
	private String description;
	private String longDescription;
	private String skuCode;
	private String skuType;
	private String mml;	
	private Long   openSku;

	/**
	 * 
	 *Constructor
	 */
	public SkuDTO() {
		super();
	}

	/**
	 * 
	 *Constructor 
	 *@param desc MenardProductDesc
	 */
	public SkuDTO(MenardProductDesc desc) {
		MenardProductDesc.MenardProductDescPK id = desc.getId();
		this.skuId = id.getSkuId();
		this.productId = id.getProductId();		
		this.description = desc.getDescription1();
		this.longDescription = desc.getDescription2();
		if (StringUtils.isNotBlank(desc.getProductDesc())) {
			this.description = desc.getProductDesc();
		}
		if (StringUtils.isNotBlank(desc.getSkuDesc())) {
			this.longDescription = desc.getSkuDesc();
		}
		this.unit = desc.getUom();
		this.isInCatalog = false;
		this.skuType = desc.getSkuType();
		this.skuCode = desc.getId().getSkuCode();
		this.openSku = desc.getId().getOpensku();
		// this.mml = desc.getMml();
		// this.bmSkuId = StringUtils.substringAfter(desc.getSkuId(), "|");
	}

	/**
	 * 
	 *Constructor 
	 *@param desc desc
	 *@param skuStatusCode skuStatusCode
	 */
	public SkuDTO(MenardProductDesc desc, String skuStatusCode) {
		this(desc);
		if (status == null) {
			return;
		}
		this.status = skuStatusCode;
	}

	public Long getSkuId() {
		return skuId;
	}

	public void setSkuId(Long skuId) {
		this.skuId = skuId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLongDescription() {
		return longDescription;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	/**
	 * 
	 * getStatus
	 * @return String String
	 */
	public String getStatus() {
		if (StringUtils.isEmpty(status)) {
			return SkuStatus.DC_SPECIAL_ORDER.getDesc();
		}

		SkuStatus skuStatus = SkuStatus.getSkuStatusByCode(Integer.parseInt(status));
		return skuStatus == null ? StringUtils.EMPTY : skuStatus.getDesc();
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public Boolean isInCatalog() {
		return isInCatalog;
	}

	public void setIsCatalog(Boolean isInCatalog) {
		this.isInCatalog = isInCatalog;
	}

	public String getSkuCode() {
		return skuCode;
	}

	public void setSkuCode(String skuCode) {
		this.skuCode = skuCode;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getSkuType() {
		return skuType;
	}

	public void setSkuType(String skuType) {
		this.skuType = skuType;
	}

	public String getMml() {
		return mml;
	}

	public void setMml(String mml) {
		this.mml = mml;
	}

	/**
	 * 
	 * getSkuClassUrl
	 * @return String String
	 */
	public String getSkuClassUrl() {
		if (StringUtils.isBlank(skuType)) {
			return StringUtils.EMPTY;
		}
		if (StringUtils.startsWith(skuType, "deptclass")) {
			return "/search/skuclass?query=" + StringUtils.substringAfter(skuType, CommonConstant.SEPARATOR);
		}

		if (StringUtils.startsWith(skuType, "single")) {
			return "/product/" + productId + "?skuId=" + skuId;
		}
		return StringUtils.EMPTY;
	}

	/**
	 * 
	 * getInCatalog
	 * @return String String
	 */
	public String getInCatalog() {
		if (StringUtils.startsWith(skuType, "deptclass")) {
			return "Multiple";
		}

		if (StringUtils.startsWith(skuType, "single")) {
			return "In Catalog";
		}
		return StringUtils.EMPTY;
	}

	public Boolean getIsInCatalog() {
		return isInCatalog;
	}

	public void setIsInCatalog(Boolean isInCatalog) {
		this.isInCatalog = isInCatalog;
	}

	public Long getOpenSku() {
		return openSku;
	}

	public void setOpenSku(Long openSku) {
		this.openSku = openSku;
	}
}
