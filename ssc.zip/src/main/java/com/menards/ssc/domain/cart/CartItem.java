package com.menards.ssc.domain.cart;

import java.io.Serializable;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

/**
 * <p>CartItem</p>
 * <p>base cart item</p>
 * <p>
 * base cart item
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class CartItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3624178946837878454L;

	@Min(1)
	@Max(9999)
	private Integer quantity = 1;;

	@Size(max = 255)
	private String comment;
	private boolean skuAvailable = true;;
	private boolean commentEditable;
	private boolean quantityEditable;

	private Long orderItemId;

	private Integer minQty = 1;
	private Integer incrementQty = 1;
	private Integer maxQty;

	private String productImgUrl;
	private String descriptionShort;
	private String modelNum;
	private String seriesNumber;
	private String brandName;
	private String color;
	private String leadTimeMsg;

	private boolean canOrder = true;

	private String type;

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Long getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(Long orderItemId) {
		this.orderItemId = orderItemId;
	}

	public boolean isCommentEditable() {
		return commentEditable;
	}

	public void setCommentEditable(boolean commentEditable) {
		this.commentEditable = commentEditable;
	}

	public String getProductImgUrl() {
		return productImgUrl;
	}

	public void setProductImgUrl(String productImgUrl) {
		this.productImgUrl = productImgUrl;
	}

	public String getDescriptionShort() {
		return descriptionShort;
	}

	public void setDescriptionShort(String descriptionShort) {
		this.descriptionShort = descriptionShort;
	}

	public String getModelNum() {
		return modelNum;
	}

	public void setModelNum(String modelNum) {
		this.modelNum = modelNum;
	}

	public String getSeriesNumber() {
		return seriesNumber;
	}

	public void setSeriesNumber(String seriesNumber) {
		this.seriesNumber = seriesNumber;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getLeadTimeMsg() {
		return leadTimeMsg;
	}

	public void setLeadTimeMsg(String leadTimeMsg) {
		this.leadTimeMsg = leadTimeMsg;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getMinQty() {
		return minQty;
	}

	public void setMinQty(Integer minQty) {
		this.minQty = minQty;
	}

	public Integer getIncrementQty() {
		return incrementQty;
	}

	public void setIncrementQty(Integer incrementQty) {
		this.incrementQty = incrementQty;
	}

	public Integer getMaxQty() {
		return maxQty;
	}

	public void setMaxQty(Integer maxQty) {
		this.maxQty = maxQty;
	}

	public boolean isQuantityEditable() {
		return quantityEditable;
	}

	public void setQuantityEditable(boolean quantityEditable) {
		this.quantityEditable = quantityEditable;
	}

	public boolean getSkuAvailable() {
		return skuAvailable;
	}

	public void setSkuAvailable(boolean skuAvailable) {
		this.skuAvailable = skuAvailable;
	}

	public boolean isCanOrder() {
		return canOrder;
	}

	public void setCanOrder(boolean canOrder) {
		this.canOrder = canOrder;
	}

}
