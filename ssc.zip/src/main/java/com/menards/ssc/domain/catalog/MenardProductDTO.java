package com.menards.ssc.domain.catalog;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

import com.menards.ssc.constants.ProductAttributeKey;
import com.menards.ssc.security.MenardSecurityContextHolder;
import com.menards.ssc.security.MenardUserDetails;

/**
 * <p>MenardProductDTO</p>
 * <p>base product dto with sku</p>
 * <p>
 * base product dto with sku which  is allow null
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class MenardProductDTO extends BaseProductDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5449462428231389200L;
	private MenardSku sku;
	private MenardSkuDTO skuDTO;

	/**
	 *Constructor
	 *@param product product
	 *@param sku sku
	 */
	public MenardProductDTO(MenardProduct product, MenardSku sku) {
		super(product);
		this.sku = sku;
		this.skuDTO = new MenardSkuDTO(sku);
	}

	public MenardSku getSelectedSku() {
		return sku;
	}

	public MenardSkuDTO getSelectedSkuDTO() {
		return skuDTO;
	}

	/**
	 * get product image url
	 * @return img url
	 */
	public String getProductImgUrl() {
		String imgUrl = null;
		if (getSelectedSku() != null) {
			imgUrl = getSelectedSkuDTO().getSkuImgUrl();
		}

		if (StringUtils.isEmpty(imgUrl)) {
			imgUrl = this.getAttrAsString(ProductAttributeKey.IMAGE_MEDIUM);
			if (StringUtils.isEmpty(imgUrl)) {
				imgUrl = this.getAttrAsString(IMAGE_LARGE);
			}
		}
		return imgUrl;

	}

	/**
	 * sku color , the product only has single one default sku show sku color
	 * @return color
	 */
	public String getColor() {
		String vendor = this.getAttrAsString(VENDOR);
		String colorAttr = "Pri_Col_Fin_" + vendor;
		String color = this.getAttrAsString(colorAttr);
		if (StringUtils.isNotEmpty(color)) {
			return color;
		} else {
			return "N/A";
		}
	}

	/**
	 * get price
	 * @return string price
	 */
	public String getPrice() {
		boolean hidePrice = getAttrAsBoolean(FLAG_HIDE_PRODUCT_PRICE);
		if (!hidePrice) {
			if (getSelectedSku() != null) {
				return getSelectedSkuDTO().getPrice();
			}
		}
		return null;
	}

	/**
	 * lead time message
	 * @return string message
	 */
	public String getLeadTimeMsg() {
		if (getSelectedSku() != null) {
			return getSelectedSkuDTO().getLeadTimeMsg();
		}
		return null;
	}

	/**
	 * get model number
	 * @return string model num
	 */
	public String getModelNum() {
		if (getProduct() != null) {
			return this.getProduct().getModelNum();
		}
		return null;
	}

	/**
	 * get sku number
	 * @return string sku num
	 */
	public String getSkuNum() {
		if (getSelectedSku() != null) {
			return getSelectedSkuDTO().getSkuNum();
		}
		return null;
	}

	/**
	 * get min quantity
	 * @return quantity integer
	 */
	public Integer getMinQty() {
		if (getSelectedSku() != null) {
			return getSelectedSkuDTO().getMinQty();
		}
		return null;
	}

	/**
	 * get min quantity
	 * @return quantity integer
	 */
	public Integer getMaxQty() {
		MenardUserDetails user = MenardSecurityContextHolder.getMenardUserDetails();
		if (!user.isGOUser()) {
			if (getSelectedSku() != null) {
				return getSelectedSkuDTO().getMaxQty();
			}
		}
		return null;
	}

	/**
	 * get min quantity
	 * @return quantity integer
	 */
	public Integer getIncrementQty() {
		if (getSelectedSku() != null) {
			return getSelectedSkuDTO().getIncrementQty();
		}
		return null;
	}

	/**
	 * get default quantity
	 * @return quantity quantity
	 */
	public int getQuantity() {
		// if (this.getMinQty() != null) {
		// return this.getMinQty();
		// }
		return 1;
	}

}
