package com.menards.ssc.domain.order;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.broadleafcommerce.common.presentation.AdminPresentation;
import org.broadleafcommerce.core.order.domain.OrderItem;
import org.broadleafcommerce.core.order.domain.OrderItemImpl;
import org.hibernate.annotations.Index;

import com.menards.ssc.constants.CommonConstant;

/**
 * 
 * <p>
 * MenardDiscreteOrderItemImpl
 * </p>
 * <p>
 * An Extended OrderImpl that extends OrderImpl for entity implementation.
 * </p>
 * <p>
 * Copyright (c) 2013
 * </p>
 * <p>
 * Menard Inc.
 * </p>
 * 
 * @author bill01.zhang
 * @version 1.0
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "MENARD_DISCRETE_ORDER_ITEM")
public class MenardOrderItemHistory extends OrderItemHistory implements Serializable {

	private static final long serialVersionUID = 800971203020655684L;

	@Column(name = "NOTES")
	private String notes;

	@Column(name = "LINE_NUMBER")
	private Integer lineNumber;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "STATUS_DATE")
	private Date statusDate;

	@Column(name = "REQUEST_TYPE")
	private String requestType;

	@ManyToOne(targetEntity = MenardOrderImpl.class)
	@JoinColumn(name = "ORDER_ID")
	@Index(name = "ORDERITEM_ORDER_INDEX", columnNames = { "ORDER_ID" })
	@AdminPresentation(excluded = true)
	private MenardOrder menardOrder;

	@OneToMany(targetEntity = MenardOrderItemTrackingHistory.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ITEM_ID")
	private List<MenardOrderItemTrackingHistory> history = new ArrayList<MenardOrderItemTrackingHistory>();

	@Column(name = "DCITEM")
	private String dcItem;

	@Column(name = "STORE_REMODEL")
	private String storeRemodel;

	@Column(name = "FULFILLER_TYPE")
	private String fulfillerTypeCode;

	@Column(name = "STORE_PRINT")
	private String storePrint;

	@Column(name = "SIGN_ID")
	private Integer signId;

	@Column(name = "SIGN_YARD_NUM")
	private String signYardNum;

	@Column(name = "ITEM_TYPE")
	private String itemType;

	@Column(name = "BM_SKU")
	private String bmSku;

	@Column(name = "MENARD_SKU")
	private String menardSkuStr;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "POS_ORDER_NUMBER")
	private Long posOrderNumber;

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Integer getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(Integer lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(Date statusDate) {
		this.statusDate = statusDate;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public MenardOrder getMenardOrder() {
		return menardOrder;
	}

	public void setMenardOrder(MenardOrder menardOrder) {
		this.menardOrder = menardOrder;
	}

	public List<MenardOrderItemTrackingHistory> getHistory() {
		return history;
	}

	public void setHistory(List<MenardOrderItemTrackingHistory> history) {
		this.history = history;
	}

	public String getDcItem() {
		return dcItem;
	}

	public void setDcItem(String dcItem) {
		this.dcItem = dcItem;
	}

	public String getStoreRemodel() {
		return storeRemodel;
	}

	public void setStoreRemodel(String storeRemodel) {
		this.storeRemodel = storeRemodel;
	}

	public String getFulfillerTypeCode() {
		return fulfillerTypeCode;
	}

	public void setFulfillerTypeCode(String fulfillerTypeCode) {
		this.fulfillerTypeCode = fulfillerTypeCode;
	}

	public String getStorePrint() {
		return storePrint;
	}

	public void setStorePrint(String storePrint) {
		this.storePrint = storePrint;
	}

	public Boolean isDcItem() {
		return CommonConstant.TRUE_STRING.equals(this.dcItem);
	}

	public Boolean isStoreRemodel() {
		return CommonConstant.TRUE_STRING.equals(this.storeRemodel);
	}

	public Boolean isStorePrint() {
		return CommonConstant.TRUE_STRING.equals(this.storePrint);
	}

	public Integer getSignId() {
		return signId;
	}

	public void setSignId(Integer signId) {
		this.signId = signId;
	}

	public String getSignYardNum() {
		return signYardNum;
	}

	public void setSignYardNum(String signYardNum) {
		this.signYardNum = signYardNum;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public String getBmSku() {
		return bmSku;
	}

	public void setBmSku(String bmSku) {
		this.bmSku = bmSku;
	}

	public String getMenardSkuStr() {
		return menardSkuStr;
	}

	public void setMenardSkuStr(String menardSku) {
		this.menardSkuStr = menardSku;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getPosOrderNumber() {
		return posOrderNumber;
	}

	public void setPosOrderNumber(Long posOrderNumber) {
		this.posOrderNumber = posOrderNumber;
	}
}
