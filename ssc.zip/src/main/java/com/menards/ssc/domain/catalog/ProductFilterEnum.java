/*
 * ProductFilterEnum
 * 
 * 2014-03-28
 *
 * Copyright (c) 2014
 * Menard Inc.
 */
package com.menards.ssc.domain.catalog;

import java.io.Serializable;

/**
 * Constant String literals for product filter function
 * @author james.ni
 */
public enum ProductFilterEnum implements Serializable{
	FILTER_FLAG_Y("Y"),
	FILTER_FLAG_N("N"),
	FILTER_ATR_SUFFIX("_ATR"),
	FILTER_SEARCHABLE_PREFIX("prd_Searchable_"),
	FILTER_SEARCH_PREFIX("prd_search_"),
    FILTER_SEPARATOR(","),
    FILTER_VENDOR("Vendor");

	private String value;

	/**
	 * 
	 *Constructor 
	 *@param value value
	 */
	private ProductFilterEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}