package com.menards.order.clothing;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventHandler;

/**
 * Created by Frank Peng on 6/11/2014.
 */
public class ClothingOrderValidationHandler implements ValidationEventHandler {
    private static final Log LOG = LogFactory.getLog(ClothingOrderValidationHandler.class);

    @Override
    public boolean handleEvent(ValidationEvent event) {
        if (event.getSeverity() == ValidationEvent.ERROR || event.getSeverity() ==  ValidationEvent.FATAL_ERROR) {
            return false;
        }
        return true;
    }
}
