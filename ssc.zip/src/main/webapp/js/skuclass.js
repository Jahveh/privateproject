$(document).ready(function() {		
	$(".skuClassTable tr:gt(0)").each(function(index, obj) {		
		$(obj).click(function() {
			
			var url = $("input[type=hidden]:eq(0)", obj).val();
			if ($.trim(url) != '') {
				window.location.href = $("input[type=hidden]:eq(0)", obj).val();
			}
		});		
	});
	
	//When mouse over the row to show hand
	$(".skuClassTable tr:gt(0)").each(function(index, obj) {		
		$(obj).mouseover(function() {
			$(obj).css('cursor','pointer');
			$(obj).css('background','#ADD8E6');
		});		
	});
	
	//When mouse out the row to show hand
	$(".skuClassTable tr:gt(0)").each(function(index, obj) {		
		$(obj).mouseout(function() {
			$(obj).css('background','');
		});		
	});	
	//Add search functionality to breadcrumb
	$(function() {
		if ($(".skuClassTable").length){
			$('#content div').html("<a href='" + urlPrefix + "'>Home</a>&nbsp;&gt;&nbsp;<a href='javascript:void(0)'>Search</a>");		
		}
	});
});