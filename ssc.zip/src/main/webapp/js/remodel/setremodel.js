function reset(){
	$("#yardList").find('option:selected').prop("selected",false);
	$("#datepickerStart").val("");
	$("#datepickerEnd").val("");
	$("#errId").text("");
}
$(document).ready(function() {
	
	$( "#datepickerStart, #datepickerEnd" ).datepicker({
		showOn: "button",
		buttonImage: "../img/calendar.gif",
		buttonImageOnly: true,
		changeMonth: true,
		changeYear: true,
		dateFormat: "mm/dd/yy"
		});
	
		
	$('#nameSortBtn').click(function(){		 
	    $("#yardList").each(function(i,v){// loop through relative selects
			var $options = $(v).find('option'); // get all options
           $options = $options.sort(function(a,b){ // sort by value of options
               return $(a).text() > $(b).text() ? 1 : -1;
           });
           $(this).html($options); // add new sorted options to select
		});
	    
	    reset();
	});
	
	 $('#numSortBtn').click(function(){
		 $("#yardList").each(function(i,v){// loop through relative selects
			var $options = $(v).find('option'); // get all options
           $options = $options.sort(function(a,b){ // sort by value of options
               return $(a).val() > $(b).val() ? 1 : -1;
           });
           $(this).html($options); // add new sorted options to select
		});
		 
		 reset();
	});
	 
	 $("#yardList").click(function(){
		 $("#remodelForm").attr("action",$("#storeRemodelAction").val());
		 $("#remodelForm").submit();
	 });
	 
	 $("#submitBtn").click(function(){
			var valid = true;
			var selectedVal = $("#yardList").val();
			if(!selectedVal){
				$("#errId").text("Please select a store");
				valid = false;
			}else{
				$("#errId").text("");
			}
			
			if(!valid){
				return;
			}
			
			var startDateStr = $("#datepickerStart").val();
			if(!startDateStr){
				$("#errId").text("Start Date is required.");
				valid = false;
			}else{
				$("#errId").text("");
			}
			
			if(!valid){
				return;
			}
			
			var today = new Date();
			var startDate = new Date(Date.parse(startDateStr));
			if(startDate < today){
				$("#errId").text("Start date must be in the future");
				valid = false;
			}else{
				$("#errId").text("");
			}
			
			if(!valid){
				return;
			}
			
			var endDateStr = $("#datepickerEnd").val();
			if(!endDateStr){
				$("#errId").text("End Date is required.");
				valid = false;
			}else{
				$("#errId").text("");
			}
			
			if(!valid){
				return;
			}
			
			var endDate = new Date(Date.parse(endDateStr));
			if(endDate < today){
				$("#errId").text("End date must be in the future");
				valid = false;
			}else{
				$("#errId").text("");
			}
			
			if(!valid){
				return;
			}			
			
			if(startDate >= endDate){
				$("#errId").text("Start date must be before the end date");
				valid = false;
			}else{
				$("#errId").text("");
			}
		
			if(!valid){
				return;
			}
			
			$("#remodelForm").submit();
		});
	 
	 var $s = $('#yardList');
	 var $offset = $s.find('option:selected').offset();
	 if($offset){		 
		 var optionTop = $offset.top;
		 var selectTop = $s.offset().top;
		 
		 $s.scrollTop($s.scrollTop() + (optionTop - selectTop));
	 }
});