$(document).ready(function () {
    /*
     * A utility method exposed on the global jquery($) object for other modules to append their respective bread crumb.
     */
    $.appendBreadCrumbs = function (linkJson) {
        $('#content div').append("&nbsp;&gt;&nbsp;").append("<a href='" + urlPrefix + linkJson.crumbLink + "'>" + linkJson.crumbName + "</a>");
    };

    //[START] disable right click
    $(document).on("contextmenu", function (e) {
        e.preventDefault();
    });
    //[END] disable right click

    //[START]disable ctrl-o key
    $(document).keydown(function () {
        msg = " has been disabled!";
        var ctrlBlocked = new Array(66, 69, 72, 73, 75, 76, 78, 79, 80);
        var ctrlBlockedValues = new Array('B', 'E', 'H', 'I', 'K', 'L', 'N', 'O', 'P');
        var shiftBlocked = new Array(93, 121);
        var shiftBlockedValues = new Array('F10', 'F10');
        var altBlocked = new Array();
        var altBlockedValues = new Array();
        var keyCode = event.keyCode;
        //cntrl-*
        if (event.ctrlKey) {
            for (var i = 0; i < ctrlBlocked.length; i++) {
                if (keyCode == ctrlBlocked[i]) {
                    alert("Cntrl+" + ctrlBlockedValues[i] + msg);
                    return false;
                }
            }
        }
        //shift-*
        else if (event.shiftKey) {
            for (var i = 0; i < shiftBlocked.length; i++) {
                if (keyCode == shiftBlocked[i]) {
                    alert("Shift+" + shiftBlockedValues[i] + msg);
                    return false;
                }
            }
        }
        //alt-*
        else if (event.altKey) {
            for (var i = 0; i < altBlocked.length; i++) {
                if (keyCode == altBlocked[i]) {
                    alert("Alt+" + shiftBlockedValues[i] + msg);
                    return false;
                }
            }
        }
        //backspace
        else if (keyCode == 8) {
            if (typeof window.event != 'undefined') { //Not a null event
                //Not an Input box, cancel the backspace action
                if (event.srcElement.tagName.toUpperCase() != 'INPUT' && event.srcElement.tagName.toUpperCase() != 'TEXTAREA') {
                    //alert("Backspace" + msg);
                    window.event.returnValue = false;
                }
                //Radio buttons are input, but need backspace disabled
                else if (event.srcElement.tagName.toUpperCase() == 'INPUT' && event.srcElement.type.toUpperCase() == 'RADIO') {
                    window.event.returnValue = false;
                }
                //Input Box or TextArea, cancel the backspace action if it is a read-only box
                else if (event.srcElement.readOnly == true) {
                    //alert("Backspace" + msg);
                    window.event.returnValue = false;
                }
            }
        }
    });
    //[END]disable ctrl-o key

    //[START] init urlPrefix
    var urlPrefix = $("#urlPrefix").attr("href");
    (function () {
        if (urlPrefix.charAt(urlPrefix.length - 1) == "/") {
            urlPrefix = urlPrefix.substring(0, urlPrefix.length - 1);
        }
    })();
    //[END] init urlPrefix

    //[START] init sliding menu
    (function () {
        function runMenu() {
			$('#sliding-menu ul').height('auto');
			$('#sliding-menu li').click(function(){
			var i= $('#sliding-menu ul:visible > li').length;
			var j= $('#sliding-menu > ul > li').length;
			var totalHeight = (i-j)* 50 + 'px';
			$('#sliding-menu ul').height(totalHeight);
			})
			$('.sliding-menu-home').click(function(){
			$('#sliding-menu ul').height('auto');
			})
            $('#menu-shadow, #sliding-menu').show();
            $('#sliding-menu').animate({'opacity': '1.00'}, 100, 'linear');
        }

        function close_menu() {
            $('#menu-shadow, #sliding-menu').animate({'opacity': '0'}, 0, 'linear', function () {
                $('#menu-shadow, #sliding-menu').hide();
            });
        }

        $("#menuBtn").on("click", function () {
            runMenu();
        });
        $('#menu-shadow').click(function () {
            close_menu();
        });
    })();
    //[END] init sliding menu

    function submitNavigationForm(url) {
        $("#navigationForm").attr("action", url);
        $("#navigationForm").submit();
    }

    //[START] attach listeners for those leaf menu item clicks
    $('#sliding-menu a:not(:has(span))').each(function (idx, ele) {
        if (idx != 0) {
            $(ele).click(function () {
                submitNavigationForm(urlPrefix + $(this).attr('url'));
            });
        }
    });
    //[END] attach listeners for those leaf menu item clicks

    //[START] create the bread crumbs
    (function () {

/*
        var buildBreadCrumbByJson = function (breadCrumbJson) {
            for (var i = 0; i < breadCrumbJson.length; i++) {
                $.appendBreadCrumbs(breadCrumbJson[i]);
            }
        }

        var buildBreadCrumbByCurrentUrl = function () {
            var menuItem = $('#sliding-menu a[nodeId="' + $("#selectedCategoryId").val() + '"]');//menu item on the nav menu
            if (menuItem.length > 0) {//found the target menu item on the nav menu
                var breadCrumbs = [];
                var allParentLIs = $(menuItem[0]).parentsUntil('div', 'li');
                for (var i = 0; i < allParentLIs.length; i++) {
                    breadCrumbs[breadCrumbs.length] = {'crumbName': $(allParentLIs[i]).children().first().text(), 'crumbLink': $(allParentLIs[i]).children().first().attr('url')};
                }
                //build specific crumbs
                for (var i = breadCrumbs.length - 1; i >= 0; i--) {
                    $.appendBreadCrumbs({'crumbLink': breadCrumbs[i].crumbLink, 'crumbName': breadCrumbs[i].crumbName})
                }
            }
        }
*/
        $('#content div').append("<a href='" + urlPrefix + "/'>Home</a>").append($('#breadCrumbHtml').html());
        
                /*
        var breadCrumbJson = $('#breadCrumbJson').val() ? JSON.parse($('#breadCrumbJson').val()) : [];
        
        if (breadCrumbJson.length > 0) {
            buildBreadCrumbByJson(breadCrumbJson);
        } else {
            buildBreadCrumbByCurrentUrl();
        }
*/
    })();
    //[END] create the bread crumbs

    //[START] control the menu content as per user roles
    (function () {
        var jsonText = $('#unaccessiblePagesJson').text();
        if (jsonText != "") {
            var unaccessiblePages = JSON.parse(jsonText);
            var allMenuItems = $('#sliding-menu a');
            for (var i = 0; i < allMenuItems.length; i++) {
                var menuUrl = $(allMenuItems[i]).attr('url');
                if (menuUrl) {
                    var hasAccess = true
                    for (var j = 0; j < unaccessiblePages.length; j++) {
                        if (menuUrl.toLowerCase().indexOf(unaccessiblePages[j].toLowerCase()) != -1) {
                            hasAccess = false;
                            break;
                        }
                    }
                    if (!hasAccess) {
                        allMenuItems[i].parentNode.style.display = 'none';
                    }
                }
            }
        }
    })();
    //[END] control the menu content as per user roles

    // Adds endsWith method to String for IE
    (function(){
        if (typeof String.prototype.endsWith !== 'function') {
            String.prototype.endsWith = function(suffix) {
                var d = this.length - suffix.length;
                return d >= 0 && this.lastIndexOf(suffix) === d;
            };
        }
    })();
	
	$(".img-thumbnail").attr("onload",function(){resizeImg(this,"");});
	$(".img-resize").attr("onload",function(){resizeImg(this,"scale");});
	var ua = 'UA-47751860-1';	
	if ($.trim($('.env').val()) == 'stage') {		
		ua = 'UA-47751860-2';
	}
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		 (i[r].q=i[r].q||[]).push(arguments);},i[r].l=1*new Date();a=s.createElement(o),
		 m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m);
		 })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
		 ga('create', ua, 'mymenards.com');
		 ga('send', 'pageview');
	

	// MCR#137475: Add a Loading overlay so users can not accidentally submit the same request multiple times
	// add a loading mask to form submission
	$("body form").submit(function() {
		$("body").addClass("loading");
	});
});

function resizeImg(ImgD,type){
	if(!$(ImgD).hasClass("resize-off")){
		minSize=80;
		limitSize=120;
		kw=limitSize;
		kh=limitSize;
		var image=new Image();
		image.src=ImgD.src;
		
		if($(ImgD).hasClass("resize-half")){
			kw=kw/2;
			kh=kh/2;
		}
		
		if(type=="scale"){
			if(image.height<image.width){
				$(ImgD).width("100%");
				$(ImgD).height("auto");			
			}else{
				$(ImgD).width("100%");
				$(ImgD).height("100%");	
			}
		}else{		
			if(image.height>minSize||image.width>minSize){
				if(image.height<image.width){
					if(image.width>kw){
						$(ImgD).width(kw);
						$(ImgD).height((image.height*kw)/image.width);
					}else{
						$(ImgD).width(image.width); 
						$(ImgD).height(image.height);
					}
				}else{
					if(image.height>kh){
						$(ImgD).height(kh);
						$(ImgD).width((image.width*kh)/image.height);
					}else{
						$(ImgD).width(image.width); 
						$(ImgD).height(image.height);
					}
				}
			}
		}
	}
}


function confirmExit() {
    var msg = "This will erase everything that you have done up to this point, are you sure you want to exit?";
    if (confirm(msg)) {
        window.close();
    }
}

function confirmRestart() {
    var msg = "This will erase everything that you have done up to this point, are you sure you want to restart?";
    if (confirm(msg)) {
        return true;
    }
    return false;
}

function setupRedirect(homeUrl) {
    var currentUrl = window.location.href;
    if (currentUrl.endsWith(homeUrl)) {
        // stop going back to history if it's on home page
        return false;
    } else {
        // handle form posting pages
        var backUrl = $("#backUrlOverride");
        if(backUrl.length > 0) {
            window.location.href = backUrl.val();
        } else {
            history.back();
        }
    }
}

//MCR#137533
//Limit the number of line items that can be added to the cart to 250.
function isItemCountOverLimit(){
	var overLimit = false;
	if(Number($("#cartItemsCount").text())>=250){
		alert("The cart items have reached the maximum limit 250.");
		overLimit = true;
	}
	
	return overLimit;
}
