$(document).ready(function () {
//    changeBreadCrumbs();
});

function redirectHome() {
    $(location).attr("href", $(location).attr("href").replace("/cart/placedpage", "/"));
}

function changeBreadCrumbs() {
    $('#content div').html("").append("<a href='/'>Home</a>");
}

setTimeout('redirectHome()', 3000);