function changeBreadCrumbs(){
    var placeOrderUrl = $("#placeOrderUrl").val();
    var o = {'crumbName': "Place Order", 'crumbLink': placeOrderUrl};
    $('#content div').html("").append("<a href='" + urlPrefix + "'>Home</a>");
    $.appendBreadCrumbs(o);
}

$(document).ready(function() {
    $('#toLeftBtn, #toRightBtn').click(function(){
	    var left = $('#yardList');
		var right = $('#selectedYardList');
		var buttonId = $(this).attr("id");
		if(buttonId == 'toLeftBtn'){
			left.append(right.find('option:selected'));
		}else{
			right.append(left.find('option:selected'));
		}
	});    
    
    $('#yardList').dblclick(function(){  
		$('#toRightBtn').click();
	});    
    
    $('#selectedYardList').dblclick(function(){  
		$('#toLeftBtn').click();
	});
   
    $('#nameSortLeftBtn, #nameSortRightBtn').click(function(){
		 var buttonId = $(this).attr("id");
		 var selectComp;
		 if(buttonId == 'nameSortLeftBtn'){
			 selectComp = $("#yardList");
		 }else{
			 selectComp = $("#selectedYardList");
		 }
		 
	    $(selectComp).each(function(i,v){// loop through relative selects
			var $options = $(v).find('option'); // get all options
            $options = $options.sort(function(a,b){ // sort by value of options
                return $(a).text() > $(b).text() ? 1 : -1;
            });
            $(this).html($options); // add new sorted options to select
		});
	});
	
	 $('#numSortLeftBtn, #numSortRightBtn').click(function(){
		 var buttonId = $(this).attr("id");
		 var selectComp;
		 if(buttonId == 'numSortLeftBtn'){
			 selectComp = $("#yardList");
		 }else{
			 selectComp = $("#selectedYardList");
		 }
		 
		 $(selectComp).each(function(i,v){// loop through relative selects
			var $options = $(v).find('option'); // get all options
            $options = $options.sort(function(a,b){ // sort by value of options
                return $(a).val() > $(b).val() ? 1 : -1;
            });
            $(this).html($options); // add new sorted options to select
		});
	});
	
	 $( "#orderType" ).change(function(){
		 var orderCode = $("#orderCode").text();
		 if(orderCode){
			 orderCode = $(this).val() + orderCode.substring(orderCode.indexOf("-"), orderCode.length);
		 }else{
			 orderCode = $(this).val() +"--";
		 }
		 $("#orderCode").text(orderCode);
	 });
	 
	 $( "#group" ).change(function(){
		 var orderCode = $("#orderCode").text();
		 if(orderCode){
			 orderCode = orderCode.substring(0, orderCode.indexOf("-")+1)+ $(this).val() + orderCode.substring(orderCode.lastIndexOf("-"), orderCode.length);
		 }else{
			 orderCode = "-"+ $(this).val() +"-";
		 }
		 $("#orderCode").text(orderCode);
	 });
	 
	 
	 $( "#deptId" ).change(function(){
		 var orderCode = $("#orderCode").text();
		 if(orderCode){
			 orderCode = orderCode.substring(0, orderCode.lastIndexOf("-")+1)+$(this).val();
		 }else{
			 orderCode = "--"+ $(this).val();
		 }
		 $("#orderCode").text(orderCode);
	 });
	
	$( "#datepicker" ).datepicker({
		showOn: "button",
		buttonImage: "../img/calendar.gif",
		buttonImageOnly: true,
		dateFormat: "yy/mm/dd",
        changeMonth: true,
        changeYear: true
		}).datepicker("setDate", "0");

	
	$("#submitBtn").click(function(){
		var isYard = $("#isYardHidden").val();
		var valid = true;
		if(isYard == 'false'){			
			$("#selectedYardList option").prop("selected",true);
			var selectedVal = $("#selectedYardList").val();
			if(!selectedVal){
				$("#yardErrorId").text("No Yards selected for order");
				valid = false;
			}else{
				$("#yardErrorId").text("");
			}
		}
		
		var comment = $("#comment").val();
		if(!comment){
			$("#commentErrorId").text("Please add a comment for this order");
			valid = false;
		}else{
			$("#commentErrorId").text("");
		}
		
		var deptId = $("#deptId").val();
		if(!deptId){
			$("#deptErrorId").text("Please select a department for this order");
			valid = false;
		}else{
			$("#deptErrorId").text("");
		}
		
		var requestBy = $("#requestBy").val();
		if(!requestBy){
			$("#requestByErrorId").text("Please add request by for this order");
			valid = false;
		}else{
			$("#requestByErrorId").text("");
		}
	
		if(!valid){
			return;
		}
		if(isYard == 'false'){			
			var orderCode = $("#orderType").val()+'-'+$("#group").val()+'-'+$("#deptId").val();
			$("#orderCodeHidden").val(orderCode);
		}else{
			$("#dueDateHidden").val(new Date());
		}
		$("#optionsForm").submit();
	});
	
	changeBreadCrumbs();
	
});