$(document).ready(function () {
    var centerCss = {
        'height': '200px',
        'vertical-align': 'middle',
        'line-height': '200px'
    };
    $("[name$='addToCartBtn']").each(function (index, obj) {
    	var addToCartBtnObj = $(this);
        $(obj).click(function () {
        	
        	 if(isItemCountOverLimit()){
     	    	return;
     	    }
            var rootUrl = $("#rootURLId").val();
            var type = $(this).prevAll().eq(0).val();
            //var quantity = $(this).prevAll().eq(1).val();
            var yardNum = $(this).prevAll().eq(2).val();
            var signId = $(this).prevAll().eq(3).val();
            var reqData = {"type": type, "yardNum": yardNum, "quantity": 1, "signId": signId};
            $.ajax({
                type: "post",
                async: false,
                url: rootUrl,
                data: reqData,
                success: function (data, textStatus) {
                	//Error happens when adding to cart and cart item over 250, 
                	if(data!="200"){
                		alert('Error happened when adding to cart!');
                		return;
                	}
                	
					add2cartEffect(addToCartBtnObj);
					setTimeout(function() {
						$("#cartItemsCount").text(Number($("#cartItemsCount").text()) + 1);
					}, 800);
                },
                error: function (data) {
                	alert('Error happened when adding to cart!');
                }
            });
        });
    });
});


function add2cartEffect(addToCartBtnObj) {
            var cart = $('.fancycart');
                    var imgtodrag = addToCartBtnObj.parent().parent().find("img").eq(0);
                    if (imgtodrag) {
                        var imgclone = imgtodrag.clone()
                            .offset({
                            top: imgtodrag.offset().top,
                            left: imgtodrag.offset().left
                        })
                            .css({
                            'opacity': '1',
                                'position': 'absolute',
                                'height': '100px',
                                'width': '100px',
                                'z-index': '100'
                        })
                            .appendTo($('body'))
                            .animate({
                            'top': cart.offset().top + 10,
                                'left': cart.offset().left + 10,
                                'width': 75,
                                'height': 75
                        }, 500, 'easeInExpo');
                        

                        imgclone.animate({
                            'width': 0,
                                'height': 0
                        }, function () {
                            $(this).detach()
                        });
                    }
}