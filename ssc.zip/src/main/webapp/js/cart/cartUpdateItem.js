$(function () {

    //text box only allows number and no allow to copy & paste 
    $.fn.numeral = function () {
        $(this).css("ime-mode", "disabled");
        this.bind("keypress", function (e) {
            var code = (e.keyCode ? e.keyCode : e.which);  //compatible with IE, FF      
            if (!$.browser.msie && (e.keyCode == 0x8))  //can use backspace under FF
            {
                return;
            }
            return code >= 48 && code <= 57;
        });
        this.bind("blur", function () {
            if (this.value.lastIndexOf(".") == (this.value.length - 1)) {
                this.value = this.value.substr(0, this.value.length - 1);
            } else if (isNaN(this.value)) {
                this.value = "";
            }
        });
        this.bind("paste", function () {
            var s = clipboardData.getData('text');
            if (!/\D/.test(s));
            value = s.replace(/^0*/, 1);
            return false;
        });
        this.bind("dragenter", function () {
            return false;
        });
        this.bind("keyup", function () {
            if (/(^0+)/.test(this.value)) {
                this.value = this.value.replace(/^0*/, 1);
            }
        });
    };

    $.fn.checkSkuQuantity = function () {
        this.blur(function() {
            checkSkuQuantity($(this));
        });
    };

    $.fn.colorSignQuantityChange = function () {

        this.bind("keypress", function () {
            var itemType = $(this).prevAll().eq(4).val();
            if (itemType == '3') {
                $(this).parent().next().next().children().eq(0).text("");
                $("#subTotalPrice").text("");
            }
        });
    };

});

var checkSkuQuantity = function (input) {
    var qty = Number(input.val());
    var minQty = Number(input.prevAll().eq(3).val());
    var incrementQty = Number(input.prevAll().eq(2).val());
    var maxQty = Number(input.prevAll().eq(1).val());
    if (maxQty == 0) {
        maxQty = -1;
    }
    var model = input.prevAll().eq(0).val();
    var focus = false;
    if (qty < minQty) {
        alert("Item " + model + " has a minimum order quantity of " + minQty + " , quantity increased to " + minQty
            + ".\n\nPlease press the Update Cart button");
        qty = minQty
        focus = true;
    } else if (qty % incrementQty != 0) {
        var newQuantity = Math.ceil((qty - minQty) / incrementQty) * incrementQty + (minQty * 1);
        if (maxQty > -1 && newQuantity > maxQty) {
            var newQuantity = Math.ceil((maxQty - incrementQty - minQty) / incrementQty) * incrementQty + (minQty * 1);
            qty = newQuantity;
            alert("Item " + model + " must be ordered in increments of " + incrementQty + " and has a maximum order limit of " + newQuantity
                + ", quantity changed to " + newQuantity + ".\n\nPlease press the Update Cart button");
        } else {
            alert("Item " + model + " must be ordered in increments of " + incrementQty + ", quantity increased to " + newQuantity
                + ".\n\nPlease press the Update Cart button");
            qty = newQuantity;
        }
        focus = true;
    }

    if (maxQty > -1 && qty > maxQty) {
        alert("Item " + model + " has a maximum order limit of " + maxQty + ", quantity changed to " + maxQty
            + ".\n\nPlease press the Update Cart button");
        qty = maxQty;
        focus = true;
    }

    input.val(qty);
    if (focus) {
        input.focus();
    }
};

function validate() {
    var valid = true;
    $("[name$='comment']").each(function () {
        var comment = $(this).val();
        if (comment && comment.length >= 120) {
            alert("The maxlength of comment is 120.");
            valid = false;
        }
    });
    return valid;
}

function editItem(btn) {
    // Edit is the same as remove
    removeItem(btn);
}

function removeItem(btn) {
    // We don't validate anything when removing the item
    $("#navigation").val($(btn).val());
    $("#cartForm").submit();
}

function changeBreadCrumbs() {
    var cartURL = $("#cartURLHidden").val();
    if ($.trim(cartURL) == '/cart/information') {
    	var o = {'crumbName': "Save Order", 'crumbLink': cartURL};
    	$('#content div').html("").append("<a href='" + urlPrefix + "'>Home</a>");
    	$.appendBreadCrumbs(o);
    	return;
    }    
    var o = {'crumbName': "Cart", 'crumbLink': cartURL};
    $('#content div').html("").append("<a href='" + urlPrefix + "'>Home</a>");
    $.appendBreadCrumbs(o);
}

function removeUnorderableItem() {
    var modelNums = "";
    $("[name$='removeItemDiv']").each(function (index, element) {
        modelNums = modelNums + $(this).children().eq(0).val() + ",";
    });
    if (modelNums) {
        //alert("These items are invalid and will be removed from the order:\n" + modelNums.substring(0, modelNums.length - 1));
    	alert("Invalid items will be removed from the order.");
        $("#removeItemsForm").submit();
    }
}

function removeNotOrderableItemBeforePlaceOrder() {
    var modelNums = "";
    $("[name$='notOrderableItemDiv']").each(function (index, element) {
        modelNums = modelNums + $(this).children().eq(0).val() + ",";
    });
    if (modelNums) {
        if (confirm("These items have reached their order limits and will be removed from the order:\n"
            + modelNums.substring(0, modelNums.length - 1))) {
            $("#removeNotOrderableItemsForm").submit();
        } else {
            return false;
        }
    } else {
        return true;
    }
}


function removeMissingDataItemBeforePlaceOrder() {
    var modelNums = "";
    $("[name$='missingDataItemDiv']").each(function (index, element) {
        modelNums = modelNums + $(this).children().eq(0).val() + ",";
    });
    if (modelNums) {
        if (confirm("These items have no required data for ordering and will be removed from the order:\n"
            + modelNums.substring(0, modelNums.length - 1))) {
            $("#removeMissingDataItemsForm").submit();
        } else {
            return false;
        }
    } else {
        return true;
    }
}

$(document).ready(function () {
    changeBreadCrumbs();
    removeUnorderableItem();

    $("[name$='quantity']").numeral();

    $("[name$='quantity']").checkSkuQuantity();

    $("[name$='quantity']").colorSignQuantityChange();


    $("#saveOrderBtn").click(function () {
        if (!validate()) {
            return false;
        }
        var hasUnavailableItem = $("#hasUnavailableItem").val();
        if ('true' == hasUnavailableItem) {
            alert("The red items are not available, please remove.");
            return;
        }
        $("#navigation").val("/cart/information");
        $("#cartForm").submit();
    });

    $("#placedOrderBtn").click(function () {
        if (validate()) {
            var hasUnavailableItem = $("#hasUnavailableItem").val();
            if ('true' == hasUnavailableItem) {
                alert("The red items are not available, please remove.");
                return;
            }
            $("#navigation").val("/cart/options");

            if (!removeNotOrderableItemBeforePlaceOrder()) {
                return;
            }
            if (!removeMissingDataItemBeforePlaceOrder()) {
                return;
            }

            $("#cartForm").submit();
        }
    });

    $("#continueShoppingBtn").click(function () {
        if (!validate()) {
            return false;
        }
        $("#navigation").val("continueShopping");
        $("#cartForm").submit();
    });

    $("#saveQuoteBtn").click(function () {
        if (!validate()) {
            return false;
        }
        $("#navigation").val("/cart");
        $("#cartForm").submit();
    });

    $("[name$='quantity']").each(function () {
        checkSkuQuantity($(this));
    });

});