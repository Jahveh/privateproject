$(document).ready(function() {

	/*$("button[name='orderFilter']" ).click(function() {			
		$("#orderHistory form" ).submit();
	});
	
	$("button[name='itemFilter']" ).click(function() {			
		$("#itemHistory form" ).submit();
	});*/
	
	var orderIdPattern = /\d{13}$/;
	var skuPattern = /\d{7}$/;

	$("button[name='orderFilter']").click(function() {
		var orderId = $('input[name=orderId]').val();
		// orderId = orderId.replace(/^\s+|\s+$/g,'');
		
		orderId = $.trim(orderId);

		if (orderId.length != 0) {
			if (!orderIdPattern.test(orderId) || orderId.length > 13) {
				alert("Order ID must be 13 digits");
				return;
			}
		}
		$("#orderHistory form").submit();
	});
	
	$('input[name=skuId]').keypress(function(e){
		if (e.keyCode == 13 || e.keyCode == 10){
            e.preventDefault();
            $("button[name='itemFilter']").click();
        } 	
    });
	
	$('input[name=orderId]').keypress(function(e){
		if (e.keyCode == 13 || e.keyCode == 10){
            e.preventDefault();
            $("button[name='orderFilter']").click();
        } 	
    });

	$("button[name='itemFilter']").click(function() {
		var skuCode = $('input[name=skuId]').val();		
		skuCode = $.trim(skuCode);
		if (skuCode.length != 0) {
			if (!skuPattern.test(skuCode) || skuCode.length > 7) {
				alert("Menards SKU must be 7 digits");
				return;
			}
		}
		$("#itemHistory form").submit();
	});

});