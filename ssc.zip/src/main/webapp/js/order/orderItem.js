$(document).ready(function() {
	
	$("#sortSelectForItemHistory" ).change(function() { 
		$("#itemHistory form" ).submit();
	});
	
	
});