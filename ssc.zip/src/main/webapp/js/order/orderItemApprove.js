$(document).ready(function() {
   
	//check all the approve radios and submit to approve
	$("button[name='Approve Page']" ).click(function() {		
		var r = confirm("Mark all items on this page as 'APPROVED' ?");
		if (r){
			$( "#approveForm table:eq(1) tr td" ).each(function(index, obj) {
				$("input[type='radio']:eq(0)",  obj).prop("checked", true);
			});
		}		
	});
	
	//Reset all the radios
	$("button[name='Reset']" ).click(function() {		
		var r = confirm("Are you sure you want to reset the form ?");		
		if (r){		
			$( "#approveForm table:eq(1) tr td" ).each(function(index, obj) {
				$("input[type='radio']",  obj).prop("checked", false);
				
				//remove the next deny comments
				var nextTr = $(obj).parent().next();
				if ($(nextTr).find( "td").prop('colspan') == 9){
					$(nextTr).remove();
				}
			});
			
			$( "#orderItemApproveFilter form select" ).each(function(index, select) {
				$(select).val('');
			});
			$( "#orderItemApproveFilter form select:eq(4) option:eq(0)" ).prop("selected", true);
		}
	});
	
	//When click the filter need to check the status of radios
	$("button[name='filter']" ).click(function() {	
		if ($("#approveForm table:eq(1) tr td input[type='radio']:checked").length > 0) {
			alert('Please Submit your Changes before Filtering?');
			return;
		}
		$("#orderItemApproveFilter form" ).submit();
	});
	
	//submit the current page to approve
	$("button[name='Submit Approvals']" ).click(function() {	
		if ($("#approveForm table:eq(1) tr td input[type='radio']:checked").length < 1) {
			alert('Could you please pick the items you want to proceed?');
			return;
		}
		
		var hasError = false;
		//Check the comments for deny
		$( "#approveForm table:eq(1) input[type='text']" ).each(function(index, obj) {			
			if (!$.trim($(obj).val())) {
				$(obj).next().show();
				hasError = true;
			}			
		});
		if (!hasError) {
			$("#approveForm").submit();
		}		
	});
	
	$( "#approveForm table:eq(1) input[type='text']" ).change(function() {	alert($(this).val());		
		if (!$.trim($(this).val())) {
			$(this).next().show();
		} else {
			$(this).next().hide();
		}			
	});	
	
	//Back to the order item page and approve more items
	$("button[name='moreItem']" ).click(function() {
		window.location.href = window.location.href.replace('approve', "list");		
	});
	
	//Sort the result of order item
	$("#sortSelect" ).change(function() { 		
		$("#orderItemApproveFilter form" ).submit();
	});
	
	$( "#approveForm table:eq(1) tr td" ).each(function(index, obj) {		
		$("input[type='radio']:eq(2)", obj).click(function() {
			var nextTr = $(this).parent().parent().next();	
			if ($(nextTr).find( "td").prop('colspan') == 9){
				$(nextTr).remove();
				$(this).prop('checked', false);
				return;
			}
			if ($(this).prop('checked')) {
				$("input[type='hidden']:eq(1)", $(this).parent()).val($(this).val());
				var name = $(this).prop('name').split('.')[0] + '.reason' ;
				$( '<tr><td colspan="9">Deny Reason:<input type="text" value="" name="' + name +'" size="120" maxlength="50"><span style=display:none class="alert alert-warning error-box inline"> Reason is required </span></td></tr>' ).insertAfter($(this).parent().parent());
				$("input[name='" + name + "']").change(function() {
					if (!$.trim($(this).val())) {
						$(this).next().show();
					} else {
						$(this).next().hide();
					}
				});	
			}
		});		
		$("input[type='radio']:lt(2)", obj).click(function() {
			if ($(this).prop('checked')) {	
				var value = $("input[type='hidden']:eq(1)", $(this).parent()).val();
				if ($.trim($(this).val()) == value) {
					$(this).prop('checked', false);
					$("input[type='hidden']:eq(1)", $(this).parent()).val('');
					return;
				}				
				var nextTr = $(this).parent().parent().next();	
				if ($(nextTr).find( "td").prop('colspan') == 9){
					$(nextTr).remove();
				}
				$("input[type='hidden']:eq(1)", $(this).parent()).val($(this).val());
			}		
		});
	});
	
	
	$('button[name=printPackingSkip]').click(function(){		
		var css_fontSize = "0.8em";
		var css_fontFamily = "Verdana, Arial, Helvetica, sans-serif";
		var myWindow = window.open('', '_blank', "width=800,height=600", "status:no;help:no;resizable:yes;");
		var popupDoc = myWindow.document;
		var containerDiv = popupDoc.createElement('div');
		containerDiv.style.fontSize = css_fontSize;
		containerDiv.style.fontFamily = css_fontFamily;
		popupDoc.body.appendChild(containerDiv);
		var parentTables = $("#orderItemApproveContent").children('table');
		for (var i = 0; i < parentTables.length; i ++) {
			//store number title
			var storeNumberDiv = popupDoc.createElement('div');
			storeNumberDiv.style.fontWeight="bold";
			storeNumberDiv.style.fontSize = css_fontSize;
			storeNumberDiv.style.fontFamily = css_fontFamily;
			var storeNumber = $($(parentTables[i]).find('TD')[0]).html();
			var storeName = $(parentTables[i]).find("input[type=hidden]:first").val();
			if (storeName == '') {
				$(storeNumberDiv).html(storeNumber);	
			} else {
				$(storeNumberDiv).html(storeNumber + '&nbsp;&nbsp;(' + storeName + ')');
			}
			
			containerDiv.appendChild(storeNumberDiv);
			
			//create table for each store
			var table = popupDoc.createElement('table');
			$(table).html("<tr><td align='center' style='border:1px solid black;'>Item ID</td><td align='center' style='border:1px solid black;'>Description</td> <td align='center' style='border:1px solid black;'>Qty</td> <td align='center' style='border:1px solid black;'>Order ID</td> <td align='center' style='border:1px solid black;'>SKU</td> <td align='center' style='border:1px solid black;'>Status</td> <td align='center' style='border:1px solid black;'>Status Date</td> <td></td></tr>");
			
			table.style.fontSize = css_fontSize;
			table.style.fontFamily = css_fontFamily;
			table.style.width = "100%";
			table.style.border = "1px solid black";
			table.style.borderCollapse = 'collapse';
			
			var parentTRs = $(parentTables[i]).find('tr');
			for (var j = 2; j < parentTRs.length - 1; j += 2 ) {
				//data row
				var newTR = popupDoc.createElement('tr');
				var allTDs = $(parentTRs[j]).find('td');
				for (var k = 0; k < allTDs.length; k++) {
					var newTD = popupDoc.createElement('td');
					if (k != 1) {
						newTD.align = 'center';
					}
					newTD.style.border = '1px solid black';
					$(newTD).html( $(allTDs[k]).html() );
					newTR.appendChild(newTD);
				}
				$(table).children("tbody")[0].appendChild(newTR);
				
				//comment row
				var commentTR = popupDoc.createElement('tr');
				var commentLabelTD = popupDoc.createElement('td');
				commentLabelTD.innerText = "Comment";
				commentLabelTD.align = "center";
				var commentValueTD = popupDoc.createElement('td');
				commentValueTD.style.border = "1px solid black";
				commentValueTD.colSpan = '7';
				$(commentValueTD).html($($(parentTRs[j+1]).find('td')[1]).html());
				commentTR.appendChild(commentLabelTD);
				commentTR.appendChild(commentValueTD);
				$(table).children("tbody")[0].appendChild(commentTR);
			}

			containerDiv.appendChild(table);
			if (i != parentTables.length - 1) {
				containerDiv.appendChild(popupDoc.createElement("br"));
				var pageBreakDiv = popupDoc.createElement("div");
				pageBreakDiv.style.pageBreakAfter = 'always';
				containerDiv.appendChild(pageBreakDiv);
			}
		}

		myWindow.print();
		myWindow.close();
	});
	
	$('#approveForm button[name=Print]').click(function(){	
		var url = $('#approveForm input[name=printUrl]').val();
		var parameter = $("#orderItemApproveFilter form" ).serialize();
		var currentPage = $('#approveForm input[name=currentPage]').val() + '&';
		window.open(url  + '?page=' + currentPage + parameter, "","width=800,height=600", "status:no;help:no;resizable:yes;");		
	});
});