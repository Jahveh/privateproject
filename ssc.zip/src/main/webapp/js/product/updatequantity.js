$(document).ready(function() {
    // append bread crumbs
    var productId = $("#productIdHidden").val();
    var productURL = $("#productURLHidden").val();
    var o = {'crumbName':productId,'crumbLink':productURL};
    $.appendBreadCrumbs(o);

	$("#updateBtn").click(function(){		
		var quantity = parseInt($("#quantityId").val());
		if (isNaN(quantity)) {
			alert("You entered an invalid quantity.");
			$("#quantityId").select();
			$("#quantityId").focus();
			return false;
		}
		else if (quantity < 0) {
			alert("You cannot enter a negative quantity.");
			$("#quantityId").select();
			$("#quantityId").focus();
			return false;
		}
		$("#updateQuantityForm").submit();
	});
});