$(function(){
	
	$.fn.tab = function() {
		
		$(this).click(function(){
			var oldActiveTab = $(this).siblings(".active").find("a").attr("href");
			$(this).siblings(".active").removeClass("active");
			$("#"+oldActiveTab.slice(1)).css("display", "none");
			
			var newActiveTab = $(this).find("a").attr("href");
			$(this).toggleClass("active");
			$("#"+newActiveTab.slice(1)).css("display", "");
		});
		
	};
	
});

$(document).ready(function() {
        	var productId = $("#productIdHidden").val();
        	var productURL = $("#productURLHidden").val();
        	var type = $("#signType").val();
        	/*if ($.trim(type) && $.trim(type) != 'Y') {
        		$('#content div').html("<a href='" + urlPrefix + "'>Home</a>");		
        	}        	
        	
			if ($.trim(type) == 'S' || $.trim(type) == 'N') {
        		var breadCrumb = $("#breadCrumb").val();
        		var array = breadCrumb.split(','); 
        		for(var i = array.length - 1; i > 0;) {
        			$.appendBreadCrumbs({'crumbName':array[i-1],'crumbLink':array[i]});
        			i = i - 2;
        		}
        	}
			var o = {'crumbName':productId,'crumbLink':productURL};
			$.appendBreadCrumbs(o);
			*/
			$('#ssczoomer').jqzoom({
				zoomType: 'reverse',
				lens:true,
				preloadImages: true,
				alwaysOn:false
			});
			
		$("#tabs").children().each(function(){
			$(this).tab();
		});	
		
		$("#skuSelectedId").change(function(){
			$("form[name='skuForm']").submit();
		});
		
		$("#add2CartBtn").click(function(){
    	    if(isItemCountOverLimit()){
    	    	return;
    	    }
			$("#skuFormId").submit();
		});
		
});