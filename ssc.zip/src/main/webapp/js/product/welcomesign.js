$(document).ready(function () {
    var productId = $("#productIdHidden").val();
    var productURL = $("#productURLHidden").val();
    var o = {'crumbName': productId, 'crumbLink': productURL};
    $.appendBreadCrumbs(o);
});