function runProgram(signId, env){//Opens the sigma application to BO users
	try{
		programPath = "C:\\PROGRA~1\\Menards\\SIGMA\\SIGMA.exe /host=" + env + " /SignID=" + signId;

		oShell = new ActiveXObject("WScript.Shell");
		oShell.Run(programPath ,1 ,false);
	}
	catch(e){
		alert("The Sigma Application was not found on this computer. Please contact IS to have the application installed.");
	}
	
//	alert("The Sigma Application was not found on this computer. Please contact IS to have the application installed.");
}