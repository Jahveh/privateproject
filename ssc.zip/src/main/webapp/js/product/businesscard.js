$(document).ready(function () {
    $("#confirmBtn").click(function () {
        var comment = $("#commentId").val();
        if (!comment) {
            $("#confirmForm").attr("action", $("#cartAction").val());
        }
        $("#confirmForm").submit();
    });

    var productId = $("#productIdHidden").val();
    var productURL = $("#productURLHidden").val();
    var o = {'crumbName': productId, 'crumbLink': productURL};
    $.appendBreadCrumbs(o);

});