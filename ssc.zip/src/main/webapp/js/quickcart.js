$(function(){
	$('#sku').focus();

	$('#sku').bind("keyup keypress", function(e) {
		var code = e.keyCode || e.which; 
		if (code  == 13) {   
			$('#quantity').focus();
			$('#quantity').select();
			e.preventDefault();
			return false;
		}
	});

	 $("#addToCartButton").click(function() {
    	 if(isItemCountOverLimit()){
  	    	return;
  	    }
    	$("#addToCartButton").attr("disabled", "disabled");
        $('#quickCartForm').submit();
    });

});