$(document).ready(function() {
	$('input[name=updateInventory]').click(function(){
		//var quantityArray = document.monthly_inventory_update.elements["skuQuantity"];
		var quantityArray = $("input[name=skuQuantity]");
		//alert(quantityArray.length);
		
		for( var i = 0; i < quantityArray.length; i++ ) {
			var quantity = parseInt($(quantityArray[i]).val());
			if (isNaN(quantity)) {
				alert("You entered an invalid quantity.");
				quantityArray[i].select();
				quantityArray[i].focus();
				return false;
			}
			else if (quantity < 0) {
				alert("You cannot enter a negative quantity.");
				quantityArray[i].select();
				quantityArray[i].focus();
				return false;
			}
		}
		
		//showPleaseWait();		
		$("form[name=monthly_inventory_update]" ).submit();
		//return true;
	});	
	
	
	
	$('input[name=print_inventory_list]').click(function(){		
		window.open('../inventory/print',"","status:no;help:no;resizable:yes;");		
	});
	
	
	$('input[name=back_to_home]').click(function(){		
		document.location.href='../';		
	});
	
	
	
	
	
});
