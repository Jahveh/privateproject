$(document).ready(function() {	
    //Make sure the current input is legal
	$("#search_button").click(function() {		
		var text = $.trim($("input[name='query']").val());	
		if ($.trim(text).length < 3) {
			alert('A minimum of 3 characters is required for the search.');
			return false;
		}
		var type = $.trim($("select[name='type']").val());
		if (text.length > 40 && (type == 'sign' || type == 'supplies')) {
			alert('A Maximum of 40 Characters is Allowed for the Search.');
			return;
		}
		if (text.length > 8 && type == 'saleSign') {
			alert('A Maximum of 8 Characters is Allowed for a Sale Sign Search.');
			return;
		}
		if ($("#yardNumber").length && $.trim($("#yardNumber").val()) == '' && type == 'saleSign') {
			alert('Yard is required!');
			return;
		}
		
		if (!text.match("^[a-zA-Z0-9\-_\.\%\#\\\"/\\\s\']{3,}$")) {
			alert('Error with text entered. Please use only: letters numbers \" - _ .  % # and spaces!');
			return;
		}
		
		var yardNumber = $("#yardNumber").val(); 
		if (type == 'saleSign' && yardNumber && !yardNumber.match("^[0-9]{4}$")) {
			alert('Error with yard umber entered. Please use only: 4 numbers!');
			return;
		}
		$("form[name='headerSearchForm']").submit();
	});
	
	$( "#searchSkuResultTable tr:gt(0)" ).each(function(index, obj) {		
		$(obj).click(function() {			
			if ($(obj).hasClass('warningMessage')) {
				return;
			}	
			var text = $.trim($("input[name='query']").val());
			var type = $.trim($("select[name='type']").val());
			window.location.href = $("input[type=hidden]:eq(0)", obj).val() + '&type=' + type + '&query=' + text;
		});		
	});
	
	$('.search_input').keypress(function(e){
		if (e.keyCode == 13 || e.keyCode == 10){
            e.preventDefault();
            $("#search_button").click();
            return false;
        } 
    });
	
	//submit the current page to add to cart
	$(".searchAddToCartBtn").click(function() {
		var selectedItems =$("#searchSignAndAddToCart input[name^='signItems'][type='checkbox']:checked").length;
		
		if(selectedItems>=1 && (selectedItems + Number($("#cartItemsCount").text())) > 250){
			alert("The cart items have reached the maximum limit 250.");
			return;
		}
		
		if (selectedItems < 1) {
			alert('Please pick the items that you want to add to the cart');
			return;
		}
		$("#searchSignAndAddToCart").submit();
	});	
	
	//When clicking the row go to sign detail page
	$( "#searchSignResultTable tr:gt(0)" ).each(function(index, obj) {		
		$(obj).click(function() {
			
			var text = $.trim($("input[name='query']").val());
			var type = $.trim($("select[name='type']").val());
			window.location.href = $("input[type=hidden]:eq(0)", obj).val() + '&type=' + type + '&query=' + text;
		});	
	});
	
	//When mouse over the row to show hand
	$("#searchSignResultTable tr:gt(0)" ).each(function(index, obj) {		
		$(obj).mouseover(function() {
			$(obj).css('cursor','pointer');
			$(obj).css('background','#ADD8E6');
		});		
	});
	
	//When mouse out the row to show hand
	$("#searchSignResultTable tr:gt(0)" ).each(function(index, obj) {		
		$(obj).mouseout(function() {
			$(obj).css('background','');
		});		
	});
	
	//When mouse over the row to show hand
	$("#searchSkuResultTable tr:gt(0)" ).each(function(index, obj) {		
		$(obj).mouseover(function() {
			$(obj).css('cursor','pointer');
			$(obj).css('background','#ADD8E6');
		});		
	});
	
	//When mouse out the row to show hand
	$("#searchSkuResultTable tr:gt(0)" ).each(function(index, obj) {		
		$(obj).mouseout(function() {
			$(obj).css('background','');
		});		
	});
	
	//Stop the event propagation and deal with the hidden value 
	$("#searchSignResultTable input[type='checkbox']" ).click(function(event) {
		
		var selectedItems =$("#searchSignAndAddToCart input[name^='signItems'][type='checkbox']:checked").length;
		
		if((selectedItems+Number($("#cartItemsCount").text()))>250){
			alert("The cart items have reached the maximum limit 250.");
			$(this).prop('checked',false);
			return;
		}
		
		if ($(this).prop('checked')) {
			var yard = $(this).next();	
			var type = $(this).next().next();
			var criteriaType = $(this).next().next().next();			
			var promoNbr = $(this).next().next().next().next();			
			var name = $(this).prop('name').replace('signId', 'yardNum');
			var typeName = $(this).prop('name').replace('signId', 'type');
			
			var promoNbrName = $(this).prop('name').replace('signId', 'promoNumber');
			var criteriaTypeName = $(this).prop('name').replace('signId', 'criteriaType');
			$(yard).prop('name', name);
			$(type).prop('name', typeName);
			if (promoNbr) {
				$(promoNbr).prop('name', promoNbrName);				
			}
			$(criteriaType).prop('name', criteriaTypeName);

		} else {
			$(this).next().prop('name', '');
			$(this).next().next().prop('name', '');
			$(this).next().next().next().prop('name', '');
			var promoNbr = $(this).next().next().next().next();
			if (promoNbr) {				
				$(promoNbr).prop('name', '');	
			}
		}
		
		if (event.stopPropagation){
			event.stopPropagation();
		} else {
			event.cancelBubble = true;
		}
	});
	
	//Stop the event propagation when clicking the last td
	$( ".signCheckbox" ).click(function(event) {
		if (event.stopPropagation){
			event.stopPropagation();
		} else {
			event.cancelBubble = true;
		}
	});
	
	$("select[name='type']").click(function() {
		var type = 	$("select[name='type']").val();
		if ($.trim(type) == 'saleSign' && $(".yards-td").children().length > 0) {
			$(".yards-td").show();
		} else {
			$(".yards-td").hide();
		}
	});	
	$("select[name='type']").click();
	
	//Show all the order items
	$(function() {
		if (!$(".homeclass").length) {
			return;
		}		
		$.getJSON('orderitem/totalCount', function(data, b, XR) {
			var text = $("h3 a[href$='/orderitem/list']").text();
			$("h3 a[href$='/orderitem/list']").text(text + '(' +  data.count + ')');
  	    }).error(function(data) { 
        });
	});	
	
	//Add search functionality to breadcrumb
	$(function() {
		if ($(".searchTable").length){
			$('#content div').html("<a href='" + urlPrefix + "'>Home</a>&nbsp;&gt;&nbsp;<a href='javascript:void(0)'>Search</a>");		
		}
	});
});