package com.menards.autoloader.integration;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.integration.gateway.EmailGateway;
import com.menards.autoloader.service.EmailUseCase;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestEmailGateway extends BaseTest {
    @Autowired
    private EmailGateway emailGateway;

    @Test
    public void testSendMail() throws InterruptedException {
        emailGateway.sendMail(1, EmailUseCase.NEW_MCR.name(), "", "");
    }

}
