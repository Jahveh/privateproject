package com.menards.autoloader.integration;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.integration.gateway.McrGateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestMcrGateway extends BaseTest {
    @Autowired
    private McrGateway mcrGateway;

    @Test
    public void testReactivate() {
        Map map = new HashMap<String, String>();
        map.put("1", "1");
        mcrGateway.reactivate(1);
        System.out.println("back from McrGateway Invocation!!!!!!!!!!!!!!!!!!");
    }

}
