package com.menards.autoloader.integration;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.integration.gateway.JobGateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestJobGateway extends BaseTest {
    @Autowired
    private JobGateway jobGateway;

    @Test
    public void testRunExcelToStageJob() {
        String filePath = "D:/project/eclipse-workspace/auto-loader-web/file_inbound/MY MN FIXTURES x Update.xls";
        jobGateway.runExcelToStageJob(filePath, 5);
    }
}
