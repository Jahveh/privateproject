package com.menards.autoloader.xmlbean;

import com.menards.autoloader.utils.validation.parser.XmlParser;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.testng.annotations.Test;

import ucAutoloader.menards.com.ImportFileAttribute;
import ucAutoloader.menards.com.ItemField;
import ucAutoloader.menards.com.SheetGroup;
import ucAutoloader.menards.com.ValidationRoot;

import java.io.IOException;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestXmlBean {

    @Test
    public void testParseXmlRule() throws IOException {
        Resource resource = new ClassPathResource("/validation/uc_validation_rules.xml");
        XmlParser xmlValidationRules = new XmlParser(resource.getFile());
        ValidationRoot validationRoot = xmlValidationRules.getValidationRoot();
        SheetGroup[] sheetGroups = validationRoot.getDataFormat().getSheetArray();
        for (SheetGroup sheetGroup : sheetGroups) {
            ItemField[] itemFields = sheetGroup.getMainItemFieldArray();
            for (ItemField itemField : itemFields) {
                ImportFileAttribute[] importFileAttributes = itemField.getImportFileArray();
                for (ImportFileAttribute importFileAttribute : importFileAttributes) {
                    System.out.println("[excel sheet] " + sheetGroup.getName() + " >> [excel column header] " + itemField.getName() + " >> [MENRARD_VENDOR column] " + importFileAttribute.getAttribute());
                }
            }
        }
    }

}
