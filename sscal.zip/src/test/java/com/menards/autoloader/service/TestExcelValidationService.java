package com.menards.autoloader.service;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.domain.mcr.ExcelValidationHistory;
import com.menards.autoloader.domain.mcr.ExcelValidationStatus;
import com.menards.autoloader.service.ExcelValidationService;
import com.menards.autoloader.utils.FileChecksumUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.FileCopyUtils;
import org.testng.annotations.Test;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestExcelValidationService extends BaseTest {

    @Autowired
    private ExcelValidationService excelValidationService;

    @Test
    public void testAddExcelValidationHistory() {
        ExcelValidationHistory excelValidationHistory = new ExcelValidationHistory();
        excelValidationHistory.setReactivateValidationStatus(ExcelValidationStatus.NOT_VALIDATED);
        excelValidationHistory.setValidationTimestamp(new Date());
        excelValidationHistory.setExcelValidationStatus(ExcelValidationStatus.NOT_VALIDATED);
        excelValidationHistory.setVendor("test_vendor_3");
        excelValidationHistory.setExcelPath("D:/project/eclipse-workspace/auto-loader-web/file_inbound/MY MN FIXTURES x Update.xls");
        excelValidationHistory.setExcelFileChecksum(FileChecksumUtils.getChecksum(new File("D:/project/eclipse-workspace/auto-loader-web/file_inbound/MY MN FIXTURES x Update.xls")));
        excelValidationHistory.setExcelFile(new File("D:/project/eclipse-workspace/auto-loader-web/file_inbound/MY MN FIXTURES x Update.xls"));
        excelValidationHistory.setLog("test log");
        excelValidationHistory.setMoveResource("NO");
        excelValidationService.addExcelValidationHistory(excelValidationHistory);
    }

    @Test
    public void testGetExcelValidationLog() {
        String log = excelValidationService.getExcelValidationHistoryLog(1397459873L);
        System.out.println("log context >>> " + log);
    }

    @Test
    public void testGetExcelContent() throws IOException {
        byte[] byteContent = excelValidationService.getExcelFileContent(1397459873L);
        File tempFile = new File("testFile.xls");
        FileCopyUtils.copy(new BufferedInputStream(new ByteArrayInputStream(byteContent)),
                new FileOutputStream(tempFile));
    }

    @Test
    public void testValidateExcel() {
        File file = new File("D:/project/eclipse-workspace/auto-loader-web/file_inbound/MY MN FIXTURES x Update.xls");
        List<String> messages = excelValidationService.validateProductFamily(file);
        for (String message : messages) {
            System.out.println();
        }
    }

    @Test
    public void testLastExcelValidationHistoriesByMcrId() {
        ExcelValidationHistory excelValidationHistory = excelValidationService.getLastExcelValidationHistoriesByMcrId(5);
        System.out.println(excelValidationHistory);
    }
}
