package com.menards.autoloader.service;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.service.PreProductionService;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestPreProductionService extends BaseTest {

    @Autowired
    private PreProductionService preProductionService;

    @Test
    public void testInitPreProductionTables() throws Exception {
        preProductionService.initPreProductionTables();
    }

}
