package com.menards.autoloader.service;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.service.JobService;

import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobParametersNotFoundException;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.Test;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestJobService extends BaseTest {
    @Autowired(required = true)
    @Qualifier("autoLoaderJobService")
    private JobService jobService;

    @Test
    public void testRunJob() throws JobInstanceAlreadyCompleteException, JobExecutionAlreadyRunningException, JobParametersInvalidException, JobRestartException, JobParametersNotFoundException, NoSuchJobException {
        String filePath = "D:/project/eclipse-workspace/auto-loader-web/file_inbound/MY MN FIXTURES x Update.xls";
        jobService.runExcelToStageJob(filePath, 5);
    }

}
