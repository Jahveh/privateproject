package com.menards.autoloader.service;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.domain.mcr.User;
import com.menards.autoloader.service.SecureUserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.io.IOException;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestSecureUserService extends BaseTest {
    @Autowired
    private SecureUserService secureUserService;

    @Test
    public void testEnrichSecureUser() {
        User user = new User();
        user.setEmail("ahorn@menard-inc.com");
        secureUserService.enrichSecureUser(user);
        System.out.println(user.getDepartment());
        System.out.println(user.getPhone());
    }

    @Test
    public void testIsAdminUser() throws IOException {
        boolean isAdminUser = secureUserService.isAdminUser("AWOLD");
    }
}
