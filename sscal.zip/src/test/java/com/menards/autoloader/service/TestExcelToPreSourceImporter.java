package com.menards.autoloader.service;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.service.ExcelToSourceTableImporter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.sql.SQLException;

/**
 * <p>TestExcelToPreSourceImporter</p>
 * <p>A test class for testing {@link ExcelToSourceTableImporter}.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class TestExcelToPreSourceImporter extends BaseTest {

    @Autowired
    private ExcelToSourceTableImporter importer;

    /**
     * test data import
     * @throws IOException an IOException
     * @throws SQLException an SQLException
     * @throws ClassNotFoundException a ClassNotFoundException
     */
    @Test
    public void testImport() throws IOException, SQLException, ClassNotFoundException {
        String file = "C:\\Users\\frank.peng\\Desktop\\duratrel.xls";
        importer.importData(file, 3);
    }

}
