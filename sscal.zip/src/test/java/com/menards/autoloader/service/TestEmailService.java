package com.menards.autoloader.service;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.service.EmailService;
import com.menards.autoloader.service.EmailUseCase;

import freemarker.template.TemplateException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.Test;

import java.io.IOException;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestEmailService extends BaseTest {
    @Autowired
    private EmailService emailService;

    @Test
    public void testSendMail() {
        String from = "noreply@menard-inc.com";
        String[] to = new String[]{"noreply@menard-inc.com"};
        String subject = "testing email";
        String body = "this is a testing email body.";
        emailService.sendMail(from, to, subject, body);
        System.out.println("finished testing sending email.");
    }

    @Test
    public void testBuildEmailBody() throws IOException, TemplateException {
        System.out.println(emailService.buildEmailBody(1, EmailUseCase.NEW_MCR));
    }

}
