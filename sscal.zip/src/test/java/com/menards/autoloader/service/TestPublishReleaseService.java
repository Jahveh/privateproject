package com.menards.autoloader.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.domain.mcr.StageApprovalInfo;
import com.menards.autoloader.service.PublishReleaseService;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author eason.yu
 * @version 1.0
 */
public class TestPublishReleaseService extends BaseTest {
    @Autowired
    private PublishReleaseService publishReleaseService;

    @Test
    public void testStageRelease() {
    	StageApprovalInfo info = new StageApprovalInfo();
    	int mcrId = 4;
    	info.setMcrId(mcrId);
    	info.setApprovalName("test name");
    	info.setApprovalEmail("test@email.com");
    	info.setDate(new Date());
    	publishReleaseService.stageApproved(info);
    }

}
