package com.menards.autoloader.service;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.domain.mcr.MCR;
import com.menards.autoloader.domain.mcr.Priority;
import com.menards.autoloader.domain.mcr.User;
import com.menards.autoloader.service.McrService;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestMcrService extends BaseTest {
    @Autowired
    private McrService mcrService;

    @Test
    public void testSaveMcr() {
        MCR mcr = buildMcr();
        mcrService.createMcr(mcr);
    }

    @Test
    public void testApproveMcr() throws IOException {
        Map<String, String> msgMap = mcrService.approveMcr(5, "frank.peng@bleum.com", "test comment");
        System.out.println("Message Map >>>>>>>> " + msgMap);
        try {
            Thread.sleep(60000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testReactivateMcr() {
        Map<String, String> msgMap = mcrService.reactivateMcr(5);
        System.out.println(msgMap);
    }

    private MCR buildMcr() {
        MCR mcr = new MCR();
        List<User> approvers = new ArrayList<User>();
        approvers.add(buildUser("frank peng", "frank.peng@bleum.com"));
        approvers.add(buildUser("peng fan", "xmpengfan@gmail.com"));
        mcr.setApprovers(approvers);
        mcr.setBusinessImpact("dummy business impact text");
        mcr.setChangeExplanation("dummy change explanation text");
        mcr.setChangeReason("dummy change reason");
        mcr.setDateRequired(new Date());
        mcr.setVendor("test_vendor_2");
        Priority priority = new Priority();
        priority.setId(1);
        priority.setName("Low");
        mcr.setPriority(priority);
        mcr.setSubmitter(buildUser("pf_", "pf_@outlook.com"));
        mcr.setTitle("dummy MCR title");
        return mcr;
    }

    private User buildUser(String userName, String userEmail) {
        User user = new User();
        user.setName(userName);
        user.setEmail(userEmail);
        return user;
    }
}
