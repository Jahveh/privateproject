package com.menards.autoloader.service;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.service.SourceTableToTargetTableImporter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.Test;

/**
 * <p>TestSourceToTargetImporter</p>
 * <p>A test class for testing {@link SourceTableToTargetTableImporter}.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class TestSourceToTargetImporter extends BaseTest {

    @Autowired
    @Qualifier("sourceTableToTargetTableImporter")
    private SourceTableToTargetTableImporter importer;

    /**
     * test service class {@link SourceTableToTargetTableImporter}
     */
    @Test
    public void testImport() {
        importer.importDataForMcr(3);
    }

}
