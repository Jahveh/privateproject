package com.menards.autoloader.utils;

import com.menards.autoloader.domain.CategoryTree;
import com.menards.autoloader.utils.CategoryTreeCalculationUtils;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * <p>TestCategoryTreeCalculationUtils</p>
 * <p>A test class for testing {@link CategoryTreeCalculationUtils}.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class TestCategoryTreeCalculationUtils {

    private Set<String> productFamilies = new HashSet<String>();

    /**
     * the UT setup method.
     */
    @BeforeClass
    public void setup() {
        productFamilies.add("Fixtures_Upright");
        productFamilies.add("Fixtures_BaseShoe");
        productFamilies.add("Fixtures_BaseShoeEndCover");
        productFamilies.add("Fixtures_Shelf");
        productFamilies.add("Fixtures_KickPlate");
        productFamilies.add("Fixtures_Pegboard");
        productFamilies.add("DeptFixtures_Hardware_HandToolsSlidersandSpinners");
        productFamilies.add("Fixtures_Slatwall");
        productFamilies.add("Fixtures_Hardboard");
        productFamilies.add("Fixtures_Rack");
        productFamilies.add("Fixtures_EndMerchandiser");
        productFamilies.add("DeptFixtures_Wallcoverings_CardDisplay");
        productFamilies.add("Fixtures_Spanner");
        productFamilies.add("Fixtures_CrossBar");
        productFamilies.add("MerchSolutions_Bracket");
        productFamilies.add("DeptFixtures_Plumb_Misc");
        productFamilies.add("DeptFixtures_Hardware_Misc");
        productFamilies.add("Fixtures_WideSpan");
        productFamilies.add("Fixtures_Hypermaxi");
        productFamilies.add("Fixtures_Basket");
        productFamilies.add("Fixtures_Divider");
        productFamilies.add("Fixtures_MDivider");
        productFamilies.add("Fixtures_DividerBar");
        productFamilies.add("Fixtures_ArmDivider");
        productFamilies.add("DeptFixtures_Floor_Misc");
        productFamilies.add("Fixtures_VDivider");
        productFamilies.add("DeptFixtures_Wallcoverings_Misc");
        productFamilies.add("Fixtures_ExtendAPeg");
        productFamilies.add("GenStoreSup_MiscStoreSupply");
        productFamilies.add("DeptFixtures_PetandFood_WideSpan");
        productFamilies.add("DeptFixtures_Millwork_Misc");
        productFamilies.add("DeptFixtures_BM_Misc");
    }

    /**
     * test CategoryTreeCalculationUtils.buildCategoryTree
     */
    @Test
    public void testBuildCategoryTree() {
        CategoryTree tree = CategoryTreeCalculationUtils.buildCategoryTree(productFamilies);
        Assert.assertTrue(tree != null);
    }

    /**
     * test CategoryTreeCalculationUtils.buildCategoryDictionaryByPath
     */
    @Test
    public void testBuildCategoryDictionaryByPath() {
        CategoryTree tree = CategoryTreeCalculationUtils.buildCategoryTree(productFamilies);
        Map<String, CategoryTree> map =  CategoryTreeCalculationUtils.buildCategoryDictionaryByPath(tree);
        Set<String> keys = map.keySet();
        for (String originalPath : productFamilies) {
            String realPath = "/" + (originalPath.replaceAll("_", "/"));
            Assert.assertTrue(keys.contains(realPath), originalPath + "should be built into the tree dictionary");
        }
    }

}
