package com.menards.autoloader.utils;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.testng.annotations.Test;

import com.menards.autoloader.utils.ExcelUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestExcelUtils {
    @Test
    public void testGetVendor() throws IOException {
        String excelPath = "D:/project/eclipse-workspace/auto-loader-web/file_inbound/MY MN FIXTURES x Update.xls";
        File file = new File(excelPath);
        Workbook workbook = new HSSFWorkbook(new FileInputStream(file));
        System.out.println(ExcelUtils.getVendor(workbook));

    }

}
