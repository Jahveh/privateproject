package com.menards.autoloader.utils;

import org.testng.annotations.Test;

import com.menards.autoloader.utils.WebUtils;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestWebUtils {
    @Test
    public void testGetCatalogNameFromFilePath() {
        String catalogName = WebUtils.getCatalogName("\\\\host\\UCAutoLoader_Data\\SOS_Data\\Literature\\vendor\\MY MN FIXTURES x Update.xls");
        String catalogName2 = WebUtils.getCatalogName("\\\\host\\UCAutoLoader_Data\\SOS_Data\\StoreSuppliesCatalog\\vendor\\MY MN FIXTURES x Update.xls");
        System.out.println(catalogName);
        System.out.println(catalogName2);
    }

}
