package com.menards.autoloader.utils;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.testng.annotations.Test;

import com.menards.autoloader.utils.SqlScriptParser;

import java.io.FileReader;
import java.io.Reader;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestSqlScriptParser {

    @Test
    public void testParser() throws Exception {
        Resource sqlScript = new ClassPathResource("/sqlScript/create-pre-pro-tables.sql");
        Reader fileReader = new FileReader(sqlScript.getFile());
        String[] sqls = SqlScriptParser.parse(fileReader);
        for (String sql : sqls) {
            System.out.println(sql);
        }


    }

}
