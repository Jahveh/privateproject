package com.menards.autoloader.utils;

import junit.framework.Assert;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.testng.annotations.Test;

import com.menards.autoloader.utils.FileChecksumUtils;

import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestFileChecksumUtils {
    @Test
    public void testFileChecksum_Get2TimesChecksumFor1File() throws IOException, NoSuchAlgorithmException {
//        Resource r = new ClassPathResource("/com/menard/autoloader/utils/TestFileChecksumUtils.class");
//        File rf = r.getFile();
//        System.out.println(">>>>>" + rf.getCanonicalPath());
        Resource resource = new ClassPathResource("/com/menard/autoloader/utils/TestFileChecksumUtils.class");
        File thisJavaFile = resource.getFile();
        String thisFileChecksum = FileChecksumUtils.getChecksum(thisJavaFile);
        Resource resource2 = new ClassPathResource("/com/menard/autoloader/utils/TestFileChecksumUtils.class");
        File thisJavaFile2 = resource2.getFile();
        String thisFileChecksum2 = FileChecksumUtils.getChecksum(thisJavaFile2);
        System.out.println("TestFileChecksumUtils >> " + thisFileChecksum);
        System.out.println("TestFileChecksumUtils >> " + thisFileChecksum2);
        Assert.assertTrue(thisFileChecksum.equals(thisFileChecksum2));
    }

    @Test
    public void testFileChecksum_Get1TimeChecksumFor2File() throws IOException, NoSuchAlgorithmException {
        Resource resource = new ClassPathResource("/com/menard/autoloader/utils/TestFileChecksumUtils.class");
        File thisJavaFile = resource.getFile();
        String thisFileChecksum = FileChecksumUtils.getChecksum(thisJavaFile);
        Resource resource2 = new ClassPathResource("/com/menard/autoloader/utils/TestCategoryTreeCalculationUtils.class");
        File thisJavaFile2 = resource2.getFile();
        String thisFileChecksum2 = FileChecksumUtils.getChecksum(thisJavaFile2);
        System.out.println("TestFileChecksumUtils >> " + thisFileChecksum);
        System.out.println("TestCategoryTreeCalculationUtils >> " + thisFileChecksum2);
        Assert.assertTrue(!thisFileChecksum.equals(thisFileChecksum2));
    }
}
