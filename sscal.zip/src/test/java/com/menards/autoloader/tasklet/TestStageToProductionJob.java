package com.menards.autoloader.tasklet;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.utils.BatchUtils;

import junit.framework.Assert;

import org.springframework.batch.admin.service.JobService;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobParametersNotFoundException;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>TestSourceToStageJob</p>
 * <p>A test class for testing sourceToStageJob.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class TestStageToProductionJob extends BaseTest {
    @Autowired
    @Qualifier("autoLoaderJobService")
    private com.menards.autoloader.service.JobService alJobService;

    @Autowired
    private JobService jobService;

    /**
     * setup method.
     */
    @BeforeClass
    public void initTest() {
        this.setJobName("stage-to-production-job");
    }

    /**
     * test sourceToStageJob
     * @throws JobParametersInvalidException a JobParametersInvalidException
     * @throws JobExecutionAlreadyRunningException a JobExecutionAlreadyRunningException
     * @throws JobRestartException a JobRestartException
     * @throws JobInstanceAlreadyCompleteException a JobInstanceAlreadyCompleteException
     * @throws NoSuchJobException a NoSuchJobException
     * @throws JobParametersNotFoundException a JobParametersNotFoundException
     * @throws InterruptedException an InterruptedException
     */
    @Test
    public void testStageToProductionTasklet() throws
            JobParametersInvalidException,
            JobExecutionAlreadyRunningException,
            JobRestartException,
            JobInstanceAlreadyCompleteException,
            NoSuchJobException,
            JobParametersNotFoundException,
            InterruptedException {

        Job job = getJobRegistry().getJob(getJobName());
        JobParameters jobParameters = BatchUtils.getNextJobParameters(job, getJobExplorer());
        Map<String, Object> newParam = new HashMap<String, Object>();
        newParam.put("MCR_ID", "5");
        jobParameters = BatchUtils.buildJobParameters(jobParameters, newParam);
        JobExecution jobExecution = jobService.launch(getJobName(), jobParameters);
        Assert.assertTrue(jobExecution.getExitStatus().getExitCode().equals("COMPLETED"));
    }

    @Test
    public void testProductionReleaseJob() throws JobInstanceAlreadyCompleteException, JobExecutionAlreadyRunningException, JobParametersInvalidException, JobRestartException, JobParametersNotFoundException, NoSuchJobException {
        alJobService.runProductionReleaseJob();
    }

    public JobService getJobService() {
        return jobService;
    }

    public void setJobService(JobService jobService) {
        this.jobService = jobService;
    }
}
