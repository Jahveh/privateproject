package com.menards.autoloader.dao;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.dao.mcr.UserDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.io.IOException;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestUserDao extends BaseTest {
    @Autowired
    private UserDao userDao;

    @Test
    public void getAllUsers() throws IOException {
        userDao.getAllUsers();
    }
}
