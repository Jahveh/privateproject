package com.menards.autoloader.dao;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.dao.target.MenardVendorDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestMenardVendorDao extends BaseTest {
    @Autowired
    @Qualifier("productionJdbcTemplate")
    JdbcTemplate jdbcTemplate;

    @Test
    public void testNewMenardVendorDao() {
        MenardVendorDao menardVendorDao = new MenardVendorDao(jdbcTemplate);
        Assert.isTrue(menardVendorDao != null);
        String vendorFullName = menardVendorDao.getVendorFullNameByVendor("sos_fixtures");
        System.out.println(vendorFullName);
    }

    @Test
    public void testGetAllValidationRules() {
        MenardVendorDao menardVendorDao = new MenardVendorDao(jdbcTemplate);
        List<String> list = menardVendorDao.getRequiredSheetNames();
        Map<String, List<String>> map = menardVendorDao.getRequiredSheetFields();
        Map<String, List<String>> map2 = menardVendorDao.getUniqueSheetFields();
        Map<String, Map<String, String>> map3 = menardVendorDao.getFieldFormatRegexMap();
        Map<String, List<String>> map4 = menardVendorDao.getDecimalSheetFields();
        System.out.println(map4.size());

    }

}
