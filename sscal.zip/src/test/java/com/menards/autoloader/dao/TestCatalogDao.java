package com.menards.autoloader.dao;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.dao.mcr.CatalogDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestCatalogDao extends BaseTest {
    @Autowired
    private CatalogDao catalogDao;

    @Test
    public void testGetAllCatalogs() throws IOException {
        List<String> allCatalogs = catalogDao.getAllCatalogs();
        for (String catalog :  allCatalogs) {
            System.out.println("catalog >> " + catalog);
        }
    }
}
