package com.menards.autoloader.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.dao.mcr.McrStageApprovalDao;
import com.menards.autoloader.domain.mcr.StageApprovalInfo;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author eason.yu
 * @version 1.0
 */
public class TestStageApprovalDao extends BaseTest {
    @Autowired
    private McrStageApprovalDao mcrStageApprovalDao;

    @Test
    public void testGetStageApprovalByMcrId() {
    	int mcrId = 1;
    	StageApprovalInfo info = mcrStageApprovalDao.getStageApprovalByMcrId(mcrId);
    	System.out.println(info.getMcrId());
    }
}
