package com.menards.autoloader.dao;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.dao.mcr.McrApprovalHistoryDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Set;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestMcrApprovalHistoryDao extends BaseTest {
    @Autowired
    private McrApprovalHistoryDao mcrApprovalHistoryDao;

    @Test
    public void testGetAllApprovalStatusByMcrId() {
        Set<String> statusSet = mcrApprovalHistoryDao.getAllApprovalStatusByMcrId(2);
        for(String status : statusSet) {
            System.out.println("mcr[" + 2 + "]approval status >>>>>> " + status);
        }
    }
}
