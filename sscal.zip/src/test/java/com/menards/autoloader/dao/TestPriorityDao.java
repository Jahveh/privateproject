package com.menards.autoloader.dao;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.dao.mcr.PriorityDao;
import com.menards.autoloader.domain.mcr.Priority;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestPriorityDao extends BaseTest {
    @Autowired
    private PriorityDao priorityDao;
    @Test
    public void testGetAllPriorities() throws IOException {
        List<Priority> allPriorities = priorityDao.getAllPriorities();
        for (Priority priority : allPriorities) {
            System.out.println("priority id >> " + priority.getId() + ", name >> " + priority.getName());
        }
    }
}
