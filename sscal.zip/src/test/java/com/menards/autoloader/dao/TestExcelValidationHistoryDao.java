package com.menards.autoloader.dao;

import com.menards.autoloader.BaseTest;
import com.menards.autoloader.dao.mcr.ExcelValidationHistoryDao;
import com.menards.autoloader.domain.mcr.ExcelValidationHistory;
import com.menards.autoloader.domain.mcr.ExcelValidationStatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class TestExcelValidationHistoryDao extends BaseTest {
    @Autowired
    private ExcelValidationHistoryDao excelValidationHistoryDao;

    @Test
    public void testGetLatestValidationStatusByVendor() {
        ExcelValidationStatus status = excelValidationHistoryDao.getLatestValidationStatusByVendor("TEST_VENDOR");
        System.out.println(status);
    }

    @Test
    public void testGetAllExcelValidationHistoryByVendor() {
        List<ExcelValidationHistory> list = excelValidationHistoryDao.getAllExcelValidationHistoryByVendor("test_vendor_3");
        System.out.println(list.size());
    }

    @Test
    public void testGetLastExcelValidationHistoriesByMcrId() {
        List<ExcelValidationHistory> list = excelValidationHistoryDao.getLastExcelValidationHistoriesByMcrId(8);
        System.out.println(list.size());
    }
}
