String.prototype.endWith = function(pattern){
    var pattern = pattern + '$'
    var regex = new RegExp(pattern);
    var result = regex.test(this);
    return result;
}
$(function(){
    (function(){
        var appContextPath = $('#appContextPathHidden').val();
        var currentPath = document.location.href.split(appContextPath)[1];
        var highLightMenuItem = function(menuUrl){
            $('#primary-left a').each(function(idx, elem){
                var menuHref = $(elem).attr('href');
                if(menuHref.endWith(menuUrl)){
                    elem.style.backgroundImage = 'url(' + appContextPath + '/resources/web/img/primary-item-background.png)';
                    elem.style.color='white';
                    elem.style.fontWeight='bold';
                }
            });
        }
        if (currentPath == '/'
            || currentPath == ''
            || currentPath.indexOf('/file') >= 0){
            highLightMenuItem('/file');
        } else if (currentPath == '/mcr' || currentPath.indexOf("/mcr?") >= 0) {
            highLightMenuItem('/mcr');
        } else if (currentPath.indexOf('mcrApproval') >= 0) {
            highLightMenuItem('/mcrApproval');
        } else if (currentPath.indexOf('mcrReactivate') >= 0) {
            highLightMenuItem('/mcrReactivate');
        } else if (currentPath.indexOf('stageApproval') >= 0) {
            highLightMenuItem('/stageApproval');
        } else if (currentPath.indexOf('productionRelease') >= 0) {
            highLightMenuItem('/productionRelease');
        } else if (currentPath.indexOf('jobs') >= 0 ) {
            if (currentPath.indexOf('executions') >= 0 ) {
                highLightMenuItem('/jobs/executions');
            } else {
                highLightMenuItem('/jobs');
            }
        }

    })();
});

