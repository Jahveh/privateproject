package com.menards.autoloader.tasklet;

import com.menards.autoloader.service.ExcelToSourceTableImporter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.util.Assert;

/**
 * Created by frank.peng on 1/9/14.
 */
public class ExcelToSourceTableTasklet implements Tasklet {

    private static final Logger LOG = LoggerFactory.getLogger(ExcelToSourceTableTasklet.class);

    private ExcelToSourceTableImporter importer;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        String filePath = (String) chunkContext.getStepContext().getJobParameters().get("EXCEL_PATH");
        String mcrId = (String) chunkContext.getStepContext().getJobParameters().get("MCR_ID");
        Assert.isTrue(mcrId != null && mcrId.matches("^[0-9]+$"), "MCR_ID should be a validate integer number.");
        Assert.isTrue(filePath.endsWith("xls"), "The input file path [" + filePath + "] should be an Excel file path.");
        importer.importData(filePath, Integer.valueOf(mcrId));
        return RepeatStatus.FINISHED;
    }

    public void setImporter(ExcelToSourceTableImporter importer) {
        this.importer = importer;
    }
}
