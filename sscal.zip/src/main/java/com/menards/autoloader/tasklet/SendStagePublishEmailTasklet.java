package com.menards.autoloader.tasklet;

import com.menards.autoloader.integration.gateway.EmailGateway;
import com.menards.autoloader.service.EmailUseCase;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class SendStagePublishEmailTasklet implements Tasklet {

    @Autowired
    private EmailGateway emailGateway;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        String mcrId = (String) chunkContext.getStepContext().getJobParameters().get("MCR_ID");
        Assert.isTrue(mcrId != null && mcrId.matches("^[0-9]+$"), "MCR_ID should be a validate integer number.");
        emailGateway.sendMail(
                Integer.valueOf(mcrId),
                EmailUseCase.MCR_STAGE_PUBLISH.name(),
                "",
                ""
        );

        return RepeatStatus.FINISHED;
    }
}
