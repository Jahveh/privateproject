package com.menards.autoloader.tasklet;

import com.menards.autoloader.service.McrService;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class UpdateMcrAfterProductionReleasedTasklet implements Tasklet {
    @Autowired
    private McrService mcrService;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        mcrService.updateMCRAfterProductionReleased();
        return RepeatStatus.FINISHED;
    }
}
