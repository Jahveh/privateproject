package com.menards.autoloader.tasklet;

import com.menards.autoloader.dao.mcr.ExcelValidationHistoryDao;
import com.menards.autoloader.dao.mcr.McrDao;
import com.menards.autoloader.domain.mcr.ExcelValidationHistory;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class UpdateMcrAfterPublishToProductionTasklet implements Tasklet {

    @Autowired
    private McrDao mcrDao;

    @Autowired
    private ExcelValidationHistoryDao excelValidationHistoryDao;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        String mcrId = (String) chunkContext.getStepContext().getJobParameters().get("MCR_ID");
        Assert.isTrue(mcrId != null && mcrId.matches("^[0-9]+$"), "MCR_ID should be a validate integer number.");
        mcrDao.mcrStagePublishedToProduction(Integer.parseInt(mcrId));
        List<ExcelValidationHistory> excelValidationHistoryList =
                excelValidationHistoryDao.getLastExcelValidationHistoriesByMcrId(Integer.parseInt(mcrId));
        Assert.isTrue(excelValidationHistoryList.size() > 0 , "Excel validation history is not found for MCR " + mcrId);
        ExcelValidationHistory excelValidationHistory = excelValidationHistoryList.get(0);
        mcrDao.setExcelPathForMcr(excelValidationHistory.getExcelPath(), Integer.parseInt(mcrId));
        return RepeatStatus.FINISHED;
    }
}
