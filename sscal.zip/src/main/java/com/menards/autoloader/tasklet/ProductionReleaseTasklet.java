package com.menards.autoloader.tasklet;

import com.menards.autoloader.service.PreProductionService;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

/**
 * Created by frank.peng on 1/27/14.
 */
public class ProductionReleaseTasklet implements Tasklet {
	private PreProductionService preProductionService;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        preProductionService.productionRelease();
        return RepeatStatus.FINISHED;
    }

    public PreProductionService getPreProductionService() {
        return preProductionService;
    }

    public void setPreProductionService(PreProductionService preProductionService) {
        this.preProductionService = preProductionService;
    }
}
