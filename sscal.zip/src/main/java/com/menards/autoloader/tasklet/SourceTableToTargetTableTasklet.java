package com.menards.autoloader.tasklet;

import com.menards.autoloader.service.SourceTableToTargetTableImporter;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

/**
 * Created by frank.peng on 1/27/14.
 */
public class SourceTableToTargetTableTasklet implements Tasklet, InitializingBean {
    private SourceTableToTargetTableImporter sourceTableToTargetTableImporter;
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        String mcrId = (String) chunkContext.getStepContext().getJobParameters().get("MCR_ID");
        Assert.isTrue(mcrId != null && mcrId.matches("^[0-9]+$"), "MCR_ID should be a validate integer number.");
        sourceTableToTargetTableImporter.importDataForMcr(Integer.valueOf(mcrId));
        return RepeatStatus.FINISHED;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.isTrue(this.sourceTableToTargetTableImporter != null, "sourceToTargetImporter must be set.");
    }

    public void setSourceToTargetImporter(SourceTableToTargetTableImporter sourceToTargetImporter) {
        this.sourceTableToTargetTableImporter = sourceToTargetImporter;
    }
}
