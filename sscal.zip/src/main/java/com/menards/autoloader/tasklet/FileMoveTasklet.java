package com.menards.autoloader.tasklet;

import com.menards.autoloader.dao.factory.TargetEnvironment;
import com.menards.autoloader.domain.mcr.ExcelValidationHistory;
import com.menards.autoloader.service.ExcelValidationService;
import com.menards.autoloader.service.FileMoveService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class FileMoveTasklet implements Tasklet {
    private static final Logger LOG = LoggerFactory.getLogger(FileMoveTasklet.class);
    @Autowired
    private ExcelValidationService excelValidationService;

    private String targetRootFolder;

    private FileMoveService fileMoveService;

    private TargetEnvironment targetEnvironmentEnum;

    /**
     *
     * @param fileMoveService file move service
     * @param targetRootFolder target root folder
     * @param targetEnvironment target environment
     */
    public FileMoveTasklet(FileMoveService fileMoveService,
                           String targetRootFolder,
                           String targetEnvironment) {
        this.fileMoveService = fileMoveService;
        this.targetRootFolder = targetRootFolder;
        this.targetEnvironmentEnum = TargetEnvironment.valueOf(targetEnvironment);
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        String mcrId = (String) chunkContext.getStepContext().getJobParameters().get("MCR_ID");
        Assert.isTrue(mcrId != null && mcrId.matches("^[0-9]+$"), "MCR_ID should be a validate integer number.");
        if (shouldMoveResource(mcrId)) {
            fileMoveService.moveFileToTargetForMcr(Integer.valueOf(mcrId), this.targetEnvironmentEnum, targetRootFolder);
        }
        return RepeatStatus.FINISHED;
    }

    /**
     *
     * @param mcrId mcr id
     * @return a flag showing whether it needs to move resource
     */
    private boolean shouldMoveResource(String mcrId) {
        ExcelValidationHistory excelValidationHistory =
                excelValidationService.getLastExcelValidationHistoriesByMcrId(Integer.valueOf(mcrId));
        if ("YES".equals(excelValidationHistory.getMoveResource())) {
            LOG.info("\"Resource Folder Path\" was provided on Validation Page.. start to move media files.");
            return true;
        }
        LOG.info("\"Resource Folder Path\" was not provided on Validation Page.. skip moving media files.");
        return false;
    }

    public void setFileMoveService(FileMoveService fileMoveService) {
        this.fileMoveService = fileMoveService;
    }

}
