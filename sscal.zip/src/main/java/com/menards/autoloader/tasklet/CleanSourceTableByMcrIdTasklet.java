package com.menards.autoloader.tasklet;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.Assert;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class CleanSourceTableByMcrIdTasklet implements Tasklet {
    @Autowired
    @Qualifier("stageJdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        String mcrId = (String) chunkContext.getStepContext().getJobParameters().get("MCR_ID");
        Assert.isTrue(mcrId != null && mcrId.matches("^[0-9]+$"), "MCR_ID should be a validate integer number.");
        jdbcTemplate.update("delete from AL_SOURCE_BLC_CATEGORY_PRODUCT_XREF where mcr_id = " + mcrId);
        jdbcTemplate.update("delete from AL_SOURCE_BLC_PRODUCT where mcr_id = " + mcrId);
        jdbcTemplate.update("delete from AL_SOURCE_BLC_PRODUCT_ATTRIBUTE where mcr_id = " + mcrId);
        jdbcTemplate.update("delete from AL_SOURCE_BLC_PRODUCT_SKU_XREF where mcr_id = " + mcrId);
        jdbcTemplate.update("delete from AL_SOURCE_BLC_SKU where mcr_id = " + mcrId);
        jdbcTemplate.update("delete from AL_SOURCE_BLC_SKU_ATTRIBUTE where mcr_id = " + mcrId);
        jdbcTemplate.update("delete from AL_SOURCE_MENARD_PRODUCT where mcr_id = " + mcrId);
        jdbcTemplate.update("delete from AL_SOURCE_MENARD_PRODUCT_OPTION where mcr_id = " + mcrId);
        jdbcTemplate.update("delete from AL_SOURCE_MENARD_SKU where mcr_id = " + mcrId);
        return RepeatStatus.FINISHED;
    }
}
