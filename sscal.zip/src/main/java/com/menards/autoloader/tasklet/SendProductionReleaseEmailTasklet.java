package com.menards.autoloader.tasklet;

import com.menards.autoloader.domain.mcr.MCR;
import com.menards.autoloader.integration.gateway.EmailGateway;
import com.menards.autoloader.service.EmailUseCase;
import com.menards.autoloader.service.McrService;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class SendProductionReleaseEmailTasklet implements Tasklet {
    @Autowired
    private McrService mcrService;

    @Autowired
    private EmailGateway emailGateway;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        List<MCR> mcrList = mcrService.getAllCandidateMcrForProductionRelease();
        for (MCR mcr : mcrList) {
            emailGateway.sendMail(mcr.getId(), EmailUseCase.MCR_PRODUCTION_RELEASE.name(), "", "");
        }
        return RepeatStatus.FINISHED;
    }
}
