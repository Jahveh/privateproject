package com.menards.autoloader.security;

import com.menards.mymenards.business.delegate.SecurityDelegate;

/**
 * <p>MenardSecurityDelegate</p>
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author leo.yang
 * @version 1.0
 */
public class MenardSecurityDelegate extends SecurityDelegate {
	public void setSds(MenardConcreteMySQLSecurityDAO sds) {		
		super.sds = sds;
	}
}