package com.menards.autoloader.domain;

/**
 * <p>BlcProduct</p>
 * <p>A domain object for representing data from BLC_PRODUCT table.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class BlcProduct {
    private String productId;
    private String url;
    private Long defaultCategoryId;
    private DataMergeActions action;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Long getDefaultCategoryId() {
        return defaultCategoryId;
    }

    public void setDefaultCategoryId(Long defaultCategoryId) {
        this.defaultCategoryId = defaultCategoryId;
    }

    public DataMergeActions getAction() {
        return action;
    }

    public void setAction(DataMergeActions action) {
        this.action = action;
    }
}
