package com.menards.autoloader.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>ValidationInboundMsg</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class ValidationInboundMsg {
    private List<String> validationExcels = new ArrayList<String>();

    public List<String> getValidationExcels() {
        return validationExcels;
    }

    public void setValidationExcels(List<String> validationExcels) {
        this.validationExcels = validationExcels;
    }
}
