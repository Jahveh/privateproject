package com.menards.autoloader.domain;

/**
 * <p>BlcSku</p>
 * <p>A domain object for representing data from BLC_SKU table.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class BlcSku {
    private String skuId;
    private String defaultProductId;
    private DataMergeActions action;
    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getDefaultProductId() {
        return defaultProductId;
    }

    public void setDefaultProductId(String defaultProductId) {
        this.defaultProductId = defaultProductId;
    }

    public DataMergeActions getAction() {
        return action;
    }

    public void setAction(DataMergeActions action) {
        this.action = action;
    }
}
