package com.menards.autoloader.domain.mcr;

import java.io.File;
import java.util.Date;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class ExcelValidationHistory {
    private String excelPath;
    private String resourceFolderPath;
    private String moveResource;
    private String vendor;
    private String vendorFullName;
    private ExcelValidationStatus excelValidationStatus;
    private ExcelValidationStatus reactivateValidationStatus;
    private Date validationTimestamp;
    private Long validationTimeStampNumber;
    private String excelFileChecksum;
    private String log;
    private File excelFile;

    public String getExcelPath() {
        return excelPath;
    }

    public void setExcelPath(String excelPath) {
        this.excelPath = excelPath;
    }

    public ExcelValidationStatus getExcelValidationStatus() {
        return excelValidationStatus;
    }

    public void setExcelValidationStatus(ExcelValidationStatus excelValidationStatus) {
        this.excelValidationStatus = excelValidationStatus;
    }

    public Date getValidationTimestamp() {
        return validationTimestamp;
    }

    public void setValidationTimestamp(Date validationTimestamp) {
        this.validationTimestamp = validationTimestamp;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }

    public ExcelValidationStatus getReactivateValidationStatus() {
        return reactivateValidationStatus;
    }

    public void setReactivateValidationStatus(ExcelValidationStatus reactivateValidationStatus) {
        this.reactivateValidationStatus = reactivateValidationStatus;
    }

    public String getResourceFolderPath() {
        return resourceFolderPath;
    }

    public void setResourceFolderPath(String resourceFolderPath) {
        this.resourceFolderPath = resourceFolderPath;
    }

    public String getMoveResource() {
        return moveResource;
    }

    public void setMoveResource(String moveResource) {
        this.moveResource = moveResource;
    }

    public String getVendorFullName() {
        return vendorFullName;
    }

    public void setVendorFullName(String vendorFullName) {
        this.vendorFullName = vendorFullName;
    }

    public Long getValidationTimeStampNumber() {
        return validationTimeStampNumber;
    }

    public void setValidationTimeStampNumber(Long validationTimeStampNumber) {
        this.validationTimeStampNumber = validationTimeStampNumber;
    }

    public String getExcelFileChecksum() {
        return excelFileChecksum;
    }

    public void setExcelFileChecksum(String excelFileChecksum) {
        this.excelFileChecksum = excelFileChecksum;
    }

    public File getExcelFile() {
        return excelFile;
    }

    public void setExcelFile(File excelFile) {
        this.excelFile = excelFile;
    }
}
