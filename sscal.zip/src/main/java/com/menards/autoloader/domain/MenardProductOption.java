package com.menards.autoloader.domain;

/**
 * <p>MenardProductOption</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class MenardProductOption {
    private String baseProductId;
    private String optionProductId;
    private String mandatory;

    public String getBaseProductId() {
        return baseProductId;
    }

    public void setBaseProductId(String baseProductId) {
        this.baseProductId = baseProductId;
    }

    public String getOptionProductId() {
        return optionProductId;
    }

    public void setOptionProductId(String optionProductId) {
        this.optionProductId = optionProductId;
    }

    public String getMandatory() {
        return mandatory;
    }

    public void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }
}
