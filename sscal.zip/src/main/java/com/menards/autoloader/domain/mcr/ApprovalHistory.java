package com.menards.autoloader.domain.mcr;

import java.util.Date;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class ApprovalHistory {
    private int id;
    private int mcrId;
    private User approvalUser;
    private McrStatus status;
    private String comment;
    private Date updateTimeStamp;

    public User getApprovalUser() {
        return approvalUser;
    }

    public void setApprovalUser(User approvalUser) {
        this.approvalUser = approvalUser;
    }

    public McrStatus getStatus() {
        return status;
    }

    public void setStatus(McrStatus status) {
        this.status = status;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMcrId() {
        return mcrId;
    }

    public void setMcrId(int mcrId) {
        this.mcrId = mcrId;
    }

    public Date getUpdateTimeStamp() {
        return updateTimeStamp;
    }

    public void setUpdateTimeStamp(Date updateTimeStamp) {
        this.updateTimeStamp = updateTimeStamp;
    }
}
