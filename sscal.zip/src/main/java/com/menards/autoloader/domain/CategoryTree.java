package com.menards.autoloader.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>CategoryTree</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class CategoryTree {
    private Long parentCategoryId;
    private Long categoryId;
    private String categoryName;
    private String pathToThisNode;
    private CategoryTree parentCategory;
    private boolean isNewCategoryForImport;
    private List<CategoryTree> subCategories = new ArrayList<CategoryTree>();
    private String urlKey;

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public List<CategoryTree> getSubCategories() {
        return subCategories;
    }

    public void setSubCategories(List<CategoryTree> subCategories) {
        this.subCategories = subCategories;
    }

    public Long getParentCategoryId() {
        return parentCategoryId;
    }

    public void setParentCategoryId(Long parentCategoryId) {
        this.parentCategoryId = parentCategoryId;
    }

    public String getPathToThisNode() {
        return pathToThisNode;
    }

    public void setPathToThisNode(String pathToThisNode) {
        this.pathToThisNode = pathToThisNode;
    }

    public CategoryTree getParentCategory() {
        return parentCategory;
    }

    public void setParentCategory(CategoryTree parentCategory) {
        this.parentCategory = parentCategory;
    }

    public boolean isNewCategoryForImport() {
        return isNewCategoryForImport;
    }

    public void setNewCategoryForImport(boolean isNewCategoryForImport) {
        this.isNewCategoryForImport = isNewCategoryForImport;
    }

    public String getUrlKey() {
        return urlKey;
    }

    public void setUrlKey(String urlKey) {
        this.urlKey = urlKey;
    }

}
