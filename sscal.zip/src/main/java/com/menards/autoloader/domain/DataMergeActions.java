package com.menards.autoloader.domain;

/**
 * <p>DataMergeActions</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public enum DataMergeActions {
    INSERT, UPDATE, DELETE
}
