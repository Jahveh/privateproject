package com.menards.autoloader.domain.mcr;

import java.util.Date;
import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class MCR {
    private int id;
    private String title;
    private Priority priority;
    private Date dateRequired;
    private User submitter;
    private String changeReason;
    private String changeExplanation;
    private String businessImpact;
    private List<User> approvers;
    private List<ApprovalHistory> approvalHistories;
    private String vendor;
    private boolean isAllApproved;
    private boolean isStageApproved;
    private boolean isStagePublishedToProduction;
    private boolean isProductionReleased;
    private String comment;
    private String additionalNotes;
    private String excelPath;
    private ExcelValidationHistory lastExcelValidationHistory;
    private String mcrStatus;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public Date getDateRequired() {
        return dateRequired;
    }

    public void setDateRequired(Date dateRequired) {
        this.dateRequired = dateRequired;
    }

    public User getSubmitter() {
        return submitter;
    }

    public void setSubmitter(User submitter) {
        this.submitter = submitter;
    }

    public List<ApprovalHistory> getApprovalHistories() {
        return approvalHistories;
    }

    public void setApprovalHistories(List<ApprovalHistory> approvalHistories) {
        this.approvalHistories = approvalHistories;
    }

    public String getChangeReason() {
        return changeReason;
    }

    public void setChangeReason(String changeReason) {
        this.changeReason = changeReason;
    }

    public String getChangeExplanation() {
        return changeExplanation;
    }

    public void setChangeExplanation(String changeExplanation) {
        this.changeExplanation = changeExplanation;
    }

    public String getBusinessImpact() {
        return businessImpact;
    }

    public void setBusinessImpact(String businessImpact) {
        this.businessImpact = businessImpact;
    }

    public List<User> getApprovers() {
        return approvers;
    }

    public void setApprovers(List<User> approvers) {
        this.approvers = approvers;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public boolean isAllApproved() {
        return isAllApproved;
    }

    public void setAllApproved(boolean isAllApproved) {
        this.isAllApproved = isAllApproved;
    }

    public boolean isStageApproved() {
        return isStageApproved;
    }

    public void setStageApproved(boolean isStageApproved) {
        this.isStageApproved = isStageApproved;
    }

    public boolean isStagePublishedToProduction() {
        return isStagePublishedToProduction;
    }

    public void setStagePublishedToProduction(boolean isStagePublishedToProduction) {
        this.isStagePublishedToProduction = isStagePublishedToProduction;
    }

    public boolean isProductionReleased() {
        return isProductionReleased;
    }

    public void setProductionReleased(boolean isProductionReleased) {
        this.isProductionReleased = isProductionReleased;
    }

    public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getAdditionalNotes() {
		return additionalNotes;
	}

	public void setAdditionalNotes(String additionalNotes) {
		this.additionalNotes = additionalNotes;
	}

    public String getExcelPath() {
        return excelPath;
    }

    public void setExcelPath(String excelPath) {
        this.excelPath = excelPath;
    }

    public ExcelValidationHistory getLastExcelValidationHistory() {
        return lastExcelValidationHistory;
    }

    public void setLastExcelValidationHistory(ExcelValidationHistory lastExcelValidationHistory) {
        this.lastExcelValidationHistory = lastExcelValidationHistory;
    }

    public String getMcrStatus() {
        return mcrStatus;
    }

    public void setMcrStatus(String mcrStatus) {
        this.mcrStatus = mcrStatus;
    }
}
