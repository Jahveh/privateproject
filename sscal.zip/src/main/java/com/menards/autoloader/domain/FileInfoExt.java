package com.menards.autoloader.domain;

/**
 * <p>FileInfoExt</p>
 * <p>A POJO extended from {@Link org.springframework.batch.admin.service.FileInfo}
 * with lastModifyDate added.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class FileInfoExt extends org.springframework.batch.admin.service.FileInfo {
    private String lastModifyDate;

    /**
     * A contructor method that accept the file path.
     * @param path file path.
     */
    public FileInfoExt(String path) {
        super(path);
    }

    /**
     * A constructor method that accepts path, timestamp and islocal
     * @param path the file path
     * @param timestamp the time timestamp at which the file is uploaded.
     * @param local whether a local file a remote file.
     */
    public FileInfoExt(String path, String timestamp, boolean local) {
        super(path, timestamp, local);
    }

    public String getLastModifyDate() {
        return lastModifyDate;
    }

    public void setLastModifyDate(String lastModifyDate) {
        this.lastModifyDate = lastModifyDate;
    }
}
