package com.menards.autoloader.domain.mcr;

import java.util.Date;

/**
 * <p>StageApproval</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author eason.yu
 * @version 1.0
 */
public class StageApprovalInfo {

	private int mcrId;
	private String approvalName;
	private String approvalEmail;
	private Date date;
	public int getMcrId() {
		return mcrId;
	}
	public void setMcrId(int mcrId) {
		this.mcrId = mcrId;
	}
	public String getApprovalName() {
		return approvalName;
	}
	public void setApprovalName(String approvalName) {
		this.approvalName = approvalName;
	}
	public String getApprovalEmail() {
		return approvalEmail;
	}
	public void setApprovalEmail(String approvalEmail) {
		this.approvalEmail = approvalEmail;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	
	
}
