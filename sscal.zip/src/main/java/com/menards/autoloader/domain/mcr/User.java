package com.menards.autoloader.domain.mcr;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class User {
    private int id;
    private String name;
    private String email;
    private String phone;
    private String department;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	@Override
    public boolean equals(Object user) {
        if (user.getClass() != User.class) {
            return false;
        }
        User u = (User) user;
        if (u.getName().equals(this.getName()) && u.getEmail().equals(this.getEmail())) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return this.getEmail().hashCode() + this.getName().hashCode();
    }

}
