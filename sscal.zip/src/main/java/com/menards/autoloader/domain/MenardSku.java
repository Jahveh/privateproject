package com.menards.autoloader.domain;

/**
 * <p>MenardSku</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class MenardSku {
    private String skuId;
    private String skuCode;
    private String menardSku;

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getSkuCode() {
        return skuCode;
    }

    public void setSkuCode(String skuCode) {
        this.skuCode = skuCode;
    }

    public String getMenardSku() {
        return menardSku;
    }

    public void setMenardSku(String menardSku) {
        this.menardSku = menardSku;
    }
}
