package com.menards.autoloader.domain.mcr;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public enum ExcelValidationStatus {
    NOT_VALIDATED("NOT_YET_VALIDATED"),
    PASSED("PASSED"),
    FAILED("FAILED"),
    FILE_NOT_EXIST("FILE_NOT_EXIST"),
    MCR_CLOSED("MCR_CLOSED");

    /**
     * private constructor method
     * @param name excel validation status name
     */
    private ExcelValidationStatus(String name) {
        this.name = name;
    }

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
