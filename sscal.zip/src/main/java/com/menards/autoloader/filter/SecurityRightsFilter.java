package com.menards.autoloader.filter;

import com.menards.autoloader.security.MenardSecurityDelegate;
import com.menards.autoloader.service.SecureUserService;
import com.menards.mymenards.integration.vo.SecureUser;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.io.IOException;

public class SecurityRightsFilter implements Filter {

    public static final Log LOG = LogFactory.getLog(SecurityRightsFilter.class);

    public static final String SECURE_USER = "SecureUser";
    private static final int INDEX = 3;

    private MenardSecurityDelegate securityDelegate;

    private SecureUserService secureUserService;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {
        HttpSession session = ((HttpServletRequest) request).getSession();
        SecureUser secureUser = (SecureUser) session.getAttribute(SECURE_USER);
        if (secureUser == null) {
            String userName = getUserNameFromContext((HttpServletRequest) request);
            secureUser = secureUserService.getSecureUser(userName);
            session.setAttribute(SECURE_USER, secureUser);
            session.setAttribute("isAdminUser", secureUserService.isAdminUser(userName));
        }
        chain.doFilter(request, response);
    }

    /**
     * Determines the user name from the "UN:" registry value,
     * @param request request
     * @return String
     */
    private String getUserNameFromContext(HttpServletRequest request) {
        String userName = null;
        String userAgent = request.getHeader("User-Agent");
        if (userAgent == null) {
            return userName;
        }
        try {
            int unIndex = userAgent.lastIndexOf("UN:");
            if (unIndex != -1) {
                userName = userAgent.substring(unIndex + INDEX, userAgent.length() - 1);
                int delimiterIndex = userName.indexOf(';');
                if (delimiterIndex != -1) {
                    userName = userName.substring(0, delimiterIndex);
                }
            }
        } catch (Exception e) {
            LOG.error(e.getMessage());
        }
        return userName;
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        ApplicationContext applicationContext = WebApplicationContextUtils
                .getWebApplicationContext(filterConfig.getServletContext());
        this.secureUserService = applicationContext.getBean("secureUserService", SecureUserService.class);
    }

    @Override
    public void destroy() {

    }

    public void setSecurityDelegate(MenardSecurityDelegate securityDelegate) {
        this.securityDelegate = securityDelegate;
    }


}
