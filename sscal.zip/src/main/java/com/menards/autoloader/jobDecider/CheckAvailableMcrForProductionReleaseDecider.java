package com.menards.autoloader.jobDecider;

import com.menards.autoloader.service.McrService;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;

import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */

public class CheckAvailableMcrForProductionReleaseDecider implements JobExecutionDecider {
    private McrService mcrService;

    public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {
        List list = mcrService.getAllCandidateMcrForProductionRelease();
        if (list.isEmpty()) {
            return new FlowExecutionStatus("NO_AVAILABLE_MCR");
        }
        else {
            return new FlowExecutionStatus("CONTINUE");
        }
    }

    public void setMcrService(McrService mcrService) {
        this.mcrService = mcrService;
    }
}
