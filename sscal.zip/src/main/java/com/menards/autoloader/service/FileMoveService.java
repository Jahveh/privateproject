package com.menards.autoloader.service;

import com.menards.autoloader.dao.factory.TargetEnvironment;
import com.menards.autoloader.dao.mcr.ExcelValidationHistoryDao;
import com.menards.autoloader.dao.source.SourceBlcProductAttributeDao;
import com.menards.autoloader.dao.source.SourceBlcSkuAttributeDao;
import com.menards.autoloader.dao.target.MenardVendorDao;
import com.menards.autoloader.domain.mcr.ExcelValidationHistory;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.Assert;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */

public class FileMoveService {
    private static final Logger LOG = LoggerFactory.getLogger(FileMoveService.class);
    @Autowired
    private ExcelValidationHistoryDao excelValidationHistoryDao = new ExcelValidationHistoryDao();
    private SourceBlcProductAttributeDao sourceBlcProductAttributeDao;
    private SourceBlcSkuAttributeDao sourceBlcSkuAttributeDao;
    private MenardVendorDao menardVendorDao;
    private MenardVendorDao stageMenardVendorDao;
    private MenardVendorDao productionMenardVendorDao;
    private String targetFolder;

    /**
     * default constructor method for cglib
     */
    public FileMoveService() {

    }

    /**
     * constructor method
     * @param sourceJdbcTemplate jdbc template for source tables
     * @param stageJdbcTemplate jdbc template for stage tables
     * @param productionJdbcTemplate jdbc template for production tables
     */
    public FileMoveService(
            JdbcTemplate sourceJdbcTemplate,
            JdbcTemplate stageJdbcTemplate,
            JdbcTemplate productionJdbcTemplate) {

        sourceBlcProductAttributeDao = new SourceBlcProductAttributeDao(sourceJdbcTemplate);
        sourceBlcSkuAttributeDao = new SourceBlcSkuAttributeDao(sourceJdbcTemplate);
        stageMenardVendorDao = new MenardVendorDao(stageJdbcTemplate);
        productionMenardVendorDao = new MenardVendorDao(productionJdbcTemplate);
    }

    /**
     *
     * @param mcrId mcr id
     * @param targetEnvironment target environment
     * @param targetFolder target folder
     */
    public void moveFileToTargetForMcr(int mcrId, TargetEnvironment targetEnvironment, String targetFolder) {
        this.targetFolder = targetFolder;
        assignMenardVendorDaoByTargetEnvironment(targetEnvironment);
        List<ExcelValidationHistory> validationHistories =
            excelValidationHistoryDao.getLastExcelValidationHistoriesByMcrId(mcrId);
        Assert.isTrue(validationHistories.size() > 0, "No successful validation history found for MCR " + mcrId);
        String resourceFolderPath = validationHistories.get(0).getResourceFolderPath();
        Assert.isTrue(resourceFolderPath != null, "Resource folder is not found last time you validated the excel.");
        Resource sourceFolderResource = new FileSystemResource(resourceFolderPath);
        Map<String, String> sourceFileNameFilePathMap = getSourceFileNameFilePathMap(sourceFolderResource);
        Map<String, String> targetFileNameFilePathMap = getTargetFileNameFilePathByMcrId(mcrId);
        moveFile(sourceFileNameFilePathMap, targetFileNameFilePathMap);
    }

    /**
     *
     * @param sourceFileNameFilePathMap mapping between file name and file path on source
     * @param targetFileNameFilePathMap mapping between file name and file path on target
     */
    private void moveFile(Map<String, String> sourceFileNameFilePathMap,
                          Map<String, String> targetFileNameFilePathMap) {
        LOG.info("Copying resource files..");
        int copyCount = 0;
        for (Map.Entry<String, String> sourceFileNameFilePathEntry : sourceFileNameFilePathMap.entrySet()) {
            for (Map.Entry<String, String> targetFileNameFilePathEntry : targetFileNameFilePathMap.entrySet()) {
                if (sourceFileNameFilePathEntry.getKey().equals(targetFileNameFilePathEntry.getKey())) {
                    IOException ioException = null;
                    try {
                    FileUtils.copyFile(new File(sourceFileNameFilePathEntry.getValue()),
                                        new File(this.targetFolder + targetFileNameFilePathEntry.getValue()));
                    LOG.info(">> " + sourceFileNameFilePathEntry.getValue() + " \n\t has been copied to "
                        + this.targetFolder + targetFileNameFilePathEntry.getValue());
                    copyCount++;
                    } catch (IOException ioEx) {
                        ioException = ioEx;
                    }
                    Assert.isTrue(ioException == null, ioException == null
                            ? ""
                            : "IOException is thrown, messages: " + ioException.getMessage());
                }
            }
        }
        LOG.info(copyCount + " resource files have been copied.");
    }

    /**
     *
     * @param resource Resource object
     * @return a mapping between source file name and source file path
     */
    private Map<String, String> getSourceFileNameFilePathMap(Resource resource) {
        Map<String, String> resultMap = new HashMap<String, String>();
        IOException ioException = null;
        try {
            File rootFolder = resource.getFile();
            Assert.isTrue(rootFolder.exists(), "Folder " + rootFolder.getCanonicalPath() + " does not exist.");
            Assert.isTrue(rootFolder.isDirectory(), rootFolder.getCanonicalPath() + " is not a folder.");
            Collection<File> allFiles = FileUtils.listFiles(rootFolder, new String[]{"jpg", "pdf", "JPG", "PDF"}, true);
            Assert.isTrue(!allFiles.isEmpty(), "Folder " + rootFolder.getAbsolutePath() + " does not contain any files.");
            for (File file : allFiles) {
                String filePath = file.getAbsolutePath();
                int lastIndexOfSeparator = filePath.lastIndexOf("/");
                if (lastIndexOfSeparator == -1) {
                    lastIndexOfSeparator = filePath.lastIndexOf("\\");
                } else {
                    lastIndexOfSeparator = filePath.lastIndexOf("/");
                }
                String fileName = filePath.substring(lastIndexOfSeparator+1);
                resultMap.put(fileName, filePath);
            }
        } catch (IOException ex) {
            ioException = ex;
        }
        Assert.isTrue(ioException == null, ioException == null
                ? ""
                : "IOException is thrown, messages: " + ioException.getMessage());
        return resultMap;
    }

    /**
     *
     * @param mcrId mcr id
     * @return mapping between file name and file path on target environment
     */
    private Map<String, String> getTargetFileNameFilePathByMcrId(int mcrId) {
        List<Map<String, String>> allProductAttributes = sourceBlcProductAttributeDao.getAllDataByMcrId(mcrId);
        List<Map<String, String>> allSkuAttributes = sourceBlcSkuAttributeDao.getAllDataByMcrId(mcrId);
        Map<String, Set<String>> productAttributeFileMap =  getAttributeFilePathMap(allProductAttributes, mcrId);
        Map<String, Set<String>> skuAttributeFileMap =  getAttributeFilePathMap(allSkuAttributes, mcrId);
        Map<String, String> fileNameFilePathMap = buildFileNameFilePathMap(productAttributeFileMap, skuAttributeFileMap);
        return fileNameFilePathMap;
    }

    /**
     *
     * @param AttributeFileMaps attribute file map
     * @return a mapping between file name and file path
     */
    private Map<String, String> buildFileNameFilePathMap(Map<String, Set<String>>...AttributeFileMaps) {
        Map<String, String> resultMap = new HashMap<String, String>();
        for (Map<String, Set<String>> attributeFileMap : AttributeFileMaps) {
            for (Set<String> filePathSet : attributeFileMap.values()) {
                for (String filePath : filePathSet) {
                    int lastIndexOfSeparator = filePath.lastIndexOf("/");
                    if (lastIndexOfSeparator == -1) {
                        lastIndexOfSeparator = filePath.lastIndexOf("\\");
                    } else {
                        lastIndexOfSeparator = filePath.lastIndexOf("/");
                    }
                    String fileName = filePath.substring(lastIndexOfSeparator+1);
                    resultMap.put(fileName, filePath);
                }
            }
        }
        return resultMap;
    }

    /**
     *
     * @param allAttributes all attributes
     * @param mcrId mcr id
     * @return mapping
     */
    private Map<String, Set<String>> getAttributeFilePathMap(List<Map<String, String>> allAttributes, int mcrId) {
        Map<String, Set<String>> resultMap = new HashMap<String, Set<String>>();
        for(Map<String, String> attribute : allAttributes) {
            String attributeName = attribute.get("NAME");
            if (menardVendorDao.isFileColumn(attributeName)) {
                if (resultMap.get(attributeName) == null) {
                    resultMap.put(attributeName, new HashSet<String>());
                }
                String contextPath = menardVendorDao.getRelativePath(attributeName, attribute.get("VENDOR_LOGO"));
                resultMap.get(attributeName).add(contextPath + attribute.get("VALUE"));
            }
        }
        return resultMap;
    }

    /**
     *
     * @param targetEnvironment target environment
     */
    private void assignMenardVendorDaoByTargetEnvironment(TargetEnvironment targetEnvironment) {
        switch (targetEnvironment) {
            case STAGE: this.menardVendorDao = stageMenardVendorDao; break;
            case PRODUCTION: this.menardVendorDao = productionMenardVendorDao; break;
            default: break;
        }
    }

}
