package com.menards.autoloader.service;

import com.menards.autoloader.utils.SqlScriptParser;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.io.FileReader;
import java.io.Reader;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Service
public class PreProductionService {
    private static final Logger LOG = LoggerFactory.getLogger(PreProductionService.class);

    @Autowired
    @Qualifier("productionJdbcTemplate")
    private JdbcTemplate productionJdbcTemplate;

    /**
     * Create pre-pro tables before loading data from stage source to production pre-pro.
     * @throws Exception exception
     */
    public void initPreProductionTables() throws Exception {
        Resource sqlScript = new ClassPathResource("/sqlScript/create-pre-pro-tables.sql");
        Reader fileReader = new FileReader(sqlScript.getFile());
        String[] sqls = SqlScriptParser.parse(fileReader);
        LOG.info("Start initializing Pre-production tables...");
        for (String sql : sqls) {
            LOG.info("Executing SQL : >>> " + sql);
            productionJdbcTemplate.execute(sql);
        }
        LOG.info("Finished initializing Pre-production tables.");
    }

    /**
     * Executing production release.
     * @throws Exception exception
     */
    public void productionRelease() throws Exception {
        Resource sqlScript = new ClassPathResource("/sqlScript/production-release.sql");
        Reader fileReader = new FileReader(sqlScript.getFile());
        String[] sqls = SqlScriptParser.parse(fileReader);
        LOG.info("Start production release...");
        for (String sql : sqls) {
            LOG.info("Executing SQL : >>> " + sql);
            productionJdbcTemplate.execute(sql);
        }
        LOG.info("Finished production release...");
    }


}
