package com.menards.autoloader.service;

import com.menards.autoloader.domain.mcr.MCR;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.io.IOException;
import java.io.StringWriter;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Service
public class EmailService {

    @Autowired
    private MailSender mailSender;

    @Autowired
    private McrService mcrService;

    private static Configuration ftlCfg = new Configuration();

    static {
        ftlCfg.setClassForTemplateLoading(EmailService.class, "/META-INF/email.template/");
    }

    /**
     * Public method for sending an email
     * @param from sender
     * @param to an array of email recipient
     * @param subject email subject
     * @param msg email body
     */
    public void sendMail(String from, String[] to, String subject, String msg) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(from);
        message.setTo(to);
        message.setSubject(subject);
        message.setText(msg);
        mailSender.send(message);
    }

    /**
     * Build a SimpleMailMessage object
     * @param mcrId mcr id
     * @param emailUseCase email use case
     * @return an object of SimpleMailMessage
     * @throws IOException io exception
     * @throws TemplateException template exception
     */
    public SimpleMailMessage buildSimpleMailMessage(int mcrId, EmailUseCase emailUseCase)
            throws IOException, TemplateException {
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setText(buildEmailBody(mcrId, emailUseCase));

        return mailMessage;
    }

    /**
     * Build email body
     * @param mcrId mcr id
     * @param emailUseCase email use case
     * @return email body
     * @throws IOException io exception
     * @throws TemplateException template exception
     */
    public String buildEmailBody(int mcrId, EmailUseCase emailUseCase) throws IOException, TemplateException {
        MCR mcr = mcrService.getCompleteMcrDataById(mcrId);
        Assert.isTrue(mcr != null, "MCR is null");
        Template template = null;
        switch (emailUseCase) {
           case MCR_APPROVAL: template = ftlCfg.getTemplate("mcr-approval-notification.ftl"); break;
           case MCR_PRODUCTION_RELEASE: template = ftlCfg.getTemplate("mcr-production-release-notification.ftl"); break;
           case MCR_STAGE_APPROVAL: template = ftlCfg.getTemplate("mcr-stage-approval-notification.ftl"); break;
           case MCR_STAGE_PUBLISH: template = ftlCfg.getTemplate("mcr-stage-publish-notification.ftl"); break;
           case NEW_MCR: template = ftlCfg.getTemplate("new-mcr-notification.ftl"); break;
           case MCR_REACTIVATE: template = ftlCfg.getTemplate("reactivate-mcr-notification.ftl"); break;
           default: break;
        }
        StringWriter stringWriter = new StringWriter();
        if (mcr != null) {
            template.process(mcr, stringWriter);
        }
        stringWriter.close();
        return stringWriter.getBuffer().toString();
    }

}
