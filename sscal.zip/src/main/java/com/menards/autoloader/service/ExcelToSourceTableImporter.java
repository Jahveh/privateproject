package com.menards.autoloader.service;

import com.menards.autoloader.dao.IDao;
import com.menards.autoloader.dao.factory.DaoNames;
import com.menards.autoloader.dao.factory.IDaoFactory;
import com.menards.autoloader.dao.target.BlcCategoryDao;
import com.menards.autoloader.domain.CategoryTree;
import com.menards.autoloader.utils.CategoryTreeCalculationUtils;
import com.menards.autoloader.utils.ExcelUtils;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>ExcelToSourceImporter</p>
 * <p>A service class that parse upload files(.xls), transform the data, save to DB.</p>
 * <p>
 * The overall process this class follows (invoked by importData method):
 * ====================================================================
 * <1> (parse) Parse excel
 * <2> (consolidate) Transform to source data structures
 * <3> (purge) Delete all source table data
 * <4> (persist) Save to source tables
 * <5> (clean-up) Clean up in-memory data
 * ====================================================================
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class ExcelToSourceTableImporter {
    private static Logger logger = LoggerFactory.getLogger(ExcelToSourceTableImporter.class);
    private Workbook workbook;
    private String workbookFilePath;
    private Set<String> allProductExcelColumnHeaders;
    private Set<String> allSkuExcelColumnHeaders;
    private Set<String> allOptionExcelColumnHeaders;
    private Set<String> allAlternateLocationColumnHeaders;

    private Map<String, CategoryTree> legacyCategoryDict = new HashMap<String, CategoryTree>();
    private Map<String, Long> legacyCategoryUrlKeyCategoryIdMap = new HashMap<String, Long>();
    private List<Map<String, String>> excelProducts = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> excelSkus = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> excelOptions = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> excelAlternateLocations = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> sourceBlcProducts = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> sourceBlcSkus = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> sourceBlcCategoryProductXrefs = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> sourceBlcProductSkuXrefs = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> sourceBlcSkuAttributes = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> sourceBlcProductAttributes = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> sourceMenardProducts = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> sourceMenardProductOptions = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> sourceMenardSkus = new ArrayList<Map<String, String>>();
    /*
    Set this flag in the process of data preparation phase,
    and then use this flag in the process of data import phase to
    signify whether to include the root node in the delta category set.
     */
    private boolean hasLegacyCategories;
    private IDao<List<Map<String, String>>> blcCategoryDao;
    private IDao<List<Map<String, String>>> sourceBlcCategoryProductXrefDao;
    private IDao<List<Map<String, String>>> sourceBlcProductSkuXrefDao;
    private IDao<List<Map<String, String>>> sourceBlcProductAttributeDao;
    private IDao<List<Map<String, String>>> sourceBlcProductDao;
    private IDao<List<Map<String, String>>> sourceBlcSkuAttributeDao;
    private IDao<List<Map<String, String>>> sourceBlcSkuDao;
    private IDao<List<Map<String, String>>> sourceMenardProductDao;
    private IDao<List<Map<String, String>>> sourceMenardProductOptionDao;
    private IDao<List<Map<String, String>>> sourceMenardSkuDao;

    private int stepInvocationOrder = 0;
    private String currentVendor;


    /**
     * A default constructor method for CGLib proxying this class.
     */
    public ExcelToSourceTableImporter() {
    }

    /**
     * A constructor method that accepts a DaoFactory for source db.
     * @param daoFactory source db dao factory.
     */
    public ExcelToSourceTableImporter(IDaoFactory<List<Map<String, String>>> daoFactory) {
        this.blcCategoryDao = daoFactory.getDao(DaoNames.BLC_CATEGORY_DAO);
        this.sourceBlcCategoryProductXrefDao = daoFactory.getDao(DaoNames.SOURCE_BLC_CATEGORY_PRODUCT_XREF_DAO);
        this.sourceBlcProductSkuXrefDao = daoFactory.getDao(DaoNames.SOURCE_BLC_PRODUCT_SKU_XREF_DAO);
        this.sourceBlcProductAttributeDao = daoFactory.getDao(DaoNames.SOURCE_BLC_PRODUCT_ATTRIBUTE_DAO);
        this.sourceBlcProductDao = daoFactory.getDao(DaoNames.SOURCE_BLC_PRODUCT_DAO);
        this.sourceBlcSkuAttributeDao = daoFactory.getDao(DaoNames.SOURCE_BLC_SKU_ATTRIBUTE_DAO);
        this.sourceBlcSkuDao = daoFactory.getDao(DaoNames.SOURCE_BLC_SKU_DAO);
        this.sourceMenardProductDao = daoFactory.getDao(DaoNames.SOURCE_MENARD_PRODUCT_DAO);
        this.sourceMenardProductOptionDao = daoFactory.getDao(DaoNames.SOURCE_MENARD_PRODUCT_OPTION_DAO);
        this.sourceMenardSkuDao = daoFactory.getDao(DaoNames.SOURCE_MENARD_SKU_DAO);
    }

    /**
     * entry method
     * @param filePath file path
     * @param mcrId mcr id
     * @throws SQLException sql exception
     * @throws IOException io exception
     * @throws ClassNotFoundException class not found exception
     */
    public void importData(String filePath, int mcrId) throws SQLException, IOException, ClassNotFoundException {
        try {
            parse(filePath);
            consolidate();
            purge(mcrId);
            assignMcrId(mcrId);
            persist();
        } finally {
            cleanUp();
        }
    }

    /**
     * Read an excel designated by the given file path
     * @param filePath the file path to the excel spread sheet.
     * @throws ClassNotFoundException a ClassNotFoundException
     * @throws SQLException an SQLException
     * @throws IOException an IOException
     */
    private void parse(String filePath) throws ClassNotFoundException, SQLException, IOException {
        logger.info("===============================Stared parsing " + filePath + "============================");
        init(filePath);
        //prepareCategory();
        //!!!Comment out this step, as product categories would probably be imported/maintained through some other ways.
        parseExcel();
        logger.info("===============================Finished parsing " + filePath + "============================");
    }


    /**
     * Transform data from excel spread sheet to source data structures
     */
    private void consolidate() {
        generateProductId();
        generateSkuId();
        buildDataRelationships();
        refactorDataForSource();
    }

    /**
    * purge source table data
    * @param mcrId mcr id
    */
    private void purge(int mcrId) {
        sourceBlcProductDao.deleteAllByMcrId(mcrId);
        sourceMenardProductDao.deleteAllByMcrId(mcrId);
        sourceBlcCategoryProductXrefDao.deleteAllByMcrId(mcrId);
        sourceBlcProductSkuXrefDao.deleteAllByMcrId(mcrId);
        sourceBlcProductAttributeDao.deleteAllByMcrId(mcrId);
        sourceMenardProductOptionDao.deleteAllByMcrId(mcrId);
        sourceBlcSkuDao.deleteAllByMcrId(mcrId);
        sourceMenardSkuDao.deleteAllByMcrId(mcrId);
        sourceBlcSkuAttributeDao.deleteAllByMcrId(mcrId);
    }

    /**
     * assign mcr id
     * @param mcrId mcr id
     */
    private void assignMcrId(int mcrId) {
        assignMcrIdForSingleSourceTable(sourceBlcProducts, mcrId);
        assignMcrIdForSingleSourceTable(sourceMenardProducts, mcrId);
        assignMcrIdForSingleSourceTable(sourceBlcCategoryProductXrefs, mcrId);
        assignMcrIdForSingleSourceTable(sourceBlcProductSkuXrefs, mcrId);
        assignMcrIdForSingleSourceTable(sourceBlcProductAttributes, mcrId);
        assignMcrIdForSingleSourceTable(sourceMenardProductOptions, mcrId);
        assignMcrIdForSingleSourceTable(sourceBlcSkus, mcrId);
        assignMcrIdForSingleSourceTable(sourceMenardSkus, mcrId);
        assignMcrIdForSingleSourceTable(sourceBlcSkuAttributes, mcrId);
    }

    /**
     * assign mcr id for a single table
     * @param list data list
     * @param mcrId mcr id
     */
    private void assignMcrIdForSingleSourceTable(List<Map<String, String>> list,  int mcrId) {
        for (Map<String, String> map : list) {
            map.put("MCR_ID", mcrId + "");
        }
    }

    /**
     * Save the data to db.
     */
    private void persist() {
        //persistBlcCategory();!!!Uncomment this line to enable category import from the s/s

        sourceBlcProductDao.batchInsert(sourceBlcProducts);
        sourceMenardProductDao.batchInsert(sourceMenardProducts);
        sourceBlcCategoryProductXrefDao.batchInsert(sourceBlcCategoryProductXrefs);
        sourceBlcProductSkuXrefDao.batchInsert(sourceBlcProductSkuXrefs);
        sourceBlcProductAttributeDao.batchInsert(sourceBlcProductAttributes);
        sourceMenardProductOptionDao.batchInsert(sourceMenardProductOptions);

        sourceBlcSkuDao.batchInsert(sourceBlcSkus);
        sourceMenardSkuDao.batchInsert(sourceMenardSkus);
        sourceBlcSkuAttributeDao.batchInsert(sourceBlcSkuAttributes);

        logger.info("Excel to source import completed successfully!");

    }

    /**
     * clean in-memory data before proceeding with the next excel spread sheet.
     */
    private void cleanUp() {
        sourceBlcProducts.clear();
        sourceMenardProducts.clear();
        sourceBlcCategoryProductXrefs.clear();
        sourceBlcProductSkuXrefs.clear();
        sourceBlcProductAttributes.clear();
        sourceMenardProductOptions.clear();
        sourceBlcSkus.clear();
        sourceMenardSkus.clear();
        sourceBlcSkuAttributes.clear();
        excelProducts.clear();
        excelSkus.clear();
        excelOptions.clear();
        excelAlternateLocations.clear();
        legacyCategoryDict.clear();
        legacyCategoryUrlKeyCategoryIdMap.clear();
        currentVendor = null;
    }

    /**
     * persist category data.
     */
    private void persistBlcCategory() {
        if (this.hasLegacyCategories) {
            legacyCategoryDict.remove("/");
            Assert.isTrue(!legacyCategoryDict.containsKey("/"),
                    "Has legacy categories, hence, should not insert root category!");
        }
        List<Map<String, String>> blcCategories = new ArrayList<Map<String, String>>(legacyCategoryDict.size());
        for (CategoryTree category : legacyCategoryDict.values()) {
            Map<String, String> categoryDataMap = new HashMap<String, String>();
            categoryDataMap.put("CATEGORY_ID", category.getCategoryId().toString());
            categoryDataMap.put("NAME", category.getCategoryName());
            categoryDataMap.put("URL", category.getPathToThisNode());
            categoryDataMap.put("DEFAULT_PARENT_CATEGORY_ID", category.getParentCategoryId().toString());
            blcCategories.add(categoryDataMap);
        }
        blcCategoryDao.batchInsert(blcCategories);
    }

    /**
     * build relationships among source db tables.
     */
    private void buildDataRelationships() {
        associateExcelProductsWithCategories();
        associateExcelSkuWithProduct();
    }


    /**
     * Change the data presentation from excel spread sheet to those of source db tables.
     */
    private void refactorDataForSource() {
        refactorProductsForSource();
        refactorSkusForSource();
        refactorAlternateLocationsForSource();
        refactorProductOptionsForSource();
    }


    /**
     * Change the product data presentation from excel spread sheet to those of source db tables.
     */
    private void refactorProductsForSource() {
        for (Map<String, String> excelProduct : this.excelProducts) {
            Map<String, String> sourceBlcProduct = new HashMap<String, String>();
            sourceBlcProduct.put("PRODUCT_ID", excelProduct.get("PRODUCT_ID"));
            sourceBlcProduct.put("URL",
                convertProductFamilyToUrl(excelProduct.get("PRODUCT_FAMILY")) + "/" + excelProduct.get("PRODUCT_ID"));
            sourceBlcProduct.put("DEFAULT_CATEGORY_ID", excelProduct.get("CATEGORY_ID"));
            this.sourceBlcProducts.add(sourceBlcProduct);
            Map<String, String> sourceMenardProduct = new HashMap<String, String>();
            sourceMenardProduct.put("PRODUCT_ID", excelProduct.get("PRODUCT_ID"));
            sourceMenardProduct.put("MODEL_NUM", excelProduct.get("MODEL_NUM"));
            this.sourceMenardProducts.add(sourceMenardProduct);
            for (Map.Entry<String, String> excelProductAttribute : excelProduct.entrySet()) {
                if (!excelProductAttribute.getKey().equals("MODEL_NUM")
                        && !excelProductAttribute.getKey().equals("PRODUCT_ID")
                        && !excelProductAttribute.getKey().equals("CATEGORY_ID")
                        && !excelProductAttribute.getKey().equals("URL")
                        && !excelProductAttribute.getKey().equals("PRODUCT_FAMILY")) {
                    Map<String, String> blcProductAttribute = new HashMap<String, String>();
                    blcProductAttribute.put("PRODUCT_ID", excelProduct.get("PRODUCT_ID"));
                    blcProductAttribute.put("NAME", excelProductAttribute.getKey());
                    blcProductAttribute.put("VALUE", excelProductAttribute.getValue());
                    blcProductAttribute.put("VENDOR_LOGO", this.currentVendor);
                    this.sourceBlcProductAttributes.add(blcProductAttribute);
                }
            }
            Map<String, String> sourceBlcCategoryProductXref = new HashMap<String, String>();
            sourceBlcCategoryProductXref.put("PRODUCT_ID", excelProduct.get("PRODUCT_ID"));
            sourceBlcCategoryProductXref.put("CATEGORY_ID", excelProduct.get("CATEGORY_ID"));
            this.sourceBlcCategoryProductXrefs.add(sourceBlcCategoryProductXref);
        }
    }


    /**
     * Change the SKU data presentation from excel spread sheet to those of source db tables.
     */
    private void refactorSkusForSource() {
        for (Map<String, String> excelSku : this.excelSkus) {
            Map<String, String> sourceBlcSku = new HashMap<String, String>();
            sourceBlcSku.put("SKU_ID", excelSku.get("SKU_ID"));
            sourceBlcSku.put("DEFAULT_PRODUCT_ID", excelSku.get("PRODUCT_ID"));
            this.sourceBlcSkus.add(sourceBlcSku);
            Map<String, String> productSkuXref = new HashMap<String, String>();
            productSkuXref.put("PRODUCT_ID", excelSku.get("PRODUCT_ID"));
            productSkuXref.put("SKU_ID", excelSku.get("SKU_ID"));
            this.sourceBlcProductSkuXrefs.add(productSkuXref);
            Map<String, String> sourceMenardSku = new HashMap<String, String>();
            sourceMenardSku.put("SKU_ID", excelSku.get("SKU_ID"));
            sourceMenardSku.put("SKU_CODE", excelSku.get("SKU_CODE"));
            sourceMenardSku.put("MENARD_SKU", excelSku.get("MENARDS_SKU"));
            sourceMenardSku.put("VENDOR_LOGO", this.currentVendor);
            this.sourceMenardSkus.add(sourceMenardSku);
            for (Map.Entry<String, String> excelSkuAttribute : excelSku.entrySet()) {
                if (!excelSkuAttribute.getKey().equals("SKU_CODE")
                        && !excelSkuAttribute.getKey().equals("MENARDS_SKU")
                        && !excelSkuAttribute.getKey().equals("PRODUCT_ID")
                        && !excelSkuAttribute.getKey().equals("MODEL_NUM")
                        && !excelSkuAttribute.getKey().equals("SKU_ID")
                        ) {
                    Map<String, String> blcSkuAttribute = new HashMap<String, String>();
                    blcSkuAttribute.put("SKU_ID", excelSku.get("SKU_ID"));
                    blcSkuAttribute.put("NAME", excelSkuAttribute.getKey());
                    blcSkuAttribute.put("VALUE", excelSkuAttribute.getValue());
                    blcSkuAttribute.put("VENDOR_LOGO", this.currentVendor);
                    this.sourceBlcSkuAttributes.add(blcSkuAttribute);
                }
            }
        }
    }


    /**
     * Change the alternate location data presentation from excel spread sheet to those of source db tables.
     */
    private void refactorAlternateLocationsForSource() {
        Set<String> tempSet = new HashSet<String>();
            for (Map<String, String> sourceBlcCategoryProductXref : sourceBlcCategoryProductXrefs) {
                tempSet.add(sourceBlcCategoryProductXref.get("CATEGORY_ID")
                + sourceBlcCategoryProductXref.get("PRODUCT_ID"));
            }

            for (Map<String, String> excelAlternateLocation : this.excelAlternateLocations) {
            String alternateProductModelNum = excelAlternateLocation.get("MODEL_NUM");
            String alternateProductId = null;
            String alternateCategoryId = null;
            for (Map<String, String> excelProduct : this.excelProducts) {
                if (alternateProductModelNum.equals(excelProduct.get("MODEL_NUM"))) {
                    alternateProductId = excelProduct.get("PRODUCT_ID");
                    break;
                }
            }
            alternateCategoryId = this.legacyCategoryUrlKeyCategoryIdMap
                    .get(excelAlternateLocation.get("PRODUCT_FAMILY")).toString();
            if (!tempSet.contains(alternateCategoryId + alternateProductId)) {
                Map<String, String> sourceBlcCategoryProductXref = new HashMap<String, String>();
                sourceBlcCategoryProductXref.put("CATEGORY_ID", alternateCategoryId);
                sourceBlcCategoryProductXref.put("PRODUCT_ID", alternateProductId);
                this.sourceBlcCategoryProductXrefs.add(sourceBlcCategoryProductXref);
            }
        }
    }


    /**
     * Change the product option data presentation from excel spread sheet to those of source db tables.
     */
    private void refactorProductOptionsForSource() {
        for (Map<String, String> excelOption : this.excelOptions) {
            Map<String, String> sourceMenardProductOption = new HashMap<String, String>();
            String baseProductId = getProductIdByModelNum(excelOption.get("BASE_MODEL_NUM"));
            String optionProductId = getProductIdByModelNum(excelOption.get("ACCESSORY_MODEL_NUM"));
            String mandatory = excelOption.get("MANDATORY");
            sourceMenardProductOption.put("BASE_PRODUCT_ID", baseProductId);
            sourceMenardProductOption.put("OPTION_PRODUCT_ID", optionProductId);
            sourceMenardProductOption.put("MANDATORY", mandatory);
            this.sourceMenardProductOptions.add(sourceMenardProductOption);
        }

    }

    /**
     * Get the product number from its model number
     * @param modelNum model number
     * @return product id.
     */
    private String getProductIdByModelNum(String modelNum) {
        for (Map<String, String> excelProduct : this.excelProducts) {
            if (excelProduct.get("MODEL_NUM").equals(modelNum)) {
                return excelProduct.get("PRODUCT_ID");
            }
        }
        return null;
    }


    /**
     * Init the parse process for the given excel spread sheet
     * @param filePath the file path to the excel spread sheet.
     * @throws IOException an IOException
     */
    private void init(String filePath) throws IOException {
        initPoi(filePath);
        initLegacyData();
    }


    /**
     * Init POI for the given file.
     * @param filePath a file path to the excel spread sheet.
     * @throws IOException  an IOException
     */
    private void initPoi(String filePath) throws IOException {
        Assert.isTrue(filePath != null, "filePath must not be null.");
        workbookFilePath = filePath;
        FileInputStream file = new FileInputStream(new File(filePath));
        this.workbook = new HSSFWorkbook(file);
        initExcelColumnHeaders();
    }

    /**
     * Read column headers for all possible sheets.
     */
    private void initExcelColumnHeaders() {
        this.allProductExcelColumnHeaders = parseColumnHeadersForSheet("Product Upload");
        this.allSkuExcelColumnHeaders = parseColumnHeadersForSheet("Sku Upload");
        this.allOptionExcelColumnHeaders = parseColumnHeadersForSheet("Option Upload");
        this.allAlternateLocationColumnHeaders = parseColumnHeadersForSheet("ALTERNATE LOCATIONS");
    }

    /**
     * Get column header for a single sheet.
     * @param sheetName a sheet name
     * @return a set of column headers.
     */
    private Set<String> parseColumnHeadersForSheet(String sheetName) {
        List<Sheet> sheets = ExcelUtils.getSheetsByNames(this.workbook, new String[]{sheetName});
        if (sheets.isEmpty()) {
            return new HashSet<String>();
        }
        return ExcelUtils.getSheetColumnHeaders(sheets.get(0));
    }

    /**
     * init existing db data.
     */
    private void initLegacyData() {
        initLegacyCategories();
    }


    /**
     * Load existing category data.
     */
    private void initLegacyCategories() {
        if (legacyCategoryDict.isEmpty()) {
            logger.info("ExcelImporter.legacyCategoryDict : "
                    + "Map<String, CategoryTree> is null, initializing it through blcCategoryDao : BlcCategoryDao ...");
            List<CategoryTree> legacyCategories = ((BlcCategoryDao) blcCategoryDao).getBlcCategories();
            if (legacyCategories.isEmpty()) {
                hasLegacyCategories = false;
                CategoryTree root = createRootCategory();
                legacyCategories.add(root);
            } else {
                hasLegacyCategories = true;
            }
            CategoryTree legacyCategoryTree = CategoryTreeCalculationUtils.buildRootCategory(legacyCategories);
            this.legacyCategoryDict = CategoryTreeCalculationUtils.buildCategoryDictionaryByPath(legacyCategoryTree);
            buildUrlKeyCategoryIdMap(legacyCategories);
        }
    }

    /**
     * build a map between url key and category id.
     * @param legacyCategories legacy categories
     */
    private void buildUrlKeyCategoryIdMap(List<CategoryTree> legacyCategories) {
        for (CategoryTree categoryTree : legacyCategories) {
            if (categoryTree.getUrlKey() != null) {
                this.legacyCategoryUrlKeyCategoryIdMap.put(categoryTree.getUrlKey(), categoryTree.getCategoryId());
            }
        }
    }

    /**
     * Create a root category tree node.
     * @return an object of {@link com.menards.autoloader.domain.CategoryTree}
     */
    private CategoryTree createRootCategory() {
        CategoryTree root = new CategoryTree();
        root.setPathToThisNode("/");
        root.setCategoryName("root");
        root.setParentCategoryId(10L);
        root.setCategoryId(10L);
        return root;
    }

    /**
     * Load all categories from db.
     * @throws ClassNotFoundException a ClassNotFoundException
     * @throws SQLException an SQLException
     */
    private void prepareCategory() throws ClassNotFoundException, SQLException {
        Set<String> excelProductFamilies = getExcelProductFamilies();
        CategoryTreeCalculationUtils.mergeNewCategories(excelProductFamilies, legacyCategoryDict);
    }


    /**
     * Read all product families from excel spread sheet.
     * @return a set of product families from excel spread sheet.
     */
    private Set<String> getExcelProductFamilies() {
        List<Sheet> sheets = ExcelUtils.getSheetsByNames(workbook, "Product Upload", "Alternate Locations");
        Assert.isTrue(!sheets.isEmpty(), "No sheet named \"Product Upload\" found in the " + workbookFilePath);
        Set<String> productFamilies = new HashSet<String>();
        for (Sheet sheet : sheets) {
            productFamilies.addAll(getDistinctProductFamilies(sheet));
        }
        return productFamilies;
    }


    /**
     * Start to parse excel spread sheet.
     */
    public void parseExcel() {

        this.excelProducts.addAll(parseExcel(this.workbook, "Product Upload", this.allProductExcelColumnHeaders));
        this.excelSkus.addAll(parseExcel(this.workbook, "Sku Upload", this.allSkuExcelColumnHeaders));
        this.excelOptions.addAll(parseExcel(this.workbook, "Option Upload", this.allOptionExcelColumnHeaders));
        this.excelAlternateLocations.addAll(parseExcel(this.workbook,
                "Alternate Locations", this.allAlternateLocationColumnHeaders));
        this.currentVendor = getCurrentExcelVendor();
        Assert.isTrue(currentVendor != null, "Vendor_Logo must not be empty for the given Excel file.");
    }

    /**
     * get the vendor for the current excel file
     * @return vendor
     */
    private String getCurrentExcelVendor() {
        for (Map<String, String> excelProduct: this.excelProducts) {
            for (Map.Entry<String, String> entry : excelProduct.entrySet()) {
                if (entry.getKey().equalsIgnoreCase("Vendor_Logo") && entry.getValue() != null) {
                    return entry.getValue();
                }
            }
        }
        return null;
    }

    /**
     * Read a single POI sheet in a single POI workbook
     * @param workbook a POI {WorkBook} object
     * @param sheetName sheet name
     * @param columnHeaders a set of column headers.
     * @return a list of data map red from the the given sheet.
     */
    private List<Map<String, String>> parseExcel(Workbook workbook, String sheetName, Set<String> columnHeaders) {
        List<Sheet> sheets = ExcelUtils.getSheetsByNames(workbook, new String[]{sheetName});
        if (sheets.isEmpty()) {
            return new ArrayList<Map<String, String>>();
        }
        Sheet sheet = sheets.get(0);
        return ExcelUtils.getSheetData(sheet, columnHeaders);
    }

    /**
     * associate the category with products in excel spread sheet.
     */
    private void associateExcelProductsWithCategories() {
        for (Map<String, String> excelProduct : this.excelProducts) {
            String productFamilyInExcel = excelProduct.get("PRODUCT_FAMILY");
            Long categoryId = this.legacyCategoryUrlKeyCategoryIdMap.get(productFamilyInExcel);
            Assert.isTrue(categoryId != null,
                    "Product Family[" + productFamilyInExcel + "] does not exist in BLC_CATEGORY table.");
            excelProduct.put("CATEGORY_ID", categoryId.toString());
        }
    }


    /**
     * Associate SKU with product from excel spread sheet.
     */
    private void associateExcelSkuWithProduct() {
        for (Map<String, String> excelSku : this.excelSkus) {
            String modelNum = excelSku.get("MODEL_NUM");
            for (Map<String, String> excelProduct : this.excelProducts) {
                String productModelNum = excelProduct.get("MODEL_NUM");
                if (modelNum.equals(productModelNum)) {
                    excelSku.put("PRODUCT_ID", excelProduct.get("PRODUCT_ID"));
                    break;
                }
            }
        }
    }


    /**
     * Build a product ID for source db.
     */
    private void generateProductId() {
        for (Map<String, String> excelProduct : this.excelProducts) {
            excelProduct.put("PRODUCT_ID", excelProduct.get("MODEL_NUM") + excelProduct.get("VENDOR_LOGO"));
        }
    }


    /**
     * Build a SKU id for source db.
     */
    private void generateSkuId() {
        for (Map<String, String> excelSku : this.excelSkus) {
            excelSku.put("SKU_ID", getMd5(excelSku.get("SKU_CODE")));
        }
    }

    /**
     * Build the MD5 from the given text.
     * @param text the text string to be encoded by MD5
     * @return the encoded string
     */
    private String getMd5(String text) {
        MessageDigest messageDigest = null;
        try {
            messageDigest = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        messageDigest.reset();
        messageDigest.update(text.getBytes(Charset.forName("UTF8")));
        byte[] resultByte = messageDigest.digest();
        return new String(Hex.encodeHex(resultByte));
    }

    /**
     * get category id by its url.
     * @param url category url
     * @return category id
     */
    private Long getCategoryIdByUrl(String url) {
        Long categoryId = null;
        CategoryTree category = legacyCategoryDict.get(url);
        if (category != null) {
            categoryId = category.getCategoryId();
        }
        return categoryId;
    }


    /**
     * Get all distinct product families from a given sheet
     * @param sheet a POI {@link org.apache.poi.ss.usermodel.Sheet}
     * @return a set of product families.
     */
    private Set<String> getDistinctProductFamilies(Sheet sheet) {
        logger.info(
                "=============================== Reading product families from sheet[" + sheet.getSheetName() + "]");
        Set<String> returnSet = new HashSet<String>();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) {
                break;
            }
            int productFamilyColumnIndex = ExcelUtils.getColumnIndexByColumnName(sheet, "Product_Family");
            Assert.isTrue(productFamilyColumnIndex >= 0,
                    "No column named \"Product_Family\" in the sheet " + sheet.getSheetName());
            Cell cell = row.getCell(productFamilyColumnIndex);
            String cellValue = ExcelUtils.getCellValue(cell);
            if (StringUtils.isNotEmpty(cellValue)) {
                returnSet.add(convertProductFamilyToUrl(cellValue));
            }

        }
        return returnSet;
    }

    /**
     * Replace the underscore sign with the forward slash sign in product family string.
     * @param productFamily a product family.
     * @return a product family string with forward slash as its hierarchy delimiters.
     */
    public static String convertProductFamilyToUrl(String productFamily) {
        String url = productFamily.replaceAll("_", "/");
        if (!url.startsWith("/")) {
            url = "/" + url;
        }
        return url;
    }
}
