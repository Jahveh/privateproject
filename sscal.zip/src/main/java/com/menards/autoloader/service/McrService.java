package com.menards.autoloader.service;

import com.menards.autoloader.dao.mcr.ExcelValidationHistoryDao;
import com.menards.autoloader.dao.mcr.McrApprovalHistoryDao;
import com.menards.autoloader.dao.mcr.McrDao;
import com.menards.autoloader.dao.target.MenardVendorDao;
import com.menards.autoloader.domain.mcr.ApprovalHistory;
import com.menards.autoloader.domain.mcr.ExcelValidationHistory;
import com.menards.autoloader.domain.mcr.ExcelValidationStatus;
import com.menards.autoloader.domain.mcr.MCR;
import com.menards.autoloader.domain.mcr.McrStatus;
import com.menards.autoloader.domain.mcr.User;
import com.menards.autoloader.integration.gateway.EmailGateway;
import com.menards.autoloader.integration.gateway.JobGateway;
import com.menards.autoloader.integration.gateway.McrGateway;
import com.menards.autoloader.utils.FileChecksumUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Service
public class McrService {
    private static final Logger LOG = LoggerFactory.getLogger(McrService.class);

    @Autowired
    private McrDao mcrDao;

    @Autowired
    private ExcelValidationService excelValidationService;

    @Autowired
    private ExcelValidationHistoryDao excelValidationHistoryDao;

    @Autowired
    private McrApprovalHistoryDao mcrApprovalHistoryDao;

    @Autowired
    private McrGateway mcrGateway;

    @Autowired
    private JobGateway jobGateway;

    @Autowired
    private EmailGateway emailGateway;

    @Autowired
    private LookupDataService lookupDataService;

    @Autowired
    @Qualifier("productionMenardVendorDao")
    private MenardVendorDao menardVendorDao;

    /**
     * Public service method for creating a new MCR.
     * @param mcr mcr
     */
    public void createMcr(MCR mcr) {
        int mcrId = mcrDao.saveMcr(mcr);
        List<ApprovalHistory> approvalHistoryList = new ArrayList<ApprovalHistory>();
        for (User approver : mcr.getApprovers()) {
            ApprovalHistory approvalHistory = new ApprovalHistory();
            approvalHistory.setApprovalUser(approver);
            approvalHistory.setStatus(McrStatus.PENDING);
            approvalHistory.setMcrId(mcrId);
            approvalHistoryList.add(approvalHistory);
        }
        mcrApprovalHistoryDao.batchInsert(approvalHistoryList);
        emailGateway.sendMail(mcrId, EmailUseCase.NEW_MCR.name(), "", "");
    }

    public void createMCRIfApproverSkipped(MCR mcr) {
        mcr.setAllApproved(true);
        int mcrId = mcrDao.saveMcr(mcr);
        List<ApprovalHistory> approvalHistoryList = new ArrayList<ApprovalHistory>();
        ApprovalHistory approvalHistory = new ApprovalHistory();
        approvalHistory.setApprovalUser(mcr.getSubmitter());
        approvalHistory.setStatus(McrStatus.APPROVED);
        approvalHistory.setMcrId(mcrId);
        approvalHistory.setComment("Automatic get approved, since no approver has been selected.");
        approvalHistoryList.add(approvalHistory);
        mcrApprovalHistoryDao.batchInsert(approvalHistoryList);
        emailGateway.sendMail(mcrId, EmailUseCase.NEW_MCR.name(), "", "");
        List<ExcelValidationHistory> excelValidationHistories = excelValidationHistoryDao.getLastExcelValidationHistoriesByMcrId(mcrId);
        jobGateway.runExcelToStageJob(excelValidationHistories.get(0).getExcelPath(), mcrId);

    }

    /**
     *
     * @param mcrId mcr id
     * @param approverEmail approver email
     * @param comment comment
     * @throws IOException io exception
     */
    public void rejectMcr(int mcrId, String approverEmail, String comment) throws IOException {
        mcrApprovalHistoryDao.updateMcrHistory(mcrId, approverEmail, McrStatus.REJECTED.getName(), comment);
        emailGateway.sendMail(
                mcrId,
                EmailUseCase.MCR_APPROVAL.name(),
                "REJECTED",
                lookupDataService.getUserNameByEmail(approverEmail)
        );
    }

    /**
     * Public service method for approved a particular MCR identified by the mcrId.
     * @param mcrId mcr id
     * @param approverEmail approver email
     * @param comment comment
     * @return a map
     */
    public Map approveMcr(int mcrId, String approverEmail, String comment) throws IOException {
        Map<String, String> returnMsg = new HashMap<String, String>();
        mcrApprovalHistoryDao.updateMcrHistory(mcrId, approverEmail, McrStatus.APPROVED.getName(), comment);
        Set<String> allStatus = mcrApprovalHistoryDao.getAllApprovalStatusByMcrId(mcrId);
        if (allStatus.size() == 1 && allStatus.contains(McrStatus.APPROVED.getName())) {//MCR should get approved.
            List<ExcelValidationHistory> excelValidationHistories = excelValidationHistoryDao.getLastExcelValidationHistoriesByMcrId(mcrId);
            if (excelValidationHistories.isEmpty()) {
                returnMsg.put("ERROR_MESSAGE", "No successful validation history found for MCR[ID = " + mcrId + "].");
            } else if (excelValidationHistories.get(0).getExcelValidationStatus() != ExcelValidationStatus.PASSED //Excel should be valid
                    && excelValidationHistories.get(0).getReactivateValidationStatus() != ExcelValidationStatus.PASSED) {
                returnMsg.put("ERROR_MESSAGE", excelValidationHistories.get(0).getVendor() + "has no successful validation history");
                returnMsg.put("MESSAGE", "The latest validation history: <br/>Excel File Path: " + excelValidationHistories.get(0).getExcelPath()
                        + ",<br/>Validation Status: " + excelValidationHistories.get(0).getExcelValidationStatus()
                        + ",<br/>Validation Timestamp: " + excelValidationHistories.get(0).getValidationTimestamp());

            } else {
                mcrDao.updateForMcrAllApproved(mcrId);
                jobGateway.runExcelToStageJob(excelValidationHistories.get(0).getExcelPath(), mcrId);
                returnMsg.put("MESSAGE", "Batch Job [excel-to-stage-job] is triggered.");
                emailGateway.sendMail(
                        mcrId,
                        EmailUseCase.MCR_APPROVAL.name(),
                        "APPROVED",
                        lookupDataService.getUserNameByEmail(approverEmail)
                );

            }
        } else {
            returnMsg.put("MESSAGE", "Thanks for approval, please wait for other approvers to approve this MCR.");
            emailGateway.sendMail(
                    mcrId,
                    EmailUseCase.MCR_APPROVAL.name(),
                    "APPROVED",
                    lookupDataService.getUserNameByEmail(approverEmail)
            );
        }
        return returnMsg;
    }

    /**
     * Reactivate a MCR, which implies that the binding excel is to be re-validated again.
     * @param mcrId mcr id
     * @return a map
     */
    public Map<String, String> reactivateMcr(int mcrId) {
        Map<String, String> returnMsg = new HashMap<String, String>();
        List<ExcelValidationHistory> excelValidationHistories = excelValidationHistoryDao.getLastExcelValidationHistoriesByMcrId(mcrId);
        if (excelValidationHistories.isEmpty()) {
            returnMsg.put("ERROR_MESSAGE", "No successful validation history found for MCR[ID = " + mcrId + "].");
            return returnMsg;
        } else if (excelValidationHistories.get(0) == null
                || excelValidationHistories.get(0).getReactivateValidationStatus() != ExcelValidationStatus.PASSED) {
            returnMsg.put("ERROR_MESSAGE", "The MCR[id=" + mcrId + "] should be validated prior to Reactivation.");
            return returnMsg;
        } else if (!FileChecksumUtils.getChecksum(new File(excelValidationHistories.get(0).getExcelPath())).equals(
                excelValidationHistories.get(0).getExcelFileChecksum())) {
            returnMsg.put("ERROR_MESSAGE", "File has been modified, please re-validate.");
            return returnMsg;
        }
        jobGateway.runExcelToStageJob(excelValidationHistories.get(0).getExcelPath(), mcrId);
        returnMsg.put("MESSAGE", "Batch Job [excel-to-stage-job] is triggered.");
        emailGateway.sendMail(
                mcrId,
                EmailUseCase.MCR_REACTIVATE.name(),
                "",
                ""
        );
        return returnMsg;
    }

    /**
     *
     */
    public void updateMCRAfterProductionReleased() {
        mcrDao.updateMCRAfterProductionReleased();
    }

    /**
     * Get a list of available vendor candidates for a new MCR, one selecting criterion
     * is that the vendor related excel should be validated beforehand.
     */
    public List<ExcelValidationHistory> getAvailableVendorCandidatesForNewMcr() {
        List<ExcelValidationHistory> excelValidationHistories = mcrDao.getAllVendorCandidatesForNewMcr();
//        addVendorDisplayName(excelValidationHistories);
        return excelValidationHistories;
    }

    /**
     *
     * @param excelValidationHistories a list of excel validation history
     */
    private void addVendorDisplayName(List<ExcelValidationHistory> excelValidationHistories) {
        for (ExcelValidationHistory excelValidationHistory : excelValidationHistories) {
            String vendorFullName = menardVendorDao.getVendorFullNameByVendor(excelValidationHistory.getVendor());
            excelValidationHistory.setVendorFullName(vendorFullName);
        }
    }

    /**
     * Get all candidate MCR for production release.
     * @return a list of mcr
     */
    public List<MCR> getAllCandidateMcrForProductionRelease() {
        return mcrDao.getAllCandidateMcrForProductionRelease();
    }

    /**
     * Get all candidate MCR for stage approval.
     * @return a list of mcr
     */
    public List<MCR> getAllCandidateMcrForStageApproval() {
        return mcrDao.getAllCandidateMcrForStageApproval();
    }

    /**
     * Get all candidate MCR for stage approval.
     * @return a list of mcr
     */
    public List<MCR> getMcrListForReactivation() {
        return mcrDao.getMcrListForReactivation();
    }

    /**
     * Get the list of approved MCR list, this list is used on the Reactivate MCR left nav-bar.
     * @return a list of mcr
     */
    public List<MCR> getAllApprovedMcr() {
        return mcrDao.getAllApprovedMcrs();
    }

    public List<MCR> getPendingMcrListWithCatalog() {
        return mcrDao.getPendingMcrListWithCatalog();
    }

    /**
     * Get MCR by ID
     *
     * @param mcrId mcr id
     * @return MCR instance with approvers and approvalHistory all setup
     */
    public MCR getMcrById(int mcrId) {
        MCR mcr = mcrDao.getMcrById(mcrId);
        ExcelValidationHistory excelValidationHistory = excelValidationService.getLastExcelValidationHistoriesByMcrId(mcrId);
        mcr.setExcelPath(excelValidationHistory.getExcelPath());
        setupApprovals(mcr);
        return mcr;
    }

    /**
     *
     * @return a list of mcr
     */
    public List<MCR> getAllInProgressMcr() {
        List<MCR> mcrList = mcrDao.getAllInProgressMcr();
        for (MCR mcr : mcrList) {
            if (!mcr.isAllApproved()) {
                Set<String> allApprovalStatus = mcrApprovalHistoryDao.getAllApprovalStatusByMcrId(mcr.getId());
                if (allApprovalStatus.contains(McrStatus.REJECTED.name())) {
                    mcr.setMcrStatus("REJECTED");
                    continue;
                }
                if (allApprovalStatus.size() > 1) {
                    mcr.setMcrStatus("PARTIALLY_APPROVED");
                    continue;
                }
                mcr.setMcrStatus("NEW_MCR");
                continue;
            }
            if (mcr.isAllApproved() && !mcr.isStageApproved()) {
                mcr.setMcrStatus("ALL_APPROVED");
                continue;
            }
            if (mcr.isAllApproved() && mcr.isStageApproved() && !mcr.isStagePublishedToProduction()) {
                mcr.setMcrStatus("STAGE_APPROVED");
                continue;
            }
            if (mcr.isAllApproved() && mcr.isStageApproved() && mcr.isStagePublishedToProduction()&& !mcr.isProductionReleased()) {
                mcr.setMcrStatus("STAGE_PUBLISHED");
                continue;
            }
            mcr.setMcrStatus("UNKNOWN");
        }
        return mcrList;
    }

    /**
     *
     * @param mcr mcr
     */
    private void setupApprovals(MCR mcr) {
        List<ApprovalHistory> approvalHistory = mcrApprovalHistoryDao.getApprovalHistoryByMcrId(mcr.getId());
        mcr.setApprovalHistories(approvalHistory);
        List<User> approvers = new ArrayList<User>(approvalHistory.size());
        for (ApprovalHistory ah: approvalHistory) {
            approvers.add(ah.getApprovalUser());
        }
        mcr.setApprovers(approvers);
    }


    /**
     *
     * @param mcrId mcr id
     * @return mcr
     */
    public MCR getCompleteMcrDataById(int mcrId) {
        MCR mcr = mcrDao.getMcrById(mcrId);
        ExcelValidationHistory excelValidationHistory =
                excelValidationHistoryDao.getLastExcelValidationHistoriesByMcrId(mcrId).get(0);
        mcr.setLastExcelValidationHistory(excelValidationHistory);
        List<ApprovalHistory> approvalHistoryList = mcrApprovalHistoryDao.getApprovalHistoryByMcrId(mcrId);
        mcr.setApprovalHistories(approvalHistoryList);
        setupApprovals(mcr);
        return mcr;
    }

    /**
     *
     * @param mcrId mcr id
     * @return MCR
     */
    public MCR getSimpleMcrDataById(int mcrId) {
        MCR mcr = mcrDao.getMcrById(mcrId);
        List<ApprovalHistory> approvalHistoryList = mcrApprovalHistoryDao.getApprovalHistoryByMcrId(mcrId);
        mcr.setApprovalHistories(approvalHistoryList);
        return mcr;
    }

    /**
     *
     * @param mcrId mcr id
     */
    public void rollbackMcrStatusForExcelToStageJob(int mcrId) {
        mcrDao.rollbackMcrStatusForExcelStageJob(mcrId);
    }

    /**
     *
     * @param mcrId mcr id
     */
    public void rollbackMcrStatusForStageToProductionJob(int mcrId) {
        mcrDao.rollbackMcrStatusForStageToProductionJob(mcrId);
    }

    /**
     *
     * @param mcrId mcr id
     */
    public void rollbackMcrStatusForProductionReleaseJob(int mcrId) {
        mcrDao.rollbackMcrStatusForStageToProductionJob(mcrId);
    }
}
