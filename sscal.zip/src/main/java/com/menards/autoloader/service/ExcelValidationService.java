package com.menards.autoloader.service;

import com.menards.autoloader.dao.factory.TargetEnvironment;
import com.menards.autoloader.dao.mcr.ExcelValidationHistoryDao;
import com.menards.autoloader.dao.mcr.McrDao;
import com.menards.autoloader.dao.target.BlcCategoryDao;
import com.menards.autoloader.dao.target.MenardVendorDao;
import com.menards.autoloader.domain.mcr.ExcelValidationHistory;
import com.menards.autoloader.domain.mcr.ExcelValidationStatus;
import com.menards.autoloader.utils.ExcelUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 * ---------------------------------------------------------------------------------------------------------------------
 *     Public Validation Methods:
 *     * public List<String> validateRequiredSheets(File excelFile)
 *     * public List<String> validateRequiredFields(File excelFile)
 *     * public List<String> validateUniqueFields(File excelFile)
 *     * public List<String> validateFieldFormatAgainstRegex(File excelFile)
 *     * public List<String> validateDecimalFields(File excelFile)
 *     * public List<String> validateProductFamily(File excelFile)
 *     * public List<String> validateForeignKey(File excelFile)
 *     * public List<String> validateFileExistenceAndSize(File excelFile, File resourceFolder)
 *     *
 * ---------------------------------------------------------------------------------------------------------------------
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class ExcelValidationService {
    private static final Logger LOG = LoggerFactory.getLogger(ExcelValidationService.class);
    @Autowired
    private ExcelValidationHistoryDao excelValidationHistoryDao;

    @Autowired
    private McrDao mcrDao;

    @Autowired
    @Qualifier("productionNonXaJdbcTemplate")
    private JdbcTemplate productionJdbcTemplate;

    @Autowired
    @Qualifier("stageNonXaJdbcTemplate")
    private JdbcTemplate stageJdbcTemplate;

    private BlcCategoryDao productionBlcCategoryDao;

    private BlcCategoryDao stageBlcCategoryDao;

    @Autowired
    @Qualifier("productionMenardVendorDao")
    private MenardVendorDao productionMenardVendorDao;

    @Autowired
    @Qualifier("stageMenardVendorDao")
    private MenardVendorDao stageMenardVendorDao;


    private String stageResourceRootFolder;

    private String productionResourceRootFolder;


    /**
     *
     * @param dateNumber timestamp number
     * @return ExcelValidationHistory
     */
    public ExcelValidationHistory getVendorByValidationDateNumber(Long dateNumber) {
        return excelValidationHistoryDao.getGetVendorByTimestampNumber(dateNumber);
    }

    public List<String> validateForeignKey(File excelFile) throws IOException {
        LOG.info("Validating foreign keys...");
        List<String> validationMessage = new LinkedList<String>();
        Workbook workbook = new HSSFWorkbook(new FileInputStream(excelFile));
        Sheet productUploadSheet = ExcelUtils.getSheetsByNames(workbook, "Product Upload").get(0);
        Set<String> allProductUploadModelNumbers = getAllModuleNumbers(productUploadSheet);
        Sheet skuUploadSheet = ExcelUtils.getSheetsByNames(workbook, "Sku Upload").get(0);
        Set<String> allSkuUploadModelNumbers = getAllModuleNumbers(skuUploadSheet);
        for (String productUploadModelNumber : allProductUploadModelNumbers) {
            if (!allSkuUploadModelNumbers.contains(productUploadModelNumber)) {
                validationMessage.add("Product Upload >> Model_Num " + productUploadModelNumber + " does not exist in Sku Upload >> Model_Num");
            }
        }
        for (String skuUploadModelNumber : allSkuUploadModelNumbers) {
            if (!allProductUploadModelNumbers.contains(skuUploadModelNumber)) {
                validationMessage.add("Sku Upload >> Model_Num " + skuUploadModelNumber + " does not exist in Product Upload >> Model_Num");
            }
        }
        if (!validationMessage.isEmpty()) {
            return validationMessage;
        }
        if (!ExcelUtils.getSheetsByNames(workbook, "Option Upload").isEmpty()) {
            for (Map.Entry<String, List<String>> entry : productionMenardVendorDao.getForeignKeyFields().entrySet()) {
                if(entry.getKey().equalsIgnoreCase("Option Upload")) {
                    List<String> referenceFields = entry.getValue();
                    Sheet optionUploadSheet = ExcelUtils.getSheetsByNames(workbook, "Option Upload").get(0);
                    for (String referenceField : referenceFields) {
                        int referenceFieldIndex = ExcelUtils.getColumnIndexByColumnName(optionUploadSheet, referenceField);
                        for (int i = 1; i <= optionUploadSheet.getLastRowNum(); i++) {
                            String modelNumber = ExcelUtils.getCellValue(optionUploadSheet.getRow(i).getCell(referenceFieldIndex));
                            if (!allProductUploadModelNumbers.contains(modelNumber)) {
                                validationMessage.add("Option Upload >> " + referenceField + " " + modelNumber + " does not exist in Product Upload >> Model_Num");
                            }
                        }

                    }
                }
            }
        }

        if (!ExcelUtils.getSheetsByNames(workbook, "ALTERNATE LOCATIONS").isEmpty()) {
            for (Map.Entry<String, List<String>> entry : productionMenardVendorDao.getForeignKeyFields().entrySet()) {
                if(entry.getKey().equalsIgnoreCase("ALTERNATE LOCATIONS")) {
                    List<String> referenceFields = entry.getValue();
                    Sheet optionUploadSheet = ExcelUtils.getSheetsByNames(workbook, "ALTERNATE LOCATIONS").get(0);
                    for (String referenceField : referenceFields) {
                        int referenceFieldIndex = ExcelUtils.getColumnIndexByColumnName(optionUploadSheet, referenceField);
                        for (int i = 1; i <= optionUploadSheet.getLastRowNum(); i++) {
                            String modelNumber = ExcelUtils.getCellValue(optionUploadSheet.getRow(i).getCell(referenceFieldIndex));
                            if (!allProductUploadModelNumbers.contains(modelNumber)) {
                                validationMessage.add("Alternate Locations >> " + referenceField + " " + modelNumber + " does not exist in Product Upload >> Model_Num");
                            }
                        }

                    }
                }
            }
        }

        return validationMessage;
    }

    private Set getAllModuleNumbers(Sheet sheet) {
        Set<String> allModelNumbers = new HashSet<>();
        int modelNumberColumnIndex = ExcelUtils.getColumnIndexByColumnName(sheet, "Model_Num");
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            String modelNumber = ExcelUtils.getCellValue(sheet.getRow(i).getCell(modelNumberColumnIndex));
            if (modelNumber != null) {
                allModelNumbers.add(modelNumber);
            }
        }
        return allModelNumbers;
    }


    /**
     *
     * @param excelFile excel file
     * @return list of validation message
     * @throws IOException IOException
     */
    public List<String> validateRequiredSheets(File excelFile) throws IOException {
        LOG.info("Validating required excel sheets...");
        List<String> validationMessage = new LinkedList<String>();
        List<String> requiredSheets = productionMenardVendorDao.getRequiredSheetNames();
        Workbook workbook = new HSSFWorkbook(new FileInputStream(excelFile));
        String[] sheetNameArray = new String[]{};
        List<Sheet> excelSheets = ExcelUtils.getSheetsByNames(workbook, requiredSheets.toArray(sheetNameArray));
        for (String requiredSheetName : requiredSheets) {
            boolean found = false;
            for (Sheet excelSheet : excelSheets) {
                if (excelSheet.getSheetName().equalsIgnoreCase(requiredSheetName)) {
                    found =  true;
                    break;
                }
            }
            if (!found) {
                validationMessage.add(requiredSheetName + " is required.");
            }
        }
        if (!validationMessage.isEmpty()) {
            LOG.info("Validation failed.");
        }
        return validationMessage;
    }

    /**
     *
     * @param excelFile excel file
     * @return list of validation message
     * @throws IOException IOException
     */
    public List<String> validateRequiredFields(File excelFile) throws IOException {
        LOG.info("Validating required excel fields...");
        List<String> validationMessage = new LinkedList<String>();
        Map<String, List<String>> requiredFields = productionMenardVendorDao.getRequiredSheetFields();
        Workbook workbook = new HSSFWorkbook(new FileInputStream(excelFile));
        for (Map.Entry<String, List<String>> entry : requiredFields.entrySet()) {
            String sheetName = entry.getKey();
            List<String> requiredFieldNames = entry.getValue();
            List<Sheet> sheetList = ExcelUtils.getSheetsByNames(workbook, sheetName);
            if (sheetList.isEmpty()) continue;
            Sheet sheet = sheetList.get(0);
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;
                for (String fieldName : requiredFieldNames) {
                    int columnIndex = ExcelUtils.getColumnIndexByColumnName(sheet, fieldName);
                    Cell cell = row.getCell(columnIndex);
                    String requiredFieldValue = ExcelUtils.getCellValue(cell);
                    if (requiredFieldValue == null) {
                        validationMessage.add(sheetName + " >> " + fieldName + " at row #" + (i + 1) + " is required.");
                    }
                }
            }
        }
        if (!validationMessage.isEmpty()) {
            LOG.info("Validation failed.");
        }
        return validationMessage;
    }

    /**
     *
     * @param excelFile excel file
     * @return list of validation message
     * @throws IOException IOException
     */
    public List<String> validateUniqueFields(File excelFile) throws IOException {
        LOG.info("Validating required excel unique fields...");
        List<String> validationMessage = new LinkedList<String>();
        Map<String, List<String>> uniqueFields = productionMenardVendorDao.getUniqueSheetFields();
        Workbook workbook = new HSSFWorkbook(new FileInputStream(excelFile));
        for (Map.Entry<String, List<String>> entry : uniqueFields.entrySet()) {
            String sheetName = entry.getKey();
            List<String> uniqueFieldNames = entry.getValue();
            List<Sheet> sheetList = ExcelUtils.getSheetsByNames(workbook, sheetName);
            if (sheetList.isEmpty()) continue;
            Sheet sheet = sheetList.get(0);
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                //Map<[Field Name], List[Field Values]>
                Map<String, List<String>> fieldsValuesMap = new HashMap<String, List<String>>(uniqueFieldNames.size());
                for (String uniqueFieldName : uniqueFieldNames) {
                    int columnIndex = ExcelUtils.getColumnIndexByColumnName(sheet, uniqueFieldName);
                    String uniqueFieldValue = ExcelUtils.getCellValue(row.getCell(columnIndex));
                    if (uniqueFieldValue != null) {
                        if (fieldsValuesMap.get(uniqueFieldName) == null) {
                            fieldsValuesMap.put(uniqueFieldName, new ArrayList<String>());
                        }
                        fieldsValuesMap.get(uniqueFieldName).add(uniqueFieldValue);
                    }
                }
                for (Map.Entry<String, List<String>> fieldsValuesEntry : fieldsValuesMap.entrySet()) {
                    Map<String, Integer> valueCountMap = new HashMap<String, Integer>();
                    List<String> allValues = fieldsValuesEntry.getValue();
                    for (String value : allValues) {
                        if (valueCountMap.get(value) == null) {
                            valueCountMap.put(value, 0);
                        } else {
                            valueCountMap.put(value, (valueCountMap.get(value) + 1));
                        }
                    }
                    for (Map.Entry<String, Integer> valueCountEntry : valueCountMap.entrySet()) {
                        if (valueCountEntry.getValue() > 1) {
                            validationMessage.add(sheetName
                                    + " has duplicate value of "
                                    + valueCountEntry.getKey()
                                    + " for field "
                                    + fieldsValuesEntry.getKey());
                        }
                    }
                }
            }
        }
        if (!validationMessage.isEmpty()) {
            LOG.info("Validation failed.");
        }
        return validationMessage;
    }

    /**
     *
     * @param excelFile excel file
     * @return list of validation message
     * @throws IOException IOException
     */
    public List<String> validateFieldFormatAgainstRegex(File excelFile) throws IOException {
        LOG.info("Validating excel data format against regular expressions...");
        List<String> validationMessage = new LinkedList<String>();
        Map<String, Map<String, String>> regexFormatFields = productionMenardVendorDao.getFieldFormatRegexMap();
        Workbook workbook = new HSSFWorkbook(new FileInputStream(excelFile));
        for (Map.Entry<String, Map<String, String>> regexSheetFieldEntry : regexFormatFields.entrySet()) {
            String sheetName = regexSheetFieldEntry.getKey();
            Map<String, String> fieldRegexMap = regexSheetFieldEntry.getValue();
            List<Sheet> sheetList = ExcelUtils.getSheetsByNames(workbook, sheetName);
            if (sheetList.isEmpty()) continue;
            Sheet sheet = sheetList.get(0);
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                for (Map.Entry<String, String> regexFieldEntry : fieldRegexMap.entrySet()) {
                    String fieldName = regexFieldEntry.getKey();
                    String regex = regexFieldEntry.getValue();
                    int columnIndex = ExcelUtils.getColumnIndexByColumnName(sheet, fieldName);
                    String fieldValue = ExcelUtils.getCellValue(row.getCell(columnIndex));
                    if (fieldValue != null) {
                        if (!fieldValue.matches(regex)) {
                            validationMessage.add(sheetName
                                    + " >> "
                                    + fieldName
                                    + " at row "
                                    + (i + 1)
                                    + "does not match the regular expression "
                                    + regex);
                        }
                    }
                }
            }
        }
        if (!validationMessage.isEmpty()) {
            LOG.info("Validation failed.");
        }
        return validationMessage;
    }

    /**
     *
     * @param excelFile excel file
     * @return list of validation message
     * @throws IOException IOException
     */
    public List<String> validateDecimalFields(File excelFile) throws IOException {
        LOG.info("Validating excel decimal fields...");
        List<String> validationMessage = new LinkedList<String>();
        Map<String, List<String>> decimalSheetFieldMap = productionMenardVendorDao.getDecimalSheetFields();
        Workbook workbook = new HSSFWorkbook(new FileInputStream(excelFile));
        for (Map.Entry<String, List<String>> decimalSheetFieldEntry : decimalSheetFieldMap.entrySet()) {
            String sheetName = decimalSheetFieldEntry.getKey();
            List<String> decimalFields = decimalSheetFieldEntry.getValue();
            List<Sheet> sheetList = ExcelUtils.getSheetsByNames(workbook, sheetName);
            if (sheetList.isEmpty()) continue;
            Sheet sheet = sheetList.get(0);
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                for (String fieldName : decimalFields) {
                    int columnIndex = ExcelUtils.getColumnIndexByColumnName(sheet, fieldName);
                    String fieldValue = ExcelUtils.getCellValue(row.getCell(columnIndex));
                    if (fieldValue != null) {
                        if (row.getCell(columnIndex).getCellType() != Cell.CELL_TYPE_NUMERIC) {
                            validationMessage.add(sheetName
                                    + " >> "
                                    + fieldName
                                    + " at row #"
                                    + (i + 1)
                                    + " should be of decimal format. ");
                        }
                    }
                }
            }
        }
        if (!validationMessage.isEmpty()) {
            LOG.info("Validation failed.");
        }
        return validationMessage;
    }

    /**
     *
     * @param excelFile excel file
     * @return a list of validation message
     */
    public List<String> validateProductFamily(File excelFile) {
        LOG.info("Validating excel product family field...");
        initCategoryDao();
        List<String> validationMessages = new LinkedList<String>();
        Set<String> excelProductFamilies = null;
        IOException ioException = null;
        try {
            excelProductFamilies = getExcelProductFamilies(excelFile);
        } catch (IOException e) {
            ioException = e;
        }
        Assert.isTrue(ioException == null, ioException == null ? "" : ioException.getMessage());
        for (String productFamily : excelProductFamilies) {
            if (!stageBlcCategoryDao.ifUrlKeyExist(productFamily)) {
                validationMessages.add("Product_Family: " + productFamily + " can not be found among STAGE categories.");
            }
            if (!productionBlcCategoryDao.ifUrlKeyExist(productFamily)) {
                validationMessages.add("Product_Family: " + productFamily + " can not be found among PRODUCTION categories.");
            }

        }
        LOG.info(" >>>> Product family validation failure count " + validationMessages.size());
        if (!validationMessages.isEmpty()) {
            LOG.info("Validation failed.");
        }
        return validationMessages;
    }

    /**
     *
     * @param excelFile excel file
     * @return vendor name (vendor logo)
     * @throws IOException IOException
     */
    public String getExcelVendor(File excelFile) throws IOException {
        Workbook workbook = new HSSFWorkbook(new FileInputStream(excelFile));
        String vendor = ExcelUtils.getVendor(workbook);
        Assert.notNull(vendor, "No Vendor_Logo is found in the excel file.");
        return vendor;
    }

    /**
     *
     * @param excelFile excel file
     * @param resourceFolder resource folder
     * @return a lit of validation message
     * @throws IOException io exception
     */
    public List<String> validateFileExistenceAndSize(File excelFile, File resourceFolder) throws IOException {
        LOG.info("Validating media files...");
        checkParameters(excelFile, resourceFolder);
        List<String> validationMessages = new LinkedList<String>();
        validationMessages.addAll(checkFileExistenceAndSizeOnStage(excelFile, resourceFolder));
        validationMessages.addAll(checkFileExistenceAndSizeOnProduction(excelFile, resourceFolder));
        return validationMessages;
    }

    /**
     *
     * @param excelFile excel file
     * @param resourceFolder resource folder
     * @throws IOException io exception
     */
    private void checkParameters(File excelFile, File resourceFolder) throws IOException {
        Assert.isTrue(excelFile.exists(), excelFile.getCanonicalPath() + " does not exist.");
        Assert.isTrue(resourceFolder.exists(), resourceFolder.getCanonicalPath() + " does not exist.");
        Assert.isTrue(!excelFile.isDirectory(), excelFile.getCanonicalPath() + " should not be a directory.");
        Assert.isTrue(excelFile.getName().endsWith("xls"), excelFile.getCanonicalPath() + " should be an excel file(.xls).");
        Assert.isTrue(resourceFolder.exists(), resourceFolder.getCanonicalPath() + " does not exist.");
        Assert.isTrue(resourceFolder.isDirectory(), resourceFolder.getCanonicalPath() + " should be a directory.");

    }

    /**
     *
     * @param excelFile excel file
     * @param resourceFolder resource folder
     * @return a list of validation message
     * @throws IOException io exception
     */
    private List<String> checkFileExistenceAndSizeOnStage(File excelFile, File resourceFolder) throws IOException {
        return checkFileExistenceAndSizeOnSingleEnvironment(excelFile, resourceFolder, TargetEnvironment.STAGE);
    }

    /**
     *
     * @param excelFile excel file
     * @param resourceFolder resource folder
     * @return a list of validation message
     * @throws IOException io exception
     */
    private List<String> checkFileExistenceAndSizeOnProduction(File excelFile, File resourceFolder) throws IOException {
        return checkFileExistenceAndSizeOnSingleEnvironment(excelFile, resourceFolder, TargetEnvironment.PRODUCTION);
    }

    /**
     *
     * @param excelFile excel file
     * @param resourceFolder resource folder
     * @param targetEnvironment target environment
     * @return a list of validation message
     * @throws IOException io exception
     */
    private List<String> checkFileExistenceAndSizeOnSingleEnvironment(File excelFile,
                                                                      File resourceFolder,
                                                                      TargetEnvironment targetEnvironment)
            throws IOException {
        List<String> validationMessages = new LinkedList<String>();
        MenardVendorDao menardVendorDao = getTargetMenardVendorDao(targetEnvironment);
        Workbook workbook = new HSSFWorkbook(new FileInputStream(excelFile));
        String vendor = ExcelUtils.getVendor(workbook);
        List<Sheet> allSheets = ExcelUtils.getSheetsByNames(workbook, "Product Upload", "Sku Upload");
        for (Sheet sheet : allSheets) {
            Set<String> columnHeaders = ExcelUtils.getSheetColumnHeaders(sheet);
            for (String columnHeader : columnHeaders) {
                if (menardVendorDao.isFileColumn(columnHeader)) {
                    LOG.info("Checking file existence and its size specified by " + columnHeader
                            + " in sheet " + sheet.getSheetName());
                    validationMessages.addAll(
                            checkFileExistenceAndSizeForSingleColumn(
                                    sheet,
                                    columnHeader,
                                    resourceFolder,
                                    vendor,
                                    targetEnvironment
                            )
                    );
                }
            }
        }
        LOG.info("File existence and size check for " + targetEnvironment.name() + " is done.");
        return validationMessages;
    }

    /**
     * Get MenardVendorDao by the target environment
     * @param targetEnvironment target environment
     * @return MenardVendorDao object
     */
    private MenardVendorDao getTargetMenardVendorDao(TargetEnvironment targetEnvironment) {
        switch (targetEnvironment) {
            case PRODUCTION: return this.productionMenardVendorDao;
            case STAGE: return this.stageMenardVendorDao;
            default: return null;
        }
    }

    /**
     *
     * @param targetEnvironment target environment
     * @return root folder for resource files on the target environment
     */
    private String getTargetRootResourceFolder(TargetEnvironment targetEnvironment) {
        switch (targetEnvironment) {
            case PRODUCTION: return this.productionResourceRootFolder;
            case STAGE: return this.stageResourceRootFolder;
            default: return null;
        }
    }

    /**
     *
     * @param sheet poi excel sheet
     * @param columnHeader column header
     * @param resourceFolder resource folder
     * @param vendor vendor
     * @param targetEnvironment target environment
     * @return a list of validation message
     */
    private List<String> checkFileExistenceAndSizeForSingleColumn(Sheet sheet,
                                                                  String columnHeader,
                                                                  File resourceFolder,
                                                                  String vendor,
                                                                  TargetEnvironment targetEnvironment) {
        MenardVendorDao menardVendorDao = getTargetMenardVendorDao(targetEnvironment);
        String rootResourceFolder = getTargetRootResourceFolder(targetEnvironment);
        String relativeFilePath = menardVendorDao.getRelativePath(columnHeader, vendor);
        String targetRootResourceFolderAbsolutePath = rootResourceFolder + relativeFilePath;
        List<File> allExistingFiles = getAllFiles(resourceFolder, new File(targetRootResourceFolderAbsolutePath));
        List<File> allSourceResourceFiles = new ArrayList<File>(FileUtils.listFiles(resourceFolder, new String[]{"jpg", "pdf", "JPG", "PDF"}, true));
        List<String> validationMessages = new LinkedList<String>();
        int columnIndex = ExcelUtils.getColumnIndexByColumnName(sheet, columnHeader);
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Cell fileCell = sheet.getRow(i).getCell(columnIndex);
            if (fileCell == null) continue; //it's not a required column, so just skip it.
            String fileName = ExcelUtils.getCellValue(fileCell);
            if (fileName == null) continue; //it's not a required column, so just skip it.
            if (!checkSingleFileExistence(fileName, allExistingFiles) && !checkSingleFileExistence(fileName, allSourceResourceFiles)) {
                validationMessages.add(
                        "File specified at row " + (i + 1) + ", column " + (columnIndex + 1)
                        + " of sheet " + sheet.getSheetName()
                        + " does not exist on either source resource folder or target resource folder on "
                        + targetEnvironment.name() + ".");
            } else if (checkSingleFileExistence(fileName, allSourceResourceFiles) &&
                    !checkFileSize(columnHeader, fileName, allSourceResourceFiles)) {
                validationMessages.add(
                        "The size of the file specified at row " + (i + 1) + ", column " + (columnIndex + 1)
                        + " of sheet " + sheet.getSheetName()
                        + " should not exceed the max size of "
                        + stageMenardVendorDao.getAllowedMaxFileSize(columnHeader) + "KB."
                        );
            }
        }
        return validationMessages;
    }

    /**
     *
     * @param columnHeader column header
     * @param fileName file name
     * @param allSourceResourceFiles all source resource files
     * @return a flag shown whether the file is existing or not
     */
    private boolean checkFileSize(String columnHeader, String fileName, Collection<File> allSourceResourceFiles) {

        for (File file : allSourceResourceFiles) {
            if (fileName.equalsIgnoreCase(file.getName())) {
                return checkSingleFileSize(columnHeader, file);
            }
        }
        return false;
    }

    /**
     *
     * @param columnHeader column header
     * @param file file
     * @return a flag shown whether the file is existing or not
     */
    private boolean checkSingleFileSize(String columnHeader, File file) {
        Double maxSize = stageMenardVendorDao.getAllowedMaxFileSize(columnHeader);
        if (maxSize == null) {
            return false;
        }
        double fileSizeInKB = file.length() / 1024;
        if (fileSizeInKB > maxSize) {
            return false;
        }
        return true;
    }

    /**
     *
     * @param fileName file name
     * @param allExistingFiles all existing files
     * @return a flag shown whether the file is existing or not
     */
    private boolean checkSingleFileExistence(String fileName, List<? extends File> allExistingFiles) {
        for (File file : allExistingFiles) {
            if (file.getName().equalsIgnoreCase(fileName)) {
                return true;
            }
        }
        return false;
    }

    /**
     *
     * @param folders an array of folder
     * @return a list of file
     */
    private List<File> getAllFiles(File... folders) {
        List<File> allFiles = new LinkedList<File>();
        for (File folder : folders) {
            if (folder.exists()) {
                allFiles.addAll(FileUtils.listFiles(folder, new String[]{"jpg", "pdf", "JPG", "PDF"}, true));
            }
        }
        return allFiles;
    }

    /**
     *
     * @param vendor vendor
     * @return ExcelValidationStatus
     */
    public ExcelValidationStatus checkLatestVendorExcelValidationStatus(String vendor) {
        return excelValidationHistoryDao.getLatestValidationStatusByVendor(vendor);
    }

    /**
     *
     * @param excelValidationHistory an object of ExcelValidationHistory
     */
    public void addExcelValidationHistory(ExcelValidationHistory excelValidationHistory) {
        boolean isForReactivation = mcrDao.isInProgressMcrCreatedForVendor(excelValidationHistory.getVendor());
        excelValidationHistoryDao.insertValidationHistory(excelValidationHistory, isForReactivation);
    }

    /**
     *
     * @param timestampNumber timestamp in number form
     * @return log content
     */
    public String getExcelValidationHistoryLog(Long timestampNumber) {
        return excelValidationHistoryDao.getValidationHistoryLogByTimestampNumber(timestampNumber);
    }

    /**
     *
     * @param timestampNumber timestamp in number form
     * @return excel binary content
     */
    public byte[] getExcelFileContent(Long timestampNumber) {
        return excelValidationHistoryDao.getValidationHistoryExcelFileByTimestampNumber(timestampNumber);
    }

    /**
     *
     * @param vendor vendor
     */
    public void purgeValidationHistoryByVendor(String vendor) {
        excelValidationHistoryDao.deleteValidationHistoryByVendor(vendor);
    }

    /**
     *
     * @param mcrId mcr id
     * @return an object of ExcelValidationHistory
     */
    public ExcelValidationHistory getLastExcelValidationHistoriesByMcrId(int mcrId) {
        List<ExcelValidationHistory> validationHistories =
                excelValidationHistoryDao.getLastExcelValidationHistoriesByMcrId(mcrId);
        Assert.isTrue(validationHistories.size() > 0, "No excel validation history found for MCR ID [" + mcrId + "]");
        return validationHistories.get(0);
    }

    /**
     * initialize productionBlcCategoryDao and stageBlcCategoryDao
     */
    private void initCategoryDao() {
        if (productionBlcCategoryDao == null) {
            productionBlcCategoryDao = new BlcCategoryDao(productionJdbcTemplate);
        }
        if (stageBlcCategoryDao == null) {
            stageBlcCategoryDao = new BlcCategoryDao(stageJdbcTemplate);
        }
    }

    /**
     *
     * @param excelFile excel file
     * @return return a set of distinct product families in the given excel file.
     * @throws IOException io exception
     */
    private Set<String> getExcelProductFamilies(File excelFile) throws IOException {
        Workbook workbook = new HSSFWorkbook(new FileInputStream(excelFile));
        List<Sheet> sheets = ExcelUtils.getSheetsByNames(workbook, "Product Upload", "Alternate Locations");
        Assert.isTrue(!sheets.isEmpty(), "No sheet named \"Product Upload\" found in the " + excelFile.getCanonicalPath());
        Set<String> productFamilies = new HashSet<String>();
        for (Sheet sheet : sheets) {
            productFamilies.addAll(getDistinctProductFamilies(sheet));
        }
        return productFamilies;
    }

    /**
     * Get all distinct product families from a given sheet
     * @param sheet a POI {@link org.apache.poi.ss.usermodel.Sheet}
     * @return a set of product families.
     */
    private Set<String> getDistinctProductFamilies(Sheet sheet) {
        Set<String> returnSet = new HashSet<String>();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) {
                break;
            }
            int productFamilyColumnIndex = ExcelUtils.getColumnIndexByColumnName(sheet, "Product_Family");
            Assert.isTrue(productFamilyColumnIndex >= 0,
                    "No column named \"Product_Family\" in the sheet " + sheet.getSheetName());
            Cell cell = row.getCell(productFamilyColumnIndex);
            String cellValue = ExcelUtils.getCellValue(cell);
            if (StringUtils.isNotEmpty(cellValue)) {
                returnSet.add(cellValue);
            }

        }
        return returnSet;
    }

    /**
     *
     * @return a list of ExcelValidationHistory
     */
    public List<ExcelValidationHistory> getAllExcelValidationHistory() {
        return excelValidationHistoryDao.getAllExcelValidationHistory();
    }

    /**
     *
     * @param vendor vendor name
     * @return a list of ExcelValidationHistory
     */
    public List<ExcelValidationHistory> getAllExcelValidationHistory(String vendor) {
        return excelValidationHistoryDao.getAllExcelValidationHistoryByVendor(vendor);
    }

    public void setStageResourceRootFolder(String stageResourceRootFolder) {
        this.stageResourceRootFolder = stageResourceRootFolder;
    }

    public void setProductionResourceRootFolder(String productionResourceRootFolder) {
        this.productionResourceRootFolder = productionResourceRootFolder;
    }
}
