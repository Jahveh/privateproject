package com.menards.autoloader.service;

import com.menards.autoloader.dao.mcr.UserDao;
import com.menards.autoloader.domain.mcr.User;
import com.menards.autoloader.security.MenardSecurityDelegate;
import com.menards.mymenards.integration.vo.SecureUser;
import com.menards.mymenards.integration.vo.Systems;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Service
public class SecureUserService {
    @Autowired
    private MenardSecurityDelegate securityDelegate;

    @Autowired
    private UserDao userDao;

    /**
     *
     * @param userName user name
     * @return an object of SecureUser
     */
    public SecureUser getSecureUser(String userName) {
        return securityDelegate.getUser(userName, Systems.CATALOGS);
    }

    /**
     *
     * @param userName user name
     * @return a flag
     * @throws IOException io exception
     */
    public boolean isAdminUser(String userName) throws IOException {
        for (User user : userDao.getAllAdministrators()) {
            if (user.getName().equalsIgnoreCase(userName)) {
                return true;
            }
        }
        return false;
    }

    /**
     *
     * @param user user object
     */
    public void enrichSecureUser(User user) {
        String email = user.getEmail();
        String ntName = email.substring(0, email.indexOf('@'));
        SecureUser secureUser = securityDelegate.getUser(ntName, Systems.CATALOGS);
        String department = secureUser.getDepartmentName();
        String phone = secureUser.getPhone();
        user.setDepartment(department);
        user.setPhone(phone);
    }
}
