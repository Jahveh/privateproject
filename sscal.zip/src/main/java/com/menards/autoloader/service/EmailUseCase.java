package com.menards.autoloader.service;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public enum EmailUseCase {
    NEW_MCR,
    MCR_APPROVAL,
    MCR_REACTIVATE,
    MCR_STAGE_APPROVAL,
    MCR_STAGE_PUBLISH,
    MCR_PRODUCTION_RELEASE,
    EXCEL_TO_STAGE_JOB_FAILURE,
    PRODUCTION_RELEASE_JOB_FAILURE,
    STAGE_TO_PRODUCTION_JOB_FAILURE
}
