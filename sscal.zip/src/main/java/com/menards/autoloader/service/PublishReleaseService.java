package com.menards.autoloader.service;

import com.menards.autoloader.dao.mcr.McrDao;
import com.menards.autoloader.dao.mcr.McrStageApprovalDao;
import com.menards.autoloader.domain.mcr.StageApprovalInfo;
import com.menards.autoloader.integration.gateway.EmailGateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Service
public class PublishReleaseService {

    @Autowired
    private EmailGateway emailGateway;

	@Autowired
    private McrStageApprovalDao stageApprovalDao;

    @Autowired
    private McrDao mcrDao;

    /**
     *
     * @param stageApproval stage approval
     */
	public void stageApproved(StageApprovalInfo stageApproval) {
        stageApprovalDao.insertIntoStageApproval(stageApproval);
        mcrDao.mcrStageApprove(stageApproval.getMcrId());
        emailGateway.sendMail(
                stageApproval.getMcrId(),
                EmailUseCase.MCR_STAGE_APPROVAL.name(),
                "APPROVED",
                stageApproval.getApprovalName()
        );
	}



}
