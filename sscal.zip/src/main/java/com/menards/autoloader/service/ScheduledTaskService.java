package com.menards.autoloader.service;

import com.menards.autoloader.dao.mcr.McrDao;
import com.menards.autoloader.integration.gateway.JobGateway;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Service
public class ScheduledTaskService {

    private static final Logger LOG = org.slf4j.LoggerFactory.getLogger(ScheduledTaskService.class);

    @Autowired
    private McrDao mcrDao;

    @Autowired
    private JobGateway jobGateway;

    /**
     *
     */
    public void stagePublishForMcr() {
        LOG.info("................... Job [stagePublishForMcr] is triggered ...............");
        List<Integer> mcrIdList =  mcrDao.getMcrForStagePublish();
        for (int mcrId : mcrIdList) {
            LOG.info("...................Stage Publish for MCR " + mcrId);
            jobGateway.runStageToProductionJob(mcrId);
        }
    }

    /**
     *
     */
    public void productionRelease() {
        LOG.info("................... Job [productionRelease] is triggered ...............");
        jobGateway.runProductionReleaseJob("dullParam");
    }
}
