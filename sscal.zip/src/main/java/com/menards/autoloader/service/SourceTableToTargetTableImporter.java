package com.menards.autoloader.service;

import com.menards.autoloader.dao.IDao;
import com.menards.autoloader.dao.factory.DaoNames;
import com.menards.autoloader.dao.factory.IDaoFactory;
import com.menards.autoloader.dao.target.BlcProductDao;
import com.menards.autoloader.dao.target.BlcProductSkuXrefDao;
import com.menards.autoloader.dao.target.BlcSkuDao;
import com.menards.autoloader.dao.target.MenardVendorDao;

import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;


/**
 * <p>SourceToTargetImporter</p>
 * <p>A service class for moving data from source tables to target business tables.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class SourceTableToTargetTableImporter {
    // ***************DAOs*******************
    // for Source tables..
    private IDao<List<Map<String, String>>> sourceBlcProductDao;
    private IDao<List<Map<String, String>>> sourceBlcProductAttributeDao;
    private IDao<List<Map<String, String>>> sourceBlcCategoryProductXrefDao;
    private IDao<List<Map<String, String>>> sourceBlcProductSkuXrefDao;
    private IDao<List<Map<String, String>>> sourceBlcSkuDao;
    private IDao<List<Map<String, String>>> sourceBlcSkuAttributeDao;
    private IDao<List<Map<String, String>>> sourceMenardProductDao;
    private IDao<List<Map<String, String>>> sourceMenardProductOptionDao;
    private IDao<List<Map<String, String>>> sourceMenardSkuDao;

    // for Target tables..
    private IDao<List<Map<String, String>>> targetBlcProductDao;
    private IDao<List<Map<String, String>>> targetBlcProductAttributeDao;
    private IDao<List<Map<String, String>>> targetBlcCategoryProductXrefDao;
    private IDao<List<Map<String, String>>> targetBlcProductSkuXrefDao;
    private IDao<List<Map<String, String>>> targetBlcSkuDao;
    private IDao<List<Map<String, String>>> targetBlcSkuAttributeDao;
    private IDao<List<Map<String, String>>> targetMenardProductDao;
    private IDao<List<Map<String, String>>> targetMenardProductOptionDao;
    private IDao<List<Map<String, String>>> targetMenardSkuDao;
    private MenardVendorDao targetMenardVendorDao;

    //***************Data List*****************
    //from Source tables..
    private List<Map<String, String>> sourceBlcProducts;
    private List<Map<String, String>> sourceBlcProductAttributes;
    private List<Map<String, String>> sourceBlcCategoryProductXrefs;
    private List<Map<String, String>> sourceBlcProductSkuXrefs;
    private List<Map<String, String>> sourceBlcSkus;
    private List<Map<String, String>> sourceBlcSkuAttributes;
    private List<Map<String, String>> sourceMenardProducts;
    private List<Map<String, String>> sourceMenardProductOptions;
    private List<Map<String, String>> sourceMenardSkus;

    //from Target tables..
    private List<Map<String, String>> targetBlcProducts;

    // data for BLC_PRODUCT is divided into 2 groups: update-product, add-product..
    private List<Map<String, String>> updateProducts;
    private List<Map<String, String>> addProducts;
    private List<String> deleteProductIDs;

    // Max IDs in target table..
    private Long maxTargetProductId;
    private Long maxTargetSkuId;
    private Long maxTargetProductAttributeId;
    private Long maxTargetSkuAttributeId;

    //Mappings of product IDs between source tables and target tables..
    private Map<String, String> updateProductIdMap;
    private Map<String, String> addProductIdMap;

    //Mappings of productId and skuId
    private Map<String, String> productSkuIdMap = new HashMap<String, String>();

    private static final String JOIN_DELIMITER = "#|#";

    /**
     * A default constructor method for CGLib proxying this class.
     */
    public SourceTableToTargetTableImporter() { }

    /**
     * A constructor method that accepts both source and target Dao factories.
     * @param sourceDaoFactory the source Dao factory.
     * @param targetDaoFactory the target Dao factory.
     */
    public SourceTableToTargetTableImporter(IDaoFactory<List<Map<String, String>>> sourceDaoFactory,
                                  IDaoFactory<List<Map<String, String>>> targetDaoFactory) {
        this.sourceBlcProductDao = sourceDaoFactory.getDao(DaoNames.SOURCE_BLC_PRODUCT_DAO);
        this.sourceBlcProductAttributeDao =
                sourceDaoFactory.getDao(DaoNames.SOURCE_BLC_PRODUCT_ATTRIBUTE_DAO);
        this.sourceBlcCategoryProductXrefDao =
                sourceDaoFactory.getDao(DaoNames.SOURCE_BLC_CATEGORY_PRODUCT_XREF_DAO);
        this.sourceBlcProductSkuXrefDao =
                sourceDaoFactory.getDao(DaoNames.SOURCE_BLC_PRODUCT_SKU_XREF_DAO);
        this.sourceBlcSkuDao = sourceDaoFactory.getDao(DaoNames.SOURCE_BLC_SKU_DAO);
        this.sourceBlcSkuAttributeDao = sourceDaoFactory.getDao(DaoNames.SOURCE_BLC_SKU_ATTRIBUTE_DAO);
        this.sourceMenardProductDao = sourceDaoFactory.getDao(DaoNames.SOURCE_MENARD_PRODUCT_DAO);
        this.sourceMenardProductOptionDao =
                sourceDaoFactory.getDao(DaoNames.SOURCE_MENARD_PRODUCT_OPTION_DAO);
        this.sourceMenardSkuDao = sourceDaoFactory.getDao(DaoNames.SOURCE_MENARD_SKU_DAO);

        this.targetBlcProductDao = targetDaoFactory.getDao(DaoNames.BLC_PRODUCT_DAO);
        this.targetBlcProductAttributeDao = targetDaoFactory.getDao(DaoNames.BLC_PRODUCT_ATTRIBUTE_DAO);
        this.targetBlcCategoryProductXrefDao = targetDaoFactory.getDao(DaoNames.BLC_CATEGORY_PRODUCT_XREF_DAO);
        this.targetBlcProductSkuXrefDao = targetDaoFactory.getDao(DaoNames.BLC_PRODUCT_SKU_XREF_DAO);
        this.targetBlcSkuDao = targetDaoFactory.getDao(DaoNames.BLC_SKU_DAO);
        this.targetBlcSkuAttributeDao = targetDaoFactory.getDao(DaoNames.BLC_SKU_ATTRIBUTE_DAO);
        this.targetMenardProductDao = targetDaoFactory.getDao(DaoNames.MENARD_PRODUCT_DAO);
        this.targetMenardProductOptionDao = targetDaoFactory.getDao(DaoNames.MENARD_PRODUCT_OPTION_DAO);
        this.targetMenardSkuDao = targetDaoFactory.getDao(DaoNames.MENARD_SKU_DAO);
        this.targetMenardVendorDao = (MenardVendorDao) targetDaoFactory.getDao(DaoNames.MENARD_VENDOR_DAO);
    }

    /**
     * Start import process.
     * @param mcrId mcr id
     */
    public void importDataForMcr(int mcrId) {
        try {
            loadAllSourceData(mcrId);
            Assert.isTrue(!this.sourceBlcProducts.isEmpty(), "No Product Data is found in the SOURCE tables.");
            Set<String> vendorLogos = new HashSet<String>();
            for (Map<String, String> map : this.sourceBlcProducts) {
                vendorLogos.add(map.get("VENDOR_LOGO"));
            }
            this.targetBlcProducts = this.targetBlcProductDao.getDataByVendor(vendorLogos);
            addModelNumVendor(this.sourceBlcProducts);
            addModelNumVendor(this.targetBlcProducts);
            prepareMergeData();
            persistData();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            cleanUp();
        }
    }

    /**
     * clean up
     */
    private void cleanUp() {
        if (this.sourceBlcProducts != null) {
            this.sourceBlcProducts.clear();
        }
        if (this.sourceBlcProductAttributes != null) {
            this.sourceBlcProductAttributes.clear();
        }
        if (this.sourceBlcCategoryProductXrefs != null) {
            this.sourceBlcCategoryProductXrefs.clear();
        }
        if (this.sourceBlcProductSkuXrefs != null) {
            this.sourceBlcProductSkuXrefs.clear();
        }
        if (this.sourceBlcSkus != null) {
            this.sourceBlcSkus.clear();
        }
        if (this.sourceBlcSkuAttributes != null) {
            this.sourceBlcSkuAttributes.clear();
        }
        if (this.sourceMenardProducts != null) {
            this.sourceMenardProducts.clear();
        }
        if (this.sourceMenardProductOptions != null) {
            this.sourceMenardProductOptions.clear();
        }
        if (this.sourceMenardSkus != null) {
            this.sourceMenardSkus.clear();
        }
        if (this.targetBlcProducts != null) {
            this.targetBlcProducts.clear();
        }
        if (this.updateProducts != null) {
            this.updateProducts.clear();
        }
        if (this.addProducts != null) {
            this.addProducts.clear();
        }
        if (this.deleteProductIDs != null) {
            this.deleteProductIDs.clear();
        }
        if (this.maxTargetProductId != null) {
            this.maxTargetProductId = null;
        }
        if (this.maxTargetSkuId != null) {
            this.maxTargetSkuId = null;
        }
        if (this.maxTargetProductAttributeId != null) {
            this.maxTargetProductAttributeId = null;
        }
        if (this.maxTargetSkuAttributeId != null) {
            this.maxTargetSkuAttributeId = null;
        }
        if (this.updateProductIdMap != null) {
            this.updateProductIdMap.clear();
        }
        if (this.addProductIdMap != null) {
            this.addProductIdMap.clear();
        }
        if (this.productSkuIdMap != null) {
            this.productSkuIdMap.clear();
        }
    }

    /**
     * Load all source table data.
     * @param mcrId mcr id
     */
    private void loadAllSourceData(int mcrId) {
        this.sourceBlcProducts = sourceBlcProductDao.getAllDataByMcrId(mcrId);
        this.sourceBlcProductAttributes = sourceBlcProductAttributeDao.getAllDataByMcrId(mcrId);
        this.sourceBlcCategoryProductXrefs = sourceBlcCategoryProductXrefDao.getAllDataByMcrId(mcrId);
        this.sourceBlcProductSkuXrefs = sourceBlcProductSkuXrefDao.getAllDataByMcrId(mcrId);
        this.sourceBlcSkus = sourceBlcSkuDao.getAllDataByMcrId(mcrId);
        this.sourceBlcSkuAttributes = sourceBlcSkuAttributeDao.getAllDataByMcrId(mcrId);
        this.sourceMenardProducts = sourceMenardProductDao.getAllDataByMcrId(mcrId);
        this.sourceMenardProductOptions = sourceMenardProductOptionDao.getAllDataByMcrId(mcrId);
        this.sourceMenardSkus = sourceMenardSkuDao.getAllDataByMcrId(mcrId);
        this.maxTargetProductId = targetBlcProductDao.getMaxId();
        this.maxTargetSkuId = targetBlcSkuDao.getMaxId();
        this.maxTargetProductAttributeId = targetBlcProductAttributeDao.getMaxId();
        this.maxTargetSkuAttributeId = targetBlcSkuAttributeDao.getMaxId();
        prepareFileUrlForAttributeTables(sourceBlcProductAttributes);
        prepareFileUrlForAttributeTables(sourceBlcSkuAttributes);
    }

    /**
     *
     * @param attributeList attribute list
     */
    private void prepareFileUrlForAttributeTables(List<Map<String, String>> attributeList ) {
        for (Map<String, String> attributes : attributeList) {
            if (targetMenardVendorDao.isFileColumn(attributes.get("NAME"))) {
                String relativePath = targetMenardVendorDao.getRelativePath(attributes.get("NAME"), attributes.get("VENDOR_LOGO"));
                String fullPath = relativePath + attributes.get("VALUE");
                attributes.put("VALUE", fullPath);
            }
        }
    }

    /**
     * Merge all spread sheet data into db data.
     */
    private void prepareMergeData() {
        this.updateProducts = new ArrayList<Map<String, String>>();
        List<String> updateTempList = getModelNumVendorCollection(this.sourceBlcProducts);
        List<String> targetTempList = getModelNumVendorCollection(this.targetBlcProducts);
        // <1> update-product set..
        updateTempList.retainAll(targetTempList);
        List<String> addProductModelVendorList = getModelNumVendorCollection(this.sourceBlcProducts);
        // <2> add-product set..
        addProductModelVendorList.removeAll(targetTempList);
        List<String> sourceTempList = getModelNumVendorCollection(this.sourceBlcProducts);
        List<String> deleteTempList = targetTempList;
        // <3> delete-product set..
        deleteTempList.removeAll(sourceTempList);
        prepareDeleteData(deleteTempList);
        prepareUpdateData(updateTempList);
        prepareAddData(addProductModelVendorList);
        updateProductUrlForSourceBlcProduct();
        assignNewSkuId();
        Assert.isTrue(this.sourceBlcProducts.size() == updateProducts.size() + addProducts.size(),
                "Total number of add-products and update-products should be same with that of sourceBlcProducts.");

    }

    /**
     * Save data to DB.
     */
    private void persistData() {
        backUpData();
        persistDeleteData();
        persistUpdateData();
        persistAddData();
    }

    /**
     * Backup data before new data get persisted to the DB.
     */
    private void backUpData() {
        this.targetBlcProductDao.backUpTable();
        this.targetBlcProductAttributeDao.backUpTable();
        this.targetBlcCategoryProductXrefDao.backUpTable();
        this.targetBlcProductSkuXrefDao.backUpTable();
        this.targetBlcSkuDao.backUpTable();
        this.targetBlcSkuAttributeDao.backUpTable();
        this.targetMenardProductDao.backUpTable();
        this.targetMenardProductOptionDao.backUpTable();
        this.targetMenardSkuDao.backUpTable();
    }

    /**
     * Persist data needs to be deleted.
     */
    private void persistDeleteData() {
        if (!this.deleteProductIDs.isEmpty()) {
            this.targetBlcProductDao.batchDeleteByProductId(this.deleteProductIDs);
            this.targetBlcSkuDao.batchDeleteByProductId(this.deleteProductIDs);
        }
    }

    /**
     * Persist data needs to be updated.
     */
    private void persistUpdateData() {
        List<String> productIDs = new ArrayList<String>(this.updateProductIdMap.values());
        BlcProductDao blcProductDao = (BlcProductDao) this.targetBlcProductDao;
        if (!this.updateProducts.isEmpty()) {
            blcProductDao.batchUpdateProductById(this.updateProducts);
        }
        updateCategoryProductXref();
        updateProductSkuXref();
        updateMenardProductOption();
        updateProductAttribute();
        updateSkuAttribute();
        updateMenardSku();
        updateMenardProduct(); //empty method
        updateSku(); //empty method
    }

    /**
     *
     */
    private void updateMenardSku() {
        this.targetMenardSkuDao.batchDeleteByProductId(
                new ArrayList<String>(this.updateProductIdMap.values())
        );
        List<Map<String, String>> menardSkus = new ArrayList<Map<String, String>>();
        for (Map.Entry<String, String> entry : updateProductIdMap.entrySet()) {
            for (Map<String, String> sourceMenardSkuMap : this.sourceMenardSkus) {
                if (entry.getValue().equals(getProductIdBySkuId(sourceMenardSkuMap.get("SKU_ID")))) {
                    menardSkus.add(sourceMenardSkuMap);
                }
            }
        }
        this.targetMenardSkuDao.batchInsert(menardSkus);
    }

    /**
     *
     */
    private void updateMenardProductOption() {
        this.targetMenardProductOptionDao.batchDeleteByProductId(
                new ArrayList<String>(this.updateProductIdMap.values())
        );
        List<Map<String, String>> menardProductOptions = new ArrayList<Map<String, String>>();
        for (Map.Entry<String, String> entry : updateProductIdMap.entrySet()) {
            for (Map<String, String> sourceMenardProductOptionMap : this.sourceMenardProductOptions) {
                if (entry.getValue().equals(sourceMenardProductOptionMap.get("BASE_PRODUCT_ID"))) {
                    menardProductOptions.add(sourceMenardProductOptionMap);
                }
            }
        }
        this.targetMenardProductOptionDao.batchInsert(menardProductOptions);
    }

    /**
     *
     */
    private void updateMenardProduct() {
        //left blank deliberately since the MENARD_PRODUCT table is just a mapping of product_id and model_num
    }

    /**
     *
     */
    private void updateSkuAttribute() {
        this.targetBlcSkuAttributeDao.batchDeleteByProductId(
                new ArrayList<String>(this.updateProductIdMap.values())
        );
        List<Map<String, String>> skuAttributes = new LinkedList<Map<String, String>>();
        for (Map.Entry<String, String> entry : updateProductIdMap.entrySet()) {
            for (Map<String, String> sourceSkuAttrMap : this.sourceBlcSkuAttributes) {
                if (entry.getValue().equals(getProductIdBySkuId(sourceSkuAttrMap.get("SKU_ID")))) {
                    skuAttributes.add(sourceSkuAttrMap);
                }
            }
        }
        this.targetBlcSkuAttributeDao.batchInsert(skuAttributes);
    }

    /**
     *
     * @param skuId sku id
     * @return product id
     */
    private String getProductIdBySkuId(String skuId) {
        return productSkuIdMap.get(skuId);
    }

    /**
     * update sku
     */
    private void updateSku() {
        //left blank deliberately since the BLC_SKU table is just a mapping of sku_id and product_id
    }

    /**
     *
     */
    private void updateProductAttribute() {
        this.targetBlcProductAttributeDao.batchDeleteByProductId(
            new ArrayList<String>(this.updateProductIdMap.values())
        );
        List<Map<String, String>> productAttributes = new LinkedList<Map<String, String>>();
        for (Map.Entry<String, String> entry : updateProductIdMap.entrySet()) {
            for (Map<String, String> map : this.sourceBlcProductAttributes) {
                if (map.get("PRODUCT_ID").equals(entry.getValue())) {
                    Map<String, String> productAttribute = new HashMap<String, String>();
                    for (Map.Entry<String, String> tempEntry : map.entrySet()) {
                        productAttribute.put(tempEntry.getKey(), tempEntry.getValue());
                    }
                    productAttribute.put("PRODUCT_ID", entry.getValue());
                    productAttributes.add(productAttribute);
                }
            }
        }
        this.targetBlcProductAttributeDao.batchInsert(productAttributes);
    }

    /**
     *
     */
    private void updateCategoryProductXref() {
        this.targetBlcCategoryProductXrefDao.batchDeleteByProductId(
                new ArrayList<String>(this.updateProductIdMap.values())
        );
        List<Map<String, String>> categoryProductXrefs = new LinkedList<Map<String, String>>();
        for (Map.Entry<String, String> entry : updateProductIdMap.entrySet()) {
            for (Map<String, String> map : this.sourceBlcCategoryProductXrefs) {
                if (map.get("PRODUCT_ID").equals(entry.getValue())) {
                    Map<String, String> categoryProductXref = new HashMap<String, String>();
                    categoryProductXref.put("CATEGORY_ID", map.get("CATEGORY_ID"));
                    categoryProductXref.put("PRODUCT_ID", entry.getValue());
                    categoryProductXrefs.add(categoryProductXref);
                }
            }
        }
        this.targetBlcCategoryProductXrefDao.batchInsert(categoryProductXrefs);
    }

    /**
     *
     */
    private void updateProductSkuXref() {
        this.targetBlcProductSkuXrefDao.batchDeleteByProductId(
                new ArrayList<String>(this.updateProductIdMap.values())
        );
        List<Map<String, String>> productSkuXrefs = new LinkedList<Map<String, String>>();
        for (Map.Entry<String, String> entry : updateProductIdMap.entrySet()) {
            for (Map<String, String> map : this.sourceBlcProductSkuXrefs) {
                if (map.get("PRODUCT_ID").equals(entry.getValue())) {
                    Map<String, String> productSkuXref = new HashMap<String, String>();
                    productSkuXref.put("SKU_ID", map.get("SKU_ID"));
                    productSkuXref.put("PRODUCT_ID", entry.getValue());
                    productSkuXrefs.add(productSkuXref);
                }
            }
        }
        this.targetBlcProductSkuXrefDao.batchInsert(productSkuXrefs);
    }

    /**
     * Persist new data to be added.
     */
    private void persistAddData() {
        if (!this.addProducts.isEmpty()) {
            //<1> Insert Product related tables..
            persistAddProduct();
            persistAddMenardProduct();
            persistAddCategoryProductXrefs();
            persistAddProductSkuXrefs();
            persistAddProductAttribute();
            persistAddProductOption();

            //<2> Insert SKU related tables..
            persistAddSku();
            persistAddSkuAttribute();
            persistAddMenardSku();
        }
    }

    /**
     *
     */
    private void persistAddMenardSku() {
        List<Map<String, String>> menardSkus = new ArrayList<Map<String, String>>();
        for (String addProductId : this.addProductIdMap.values()) {
            for (Map<String, String> menardSkuMap : this.sourceMenardSkus) {
                if  (addProductId.equals(getProductIdBySkuId(menardSkuMap.get("SKU_ID")))) {
                    menardSkus.add(menardSkuMap);
                }
            }
        }
        this.targetMenardSkuDao.batchInsert(menardSkus);
    }

    /**
     *
     */
    private void persistAddSkuAttribute() {
        List<Map<String, String>> skuAttributes = new ArrayList<Map<String, String>>();
        for (String addProductId : this.addProductIdMap.values()) {
            for (Map<String, String> skuAttributeMap : this.sourceBlcSkuAttributes) {
                if  (addProductId.equals(getProductIdBySkuId(skuAttributeMap.get("SKU_ID")))) {
                    skuAttributes.add(skuAttributeMap);
                }
            }
        }
        this.targetBlcSkuAttributeDao.batchInsert(skuAttributes);

    }

    /**
     *
     */
    private void persistAddSku() {
        List<Map<String, String>> skus = new ArrayList<Map<String, String>>();
        for (String addProductId : this.addProductIdMap.values()) {
            for (Map<String, String> skuMap : this.sourceBlcSkus) {
                if  (skuMap.get("DEFAULT_PRODUCT_ID").equals(addProductId)) {
                    skus.add(skuMap);
                }
            }
        }
        this.targetBlcSkuDao.batchInsert(skus);
    }

    /**
     *
     */
    private void persistAddProductOption() {
        List<Map<String, String>> productOptions = new ArrayList<Map<String, String>>();
        for (String addProductId : this.addProductIdMap.values()) {
            for (Map<String, String> menardProductOptionMap : this.sourceMenardProductOptions) {
                if  (menardProductOptionMap.get("BASE_PRODUCT_ID").equals(addProductId)) {
                    productOptions.add(menardProductOptionMap);
                }
            }
        }
        this.targetMenardProductOptionDao.batchInsert(productOptions);
    }

    /**
     *
     */
    private void persistAddProductAttribute() {
        List<Map<String, String>> productAttributes = new ArrayList<Map<String, String>>();
        for (String addProductId : this.addProductIdMap.values()) {
            for (Map<String, String> productAttributeMap : this.sourceBlcProductAttributes) {
                if  (productAttributeMap.get("PRODUCT_ID").equals(addProductId)) {
                    productAttributes.add(productAttributeMap);
                }
            }
        }
        this.targetBlcProductAttributeDao.batchInsert(productAttributes);
    }

    /**
     *
     */
    private void persistAddCategoryProductXrefs() {
        List<Map<String, String>> categoryProductXrefs = new ArrayList<Map<String, String>>();
        for (String addProductId : this.addProductIdMap.values()) {
            for (Map<String, String> productCategoryXrefMap : this.sourceBlcCategoryProductXrefs) {
                if  (productCategoryXrefMap.get("PRODUCT_ID").equals(addProductId)) {
                    categoryProductXrefs.add(productCategoryXrefMap);
                }
            }
        }
        this.targetBlcCategoryProductXrefDao.batchInsert(categoryProductXrefs);
    }

    /**
     *
     */
    private void persistAddProductSkuXrefs() {
        List<Map<String, String>> productSkuXrefs = new ArrayList<Map<String, String>>();
        for (String addProductId : this.addProductIdMap.values()) {
            for (Map<String, String> productSkuXrefMap : this.sourceBlcProductSkuXrefs) {
                if  (productSkuXrefMap.get("PRODUCT_ID").equals(addProductId)) {
                    productSkuXrefs.add(productSkuXrefMap);
                }
            }
        }
        this.targetBlcProductSkuXrefDao.batchInsert(productSkuXrefs);
    }

    /**
     *
     */
    private void persistAddMenardProduct() {
        List<Map<String, String>> menardProducts = new ArrayList<Map<String, String>>();
        for (String addProductId : this.addProductIdMap.values()) {
            for (Map<String, String> menardProductMap : this.sourceMenardProducts) {
                if  (menardProductMap.get("PRODUCT_ID").equals(addProductId)) {
                    menardProducts.add(menardProductMap);
                }
            }
        }
        this.targetMenardProductDao.batchInsert(menardProducts);
    }

    /**
     *
     */
    private void persistAddProduct() {
        this.targetBlcProductDao.batchInsert(this.addProducts);
    }

    /**
     * Assign new sku id for those new SKU from excel spread sheet.
     */
    private void assignNewSkuId() {
        Map<String, String> skuIdMap = new HashMap<String, String>();
        List<String> productIds = new ArrayList();
        //till this point, all sourceBlcSkus should have "REAL" DEFAULT_PRODUCT_ID
        for (Map<String, String> sourceBlcSku : this.sourceBlcSkus) {
            productIds.add(sourceBlcSku.get("DEFAULT_PRODUCT_ID"));
        }
        Map<String, String> existingProductSkuIdMap =
                ((BlcSkuDao) this.targetBlcSkuDao).getProductSkuIdMapByProductIdList(productIds);
        existingProductSkuIdMap.putAll(((BlcProductSkuXrefDao) this.targetBlcProductSkuXrefDao).getProductSkuIdMapByProductIdList(productIds));
        for (Map<String, String> sourceBlcSku : this.sourceBlcSkus) { //update for those existing sku
            String existingProductId = existingProductSkuIdMap.get(sourceBlcSku.get("DEFAULT_PRODUCT_ID"));
            if (existingProductId != null) {
                String newSkuId = existingProductId;
                String oldSkuId = sourceBlcSku.get("SKU_ID");
                skuIdMap.put(oldSkuId, newSkuId);
                sourceBlcSku.put("SKU_ID", existingProductId);
            }
        }
        for (String addProductId : this.addProductIdMap.values()) { //update for those new sku
            for (Map<String, String> sourceBlcSku : this.sourceBlcSkus) {
                if (addProductId.equals(sourceBlcSku.get("DEFAULT_PRODUCT_ID"))) {
                    String newSkuId = (++this.maxTargetSkuId).toString();
                    String oldSkuId = sourceBlcSku.get("SKU_ID");
                    skuIdMap.put(oldSkuId, newSkuId);
                    sourceBlcSku.put("SKU_ID", newSkuId);
                }
            }
        }
        initProductSkuIdMap();
        for (Map<String, String> sourceMenardSku : this.sourceMenardSkus) {
            sourceMenardSku.put("SKU_ID", skuIdMap.get(sourceMenardSku.get("SKU_ID")));
        }
        for (Map<String, String> sourceBlcAttribute : this.sourceBlcSkuAttributes) {
            sourceBlcAttribute.put("SKU_ID", skuIdMap.get(sourceBlcAttribute.get("SKU_ID")));
        }
        for (Map<String, String> sourceBlcProductSkuXref : this.sourceBlcProductSkuXrefs) {
            sourceBlcProductSkuXref.put("SKU_ID", skuIdMap.get(sourceBlcProductSkuXref.get("SKU_ID")));
        }
    }

    /**
     *
     */
    private void initProductSkuIdMap() {
        if (this.productSkuIdMap.isEmpty()) {
            for (Map<String, String> map : this.sourceBlcSkus) {
                this.productSkuIdMap.put(map.get("SKU_ID"), map.get("DEFAULT_PRODUCT_ID"));
            }
        }
    }

    /**
     * Prepare data needs to be updated.
     * @param updateModelVendorList a lis of model and vendor combinations.
     */
    private void prepareUpdateData(List<String> updateModelVendorList) {
        this.updateProductIdMap = getUpdateProductIdMap(updateModelVendorList);
        syncUpdateProductIDs(this.updateProductIdMap);
        this.updateProducts = new ArrayList<Map<String, String>>(this.updateProductIdMap.size());
        for (String id : this.updateProductIdMap.values()) {
            for (Map<String, String> targetProduct : this.targetBlcProducts) {
                if (id.equals(targetProduct.get("PRODUCT_ID"))) {
                    this.updateProducts.add(targetProduct);
                }
            }
        }
    }

    /**
     * Prepare data to be added.
     * @param addProductModelVendorList a list of model and vendor combination.
     */
    private void prepareAddData(List<String> addProductModelVendorList) {
        this.addProductIdMap = new HashMap<String, String>(addProductModelVendorList.size());
        for (String productModelVendor : addProductModelVendorList) {
            for (Map<String, String> sourceProduct : this.sourceBlcProducts) {
                if (sourceProduct.get("MODEL_VENDOR").equals(productModelVendor)) {
                    String newProductId = (++this.maxTargetProductId).toString();
                    this.addProductIdMap.put(sourceProduct.get("PRODUCT_ID"), newProductId);
                }
            }
        }
        assignNewProductId();
        this.addProducts = new ArrayList<Map<String, String>>(addProductIdMap.size());
        for (String id : this.addProductIdMap.values()) {
            for (Map<String, String> sourceProduct : this.sourceBlcProducts) {
                if (id.equals(sourceProduct.get("PRODUCT_ID"))) {
                    this.addProducts.add(sourceProduct);
                }
            }
        }
    }

    /**
     * Assign new product id for those new products from excel spread sheet.
     */
    private void assignNewProductId() {
        updateProductIdForSource(this.addProductIdMap, this.sourceBlcProducts);
        updateProductIdForSource(this.addProductIdMap, this.sourceBlcProductAttributes);
        updateProductIdForSource(this.addProductIdMap, this.sourceBlcCategoryProductXrefs);
        updateProductIdForSource(this.addProductIdMap, this.sourceBlcProductSkuXrefs);
        updateProductIdForSource(this.addProductIdMap, this.sourceBlcSkus);
        updateProductIdForSource(this.addProductIdMap, this.sourceMenardProducts);
        updateProductIdForSource(this.addProductIdMap, this.sourceMenardProductOptions);
    }

    /**
     * Sync product id for those update data.
     * @param productIdMap a map of source product id and target product id.
     */
    private void syncUpdateProductIDs(Map<String, String> productIdMap) {
        if (productIdMap.isEmpty()) {
            return;
        }
        updateProductIdForSource(productIdMap, this.sourceBlcProducts);
        updateProductIdForSource(productIdMap, this.sourceBlcProductAttributes);
        updateProductIdForSource(productIdMap, this.sourceBlcCategoryProductXrefs);
        updateProductIdForSource(productIdMap, this.sourceBlcProductSkuXrefs);
        updateProductIdForSource(productIdMap, this.sourceBlcSkus);
        updateProductIdForSource(productIdMap, this.sourceMenardProducts);
        updateProductIdForSource(productIdMap, this.sourceMenardProductOptions);
    }

    /**
     * Assign the product id in source DB with the product id from target DB.
     * @param productIdMap a map of source product id and target product id.
     * @param dataSet source data.
     */
    private void updateProductIdForSource(Map<String, String> productIdMap, List<Map<String, String>> dataSet) {
        for (Map<String, String> dataMap : dataSet) {
            if (dataMap.get("PRODUCT_ID") != null && productIdMap.get(dataMap.get("PRODUCT_ID")) != null) {
                dataMap.put("PRODUCT_ID", productIdMap.get(dataMap.get("PRODUCT_ID")));
            }
            if (dataMap.get("DEFAULT_PRODUCT_ID") != null
                    && productIdMap.get(dataMap.get("DEFAULT_PRODUCT_ID")) != null) {
                dataMap.put("DEFAULT_PRODUCT_ID", productIdMap.get(dataMap.get("DEFAULT_PRODUCT_ID")));
            }
            if (dataMap.get("OPTION_PRODUCT_ID") != null
                    && productIdMap.get(dataMap.get("OPTION_PRODUCT_ID")) != null) {
                dataMap.put("OPTION_PRODUCT_ID", productIdMap.get(dataMap.get("OPTION_PRODUCT_ID")));
            }
            if (dataMap.get("BASE_PRODUCT_ID") != null && productIdMap.get(dataMap.get("BASE_PRODUCT_ID")) != null) {
                dataMap.put("BASE_PRODUCT_ID", productIdMap.get(dataMap.get("BASE_PRODUCT_ID")));
            }
        }
    }

    /**
     * Update the source product url after new source product get new target DB product id.
     */
    private void updateProductUrlForSourceBlcProduct() {
        for (Map<String, String> sourceProduct : this.sourceBlcProducts) {
            sourceProduct.put("URL",
                    updateProductUrl(sourceProduct.get("URL"), sourceProduct.get("PRODUCT_ID")));
        }
    }

    /**
     * Update a single source product url after new source product get new target DB product id.
     * @param url the source product id.
     * @param productId product id in target db.
     * @return the updated product url.
     */
    private String updateProductUrl(String url, String productId) {
        return url.substring(0, url.lastIndexOf("/") + 1) + productId;
    }

    /**
     * Compare the source db and target db by the combination of vendor and model,
     * and return a map of source product id and target product id.
     * @param updateModelVendorList a list of the combination of model and vendor
     * @return a map of source product id and target product id.
     */
    private Map<String, String> getUpdateProductIdMap(List<String> updateModelVendorList) {
        Map<String, String> updateProductIdMap = new HashMap<String, String>(updateModelVendorList.size());
        for (String modelVendor : updateModelVendorList) {
            for (Map<String, String> targetProduct : this.targetBlcProducts) {
                if (modelVendor.equals(targetProduct.get("MODEL_VENDOR"))) {
                    for (Map<String, String> sourceProduct : this.sourceBlcProducts) {
                        if (modelVendor.equals(sourceProduct.get("MODEL_VENDOR"))) {
                            updateProductIdMap.put(
                                    sourceProduct.get("PRODUCT_ID"),
                                    targetProduct.get("PRODUCT_ID")
                            );
                        }
                    }
                }
            }
        }
        return updateProductIdMap;
    }

    /**
     * Prepare the data to be deleted based on the given list of the combination of model and vendor.
     * @param deleteModelVendorList a list of the combination of model and vendor.
     */
    private void prepareDeleteData(List<String> deleteModelVendorList) {
        this.deleteProductIDs = new ArrayList<String>(deleteModelVendorList.size());
        for (String modelVendor : deleteModelVendorList) {
            for (Map<String, String> targetProduct : this.targetBlcProducts) {
                if (modelVendor.equals(targetProduct.get("MODEL_VENDOR"))) {
                    this.deleteProductIDs.add(targetProduct.get("PRODUCT_ID"));
                }
            }
        }
    }

    /**
     * Get a model-vendor combination list from a list of data map.
     * @param listMap a list of data map from which the individual model and vendor will be retrieved.
     * @return a list of model-vendor combination list.
     */
    private List<String> getModelNumVendorCollection(List<Map<String, String>> listMap) {
        List<String> tempList = new ArrayList<String>(listMap.size());
        for (Map<String, String> sourceProduct : listMap) {
            tempList.add(sourceProduct.get("MODEL_VENDOR"));
        }
        return tempList;
    }

    /**
     * Add model-vendor combination to the a list of data map.
     * @param list a list of data map which would contain "MODEL_VENDOR" data field.
     */
    private void addModelNumVendor(List<Map<String, String>> list) {
        for (Map<String, String> map : list) {
            map.put("MODEL_VENDOR", map.get("MODEL_NUM") + JOIN_DELIMITER + map.get("VENDOR_LOGO"));
        }
    }

}
