package com.menards.autoloader.service;

import com.menards.autoloader.domain.FileInfoExt;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.admin.service.FileInfo;
import org.springframework.batch.admin.service.FileSender;
import org.springframework.batch.admin.service.FileService;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.ContextResource;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.util.Assert;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;


/**
 * <p>LocalFileService</p>
 * <p>
 * An implementation of {@link org.springframework.batch.admin.service.FileService} that deals with files only in the
 * local file system. Files and triggers are created in subdirectories of the
 * Java temporary directory.
 * </p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class LocalFileService implements FileService, InitializingBean, ResourceLoaderAware {

    private File outputDir = new File(System.getProperty("java.io.tmpdir", "/tmp"), "batch/files");

    private static final Log LOGGER = LogFactory.getLog(LocalFileService.class);

    private ResourceLoader resourceLoader = new DefaultResourceLoader();

    private FileSender fileSender;

    public void setResourceLoader(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    public void setFileSender(FileSender fileSender) {
        this.fileSender = fileSender;
    }

    /**
     * The output directory to store new files. Defaults to
     * <code>${java.io.tmpdir}/batch/files</code>.
     *
     * @param outputDir the output directory to set
     */
    public void setOutputDir(File outputDir) {
        this.outputDir = outputDir;
    }

    @Override
    public void afterPropertiesSet() {
        Assert.state(fileSender != null, "A FileSender must be provided");
        if (!outputDir.exists()) {
            Assert.state(outputDir.mkdirs(), "Cannot create output directory " + outputDir);
        }
        Assert.state(outputDir.exists(), "Output directory does not exist " + outputDir);
        Assert.state(outputDir.isDirectory(), "Output file is not a directory " + outputDir);
    }

    @Override
    public FileInfo createFile(String path) throws IOException {

        path = sanitize(path);

        Assert.hasText(path, "The file path must not be empty");

        String name = path.substring(path.lastIndexOf("/") + 1);
        String parent = path.substring(0, path.lastIndexOf(name));
        if (parent.endsWith("/")) {
            parent = parent.substring(0, parent.length() - 1);
        }

        File directory = new File(outputDir, parent);
        directory.mkdirs();
        Assert.state(directory.exists() && directory.isDirectory(), "Could not create directory: " + directory);

        FileInfo result = new FileInfo(path);
        File dest = new File(outputDir, path);
        dest.createNewFile();

        return result;

    }

    /**
     * @param target the target file
     * @return the path to the file from the base output directory
     */
    private String extractPath(File target) {
        String outputPath = outputDir.getAbsolutePath();
        return target.getAbsolutePath().substring(outputPath.length() + 1).replace("\\", "/");
    }

    @Override
    public boolean publish(FileInfo dest) throws IOException {
        String path = dest.getPath();
        fileSender.send(getResource(path).getFile());
        return true;
    }

    @Override
    public int countFiles() {
        ResourcePatternResolver resolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
        Resource[] resources;
        try {
            resources = resolver.getResources("file:///" + outputDir.getAbsolutePath() + "/**");
        } catch (IOException e) {
            throw new IllegalStateException("Unexpected problem resolving files", e);
        }
        return resources.length;
    }

    @Override
    public List<FileInfo> getFiles(int startFile, int pageSize) throws IOException {
        List<FileInfo> files = getFiles("**");
        return new ArrayList<FileInfo>(files.subList(startFile, Math.min(startFile + pageSize, files.size())));

    }

    /**
     * Get a list of {@link FileInfo} based the pattern.
     * @param pattern A pattern string used to match the file names on the server.
     * @return a list of {@link FileInfo}.
     */
    private List<FileInfo> getFiles(String pattern) {
        ResourcePatternResolver resolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
        List<Resource> resources = new ArrayList<Resource>();

        if (!pattern.startsWith("/")) {
            pattern = "/" + outputDir.getAbsolutePath() + "/" + pattern;
        }
        if (!pattern.startsWith("file:")) {
            pattern = "file:///" + pattern;
        }

        try {
            resources = Arrays.asList(resolver.getResources(pattern));
        } catch (IOException e) {
            LOGGER.debug("Cannot locate files " + pattern, e);
            return new ArrayList<FileInfo>();
        }

        List<FileInfo> files = new ArrayList<FileInfo>();
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        for (Resource resource : resources) {
            File file;
            try {
                file = resource.getFile();
                if (file.isFile()) {
                    FileInfoExt info = new FileInfoExt(extractPath(file));
                    String lastModifiedDate = sdf.format(new Date(file.lastModified()));
                    info.setLastModifyDate(lastModifiedDate);
                    files.add(info);
                }
            } catch (IOException e) {
                LOGGER.debug("Cannot locate file " + resource, e);
            }
        }

        Collections.sort(files);
        return new ArrayList<FileInfo>(files);

    }

    @Override
    public int delete(String pattern) throws IOException {

        ResourcePatternResolver resolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
        if (!pattern.startsWith("/")) {
            pattern = "/" + outputDir.getAbsolutePath() + "/" + pattern;
        }
        if (!pattern.startsWith("file:")) {
            pattern = "file:///" + pattern;
        }

        Resource[] resources = resolver.getResources(pattern);

        int count = 0;
        for (Resource resource : resources) {
            File file = resource.getFile();
            if (file.isFile()) {
                count++;
                FileUtils.deleteQuietly(file);
            }
        }

        return count;

    }

    /**
     * Check whether the file designated by the file name is existed or not.
     * @param fileName the file name.
     * @return a boolean value showing whether the file is existed or not.
     */
    public boolean isFileExist(String fileName) {
        File file = new File(outputDir, fileName);
        return file.exists();
    }

    /**
     * Get the file by its name
     * @param fileName file name
     * @return {@link File} object
     */
    public File getFile(String fileName) {
        return new File(outputDir, fileName);
    }

    @Override
    public Resource getResource(String path) {

        path = sanitize(path);
        FileInfo pattern = new FileInfo(path);
        List<FileInfo> files = getFiles(pattern.getPattern());
        FileInfo info = null;
        if (files.isEmpty()) {
            info = pattern;
        } else {
            info = files.get(0);
        }
        File file = new File(outputDir, info.getFileName());
        return new FileServiceResource(file, path);

    }

    public File getUploadDirectory() {
        return outputDir;
    }

    /**
     * Normalize file separators to "/" and strip leading prefix and separators
     * to create a simple relative path.
     *
     * @param path the raw path
     * @return a sanitized version
     */
    private String sanitize(String path) {
        path = path.replace("\\", "/");
        if (path.startsWith("files:")) {
            path = path.substring("files:".length());
            while (path.startsWith("/")) {
                path = path.substring(1);
            }
        }
        return path;
    }

    /**
     * An extension to the {@link FileSystemResource}
     */
    private static class FileServiceResource extends FileSystemResource implements ContextResource {

        private final String path;

        /**
         * A constructor method
         * @param file a file object
         * @param path the path to the file.
         */
        public FileServiceResource(File file, String path) {
            super(file);
            this.path = path;
        }

        public String getPathWithinContext() {
            return path;
        }

    }

}
