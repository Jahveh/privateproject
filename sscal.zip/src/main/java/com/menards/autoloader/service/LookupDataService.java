package com.menards.autoloader.service;

import com.menards.autoloader.dao.mcr.CatalogDao;
import com.menards.autoloader.dao.mcr.PriorityDao;
import com.menards.autoloader.dao.mcr.UserDao;
import com.menards.autoloader.domain.mcr.Priority;
import com.menards.autoloader.domain.mcr.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Service
public class LookupDataService {
    @Autowired
    private PriorityDao priorityDao;

    @Autowired
    private CatalogDao catalogDao;

    @Autowired
    private UserDao userDao;

    /**
     *
     * @return a list of all priority
     * @throws IOException io exception
     */
    public List<Priority> getAllPriorities() throws IOException {
        return priorityDao.getAllPriorities();
    }

    /**
     *
     * @return a list of catalog
     * @throws IOException io exception
     */
    public List<String> getAllCatalogs() throws IOException {
        return catalogDao.getAllCatalogs();
    }

    /**
     *
     * @return a list of User object
     * @throws IOException io exception
     */
    public List<User> getAllRequesters() throws IOException {
        return userDao.getAllRequesters();
    }

    /**
     *
     * @return a list of User object
     * @throws IOException io exception
     */
    public List<User> getAllApprovers() throws IOException {
        return userDao.getAllApprovers();
    }

    /**
     *
     * @return a list of User object
     * @throws IOException io exception
     */
    public List<User> getAllUsers() throws IOException {
        return userDao.getAllUsers();
    }

    /**
     *
     * @param userEmail user email
     * @return user name
     * @throws IOException io exception
     */
    public String getUserNameByEmail(String userEmail) throws IOException {
        List<User> users = userDao.getAllUsers();
        for (User user : users) {
            if (user.getEmail().trim().equalsIgnoreCase(userEmail.trim())) {
                return user.getName();
            }
        }
        return null;
    }

}
