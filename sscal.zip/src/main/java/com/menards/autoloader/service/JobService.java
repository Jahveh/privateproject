package com.menards.autoloader.service;

import com.menards.autoloader.utils.BatchUtils;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.JobParametersNotFoundException;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Service("autoLoaderJobService")
public class JobService {
    private final String EXCEL_TO_STAGE_JOB_NAME = "excel-to-stage-job";
    private final String STAGE_TO_PRODUCTION_JOB_NAME = "stage-to-production-job";
    private final String PRODUCTION_RELEASE_JOB_NAME = "production-release-job";

    @Autowired
    private JobRegistry jobRegistry;

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private JobExplorer jobExplorer;

    @Autowired
    private org.springframework.batch.admin.service.JobService jobService;

    public void runExcelToStageJob(String filePath, int mcrId) throws
            NoSuchJobException,
            JobParametersNotFoundException,
            JobParametersInvalidException,
            JobExecutionAlreadyRunningException,
            JobRestartException,
            JobInstanceAlreadyCompleteException {
        Job job = jobRegistry.getJob(EXCEL_TO_STAGE_JOB_NAME);
        JobParameters jobParameters = BatchUtils.getNextJobParameters(job, jobExplorer);
        Map<String, Object> newParam = new HashMap<String, Object>();
        newParam.put("EXCEL_PATH", filePath);
        newParam.put("MCR_ID", mcrId+"");
        jobParameters = BatchUtils.buildJobParameters(jobParameters, newParam);
        JobExecution jobExecution = jobLauncher.run(job, jobParameters);
    }
    
    public void runStageToProductionJob(int mcrId) throws
    		NoSuchJobException,
    		JobParametersNotFoundException,
    		JobParametersInvalidException,
    		JobExecutionAlreadyRunningException,
    		JobRestartException,
    		JobInstanceAlreadyCompleteException {
    	Job job = jobRegistry.getJob(STAGE_TO_PRODUCTION_JOB_NAME);
    	JobParameters jobParameters = BatchUtils.getNextJobParameters(job, jobExplorer);
        Map<String, Object> newParam = new HashMap<String, Object>();
        newParam.put("MCR_ID", mcrId+"");
        jobParameters = BatchUtils.buildJobParameters(jobParameters, newParam);
    	jobLauncher.run(job, jobParameters);
    }
    
    public void runProductionReleaseJob() throws
    		NoSuchJobException,
    		JobParametersNotFoundException,
    		JobParametersInvalidException,
    		JobExecutionAlreadyRunningException,
    		JobRestartException,
    		JobInstanceAlreadyCompleteException {
    	Job job = jobRegistry.getJob(PRODUCTION_RELEASE_JOB_NAME);
    	JobParameters jobParameters = BatchUtils.getNextJobParameters(job, jobExplorer);
    	jobLauncher.run(job, jobParameters);
}
}
