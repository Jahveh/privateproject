package com.menards.autoloader.jobListener;

import com.menards.autoloader.domain.mcr.MCR;
import com.menards.autoloader.integration.gateway.EmailGateway;
import com.menards.autoloader.service.EmailUseCase;
import com.menards.autoloader.service.McrService;

import org.apache.commons.lang.StringUtils;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class JobFailedListener implements JobExecutionListener {
    @Autowired
    private EmailGateway emailGateway;

    @Autowired
    private McrService mcrService;

    @Override
    public void beforeJob(JobExecution jobExecution) {

    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        if (jobExecution.getStatus() == BatchStatus.FAILED) {

            List<String> errorMessageList = new ArrayList<String>();
            Long executionId = jobExecution.getId();
            errorMessageList.add("Execution ID: " + Long.toString(executionId));
            for (Throwable throwable : jobExecution.getAllFailureExceptions()) {
                errorMessageList.add(throwable.getMessage());
            }
            String joinedErrorMessages = StringUtils.join(errorMessageList.iterator(), "#~#");
            String jobName = jobExecution.getJobInstance().getJobName();
            EmailUseCase emailUseCase = null;
            if (jobName.equals("excel-to-stage-job")) {
                emailUseCase = EmailUseCase.EXCEL_TO_STAGE_JOB_FAILURE;
                int mcrId = Integer.valueOf(jobExecution.getJobInstance().getJobParameters().getString("MCR_ID"));
                mcrService.rollbackMcrStatusForExcelToStageJob(mcrId);
            } else if (jobName.equals("stage-to-production-job")) {
                emailUseCase = EmailUseCase.STAGE_TO_PRODUCTION_JOB_FAILURE;
                int mcrId = Integer.valueOf(jobExecution.getJobInstance().getJobParameters().getString("MCR_ID"));
                mcrService.rollbackMcrStatusForStageToProductionJob(mcrId);
            } else if (jobName.equals("production-release-job")) {
                emailUseCase = EmailUseCase.PRODUCTION_RELEASE_JOB_FAILURE;
            }

            if (emailUseCase == EmailUseCase.PRODUCTION_RELEASE_JOB_FAILURE) {
                List<MCR> mcrList = mcrService.getAllCandidateMcrForProductionRelease();
                for (MCR mcr : mcrList) {
                    emailGateway.sendMail(mcr.getId(), emailUseCase.name(), joinedErrorMessages, "");
                    mcrService.rollbackMcrStatusForProductionReleaseJob(mcr.getId());
                }
            } else {
                String mcrId = jobExecution.getJobInstance().getJobParameters().getString("MCR_ID");
                Assert.isTrue(mcrId != null && mcrId.matches("^[0-9]+$"), "MCR_ID should be a validate integer number.");
                emailGateway.sendMail(Integer.parseInt(mcrId), emailUseCase.name(), joinedErrorMessages, "");
            }
        }
    }


}
