package com.menards.autoloader.integration.transformer;

import com.menards.autoloader.domain.mcr.ApprovalHistory;
import com.menards.autoloader.domain.mcr.MCR;
import com.menards.autoloader.service.EmailUseCase;
import com.menards.autoloader.service.McrService;
import com.menards.autoloader.service.SecureUserService;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.Message;
import org.springframework.integration.annotation.Header;
import org.springframework.integration.annotation.Payload;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.mail.MailHeaders;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.util.Assert;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */

public class McrEmailTransformer {

    @Autowired
    private McrService mcrService;

    @Autowired
    private SecureUserService secureUserService;

    private static Configuration ftlCfg = new Configuration();

    static {
        ftlCfg.setClassForTemplateLoading(McrEmailTransformer.class, "/META-INF/email.template/");
    }

    /**
     * A message transformer transforming a given mcr id into mail message
     * @param mcrId mcr id
     * @param emailUseCaseEnum email use case
     * @param approvalStatus approval status
     * @param userName user name
     * @return Message object
     * @throws IOException io exception
     * @throws TemplateException template exception
     */
    @Transformer
    public Message<String> transformToMcrMailMessage(@Payload int mcrId,
                                                     @Header("email-use-case") String emailUseCaseEnum,
                                                     @Header("approval-status") String approvalStatus,
                                                     @Header("operator") String userName)
            throws IOException, TemplateException {
        MCR mcr = null;
        if (EmailUseCase.valueOf(emailUseCaseEnum) == EmailUseCase.MCR_STAGE_PUBLISH
                || EmailUseCase.valueOf(emailUseCaseEnum) == EmailUseCase.MCR_PRODUCTION_RELEASE
                || EmailUseCase.valueOf(emailUseCaseEnum) == EmailUseCase.PRODUCTION_RELEASE_JOB_FAILURE
                || EmailUseCase.valueOf(emailUseCaseEnum) == EmailUseCase.STAGE_TO_PRODUCTION_JOB_FAILURE) {
            mcr = mcrService.getSimpleMcrDataById(mcrId);
        } else {
            mcr = mcrService.getCompleteMcrDataById(mcrId);
        }
        String mailSubject = getEmailSubject(mcr, EmailUseCase.valueOf(emailUseCaseEnum), approvalStatus, userName);
        String[] toArray = getEmailToList(mcr, EmailUseCase.valueOf(emailUseCaseEnum));
        List<String> exceptionList = buildExceptionMessageList(EmailUseCase.valueOf(emailUseCaseEnum), approvalStatus);
        String mailBody = buildMailBody(mcr, mailSubject, exceptionList);
        Message<String> message = null;
        if (EmailUseCase.valueOf(emailUseCaseEnum) == EmailUseCase.NEW_MCR) {
            message = MessageBuilder.withPayload(mailBody)
                    .setHeader(MailHeaders.FROM, "noreply@menard-inc.com")
                    .setHeader(MailHeaders.TO, toArray)
                    .setHeader(MailHeaders.CC, "issintra@menards.net")
                    .setHeader(MailHeaders.SUBJECT, mailSubject).build();
        } else {
            message = MessageBuilder.withPayload(mailBody)
                    .setHeader(MailHeaders.FROM, "noreply@menard-inc.com")
                    .setHeader(MailHeaders.TO, toArray)
                    .setHeader(MailHeaders.SUBJECT, mailSubject).build();
        }

        return message;
    }

    /**
     *
     * @param emailUseCase email use case
     * @param exceptions exception messages
     * @return a list of messages
     */
    private List<String> buildExceptionMessageList(EmailUseCase emailUseCase, String exceptions) {
        if (emailUseCase == EmailUseCase.EXCEL_TO_STAGE_JOB_FAILURE
                || emailUseCase == EmailUseCase.STAGE_TO_PRODUCTION_JOB_FAILURE
                || emailUseCase == EmailUseCase.PRODUCTION_RELEASE_JOB_FAILURE
                ) {
            String[] exceptionArray = exceptions.split("#~#");
            Assert.isTrue(exceptionArray.length > 0,
                    "No exception found while preparing for job failure notification email.");
            return Arrays.asList(exceptionArray);
        } else {
            return new ArrayList<String>();
        }
    }

    /**
     *
     * @param mcr mcr
     * @param emailUseCase email use case
     * @param approvalStatus approval status
     * @param userName user name
     * @return email subject
     */
    private String getEmailSubject(MCR mcr, EmailUseCase emailUseCase, String approvalStatus, String userName) {
        switch (emailUseCase) {
            case NEW_MCR: return "New MCR Created - Need Managers' Approval";
            case MCR_REACTIVATE: return "MCR has been Reactivated";
            case MCR_APPROVAL: return "MCR Status Updated - " + approvalStatus + " by " + userName;
            case MCR_STAGE_PUBLISH: return "MCR Status Updated - Published to Production.";
            case MCR_PRODUCTION_RELEASE: return "MCR Status Updated - Released on Production.";
            case MCR_STAGE_APPROVAL: return "MCR Status Updated - Approved on Stage.";
            case EXCEL_TO_STAGE_JOB_FAILURE: return "Batch Job [excel-to-stage-job] Failed";
            case STAGE_TO_PRODUCTION_JOB_FAILURE: return "Batch Job [stage-to-production-job] Failed";
            case PRODUCTION_RELEASE_JOB_FAILURE: return "Batch Job [production-release-job] Failed";
            default: return "";
        }
    }

    /**
     *
     * @param mcr mcr
     * @param emailUseCase email use case
     * @return a list of email recipient
     */
    private String[] getEmailToList(MCR mcr, EmailUseCase emailUseCase) {
        switch (emailUseCase) {
            case NEW_MCR:
            case MCR_APPROVAL:
            case MCR_STAGE_PUBLISH:
            case MCR_PRODUCTION_RELEASE:
            case EXCEL_TO_STAGE_JOB_FAILURE:
            case STAGE_TO_PRODUCTION_JOB_FAILURE:
            case PRODUCTION_RELEASE_JOB_FAILURE:
            case MCR_STAGE_APPROVAL: return getAllEmailAddresses(mcr);
            case MCR_REACTIVATE: return getSubmitterEmailAddress(mcr);
            default: return null;
        }
    }

    /**
     *
     * @param mcr mcr
     * @return an array of submitter email addresss
     */
    private String[] getSubmitterEmailAddress(MCR mcr) {
        List<String> toList = new LinkedList<String>();
        toList.add(mcr.getSubmitter().getEmail());
        String[] toArray = toList.toArray(new String[toList.size()]);
        return toArray;
    }

    /**
     *
     * @param mcr mcr
     * @return an array of email address
     */
    private String[] getAllEmailAddresses(MCR mcr) {
        List<String> toList = new LinkedList<String>();
        for (ApprovalHistory approvalHistory : mcr.getApprovalHistories()) {
            toList.add(approvalHistory.getApprovalUser().getEmail());
        }
        toList.add(mcr.getSubmitter().getEmail());
        String[] toArray = toList.toArray(new String[toList.size()]);
        return toArray;
    }

    /**
     *
     * @param mcr mcr
     * @param mailSubject email subject
     * @param exceptionList exception list
     * @return  email body
     * @throws IOException io exception
     * @throws TemplateException template exception
     */
    private String buildMailBody(MCR mcr, String mailSubject, List<String> exceptionList)
            throws IOException, TemplateException {
        Template template = ftlCfg.getTemplate("mcr-notification.ftl");
        StringWriter stringWriter = new StringWriter();
        Map<String, Object> dataMap = new HashMap<String, Object>();
        secureUserService.enrichSecureUser(mcr.getSubmitter());
        dataMap.put("mcr", mcr);
        dataMap.put("mailSubject", mailSubject);
        if (exceptionList.size() > 0) {
            dataMap.put("exceptionList", exceptionList);
        }
        template.process(dataMap, stringWriter);
        stringWriter.close();
        return stringWriter.getBuffer().toString();
    }

}
