package com.menards.autoloader.integration.gateway;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.Header;
import org.springframework.integration.annotation.Payload;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public interface EmailGateway {

    /**
     * An email gateway
     * @param mcrId MCR id
     * @param emailUseCase email use case
     * @param approvalStatus approval status
     * @param userName user name
     */
    @Gateway
    void sendMail(@Payload int mcrId,
                  @Header("email-use-case") String emailUseCase,
                  @Header("approval-status") String approvalStatus,
                  @Header("operator") String userName);
}
