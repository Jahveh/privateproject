package com.menards.autoloader.integration.gateway;

import org.springframework.integration.annotation.Gateway;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public interface McrGateway {

    /**
     * A gateway method for mcr reactivation
     * @param mcrId mcr id
     */
    @Gateway
    void reactivate(int mcrId);

}
