package com.menards.autoloader.integration.gateway;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.Header;
import org.springframework.integration.annotation.Payload;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public interface JobGateway {

    @Gateway(requestChannel = "runExcelToStageJobChannel")
    void runExcelToStageJob(@Payload String filePath, @Header("mcrId") int mcrId);

    @Gateway(requestChannel = "runStageToProductionJobChannel")
    void runStageToProductionJob(int mcrId);

    @Gateway(requestChannel = "runProductionReleaseJobChannel")
    void runProductionReleaseJob(String dullParam);
}
