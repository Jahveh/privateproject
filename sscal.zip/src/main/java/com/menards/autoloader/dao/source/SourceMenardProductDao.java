package com.menards.autoloader.dao.source;

import com.menards.autoloader.dao.DaoAdapter;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>SourceMenardProductDao</p>
 * <p>A {@link DaoAdapter} sub class for manipulating AL_SOURCE_MENARD_PRODUCT table.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class SourceMenardProductDao extends DaoAdapter<List<Map<String, String>>> {
    private static final String BATCH_INSERT_SQL =
            "insert into AL_SOURCE_MENARD_PRODUCT (PRODUCT_ID, MODEL_NUM, MCR_ID) values (?, ?, ?)";
    private static final String QUERY_GET_ALL_DATA_BY_MCR_ID =
            "SELECT PRODUCT_ID, MODEL_NUM from AL_SOURCE_MENARD_PRODUCT WHERE MCR_ID = ?";
    private static final String DELETE_ALL_BY_MCR_ID = "DELETE FROM AL_SOURCE_MENARD_PRODUCT WHERE MCR_ID = ?";

    @Override
    public void deleteAllByMcrId(int mcrId) {
        getJdbcTemplate().update(DELETE_ALL_BY_MCR_ID, mcrId);
    }

    @Override
    public void batchInsert(final List<Map<String, String>> sourceMenardProducts) {
        getJdbcTemplate().batchUpdate(BATCH_INSERT_SQL, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                Map<String, String> sourceMenardProduct = sourceMenardProducts.get(i);
                ps.setString(1, sourceMenardProduct.get("PRODUCT_ID"));
                ps.setString(2, sourceMenardProduct.get("MODEL_NUM"));
                ps.setInt(3, Integer.parseInt(sourceMenardProduct.get("MCR_ID")));
            }
            @Override
            public int getBatchSize() {
                return sourceMenardProducts.size();
            }
        });
    }

    @Override
    public List<Map<String, String>> getAllDataByMcrId(int mcrId) {
        return getJdbcTemplate().query(QUERY_GET_ALL_DATA_BY_MCR_ID,
                new Object[]{mcrId},
                new RowMapper<Map<String, String>>() {
            @Override
            public Map<String, String> mapRow(ResultSet rs, int rowNum) throws SQLException {
                Map<String, String> sourceMenardProduct = new HashMap<String, String>();
                sourceMenardProduct.put("PRODUCT_ID", rs.getString(1));
                sourceMenardProduct.put("MODEL_NUM", rs.getString(2));
                return sourceMenardProduct;
            }
        });
    }

    /**
     * A constructor method.
     * @param jdbcTemplate A {@link org.springframework.jdbc.core.JdbcTemplate} object that executes JDBC statements.
     */
    public SourceMenardProductDao(JdbcTemplate jdbcTemplate) {
        setJdbcTemplate(jdbcTemplate);
    }
}
