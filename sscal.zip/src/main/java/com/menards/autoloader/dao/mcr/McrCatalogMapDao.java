package com.menards.autoloader.dao.mcr;

import org.springframework.stereotype.Repository;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Repository
public class McrCatalogMapDao {
}
