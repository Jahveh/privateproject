package com.menards.autoloader.dao.mcr;

import au.com.bytecode.opencsv.CSVReader;

import com.menards.autoloader.domain.mcr.User;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Repository;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Repository
public class UserDao {
    private static final String APPROVERS_FILE_PATH = "/lookup-data/mcrApprovers.csv";
    private static final String REQUESTERS_FILE_PATH = "/lookup-data/mcrRequesters.csv";
    private static final String ADMINISTRATORS_FILE_PATH = "/lookup-data/autoLoaderAdministrators.csv";

    /**
     *
     * @return a list of user
     * @throws IOException io exception
     */
    public List<User> getAllUsers() throws IOException {
        List<User> allUsers = new ArrayList<User>();
        Resource resource = new ClassPathResource(APPROVERS_FILE_PATH);
        CSVReader csvReader = new CSVReader(new FileReader(resource.getFile()), ',');
        String [] nextLine;
        while ((nextLine = csvReader.readNext()) != null) {
            User user = new User();
            user.setName(nextLine[0].trim());
            user.setEmail(nextLine[1].trim());
            allUsers.add(user);
        }
        resource = new ClassPathResource(REQUESTERS_FILE_PATH);
        csvReader = new CSVReader(new FileReader(resource.getFile()), ',');
        nextLine = null;
        while ((nextLine = csvReader.readNext()) != null) {
            User user = new User();
            user.setName(nextLine[0].trim());
            user.setEmail(nextLine[1].trim());
            allUsers.add(user);
        }
        return sortUserList(allUsers);
    }

    /**
     *
     * @return a list of user
     * @throws IOException io exception
     */
    public List<User> getAllApprovers() throws IOException {
        return getAllUsers(APPROVERS_FILE_PATH);
    }

    /**
     *
     * @return a list of user
     * @throws IOException io exception
     */
    public List<User> getAllRequesters() throws IOException {
        return getAllUsers(REQUESTERS_FILE_PATH);
    }

    /**
     *
     * @return a list of user
     * @throws IOException io exception
     */
    public List<User> getAllAdministrators() throws IOException {
        return getAllUsers(ADMINISTRATORS_FILE_PATH);
    }

    /**
     *
     * @param filePath file path
     * @return a list of user
     * @throws IOException io exception
     */
    private List<User> getAllUsers(String filePath) throws IOException {
        List<User> allUsers = new ArrayList<User>();
        Resource resource = new ClassPathResource(filePath);
        CSVReader csvReader = new CSVReader(new FileReader(resource.getFile()), ',');
        String [] nextLine;
        while ((nextLine = csvReader.readNext()) != null) {
            User user = new User();
            user.setName(nextLine[0].trim());
            if (nextLine.length > 1) {
                user.setEmail(nextLine[1].trim());
            }
            allUsers.add(user);
        }
        return sortUserList(allUsers);
    }

    /**
     *
     * @param allUsers all users
     * @return a list of user
     */
    private List<User> sortUserList(List<User> allUsers) {
        String[] userNames = new String[allUsers.size()];
        for (int i = 0; i < allUsers.size(); i++) {
            userNames[i] = allUsers.get(i).getName();
        }
        Arrays.sort(userNames);
        List<User> sortedUsers = new ArrayList<User>(userNames.length);
        for (String userName : userNames) {
            for (User user : allUsers) {
                if (user.getName().equals(userName)) {
                    sortedUsers.add(user);
                    break;
                }
            }
        }
        return sortedUsers;
    }


}
