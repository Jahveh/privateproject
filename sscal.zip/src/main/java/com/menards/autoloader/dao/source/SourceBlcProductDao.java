package com.menards.autoloader.dao.source;

import com.menards.autoloader.dao.DaoAdapter;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>PreSourceBlcProductDao</p>
 * <p>A {@link DaoAdapter} sub class for manipulating AL_SOURCE_BLC_PRODUCT table.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class SourceBlcProductDao  extends DaoAdapter<List<Map<String, String>>> {
    private static final String BATCH_INSERT_SQL =
            "insert into AL_SOURCE_BLC_PRODUCT (PRODUCT_ID, URL, DEFAULT_CATEGORY_ID, MCR_ID) values (?, ?, ?, ?)";
    private static final String DELETE_ALL_BY_MCR_ID = "DELETE FROM AL_SOURCE_BLC_PRODUCT WHERE MCR_ID = ?";

    @Override
    public void deleteAllByMcrId(int mcrId) {
        getJdbcTemplate().update(DELETE_ALL_BY_MCR_ID, mcrId);
    }

    private static final String QUERY_GET_ALL_DATA_BY_MCR_ID =
                    "SELECT p.PRODUCT_ID, p.URL, p.DEFAULT_CATEGORY_ID, mpv.MODEL_NUM, mpv.VENDOR_LOGO "
                    + "from AL_SOURCE_BLC_PRODUCT p "
                    + "JOIN ("
                    + "SELECT mp.PRODUCT_ID, mp.MODEL_NUM, attr.VENDOR_LOGO "
                    + "FROM AL_SOURCE_MENARD_PRODUCT mp "
                    + "JOIN ("
                    + "SELECT DISTINCT vw.PRODUCT_ID, vw.VENDOR_LOGO "
                    + "FROM ("
                    + "SELECT pa.PRODUCT_ID, "
                    + "CASE pa.NAME "
                    + "WHEN 'VENDOR_LOGO' "
                    + "THEN pa.VALUE "
                    + "END VENDOR_LOGO "
                    + "FROM AL_SOURCE_BLC_PRODUCT_ATTRIBUTE pa where pa.mcr_id = ? ) vw "
                    + "WHERE vw.VENDOR_LOGO IS NOT NULL) attr "
                    + "ON mp.PRODUCT_ID = attr.PRODUCT_ID where mp.mcr_id = ? ) mpv "
                    + "on p.PRODUCT_ID = mpv.PRODUCT_ID where p.mcr_id = ?";
    private static final String GET_MAX_ID =
            "select ifnull(count(1), 0) FROM AL_SOURCE_BLC_PRODUCT";
    @Override
    public void batchInsert(final List<Map<String, String>> sourceBlcProducts) {
        getJdbcTemplate().batchUpdate(BATCH_INSERT_SQL, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                Map<String, String> sourceBlcProduct = sourceBlcProducts.get(i);
                ps.setString(1, sourceBlcProduct.get("PRODUCT_ID"));
                ps.setString(2, sourceBlcProduct.get("URL"));
                ps.setLong(3, Long.parseLong(sourceBlcProduct.get("DEFAULT_CATEGORY_ID")));
                ps.setInt(4, Integer.parseInt(sourceBlcProduct.get("MCR_ID")));
            }
            @Override
            public int getBatchSize() {
                return sourceBlcProducts.size();
            }
        });
    }

    @Override
    public List<Map<String, String>> getAllDataByMcrId(int mcrId) {
        return getJdbcTemplate().query(QUERY_GET_ALL_DATA_BY_MCR_ID, new Object[]{mcrId, mcrId, mcrId},
                new RowMapper<Map<String, String>>() {
            @Override
            public Map<String, String> mapRow(ResultSet rs, int rowNum) throws SQLException {
                Map<String, String> product = new HashMap<String, String>();
                product.put("PRODUCT_ID", rs.getString(1));
                product.put("URL", rs.getString(2));
                product.put("DEFAULT_CATEGORY_ID", rs.getString(3));
                product.put("MODEL_NUM", rs.getString(4));
                product.put("VENDOR_LOGO", rs.getString(5));
                return product;
            }
        });
    }

    @Override
    public Long getMaxId() {
        return getJdbcTemplate().queryForLong(GET_MAX_ID);
    }

    /**
     * A constructor method.
     * @param jdbcTemplate A {@link org.springframework.jdbc.core.JdbcTemplate} object that executes JDBC statements.
     */
    public SourceBlcProductDao(JdbcTemplate jdbcTemplate) {
        setJdbcTemplate(jdbcTemplate);
    }

}
