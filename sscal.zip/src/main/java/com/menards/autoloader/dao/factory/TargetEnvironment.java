package com.menards.autoloader.dao.factory;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public enum TargetEnvironment {
    PRODUCTION, STAGE
}
