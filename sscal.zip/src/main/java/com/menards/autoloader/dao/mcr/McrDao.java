package com.menards.autoloader.dao.mcr;

import com.menards.autoloader.domain.mcr.ExcelValidationHistory;
import com.menards.autoloader.domain.mcr.MCR;
import com.menards.autoloader.domain.mcr.User;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Repository
public class McrDao {

    @Autowired
    private PriorityDao priorityDao;

    private static final Logger LOG = LoggerFactory.getLogger(McrDao.class);

    private static final String INSERT_MCR =
            "insert into AL_BIZ_MCR(ID, TITLE, PRIORITY_ID, DATE_REQUIRED, SUBMITTER_NAME,"
            + " SUBMITTER_EMAIL, CHANGE_REASON, CHANGE_EXPLANATION, BUSINESS_IMPACT, VENDOR, ALL_APPROVED) "
            + "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String GET_NEXT_ID = "select ifnull(max(id), 0)+1 from AL_BIZ_MCR";

    private static final String GET_ALL_APPROVED_MCR =
            "SELECT ID, TITLE, PRIORITY_ID, DATE_REQUIRED, SUBMITTER_NAME, SUBMITTER_EMAIL, "
            + "CHANGE_REASON, CHANGE_EXPLANATION, BUSINESS_IMPACT, VENDOR, ALL_APPROVED "
            + "FROM AL_BIZ_MCR "
            + "WHERE ALL_APPROVED = 'YES'";

    private static final String GET_PENDING_MCR_WITH_CATALOG = new StringBuilder()
            .append("SELECT mcr.id, ")
            .append("       mcr.title, ")
            .append("       vali_hist.excel_path ")
            .append("FROM   AL_BIZ_MCR mcr, ")
            .append("       (SELECT vali.excel_path, ")
            .append("               vali.vendor, ")
            .append("               Max(vali.validation_timestamp) validation_time ")
            .append("        FROM   AL_BIZ_EXCEL_VALIDATION_HISTORY vali ")
            .append("        GROUP  BY vali.vendor) AS vali_hist ")
            .append("WHERE  mcr.vendor = vali_hist.vendor and mcr.ALL_APPROVED = 'NO' ").toString();

    private static final String GET_MCR_BY_ID =
            "SELECT ID, TITLE, PRIORITY_ID, DATE_REQUIRED, SUBMITTER_NAME, SUBMITTER_EMAIL, "
            + "CHANGE_REASON, CHANGE_EXPLANATION, BUSINESS_IMPACT, VENDOR, ALL_APPROVED "
            + "FROM AL_BIZ_MCR "
            + "WHERE ID = ?";

    private static final String IS_IN_PROCESS_MCR_CREATED_FOR_VENDOR =
            "select case when count(1) > 0 then 'true' else 'false' end "
            + "from AL_BIZ_MCR where vendor = ? "
            + "AND STAGE_PUBLISHED_TO_PRODUCTION = 'NO'" ;

    private static final String GET_VENDOR_BY_MCR_ID = "select VENDOR from AL_BIZ_MCR WHERE ID = ?";

    private static final String GET_ALL_VENDOR_CANDIDATES_FOR_NEW_MCR =
            "select hist_full.EXCEL_PATH, hist_full.VENDOR from AL_BIZ_EXCEL_VALIDATION_HISTORY hist_full "
            + "join( "
            + "SELECT vendor, max(validation_timestamp) ts "
            + "FROM AL_BIZ_EXCEL_VALIDATION_HISTORY "
            + "group by vendor "
            + ") hist_latest "
            + "on hist_full.vendor = hist_latest.vendor "
            + "where hist_full.VALIDATION_TIMESTAMP = hist_latest.ts "
            + "AND "
            + "hist_full.VENDOR not in (select vendor from AL_BIZ_MCR where ALL_APPROVED = 'NO') "
            + "AND (hist_full.VALIDATION_STATUS = 'PASSED' OR hist_full.REACTIVATE_VALIDATION_STATUS = 'PASSED') "
            + "AND hist_full.VENDOR NOT IN "
            + "(SELECT DISTINCT VENDOR FROM AL_BIZ_MCR WHERE STAGE_PUBLISHED_TO_PRODUCTION = 'NO')";

    private static final String GET_ALL_CANDIDATE_MCR_FOR_PRODUCTION_RELEASE =
            "SELECT ID, VENDOR, TITLE FROM AL_BIZ_MCR WHERE ALL_APPROVED = 'YES' AND stage_approved = 'YES' "
                    + "AND stage_published_to_production = 'YES' AND production_released = 'NO' ";


    private static final String GET_ALL_CANDIDATE_MCR_FOR_STAGE_APPROVAL = new StringBuffer()
            .append("SELECT mcr.id, ")
            .append("       mcr.title, ")
            .append("       vali_hist.excel_path ")
            .append("FROM   AL_BIZ_MCR mcr, ")
            .append("       (SELECT vali.excel_path, ")
            .append("               vali.vendor, ")
            .append("               Max(vali.validation_timestamp) validation_time ")
            .append("        FROM   AL_BIZ_EXCEL_VALIDATION_HISTORY vali ")
            .append("        WHERE  vali.reactivate_validation_status = 'PASSED' OR vali.validation_status = 'PASSED'")
            .append("        GROUP  BY vali.vendor) AS vali_hist ")
            .append("WHERE  mcr.vendor = vali_hist.vendor ")
            .append("       AND mcr.ALL_APPROVED = 'YES' ")
            .append("       AND mcr.STAGE_APPROVED = 'NO' ").toString();

    private static final String MCR_STAGE_APPROVE = "UPDATE AL_BIZ_MCR set stage_approved = 'YES' where id = ?";

    private static final String MCR_STAGE_PUBLISHED_TO_PRODUCTION =
            "UPDATE AL_BIZ_MCR set stage_published_to_production = 'YES' where id = ?";

    private static final String UPDATE_MCR_AFTER_PRODUCTION_RELEASED = "update AL_BIZ_MCR "
            + "SET PRODUCTION_RELEASED = 'YES' "
            + "where ALL_APPROVED = 'YES'  "
            + "AND STAGE_APPROVED = 'YES' "
            + "AND STAGE_PUBLISHED_TO_PRODUCTION = 'YES' "
            + "AND PRODUCTION_RELEASED = 'NO' ";

    private static final String UPDATE_FOR_MCR_ALL_APPROVED = "UPDATE AL_BIZ_MCR SET ALL_APPROVED = 'YES' where id = ? ";

    private static final String GET_ALL_IN_PROGRESS_MCR =
            " SELECT mcr.id, mcr.vendor, mcr.title, mcr.all_approved, "
            + " mcr.stage_approved, mcr.stage_published_to_production, "
            + " mcr.production_released, excel.excel_path"
            + " FROM ("
            + " SELECT ID, VENDOR, TITLE, ALL_APPROVED, STAGE_APPROVED, "
            + " STAGE_PUBLISHED_TO_PRODUCTION, PRODUCTION_RELEASED"
            + " FROM AL_BIZ_MCR"
            + " WHERE PRODUCTION_RELEASED = 'NO'"
            + " ) mcr"
            + " join ("
            + " select distinct hist_full.EXCEL_PATH, hist_full.VENDOR from AL_BIZ_EXCEL_VALIDATION_HISTORY hist_full"
            + " join("
            + " SELECT vendor, max(validation_timestamp) ts"
            + " FROM AL_BIZ_EXCEL_VALIDATION_HISTORY  "
            + " group by vendor"
            + " ) hist_latest "
            + " on hist_full.vendor = hist_latest.vendor"
            + " where hist_full.VALIDATION_TIMESTAMP = hist_latest.ts"
            + " ) excel"
            + " on mcr.vendor = excel.vendor";

    private static final String GET_ALL_STAGE_PUBLISHED_TO_PRODUCTION_MCR =
            "SELECT id, vendor, title, all_approved, stage_approved, "
            + "stage_published_to_production, production_released, excel_path "
            + "FROM AL_BIZ_MCR "
            + "WHERE ALL_APPROVED = 'YES' AND stage_approved = 'YES' "
            + "AND stage_published_to_production = 'YES' AND production_released = 'NO' ";

    private static final String GET_MCR_FOR_STAGE_PUBLISH =
            "SELECT ID FROM AL_BIZ_MCR WHERE ALL_APPROVED = 'YES' "
            + "and STAGE_APPROVED = 'YES' AND STAGE_PUBLISHED_TO_PRODUCTION = 'NO' ";

    private static final String ROLL_BACK_MCR_STATUS_FOR_EXCEL_TO_STAGE_JOB =
            "UPDATE AL_BIZ_MCR SET ALL_APPROVED = 'NO' WHERE ID = ?";

    private static final String ROLL_BACK_MCR_STATUS_FOR_STAGE_TO_PRODUCTION_JOB =
            "UPDATE AL_BIZ_MCR SET STAGE_PUBLISHED_TO_PRODUCTION = 'NO' WHERE ID = ?";

    private static final String ROLL_BACK_MCR_STATUS_FOR_PRODUCTION_RELEASE_JOB =
            "UPDATE AL_BIZ_MCR SET PRODUCTION_RELEASED = 'NO' WHERE ID = ?";

    private static final String GET_MCR_FOR_REACTIVATION =
            "SELECT mcr.ID, mcr.TITLE, vali_hist.EXCEL_PATH "
            + "FROM AL_BIZ_MCR mcr "
            + "JOIN ( "
            + "SELECT h1.excel_path, h1.vendor "
            + "FROM AL_BIZ_EXCEL_VALIDATION_HISTORY h1 "
            + "JOIN ( "
            + "SELECT MAX(validation_timestamp) vali_time, vendor "
            + "FROM AL_BIZ_EXCEL_VALIDATION_HISTORY "
            + "GROUP BY VENDOR "
            + ") h2 ON h1.validation_timestamp = h2.vali_time AND h1.vendor = h2.vendor "
            + "where h1.reactivate_validation_status = 'PASSED' "
            + ") vali_hist ON mcr.vendor = vali_hist.vendor "
            + "WHERE mcr.ALL_APPROVED = 'YES' AND mcr.STAGE_APPROVED = 'NO' ";

    private static final String SET_EXCEL_PATH_FOR_MCR = "update AL_BIZ_MCR set EXCEL_PATH = ? where id = ?";

    /**
     *
     * @param excelPath excel path
     * @param mcrId mcr id
     */
    public void setExcelPathForMcr(String excelPath, int mcrId) {
        jdbcTemplate.update(SET_EXCEL_PATH_FOR_MCR, excelPath, mcrId);
    }

    /**
     *
     * @param mcrId mcr id
     */
    public void rollbackMcrStatusForExcelStageJob(int mcrId) {
        jdbcTemplate.update(ROLL_BACK_MCR_STATUS_FOR_EXCEL_TO_STAGE_JOB, mcrId);
    }

    /**
     *
     * @param mcrId mcr id
     */
    public void rollbackMcrStatusForStageToProductionJob(int mcrId) {
        jdbcTemplate.update(ROLL_BACK_MCR_STATUS_FOR_STAGE_TO_PRODUCTION_JOB, mcrId);
    }

    /**
     *
     * @param mcrId mcr id
     */
    public void rollbackMcrStatusForProductionReleaseJob(int mcrId) {
        jdbcTemplate.update(ROLL_BACK_MCR_STATUS_FOR_PRODUCTION_RELEASE_JOB, mcrId);
    }

    /**
     * update mcr after production release
     */
    public void updateMCRAfterProductionReleased() {
        jdbcTemplate.update(UPDATE_MCR_AFTER_PRODUCTION_RELEASED);
    }

    public List<MCR> getMcrListForReactivation() {
        return jdbcTemplate.query(GET_MCR_FOR_REACTIVATION, new RowMapper<MCR>() {
            @Override
            public MCR mapRow(ResultSet rs, int rowNum) throws SQLException {
                MCR mcr = new MCR();
                mcr.setId(rs.getInt(1));
                mcr.setTitle(rs.getString(2));
                mcr.setExcelPath(rs.getString(3));
                return mcr;
            }
        });
    }

    public List<Integer> getMcrForStagePublish() {
        return jdbcTemplate.queryForList(GET_MCR_FOR_STAGE_PUBLISH, Integer.class);
    }

    public List<MCR> getAllInProgressMcr() {
        List mcrList = jdbcTemplate.query(GET_ALL_IN_PROGRESS_MCR, new RowMapper<MCR>() {
            @Override
            public MCR mapRow(ResultSet rs, int i) throws SQLException {
                MCR mcr = new MCR();
                mcr.setId(rs.getInt(1));
                mcr.setVendor(rs.getString(2));
                mcr.setTitle(rs.getString(3));
                mcr.setAllApproved(rs.getString(4).equals("YES"));
                mcr.setStageApproved(rs.getString(5).equals("YES"));
                mcr.setStagePublishedToProduction(rs.getString(6).equals("YES"));
                mcr.setProductionReleased(rs.getString(7).equals("YES"));
                mcr.setExcelPath(rs.getString(8));
                return mcr;
            }
        });

        mcrList.addAll(jdbcTemplate.query(GET_ALL_STAGE_PUBLISHED_TO_PRODUCTION_MCR, new RowMapper<MCR>() {
            @Override
            public MCR mapRow(ResultSet rs, int i) throws SQLException {
                MCR mcr = new MCR();
                mcr.setId(rs.getInt(1));
                mcr.setVendor(rs.getString(2));
                mcr.setTitle(rs.getString(3));
                mcr.setAllApproved(rs.getString(4).equals("YES"));
                mcr.setStageApproved(rs.getString(5).equals("YES"));
                mcr.setStagePublishedToProduction(rs.getString(6).equals("YES"));
                mcr.setProductionReleased(rs.getString(7).equals("YES"));
                mcr.setExcelPath(rs.getString(8));
                return mcr;
            }
        }));
        return mcrList;
    }

    /**
     *
     * @param mcrId mcr id
     */
    public void updateForMcrAllApproved(int mcrId) {
        jdbcTemplate.update(UPDATE_FOR_MCR_ALL_APPROVED, mcrId);
    }

    /**
     *
     * @param mcrId mcr id
     */
    public void mcrStageApprove(int mcrId) {
        jdbcTemplate.update(MCR_STAGE_APPROVE, mcrId);
    }

    /**
     *
     * @param mcrId mcr id
     */
    public void mcrStagePublishedToProduction(int mcrId) {
        jdbcTemplate.update(MCR_STAGE_PUBLISHED_TO_PRODUCTION, mcrId);
    }

    public List<MCR> getAllCandidateMcrForStageApproval() {
        return jdbcTemplate.query(GET_ALL_CANDIDATE_MCR_FOR_STAGE_APPROVAL, new RowMapper<MCR>() {
            @Override
            public MCR mapRow(ResultSet rs, int rowNum) throws SQLException {
                MCR mcr = new MCR();
                mcr.setId(rs.getInt(1));
                mcr.setTitle(rs.getString(2));
                mcr.setExcelPath(rs.getString(3));
                return mcr;
            }
        });
    }


    public List<MCR> getAllCandidateMcrForProductionRelease() {
        return jdbcTemplate.query(GET_ALL_CANDIDATE_MCR_FOR_PRODUCTION_RELEASE, new RowMapper<MCR>() {
            @Override
            public MCR mapRow(ResultSet rs, int rowNum) throws SQLException {
                MCR mcr = new MCR();
                mcr.setId(rs.getInt(1));
                mcr.setVendor(rs.getString(2));
                mcr.setTitle(rs.getString(3));
                return mcr;
            }
        });
    }

    public List<ExcelValidationHistory> getAllVendorCandidatesForNewMcr() {
        return jdbcTemplate.query(GET_ALL_VENDOR_CANDIDATES_FOR_NEW_MCR, new RowMapper<ExcelValidationHistory>() {
            @Override
            public ExcelValidationHistory mapRow(ResultSet rs, int rowNum) throws SQLException {
                ExcelValidationHistory history = new ExcelValidationHistory();
                history.setExcelPath(rs.getString(1));
                history.setVendor(rs.getString(2));
                return history;
            }
        });
    }

    /**
     *
     * @param mcrId mcr id
     * @return vendor
     */
    public String getVendorByMcrId(int mcrId) {
        return jdbcTemplate.queryForObject(GET_VENDOR_BY_MCR_ID, new Object[]{mcrId}, String.class);
    }

    /**
     *
     * @param mcr mcr
     * @return max id in AL_BIZ_MCR table
     */
    public int saveMcr(MCR mcr) {
        int id = getMaxId();
        jdbcTemplate.update(INSERT_MCR,
                id,
                mcr.getTitle(),
                mcr.getPriority().getId(),
                mcr.getDateRequired(),
                StringUtils.isEmpty(mcr.getSubmitter().getName())
                        ?
                        mcr.getSubmitter().getEmail().substring(0, mcr.getSubmitter().getEmail().indexOf("@"))
                        :
                        mcr.getSubmitter().getName(),
                mcr.getSubmitter().getEmail(),
                mcr.getChangeReason(),
                mcr.getChangeExplanation(),
                mcr.getBusinessImpact(),
                mcr.getVendor(),
                mcr.isAllApproved() ? "YES" : "NO"
        );
        return id;
    }


    public List<MCR> getAllApprovedMcrs() {
        return jdbcTemplate.query(GET_ALL_APPROVED_MCR, new RowMapper<MCR>() {
            @Override
            public MCR mapRow(ResultSet rs, int rowNum) throws SQLException {
                MCR mcr = new MCR();
                mcr.setId(rs.getInt(1));
                mcr.setTitle(rs.getString(2));
                try {
                    mcr.setPriority(priorityDao.getPriorityById(rs.getInt(3)));
                } catch (IOException e) {
                    LOG.error("ERROR OCCURRED:", e);
                }
                mcr.setDateRequired(rs.getDate(4));
                User submitter = new User();
                submitter.setName(rs.getString(5));
                submitter.setEmail(rs.getString(6));
                mcr.setSubmitter(submitter);
                mcr.setChangeReason(rs.getString(7));
                mcr.setChangeExplanation(rs.getString(8));
                mcr.setBusinessImpact(rs.getString(9));
                mcr.setVendor(rs.getString(10));
                mcr.setAllApproved(rs.getString(11).equals("YES"));
                return mcr;
            }
        });
    }

    public List<MCR> getPendingMcrListWithCatalog() {
        return jdbcTemplate.query(GET_PENDING_MCR_WITH_CATALOG, new RowMapper<MCR>() {
            @Override
            public MCR mapRow(ResultSet rs, int rowNum) throws SQLException {
                MCR mcr = new MCR();
                mcr.setId(rs.getInt(1));
                mcr.setTitle(rs.getString(2));
                mcr.setExcelPath(rs.getString(3));
                return mcr;
            }
        });
    }

    /**
     *
     * @param vendor vendor
     * @return flag
     */
    public boolean isInProgressMcrCreatedForVendor(String vendor) {
        return Boolean.valueOf(jdbcTemplate.queryForObject(
                IS_IN_PROCESS_MCR_CREATED_FOR_VENDOR,
                new Object[]{vendor},
                String.class)
        );
    }

    private int getMaxId() {
        return jdbcTemplate.queryForInt(GET_NEXT_ID);
    }

    @Autowired
    @Qualifier("autoLoaderBizJdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     *
     * @param mcrId mcr id
     * @return MCR
     */
    public MCR getMcrById(int mcrId) {
        return jdbcTemplate.queryForObject(GET_MCR_BY_ID,
                new Object[]{mcrId}, new int[]{Types.INTEGER}, new RowMapper<MCR>() {
            @Override
            public MCR mapRow(ResultSet rs, int rowNum) throws SQLException {
                MCR mcr = new MCR();
                mcr.setId(rs.getInt(1));
                mcr.setTitle(rs.getString(2));
                IOException ioException = null;
                try {
                    mcr.setPriority(priorityDao.getPriorityById(rs.getInt(3)));
                } catch (IOException e) {
                    ioException = e;
                    LOG.error("ERROR OCCURRED:", e);
                }
                Assert.isTrue(ioException == null, ioException == null ? "" : ioException.getMessage());
                mcr.setDateRequired(rs.getDate(4));
                User submitter = new User();
                submitter.setName(rs.getString(5));
                submitter.setEmail(rs.getString(6));
                mcr.setSubmitter(submitter);
                mcr.setChangeReason(rs.getString(7));
                mcr.setChangeExplanation(rs.getString(8));
                mcr.setBusinessImpact(rs.getString(9));
                mcr.setVendor(rs.getString(10));
                mcr.setAllApproved(rs.getString(11).equals("YES"));
                return mcr;
            }
        });
    }

}
