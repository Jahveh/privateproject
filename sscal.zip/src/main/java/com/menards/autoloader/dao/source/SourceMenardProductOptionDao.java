package com.menards.autoloader.dao.source;

import com.menards.autoloader.dao.DaoAdapter;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>SourceMenardProductOptionDao</p>
 * <p>A {@link DaoAdapter} sub class for manipulating AL_SOURCE_MENARD_PRODUCT_OPTION table.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class SourceMenardProductOptionDao extends DaoAdapter<List<Map<String, String>>> {
    private static final String BATCH_INSERT_SQL =
        "insert into AL_SOURCE_MENARD_PRODUCT_OPTION (BASE_PRODUCT_ID, OPTION_PRODUCT_ID, MANDATORY, MCR_ID) "
        + "values (?, ?, ?, ?)";
    private static final String QUERY_GET_ALL_DATA_BY_MCR_ID =
            "SELECT BASE_PRODUCT_ID, OPTION_PRODUCT_ID, MANDATORY from AL_SOURCE_MENARD_PRODUCT_OPTION WHERE MCR_ID = ?";
    private static final String DELETE_ALL_BY_MCR_ID = "DELETE FROM AL_SOURCE_MENARD_PRODUCT_OPTION WHERE MCR_ID = ?";

    @Override
    public void deleteAllByMcrId(int mcrId) {
        getJdbcTemplate().update(DELETE_ALL_BY_MCR_ID, mcrId);
    }

    @Override
    public void batchInsert(final List<Map<String, String>> sourceMenardProductOptions) {
        getJdbcTemplate().batchUpdate(BATCH_INSERT_SQL, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                Map<String, String> sourceMenardProductOption = sourceMenardProductOptions.get(i);
                ps.setString(1, sourceMenardProductOption.get("BASE_PRODUCT_ID"));
                ps.setString(2, sourceMenardProductOption.get("OPTION_PRODUCT_ID"));
                ps.setString(3, sourceMenardProductOption.get("MANDATORY"));
                ps.setInt(4, Integer.parseInt(sourceMenardProductOption.get("MCR_ID")));
            }
            @Override
            public int getBatchSize() {
                return sourceMenardProductOptions.size();
            }
        });
    }

    @Override
    public List<Map<String, String>> getAllDataByMcrId(int mcrId) {
        return getJdbcTemplate().query(QUERY_GET_ALL_DATA_BY_MCR_ID,
                new Object[]{mcrId},
                new RowMapper<Map<String, String>>() {
            @Override
            public Map<String, String> mapRow(ResultSet rs, int rowNum) throws SQLException {
                Map<String, String> sourceMenardProductOption = new HashMap<String, String>();
                sourceMenardProductOption.put("BASE_PRODUCT_ID", rs.getString(1));
                sourceMenardProductOption.put("OPTION_PRODUCT_ID", rs.getString(2));
                sourceMenardProductOption.put("MANDATORY", rs.getString(3));
                return sourceMenardProductOption;
            }
        });
    }

    /**
     * A constructor method.
     * @param jdbcTemplate A {@link org.springframework.jdbc.core.JdbcTemplate} object that executes JDBC statements.
     */
    public SourceMenardProductOptionDao(JdbcTemplate jdbcTemplate) {
        setJdbcTemplate(jdbcTemplate);
    }

}
