package com.menards.autoloader.dao.factory;

import com.menards.autoloader.dao.IDao;
import com.menards.autoloader.dao.source.SourceBlcCategoryProductXrefDao;
import com.menards.autoloader.dao.source.SourceBlcProductAttributeDao;
import com.menards.autoloader.dao.source.SourceBlcProductDao;
import com.menards.autoloader.dao.source.SourceBlcProductSkuXrefDao;
import com.menards.autoloader.dao.source.SourceBlcSkuAttributeDao;
import com.menards.autoloader.dao.source.SourceBlcSkuDao;
import com.menards.autoloader.dao.source.SourceMenardProductDao;
import com.menards.autoloader.dao.source.SourceMenardProductOptionDao;
import com.menards.autoloader.dao.source.SourceMenardSkuDao;
import com.menards.autoloader.dao.target.BlcCategoryDao;
import com.menards.autoloader.dao.target.BlcCategoryProductXrefDao;
import com.menards.autoloader.dao.target.BlcProductAttributeDao;
import com.menards.autoloader.dao.target.BlcProductDao;
import com.menards.autoloader.dao.target.BlcProductSkuXrefDao;
import com.menards.autoloader.dao.target.BlcSkuAttributeDao;
import com.menards.autoloader.dao.target.BlcSkuDao;
import com.menards.autoloader.dao.target.MenardProductDao;
import com.menards.autoloader.dao.target.MenardProductOptionDao;
import com.menards.autoloader.dao.target.MenardSkuDao;
import com.menards.autoloader.dao.target.MenardVendorDao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;

/**
 * <p>ProductionDaoFactory</p>
 * <p>An {@link IDaoFactory} implementation class for creating DAO objects for production DB tables.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class ProductionDaoFactory implements IDaoFactory<List<Map<String, String>>> {
    private static final Logger LOG = LoggerFactory.getLogger(StageDaoFactory.class);
    //Target tables
    private IDao<List<Map<String, String>>> blcCategoryDao;
    private IDao<List<Map<String, String>>> blcCategoryProductXrefDao;
    private IDao<List<Map<String, String>>> blcProductSkuXrefDao;
    private IDao<List<Map<String, String>>> blcProductDao;
    private IDao<List<Map<String, String>>> blcSkuAttributeDao;
    private IDao<List<Map<String, String>>> blcSkuDao;
    private IDao<List<Map<String, String>>> blcProductAttributeDao;
    private IDao<List<Map<String, String>>> menardProductDao;
    private IDao<List<Map<String, String>>> menardProductOptionDao;
    private IDao<List<Map<String, String>>> menardSkuDao;
    private IDao<List<Map<String, String>>> menardVendorDao;

    //Source tables
    private IDao<List<Map<String, String>>> sourceBlcCategoryProductXrefDao;
    private IDao<List<Map<String, String>>> sourceBlcProductSkuXrefDao;
    private IDao<List<Map<String, String>>> sourceBlcProductAttributeDao;
    private IDao<List<Map<String, String>>> sourceBlcProductDao;
    private IDao<List<Map<String, String>>> sourceBlcSkuAttributeDao;
    private IDao<List<Map<String, String>>> sourceBlcSkuDao;
    private IDao<List<Map<String, String>>> sourceMenardProductDao;
    private IDao<List<Map<String, String>>> sourceMenardProductOptionDao;
    private IDao<List<Map<String, String>>> sourceMenardSkuDao;

    @Override
    public IDao getDao(DaoNames daoName) {
        switch (daoName) {
            //Target tables
            case BLC_CATEGORY_DAO: return blcCategoryDao;
            case BLC_CATEGORY_PRODUCT_XREF_DAO: return blcCategoryProductXrefDao;
            case BLC_PRODUCT_SKU_XREF_DAO: return blcProductSkuXrefDao;
            case BLC_PRODUCT_DAO: return blcProductDao;
            case BLC_SKU_ATTRIBUTE_DAO: return blcSkuAttributeDao;
            case BLC_SKU_DAO: return blcSkuDao;
            case BLC_PRODUCT_ATTRIBUTE_DAO: return blcProductAttributeDao;
            case MENARD_PRODUCT_DAO: return menardProductDao;
            case MENARD_PRODUCT_OPTION_DAO: return menardProductOptionDao;
            case MENARD_SKU_DAO: return menardSkuDao;
            case MENARD_VENDOR_DAO: return menardVendorDao;

            //Source tables
            case SOURCE_BLC_CATEGORY_PRODUCT_XREF_DAO: return sourceBlcCategoryProductXrefDao;
            case SOURCE_BLC_PRODUCT_SKU_XREF_DAO: return sourceBlcProductSkuXrefDao;
            case SOURCE_BLC_PRODUCT_ATTRIBUTE_DAO: return sourceBlcProductAttributeDao;
            case SOURCE_BLC_PRODUCT_DAO: return sourceBlcProductDao;
            case SOURCE_BLC_SKU_ATTRIBUTE_DAO: return sourceBlcSkuAttributeDao;
            case SOURCE_BLC_SKU_DAO: return sourceBlcSkuDao;
            case SOURCE_MENARD_PRODUCT_DAO: return sourceMenardProductDao;
            case SOURCE_MENARD_PRODUCT_OPTION_DAO: return sourceMenardProductOptionDao;
            case SOURCE_MENARD_SKU_DAO: return sourceMenardSkuDao;
            default: return null;
        }
    }

    /**
     * A constructor method that accepts an object of {@link org.springframework.jdbc.core.JdbcTemplate}
     * @param jdbcTemplate an object of {@link org.springframework.jdbc.core.JdbcTemplate}
     *                     to which all the Dao JDBC operations will be delegated.
     * @throws Exception an Exception
     */
    public ProductionDaoFactory(JdbcTemplate jdbcTemplate) throws Exception {
        LOG.info("Initializing ProductionDaoFactory..");
        blcCategoryDao = new BlcCategoryDao(jdbcTemplate);
        blcCategoryProductXrefDao = new BlcCategoryProductXrefDao(jdbcTemplate, TargetEnvironment.PRODUCTION);
        blcProductSkuXrefDao = new BlcProductSkuXrefDao(jdbcTemplate, TargetEnvironment.PRODUCTION);
        blcProductDao = new BlcProductDao(jdbcTemplate, TargetEnvironment.PRODUCTION);
        blcSkuAttributeDao = new BlcSkuAttributeDao(jdbcTemplate, TargetEnvironment.PRODUCTION);
        blcSkuDao = new BlcSkuDao(jdbcTemplate, TargetEnvironment.PRODUCTION);
        blcProductAttributeDao = new BlcProductAttributeDao(jdbcTemplate, TargetEnvironment.PRODUCTION);
        menardProductDao = new MenardProductDao(jdbcTemplate, TargetEnvironment.PRODUCTION);
        menardProductOptionDao = new MenardProductOptionDao(jdbcTemplate, TargetEnvironment.PRODUCTION);
        menardSkuDao = new MenardSkuDao(jdbcTemplate, TargetEnvironment.PRODUCTION);
        menardVendorDao = new MenardVendorDao(jdbcTemplate);

        //Source tables
        sourceBlcCategoryProductXrefDao = new SourceBlcCategoryProductXrefDao(jdbcTemplate);
        sourceBlcProductSkuXrefDao = new SourceBlcProductSkuXrefDao(jdbcTemplate);
        sourceBlcProductAttributeDao = new SourceBlcProductAttributeDao(jdbcTemplate);
        sourceBlcProductDao = new SourceBlcProductDao(jdbcTemplate);
        sourceBlcSkuAttributeDao = new SourceBlcSkuAttributeDao(jdbcTemplate);
        sourceBlcSkuDao = new SourceBlcSkuDao(jdbcTemplate);
        sourceMenardProductDao = new SourceMenardProductDao(jdbcTemplate);
        sourceMenardProductOptionDao = new SourceMenardProductOptionDao(jdbcTemplate);
        sourceMenardSkuDao = new SourceMenardSkuDao(jdbcTemplate);

    }

}
