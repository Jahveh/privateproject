package com.menards.autoloader.dao.factory;

import com.menards.autoloader.dao.IDao;

/**
 * <p>IDaoFactory</p>
 * <p>A DAO factory interface.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @param <T> The type the DAO methods could manipulate.
 * @author frank.peng
 * @version 1.0
 */
public interface IDaoFactory<T> {

    /**
     * Get a Dao object by its name
     * @param daoName dao name specified in the DaoNames.
     * @return a Dao object
     */
    IDao<T> getDao(DaoNames daoName);
}
