package com.menards.autoloader.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Set;

/**
 * <p>DaoAdapter</p>
 * <p>The {@link IDao}'s adapter class that specific DAO classes should inherit from.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @param <T> The type the DAO methods could manipulate.
 * @author frank.peng
 * @version 1.0
 */
public class DaoAdapter<T> implements IDao<T> {

    private JdbcTemplate jdbcTemplate;

    @Override
    public void batchInsert(T dataSet) {
        throw new RuntimeException("batchInsert method is not implemented by " + this.getClass().getCanonicalName());
    }

    @Override
    public void batchDeleteByProductId(List<String> idList) {
        throw new RuntimeException("batchDeleteByProductId method is not implemented by "
                + this.getClass().getCanonicalName());
    }

    @Override
    public void backUpTable() {
        throw new RuntimeException("backUpTable method is not implemented by " + this.getClass().getCanonicalName());
    }

    @Override
    public T getDataByVendor(Set<String> vendors) {
        throw new RuntimeException("getDataByVendor method is not implemented by "
                + this.getClass().getCanonicalName());
    }

    @Override
    public T getAllDataByMcrId(int mcrId) {
        throw new RuntimeException("getAllData method is not implemented by " + this.getClass().getCanonicalName());
    }

    @Override
    public Long getMaxId() {
        throw new RuntimeException("getMaxId method is not implemented by " + this.getClass().getCanonicalName());
    }

    @Override
    public void deleteAllByMcrId(int mcrId) {
        throw new RuntimeException("deleteAll method is not implemented by " + this.getClass().getCanonicalName());
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
}
