package com.menards.autoloader.dao.factory;

import com.menards.autoloader.dao.IDao;
import com.menards.autoloader.dao.source.SourceBlcCategoryProductXrefDao;
import com.menards.autoloader.dao.source.SourceBlcProductAttributeDao;
import com.menards.autoloader.dao.source.SourceBlcProductDao;
import com.menards.autoloader.dao.source.SourceBlcSkuAttributeDao;
import com.menards.autoloader.dao.source.SourceBlcSkuDao;
import com.menards.autoloader.dao.source.SourceMenardProductDao;
import com.menards.autoloader.dao.source.SourceMenardProductOptionDao;
import com.menards.autoloader.dao.source.SourceMenardSkuDao;
import com.menards.autoloader.dao.target.BlcCategoryDao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * <p>PreSourceDaoFactory</p>
 * <p>A {@link IDaoFactory} implementation class for creating DAO objects for source DB.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class AutoLoaderBusinessDaoFactory implements IDaoFactory {
    private static final Logger LOG = LoggerFactory.getLogger(AutoLoaderBusinessDaoFactory.class);
    private IDao blcCategoryDao;
    private IDao sourceBlcCategoryProductXrefDao;
    private IDao sourceBlcProductAttributeDao;
    private IDao sourceBlcProductDao;
    private IDao sourceBlcSkuAttributeDao;
    private IDao sourceBlcSkuDao;
    private IDao sourceMenardProductDao;
    private IDao sourceMenardProductOptionDao;
    private IDao sourceMenardSkuDao;

    @Override
    public IDao getDao(DaoNames daoName) {
        switch(daoName) {
            case BLC_CATEGORY_DAO: return blcCategoryDao;
            case SOURCE_BLC_CATEGORY_PRODUCT_XREF_DAO: return sourceBlcCategoryProductXrefDao;
            case SOURCE_BLC_PRODUCT_ATTRIBUTE_DAO: return sourceBlcProductAttributeDao;
            case SOURCE_BLC_PRODUCT_DAO: return sourceBlcProductDao;
            case SOURCE_BLC_SKU_ATTRIBUTE_DAO: return sourceBlcSkuAttributeDao;
            case SOURCE_BLC_SKU_DAO: return sourceBlcSkuDao;
            case SOURCE_MENARD_PRODUCT_DAO: return sourceMenardProductDao;
            case SOURCE_MENARD_PRODUCT_OPTION_DAO: return sourceMenardProductOptionDao;
            case SOURCE_MENARD_SKU_DAO: return sourceMenardSkuDao;
            default: return null;
        }
    }
    /**
     * A constructor method that accepts an object of {@link org.springframework.jdbc.core.JdbcTemplate}
     * @param jdbcTemplate an object of {@link org.springframework.jdbc.core.JdbcTemplate}
     *                     to which all the Dao JDBC operations will be delegated.
     * @throws Exception an Exception
     */
    public AutoLoaderBusinessDaoFactory(JdbcTemplate jdbcTemplate) throws Exception {
        LOG.info("Initializing PreSourceDaoFactory..");
        blcCategoryDao = new BlcCategoryDao(jdbcTemplate);
        sourceBlcCategoryProductXrefDao = new SourceBlcCategoryProductXrefDao(jdbcTemplate);
        sourceBlcProductAttributeDao = new SourceBlcProductAttributeDao(jdbcTemplate);
        sourceBlcProductDao = new SourceBlcProductDao(jdbcTemplate);
        sourceBlcSkuAttributeDao = new SourceBlcSkuAttributeDao(jdbcTemplate);
        sourceBlcSkuDao = new SourceBlcSkuDao(jdbcTemplate);
        sourceMenardProductDao = new SourceMenardProductDao(jdbcTemplate);
        sourceMenardProductOptionDao = new SourceMenardProductOptionDao(jdbcTemplate);
        sourceMenardSkuDao = new SourceMenardSkuDao(jdbcTemplate);
    }

}
