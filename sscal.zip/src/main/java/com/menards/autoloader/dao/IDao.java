package com.menards.autoloader.dao;

import java.util.List;
import java.util.Set;

/**
 * <p>IDao</p>
 * <p>A DAO interface.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @param <T> The type the DAO methods could manipulate.
 * @author frank.peng
 * @version 1.0
 */

public interface IDao<T> {

    /**
     * Batch insert a list of data.
     * @param dataList a list of data.
     */
    void batchInsert(T dataList);

    /**
     * Batch delete a list of products and all its sub objects.
     * @param idList a list of product id.
     */
    void batchDeleteByProductId(List<String> idList);

    /**
     * backup tables.
     */
    void backUpTable();

    /**
     * Get data by a list of vendors.
     * @param vendors a list of vendors
     * @return T
     */
    T getDataByVendor(Set<String> vendors);

    /**
     * Get all data by mcr id.
     * @param mcrId mcr id
     * @return the data from DB.
     */
    T getAllDataByMcrId(int mcrId);

    /**
     * Get max id number.
     * @return the mox id number from db.
     */
    Long getMaxId();

    /**
     * @param mcrId mcr id
     * Delete all data
     */
    void deleteAllByMcrId(int mcrId);
}
