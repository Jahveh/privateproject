package com.menards.autoloader.dao.mcr;

import com.menards.autoloader.domain.mcr.StageApprovalInfo;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author eason.yu
 * @version 1.0
 */
@Repository
public class McrStageApprovalDao {
    private static final String INSERT_MCR_STAGE_APPROVAL_HISTORY =
        "insert into AL_BIZ_MCR_STAGE_APPROVAL_HISTORY(MCR_ID, APPROVER_NAME, APPROVER_EMAIL, APPROVAL_DATE) "
        + "values (?, ?, ?, ?)";

    private static final String GET_MCR_STAGE_APPROVAL_HISTORY_BY_MCR_ID =
        "SELECT MCR_ID mcrId, APPROVER_NAME approvalName, APPROVER_EMAIL approvalEmail, APPROVAL_DATE date "
        + " FROM AL_BIZ_MCR_STAGE_APPROVAL_HISTORY WHERE MCR_ID = ?";


    /**
     *
     * @param stageApproval an object of StageApprovalInfo
     * @return the number of updated record
     */
    public int insertIntoStageApproval(StageApprovalInfo stageApproval) {
        return jdbcTemplate.update(INSERT_MCR_STAGE_APPROVAL_HISTORY, 
        		stageApproval.getMcrId(), stageApproval.getApprovalName(), 
        		stageApproval.getApprovalEmail(), stageApproval.getDate());
    }

    /**
     *
     * @param mcrId mcr id
     * @return an object of StageApprovalInfo
     */
    public StageApprovalInfo getStageApprovalByMcrId(int mcrId) {
    	List<StageApprovalInfo> infos =  jdbcTemplate.query(GET_MCR_STAGE_APPROVAL_HISTORY_BY_MCR_ID, 
    			new Object[]{mcrId}, new RowMapper<StageApprovalInfo>(){
    		
					@Override
					public StageApprovalInfo mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final StageApprovalInfo info = new StageApprovalInfo();
						info.setMcrId(rs.getInt(1));
						info.setApprovalName(rs.getString(2));
						info.setApprovalEmail(rs.getString(3));
						info.setDate(rs.getDate(4));
						return info;
					}});
    	if (CollectionUtils.isNotEmpty(infos)) {
    		return infos.get(0);
    	}
    	return null;
    }


    @Autowired
    @Qualifier("autoLoaderBizJdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

}
