package com.menards.autoloader.dao.mcr;

import au.com.bytecode.opencsv.CSVReader;

import com.menards.autoloader.domain.mcr.Priority;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Repository;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Repository
public class PriorityDao {
    private static final String PRIORITY_FILE_PATH = "/lookup-data/priority.csv";

    /**
     *
     * @return a list of priority
     * @throws IOException io exception
     */
    public List<Priority> getAllPriorities() throws IOException {
        List<Priority> allPriorities = new ArrayList<Priority>();
        Resource resource = new ClassPathResource(PRIORITY_FILE_PATH);
        CSVReader csvReader = new CSVReader(new FileReader(resource.getFile()), ',');
        String [] nextLine;

        while ((nextLine = csvReader.readNext()) != null) {
            Priority priority = new Priority();
            priority.setId(Integer.valueOf(nextLine[0]));
            priority.setName(nextLine[1]);
            allPriorities.add(priority);
        }
        Collections.sort(allPriorities, new Comparator<Priority>() {
            @Override
            public int compare(Priority o1, Priority o2) {
                if (o1.getId() > o2.getId()) {
                    return 1;
                } else if (o1.getId() < o2.getId()) {
                    return -1;
                } else {
                    return 0;
                }
            }
        });
        return allPriorities;
    }

    /**
     *
     * @param i priority id
     * @return priority
     * @throws IOException io exception
     */
    public Priority getPriorityById(int i) throws IOException {
        List<Priority> priorities = getAllPriorities();
        for (Priority priority : priorities) {
            if (priority.getId() == i) {
                return priority;
            }
        }
        return null;
    }
}
