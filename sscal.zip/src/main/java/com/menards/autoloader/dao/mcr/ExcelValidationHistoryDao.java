package com.menards.autoloader.dao.mcr;

import com.menards.autoloader.domain.mcr.ExcelValidationHistory;
import com.menards.autoloader.domain.mcr.ExcelValidationStatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.jdbc.support.lob.LobHandler;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Repository
public class ExcelValidationHistoryDao {
    private static final String QUERY_GET_LATEST_VALIDATION_STATUS_BY_VENDOR =
                    "SELECT VALIDATION_STATUS, REACTIVATE_VALIDATION_STATUS "
                    + "FROM AL_BIZ_EXCEL_VALIDATION_HISTORY "
                    + "WHERE VALIDATION_TIMESTAMP = ( "
                    + "        SELECT MAX(VALIDATION_TIMESTAMP) "
                    + "FROM AL_BIZ_EXCEL_VALIDATION_HISTORY "
                    + "WHERE VENDOR = ?) ";

    private static final String INSERT_VALIDATION_HISTORY =
                    "INSERT INTO AL_BIZ_EXCEL_VALIDATION_HISTORY "
                    + "(EXCEL_PATH, RESOURCE_FOLDER_PATH, MOVE_RESOURCE, VENDOR, "
                    + "VALIDATION_STATUS, LOG, EXCEL_FILE_CHECKSUM, EXCEL_FILE) "
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String INSERT_VALIDATION_HISTORY_FOR_REACTIVATION =
                    "INSERT INTO AL_BIZ_EXCEL_VALIDATION_HISTORY "
                    + "(EXCEL_PATH, RESOURCE_FOLDER_PATH, MOVE_RESOURCE, VENDOR, "
                    + "REACTIVATE_VALIDATION_STATUS, LOG, EXCEL_FILE_CHECKSUM, EXCEL_FILE) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String DELETE_VALIDATION_HISTORY_BY_VENDOR =
                    "DELETE FROM AL_BIZ_EXCEL_VALIDATION_HISTORY WHERE VENDOR = ?";

    private static final String GET_EXCEL_VALIDATION_HISTORIES_BY_MCR_ID =
                     "SELECT biz_hist.EXCEL_PATH, biz_hist.RESOURCE_FOLDER_PATH, biz_hist.MOVE_RESOURCE, "
                    + "biz_hist.VENDOR, biz_hist.VALIDATION_STATUS,  "
                    + "biz_hist.REACTIVATE_VALIDATION_STATUS,  "
                    + "biz_hist.VALIDATION_TIMESTAMP, "
                    + "biz_hist.EXCEL_FILE_CHECKSUM "
                    + "FROM AL_BIZ_EXCEL_VALIDATION_HISTORY biz_hist "
                    + "JOIN ( "
                    + "SELECT VENDOR, MAX(validation_timestamp) max_time "
                    + "FROM AL_BIZ_EXCEL_VALIDATION_HISTORY "
                    + "WHERE (validation_status = 'PASSED' OR reactivate_validation_status = 'PASSED') "
                    + "and vendor in (SELECT VENDOR FROM AL_BIZ_MCR where ID = ?) "
                    + "GROUP BY vendor "
                    + ") max_vendor "
                    + "on biz_hist.vendor = max_vendor.vendor  "
                    + "and biz_hist.validation_timestamp = max_vendor.max_time ";

    private static final String DELETE_BY_MCR_ID = "DELETE FROM AL_BIZ_EXCEL_VALIDATION_HISTORY "
            + "WHERE VENDOR IN ( "
            + "SELECT DISTINCT VENDOR "
            + "FROM AL_BIZ_MCR "
            + "WHERE STAGE_PUBLISHED_TO_PRODUCTION = 'YES' AND ID = ? )";

    private static final String GET_ALL_EXCEL_VALIDATION_HISTORY =
            "select vendor, validation_status, reactivate_validation_status, validation_timestamp, "
            + "UNIX_TIMESTAMP(validation_timestamp) timestamp_number "
            + "from AL_BIZ_EXCEL_VALIDATION_HISTORY order by vendor, validation_timestamp desc";

    private static final String GET_ALL_EXCEL_VALIDATION_HISTORY_BY_VENDOR =
            "select vendor, validation_status, reactivate_validation_status, validation_timestamp, "
                    + "UNIX_TIMESTAMP(validation_timestamp) timestamp_number "
                    + "from AL_BIZ_EXCEL_VALIDATION_HISTORY "
                    + "where vendor like :vendorName order by vendor, validation_timestamp desc";

    private static final String GET_LOG_BY_TIMESTAMP_NUMBER =
            "select log from AL_BIZ_EXCEL_VALIDATION_HISTORY where UNIX_TIMESTAMP(validation_timestamp) = ?";

    private static final String GET_EXCEL_FILE_BY_TIMESTAMP_NUMBER =
            "select excel_file from AL_BIZ_EXCEL_VALIDATION_HISTORY where UNIX_TIMESTAMP(validation_timestamp) = ?";

    private static final String GET_VENDOR_BY_TIMESTAMP_NUMBER =
            "select vendor, validation_timestamp from AL_BIZ_EXCEL_VALIDATION_HISTORY where UNIX_TIMESTAMP(validation_timestamp) = ?";

    /**
     *
     * @param timestampNumber timestamp number
     * @return vendor name
     */
    public ExcelValidationHistory getGetVendorByTimestampNumber(Long timestampNumber) {
        List<ExcelValidationHistory> excelValidationHistories =
                jdbcTemplate.query(GET_VENDOR_BY_TIMESTAMP_NUMBER,
                        new Object[]{timestampNumber},
                        new RowMapper<ExcelValidationHistory>() {
                            @Override
                            public ExcelValidationHistory mapRow(ResultSet rs, int i) throws SQLException {
                                ExcelValidationHistory excelValidationHistory = new ExcelValidationHistory();
                                excelValidationHistory.setVendor(rs.getString(1));
                                excelValidationHistory.setValidationTimestamp(new Date(rs.getTimestamp(2).getTime()));
                                return excelValidationHistory;
                            }
                        });
        return excelValidationHistories.get(0);
    }

    /**
     *
     * @param timestampNumber timestamp number
     * @return log content
     */
    public String getValidationHistoryLogByTimestampNumber(Long timestampNumber) {
        List<String> logList = jdbcTemplate.queryForList(
                GET_LOG_BY_TIMESTAMP_NUMBER,
                new Object[]{timestampNumber},
                String.class
        );
        String log = null;
        if (logList.size() > 0) {
            log = logList.get(0);
        }
        return log;
    }


    /**
     *
     * @param timestampNumber timestamp number
     * @return excel binary content
     */
    public byte[] getValidationHistoryExcelFileByTimestampNumber(Long timestampNumber) {
        List<byte[]> excelContentList = jdbcTemplate.queryForList(
                GET_EXCEL_FILE_BY_TIMESTAMP_NUMBER,
                new Object[]{timestampNumber},
                byte[].class
        );
        byte[] excelContent = null;
        if (excelContentList.size() > 0) {
            excelContent = excelContentList.get(0);
        }
        return excelContent;
    }

    /**
     *
     * @return all excel validation history
     */
    public List<ExcelValidationHistory> getAllExcelValidationHistory() {
        return jdbcTemplate.query(GET_ALL_EXCEL_VALIDATION_HISTORY, validationPageRowMapper);
    }

    /**
     *
     * @param vendor vendor name
     * @return all excel validation history for a given vendor
     */
    public List<ExcelValidationHistory> getAllExcelValidationHistoryByVendor(String vendor) {
        String newSql = GET_ALL_EXCEL_VALIDATION_HISTORY_BY_VENDOR.replace(":vendorName", "'%" + vendor + "%'");
        return jdbcTemplate.query(newSql, validationPageRowMapper);
    }

    private RowMapper<ExcelValidationHistory> validationPageRowMapper = new RowMapper<ExcelValidationHistory>() {
        @Override
        public ExcelValidationHistory mapRow(ResultSet rs, int i) throws SQLException {
            ExcelValidationHistory excelValidationHistory = new ExcelValidationHistory();
            excelValidationHistory.setVendor(rs.getString(1));
            excelValidationHistory.setExcelValidationStatus(rs.getString(2) == null
                    ?
                    null
                    :
                    ExcelValidationStatus.valueOf(rs.getString(2)));
            excelValidationHistory.setReactivateValidationStatus(rs.getString(3) == null
                    ?
                    null
                    :
                    ExcelValidationStatus.valueOf(rs.getString(3)));
            excelValidationHistory.setValidationTimestamp(new Date(rs.getTimestamp(4).getTime()));
            excelValidationHistory.setValidationTimeStampNumber(rs.getLong(5));
            return excelValidationHistory;
        }
    };


    /**
     * @param mcrId mcr id
     */
    public void deleteExcelValidationHistoryByMcrId(int mcrId) {
        jdbcTemplate.update(DELETE_BY_MCR_ID, mcrId);
    }

    /**
     *
     * @param mcrId mcr id
     * @return a list of ExcelValidationHistory object
     */
    public List<ExcelValidationHistory> getLastExcelValidationHistoriesByMcrId(int mcrId) {
        List<ExcelValidationHistory> list = jdbcTemplate.query(GET_EXCEL_VALIDATION_HISTORIES_BY_MCR_ID,
                new Object[]{mcrId},
                new RowMapper<ExcelValidationHistory>() {
            @Override
            public ExcelValidationHistory mapRow(ResultSet rs, int rowNum) throws SQLException {
                ExcelValidationHistory excelValidationHistory = new ExcelValidationHistory();
                excelValidationHistory.setExcelPath(rs.getString(1));
                excelValidationHistory.setResourceFolderPath(rs.getString(2));
                excelValidationHistory.setMoveResource(rs.getString(3));
                excelValidationHistory.setVendor(rs.getString(4));
                excelValidationHistory.setExcelValidationStatus(rs.getString(5) == null
                        ?
                        null
                        :
                        ExcelValidationStatus.valueOf(rs.getString(5)));
                excelValidationHistory.setReactivateValidationStatus(rs.getString(6) == null
                        ?
                        null
                        :
                        ExcelValidationStatus.valueOf(rs.getString(6)));
                excelValidationHistory.setValidationTimestamp(new Date(rs.getTimestamp(7).getTime()));
                excelValidationHistory.setExcelFileChecksum(rs.getString(8));
                return excelValidationHistory;
            }
        });
        return list;
    }

    /**
     *
     * @param excelValidationHistory an object of ExcelValidationHistory
     * @param isForReactivation a flag showing if for reactivation
     */
    public void insertValidationHistory(ExcelValidationHistory excelValidationHistory, boolean isForReactivation) {
        LobHandler lobHandler = new DefaultLobHandler();
        Exception ex = null;
        try {
            jdbcTemplate.update(
                    isForReactivation ? INSERT_VALIDATION_HISTORY_FOR_REACTIVATION : INSERT_VALIDATION_HISTORY,
                    new Object[] {
                            excelValidationHistory.getExcelPath(),
                            excelValidationHistory.getResourceFolderPath(),
                            excelValidationHistory.getMoveResource(),
                            excelValidationHistory.getVendor(),
                            excelValidationHistory.getExcelValidationStatus().getName(),
                            excelValidationHistory.getLog(),
                            excelValidationHistory.getExcelFileChecksum(),
                            new SqlLobValue(new FileInputStream(excelValidationHistory.getExcelFile()),
                                    (int) excelValidationHistory.getExcelFile().length(),
                                    lobHandler
                            )
                    }, new int[] {
                                    Types.VARCHAR,
                                    Types.VARCHAR,
                                    Types.VARCHAR,
                                    Types.VARCHAR,
                                    Types.VARCHAR,
                                    Types.VARCHAR,
                                    Types.VARCHAR,
                                    Types.BLOB
                                }
            );
        } catch (FileNotFoundException fileNotFoundEx) {
            ex = fileNotFoundEx;
        }
        Assert.isTrue(ex == null, ex == null ? "" : ex.getMessage());
    }

    /**
     *
     * @param vendor vendor
     * @return an object of ExcelValidationStatus
     */
    public ExcelValidationStatus getLatestValidationStatusByVendor(String vendor) {
        List<Map<String, String>> resultList = jdbcTemplate.query(QUERY_GET_LATEST_VALIDATION_STATUS_BY_VENDOR, new Object[]{vendor},
                new RowMapper<Map<String, String>>() {
                    @Override
                    public Map<String, String> mapRow(ResultSet rs, int i) throws SQLException {
                        Map<String, String> result = new HashMap<String, String>();
                        result.put("VALIDATION_STATUS", rs.getString(1));
                        result.put("REACTIVATE_VALIDATION_STATUS", rs.getString(2));
                        return result;
                    }
                });
        ExcelValidationStatus status;
        Map<String, String> resultMap = resultList.get(0);
        Assert.isTrue(resultMap != null, "No validation history found for vendor [" + vendor + "]");
        if (resultMap.get("REACTIVATE_VALIDATION_STATUS") != null) {
            ExcelValidationStatus.valueOf(resultMap.get("REACTIVATE_VALIDATION_STATUS"));
        }
        return ExcelValidationStatus.valueOf(resultMap.get("VALIDATION_STATUS"));
    }

    /**
     *
     * @param vendor vendor
     */
    public void deleteValidationHistoryByVendor(String vendor) {
        jdbcTemplate.update(DELETE_VALIDATION_HISTORY_BY_VENDOR);
    }

    @Autowired
    @Qualifier("autoLoaderBizJdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
}
