package com.menards.autoloader.dao.source;

import com.menards.autoloader.dao.DaoAdapter;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>BlcCategoryProductXrefDao</p>
 * <p>A {@link DaoAdapter} sub class for manipulating AL_SOURCE_BLC_CATEGORY_PRODUCT_XREF table.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class SourceBlcCategoryProductXrefDao extends DaoAdapter<List<Map<String, String>>> {
    private static final String BATCH_INSERT_SQL =
            "insert into AL_SOURCE_BLC_CATEGORY_PRODUCT_XREF (CATEGORY_ID, PRODUCT_ID, MCR_ID) values (?, ?, ?)";
    private static final String QUERY_GET_ALL_DATA_BY_MCR_ID =
            "SELECT CATEGORY_ID, PRODUCT_ID FROM AL_SOURCE_BLC_CATEGORY_PRODUCT_XREF WHERE MCR_ID = ?";
    private static final String DELETE_ALL_BY_MCR_ID = "DELETE FROM AL_SOURCE_BLC_CATEGORY_PRODUCT_XREF WHERE MCR_ID = ?";

    @Override
    public void deleteAllByMcrId(int mcrId) {
        getJdbcTemplate().update(DELETE_ALL_BY_MCR_ID, mcrId);
    }

    @Override
    public void batchInsert(final List<Map<String, String>> sourceCategoryProductXrefs) {
        getJdbcTemplate().batchUpdate(BATCH_INSERT_SQL, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                Map<String, String> sourceCategoryProductXRef = sourceCategoryProductXrefs.get(i);
                ps.setString(1, sourceCategoryProductXRef.get("CATEGORY_ID"));
                ps.setString(2, sourceCategoryProductXRef.get("PRODUCT_ID"));
                ps.setInt(3, Integer.parseInt(sourceCategoryProductXRef.get("MCR_ID")));
            }
            @Override
            public int getBatchSize() {
                return sourceCategoryProductXrefs.size();
            }
        });
    }

    @Override
    public List<Map<String, String>> getAllDataByMcrId(int mcrId) {
        return getJdbcTemplate().query(QUERY_GET_ALL_DATA_BY_MCR_ID, new Object[]{mcrId}, new RowMapper<Map<String, String>>() {
            @Override
            public Map<String, String> mapRow(ResultSet rs, int rowNum) throws SQLException {
                Map<String, String> preSourceBlcCategoryProductXref = new HashMap<String, String>();
                preSourceBlcCategoryProductXref.put("CATEGORY_ID", Long.toString(rs.getLong(1)));
                preSourceBlcCategoryProductXref.put("PRODUCT_ID", rs.getString(2));
                return preSourceBlcCategoryProductXref;
            }
        });
    }

    /**
     * A constructor method.
     * @param jdbcTemplate A {@link org.springframework.jdbc.core.JdbcTemplate} object that executes JDBC statements.
     */
    public SourceBlcCategoryProductXrefDao(JdbcTemplate jdbcTemplate) {
        setJdbcTemplate(jdbcTemplate);
    }

}
