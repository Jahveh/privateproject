package com.menards.autoloader.dao.source;

import com.menards.autoloader.dao.DaoAdapter;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>SourceBlcSkuDao</p>
 * <p>A {@link DaoAdapter} sub class for manipulating AL_SOURCE_BLC_SKU table.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public class SourceMenardSkuDao extends DaoAdapter<List<Map<String, String>>> {
    private static final String BATCH_INSERT_SQL =
            "insert into AL_SOURCE_MENARD_SKU (SKU_ID, SKU_CODE, MENARD_SKU, MCR_ID, VENDOR_LOGO) values (?, ?, ?, ?, ?)";
    private static final String QUERY_GET_ALL_DATA_BY_MCR_ID =
            "SELECT SKU_ID, SKU_CODE, MENARD_SKU, VENDOR_LOGO From AL_SOURCE_MENARD_SKU WHERE MCR_ID = ?";
    private static final String DELETE_ALL_BY_MCR_ID = "DELETE FROM AL_SOURCE_MENARD_SKU WHERE MCR_ID = ?";

    @Override
    public void deleteAllByMcrId(int mcrId) {
        getJdbcTemplate().update(DELETE_ALL_BY_MCR_ID, mcrId);
    }

    @Override
    public void batchInsert(final List<Map<String, String>> sourceMenardSkus) {
        getJdbcTemplate().batchUpdate(BATCH_INSERT_SQL, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                Map<String, String> sourceMenardSku = sourceMenardSkus.get(i);
                ps.setString(1, sourceMenardSku.get("SKU_ID"));
                ps.setString(2, sourceMenardSku.get("SKU_CODE"));
                ps.setString(3, sourceMenardSku.get("MENARD_SKU"));
                ps.setInt(4, Integer.parseInt(sourceMenardSku.get("MCR_ID")));
                ps.setString(5, sourceMenardSku.get("VENDOR_LOGO"));
            }
            @Override
            public int getBatchSize() {
                return sourceMenardSkus.size();
            }
        });
    }

    @Override
    public List<Map<String, String>> getAllDataByMcrId(int mcrId) {
        return getJdbcTemplate().query(QUERY_GET_ALL_DATA_BY_MCR_ID,
                new Object[]{mcrId},
                new RowMapper<Map<String, String>>() {
            @Override
            public Map<String, String> mapRow(ResultSet rs, int rowNum) throws SQLException {
                Map<String, String> sourceMenardSku = new HashMap<String, String>();
                sourceMenardSku.put("SKU_ID", rs.getString(1));
                sourceMenardSku.put("SKU_CODE", rs.getString(2));
                sourceMenardSku.put("MENARD_SKU", rs.getString(3));
                sourceMenardSku.put("VENDOR_LOGO", rs.getString(4));
                return sourceMenardSku;
            }
        });
    }

    /**
     * A constructor method.
     * @param jdbcTemplate A {@link org.springframework.jdbc.core.JdbcTemplate} object that executes JDBC statements.
     */
    public SourceMenardSkuDao(JdbcTemplate jdbcTemplate) {
        setJdbcTemplate(jdbcTemplate);
    }
}
