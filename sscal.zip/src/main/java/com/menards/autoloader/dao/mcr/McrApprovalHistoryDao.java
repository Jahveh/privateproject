package com.menards.autoloader.dao.mcr;

import com.menards.autoloader.domain.mcr.ApprovalHistory;
import com.menards.autoloader.domain.mcr.McrStatus;
import com.menards.autoloader.domain.mcr.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Repository
public class McrApprovalHistoryDao {
    private static final String BATCH_INSERT_MCR_APPROVAL_HISTORY =
"insert into AL_BIZ_MCR_APPROVAL_HISTORY(ID, MCR_ID, APPROVER_NAME, APPROVER_EMAIL, APPROVAL_STATUS, APPROVAL_COMMENT) "
            + "values (?, ?, ?, ?, ?, ?)";
    private static final String UPDATE_MCR_APPROVAL_HISTORY =
            "UPDATE AL_BIZ_MCR_APPROVAL_HISTORY SET APPROVAL_STATUS = ?, APPROVAL_COMMENT = ?, UPDATE_TIMESTAMP = ? "
            + "where MCR_ID = ? and APPROVER_EMAIL = ?";

    private static final String GET_MAX_ID =
"select ifnull(max(id), 0) + 1 from AL_BIZ_MCR_APPROVAL_HISTORY";

    private static final String GET_ALL_STATUS_BY_MCR_ID =
"SELECT APPROVAL_STATUS FROM AL_BIZ_MCR_APPROVAL_HISTORY WHERE MCR_ID = ?";

    private static final String GET_APPROVAL_HISTORY_BY_MCR_ID =
    "SELECT ID, MCR_ID, APPROVER_NAME, APPROVER_EMAIL, APPROVAL_STATUS, APPROVAL_COMMENT, UPDATE_TIMESTAMP"
    + " FROM AL_BIZ_MCR_APPROVAL_HISTORY WHERE MCR_ID = ?";

    /**
     * batch insert approval history
     * @param approvalHistoryList a list of ApprovalHistory object
     */
    public void batchInsert(final List<ApprovalHistory> approvalHistoryList) {
        final int maxId = getMaxId();
        jdbcTemplate.batchUpdate(BATCH_INSERT_MCR_APPROVAL_HISTORY, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                ApprovalHistory approvalHistory = approvalHistoryList.get(i);
                ps.setInt(1, maxId + i);
                ps.setInt(2, approvalHistory.getMcrId());
                ps.setString(3, approvalHistory.getApprovalUser().getName()==null
                                ?
                        approvalHistory.getApprovalUser().getEmail().substring(0, approvalHistory.getApprovalUser().getEmail().indexOf("@"))
                                :
                        approvalHistory.getApprovalUser().getName()
                );
                ps.setString(4, approvalHistory.getApprovalUser().getEmail());
                ps.setString(5, approvalHistory.getStatus().getName());
                ps.setString(6, approvalHistory.getComment());
            }
            @Override
            public int getBatchSize() {
                return approvalHistoryList.size();
            }
        });
    }

    /**
     * Update AL_BIZ_MCR_HISTORY table
     * @param mcrId mcr id
     * @param approverEmail approver email
     * @param approvalStatus approval status
     * @param comment approval comment
     * @return number of records updated
     */
    public int updateMcrHistory(int mcrId, String approverEmail, String approvalStatus, String comment) {
        return jdbcTemplate.update(UPDATE_MCR_APPROVAL_HISTORY,
                approvalStatus,
                comment,
                new Date(),
                mcrId,
                approverEmail
        );
    }


    /**
     * Get a set of approval status by a given mcr id.
     * @param mcrId mcr id
     * @return a set of approval status
     */
    public Set<String> getAllApprovalStatusByMcrId(int mcrId) {
        Set<String> result = new HashSet<String>();
        List<String> list = jdbcTemplate.queryForList(GET_ALL_STATUS_BY_MCR_ID, new Object[]{mcrId}, String.class);
        for (String status : list) {
            result.add(status);
        }
        return result;
    }

    /**
     * Get a list of ApprovalHistory object by mcr id
     * @param mcrId mcr id
     * @return a list of ApprovalHistory object
     */
    public List<ApprovalHistory> getApprovalHistoryByMcrId(int mcrId) {
        return jdbcTemplate.query(GET_APPROVAL_HISTORY_BY_MCR_ID,
                new Object[]{mcrId}, new int[]{Types.INTEGER},
                new RowMapper<ApprovalHistory>() {
                    @Override
                    public ApprovalHistory mapRow(ResultSet rs, int rowNum) throws SQLException {
                        ApprovalHistory ah = new ApprovalHistory();
                        ah.setId(rs.getInt(1));
                        ah.setMcrId(rs.getInt(2));
                        User approvalUser = new User();
                        approvalUser.setId(rs.getInt(1)); // TODO: set user id as the same with approval history record.
                        approvalUser.setName(rs.getString(3));
                        approvalUser.setEmail(rs.getString(4));
                        ah.setApprovalUser(approvalUser);
                        ah.setStatus(McrStatus.valueOf(rs.getString(5)));
                        ah.setComment(rs.getString(6));
                        ah.setUpdateTimeStamp(rs.getTimestamp(7));
                        return ah;
                    }
                });
    }

    /**
     * Get max id of AL_BIZ_MCR_APPROVAL_HISTORY table.
     * @return the max id.
     */
    private int getMaxId() {
        return jdbcTemplate.queryForInt(GET_MAX_ID);
    }

    @Autowired
    @Qualifier("autoLoaderBizJdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

}
