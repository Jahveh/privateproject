package com.menards.autoloader.dao.mcr;

import au.com.bytecode.opencsv.CSVReader;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Repository;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
@Repository
public class CatalogDao {
    private static final String CATALOG_FILE_PATH = "/lookup-data/catalog.csv";

    /**
     * Get all catalogs
     * @return a list of catalog
     * @throws IOException io exception
     */
    public List<String> getAllCatalogs() throws IOException {
        List<String> allCatalogs = new ArrayList<String>();
        Resource resource = new ClassPathResource(CATALOG_FILE_PATH);
        CSVReader csvReader = new CSVReader(new FileReader(resource.getFile()), ',');
        String [] nextLine;

        while ((nextLine = csvReader.readNext()) != null) {
            for (String token : nextLine) {
                allCatalogs.add(token);
            }
        }

        Collections.sort(allCatalogs);
        return allCatalogs;
    }

}
