package com.menards.autoloader.dao.factory;

/**
 * <p>DaoNames</p>
 * <p>An enum that lists all the Dao names..</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public enum DaoNames {

    BLC_CATEGORY_DAO, //Used for category, unused now.
    MENARD_VENDOR_DAO, //Used for product/sku file attribute

    //9 Target DAOs..
    BLC_CATEGORY_PRODUCT_XREF_DAO,
    BLC_PRODUCT_DAO,
    BLC_SKU_ATTRIBUTE_DAO,
    BLC_SKU_DAO,
    BLC_PRODUCT_ATTRIBUTE_DAO,
    BLC_PRODUCT_SKU_XREF_DAO,
    MENARD_PRODUCT_DAO,
    MENARD_PRODUCT_OPTION_DAO,
    MENARD_SKU_DAO,

    //9 Source DAOs..
    SOURCE_BLC_CATEGORY_PRODUCT_XREF_DAO,
    SOURCE_BLC_PRODUCT_ATTRIBUTE_DAO,
    SOURCE_BLC_PRODUCT_DAO,
    SOURCE_BLC_SKU_ATTRIBUTE_DAO,
    SOURCE_BLC_SKU_DAO,
    SOURCE_BLC_PRODUCT_SKU_XREF_DAO,
    SOURCE_MENARD_PRODUCT_DAO,
    SOURCE_MENARD_PRODUCT_OPTION_DAO,
    SOURCE_MENARD_SKU_DAO

}
