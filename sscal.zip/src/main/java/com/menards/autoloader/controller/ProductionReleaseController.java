package com.menards.autoloader.controller;

import com.menards.autoloader.domain.mcr.MCR;
import com.menards.autoloader.service.LookupDataService;
import com.menards.autoloader.service.McrService;
import com.menards.autoloader.service.PublishReleaseService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.ServletContext;

import java.util.List;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @author james.ni
 * @version 1.0
 */
@Controller
@RequestMapping("/productionRelease")
public class ProductionReleaseController extends BaseController {

    @Autowired
    private ServletContext context;

    @Autowired
    private McrService mcrService;

    @Autowired
    private PublishReleaseService releaseService;

    @Autowired
    private LookupDataService lookupDataService;


    /**
     *
     * @return logic view name
     */
    @RequestMapping(method = RequestMethod.GET)
    public String showMcrPage() {
        return "productionRelease";
    }

    /**
     *
     * @return logic view name
     */
    @RequestMapping(value="/release", method = RequestMethod.POST)
    public View release() {
//        releaseService.productionRelease();
        String appContextPath = context.getContextPath();
        return new RedirectView(appContextPath + "/productionRelease");
    }

    /**
     *
     * @return logic view name
     */
    @ModelAttribute("pendingMcrList")
    public List<MCR> loadPendingMcrList() {
        return mcrService.getAllCandidateMcrForProductionRelease();
    }

}
