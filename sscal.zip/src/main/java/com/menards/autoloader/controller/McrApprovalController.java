package com.menards.autoloader.controller;

import com.menards.autoloader.domain.mcr.ApprovalHistory;
import com.menards.autoloader.domain.mcr.MCR;
import com.menards.autoloader.domain.mcr.User;
import com.menards.autoloader.filter.SecurityRightsFilter;
import com.menards.autoloader.service.LookupDataService;
import com.menards.autoloader.service.McrService;
import com.menards.autoloader.utils.FileChecksumUtils;
import com.menards.autoloader.utils.WebUtils;
import com.menards.autoloader.validator.McrValidator;
import com.menards.mymenards.integration.vo.SecureUser;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @author james.ni
 * @version 1.0
 */
@Controller
@RequestMapping("/mcrApproval")
public class McrApprovalController extends BaseController {

    @Autowired
    private ServletContext context;

    @Autowired
    private McrService mcrService;

    @Autowired
    private LookupDataService lookupDataService;

    @Autowired
    private McrValidator mcrValidator;

    /**
     *
     * @param parameters multipart parameter
     * @param model model
     * @return logic view name
     */
    @RequestMapping(method = RequestMethod.GET)
    public String showMcrApprovalPage(@RequestParam MultiValueMap parameters, ModelMap model) {
        if (parameters != null && !parameters.isEmpty()) {
            model.addAttribute("errors", parameters.get("errors"));
        }
        return "mcrApproval";
    }

    /**
     *
     * @param mcrId mcr id
     * @param model model
     * @return logic view name
     */
    @RequestMapping(value = "/{mcrId}", method = RequestMethod.GET)
    public String loadMcr(@PathVariable("mcrId") int mcrId, ModelMap model, HttpServletRequest request) {
        MCR pendingMcr = mcrService.getCompleteMcrDataById(mcrId);
        File excelFile = new File(pendingMcr.getLastExcelValidationHistory().getExcelPath());
        model.addAttribute("pendingMcr", pendingMcr);
        SecureUser secureUser = (SecureUser) request.getSession().getAttribute(SecurityRightsFilter.SECURE_USER);
        String currentUserEmail = secureUser.getEmail();
        List<String> approverEmails = new ArrayList<String>();
        for (ApprovalHistory approvalHistory : pendingMcr.getApprovalHistories()) {
            approverEmails.add(approvalHistory.getApprovalUser().getEmail().toLowerCase());
        }
        if (!approverEmails.contains(currentUserEmail.toLowerCase())) {
            List<String> errorMessages = new ArrayList<String>();
            errorMessages.add("Sorry, you are not the intended approver. ");
            model.addAttribute("approvalEnabled", false);
            model.addAttribute("errors", errorMessages);
            return "mcrApproval";
        }
        if (!excelFile.exists()) {
            List<String> errorMessages = new ArrayList<String>();
            errorMessages.add("The excel file associated with this MCR no longer exists. "
                    + "Please ask the MCR submitter to re-upload the excel file and re-validate it.");
            model.addAttribute("approvalEnabled", false);
            model.addAttribute("errors", errorMessages);
            return "mcrApproval";
        }
        String realChecksum = FileChecksumUtils.getChecksum(excelFile);
        if (!realChecksum.equals(pendingMcr.getLastExcelValidationHistory().getExcelFileChecksum())) {
            List<String> errorMessages = new ArrayList<String>();
            errorMessages.add("The excel file associated with this MCR has been changed. "
                    + "Please ask the MCR submitter to re-validate the excel file.");
            model.addAttribute("approvalEnabled", false);
            model.addAttribute("errors", errorMessages);
            return "mcrApproval";
        }
        model.addAttribute("approvalEnabled", true);
        return "mcrApproval";

    }

    /**
     *
     * @param approvalHistory approval history
     * @param action action
     * @param model model
     * @return logic view
     * @throws IOException
     */
    @RequestMapping(value = "/submit", method = RequestMethod.POST)
    public View submit(
            @ModelAttribute("approvalHistory") ApprovalHistory approvalHistory,
            @RequestParam("action") String action,
            ModelMap model) throws IOException {

        if (StringUtils.equalsIgnoreCase(action, "Approve")) {
            approve(approvalHistory, model);
        } else if (StringUtils.equalsIgnoreCase(action, "Reject")) {
            reject(approvalHistory, model);
        }
        String appContextPath = context.getContextPath();
        return new RedirectView(appContextPath + "/mcrApproval");
    }

    /**
     *
     * @param approvalHistory approval history
     * @param model model
     * @throws IOException io exception
     */
    private void approve(ApprovalHistory approvalHistory, ModelMap model) throws IOException {
        Map<String, String> messages = mcrService.approveMcr(approvalHistory.getMcrId(),
                approvalHistory.getApprovalUser().getEmail(),
                approvalHistory.getComment());
        if (!messages.isEmpty()) {
            WebUtils.addAllErrorMsgToModel(model, messages);
        }
    }

    /**
     *
     * @param approvalHistory approval history
     * @param model model
     * @throws IOException io exception
     */
    private void reject(ApprovalHistory approvalHistory, ModelMap model) throws IOException {
        mcrService.rejectMcr(approvalHistory.getMcrId(),
                approvalHistory.getApprovalUser().getEmail(),
                approvalHistory.getComment());
    }

    /**
     * Model attribute named "allUsers"
     * @return a list of user
     * @throws IOException io exception
     */
    @ModelAttribute("allUsers")
    public List<User> loadAllUsers() throws IOException {
        return lookupDataService.getAllUsers();
    }

    /**
     * Model attribute named "approvalHistory"
     * @return approval history
     */
    @ModelAttribute("approvalHistory")
    public ApprovalHistory initApprovalHistory() {
        return new ApprovalHistory();
    }

    /**
     * Model attribute named "vendorToMcrInProgressMap"
     * @return all WIP mcr
     */
    @ModelAttribute("vendorToMcrInProgressMap")
    public Map<String, List<MCR>> loadAllCatalogs() {
        List<MCR> allMCRs = mcrService.getAllInProgressMcr();
        Map<String, List<MCR>> vendorToMcrMap = new HashMap<String, List<MCR>>();
        for (MCR mcr: allMCRs) {
            String catalogName = WebUtils.getCatalogName(mcr.getExcelPath());
            if (vendorToMcrMap.containsKey(catalogName)) {
                vendorToMcrMap.get(catalogName).add(mcr);
            } else {
                List<MCR> mcrList = new ArrayList<MCR>();
                mcrList.add(mcr);
                vendorToMcrMap.put(catalogName, mcrList);
            }
        }
        return vendorToMcrMap;
    }

    /**
     * Model attribute named "vendorToMcrMap"
     * @return a map
     */
    @ModelAttribute("vendorToMcrMap")
    public Map<String, List<MCR>> loadVendorToMcrMap() {
        List<MCR> allMCRs = mcrService.getPendingMcrListWithCatalog();
        Map<String, List<MCR>> vendorToMcrMap = new HashMap<String, List<MCR>>();
        for (MCR mcr: allMCRs) {
            String catalogName = WebUtils.getCatalogName(mcr.getExcelPath());
            if (vendorToMcrMap.containsKey(catalogName)) {
                vendorToMcrMap.get(catalogName).add(mcr);
            } else {
                List<MCR> mcrList = new ArrayList<MCR>();
                mcrList.add(mcr);
                vendorToMcrMap.put(catalogName, mcrList);
            }
        }
        return vendorToMcrMap;
    }
}
