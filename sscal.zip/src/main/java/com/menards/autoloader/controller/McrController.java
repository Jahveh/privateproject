package com.menards.autoloader.controller;

import com.menards.autoloader.domain.mcr.ExcelValidationHistory;
import com.menards.autoloader.domain.mcr.MCR;
import com.menards.autoloader.domain.mcr.Priority;
import com.menards.autoloader.domain.mcr.User;
import com.menards.autoloader.service.LookupDataService;
import com.menards.autoloader.service.McrService;
import com.menards.autoloader.utils.WebUtils;
import com.menards.autoloader.validator.McrValidator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomCollectionEditor;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.util.HtmlUtils;

import javax.servlet.ServletContext;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @author james.ni
 * @version 1.0
 */
@Controller
@RequestMapping("/mcr")
public class McrController extends BaseController {

    @Autowired
    private ServletContext context;

    @Autowired
    private McrService mcrService;

    @Autowired
    private LookupDataService lookupDataService;

    @Autowired
    private McrValidator mcrValidator;

    /**
     *
     * @param binder binder
     * @throws IOException ioException
     */
    @InitBinder
    public void initBinder(WebDataBinder binder) throws IOException {
        final List<User> allUsers = lookupDataService.getAllApprovers();
//        binder.registerCustomEditor(User.class, new UserEditor(allUsers));
        binder.registerCustomEditor(List.class, "approvers", new CustomCollectionEditor(List.class) {
            protected Object convertElement(Object element) {
                if (element instanceof User) {
                    return element;
                }
                if (element instanceof String) {
                    final String userEmail = element.toString();
                    for (User user : allUsers) {
                        if ((user.getEmail()).equals(userEmail)) {
                            return user;
                        }
                    }
                }
                return null;
            }
        });

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false);
        // date is not required, allow empty here
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }

    /**
     * Show new MCR page (default)
     *
     * @return view string
     */
    @RequestMapping(method = RequestMethod.GET)
    public String showNewMcrPage() {
        return "mcr";
    }

    /**
     *
     * @param newMcr mcr
     * @param result binding result
     * @param model model
     * @return an object of ModelAndView
     * @throws IOException io exception
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public ModelAndView create(@ModelAttribute("newMcr") MCR newMcr,
                         BindingResult result, ModelMap model) throws IOException {
        // validate user input
        mcrValidator.validate(newMcr, result);
        if (!result.hasErrors()) {
            if (newMcr.getApprovers().isEmpty() || newMcr.getApprovers().get(0) == null) {//approver skipped
                mcrService.createMCRIfApproverSkipped(newMcr);
                String msg = "No approver has been selected, Batch Job [excel-to-stage-job] has been triggered.";
                return new ModelAndView(new RedirectView(context.getContextPath() + "/mcr?msg="+msg));
            } else {
                User submitter = findUserByEmail(newMcr.getSubmitter().getEmail());
                newMcr.setSubmitter(submitter);
                mcrService.createMcr(newMcr);
                return new ModelAndView(new RedirectView(context.getContextPath() + "/mcrApproval"));
            }
        } else {
            model.addAttribute("errors", result.getAllErrors());
            ModelAndView view = new ModelAndView("mcr", "newMcr", newMcr);
            view.addAllObjects(result.getModel());
            return view;
        }
    }

    /**
     * model attribute named "newMcr"
     * @return an object of MCR
     */
    @ModelAttribute("newMcr")
    public MCR loadNewMcr() {
        return new MCR();
    }

    /**
     * model attribute named "priorities"
     * @return a list of priority
     * @exception java.io.IOException io exception
     */
    @ModelAttribute("priorities")
    public List<Priority> loadAllPriorities() throws IOException {
        return lookupDataService.getAllPriorities();
    }

    /**
     * model attribute named "vendorToMcrInProgressMap"
     * @return a map between Catalog and it's MCRs
     */
    @ModelAttribute("vendorToMcrInProgressMap")
    public Map<String, List<MCR>> loadAllWipMcrs() {
        List<MCR> allMCRs = mcrService.getAllInProgressMcr();
        Map<String, List<MCR>> vendorToMcrMap = new HashMap<String, List<MCR>>();
        for (MCR mcr: allMCRs) {
            String catalogName = WebUtils.getCatalogName(mcr.getExcelPath());
            if (vendorToMcrMap.containsKey(catalogName)) {
                vendorToMcrMap.get(catalogName).add(mcr);
            } else {
                List<MCR> mcrList = new ArrayList<MCR>();
                mcrList.add(mcr);
                vendorToMcrMap.put(catalogName, mcrList);
            }
        }
        return vendorToMcrMap;
    }

    /**
     * model attribute named "catalogMap"
     * @return catalog map
     */
    @ModelAttribute("catalogMap")
    public Map<String, List<ExcelValidationHistory>> loadAllCatalogs() {
        List<ExcelValidationHistory> validationHistories = mcrService.getAvailableVendorCandidatesForNewMcr();
        Map<String, List<ExcelValidationHistory>> catalogMap = new HashMap<String, List<ExcelValidationHistory>>();
        for (ExcelValidationHistory excelValidationHistory: validationHistories) {
            String catalogName = WebUtils.getCatalogName(excelValidationHistory.getExcelPath());
            if (!catalogMap.containsKey(catalogName)) {
                catalogMap.put(catalogName, new ArrayList<ExcelValidationHistory>());
            }
            catalogMap.get(catalogName).add(excelValidationHistory);
        }
        return catalogMap;
    }

    /**
     * model attribute named "allUsers"
     * @return a list of User object
     * @throws IOException io exception
     */
    @ModelAttribute("allUsers")
    public List<User> loadAllUsers() throws IOException {
        return lookupDataService.getAllRequesters();
    }

    /**
     * model attribute named "allApprovers"
     * @return a list of User object
     * @throws IOException io exception
     */
    @ModelAttribute("allApprovers")
    public List<User> loadAllApprovers() throws IOException {
        return lookupDataService.getAllApprovers();
    }

    /**
     * find a user by email
     * @param email user email
     * @return User object
     * @throws IOException io exception
     */
    private User findUserByEmail(String email) throws IOException {
        String ntName = email.substring(0, email.indexOf("@") + 1).toLowerCase();
        for (User user : lookupDataService.getAllUsers()) {
            if (user.getEmail().toLowerCase().indexOf(ntName) == 0) {
                return user;
            }
        }
        return null;
    }
}
