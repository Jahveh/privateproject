package com.menards.autoloader.controller;

import com.menards.autoloader.domain.mcr.ApprovalHistory;
import com.menards.autoloader.domain.mcr.MCR;
import com.menards.autoloader.domain.mcr.StageApprovalInfo;
import com.menards.autoloader.domain.mcr.User;
import com.menards.autoloader.filter.SecurityRightsFilter;
import com.menards.autoloader.service.LookupDataService;
import com.menards.autoloader.service.McrService;
import com.menards.autoloader.service.PublishReleaseService;
import com.menards.autoloader.service.ScheduledTaskService;
import com.menards.autoloader.utils.WebUtils;
import com.menards.mymenards.integration.vo.SecureUser;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @author james.ni
 * @version 1.0
 */
@Controller
@RequestMapping("/stageApproval")
public class StageApprovalController extends BaseController {

    @Autowired
    private ServletContext context;

    @Autowired
    private McrService mcrService;

    @Autowired
    private PublishReleaseService releaseService;

    @Autowired
    private LookupDataService lookupDataService;

    @Autowired
    private ScheduledTaskService scheduledTaskService;
    /**
     * Show the stage approval page.
     * @return logic view name
     */
    @RequestMapping(method = RequestMethod.GET)
    public String showStageApprovalPage() {
//        scheduledTaskService.stagePublishForMcr();
        return "stageApproval";
    }

    /**
     * Show approval page for a particular mcr
     * @param mcrId mcr id
     * @param model Spring MVC model map
     * @return logic view name
     */
    @RequestMapping(value = "/{mcrId}", method = RequestMethod.GET)
    public String loadMcrByVendor(@PathVariable("mcrId") int mcrId, ModelMap model, HttpServletRequest request) {
        MCR pendingMcr = mcrService.getCompleteMcrDataById(mcrId);
        model.addAttribute("pendingMcr", pendingMcr);
/*        SecureUser secureUser = (SecureUser) request.getSession().getAttribute(SecurityRightsFilter.SECURE_USER);
        String currentUserEmail = secureUser.getEmail();
        String mcrSubmitterUserEmail = pendingMcr.getSubmitter().getEmail();
        if (!currentUserEmail.equalsIgnoreCase(mcrSubmitterUserEmail)) {
            List<String> errorMessages = new ArrayList<String>();
            errorMessages.add("Sorry, only the MCR submitter can approve on stage. ");
            model.addAttribute("approvalEnabled", false);
            model.addAttribute("errors", errorMessages);
        }*/
        model.addAttribute("approvalEnabled", true);
        return "stageApproval";
    }

    /**
     * Method for approving a particular mcr id.
     * @param stageApproval command object from page
     * @param result binding result
     * @param model Spring Spring MVC model map
     * @return Spring MVC view
     */
    @RequestMapping(value = "/approve", method = RequestMethod.POST)
    public View approve(
            @ModelAttribute("stageApproval") StageApprovalInfo stageApproval,
            BindingResult result,
            ModelMap model) {
        if (stageApproval.getMcrId() > 0) {
            releaseService.stageApproved(stageApproval);
        }
        String appContextPath = context.getContextPath();
        return new RedirectView(appContextPath + "/stageApproval");
    }


    /**
     *
     * @return Model Attribute named "stageApproval"
     */
    @ModelAttribute("stageApproval")
    public StageApprovalInfo initStageApprovalInfo() {
        return new StageApprovalInfo();
    }

    /**
     *
     * @return Model Attribute named "allApprovers"
     * @throws IOException io exception
     */
    @ModelAttribute("allApprovers")
    public List<User> loadAllApprovers() throws IOException {
        return lookupDataService.getAllUsers();
    }

    /**
     *
     * @return Model Attribute named "pendingMcrList"
     */
    @ModelAttribute("pendingMcrList")
    public Map<String, List<MCR>> loadVendorToMcrMap() {
        List<MCR> allMCRs = mcrService.getAllCandidateMcrForStageApproval();
        Map<String, List<MCR>> vendorToMcrMap = new HashMap<String, List<MCR>>();
        for (MCR mcr: allMCRs) {
            String catalogName = WebUtils.getCatalogName(mcr.getExcelPath());
            if (vendorToMcrMap.containsKey(catalogName)) {
                vendorToMcrMap.get(catalogName).add(mcr);
            } else {
                List<MCR> mcrList = new ArrayList<MCR>();
                mcrList.add(mcr);
                vendorToMcrMap.put(catalogName, mcrList);
            }
        }
        return vendorToMcrMap;
    }

    /**
     * @return Model Attribute named "vendorToMcrInProgressMap"
     * @return
     */
    @ModelAttribute("vendorToMcrInProgressMap")
    public Map<String, List<MCR>> loadAllWipMcrs() {
        List<MCR> allMCRs = mcrService.getAllInProgressMcr();
        Map<String, List<MCR>> vendorToMcrMap = new HashMap<String, List<MCR>>();
        for (MCR mcr: allMCRs) {
            String catalogName = WebUtils.getCatalogName(mcr.getExcelPath());
            if (vendorToMcrMap.containsKey(catalogName)) {
                vendorToMcrMap.get(catalogName).add(mcr);
            } else {
                List<MCR> mcrList = new ArrayList<MCR>();
                mcrList.add(mcr);
                vendorToMcrMap.put(catalogName, mcrList);
            }
        }
        return vendorToMcrMap;
    }
}
