package com.menards.autoloader.controller;

import com.menards.autoloader.domain.mcr.MCR;
import com.menards.autoloader.service.LookupDataService;
import com.menards.autoloader.service.McrService;
import com.menards.autoloader.service.ScheduledTaskService;
import com.menards.autoloader.utils.WebUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.ServletContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @author James.Ni
 * @version 1.0
 */
@Controller
@RequestMapping("/mcrReactivate")
public class McrReactivateController extends BaseController {

    @Autowired
    private ServletContext context;

    @Autowired
    private McrService mcrService;

    @Autowired
    private LookupDataService lookupDataService;

    @Autowired
    private ScheduledTaskService scheduledTaskService;
    /**
     *
     * @param parameters parameters
     * @param model model
     * @return model name
     */
    @RequestMapping(method = RequestMethod.GET)
    public String showMcrReactivatePage(@RequestParam MultiValueMap parameters, ModelMap model) {
        if (parameters != null && !parameters.isEmpty()) {
            model.addAttribute("errors", parameters.get("errors"));
        }
//        scheduledTaskService.productionRelease();
        return "mcrReactivate";
    }

    /**
     *
     * @param mcrId mcr id
     * @param model model
     * @return logic view name
     */
    @RequestMapping(value = "/{mcrId}", method = RequestMethod.GET)
    public String loadMcr(@PathVariable("mcrId") int mcrId, ModelMap model) {
        MCR pendingMcr = mcrService.getCompleteMcrDataById(mcrId);
        model.addAttribute("pendingMcr", pendingMcr);
        return "mcrReactivate";
    }

    /**
     *
     * @param mcrId mcr id
     * @param model model
     * @return a View object
     */
    @RequestMapping(value = "/reactivate", method = RequestMethod.POST)
    public View reactivate(@RequestParam("mcrId") int mcrId, ModelMap model) {
        if (mcrId > 0) {
            Map<String, String> messages = mcrService.reactivateMcr(mcrId);
            if (!messages.isEmpty()) {
                WebUtils.addAllErrorMsgToModel(model, messages);
            }
        }
        String appContextPath = context.getContextPath();
        return new RedirectView(appContextPath + "/mcrReactivate");
    }

    /**
     * Model attribute named "vendorToMcrMap"
     * @return a map
     */
    @ModelAttribute("vendorToMcrMap")
    public Map<String, List<MCR>> loadVendorToMcrMap() {
        List<MCR> allMCRs = mcrService.getMcrListForReactivation();
        Map<String, List<MCR>> vendorToMcrMap = new HashMap<String, List<MCR>>();
        for (MCR mcr: allMCRs) {
            String catalogName = WebUtils.getCatalogName(mcr.getExcelPath());
            if (vendorToMcrMap.containsKey(catalogName)) {
                vendorToMcrMap.get(catalogName).add(mcr);
            } else {
                List<MCR> mcrList = new ArrayList<MCR>();
                mcrList.add(mcr);
                vendorToMcrMap.put(catalogName, mcrList);
            }
        }
        return vendorToMcrMap;
    }

    /**
     * An model attribute named "vendorToMcrInProgressMap"
     * @return a map
     */
    @ModelAttribute("vendorToMcrInProgressMap")
    public Map<String, List<MCR>> loadAllWipMcrs() {
        List<MCR> allMCRs = mcrService.getAllInProgressMcr();
        Map<String, List<MCR>> vendorToMcrMap = new HashMap<String, List<MCR>>();
        for (MCR mcr: allMCRs) {
            String catalogName = WebUtils.getCatalogName(mcr.getExcelPath());
            if (vendorToMcrMap.containsKey(catalogName)) {
                vendorToMcrMap.get(catalogName).add(mcr);
            } else {
                List<MCR> mcrList = new ArrayList<MCR>();
                mcrList.add(mcr);
                vendorToMcrMap.put(catalogName, mcrList);
            }
        }
        return vendorToMcrMap;
    }
}
