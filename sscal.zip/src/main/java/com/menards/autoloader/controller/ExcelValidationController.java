package com.menards.autoloader.controller;

import com.menards.autoloader.domain.mcr.ExcelValidationHistory;
import com.menards.autoloader.domain.mcr.ExcelValidationStatus;
import com.menards.autoloader.service.ExcelValidationService;
import com.menards.autoloader.utils.ExcelUtils;
import com.menards.autoloader.utils.FileChecksumUtils;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Writer;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * <p>ExcelValidationController</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @author james.ni
 * @version 1.0
 */

@Controller
public class ExcelValidationController extends BaseController{
    private final Logger logger = LoggerFactory.getLogger(ExcelValidationController.class);
    private static final String VALIDATION_DONE = "Validation done!";

    @Autowired
    private ExcelValidationService excelValidationService;

    @Value("${excel.file.root.path}")
    private String excelFileRootPath;

    @Value("${media.file.root.path}")
    private String mediaFileRootPath;
    /**
     *
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @throws IOException io exception
     */
    @RequestMapping(value = "/validateExcel", method = RequestMethod.POST)
    public void onMessage(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String filePathParams = request.getParameter("file-paths");
        ObjectMapper mapper = new ObjectMapper();
        List<String> filePathList = mapper.readValue(filePathParams, List.class);
        Writer writer = response.getWriter();
        String excelPath = getAbsoluteExcelPath(filePathList.get(0));
        String mediaPath = getAbsoluteExcelPath(filePathList.get(1));
        String moveMedia = request.getParameter("move-media");
        List<String> validationMessage = fileExistenceCheck(excelPath, mediaPath);
        if (validationMessage.isEmpty()) {
            validationMessage = doValidate(excelPath, mediaPath, moveMedia.equalsIgnoreCase("YES"));
            String vendor = ExcelUtils.getVendor(new HSSFWorkbook(new FileInputStream(excelPath)));
            if (!(validationMessage.size() <= 1) && moveMedia.equalsIgnoreCase("YES")) { // copy all media files to temp folder
                mediaPath = copyMediaFilesToTempFolder(mediaPath, vendor);
            }
            persistValidationStatus(excelPath, mediaPath, moveMedia, vendor, validationMessage.size() > 1, validationMessage);
        }
        response.setContentType("application/json");
        writer.write(mapper.writeValueAsString(validationMessage));
        writer.flush();
        writer.close();
    }

    private String getAbsoluteExcelPath(String excelRelativePath) {
        excelRelativePath = excelRelativePath.replaceAll("\\\\", "/");
        if (excelRelativePath.startsWith("/") || excelRelativePath.startsWith("\\")) {
            return excelFileRootPath + excelRelativePath.substring(1);
        }
        return excelFileRootPath + excelRelativePath;
    }

    private List<String> fileExistenceCheck(String excelPath, String mediaPath) {
        File excelFile = new File(excelPath);
        File mediaFolder = new File(mediaPath);
        List<String> validationMessage = new LinkedList<String>();
        if (!excelFile.exists()) {
            validationMessage.add("Excel file path: " + excelFile + " is not accessible or does not exist.");
            validationMessage.add((VALIDATION_DONE));
            return validationMessage;
        }
        if (excelFile.isDirectory()) {
            validationMessage.add("Excel file: " + excelFile + " is not a file.");
            validationMessage.add((VALIDATION_DONE));
            return validationMessage;
        }
        if (!excelPath.endsWith("xls")) {
            validationMessage.add("Excel file: " + excelFile + " should have extension xls.");
            validationMessage.add((VALIDATION_DONE));
            return validationMessage;
        }
        if (!StringUtils.isEmpty(mediaPath) && !mediaFolder.exists()) {
            validationMessage.add("Resource folder path: " + mediaPath + " is not accessible or does not exist.");
            validationMessage.add((VALIDATION_DONE));
            return validationMessage;
        }
        if (!StringUtils.isEmpty(mediaPath) && !mediaFolder.isDirectory()) {
            validationMessage.add("Resource folder path: " + mediaPath + " should be a folder path.");
            validationMessage.add((VALIDATION_DONE));
            return validationMessage;
        }
        return validationMessage;
    }

    /**
     *
     * @param excelPath excel path
     * @param mediaPath media path
     * @param moveMedia flag whether to move media file
     * @return a list of validation message
     * @throws IOException IOException
     */
    private List<String> doValidate(String excelPath, String mediaPath, boolean moveMedia) throws IOException {
        File excelFile = new File(excelPath);
        File mediaFolder = new File(mediaPath);

        List<String> validationMessage = new LinkedList<String>();
        try {
            validationMessage.addAll(excelValidationService.validateRequiredSheets(excelFile));
            if (!validationMessage.isEmpty()) {
                validationMessage.add((VALIDATION_DONE));
                return validationMessage;
            }
            validationMessage.addAll(excelValidationService.validateRequiredFields(excelFile));
            if (!validationMessage.isEmpty()) {
                validationMessage.add((VALIDATION_DONE));
                return validationMessage;
            }
            validationMessage.addAll(excelValidationService.validateProductFamily(excelFile));
            if (!validationMessage.isEmpty()) {
                validationMessage.add((VALIDATION_DONE));
                return validationMessage;
            }
            validationMessage.addAll(excelValidationService.validateFieldFormatAgainstRegex(excelFile));
            if (!validationMessage.isEmpty()) {
                validationMessage.add((VALIDATION_DONE));
                return validationMessage;
            }
            validationMessage.addAll(excelValidationService.validateUniqueFields(excelFile));
            if (!validationMessage.isEmpty()) {
                validationMessage.add((VALIDATION_DONE));
                return validationMessage;
            }
            validationMessage.addAll(excelValidationService.validateDecimalFields(excelFile));
            if (!validationMessage.isEmpty()) {
                validationMessage.add((VALIDATION_DONE));
                return validationMessage;
            }
            validationMessage.addAll(excelValidationService.validateForeignKey(excelFile));
            if (!validationMessage.isEmpty()) {
                validationMessage.add((VALIDATION_DONE));
                return validationMessage;
            }
            if (moveMedia) {
                validationMessage.addAll(excelValidationService.validateFileExistenceAndSize(excelFile, mediaFolder));
                if (!validationMessage.isEmpty()) {
                    validationMessage.add((VALIDATION_DONE));
                    return validationMessage;
                }
            }
        }catch(Exception ex) {
            validationMessage.add(ex.getMessage());
            logger.error(ex.getMessage());
        }
        validationMessage.add((VALIDATION_DONE));
        return validationMessage;
    }

    /**
     * save validation status
     * @param excelPath excel path
     * @param mediaPath media path
     * @param moveMedia a flag whether to move media
     * @param vendor vendor
     * @param hasValidationError a flag showing if there is validation error
     */
    private void persistValidationStatus(String excelPath,
                                         String mediaPath,
                                         String moveMedia,
                                         String vendor,
                                         boolean hasValidationError,
                                         List<String> validationMessages) {
        ExcelValidationHistory validationHistory = new ExcelValidationHistory();
        validationHistory.setExcelPath(excelPath);
        File excelFile = new File(excelPath);
        validationHistory.setExcelFile(excelFile);
        validationHistory.setExcelFileChecksum(FileChecksumUtils.getChecksum(excelFile));
        validationHistory.setResourceFolderPath(mediaPath);
        validationHistory.setMoveResource(moveMedia);
        validationHistory.setVendor(vendor);
        validationHistory.setValidationTimestamp(new Date());
        if (!hasValidationError) {
            validationHistory.setExcelValidationStatus(ExcelValidationStatus.PASSED);
        } else {
            validationHistory.setExcelValidationStatus(ExcelValidationStatus.FAILED);
        }
        validationHistory.setLog(StringUtils.join(validationMessages.iterator(), "\r\n"));
        excelValidationService.addExcelValidationHistory(validationHistory);
    }

    /**
     * copy media file to a temp folder in
     * @param mediaPath media path
     * @param vendor vendor
     */
    private String copyMediaFilesToTempFolder(String mediaPath, String vendor) {
        IOException ioException = null;
        File tempFolder = new File("./al_media_temp", vendor);
        FileUtils.deleteQuietly(tempFolder);
        String tempFolderPath = null;
        try {
            FileUtils.copyDirectory(new File(mediaPath), tempFolder);
            tempFolderPath = tempFolder.getCanonicalPath();
        } catch (IOException e) {
            ioException = e;
        }
        Assert.isTrue(ioException == null, ioException == null ? "" : ioException.getMessage());
        return tempFolderPath;
    }
}
