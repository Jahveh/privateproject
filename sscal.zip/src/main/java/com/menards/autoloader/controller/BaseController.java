package com.menards.autoloader.controller;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class BaseController {
    @ExceptionHandler(Exception.class)
    public ModelAndView handlerException(HttpServletRequest req, Exception exception) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("exceptionMessage", exception.getClass().getCanonicalName() + ", message: " + exception.getMessage());
        mav.setViewName("error");
        return mav;
    }

}
