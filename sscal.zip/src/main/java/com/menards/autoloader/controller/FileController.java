package com.menards.autoloader.controller;

import com.menards.autoloader.domain.mcr.ExcelValidationHistory;
import com.menards.autoloader.service.ExcelValidationService;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * <p>FileController</p>
 * <p>A controller class for file upload.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @author james.ni
 * @version 1.0
 */
@Controller
public class FileController extends BaseController {

    private static Log logger = LogFactory.getLog(FileController.class);
    private static final int PAGE_SIZE = 10;

    @Autowired
    private ExcelValidationService excelValidationService;

    /**
     * A controller method that list all the uploaded files.
     * @param model model object that pass the data to the page.
     * @param servletRequest HttpServletRequest
     * @throws Exception  an Exception.
     */
    @RequestMapping(value = { "/file" }, method = RequestMethod.GET)
    public void list(HttpServletRequest servletRequest, ModelMap model,
                     @RequestParam(defaultValue = "1") int pageNum) throws Exception {
        List<ExcelValidationHistory> excelValidationHistoryList = null;
        String historyVendor = servletRequest.getParameter("historyVendor");
        if (historyVendor != null && !"".equals(historyVendor.trim())) {
            excelValidationHistoryList = excelValidationService.getAllExcelValidationHistory(historyVendor);
        } else {
            excelValidationHistoryList = excelValidationService.getAllExcelValidationHistory();
        }
        setPaginationModeAttribute(pageNum, model, excelValidationHistoryList);
    }

    /**
     *
     * @param pageNum page number
     * @param model ModeMap
     * @param excelValidationHistoryList list of excel validation history
     */
    private void setPaginationModeAttribute(int pageNum,
                                            ModelMap model,
                                            List<ExcelValidationHistory> excelValidationHistoryList) {
        int totalRecords = excelValidationHistoryList.size();
        int totalPage = (int) Math.ceil(Double.valueOf(totalRecords) / PAGE_SIZE);
        if (totalPage == pageNum) {
            model.put("isLastPage", true);
        }
        if (pageNum == 1) {
            model.put("isFirstPage", true);
        }
        model.put("pageNum", pageNum);
        model.put("pageSize", PAGE_SIZE);
        model.put("totalPage", totalPage);
        int startRecordNum = (pageNum - 1) * PAGE_SIZE;
        int endRecordNum = pageNum * PAGE_SIZE;
        List subList = excelValidationHistoryList.subList(startRecordNum,
                endRecordNum > totalRecords ? totalRecords : endRecordNum);
        model.put("excelValidationHistoryList", subList);
    }

    /**
     * A controller method that download the file content.
     * @param request an {@link HttpServletRequest} object from which the file path to be download will be retrieved.
     * @param response an {@link HttpServletResponse} object to which the binary file content will be sent.
     * @param model model object that pass the data to the page.
     * @return the logic view name.
     * @throws Exception an Exception.
     */
    @RequestMapping(value = "/file/{fileType}/{validationTimestampNumber}", method = RequestMethod.GET)
    public String get(HttpServletRequest request,
                      HttpServletResponse response,
                      ModelMap model,
                      @PathVariable("fileType") String fileType,
                      @PathVariable("validationTimestampNumber") String validationTimestampNumber) throws Exception {

        Long dateNumber = Long.valueOf(validationTimestampNumber);
        ExcelValidationHistory excelValidationHistory =
                excelValidationService.getVendorByValidationDateNumber(dateNumber);
        String dateString = getStringDate(excelValidationHistory.getValidationTimestamp());
        String vendor = excelValidationHistory.getVendor();
        if ("log".equals(fileType)) {
            String logContent = excelValidationService.getExcelValidationHistoryLog(dateNumber);
            if (logContent == null) {
                return null;
            }
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + vendor + "_" + dateString + ".log\"");
            FileCopyUtils.copy(new BufferedInputStream(new ByteArrayInputStream(logContent.getBytes())), response.getOutputStream());
        } else if ("excel".equals(fileType)) {
            byte[] excelContent = excelValidationService.getExcelFileContent(dateNumber);
            if (excelContent == null) {
                return null;
            }
            response.setContentType("text/plain");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + vendor + "_" + dateString + ".xls\"");
            FileCopyUtils.copy(new BufferedInputStream(new ByteArrayInputStream(excelContent)), response.getOutputStream());
        }
        return null;
    }

    /**
     *
     * @param date date
     * @return human readable date format
     */
    private String getStringDate(Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String dateString = simpleDateFormat.format(date);
        return dateString;
    }
}
