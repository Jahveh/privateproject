package com.menards.autoloader.utils;

import org.springframework.util.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public final class FileChecksumUtils {
    /**
     *
     * @param file file
     * @return checksum in the form of String
     * @throws NoSuchAlgorithmException exception
     * @throws IOException io exception
     */
    public static String getChecksum(File file) {
        Exception exception = null;
        StringBuffer sb = new StringBuffer("");
        try {
            MessageDigest md = MessageDigest.getInstance("SHA1");
            FileInputStream fis = new FileInputStream(file);
            byte[] dataBytes = new byte[1024];
            int nRead = 0;
            while ((nRead = fis.read(dataBytes)) != -1) {
                md.update(dataBytes, 0, nRead);
            }

            byte[] mdBytes = md.digest();
            //convert the byte to hex format
            for (byte b : mdBytes) {
                sb.append(Integer.toString((b & 0xff) + 0x100, 16).substring(1));
            }
        } catch(Exception ex) {
            exception = ex;
        }
        Assert.isTrue(exception == null, exception == null ? "" : exception.getMessage());
        return sb.toString();
    }

    /**
     * a private constructor
     */
    private FileChecksumUtils() {

    }
}
