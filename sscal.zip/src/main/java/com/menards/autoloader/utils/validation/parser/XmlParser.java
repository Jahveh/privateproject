/*
 * XmlParser
 * 
 * PCR      Who Date        Change
 * -----    --- --------    -------
 *          SL              created
 */
package com.menards.autoloader.utils.validation.parser;

import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ucAutoloader.menards.com.ValidationDocument;
import ucAutoloader.menards.com.ValidationRoot;

import java.io.File;
import java.io.IOException;


/**
 * XmlParser
 * <p/>
 * Simple wrapper to extract the xml data
 * <p/>
 * Copyright (c) 2008
 * Menard Inc.
 *
 * @author Stephen Lake
 * @version 1.0
 */
public class XmlParser {

    private Logger logger = LoggerFactory.getLogger(XmlParser.class);

    private ValidationRoot validationRoot;

    /**
     *
     * @param file file
     */
    public XmlParser(File file) {
        if (file == null) {
            logger.info("XmlParser requires a file name");
            System.exit(1);
        }

        try {
            ValidationDocument validationDocument = ValidationDocument.Factory.parse(file);
            validationRoot = validationDocument.getValidation();
        } catch (XmlException e) {
            logger.error("error with xml file" + file.getAbsoluteFile());
        } catch (IOException e) {
            logger.error("xml file not found at " + file.getAbsoluteFile());
        }
    }

    public ValidationRoot getValidationRoot() {
        return validationRoot;
    }


}
