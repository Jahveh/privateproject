package com.menards.autoloader.utils;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersIncrementer;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobParametersNotFoundException;
import org.springframework.util.Assert;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * <p>BatchUtils</p>
 * <p>A Spring Batch utility class.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public final class BatchUtils {
    /**
     * A private constructor just make it un-instantiable.
     */
    private BatchUtils() {

    }

    /**
     * Get next runtime job parameter.
     * @param job the job to which needs the next parameter.
     * @param jobExplorer a jobExplorer object from which data in job repo is accessible.
     * @return the next runtime job parameter
     * @throws JobParametersNotFoundException thrown if no job parameter incrementer is configured.
     */
    public static JobParameters getNextJobParameters(Job job, JobExplorer jobExplorer)
            throws JobParametersNotFoundException {
        String jobIdentifier = job.getName();
        JobParameters jobParameters;
        List<JobInstance> lastInstances = jobExplorer.getJobInstances(jobIdentifier, 0, 1);

        JobParametersIncrementer incrementer = job.getJobParametersIncrementer();
        if (incrementer == null) {
            throw new JobParametersNotFoundException("No job parameters incrementer found for job=" + jobIdentifier);
        }

        if (lastInstances.isEmpty()) {
            jobParameters = incrementer.getNext(new JobParameters());
            if (jobParameters == null) {
                throw new JobParametersNotFoundException("No bootstrap parameters found from incrementer for job="
                        + jobIdentifier);
            }
        } else {
            jobParameters = incrementer.getNext(lastInstances.get(0).getJobParameters());
        }
        return jobParameters;
    }

    /**
     * Build JobParameters based on an existing JobParameters
     * @param oldJobParameters an existing JobParameters
     * @param newParameters a map containing the new parameters
     * @return a JobParameter combining both oblJobParameters and new parameter map.
     */
    public static JobParameters buildJobParameters(JobParameters oldJobParameters, Map<String, Object> newParameters) {
        Assert.isTrue(newParameters != null, "The Map should not be null.");
        JobParametersBuilder paramBuilder = new JobParametersBuilder();
        if (oldJobParameters != null) {
            for (Map.Entry<String, JobParameter> entry : oldJobParameters.getParameters().entrySet()) {
                paramBuilder.addParameter(entry.getKey(), entry.getValue());
            }
        }
        for (Map.Entry<String, ?> newParam : newParameters.entrySet()) {
            Assert.isTrue(newParam.getValue() instanceof String
                    || newParam.getValue() instanceof Long
                    || newParam.getValue() instanceof Date
                    || newParam.getValue() instanceof Double,
                    "The value's type of the Map should be either of String, Long, Date, Double");

            if (newParam.getValue() instanceof String) {
                paramBuilder.addString(newParam.getKey(), (String) newParam.getValue());
            } else if (newParam.getValue() instanceof Long) {
                paramBuilder.addLong(newParam.getKey(), (Long) newParam.getValue());
            } else if (newParam.getValue() instanceof Date) {
                paramBuilder.addDate(newParam.getKey(), (Date) newParam.getValue());
            } else if (newParam.getValue() instanceof Double) {
                paramBuilder.addDouble(newParam.getKey(), (Double) newParam.getValue());
            }
        }



        return paramBuilder.toJobParameters();
    }



}
