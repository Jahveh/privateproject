package com.menards.autoloader.utils;

import org.springframework.batch.admin.web.resources.Menu;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


/**
 * <p>MenuManager</p>
 * <p>A Spring managed bean that auto collect all the menu items declared through Spring context
 * configuration files.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
@Component
public class MenuManager {

    private List<Menu> menus;

    /**
     * The menus to manage. Autowired so the aggregation happens automatically
     * by default.
     *
     * @param menus the menus to set
     */
    @Autowired
    public void setMenus(Collection<Menu> menus) {
        this.menus = new ArrayList();
        List<Menu> tailingMenus = new ArrayList<Menu>();
        for (Menu menu : menus) {
            if (!menu.getUrl().endsWith("files") && !menu.getLabel().equals("Home")) {
                if (menu.getLabel().equals("Jobs") || menu.getLabel().equals("Executions")) {
                    tailingMenus.add(menu);
                    continue;
                }
                this.menus.add(menu);
            }
        }
        Collections.sort(this.menus, new MenuComparator());
        this.menus.addAll(tailingMenus);
    }

    public Collection<Menu> getMenus() {
        return menus;
    }

    /**
     * A Comparator strategy class that implements {@link Comparator}
     */
    private static class MenuComparator implements Comparator<Menu> {
        @Override
        public int compare(Menu one, Menu two) {
            if (one.getOrder() == two.getOrder()) {
                return one.getLabel().compareTo(two.getLabel());
            }
            if (one.getOrder() < two.getOrder()) {
                return -1;
            } else if (one.getOrder() > two.getOrder()) {
                return 1;
            } else {
                return 0;
            }
        }

    }

}