package com.menards.autoloader.utils;

import com.menards.autoloader.domain.CategoryTree;

import org.apache.commons.collections.CollectionUtils;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;


/**
 * <p>CategoryTreeCalculationUtils</p>
 * <p>An utility class that encapsulates tree manipulation algorithms for the category.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public final class CategoryTreeCalculationUtils {

    /**
     * Private constructor that makes it un-instantiable.
     */
    private CategoryTreeCalculationUtils() {

    }

    /**
     * Build a dictionary data structure with category tree path as keys, and category as values.
     * @param category Root category tree node.
     * @return a dictionary.
     */
    public static Map<String, CategoryTree> buildCategoryDictionaryByPath(CategoryTree category) {
        Map<String, CategoryTree> map = new HashMap<String, CategoryTree>();
        traverseCategoryTree(category, map);
        return map;
    }

    /**
     * Assemble the dictionary data structure from the root category.
     * @param category Root category tree node.
     * @param map A dictionary.
     */
    private static void traverseCategoryTree(CategoryTree category, Map<String, CategoryTree> map) {
        map.put(category.getPathToThisNode(), category);
        for (CategoryTree tree : category.getSubCategories()) {
            traverseCategoryTree(tree, map);
        }
    }

    /**
     * Build a category dictionary from a list of {@link CategoryTree}.
     * @param list a list of {@link CategoryTree}.
     * @return a dictionary.
     */
    public static Map<String, CategoryTree> buildCategoryDictionaryByPath(List<CategoryTree> list) {
        Map<String, CategoryTree> categoryTreeDictionary = new LinkedHashMap<String, CategoryTree>();
        for (CategoryTree category : list) {
            categoryTreeDictionary.put(category.getPathToThisNode(), category);
        }
        return categoryTreeDictionary;
    }

    /**
     * Build a dictionary data structure with category id path as keys, and category as values.
     * @param list a list of {@link CategoryTree}.
     * @return a dictionary.
     */
    public static Map<Long, CategoryTree> buildCategoryDictionaryById(List<CategoryTree> list) {
        Map<Long, CategoryTree> categoryTreeDictionary = new LinkedHashMap<Long, CategoryTree>();
        for (CategoryTree category : list) {
            categoryTreeDictionary.put(category.getCategoryId(), category);
        }
        return categoryTreeDictionary;
    }

    /**
     * Assemble a list of {@link CategoryTree} into one tree.
     * @param list a list of {@link CategoryTree}.
     * @return a dictionary.
     */
    public static CategoryTree buildRootCategory(List<CategoryTree> list) {
        Map<Long, CategoryTree> categoryTreeDictionary = buildCategoryDictionaryById(list);
        CategoryTree root = null;
        for (Map.Entry<Long, CategoryTree> entry : categoryTreeDictionary.entrySet()) {
            CategoryTree currentCategory = entry.getValue();
            CategoryTree parentCategory = categoryTreeDictionary.get(currentCategory.getParentCategoryId());
            if (parentCategory.getCategoryId().equals(currentCategory.getCategoryId())) {
                root = currentCategory;
                root.setParentCategory(root);
            } else {
                parentCategory.getSubCategories().add(currentCategory);
                currentCategory.setParentCategory(parentCategory);
            }
        }
        return root;
    }

    /**
     * Merge the new product families specified in the excel spread sheet into the existing categories.
     * @param excelProductFamilies product families from excel spread sheet.
     * @param legacyCategoryDict existing categories in dictionary data structure.
     */
    public static void mergeNewCategories(Set<String> excelProductFamilies,
                                          Map<String, CategoryTree> legacyCategoryDict) {
        Collection<String> deltaProductFamilies =
                CollectionUtils.subtract(excelProductFamilies, legacyCategoryDict.keySet());
        for (String productFamily : deltaProductFamilies) {
            mergerSingleCategoryPath(productFamily, legacyCategoryDict);
        }
    }

    /**
     * Merge a single product family from excel spread sheet into existing DB category.
     * @param categoryPath A new category path from excel spread sheet.
     * @param legacyCategoryDict the existing categories in DB.
     */
    private static void mergerSingleCategoryPath(String categoryPath,
                                                  Map<String, CategoryTree> legacyCategoryDict) {
        Stack<String> categoryPathStack = new Stack<String>();
        Set<String> legacyCategoryPaths = legacyCategoryDict.keySet();
        do {
            categoryPathStack.push(categoryPath);
            categoryPath = getParentCategoryPath(categoryPath);
        } while (!legacyCategoryPaths.contains(categoryPath));
        appendDescendCategories(categoryPathStack, legacyCategoryDict, categoryPath);
    }

    /**
     * Create a CategoryTree based on each category path in the categoryPathStack, and then append as the child
     * category to the CategoryTree represented by the parentCategoryPath.
     *
     * @param categoryPathStack All the category paths to be created on the old category tree.
     * @param legacyCategoryDict The legacy category dictionary.
     * @param parentCategoryPath The target category tree node (represented by this param) to which the newly created
     *                           category tree node will be appended.
     */
    private static void appendDescendCategories(Stack<String> categoryPathStack,
                                                Map<String, CategoryTree> legacyCategoryDict,
                                                String parentCategoryPath) {

        for (String categoryPath = categoryPathStack.pop(); true; categoryPath = categoryPathStack.pop()) {
            CategoryTree parentCategory = legacyCategoryDict.get(parentCategoryPath);
            CategoryTree newCategory = new CategoryTree();
            newCategory.setCategoryName(categoryPath.substring(categoryPath.lastIndexOf("/") + 1));
            newCategory.setNewCategoryForImport(true);
            newCategory.setCategoryId(buildCategoryIdByParentCategory(parentCategory));
            newCategory.setParentCategoryId(parentCategory.getCategoryId());
            newCategory.setParentCategory(parentCategory);
            newCategory.setPathToThisNode(categoryPath);
            parentCategory.getSubCategories().add(newCategory);
            parentCategoryPath = categoryPath;
            legacyCategoryDict.put(categoryPath, newCategory);
            if (categoryPathStack.size() == 0) {
                break;
            }
        }
    }

    /**
     * Get the parent category for a given category path.
     * @param categoryPath a category path.
     * @return the parent category path.
     */
    private static String getParentCategoryPath(String categoryPath) {
        String parentPath = categoryPath.substring(0, categoryPath.lastIndexOf("/"));
        if (parentPath.equals("")) {
            return "/";
        }
        return parentPath;
    }

    /**
     * Build a category tree from a list of product families.
     * @param productFamilies a list of product families.
     * @return a root tree represented by {@link CategoryTree}
     */
    public static CategoryTree buildCategoryTree(Set<String> productFamilies) {
        CategoryTree rootTree = createCategoryTree("root", 10L, 10L);
        rootTree.setPathToThisNode("/");
        Iterator<String> iterator = productFamilies.iterator();
        String aTreePath;
        while (iterator.hasNext()) {
            aTreePath = iterator.next();
            constructTreeByATreePath(aTreePath.split("_"), rootTree);
        }
        return rootTree;
    }

    /**
     * A builder method that builds an object of {@link CategoryTree} from the pass-in parameters
     * @param categoryName category name.
     * @param categoryId category id.
     * @param parentId parent category id.
     * @return a root category thee in form of {@link CategoryTree}
     */
    public static CategoryTree createCategoryTree(String categoryName, Long categoryId, Long parentId) {
        CategoryTree categoryTree = new CategoryTree();
        categoryTree.setCategoryName(categoryName);
        categoryTree.setCategoryId(categoryId);
        categoryTree.setParentCategoryId(parentId);
        return categoryTree;
    }

    /**
     * Add tree branches to the given category tree.
     * @param treePath an array of tree pathes.
     * @param categoryTree the root category tree to which all the newly created tree branches would be attached.
     */
    private static void constructTreeByATreePath(String[] treePath, CategoryTree categoryTree) {
        CategoryTree currentTree = categoryTree;
        for (String aTreePath : treePath) {
            currentTree = putNodeInTree(currentTree, aTreePath);
        }
    }

    /**
     * Add a child tree node to the designated tree node.
     * @param currentTree a tree node.
     * @param childNodeName new tree node to be created.
     * @return a category tree node.
     */
    private static CategoryTree putNodeInTree(CategoryTree currentTree, String childNodeName) {
        for (int i = 0; i < currentTree.getSubCategories().size(); i++) {
            if (childNodeName.equals(currentTree.getSubCategories().get(i).getCategoryName())) {
                return currentTree.getSubCategories().get(i);
            }
        }
        long newNodeId = buildCategoryIdByParentCategory(currentTree);
        CategoryTree newTreeNode = createCategoryTree(childNodeName, newNodeId, currentTree.getCategoryId());
        String tmp;
        if (currentTree.getPathToThisNode().equals("/")) {
            tmp = "";
        } else {
            tmp = "/";
        }
        newTreeNode.setPathToThisNode(currentTree.getPathToThisNode() + tmp + childNodeName);
        newTreeNode.setParentCategory(currentTree);
        currentTree.getSubCategories().add(newTreeNode);
        return newTreeNode;
    }

    /**
     * Calculate a category id.
     * @param category the category of which the new id would be created.
     * @return the newly created category id.
     */
    private static Long buildCategoryIdByParentCategory(CategoryTree category) {
        return category.getCategoryId() * 100 + category.getSubCategories().size() + 1;
    }

}
