package com.menards.autoloader.utils;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>ExcelUtils</p>
 * <p>An utility class that encapsulates all the necessary excel spread sheet manipulation operations
 * through Apache POI.</p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 * @author frank.peng
 * @version 1.0
 */
public final class ExcelUtils {

    /**
     * Upper Case Column Headers <==> Original Column Headers
     */
    private static Map<String, String> excelColumnHeaderMap = new HashMap<String, String>();

    public static Map<String, String> getExcelColumnHeaderMap() {
        return Collections.unmodifiableMap(excelColumnHeaderMap);
    }

    /**
     * The private constructor method that makes it un-instantiable.
     */
    private ExcelUtils() {

    }
    /**
     * Return the sheet by the name regardless of the case of the name.
     *
     * @param workbook a POI {@link Workbook}
     * @param sheetName the name of the sheet
     * @return a POI {@link Sheet}.
     */
    public static Sheet getSheetByName(Workbook workbook, String sheetName) {
        Sheet sheet = null;
        for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
            sheet = workbook.getSheetAt(i);
            if (sheet.getSheetName().equalsIgnoreCase(sheetName)) {
                break;
            }
        }
        return sheet;
    }


    /**
     * Get a list of POI sheet based on a list of sheet names.
     * @param workbook a POI {@link Workbook}
     * @param sheetNames a list of sheet names
     * @return a list of POI {@link Sheet}.
     */
    public static List<Sheet> getSheetsByNames(Workbook workbook, String... sheetNames) {
        List<Sheet> sheets = new ArrayList<Sheet>();
        for (String sheetName : sheetNames) {
            for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
                Sheet sheet = workbook.getSheetAt(i);
                if (sheet.getSheetName().equalsIgnoreCase(sheetName)) {
                    sheets.add(sheet);
                }
            }
        }
        return sheets;
    }

    /**
     * Get index of column in the given sheet.
     * @param sheet a POI {@link Sheet}.
     * @param columnName column name
     * @return the index number
     */
    public static int getColumnIndexByColumnName(Sheet sheet, String columnName) {
        int index = -1;
        Row row = sheet.getRow(0);
        for (int i = 0; i < row.getLastCellNum(); i++) {
            if (columnName.equalsIgnoreCase(row.getCell(i).getStringCellValue())) {
                index = i;
                break;
            }
        }
        return index;
    }

    /**
     *
     * @param sheet a POI {@link Sheet}.
     * @param row a POI {@link Row}
     * @param excelColumns a set of column names
     * @return a data map with spread sheet column name as its key and corresponding cell value as its value.
     */
    public static Map<String, String> getRowFieldValues(Sheet sheet, Row row, Set<String> excelColumns) {
        Map<String, String> rowFieldValues = new HashMap<String, String>();
        for (String columnName : excelColumns) {
            int columnIndex = getColumnIndexByColumnName(sheet, columnName);
            if (columnIndex == -1) {
                continue;
            }
            String cellValue = row.getCell(columnIndex).getStringCellValue();
            rowFieldValues.put(columnName, cellValue);
        }
        return rowFieldValues;
    }

    /**
     * Get a column headers for a given sheet
     * @param sheet a POI {@link Sheet}.
     * @return a {@link Set} object containing all the column headers.
     */
    public static Set<String> getSheetColumnHeaders(Sheet sheet) {
        Set<String> columnHeaders = new HashSet<String>();
        Row headerRow = sheet.getRow(0);
        for (int i = 0; i < headerRow.getLastCellNum(); i++) {
            Cell cell = headerRow.getCell(i);
            columnHeaders.add(cell.getStringCellValue());
        }
        return columnHeaders;
    }

    /**
     * Read the data from the given sheet.
     * @param sheet a POI {@link Sheet}.
     * @param columnHeaders a {@link java.util.Set} of column headers
     * @return a list of data map
     */
    public static List<Map<String, String>> getSheetData(Sheet sheet, Set<String> columnHeaders) {
        List<Map<String, String>> sheetData = new LinkedList<Map<String, String>>();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) {
                continue;
            }
            Map<String, String> rowData = getDataForRow(row, columnHeaders);
            if (!rowData.isEmpty()) {
                sheetData.add(rowData);
            }
        }
        return sheetData;
    }

    /**
     * Get a single data map for a given row
     * @param row a POI {@link Row}
     * @param columnHeaders a {@link java.util.Set} of column headers
     * @return a single data map with column headers as its keys and cell values as its values.
     */
    public static Map<String, String> getDataForRow(Row row, Set<String> columnHeaders) {
        Map<String, String> rowData = new HashMap<String, String>();
        for (String columnHeader : columnHeaders) {
            int columnIndex = getColumnIndexByColumnName(row.getSheet(), columnHeader);
            Cell cell = row.getCell(columnIndex);
            if (cell == null) {
                continue;
            }
            String cellValue = getCellValue(cell);
            if (cellValue != null) {
                excelColumnHeaderMap.put(columnHeader.toUpperCase(), columnHeader);
                rowData.put(columnHeader.toUpperCase(), cellValue);
            }
        }
        return rowData;
    }


    /**
     * Read a cell's value based on its type.
     * @param cell a POI {@link org.apache.poi.ss.usermodel.Cell} object
     * @return a string representation of the cell value.
     */
    public static String getCellValue(Cell cell) {
        String value = null;
        if (cell == null) {
            return null;
        }
        switch (cell.getCellType()) {
            case Cell.CELL_TYPE_NUMERIC:
                value = Long.toString((long) cell.getNumericCellValue());
                break;
            case Cell.CELL_TYPE_STRING:
                value = cell.getStringCellValue();
                break;
            case Cell.CELL_TYPE_BOOLEAN:
                value = Boolean.toString(cell.getBooleanCellValue());
                break;
            default:
                value = null;
        }
        return value;
    }

    /**
     * get vendor from a given workbook
     * @param workbook an excel workbook
     * @return vendor
     */
    public static String getVendor(Workbook workbook) {
        String vendor = null;
        for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
            Sheet sheet = workbook.getSheetAt(i);
            Set<String> columnHeaders = getSheetColumnHeaders(sheet);
            for (String columnHeader : columnHeaders) {
                if (columnHeader.equalsIgnoreCase("VENDOR_LOGO")) {
                    int vendorLogoColumnIndex = getColumnIndexByColumnName(sheet, "VENDOR_LOGO");
                    for (int j = 1; j <= sheet.getLastRowNum(); j++) {
                        String vendorLogo = getCellValue(sheet.getRow(j).getCell(vendorLogoColumnIndex));
                        if (vendorLogo != null && !vendorLogo.trim().equals("")) {
                            return vendorLogo;
                        }
                    }
                }
            }

        }
        return vendor;
    }

}
