package com.menards.autoloader.utils;

import org.springframework.ui.ModelMap;
import org.springframework.util.Assert;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author frank.peng
 * @version 1.0
 */
public class WebUtils {

    /**
     * Private constructor make this utility class un-instantiable.
     */
    private WebUtils() {

    }

    /**
     * A utility method that adds error message to the model.
     *
     * @param model    model object that pass the data to the page.
     * @param errorMsg error message.
     */
    public static void addErrorMsgToModel(ModelMap model, String errorMsg) {
        List<String> errors = (List<String>) (model.get("errors"));
        if (errors == null) {
            errors = new ArrayList<String>();
        }
        errors.add(errorMsg);
        model.put("errors", errors);
    }

    /**
     * A utility method that adds all error messages in a map to the model.
     *
     * @param model model object that pass the data to the page.
     * @param map   map with error messages.
     */
    public static void addAllErrorMsgToModel(ModelMap model, Map<String, String> map) {
        List<String> errors = (List<String>) (model.get("errors"));
        if (errors == null) {
            errors = new ArrayList<String>();
        }
        errors.addAll(map.values());
        model.addAttribute("errors", errors);
    }

    /**
     * Extract catalog name from Excel path
     * @param path path
     * @return catalog name
     */
    public static String getCatalogName(String path) {
        String literaturePrefix = "Literature";
        String sscPrefix = "StoreSuppliesCatalog";
        String unknownCatalog = "Unknown Catalog";
        if (path.contains(literaturePrefix)) {
            return "Literature";
        } else if (path.contains(sscPrefix)) {
            return "Store Supplies Catalog";
        }
        return unknownCatalog;
    }
}
