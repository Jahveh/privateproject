package com.menards.autoloader.utils;

import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.jdbc.support.incrementer.MySQLMaxValueIncrementer;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by frank.peng on 1/22/14.
 */
public class SimpleMySQLMaxValueIncrementer extends MySQLMaxValueIncrementer {

    /** The next id to serve */
    private long nextId = 0;

    /** The max id to serve */
    private long maxId = 0;

    @Override
    protected synchronized long getNextKey() {
        if (this.maxId == this.nextId) {
			/*
			* Need to use straight JDBC code because we need to make sure that the insert and select
			* are performed on the same connection (otherwise we can't be sure that last_insert_id()
			* returned the correct value)
			*/
            Connection con = DataSourceUtils.getConnection(getDataSource());
            Statement stmt = null;
            try {
                stmt = con.createStatement();
                DataSourceUtils.applyTransactionTimeout(stmt, getDataSource());
                // Increment the sequence column...
                String columnName = getColumnName();
                stmt.executeUpdate("update " + getIncrementerName() + " set " + columnName
                        + " = " + columnName + " + " + getCacheSize());
                ResultSet rs = stmt.executeQuery("select " + columnName + " from " + getIncrementerName());
                try {
                    if (!rs.next()) {
                        throw new DataAccessResourceFailureException(
                                " [select " + columnName + " from " + getIncrementerName() + "] returns no value!");
                    }
                    maxId = rs.getLong(1);
                } finally {
                    JdbcUtils.closeResultSet(rs);
                }
                this.nextId = this.maxId - getCacheSize() + 1;
            } catch (SQLException ex) {
                throw new DataAccessResourceFailureException("Could not obtain maxId from " + getIncrementerName(), ex);
            } finally {
                JdbcUtils.closeStatement(stmt);
                DataSourceUtils.releaseConnection(con, getDataSource());
            }
        } else {
            this.nextId++;
        }
        return this.nextId;
    }

    /**
     * Default constructor for bean property style usage.
     *
     * @see #setDataSource
     * @see #setIncrementerName
     * @see #setColumnName
     */
    public SimpleMySQLMaxValueIncrementer() {
    }

    /**
     * Convenience constructor.
     *
     * @param dataSource      the DataSource to use
     * @param incrementerName the name of the sequence/table to use
     * @param columnName      the name of the column in the sequence table to use
     */
    public SimpleMySQLMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName) {
        super(dataSource, incrementerName, columnName);
    }
}
