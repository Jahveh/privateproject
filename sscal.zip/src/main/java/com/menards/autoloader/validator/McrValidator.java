package com.menards.autoloader.validator;

import com.menards.autoloader.domain.mcr.MCR;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 * <p></p>
 * <p>Copyright (c) 2014</p>
 * <p>Menard Inc.</p>
 *
 * @author james.ni
 * @version 1.0
 */
@Component
public class McrValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return MCR.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        MCR newMcr = (MCR) target;
        if (StringUtils.isBlank(newMcr.getTitle())) {
            addErrorMessage(errors, "title.missing", "Title is required. ");
        }
        if (null == newMcr.getPriority() || newMcr.getPriority().getId() < 0) {
            addErrorMessage(errors, "priority.missing", "Priority is required. ");
        }
        if (StringUtils.isBlank(newMcr.getChangeReason())) {
            addErrorMessage(errors, "changeReason.missing", "Reason for change is required. ");
        }
        if (StringUtils.isBlank(newMcr.getChangeExplanation())) {
            addErrorMessage(errors, "changeExplanation.missing", "Explanation for change is required. ");
        }
        if (StringUtils.isBlank(newMcr.getBusinessImpact())) {
            addErrorMessage(errors, "businessImpact.missing", "Business or user impact of change required.");
        }
        if (newMcr.getApprovers() == null || newMcr.getApprovers().isEmpty()) {
            addErrorMessage(errors, "approvers.missing", "Approvals required. ");
        }
    }

    /**
     *
     * @param errors error
     * @param errorCode error code
     * @param defaultMessage default error message
     */
    private void addErrorMessage(Errors errors, String errorCode, String defaultMessage) {
        errors.rejectValue(errorCode, defaultMessage);
    }
}
