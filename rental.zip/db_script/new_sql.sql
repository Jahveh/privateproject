CREATE TABLE `overdue_notification` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`agreement_nbr` VARCHAR(16) NOT NULL,
	`times` INT(11) NOT NULL,
	PRIMARY KEY (`id`),
	UNIQUE INDEX `id` (`id`),
	INDEX `FK_overdue_notification_rental_agreement` (`agreement_nbr`),
	CONSTRAINT `FK_overdue_notification_rental_agreement` FOREIGN KEY (`agreement_nbr`) REFERENCES `rental_agreement` (`rental_agreement_nbr`)
)
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB
AUTO_INCREMENT=5;
CREATE TABLE `agreement_log` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `agreement_id` bigint(20) NOT NULL,
  `pre_due_by` datetime DEFAULT '0000-00-00 00:00:00',
  `cur_due_by` datetime DEFAULT '0000-00-00 00:00:00',
  `demand_letter_status` int(1) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
