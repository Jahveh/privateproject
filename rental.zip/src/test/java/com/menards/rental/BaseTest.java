package com.menards.rental;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"file:src/main/webapp/WEB-INF/config/applicationContext.xml",
    "file:src/main/webapp/WEB-INF/config/applicationContext-ws.xml",
    "classpath:spring/config/applicationContext-override.xml"    
}
)
public abstract class BaseTest {

}
