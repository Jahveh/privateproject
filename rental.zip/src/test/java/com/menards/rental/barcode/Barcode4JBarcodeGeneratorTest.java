/*
 * Barcode4JBarcodeGeneratorTest.java
 */
package com.menards.rental.barcode;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

import com.menards.rental.service.BarcodeTypeStrategy;
import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.krysalis.barcode4j.impl.AbstractBarcodeBean;
import org.krysalis.barcode4j.impl.code39.Code39Bean;

/**
 * The Class Barcode4JBarcodeGeneratorTest.
 */
public class Barcode4JBarcodeGeneratorTest {

	/** The bar code generator. */
	private BarcodeGenerator barCodeGenerator;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		barCodeGenerator = new Barcode4JBarcodeGenerator();
	}

	/**
	 * Check barcode is generated given a value.
	 */
	@Test
	public void checkBarcodeIsGeneratedGivenAValue() {
		final BarcodeDetails barcodeDetails = new BarcodeDetails();
		barcodeDetails.setImageType("image/x-png");
		barcodeDetails.setBarHeight(12.5); // 12.5 mm
		barcodeDetails.setNarrowBarWidth(0.20); // 0.20 mm
		barcodeDetails.setWidthFactor(3);
		barcodeDetails.setResolution(150);
        final BarcodeTypeStrategy typeStrategy = mock(BarcodeTypeStrategy.class);
        when(typeStrategy.getBean(barcodeDetails)).thenReturn(new Code39Bean());
        barcodeDetails.setTypeStrategy(typeStrategy);
		barcodeDetails.setToGenerateValue("888840010001");

		final Barcode barcode = barCodeGenerator.generateBarcode(barcodeDetails);

		assertNotNull(barcode);

		// The 290 comes from basically the code itself. It can change if the
		// algorithm to generate the bar code or the image type or the barcode
		// details is changed.
		// length seems to be OS dependent as well. I get 282 on Mac OS X 10.6.4
		assertTrue(barcode.getImage().length > 0);
		assertEquals("image/x-png", barcode.getImageType());
	}

	/**
	 * Return null if bar code generation fails.
	 */
	@Test
	public void returnNullIfBarCodeGenerationFails() {
		// Make a BarcodeDetails object with no parameter set
		final BarcodeDetails barcodeDetails = new BarcodeDetails();
        final BarcodeTypeStrategy typeStrategy = mock(BarcodeTypeStrategy.class);
        when(typeStrategy.getBean(barcodeDetails)).thenReturn(new Code39Bean());

		final Barcode barcode = barCodeGenerator.generateBarcode(barcodeDetails);
		Assert.assertNull(barcode);

	}
}
