package com.menards.rental.action;

import com.menards.rental.dao.SearchDao;
import com.menards.rental.domain.Product;
import com.menards.rental.domain.RentalSKU;
import com.menards.rental.service.ContextService;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
public class SearchActionTest {

    private SearchAction action;
    private ContextService contextService;
    private SearchDao searchDao;

    @Before
    public void setUp() {
        action = new SearchAction();
        contextService = mock(ContextService.class);
        action.setContextService(contextService);
        searchDao = mock(SearchDao.class);
        action.setSearchDao(searchDao);
    }

    @Test
    public void shouldReturnTheRentalSKUInstance() {
        assertNotNull(action.createEmptySKU());
    }
    
    @Test
    public void shouldGetTheCurrentStoreNumberFromTheContextService() {
        when(contextService.getStoreNumber()).thenReturn(1233);
        final ArrayList<Product> products = new ArrayList<Product>();
        final RentalSKU baseSKU = new RentalSKU();
        when(searchDao.getAllMatchingProductsForStore(1233, baseSKU)).thenReturn(products);

        assertSame(products, action.getAllMatchingProductsForCurrentStore(baseSKU));
    }
}
