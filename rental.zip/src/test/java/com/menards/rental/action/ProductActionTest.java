/*
 * ProductActionTest.java
 */
package com.menards.rental.action;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.expectReturn;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.playback;

import java.util.ArrayList;

import com.menards.rental.domain.RentalSKU;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.staticmock.MockStaticEntityMethods;
import org.springframework.webflow.core.collection.MutableAttributeMap;
import org.springframework.webflow.execution.RequestContext;

import com.menards.rental.domain.Product;
import com.menards.rental.service.ProductService;

/**
 * User: deep Date: 10 Jun, 2010 Time: 1:45:44 PM.
 */
@MockStaticEntityMethods
public class ProductActionTest {
	
	/** The action. */
	private ProductAction action;
	
	/** The service. */
	private ProductService service;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		action = new ProductAction();
		service = mock(ProductService.class);
		action.setProductService(service);
	}

	/**
	 * Should populate base sku list in the request context request scope.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldPopulateBaseSKUListInTheRequestContextRequestScope() throws Exception {
		final RentalSKU sku = new RentalSKU();
		sku.setType(RentalSKU.Type.BASE.toString());
		final ArrayList<RentalSKU> allSKUs = new ArrayList<RentalSKU>();
		allSKUs.add(sku);
		RentalSKU.findAllSKUSOrderedByTypeAndValue();
		expectReturn(allSKUs);
		playback();

		final RequestContext requestContext = getMockedRequestContext();
		action.populateSKU(requestContext);

		verify(requestContext.getRequestScope()).put("baseSKUs", allSKUs);
	}

	/**
	 * Should populate additional sku list in the request context request scope.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldPopulateAdditionalSKUListInTheRequestContextRequestScope() throws Exception {
		final RentalSKU baseSku = new RentalSKU();
		baseSku.setType(RentalSKU.Type.ADDITIONAL.toString());
		final ArrayList<RentalSKU> allSKUs = new ArrayList<RentalSKU>();
		allSKUs.add(baseSku);
		RentalSKU.findAllSKUSOrderedByTypeAndValue();
		expectReturn(allSKUs);
		playback();

		final RequestContext requestContext = getMockedRequestContext();
		action.populateSKU(requestContext);

		verify(requestContext.getRequestScope()).put("incrementalSKUs", allSKUs);
	}

	/**
	 * Should populate selling sku list in the request context request scope.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldPopulateSellingSKUListInTheRequestContextRequestScope() throws Exception {
		final RentalSKU baseSku = new RentalSKU();
		baseSku.setType(RentalSKU.Type.SELLING.toString());
		final ArrayList<RentalSKU> allSKUs = new ArrayList<RentalSKU>();
		allSKUs.add(baseSku);
		RentalSKU.findAllSKUSOrderedByTypeAndValue();
		expectReturn(allSKUs);
		playback();

		final RequestContext requestContext = getMockedRequestContext();
		action.populateSKU(requestContext);

		verify(requestContext.getRequestScope()).put("sellingSKUs", allSKUs);
	}

	/**
	 * Should populate surcharge sku list in the request context request scope.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldPopulateSurchargeSKUListInTheRequestContextRequestScope() throws Exception {
		final RentalSKU baseSku = new RentalSKU();
		baseSku.setType(RentalSKU.Type.SURCHARGE.toString());
		final ArrayList<RentalSKU> allSKUs = new ArrayList<RentalSKU>();
		allSKUs.add(baseSku);
		RentalSKU.findAllSKUSOrderedByTypeAndValue();
		expectReturn(allSKUs);
		playback();

		final RequestContext requestContext = getMockedRequestContext();
		action.populateSKU(requestContext);

		verify(requestContext.getRequestScope()).put("surchargeSKUs", allSKUs);
	}

	/**
	 * Should save the product using the product service.
	 */
	@Test
	public void shouldSaveTheProductUsingTheProductService() {
        final Product productToSave = new Product();
        final RentalSKU baseSKU = new RentalSKU();
        baseSKU.setId(1233L);
        productToSave.setBaseSKU(baseSKU);

        Product.findProductByBaseSKUId(1233L);
        expectReturn(null);
        playback();
		action.save(productToSave);

		verify(service).save(productToSave);
	}

    @Test
    public void shouldMergeTheProductIfAProductWithTheSameBaseSKUIdExistsInTheDb() {
        final Product productFromDB = new Product();

        Product.findProductByBaseSKUId(1233L);
        expectReturn(productFromDB);
        playback();

        final Product productToSave = new Product();
        final RentalSKU baseSKU = new RentalSKU();
        baseSKU.setId(1233L);
        productToSave.setBaseSKU(baseSKU);

        action.save(productToSave);

        verify(service).merge(productFromDB, productToSave);
    }

	/**
	 * Gets the mocked request context.
	 *
	 * @return the mocked request context
	 */
	private RequestContext getMockedRequestContext() {
		final MutableAttributeMap attr = mock(MutableAttributeMap.class);
		final RequestContext requestContext = mock(RequestContext.class);
		when(requestContext.getRequestScope()).thenReturn(attr);
		return requestContext;
	}
}
