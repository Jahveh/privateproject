/*
 * ItemActionTest.java
 */
package com.menards.rental.action;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.webflow.core.collection.MutableAttributeMap;
import org.springframework.webflow.execution.RequestContext;

import com.menards.rental.domain.Item;
import com.menards.rental.domain.Product;
import com.menards.rental.service.ItemService;
import com.menards.rental.utils.Constants;

/**
 * The Class ItemActionTest.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest(Product.class)
public class ItemActionTest {

	/** The item action. */
	private ItemAction itemAction;
	
	/** The item service mock. */
	private ItemService itemServiceMock;
	
	/** The product is a vehicle mock. */
	private Product productIsAVehicleMock;
	
	/** The product is not a vehicle mock. */
	private Product productIsNotAVehicleMock;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		itemServiceMock = mock(ItemService.class);

		itemAction = new ItemAction();
		itemAction.setItemService(itemServiceMock);

		productIsAVehicleMock = mock(Product.class);
		when(productIsAVehicleMock.getInsuranceAdditionalDriverLicenseRequired()).thenReturn(true);

		productIsNotAVehicleMock = mock(Product.class);
		when(productIsNotAVehicleMock.getInsuranceAdditionalDriverLicenseRequired()).thenReturn(false);
	}

	/**
	 * Should create new item.
	 */
	@Test
	public void shouldCreateNewItem() {
		when(itemServiceMock.createNewItem()).thenReturn(new Item());
		final Item item = itemAction.createNewItem();
		assertNotNull(item);
	}

    @Test
    public void shouldReturnSuccessIfEverythingGoesFimeWhileGeneratingItemSerialNumber() {
        final Item mockItem = mock(Item.class);
        when(mockItem.getProduct()).thenReturn(productIsAVehicleMock);

        final RequestContext requestContext = getMockedRequestContext();

        assertEquals("success", itemAction.generateItemSerialNumber(mockItem, requestContext).getId());
    }

    @Test
    public void shouldPopulateErrorWhileGeneratingItemSerialNumberIfNumberOfRentalItemsIsAlreadyEqualToItemCountInKiosk() {
        final Item item = mock(Item.class);
        when(itemServiceMock.isNewItemCreationNotPossible(item)).thenReturn(true);

        final RequestContext requestContext = getMockedRequestContext();

        itemAction.generateItemSerialNumber(item, requestContext);

        verify(requestContext.getFlashScope()).put("maxItemsAlreadyCreated", true);
    }

    @Test
    public void shouldReturnErrorIfWhileGeneratingItemSerialNumberIfNumberOfRentalItemsIsAlreadyEqualToItemCountInKiosk() {
        final Item item = mock(Item.class);
        when(itemServiceMock.isNewItemCreationNotPossible(item)).thenReturn(true);

        assertEquals("error", itemAction.generateItemSerialNumber(item, getMockedRequestContext()).getId());
    }

    
	/**
	 * Generate item serial number for a vehicle product.
	 */
	@Test
	public void generateItemSerialNumberForAVehicleProduct() {
		final Item mockItem = mock(Item.class);
		when(mockItem.getProduct()).thenReturn(productIsAVehicleMock);

		final RequestContext requestContext = getMockedRequestContext();

		itemAction.generateItemSerialNumber(mockItem, requestContext);

		verify(requestContext.getFlashScope()).put("isVehicle", true);
		verify(mockItem).generateSerialNumber();
	}

	/**
	 * Generate item serial number for a product which is note vehicle.
	 */
	@Test
	public void generateItemSerialNumberForAProductWhichIsNoteVehicle() {
		final Item mockItem = mock(Item.class);
		when(mockItem.getProduct()).thenReturn(productIsNotAVehicleMock);

		final RequestContext requestContext = getMockedRequestContext();

		itemAction.generateItemSerialNumber(mockItem, requestContext);

		verify(requestContext.getFlashScope()).put("isVehicle", false);
		verify(mockItem).generateSerialNumber();
	}

    /**
     * Save item persists item for vehicle product.
     */
    @Test
    public void shouldSyncInventoryAfterSavingTheItem() {
        final Item item = mock(Item.class);
        final Product product = mock(Product.class);
        when(item.getProduct()).thenReturn(product);
        itemAction.saveItem(item, getMockedRequestContext());

        verify(itemServiceMock).syncItemInventory(item.getProduct());
    }

    /**
     * Save item persists item for vehicle product.
     */
    @Test
    public void shouldSaveTheItemUsingTheItemService() {
        final Item item = mock(Item.class);
        itemAction.saveItem(item, getMockedRequestContext());

        verify(itemServiceMock).saveItem(item);
    }

    @Test
    public void shouldSyncTheInventoryAfterItemIsSaved() {
        final Item item = mock(Item.class);
        itemAction.saveItem(item, getMockedRequestContext());

        final InOrder order = Mockito.inOrder(itemServiceMock);
        order.verify(itemServiceMock).saveItem(item);
        order.verify(itemServiceMock).syncItemInventory(item.getProduct());
    }

    @Test
    public void shouldReturnSuccessIfSyncInventoryIsSuccessful() {
        final Item item = mock(Item.class);
        when(itemServiceMock.syncItemInventory(item.getProduct())).thenReturn(true);
        assertEquals("success", itemAction.saveItem(item, getMockedRequestContext()).getId());
    }

    @Test
    public void shouldReturnErrorIfSyncInventoryFails() {
        final Item item = mock(Item.class);
        when(itemServiceMock.syncItemInventory(item.getProduct())).thenReturn(false);
        final RequestContext requestContext = getMockedRequestContext();
        assertEquals("error", itemAction.saveItem(item, requestContext).getId());
        verify(requestContext.getFlashScope()).put(Constants.Agreement.KIOSK_ERROR, true);
    }

    @Test
    public void shouldSyncInventoryForTheGivenProduct() {
        final Product product = mock(Product.class);
        mockStatic(Product.class);
        when(Product.findProduct(1233L)).thenReturn(product);

        itemAction.syncInventory(1233L, getMockedRequestContext());

        verify(itemServiceMock).syncItemInventory(product);
    }

    @Test
    public void shouldPopulateSuccessInTheResponseIfSyncInventorySucceeds() {
        final Product product = mock(Product.class);
        mockStatic(Product.class);
        when(Product.findProduct(1233L)).thenReturn(product);

        when(itemServiceMock.syncItemInventory(product)).thenReturn(true);

        final RequestContext requestContext = getMockedRequestContext();
        itemAction.syncInventory(1233L, requestContext);

        verify(requestContext.getFlashScope()).put("syncInventorySuccessful", true);
    }

    @Test
    public void shouldPopulateErrorInTheResponseIfSyncInventoryFails() {
        final Product product = mock(Product.class);
        mockStatic(Product.class);
        when(Product.findProduct(1233L)).thenReturn(product);

        when(itemServiceMock.syncItemInventory(product)).thenReturn(false);

        final RequestContext requestContext = getMockedRequestContext();
        itemAction.syncInventory(1233L, requestContext);

        verify(requestContext.getFlashScope()).put("syncInventoryError", true);
    }

	/**
	 * Gets the mocked request context.
	 *
	 * @return the mocked request context
	 */
	private RequestContext getMockedRequestContext() {
		final RequestContext requestContext = mock(RequestContext.class);
		final MutableAttributeMap mockedViewScope = mock(MutableAttributeMap.class);
		final MutableAttributeMap mockedFlashScope = mock(MutableAttributeMap.class);
		when(requestContext.getViewScope()).thenReturn(mockedViewScope);
		when(requestContext.getFlashScope()).thenReturn(mockedFlashScope);
		return requestContext;
	}

}
