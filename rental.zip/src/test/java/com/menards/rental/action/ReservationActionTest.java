/*
 * ReservationActionTest.java
 */
package com.menards.rental.action;

import static junit.framework.Assert.*;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.*;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.expectReturn;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.playback;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.mock.staticmock.MockStaticEntityMethods;
import org.springframework.webflow.core.collection.MutableAttributeMap;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.menards.rental.builder.GuestBuilder;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.Guest;
import com.menards.rental.domain.Item;
import com.menards.rental.domain.Product;
import com.menards.rental.domain.Reservation;
import com.menards.rental.domain.ReservationAgreement;
import com.menards.rental.domain.Store;
import com.menards.rental.domain.StoreUserInfo;
import com.menards.rental.service.MenardsService;
import com.menards.rental.service.NotificationService;
import com.menards.rental.service.ReservationService;
import com.menards.rental.service.external.TeamService;
import com.menards.rental.utils.Constants;

/**
 * User: deep Date: 21 Jul, 2010 Time: 1:42:31 PM.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest( { Product.class, ReservationAgreement.class, Item.class })
@MockStaticEntityMethods
public class ReservationActionTest {
	
	/** The reservation action. */
	private ReservationAction reservationAction;
	
	/** The mocked reservation service. */
	private ReservationService mockedReservationService;
	
	/** The mocked Team service. */
	private TeamService mockedTeamService;
	
	/** The mocked agreement action. */
	private AgreementAction mockedAgreementAction;
	
	/** The mocked menards service. */
	private MenardsService mockedMenardsService;
    private NotificationService notificationService;

    /**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		reservationAction = new ReservationAction();
		mockedReservationService = mock(ReservationService.class);
		mockedTeamService = mock(TeamService.class);
		mockedAgreementAction = mock(AgreementAction.class);
		mockedMenardsService = mock(MenardsService.class);

		reservationAction.setReservationService(mockedReservationService);
		reservationAction.setTeamService(mockedTeamService);
		reservationAction.setAgreementAction(mockedAgreementAction);
		reservationAction.setMenardsService(mockedMenardsService);
        notificationService = mock(NotificationService.class);
        reservationAction.setNotificationService(notificationService);
	}

	/**
	 * Should call the reservation service to create a new reservation agreement.
	 */
	@Test
	public void shouldCallTheReservationServiceToCreateANewReservationAgreement() {
		final ReservationAgreement expectedReservationAgreement = new ReservationAgreement();
		when(mockedReservationService.createReservationAgreement()).thenReturn(expectedReservationAgreement);

		assertSame(expectedReservationAgreement, reservationAction.createReservationAgreement());
	}

	/**
	 * Should populate check inventory lookups.
	 */
	@Test
	public void shouldPopulateCheckInventoryLookups() {
		final List<Product> expectedProducts = new ArrayList<Product>();
		Product.findAllProducts();
		expectReturn(expectedProducts);
		playback();

		assertSame(expectedProducts, reservationAction.getAllProducts());
	}

	/**
	 * Should get populate all active items in the request scope for the given product.
	 */
	@Test
	public void shouldGetPopulateAllActiveItemsInTheRequestScopeForTheGivenProduct() {
		final Product product = mock(Product.class);
		final List<Item> expectedItems = new ArrayList<Item>();

		Product.findProduct(7866L);
		expectReturn(product);
		Item.findAllItemsByProductAndStoreNumber(product, 1233);
		expectReturn(expectedItems);
		playback();

		final ReservationAgreement mockedAgreement = mock(ReservationAgreement.class);
		when(mockedAgreement.getStoreNumber()).thenReturn(1233);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		reservationAction.populateActiveItemAndReservationsFor(7866L, mockedAgreement, mockedRequestContext);

		verify(mockedRequestContext.getViewScope()).put("itemList", expectedItems);
	}

	/**
	 * Should populate all reservations for the given product in the flash scope.
	 */
	@Test
	public void shouldPopulateAllReservationsForTheGivenProductInTheFlashScope() {
		final Product product = mock(Product.class);
		final List<Item> expectedItems = new ArrayList<Item>();

		Product.findProduct(7866L);
		expectReturn(product);
		Item.findAllItemsByProductAndStoreNumber(product, 1233);
		expectReturn(expectedItems);
		playback();
		playback();

		final ReservationAgreement mockedAgreement = mock(ReservationAgreement.class);
		when(mockedAgreement.getStoreNumber()).thenReturn(1233);

		final List<Reservation> expectedReservations = new ArrayList<Reservation>();
		when(product.getOpenReservationsFor(1233)).thenReturn(expectedReservations);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		reservationAction.populateActiveItemAndReservationsFor(7866L, mockedAgreement, mockedRequestContext);

		verify(mockedRequestContext.getViewScope()).put("reservationList", expectedReservations);
	}

	/**
	 * Should create new reservation using the reservation service.
	 */
	@Test
	public void shouldCreateNewReservationUsingTheReservationService() {
		final Reservation expectedReservation = new Reservation();
		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);

		final Product product = new Product();
		Product.findProduct(1233L);
		expectReturn(product);
		playback();

        mockStatic(Item.class);
        when(Item.countRentableItemsByProductAndStoreNumber(Matchers.<Product>anyObject(), anyInt())).thenReturn(2L);

		when(mockedReservationService.createReservation(product, reservationAgreement)).thenReturn(expectedReservation);

		assertSame(expectedReservation, reservationAction.createReservation(1233, reservationAgreement,
		        getMockedRequestContext()));
	}

    @Test
    public void shouldPopulateErrorInTheFlashScopeIfReservationServiceFails() {
        final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);

        final Product product = new Product();
        Product.findProduct(1233L);
        expectReturn(product);
        playback();

        mockStatic(Item.class);
        when(Item.countRentableItemsByProductAndStoreNumber(Matchers.<Product>anyObject(), anyInt())).thenReturn(2L);

        when(mockedReservationService.createReservation(product, reservationAgreement)).thenReturn(null);

        final RequestContext requestContext = getMockedRequestContext();
        reservationAction.createReservation(1233, reservationAgreement,
                requestContext);
        verify(requestContext.getFlashScope()).put("kioskError", true);
    }

	/**
	 * Should populate error if a reservation already exist for the choosen product.
	 */
	@Test
	public void shouldPopulateErrorIfAReservationAlreadyExistForTheChoosenProduct() {
		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);

		final Product product = new Product();

		mockStatic(Product.class);
		when(Product.findProduct(1233L)).thenReturn(product);

		when(reservationAgreement.isReservationPresentFor(product)).thenReturn(true);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		reservationAction.createReservation(1233L, reservationAgreement, mockedRequestContext);

		verify(mockedRequestContext.getFlashScope()).put("alreadyReserved", true);
	}

	@Test
	public void shouldPopulateErrorIfRentableItemCountForTheProductForTheStoreIsZero() {
		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
        when(reservationAgreement.getStoreNumber()).thenReturn(7866);

		final Product product = new Product();

		mockStatic(Product.class);
		when(Product.findProduct(1233L)).thenReturn(product);

        mockStatic(Item.class);
        when(Item.countRentableItemsByProductAndStoreNumber(product, 7866)).thenReturn(0L);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		reservationAction.createReservation(1233L, reservationAgreement, mockedRequestContext);

		verify(mockedRequestContext.getFlashScope()).put("rentableItemsNotFound", true);
	}

	/**
	 * Should return error if a reservation already exist for the choosen product.
	 */
	@Test
	public void shouldReturnErrorIfAReservationAlreadyExistForTheChoosenProduct() {
		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);

		final Product product = new Product();

		mockStatic(Product.class);
		when(Product.findProduct(1233L)).thenReturn(product);

		when(reservationAgreement.isReservationPresentFor(product)).thenReturn(true);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		assertNull(reservationAction.createReservation(1233L, reservationAgreement, mockedRequestContext));
	}

	/**
	 * Should remove the reservation from the view scope.
	 */
	@Test
	public void shouldRemoveTheReservationFromTheViewScope() {
		final RequestContext mockedRequestContext = getMockedRequestContext();
        when(mockedRequestContext.getFlowScope().get("reservationAgreement")).thenReturn(new ReservationAgreement());
		reservationAction.removeTemporaryReservation(mockedRequestContext);

		verify(mockedRequestContext.getViewScope()).remove("reservation");
	}

    @Test
    public void shouldRemoveTheReservationFromTheReservationAgreementAsWell() {
        final RequestContext mockedRequestContext = getMockedRequestContext();
        final ReservationAgreement agreement = new ReservationAgreement();
        when(mockedRequestContext.getFlowScope().get("reservationAgreement")).thenReturn(agreement);
        final Reservation reservation = new Reservation();
        agreement.addReservation(reservation);
        when(mockedRequestContext.getViewScope().remove("reservation")).thenReturn(reservation);

        assertFalse(agreement.getReservations().isEmpty());

        reservationAction.removeTemporaryReservation(mockedRequestContext);

        assertTrue(agreement.getReservations().isEmpty());
    }

	/**
	 * Should populate conflicting reservations in the flash scope if reservation is not possible right now.
	 */
	@Test
	public void shouldPopulateConflictingReservationsInTheFlashScopeIfReservationIsNotPossibleRightNow() {
		final Reservation reservation = new Reservation();

		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

		reservation.setCheckOutTimeStamp(outDate);
		reservation.setCheckInTimeStamp(inDate);

		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
		when(reservationAgreement.getStoreNumber()).thenReturn(1233);

		final Product mockedProduct = getMockedProduct(reservation);

		when(mockedReservationService.isReservationPossible(mockedProduct, reservation, reservationAgreement)).thenReturn(
		        false);

		final List<Reservation> expectedReservations = new ArrayList<Reservation>();
		when(mockedProduct.getOverlappingOpenReservationsForStore(1233, outDate, inDate)).thenReturn(expectedReservations);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		reservationAction.reserveProduct(reservation, reservationAgreement, mockedRequestContext);

		verify(mockedRequestContext.getFlashScope()).put("conflictingReservations", expectedReservations);
	}

	/**
	 * Should return error if reservation is not possible right now.
	 */
	@Test
	public void shouldReturnErrorIfReservationIsNotPossibleRightNow() {
		final Reservation reservation = new Reservation();

		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

		reservation.setCheckOutTimeStamp(outDate);
		reservation.setCheckInTimeStamp(inDate);

		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
		when(reservationAgreement.getStoreNumber()).thenReturn(1233);

		final Product mockedProduct = getMockedProduct(reservation);

		when(mockedReservationService.isReservationPossible(mockedProduct, reservation, reservationAgreement)).thenReturn(
		        false);

		final List<Reservation> expectedReservations = new ArrayList<Reservation>();
		when(mockedProduct.getOverlappingOpenReservationsForStore(1233, outDate, inDate)).thenReturn(expectedReservations);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		assertEquals("error", reservationAction.reserveProduct(reservation, reservationAgreement, mockedRequestContext)
		        .getId());
	}

	/**
	 * Should add the reservation to reservation agreement.
	 */
	@Test
	public void shouldAddTheReservationToReservationAgreement() {
		final Reservation reservation = new Reservation();

		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

		reservation.setCheckOutTimeStamp(outDate);
		reservation.setCheckInTimeStamp(inDate);

		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
		when(reservationAgreement.getStoreNumber()).thenReturn(1233);

		final Product mockedProduct = getMockedProduct(reservation);

		when(mockedReservationService.isReservationPossible(mockedProduct, reservation, reservationAgreement)).thenReturn(
		        true);

		final List<Reservation> expectedReservations = new ArrayList<Reservation>();
		when(mockedProduct.getOverlappingOpenReservationsForStore(1233, outDate, inDate)).thenReturn(expectedReservations);

		reservationAction.reserveProduct(reservation, reservationAgreement, getMockedRequestContext());

		verify(reservationAgreement).addReservation(reservation);
	}

	/**
	 * Should add the reservation to reservation agreement.
	 */
	@Test
	public void shouldCalculateEstimatedChargesAndDuration() {
		final Reservation reservation = new Reservation();

		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

		reservation.setCheckOutTimeStamp(outDate);
		reservation.setCheckInTimeStamp(inDate);

		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
		when(reservationAgreement.getStoreNumber()).thenReturn(1233);

		final Product mockedProduct = getMockedProduct(reservation);

		when(mockedReservationService.isReservationPossible(mockedProduct, reservation, reservationAgreement)).thenReturn(
		        true);

		final List<Reservation> expectedReservations = new ArrayList<Reservation>();
		when(mockedProduct.getOverlappingOpenReservationsForStore(1233, outDate, inDate)).thenReturn(expectedReservations);

		reservationAction.reserveProduct(reservation, reservationAgreement, getMockedRequestContext());

		verify(mockedReservationService).calculateEstimatedChargesAndDuration(reservation);
	}

	/**
	 * Should return success if reservation is possible.
	 */
	@Test
	public void shouldReturnSuccessIfReservationIsPossible() {
		final Reservation reservation = new Reservation();

		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

		reservation.setCheckOutTimeStamp(outDate);
		reservation.setCheckInTimeStamp(inDate);

		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
		when(reservationAgreement.getStoreNumber()).thenReturn(1233);

		final Product mockedProduct = getMockedProduct(reservation);

		when(mockedReservationService.isReservationPossible(mockedProduct, reservation, reservationAgreement)).thenReturn(
		        true);

		final List<Reservation> expectedReservations = new ArrayList<Reservation>();
		when(mockedProduct.getOverlappingOpenReservationsForStore(1233, outDate, inDate)).thenReturn(expectedReservations);

		assertEquals("success", reservationAction.reserveProduct(reservation, reservationAgreement,
		        getMockedRequestContext()).getId());
	}

	/**
	 * Gets the mocked request context.
	 *
	 * @return the mocked request context
	 */
	private RequestContext getMockedRequestContext() {
		final RequestContext mockedRequestContext = mock(RequestContext.class);
		final MutableAttributeMap attr1 = mock(MutableAttributeMap.class);
		when(mockedRequestContext.getRequestScope()).thenReturn(attr1);
		final MutableAttributeMap attr2 = mock(MutableAttributeMap.class);
		when(mockedRequestContext.getViewScope()).thenReturn(attr2);
		final MutableAttributeMap attr3 = mock(MutableAttributeMap.class);
		when(mockedRequestContext.getFlashScope()).thenReturn(attr3);
		final MutableAttributeMap attr4 = mock(MutableAttributeMap.class);
		when(mockedRequestContext.getFlowScope()).thenReturn(attr4);
		return mockedRequestContext;
	}

	/**
	 * Should return all the managers.
	 */
	@Test
	public void shouldReturnAllTheManagers() {
		final List<StoreUserInfo> expectedManagerNames = new ArrayList<StoreUserInfo>();
		when(mockedTeamService.getGeneralManagerForCurrentStore()).thenReturn(expectedManagerNames);

		assertSame(expectedManagerNames, reservationAction.getAllManagers());
	}

    /**
	 * Should remove the reservation with the given id from the reservation agreement.
	 */
	@Test
	public void shouldRemoveTheReservationWithTheGivenIdFromTheReservationAgreement() {
		final ReservationAgreement mockedReservationAgreement = mock(ReservationAgreement.class);
		reservationAction.removeReservationFor(mockedReservationAgreement, 1233L);

		verify(mockedReservationAgreement).removeReservationFor(1233L);
	}

	/**
	 * Should return error if reservation agreement has no reservations.
	 */
	@Test
	public void shouldReturnErrorIfReservationAgreementHasNoReservations() {
		final ReservationAgreement agreement = mock(ReservationAgreement.class);

		assertEquals(agreement, reservationAction.save(agreement, getMockedRequestContext()));
	}

	/**
	 * Should return error in the flash scope if reservation agreement has no reservations.
	 */
	@Test
	public void shouldReturnErrorInTheFlashScopeIfReservationAgreementHasNoReservations() {
		final ReservationAgreement agreement = mock(ReservationAgreement.class);

		final RequestContext context = getMockedRequestContext();
		reservationAction.save(agreement, context);

		verify(context.getFlashScope()).put("noReservationsFound", true);
	}

	/**
	 * Should save the reservation if reservation agreement via service.
	 */
	@Test
	public void shouldSaveTheReservationIfReservationAgreementViaService() {
		final ReservationAgreement agreement = mock(ReservationAgreement.class);
		when(agreement.hasReservations()).thenReturn(true);

		mockStatic(ReservationAgreement.class);
		reservationAction.save(agreement, getMockedRequestContext());

		verify(mockedReservationService).save(agreement);
	}

	@Test
	public void shouldPopulateErrorInTheFlashScopeIfWhileSavingTheReservationServiceFails() {
		final ReservationAgreement agreement = mock(ReservationAgreement.class);
		when(agreement.hasReservations()).thenReturn(true);
        doThrow(new RuntimeException()).when(mockedReservationService).save(Matchers.<ReservationAgreement>anyObject());

        final RequestContext requestContext = getMockedRequestContext();

        assertSame(agreement, reservationAction.save(agreement, requestContext));

        verify(requestContext.getFlashScope()).put("couldNotSaveReservation", true);
        verify(notificationService, never()).sendReservationNotificationFor(Matchers.<ReservationAgreement>anyObject());
	}

	/**
	 * Should return error if reservation agreement has no reservations.
	 */
	@Test
	public void shouldReturnErrorIfReservationAgreementHasNoReservationsWhileSavingNotes() {
		final ReservationAgreement agreement = mock(ReservationAgreement.class);

		assertEquals(agreement, reservationAction.saveNotes(agreement, getMockedRequestContext()));
	}

	/**
	 * Should return error in the flash scope if reservation agreement has no reservations.
	 */
	@Test
	public void shouldReturnErrorInTheFlashScopeIfReservationAgreementHasNoReservationsWhileSavingNotes() {
		final ReservationAgreement agreement = mock(ReservationAgreement.class);

		final RequestContext context = getMockedRequestContext();
		reservationAction.saveNotes(agreement, context);

		verify(context.getFlashScope()).put("noReservationsFound", true);
	}

	/**
	 * Should save the reservation if reservation agreement via service.
	 */
	@Test
	public void shouldSaveTheReservationIfReservationAgreementViaServiceWhileSavingNotes() {
		final ReservationAgreement agreement = mock(ReservationAgreement.class);
		when(agreement.hasReservations()).thenReturn(true);

		mockStatic(ReservationAgreement.class);
		reservationAction.saveNotes(agreement, getMockedRequestContext());

		verify(mockedReservationService).save(agreement);
	}

	@Test
	public void shouldPopulateErrorInTheFlashScopeIfWhileSavingTheReservationServiceFailsWhileSavingNotes() {
		final ReservationAgreement agreement = mock(ReservationAgreement.class);
		when(agreement.hasReservations()).thenReturn(true);
        doThrow(new RuntimeException()).when(mockedReservationService).save(Matchers.<ReservationAgreement>anyObject());

        final RequestContext requestContext = getMockedRequestContext();

        assertSame(agreement, reservationAction.saveNotes(agreement, requestContext));

        verify(requestContext.getFlashScope()).put("couldNotSaveReservation", true);
	}

	/**
	 * Should save the reservation if reservation agreement via service.
	 */
	@Test
	public void shouldNotifyTheGuestAboutTheReservation() {
		final ReservationAgreement agreement = mock(ReservationAgreement.class);
		when(agreement.hasReservations()).thenReturn(true);

		mockStatic(ReservationAgreement.class);
		reservationAction.save(agreement, getMockedRequestContext());

		verify(notificationService).sendReservationNotificationFor(agreement);
	}

	/**
	 * Should find the updated reservation agreement and return that to the caller.
	 */
	@Test
	public void shouldFindTheUpdatedReservationAgreementAndReturnThatToTheCaller() {
		final ReservationAgreement expectedAgreement = new ReservationAgreement();

		final ReservationAgreement agreement = mock(ReservationAgreement.class);
		when(agreement.hasReservations()).thenReturn(true);
		when(agreement.getId()).thenReturn(1233L);

		mockStatic(ReservationAgreement.class);
		when(ReservationAgreement.loadFull(1233L)).thenReturn(expectedAgreement);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		assertSame(expectedAgreement, reservationAction.save(agreement, mockedRequestContext));
	}

	@Test
	public void shouldFindTheUpdatedReservationAgreementAndReturnThatToTheCallerWhileSavingNotes() {
		final ReservationAgreement expectedAgreement = new ReservationAgreement();

		final ReservationAgreement agreement = mock(ReservationAgreement.class);
		when(agreement.hasReservations()).thenReturn(true);
		when(agreement.getId()).thenReturn(1233L);

		mockStatic(ReservationAgreement.class);
		when(ReservationAgreement.loadFull(1233L)).thenReturn(expectedAgreement);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		assertSame(expectedAgreement, reservationAction.saveNotes(agreement, mockedRequestContext));
	}

	/**
	 * Should load the reservation agreement.
	 */
	@Test
	public void shouldLoadTheReservationAgreement() {
		final ReservationAgreement agreement = new ReservationAgreement();
		mockStatic(ReservationAgreement.class);
		when(ReservationAgreement.loadFull(1233L)).thenReturn(agreement);

		assertSame(agreement, reservationAction.loadReservationAgreement(1233));
	}

	/**
	 * Should return the agreement item.
	 */
	@Test
	public void shouldReturnTheAgreementItem() {
		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
		final Reservation reservation = mock(Reservation.class);
		when(reservationAgreement.findReservationById(1233L)).thenReturn(reservation);

		final Agreement agreement = mock(Agreement.class);
		final RequestContext mockedRequestContext = getMockedRequestContext();

		final AgreementItem agreementItem = new AgreementItem();
		when(mockedAgreementAction.getRentalItemToAdd(agreement, 7866L, mockedRequestContext)).thenReturn(agreementItem);
		when(reservation.isForSameProduct(agreementItem)).thenReturn(true);

		assertSame(agreementItem, reservationAction.getRentalItemToEdit(agreement, reservationAgreement, 7866L, 1233L,
		        mockedRequestContext));
	}

	/**
	 * Should return null the agreement item is not for the same product as the reservation.
	 */
	@Test
	public void shouldReturnNullTheAgreementItemIsNotForTheSameProductAsTheReservation() {
		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
		final Reservation reservation = mock(Reservation.class);
		when(reservationAgreement.findReservationById(1233L)).thenReturn(reservation);

		final Agreement agreement = mock(Agreement.class);
		final RequestContext mockedRequestContext = getMockedRequestContext();

		final AgreementItem agreementItem = new AgreementItem();
		when(mockedAgreementAction.getRentalItemToAdd(agreement, 7866L, mockedRequestContext)).thenReturn(agreementItem);
		when(reservation.isForSameProduct(agreementItem)).thenReturn(false);

		assertNull(reservationAction
		        .getRentalItemToEdit(agreement, reservationAgreement, 7866L, 1233L, mockedRequestContext));
	}

	/**
	 * Should not start pocessing the reservation if agreement item was not for the same product.
	 */
	@Test
	public void shouldNotStartPocessingTheReservationIfAgreementItemWasNotForTheSameProduct() {
		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
		final Reservation reservation = mock(Reservation.class);
		when(reservationAgreement.findReservationById(1233L)).thenReturn(reservation);

		final Agreement agreement = mock(Agreement.class);
		final RequestContext mockedRequestContext = getMockedRequestContext();

		final AgreementItem agreementItem = new AgreementItem();
		when(mockedAgreementAction.getRentalItemToAdd(agreement, 7866L, mockedRequestContext)).thenReturn(agreementItem);
		when(reservation.isForSameProduct(agreementItem)).thenReturn(false);

		reservationAction.getRentalItemToEdit(agreement, reservationAgreement, 7866L, 1233L, mockedRequestContext);

		verify(reservation, never()).prepareAgreementItem(agreementItem);
	}

	/**
	 * Should populate the error message in the request context.
	 */
	@Test
	public void shouldPopulateTheErrorMessageInTheRequestContext() {
		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
		final Reservation reservation = mock(Reservation.class);
		when(reservationAgreement.findReservationById(1233L)).thenReturn(reservation);

		final Agreement agreement = mock(Agreement.class);
		final RequestContext mockedRequestContext = getMockedRequestContext();

		final AgreementItem agreementItem = new AgreementItem();
		when(mockedAgreementAction.getRentalItemToAdd(agreement, 7866L, mockedRequestContext)).thenReturn(agreementItem);
		when(reservation.isForSameProduct(agreementItem)).thenReturn(false);

		reservationAction.getRentalItemToEdit(agreement, reservationAgreement, 7866L, 1233L, mockedRequestContext);

		verify(mockedRequestContext.getFlashScope()).put("itemStatus", "invalidItemReservationCombination");
	}

	/**
	 * Should copy checkin date to the agreement item.
	 */
	@Test
	public void shouldCopyCheckinDateToTheAgreementItem() {
		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
		final Reservation reservation = mock(Reservation.class);

		when(reservationAgreement.findReservationById(1233L)).thenReturn(reservation);

		final Agreement agreement = mock(Agreement.class);
		final RequestContext mockedRequestContext = getMockedRequestContext();

		final AgreementItem agreementItem = new AgreementItem();
		when(mockedAgreementAction.getRentalItemToAdd(agreement, 7866L, mockedRequestContext)).thenReturn(agreementItem);
		when(reservation.isForSameProduct(agreementItem)).thenReturn(true);

		reservationAction.getRentalItemToEdit(agreement, reservationAgreement, 7866L, 1233L, mockedRequestContext);

		verify(reservation).prepareAgreementItem(agreementItem);
	}

	/**
	 * Should return event after agreement action adds the agreement item to the agreement.
	 */
	@Test
	public void shouldReturnEventAfterAgreementActionAddsTheAgreementItemToTheAgreement() {
		final Event expectedEvent = new Event(this, "error");
		final Agreement agreement = mock(Agreement.class);
		final AgreementItem agreementItem = mock(AgreementItem.class);
		final RequestContext requestContext = getMockedRequestContext();
		when(mockedAgreementAction.addAgreementItemToAgreement(agreement, agreementItem, requestContext)).thenReturn(
		        expectedEvent);

		assertSame(expectedEvent, reservationAction.addAgreementItemToAgreement(agreement, agreementItem,
		        mock(ReservationAgreement.class), 1233L, requestContext));
	}

	/**
	 * Should find the reservation with the given id and start processing it.
	 */
	@Test
	public void shouldFindTheReservationWithTheGivenIdAndStartProcessingIt() {
		final Event expectedEvent = new Event(this, "success");
		final Agreement agreement = mock(Agreement.class);
		final AgreementItem agreementItem = mock(AgreementItem.class);
		final RequestContext requestContext = getMockedRequestContext();
		when(mockedAgreementAction.addAgreementItemToAgreement(agreement, agreementItem, requestContext)).thenReturn(
		        expectedEvent);

		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
		final Reservation reservation = mock(Reservation.class);
		when(reservationAgreement.findReservationById(1233L)).thenReturn(reservation);

		reservationAction.addAgreementItemToAgreement(agreement, agreementItem, reservationAgreement, 1233L, requestContext);

		verify(reservation).startProcessing();
	}

	/**
	 * Should not start processing the reservation if success was not returned.
	 */
	@Test
	public void shouldNotStartProcessingTheReservationIfSuccessWasNotReturned() {
		final Event expectedEvent = new Event(this, "error");
		final Agreement agreement = mock(Agreement.class);
		final AgreementItem agreementItem = mock(AgreementItem.class);
		final RequestContext requestContext = getMockedRequestContext();
		when(mockedAgreementAction.addAgreementItemToAgreement(agreement, agreementItem, requestContext)).thenReturn(
		        expectedEvent);

		final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
		final Reservation reservation = mock(Reservation.class);
		when(reservationAgreement.findReservationById(1233L)).thenReturn(reservation);

		reservationAction.addAgreementItemToAgreement(agreement, agreementItem, reservationAgreement, 1233L, requestContext);

		verify(reservation, never()).startProcessing();
	}

	/**
	 * Should create a new guest if guest is null in the agreement.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCreateANewGuestIfGuestIsNullInTheAgreement() throws Exception {
		final Agreement agreement = new Agreement();
		final ReservationAgreement reservationAgreement = new ReservationAgreement();
		reservationAgreement.setGuest(new Guest());

		reservationAction.copyGuestInfo(agreement, reservationAgreement);

		assertNotNull(agreement.getGuest());
	}

	/**
	 * Should not do anything if agreement already has a not null guest.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldNotDoAnythingIfAgreementAlreadyHasANotNullGuest() throws Exception {
		final Agreement agreement = new Agreement();
		final Guest expectedGuest = new Guest();
		agreement.setGuest(expectedGuest);
		final ReservationAgreement reservationAgreement = new ReservationAgreement();
		reservationAgreement.setGuest(new Guest());

		reservationAction.copyGuestInfo(agreement, reservationAgreement);

		assertSame(expectedGuest, agreement.getGuest());
	}

	/**
	 * Should copy the guest information if guest is null in the agreement.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCopyTheGuestInformationIfGuestIsNullInTheAgreement() throws Exception {
		final Agreement agreement = new Agreement();
		final ReservationAgreement reservationAgreement = new ReservationAgreement();
		reservationAgreement.setGuest(new GuestBuilder().withFirstName("Hello").withLastName("World").buildGuest());

		reservationAction.copyGuestInfo(agreement, reservationAgreement);

		assertEquals("Hello", agreement.getGuest().getFirstName());
		assertEquals("World", agreement.getGuest().getLastName());
	}

	/**
	 * Should fulfill reservations.
	 */
	@Test
	public void shouldFulfillReservations() {
		final Agreement mockedAgreement = mock(Agreement.class);
		final ReservationAgreement mockedReservationAgreement = mock(ReservationAgreement.class);
		reservationAction.fulfillReservation(mockedAgreement, mockedReservationAgreement);

		verify(mockedAgreement).fulfillReservations();
	}

	/**
	 * Should fulfill reservation agreement if possible.
	 */
	@Test
	public void shouldFulfillReservationAgreementIfPossible() {
		final Agreement mockedAgreement = mock(Agreement.class);
		final ReservationAgreement mockedReservationAgreement = mock(ReservationAgreement.class);
		reservationAction.fulfillReservation(mockedAgreement, mockedReservationAgreement);

		verify(mockedReservationAgreement).fulfillIfAllReservationsFulfilledOrCancelled();
	}

	/**
	 * Should merge the reservation agreement.
	 */
	@Test
	public void shouldMergeTheReservationAgreement() {
		final Agreement mockedAgreement = mock(Agreement.class);
		final ReservationAgreement mockedReservationAgreement = mock(ReservationAgreement.class);
		reservationAction.fulfillReservation(mockedAgreement, mockedReservationAgreement);

		verify(mockedReservationAgreement).merge();
	}

	/**
	 * Should get populate all active items in the request scope for the given product by store number.
	 */
	@Test
	public void shouldGetPopulateAllActiveItemsInTheRequestScopeForTheGivenProductByStoreNumber() {
		final Product product = mock(Product.class);
		final List<Item> expectedItems = new ArrayList<Item>();

		Product.findProduct(7866L);
		expectReturn(product);
		Item.findAllItemsByProductAndStoreNumber(product, 1233);
		expectReturn(expectedItems);
		playback();

		final Store store = new Store();
		store.setStoreNumber(1233);

		when(mockedMenardsService.getCurrentStore()).thenReturn(store);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		reservationAction.populateActiveItemAndReservationsByCurrentStore(7866L, mockedRequestContext);

		verify(mockedRequestContext.getViewScope()).put("itemList", expectedItems);
	}

	/**
	 * Should populate all reservations for the given product in the flash scope by store number.
	 */
	@Test
	public void shouldPopulateAllReservationsForTheGivenProductInTheFlashScopeByStoreNumber() {
		final Product product = mock(Product.class);
		final List<Item> expectedItems = new ArrayList<Item>();

		Product.findProduct(7866L);
		expectReturn(product);
		Item.findAllItemsByProductAndStoreNumber(product, 1233);
		expectReturn(expectedItems);
		playback();
		playback();

		final Store store = new Store();
		store.setStoreNumber(1233);

		when(mockedMenardsService.getCurrentStore()).thenReturn(store);

		final List<Reservation> expectedReservations = new ArrayList<Reservation>();
		when(product.getOpenReservationsFor(1233)).thenReturn(expectedReservations);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		reservationAction.populateActiveItemAndReservationsByCurrentStore(7866L, mockedRequestContext);

		verify(mockedRequestContext.getViewScope()).put("reservationList", expectedReservations);
	}

    @Test
    public void shouldPopulateTheTMNameFromTheTMNumber() {
        final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
        reservationAction.populateTMNameFromTMNumber(reservationAgreement);
        verify(mockedReservationService).populateTMNameFromTMNumber(reservationAgreement);
    }
    
    @Test
    public void shouldPopulateErrorInTheRequestContextIfGuestDoesNotMeetTheMinimumAgeRequirement() {
        final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
        final RequestContext requestContext = getMockedRequestContext();
        when(reservationAgreement.isGuestAgeGreaterThanMinimumAge()).thenReturn(false);

        reservationAction.addGuest(reservationAgreement, requestContext);
        verify(requestContext.getFlashScope()).put(Constants.Agreement.MIN_AGE_LIMIT_NOT_MET, true);
    }

    @Test
    public void shouldReturnErrorResponseIfGuestDoesNotMeetTheMinimumAgeRequirement() {
        final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
        final RequestContext requestContext = getMockedRequestContext();
        when(reservationAgreement.isGuestAgeGreaterThanMinimumAge()).thenReturn(false);

        assertEquals("error", reservationAction.addGuest(reservationAgreement, requestContext).getId());
    }

    @Test
    public void shouldNotPopulateErrorInTheRequestContextIfGuestDoesMeetsTheMinimumAgeRequirement() {
        final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
        final RequestContext requestContext = getMockedRequestContext();
        when(reservationAgreement.isGuestAgeGreaterThanMinimumAge()).thenReturn(true);

        reservationAction.addGuest(reservationAgreement, requestContext);
        verify(requestContext.getFlashScope(), never()).put(Constants.Agreement.MIN_AGE_LIMIT_NOT_MET, true);
    }

    @Test
    public void shouldReturnSuccessResponseIfGuestDoesNotMeetTheMinimumAgeRequirement() {
        final ReservationAgreement reservationAgreement = mock(ReservationAgreement.class);
        final RequestContext requestContext = getMockedRequestContext();
        when(reservationAgreement.isGuestAgeGreaterThanMinimumAge()).thenReturn(true);

        assertEquals("success", reservationAction.addGuest(reservationAgreement, requestContext).getId());
    }

	/**
	 * Gets the mocked product.
	 *
	 * @param reservation the reservation
	 * @return the mocked product
	 */
	private Product getMockedProduct(final Reservation reservation) {
		final Product mockedProduct = mock(Product.class);
		final Product product = new Product();
		product.setId(7866L);
		reservation.setProduct(product);

		mockStatic(Product.class);
		when(Product.findProduct(7866L)).thenReturn(mockedProduct);
		return mockedProduct;
	}
}
