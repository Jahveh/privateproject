/*
 * AgreementActionTest.java
 */
package com.menards.rental.action;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.doReturn;
import static org.powermock.api.mockito.PowerMockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.spy;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.webflow.core.collection.MutableAttributeMap;
import org.springframework.webflow.execution.RequestContext;

import com.menards.rental.builder.AgreementBuilder;
import com.menards.rental.builder.AgreementItemBuilder;
import com.menards.rental.builder.ItemBuilder;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.AgreementItemStatus;
import com.menards.rental.domain.Guest;
import com.menards.rental.domain.Item;
import com.menards.rental.domain.OverrideReason;
import com.menards.rental.domain.Product;
import com.menards.rental.domain.Question;
import com.menards.rental.domain.Reservation;
import com.menards.rental.domain.SelectedAgreementItems;
import com.menards.rental.domain.StoreUserInfo;
import com.menards.rental.service.AgreementService;
import com.menards.rental.service.ReservationService;
import com.menards.rental.service.external.TeamService;
import com.menards.rental.utils.Constants;

/**
 * Created by IntelliJ IDEA. User: deep Date: 4 Jun, 2010 Time: 7:08:18 AM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest( { Item.class, Agreement.class, Question.class, AgreementItemStatus.class, OverrideReason.class })
public class AgreementActionTest {
	
	/** The action. */
	private AgreementAction action;

    /** The mocked agreement service. */
	private AgreementService mockedAgreementService;
	
	/** The mocked team service. */
	private TeamService mockedTeamService;
	
	/** The mocked reservation service. */
	private ReservationService mockedReservationService;
	
	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		action = new AgreementAction();
		mockedAgreementService = mock(AgreementService.class);
		mockedTeamService = mock(TeamService.class);
		mockedReservationService = mock(ReservationService.class);

		action.setAgreementService(mockedAgreementService);
		action.setTeamService(mockedTeamService);
		action.setReservationService(mockedReservationService);
	}

	/**
	 * Should return agreement given id.
	 */
	@Test
	public void shouldReturnAgreementGivenId() {
		final Agreement agreement = new Agreement();

		mockStatic(Agreement.class);
		when(Agreement.loadFull(1L)).thenReturn(agreement);
		assertEquals(agreement, action.loadAgreement(1L));
	}

	/**
	 * Gets the null agreement item on serial number being null.
	 */
	@Test
	public void getNullAgreementItemOnSerialNumberBeingNull() {
		final RequestContext requestContext = getMockedRequestContext();
		final Long serialNumber = null;
		final AgreementItem agreementItem = action.getRentalItemToAdd(null, serialNumber, requestContext);
		assertNull(agreementItem);
		verify(requestContext.getFlashScope()).put("itemStatus", "notFound");
	}

	/**
	 * Gets the null agreement item on serial number list being null.
	 */
	@Test
	public void getNullAgreementItemOnSerialNumberListBeingNull() {
		final RequestContext requestContext = getMockedRequestContext();
		final String selectedSerialNumbers = null;
		final SelectedAgreementItems selectedAgreementItems = action.getRentalItemsToAdd(null, selectedSerialNumbers, requestContext);
		assertNull(selectedAgreementItems);
		verify(requestContext.getFlashScope()).put("itemStatus", "itemsNotFound");
	}
	
	/**
	 * Should return null if item with the given serial number is not found.
	 */
	@Test
	public void shouldReturnNullIfItemWithTheGivenSerialNumberIsNotFound() {
		mockStatic(Item.class);

		assertNull(action.getRentalItemToAdd(null, 123L, getMockedRequestContext()));
	}

	/**
	 * Should return null if the selected items with the given serial numbers are not found.
	 */
	@Test
	public void shouldReturnNullIfItemsWithTheGivenSerialNumbersAreNotFound() {
		mockStatic(Item.class);

		assertNull(action.getRentalItemsToAdd(null, "123,112", getMockedRequestContext()));
	}
	
	/**
	 * Should set item status as not found if the item with the given serial number is not found.
	 */
	@Test
	public void shouldSetItemStatusAsNotFoundIfTheItemWithTheGivenSerialNumberIsNotFound() {
		mockStatic(Item.class);

		final RequestContext requestContext = getMockedRequestContext();
		action.getRentalItemToAdd(null, 123L, requestContext);

		verify(requestContext.getFlashScope()).put("itemStatus", "notFound");
	}

	/**
	 * Should set items status as not found if the items with the given serial numbers are not found.
	 */
	@Test
	public void shouldSetItemsStatusAsNotFoundIfTheItemsWithTheGivenSerialNumbersAreNotFound() {
		mockStatic(Item.class);

		final RequestContext requestContext = getMockedRequestContext();
		action.getRentalItemsToAdd(null, "123,112", requestContext);

		verify(requestContext.getFlashScope()).put("itemStatus", "itemsNotFound");
	}
	
	/**
	 * Should set item status as already added if the item with the given serial number is already present in the agreement.
	 */
	@Test
	public void shouldSetItemStatusAsAlreadyAddedIfTheItemWithTheGivenSerialNumberIsAlreadyPresentInTheAgreement() {
		final Item expectedItem = new Item();
		mockStatic(Item.class);
		when(Item.findItemBySerialNumber(1233L)).thenReturn(expectedItem);

		final RequestContext requestContext = getMockedRequestContext();
		final Agreement agreement = mock(Agreement.class);
		when(agreement.isItemPartOfAgreement(expectedItem)).thenReturn(true);

		assertNull(action.getRentalItemToAdd(agreement, 1233L, requestContext));

		verify(requestContext.getFlashScope()).put("itemStatus", "alreadyAdded");
	}

	/**
	 * Should set items status as already added if the items with the given serial numbers are already present in the agreement.
	 */
	@Test
	public void shouldSetItemsStatusAsAlreadyAddedIfTheItemsWithTheGivenSerialNumbersAreAlreadyPresentInTheAgreement() {
		final Item expectedItem = new Item();
		mockStatic(Item.class);
		when(Item.findItemBySerialNumber(1233L)).thenReturn(expectedItem);

		final RequestContext requestContext = getMockedRequestContext();
		final Agreement agreement = mock(Agreement.class);
		when(agreement.isItemPartOfAgreement(expectedItem)).thenReturn(true);

		assertNull(action.getRentalItemsToAdd(agreement, "1233", requestContext));

		verify(requestContext.getFlashScope()).put("itemStatus", "alreadyAdded");
	}
	
	/**
	 * Should set item status as on hold if the item is not available.
	 */
	@Test
	public void shouldSetItemStatusAsOnHoldIfTheItemIsNotAvailable() {
		final Item item = mock(Item.class);
		mockStatic(Item.class);
		when(Item.findItemBySerialNumber(1233L)).thenReturn(item);

		final RequestContext requestContext = getMockedRequestContext();
		final Agreement agreement = mock(Agreement.class);

		assertNull(action.getRentalItemToAdd(agreement, 1233L, requestContext));

		verify(requestContext.getFlashScope()).put("itemStatus", "onHold");
	}

	/**
	 * Should return the item and set item status as found.
	 */
	@Test
	public void shouldReturnTheItemAndSetItemStatusAsFound() {
		final Item item = mock(Item.class);
		mockStatic(Item.class);
		when(Item.findItemBySerialNumber(1233L)).thenReturn(item);

		final RequestContext requestContext = getMockedRequestContext();
		final Agreement agreement = mock(Agreement.class);
		when(item.isAvailable()).thenReturn(true);

		final AgreementItem expectedAgreementItem = new AgreementItem();
		when(mockedAgreementService.createNewAgreementItem(item, agreement)).thenReturn(expectedAgreementItem);
		final AgreementItem agreementItem = action.getRentalItemToAdd(agreement, 1233L, requestContext);
		assertSame(expectedAgreementItem, agreementItem);

		verify(requestContext.getFlashScope()).put("itemStatus", "found");
	}

    @Test
    public void shouldReturnNullIfAgreementItemIsNotCreatedByTheService() {
        final Item item = mock(Item.class);
        mockStatic(Item.class);
        when(Item.findItemBySerialNumber(1233L)).thenReturn(item);

        final RequestContext requestContext = getMockedRequestContext();
        final Agreement agreement = mock(Agreement.class);
        when(item.isAvailable()).thenReturn(true);

        when(mockedAgreementService.createNewAgreementItem(item, agreement)).thenReturn(null);
        assertNull(action.getRentalItemToAdd(agreement, 1233L, requestContext));

        verify(requestContext.getFlashScope()).put("itemStatus", "kioskError");        
    }

	/**
	 * Should return item status as not found if item is not found with the given serial number.
	 */
	@Test
	public void shouldReturnItemStatusAsNotFoundIfItemIsNotFoundWithTheGivenSerialNumber() {
		final AgreementItem agreementItem = new AgreementItemBuilder().withItem(
		        new ItemBuilder().withSerialNumber(1233L).buildItem()).buildAgreementItem();
		mockStatic(Item.class);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		action.addAgreementItemToAgreement(null, agreementItem, mockedRequestContext);

		verify(mockedRequestContext.getFlashScope()).put("itemStatus", "notFound");
	}

	/**
	 * Should return error if item is not found with the given serial number.
	 */
	@Test
	public void shouldReturnErrorIfItemIsNotFoundWithTheGivenSerialNumber() {
		final AgreementItem agreementItem = new AgreementItemBuilder().withItem(
		        new ItemBuilder().withSerialNumber(1233L).buildItem()).buildAgreementItem();
		mockStatic(Item.class);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		assertEquals("error", action.addAgreementItemToAgreement(null, agreementItem, mockedRequestContext).getId());
	}

	/**
	 * Should set the product in the flash scope if item has conflicting reservations.
	 */
	@Test
	public void shouldSetTheProductInTheFlashScopeIfItemHasConflictingReservations() {
		final Calendar expectedDueByDate = Calendar.getInstance();

		mockStatic(Item.class);
		final Item mockedItem = mock(Item.class);
		when(Item.findItemBySerialNumber(7866L)).thenReturn(mockedItem);

		final AgreementItem mockedAgreementItem = mock(AgreementItem.class);
		when(mockedAgreementItem.getSerialNumber()).thenReturn(7866L);
		when(mockedAgreementItem.getDueBy()).thenReturn(expectedDueByDate);

		when(
		        mockedReservationService.hasNoConflictingReservation(eq(mockedItem), Matchers.<Calendar> anyObject(),
		                eq(expectedDueByDate))).thenReturn(false);

		final List<Reservation> expectedConflictingReservations = new ArrayList<Reservation>();
		when(mockedItem.getOverlappingOpenReservationsFor(Matchers.<Calendar> anyObject(), eq(expectedDueByDate)))
		        .thenReturn(expectedConflictingReservations);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		action.addAgreementItemToAgreement(null, mockedAgreementItem, mockedRequestContext);

		verify(mockedRequestContext.getFlashScope()).put("agreementConflictingReservations",
                expectedConflictingReservations);
	}

	/**
	 * Should not bother about conflicting reservation if gm override for the reservation is done.
	 */
	@Test
	public void shouldNotBotherAboutConflictingReservationIfGMOverrideForTheReservationIsDone() {
		final Calendar expectedDueByDate = Calendar.getInstance();

		mockStatic(Item.class);
		mockStatic(AgreementItemStatus.class);
		final Item mockedItem = mock(Item.class);
		when(Item.findItemBySerialNumber(7866L)).thenReturn(mockedItem);
		final Product mockedProduct = mock(Product.class);
		when(mockedItem.getProduct()).thenReturn(mockedProduct);

		final AgreementItem mockedAgreementItem = mock(AgreementItem.class);
		when(mockedAgreementItem.getSerialNumber()).thenReturn(7866L);
		when(mockedAgreementItem.getDueBy()).thenReturn(expectedDueByDate);
		when(mockedAgreementItem.isReservationBeingFulfilledOrHasReservationOverride()).thenReturn(true);

		final RequestContext mockedRequestContext = getMockedRequestContext();

		action.addAgreementItemToAgreement(mock(Agreement.class), mockedAgreementItem, mockedRequestContext);

		verify(mockedReservationService, never()).hasNoConflictingReservation(Matchers.<Item> anyObject(),
		        Matchers.<Calendar> anyObject(), Matchers.<Calendar> anyObject());
	}

	/**
	 * Should return error if item has conflicting reservations.
	 */
	@Test
	public void shouldReturnErrorIfItemHasConflictingReservations() {
		final Calendar expectedDueByDate = Calendar.getInstance();

		mockStatic(Item.class);
		final Item mockedItem = mock(Item.class);
		when(Item.findItemBySerialNumber(7866L)).thenReturn(mockedItem);
		final Product mockedProduct = mock(Product.class);
		when(mockedItem.getProduct()).thenReturn(mockedProduct);

		final AgreementItem mockedAgreementItem = mock(AgreementItem.class);
		when(mockedAgreementItem.getSerialNumber()).thenReturn(7866L);
		when(mockedAgreementItem.getDueBy()).thenReturn(expectedDueByDate);

		when(
		        mockedReservationService.hasNoConflictingReservation(eq(mockedItem), Matchers.<Calendar> anyObject(),
		                eq(expectedDueByDate))).thenReturn(false);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		assertEquals("error", action.addAgreementItemToAgreement(null, mockedAgreementItem, mockedRequestContext).getId());
	}

	/**
	 * Should perform operations on agreement item if reservation override exists.
	 */
	@Ignore
	@Test
	public void shouldPerformOperationsOnAgreementItemIfReservationOverrideExists() {
		mockStatic(Item.class);
		mockStatic(AgreementItemStatus.class);
		final Item mockedItem = mock(Item.class);
		when(Item.findItemBySerialNumber(1233L)).thenReturn(mockedItem);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		final AgreementItem mockedAgreementItem = mock(AgreementItem.class);
		when(mockedAgreementItem.getSerialNumber()).thenReturn(1233L);

		when(mockedAgreementItem.isReservationBeingFulfilledOrHasReservationOverride()).thenReturn(true);

		final Agreement mockedAgreement = mock(Agreement.class);
		action.addAgreementItemToAgreement(mockedAgreement, mockedAgreementItem, mockedRequestContext);

		verify(mockedAgreementService).addAgreementItemToAgreement(mockedAgreement, mockedAgreementItem, mockedItem);
	}

	/**
	 * Should perform operations on agreement item if everything is fine.
	 */
	@Ignore
	@Test
	public void shouldPerformOperationsOnAgreementItemIfEverythingIsFine() {
		mockStatic(Item.class);
		mockStatic(AgreementItemStatus.class);
		final Item mockedItem = mock(Item.class);
		when(Item.findItemBySerialNumber(1233L)).thenReturn(mockedItem);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		final AgreementItem mockedAgreementItem = mock(AgreementItem.class);
		when(mockedAgreementItem.getSerialNumber()).thenReturn(1233L);

		when(
		        mockedReservationService.hasNoConflictingReservation(Matchers.<Item> anyObject(), Matchers
		                .<Calendar> anyObject(), Matchers.<Calendar> anyObject())).thenReturn(true);

		final Agreement mockedAgreement = mock(Agreement.class);
		action.addAgreementItemToAgreement(mockedAgreement, mockedAgreementItem, mockedRequestContext);

		verify(mockedAgreementService).addAgreementItemToAgreement(mockedAgreement, mockedAgreementItem, mockedItem);
	}

	/**
	 * Should return success if everything goes fine.
	 */
	@Ignore
	@Test
	public void shouldReturnSuccessIfEverythingGoesFine() {
		mockStatic(Item.class);
		mockStatic(AgreementItemStatus.class);
		final Item mockedItem = mock(Item.class);
		when(Item.findItemBySerialNumber(1233L)).thenReturn(mockedItem);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		final AgreementItem mockedAgreementItem = mock(AgreementItem.class);
		when(mockedAgreementItem.getSerialNumber()).thenReturn(1233L);

		when(
		        mockedReservationService.hasNoConflictingReservation(Matchers.<Item> anyObject(), Matchers
		                .<Calendar> anyObject(), Matchers.<Calendar> anyObject())).thenReturn(true);

		final Agreement mockedAgreement = mock(Agreement.class);
		assertEquals("success", action.addAgreementItemToAgreement(mockedAgreement, mockedAgreementItem,
		        mockedRequestContext).getId());
	}

	/**
	 * Should create an empty guest and assign it to agreement.
	 */
	@Test
	public void shouldCreateAnEmptyGuestAndAssignItToAgreement() {
		final Agreement agreement = new Agreement();
		action.ensureGuestInitialized(agreement);

		assertNotNull(agreement.getGuest());
		assertNotNull(agreement.getGuest().getAddress());
		assertNotNull(agreement.getGuest().getIdentification());
	}

	/**
	 * Should merge guest and driver information if guest meets the minimum age.
	 */
	@Test
	public void shouldMergeGuestAndDriverInformationIfGuestMeetsTheMinimumAge() {
		final Agreement mockedAgreement = mock(Agreement.class);

		when(mockedAgreement.isDriverAgeGreaterThanMinimumRentalAge()).thenReturn(true);

		action.addGuestAndDriverInformation(mockedAgreement, getMockedRequestContext());

		verify(mockedAgreement).mergeVehicleRentalDetails();
	}

	/**
	 * Should return success if guest meets the minimum age.
	 */
	@Test
	public void shouldReturnSuccessIfGuestMeetsTheMinimumAge() {
		final Agreement mockedAgreement = mock(Agreement.class);

		when(mockedAgreement.isDriverAgeGreaterThanMinimumRentalAge()).thenReturn(true);

		assertEquals("success", action.addGuestAndDriverInformation(mockedAgreement, getMockedRequestContext()).getId());
	}

	/**
	 * Should populate error in the request context if guest does not meets the minimum age.
	 */
	@Test
	public void shouldPopulateErrorInTheRequestContextIfGuestDoesNotMeetsTheMinimumAge() {
		final Agreement mockedAgreement = mock(Agreement.class);

		when(mockedAgreement.isDriverAgeGreaterThanMinimumRentalAge()).thenReturn(false);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		action.addGuestAndDriverInformation(mockedAgreement, mockedRequestContext);

		verify(mockedRequestContext.getFlashScope()).put("minimumAgeLimitNotMet", true);

		verify(mockedAgreement, never()).mergeVehicleRentalDetails();
	}

	/**
	 * Should return error if guest does not meets the minimum age.
	 */
	@Test
	public void shouldReturnErrorIfGuestDoesNotMeetsTheMinimumAge() {
		final Agreement mockedAgreement = mock(Agreement.class);

		when(mockedAgreement.isDriverAgeGreaterThanMinimumRentalAge()).thenReturn(false);

		assertEquals("error", action.addGuestAndDriverInformation(mockedAgreement, getMockedRequestContext()).getId());
	}

	/**
	 * Should remove the agreement item from the agreement using the agreement service.
	 */
	@Test
	public void shouldRemoveTheAgreementItemFromTheAgreementUsingTheAgreementService() {
		final Agreement expectedAgreement = new Agreement();

		action.removeAgreementItemFromAgreement(expectedAgreement, 100L);

		verify(mockedAgreementService).removeItemFromAgreement(expectedAgreement, 100L);
	}

	/**
	 * Sets the guest called on agreement if guest is null.
	 */
	@Test
	public void setGuestCalledOnAgreementIfGuestIsNull() {
		final Agreement agreement = mock(Agreement.class);

		when(agreement.getGuest()).thenReturn(null);
		action.ensureGuestInitialized(agreement);
		verify(agreement).setGuest(Matchers.any(Guest.class));
	}

	/**
	 * Should return the agreement item corresponding to the given serial number.
	 */
	@Test
	public void shouldReturnTheAgreementItemCorrespondingToTheGivenSerialNumber() {
		final Agreement mockedAgreement = mock(Agreement.class);
		final AgreementItem expectedAgreementItem = new AgreementItem();
        expectedAgreementItem.setAgreement(mockedAgreement);
		when(mockedAgreement.findItemBySerialNumber(1233L)).thenReturn(expectedAgreementItem);
		mockStatic(Question.class);

		assertSame(expectedAgreementItem, action.getChecklistQuestionsFor(mockedAgreement, 1233L));
	}

	/**
	 * Should return the agreement item with the checkin time stamp.
	 */
	@Test
	public void shouldReturnTheAgreementItemWithTheCheckinTimeStamp() {
		final Agreement mockedAgreement = mock(Agreement.class);
        final AgreementItem agreementItem1 = new AgreementItem();
        agreementItem1.setAgreement(mockedAgreement);
        when(mockedAgreement.findItemBySerialNumber(1233L)).thenReturn(agreementItem1);
		final Calendar currentDate = Calendar.getInstance();
		when(mockedAgreement.getCheckinDate()).thenReturn(currentDate);
		mockStatic(Question.class);

		final AgreementItem agreementItem = action.getChecklistQuestionsFor(mockedAgreement, 1233L);
		assertSame(currentDate, agreementItem.getCheckinDate());
	}

	/**
	 * Should add all checklist questions to the request scope.
	 */
	@Test
	public void shouldAddAllChecklistQuestionsToTheRequestScope() {
		final ArrayList<Question> expectedQuestions = new ArrayList<Question>();

		mockStatic(Question.class);
		when(Question.findAllQuestions()).thenReturn(expectedQuestions);

		final RequestContext requestContext = getMockedRequestContext();
		action.setTeamService(mock(TeamService.class));

		action.populateCheckinLookups(mock(AgreementItem.class), requestContext);

		verify(requestContext.getRequestScope()).put("questions", expectedQuestions);
	}

	/**
	 * Should put the list of general managers in the request scope.
	 */
	@Test
	public void shouldPutTheListOfGeneralManagersInTheRequestScope() {
		mockStatic(Question.class);

		final RequestContext requestContext = getMockedRequestContext();
		final TeamService mockedManagerService = mock(TeamService.class);

		final ArrayList<StoreUserInfo> expectedManagerNames = new ArrayList<StoreUserInfo>();
		when(mockedManagerService.getGeneralManagerForCurrentStore()).thenReturn(expectedManagerNames);

		action.setTeamService(mockedManagerService);

		action.populateCheckinLookups(mock(AgreementItem.class), requestContext);

		verify(requestContext.getRequestScope()).put("managerNames", expectedManagerNames);
	}

	/**
	 * Should create empty checklist answers if required.
	 */
	@Test
	public void shouldCreateEmptyChecklistAnswersIfRequired() {
		final List<Question> expectedQuestions = new ArrayList<Question>();
		mockStatic(Question.class);
		when(Question.findAllQuestions()).thenReturn(expectedQuestions);

		action.setTeamService(mock(TeamService.class));

		final AgreementItem mockedAgreementItem = mock(AgreementItem.class);
		action.populateCheckinLookups(mockedAgreementItem, getMockedRequestContext());

		verify(mockedAgreementItem).createEmptyAnswersIfRequired(expectedQuestions);
	}

	/**
	 * Should copy the answers to the answer set.
	 */
	@Test
	public void shouldCopyTheAnswersToTheAnswerSet() {
		final AgreementItem mockedCheckin = mock(AgreementItem.class);
		action.markItemToCheckin(mockedCheckin);

		verify(mockedCheckin).markToCheckin();
	}

	/**
	 * Should save the checked in items.
	 */
	@Ignore
	@Test
	public void shouldSaveTheCheckedInItems() {
		final Agreement agreement = new Agreement();
        agreement.setId(1233L);
		final RequestContext requestContest = getMockedRequestContext();

        final Agreement savedAgreement = mock(Agreement.class);

        mockStatic(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(savedAgreement);
        when(mockedAgreementService.sendAgreementToKiosk(Matchers.<Agreement>anyObject(), anyString()))
                .thenReturn(true);

        if (agreement == null){
        	System.out.println("agreement is null");
        }
        
        if (requestContest == null){
        	System.out.println("requestContest is null");
        }
        
		action.checkinMarkedItems(agreement, requestContest);

		verify(mockedAgreementService).checkinMarkedItems(agreement);
		verify(requestContest.getFlashScope()).put("showReport", true);
		verify(requestContest.getFlowScope()).put("notEditable", true);
	}
	@Ignore
	@Test
	public void shouldSyncInventoryWhileCheckinItemIsDone() {
		final Agreement agreement = new Agreement();
        agreement.setId(1233L);
		final RequestContext requestContest = getMockedRequestContext();

        final Agreement savedAgreement = mock(Agreement.class);

        mockStatic(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(savedAgreement);
        when(mockedAgreementService.sendAgreementToKiosk(Matchers.<Agreement>anyObject(), anyString()))
                .thenReturn(true);

		action.checkinMarkedItems(agreement, requestContest);

		verify(mockedAgreementService).syncInventoryForCheckedInItems(agreement);
	}
	@Ignore
	@Test
	public void shouldSendTheAgreementToTheKioskServer() {
		final Agreement agreement = mock(Agreement.class);
        when(agreement.getId()).thenReturn(1233L);
        when(agreement.getAgreementNumber()).thenReturn("8888-45459-009");

        final Agreement savedAgreement = mock(Agreement.class);

        when(savedAgreement.getAgreementNumber()).thenReturn("8888-45459-010");
        mockStatic(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(savedAgreement);

		final RequestContext requestContest = getMockedRequestContext();
		action.checkinMarkedItems(agreement, requestContest);

		verify(mockedAgreementService).sendAgreementToKiosk(savedAgreement, "8888-45459-009");
	}
	@Ignore
	@Test
	public void shouldNotThrowAnExceptionEvenIfKioskServiceFails() {
		final Agreement agreement = new Agreement();
        agreement.setId(1233L);

        final Agreement savedAgreement = mock(Agreement.class);

        mockStatic(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(savedAgreement);

		final RequestContext requestContest = getMockedRequestContext();

        action.checkinMarkedItems(agreement, requestContest);
        verify(requestContest.getFlashScope()).put("kioskError", true);
	}
	@Ignore
    @Test
    public void shouldCompleteTheAgreementIfNoAdditionalChargesAreIncurredByTheAgreement() {
        final Agreement mockedAgreement = mock(Agreement.class);
        when(mockedAgreement.getId()).thenReturn(1233L);

        final Agreement agreement1 = mock(Agreement.class);
        mockStatic(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(agreement1);

        when(agreement1.isNoTotalAdditionalChargeApplicable()).thenReturn(true);

        action.checkinMarkedItems(mockedAgreement, getMockedRequestContext());

        verify(mockedAgreementService).makeAgreementCompleteIfPossible(eq(agreement1),
                Matchers.<Calendar>anyObject());
    }
	@Ignore
    @Test
    public void shouldNotCompleteTheAgreementIfAdditionalChargesAreIncurredByTheAgreement() {
        final Agreement mockedAgreement = mock(Agreement.class);

        when(mockedAgreement.getId()).thenReturn(1233L);

        final Agreement agreement1 = mock(Agreement.class);
        mockStatic(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(agreement1);

        when(agreement1.isNoTotalAdditionalChargeApplicable()).thenReturn(false);

        action.checkinMarkedItems(mockedAgreement, getMockedRequestContext());

        verify(mockedAgreementService, never())
                .makeAgreementCompleteIfPossible(Matchers.<Agreement>anyObject(), Matchers.<Calendar>anyObject());
    }

	/**
	 * Should calculate the damage waiver charges.
	 */
	@Test
	public void shouldCalculateTheDamageWaiverCharges() {
		final Agreement mockedAgreement = mock(Agreement.class);
		action.updateDamageWaiverCharges(mockedAgreement);

		verify(mockedAgreement).calculateDamageWaiverCharges();
	}

    @Test
    public void shouldReturnErrorIfAgreementHasNoItems() {
        final Agreement agreement = mock(Agreement.class);
        when(agreement.hasItems()).thenReturn(false);

        final RequestContext requestContext = getMockedRequestContext();
        assertEquals("error", action.saveOrUpdate(agreement, requestContext).getId());
        verify(requestContext.getFlashScope()).put("agreementNoItemsError", true);
    }

	/**
	 * Should return success if service was able to save or update the agreement.
	 */
	@Test
	public void shouldReturnSuccessIfServiceWasAbleToSaveOrUpdateTheAgreement() {

        final Agreement agreement = mock(Agreement.class);
        when(agreement.hasItems()).thenReturn(true);
        mockStatic(Agreement.class);
        when(Agreement.loadFull(agreement.getId())).thenReturn(agreement);
		doNothing().when(mockedAgreementService).saveOrUpdateAgreement(agreement);

		assertEquals("success", action.saveOrUpdate(agreement, getMockedRequestContext()).getId());
	}

	@Test
	public void shouldCopyTheTransientInformationInTheAgreement() {

        final Agreement agreement = mock(Agreement.class);
        when(agreement.getId()).thenReturn(1233L);
        when(agreement.hasItems()).thenReturn(true);
        final Agreement agreement1 = mock(Agreement.class);
        mockStatic(Agreement.class);
        when(Agreement.loadFull(1233L)).thenReturn(agreement1);

		doNothing().when(mockedAgreementService).saveOrUpdateAgreement(agreement);

		action.saveOrUpdate(agreement, getMockedRequestContext()).getId();
        verify(agreement1).copyTransientInformationFrom(agreement);
	}

	/**
	 * Should return success if service was able to save or update the agreement.
	 */
	@Test
	public void shouldSendTheRentalOverrideMailsIfReservationWasOverriden() {
        final Agreement agreement = mock(Agreement.class);
        when(agreement.hasItems()).thenReturn(true);
        mockStatic(Agreement.class);
        when(Agreement.loadFull(agreement.getId())).thenReturn(agreement);
        when(mockedAgreementService.sendAgreementToKiosk(Matchers.<Agreement>anyObject(), anyString())).thenReturn(true);
		action.saveOrUpdate(agreement, getMockedRequestContext());

        verify(mockedAgreementService).sendRentalOverrideMailsIfAny(agreement);
	}

	/**
	 * Should set the show report in request context if service was able to save or update the agreement.
	 */
	@Test
	public void shouldSetTheShowReportInRequestContextIfServiceWasAbleToSaveOrUpdateTheAgreement() {

        final Agreement agreement = mock(Agreement.class);
        when(agreement.hasItems()).thenReturn(true);
		doNothing().when(mockedAgreementService).saveOrUpdateAgreement(agreement);

        mockStatic(Agreement.class);
        when(Agreement.loadFull(agreement.getId())).thenReturn(agreement);
		final RequestContext mockedRequestContext = getMockedRequestContext();
        when(mockedAgreementService.sendAgreementToKiosk(Matchers.<Agreement>anyObject(), anyString())).thenReturn(true);
		action.saveOrUpdate(agreement, mockedRequestContext);

		verify(mockedRequestContext.getFlashScope()).put("showReport", true);
	}

	/**
	 * Should set the show report in request context if service was able to save or update the agreement.
	 */
	@Test
	public void shouldNotSetTheKioskErrorInRequestContextIfServiceWasAbleToSaveOrUpdateTheAgreementAndKioskServiceReturnedDidntReturnError() {

        final Agreement agreement = mock(Agreement.class);
        when(agreement.hasItems()).thenReturn(true);
        when(agreement.getAgreementNumber()).thenReturn("8888-45459-009");
		doNothing().when(mockedAgreementService).saveOrUpdateAgreement(agreement);
        when(mockedAgreementService.sendAgreementToKiosk(agreement, "8888-45459-009")).thenReturn(true);

        mockStatic(Agreement.class);
        when(Agreement.loadFull(agreement.getId())).thenReturn(agreement);
		final RequestContext mockedRequestContext = getMockedRequestContext();
		action.saveOrUpdate(agreement, mockedRequestContext);

		verify(mockedRequestContext.getFlashScope(), never()).put("kioskError", true);
	}

	/**
	 * Should set the agreement object in flow scope if service was able to save or update the agreement.
	 */
	@Test
	public void shouldSetTheAgreementObjectInFlowScopeIfServiceWasAbleToSaveOrUpdateTheAgreement() {

        final Agreement agreement = mock(Agreement.class);
        when(agreement.hasItems()).thenReturn(true);
        when(agreement.getId()).thenReturn(1233L);

		doNothing().when(mockedAgreementService).saveOrUpdateAgreement(agreement);

		final RequestContext mockedRequestContext = getMockedRequestContext();

		mockStatic(Agreement.class);
		when(Agreement.loadFull(1233L)).thenReturn(agreement);

		action.saveOrUpdate(agreement, mockedRequestContext);

		verify(mockedRequestContext.getFlowScope()).put("agreement", agreement);
	}

	/**
	 * Should return error if service was not able to save or update the agreement.
	 */
	@Test
	public void shouldReturnErrorIfServiceWasNotAbleToSaveOrUpdateTheAgreement() {

        final Agreement agreement = mock(Agreement.class);
        when(agreement.hasItems()).thenReturn(true);
		doThrow(new IllegalStateException()).when(mockedAgreementService).saveOrUpdateAgreement(agreement);
        mockStatic(Agreement.class);

		assertEquals("error", action.saveOrUpdate(agreement, getMockedRequestContext()).getId());
	}

	/**
	 * Should set the error in request context if service was not able to save or update the agreement.
	 */
	@Test
	public void shouldSetTheErrorInRequestContextIfServiceWasNotAbleToSaveOrUpdateTheAgreement() {

        final Agreement agreement = mock(Agreement.class);
        when(agreement.hasItems()).thenReturn(true);
		doThrow(new IllegalStateException()).when(mockedAgreementService).saveOrUpdateAgreement(agreement);
        mockStatic(Agreement.class);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		action.saveOrUpdate(agreement, mockedRequestContext);

		verify(mockedRequestContext.getFlashScope()).put("hasError", true);
	}

	/**
	 * Should populate manager names while populating the override lookups.
	 */
	@Test
	public void shouldPopulateManagerNamesWhilePopulatingTheOverrideLookups() {
		final ArrayList<StoreUserInfo> managerNames = new ArrayList<StoreUserInfo>();
		when(mockedTeamService.getGeneralManagerForCurrentStore()).thenReturn(managerNames);
		mockStatic(OverrideReason.class);

		final RequestContext mockedRequestContext = getMockedRequestContext();

		action.populateOverrideLookups(mock(Agreement.class), mockedRequestContext);

		verify(mockedRequestContext.getRequestScope()).put("managerNames", managerNames);
	}

	/**
	 * Should populate override reasons while populating the override lookups.
	 */
	@Test
	public void shouldPopulateOverrideReasonsWhilePopulatingTheOverrideLookups() {
		mockStatic(OverrideReason.class);
		final ArrayList<OverrideReason> reasons = new ArrayList<OverrideReason>();
		when(OverrideReason.findAllOverrideReasons()).thenReturn(reasons);

		final RequestContext mockedRequestContext = getMockedRequestContext();

		action.populateOverrideLookups(mock(Agreement.class), mockedRequestContext);

		verify(mockedRequestContext.getRequestScope()).put("overrideReasons", reasons);
	}

	/**
	 * Should populate price override manager name while populating the override lookups.
	 */
	@Test
	public void shouldPopulatePriceOverrideManagerNameWhilePopulatingTheOverrideLookups() {
		mockStatic(OverrideReason.class);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		final Agreement mockedAgreement = mock(Agreement.class);
		when(mockedAgreement.getPriceOverrideApprovedBy()).thenReturn(1233);

		action.populateOverrideLookups(mockedAgreement, mockedRequestContext);

		verify(mockedRequestContext.getRequestScope()).put("selectedPriceOverrideManagerName", 1233);
	}

	/**
	 * Should populate quantity override manager name while populating the override lookups.
	 */
	@Test
	public void shouldPopulateQuantityOverrideManagerNameWhilePopulatingTheOverrideLookups() {
		mockStatic(OverrideReason.class);

		final RequestContext mockedRequestContext = getMockedRequestContext();
		final Agreement mockedAgreement = mock(Agreement.class);
		when(mockedAgreement.getQuantityOverrideApprovedBy()).thenReturn(1233);

		action.populateOverrideLookups(mockedAgreement, mockedRequestContext);

		verify(mockedRequestContext.getRequestScope()).put("selectedQuantityOverrideManagerName", 1233);
	}

	/**
	 * Should set the price override manager name.
	 */
	@Test
	public void shouldSetThePriceOverrideManagerName() {
		final Agreement mockedAgreement = mock(Agreement.class);
		action.setPriceOverrideManagerNameAndUpdateCharges(mockedAgreement,1233);

		verify(mockedAgreement).setPriceOverrideApprovedBy(1233);
	}

	/**
	 * Should calculate the damage waiver charges when price override is done.
	 */
	@Test
	public void shouldCalculateTheDamageWaiverChargesWhenPriceOverrideIsDone() {
		final Agreement mockedAgreement = mock(Agreement.class);
		action.setPriceOverrideManagerNameAndUpdateCharges(mockedAgreement, 1233);

		verify(mockedAgreement).calculateDamageWaiverCharges();
	}

	/**
	 * Should set the quantity override manager name.
	 */
	@Test
	public void shouldSetTheQuantityOverrideManagerName() {
		final Agreement mockedAgreement = mock(Agreement.class);
		action.setQuantityOverrideManagerNameToAgreement(mockedAgreement, 1233);

		verify(mockedAgreement).setQuantityOverrideApprovedBy(1233);
	}

	/**
	 * Should return the agreement item with the matching serial number.
	 */
	@Test
	public void shouldReturnTheAgreementItemWithTheMatchingSerialNumber() {
		final Agreement mockedAgreement = mock(Agreement.class);

		final AgreementItem expectedAgreementItem = new AgreementItem();
		when(mockedAgreement.findItemBySerialNumber(1233L)).thenReturn(expectedAgreementItem);

		assertSame(expectedAgreementItem, action.getRentalItemToEdit(mockedAgreement, 1233L));
	}

	/**
	 * Should calculate the add estimated charges and amounts when updating the item.
	 */
	@Test
	public void shouldCalculateTheAddEstimatedChargesAndAmountsWhenUpdatingTheItem() {
		final AgreementItem mockedAgreementItem = mock(AgreementItem.class);
		action.reCalculateChargesAndDurationForAgreementItem(mockedAgreementItem);

		verify(mockedAgreementItem).calculateEstimatedChargesAndDuration();
	}

	/**
	 * Should populate manager names in the request scope.
	 */
	@Test
	public void shouldPopulateManagerNamesInTheRequestScope() {
		final RequestContext mockedRequestContext = getMockedRequestContext();

		final List<StoreUserInfo> expectedGeneralManager = new ArrayList<StoreUserInfo>();
		when(mockedTeamService.getGeneralManagerForCurrentStore()).thenReturn(expectedGeneralManager);

		action.populatePopupLookups(mockedRequestContext);

		verify(mockedRequestContext.getRequestScope()).put("managerNames", expectedGeneralManager);
	}
    
    @Test
    public void shouldReturnFalseIfNullIsReturnedForTheSerialNumberToCheckin() {
        final Agreement agreement = mock(Agreement.class);
        final RequestContext mockedRequestContext = getMockedRequestContext();

        when(agreement.getNextItemSerialNumberToAnswerChecklist()).thenReturn(null);

        assertFalse(action.hasMoreItemsToBeCheckedin(agreement, mockedRequestContext));
    }

    @Test
    public void shouldReturnTrueIfAValidSerialNumberIsReturnedForTheSerialNumberToCheckin() {
        final Agreement agreement = mock(Agreement.class);
        final RequestContext mockedRequestContext = getMockedRequestContext();

        when(agreement.getNextItemSerialNumberToAnswerChecklist()).thenReturn(123123123L);

        assertTrue(action.hasMoreItemsToBeCheckedin(agreement, mockedRequestContext));
    }

    @Test
    public void shouldPopulateTheNextSerialNumberToCheckinInTheFlashScope() {
        final Agreement agreement = mock(Agreement.class);
        final RequestContext mockedRequestContext = getMockedRequestContext();

        when(agreement.getNextItemSerialNumberToAnswerChecklist()).thenReturn(123123123L);

        action.hasMoreItemsToBeCheckedin(agreement, mockedRequestContext);

        verify(mockedRequestContext.getFlashScope()).put("checkinItemSerialNumber", 123123123L);
    }

    @Test
    public void shouldNotDoAnythingIfTheItemIdIsNull() {
        final AgreementItem agreementItem = new AgreementItem();
        action.markItemForCheckin(new AgreementBuilder().withItem(agreementItem).buildAgreement(), null);

        assertFalse(agreementItem.isCheckedin());
    }

    @Test
    public void shouldNotDoAnythingIfTheItemIdIs0() {
        final AgreementItem agreementItem = new AgreementItem();
        action.markItemForCheckin(new AgreementBuilder().withItem(agreementItem).buildAgreement(), 0L);

        assertFalse(agreementItem.isCheckedin());
    }

    @Test
    public void shouldFindTheAgreementItemMatchingTheItemIdAndMarkThatForCheckin() {
        final Item item = new Item();
        item.setSerialNumber(1233L);
        final AgreementItem agreementItem = new AgreementItemBuilder().withItem(item).buildAgreementItem();
        final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
        items.add(agreementItem);
        final AgreementItem other = new AgreementItem();
        final Item item1 = new Item();
        other.setItem(item1);
        item1.setSerialNumber(7866L);
        items.add(other);
        action.markItemForCheckin(new AgreementBuilder().withItems(items).buildAgreement(), 1233L);

        assertTrue(agreementItem.isCheckedin());        
        assertFalse(other.isCheckedin());        
    }
    
    @Test
    public void shouldReturnSuccessIfThereAreItemsToBeCheckedin() {
        action = spy(action);
        final Agreement agreement = mock(Agreement.class);
        doReturn(true).when(action).hasMoreItemsToBeCheckedin(agreement, null);

        assertEquals("success", action.checkIfAtleastOneItemSelectedForCheckin(agreement, null).getId());
    }

    @Test
    public void shouldReturnErrorIfThereAreNoItemsToBeCheckedin() {
        action = spy(action);
        final Agreement agreement = mock(Agreement.class);
        final RequestContext requestContext = getMockedRequestContext();
        doReturn(false).when(action).hasMoreItemsToBeCheckedin(agreement, requestContext);

        assertEquals("error", action.checkIfAtleastOneItemSelectedForCheckin(agreement, requestContext).getId());
        verify(requestContext.getFlashScope()).put(Constants.Agreement.NO_ITEMS_SELECTED_FOR_CHECKIN_ERROR_KEY, true);
    }

    @Test
    public void shouldNotDoAnythingIfTheAgreementIsEditable() {
        final Agreement agreement = mock(Agreement.class);
        when(agreement.isEditable()).thenReturn(true);
        
        mockStatic(Agreement.class);
        action.saveNotesIfPossible(agreement, getMockedRequestContext());
        
        verify(mockedAgreementService, never()).merge(Matchers.<Agreement>anyObject());
    }
    
    @Ignore
    @Test
    public void shouldMergeTheAgreementIfAgreementIsNotEditableButUserIsSimplyAddingNotesToIt() {
        final Agreement agreement = mock(Agreement.class);
        when(agreement.isEditable()).thenReturn(false);

        mockStatic(Agreement.class);
        action.saveNotesIfPossible(agreement, getMockedRequestContext());

        verify(mockedAgreementService).merge(agreement);
    }

    @Test
    public void shouldLoadTheSavedAgreementAndUpdateTheFlowScopeVariable() {
        final Agreement savedAgreement = new Agreement();
        final Agreement agreement = mock(Agreement.class);
        when(agreement.getId()).thenReturn(1233L);
        when(agreement.isEditable()).thenReturn(false);

        mockStatic(Agreement.class);
        when(Agreement.loadFull(1233L)).thenReturn(savedAgreement);

        final RequestContext requestContext = getMockedRequestContext();
        action.saveNotesIfPossible(agreement, requestContext);

        verify(requestContext.getFlowScope()).put("agreement", savedAgreement);
    }

    @Test
    public void shouldPopulateErrorIfNoCheckinQuestionsHaveBeenSetup() {
        mockStatic(Question.class);
        when(Question.countQuestions()).thenReturn(0L);

        final RequestContext requestContext = getMockedRequestContext();
        action.checkIfAtleastOneCheckinQuestionIsSetup(requestContext);

        verify(requestContext.getFlashScope()).put("noChecklistQuestionsError", true);
    }

    @Test
    public void shouldReturnErrorIfNoCheckinQuestionsHaveBeenSetup() {
        mockStatic(Question.class);
        when(Question.countQuestions()).thenReturn(0L);

        final RequestContext requestContext = getMockedRequestContext();
        assertEquals("error", action.checkIfAtleastOneCheckinQuestionIsSetup(requestContext).getId());
    }

    @Test
    public void shouldReturnSuccessIfAtleastOneCheckinQuestionIsSetup() {
        mockStatic(Question.class);
        when(Question.countQuestions()).thenReturn(1L);

        final RequestContext requestContext = getMockedRequestContext();
        assertEquals("success", action.checkIfAtleastOneCheckinQuestionIsSetup(requestContext).getId());
    }

	/**
	 * Gets the mocked request context.
	 *
	 * @return the mocked request context
	 */
	private RequestContext getMockedRequestContext() {
		final RequestContext requestContext = mock(RequestContext.class);
		final MutableAttributeMap mockedFlashScope = mock(MutableAttributeMap.class);
		final MutableAttributeMap mockedFlowScope = mock(MutableAttributeMap.class);
		final MutableAttributeMap mockedRequestScope = mock(MutableAttributeMap.class);
		when(requestContext.getFlashScope()).thenReturn(mockedFlashScope);
		when(requestContext.getFlowScope()).thenReturn(mockedFlowScope);
		when(requestContext.getRequestScope()).thenReturn(mockedRequestScope);

		return requestContext;
	}
}
