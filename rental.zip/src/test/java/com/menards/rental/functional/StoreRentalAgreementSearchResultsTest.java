/*
 * StoreRentalAgreementSearchResultsTest.java
 */
package com.menards.rental.functional;

import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.functional.action.RentalAgreementLookupAction;
import com.menards.rental.functional.action.RentalAgreementSearchResultsAction;
import com.menards.rental.functional.action.RentalAgreementSummaryAction;
import com.menards.rental.functional.action.StoreUtilityLandingAction;

/**
 * User: Rasika Date: 23rd Jun, 2010 Time: 12:30 PM.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
public class StoreRentalAgreementSearchResultsTest extends BaseFunctionalTestCase {

	// Test to verify 'New search' button click launches 'Rental Agreement
	// Lookup' screen

	/**
	 * Test to verify new search button click.
	 */
	public void testToVerifyNewSearchButtonClick() {

		RentalAgreementLookupAction rentalAgreementLookupAction = new StoreUtilityLandingAction(selenium).open()
		        .clickLookupRentalAgreement();

		final RentalAgreementSearchResultsAction rentalAgreementSearchResultsAction = rentalAgreementLookupAction
		        .clickSearch();

		rentalAgreementLookupAction = rentalAgreementSearchResultsAction.clickNewSearch();

		rentalAgreementLookupAction.verifyTextMessage("Electronic Rental Agreements - Rental Agreement Lookup");

	}

	// Test to verify 'view/print' button click launches Agreement Summary Page

	/**
	 * Test to verify view print button click.
	 */
	public void testToVerifyViewPrintButtonClick() {

		final RentalAgreementLookupAction rentalAgreementLookupAction = new StoreUtilityLandingAction(selenium).open()
		        .clickLookupRentalAgreement();

		final RentalAgreementSearchResultsAction rentalAgreementSearchResultsAction = rentalAgreementLookupAction
		        .clickSearch();

		final RentalAgreementSummaryAction rentalAgreementSummaryAction = rentalAgreementSearchResultsAction
		        .clickViewPrint();

		rentalAgreementSummaryAction.verifyTextPage("Rental Agreement Number: 21234-001");

	}

}
