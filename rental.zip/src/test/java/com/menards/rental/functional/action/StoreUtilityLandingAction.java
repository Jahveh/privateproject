/*
 * StoreUtilityLandingAction.java
 */
package com.menards.rental.functional.action;

import static junit.framework.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/*
 *User: Rasika
 * Date: 21st Jun, 2010
 * Time: 11:48 AM
 */

/**
 * The Class StoreUtilityLandingAction.
 */
public class StoreUtilityLandingAction {
	
	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new store utility landing action.
	 *
	 * @param selenium the selenium
	 */
	public StoreUtilityLandingAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Open.
	 *
	 * @return the store utility landing action
	 */
	public StoreUtilityLandingAction open() {
		selenium.open("storeutility");
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Click add new rental item.
	 *
	 * @return the adds the rental items action
	 */
	public AddRentalItemsAction clickAddNewRentalItem() {
		selenium.click(Constants.StoreUtilityLandingPage.ADD_NEW_RENTAL_ITEM_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new AddRentalItemsAction(selenium);
	}

	/**
	 * Verify text present.
	 *
	 * @param text the text
	 * @return the store utility landing action
	 */
	public StoreUtilityLandingAction verifyTextPresent(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Click lookup rental agreement.
	 *
	 * @return the rental agreement lookup action
	 */
	public RentalAgreementLookupAction clickLookupRentalAgreement() {
		selenium.click(Constants.StoreUtilityLandingPage.LOOKUP_RENTAL_AGREEMENT_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new RentalAgreementLookupAction(selenium);
	}

}
