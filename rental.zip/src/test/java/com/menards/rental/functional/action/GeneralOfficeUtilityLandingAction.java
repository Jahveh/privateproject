/*
 * GeneralOfficeUtilityLandingAction.java
 */
package com.menards.rental.functional.action;

import static junit.framework.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: deep Date: 14 Jun, 2010 Time: 11:40:44 AM To
 * change this template use File | Settings | File Templates.
 */
public class GeneralOfficeUtilityLandingAction {
	
	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new general office utility landing action.
	 *
	 * @param selenium the selenium
	 */
	public GeneralOfficeUtilityLandingAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Open.
	 *
	 * @return the general office utility landing action
	 */
	public GeneralOfficeUtilityLandingAction open() {
		selenium.open("generalofficeutility");
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Click rental sku setup.
	 *
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction clickRentalSKUSetup() {
		selenium.click(Constants.GeneralOfficeUtilityLandingPage.RENTAL_SKU_SETUP_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new RentalSKUSetupAction(selenium);
	}

	/**
	 * Verify text present.
	 *
	 * @param text the text
	 * @return the general office utility landing action
	 */
	public GeneralOfficeUtilityLandingAction verifyTextPresent(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}
}
