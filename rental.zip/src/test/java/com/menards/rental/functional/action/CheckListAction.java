/*
 * CheckListAction.java
 */
package com.menards.rental.functional.action;

import static org.junit.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Jul 27, 2010 Time: 3:09:19 PM To
 * change this template use File | Settings | File Templates.
 */
public class CheckListAction {

	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new check list action.
	 *
	 * @param selenium the selenium
	 */
	public CheckListAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Verify check list screen text.
	 *
	 * @param text the text
	 * @return the check list action
	 */
	public CheckListAction verifyCheckListScreenText(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Fill form.
	 *
	 * @return the check list action
	 */
	public CheckListAction fillForm() {
		selenium.type(Constants.CheckInAgreement.TEAMEMBER_TEXTBOX_ID, "ABC");
		selenium.click("//div[@id='AnyTime--checkinDateId']/div/div[1]/ul[1]/li[1]");
		selenium.click("checkinDateId");
		selenium.click("yesAnswer_0");
		selenium.type("chargeAmount_0", "10");
		selenium.click("no_1");
		selenium.click("no_2");
		selenium.click("no_3");
		selenium.click("yesAnswer_4");
		selenium.type("chargeAmount_4", "20");
		selenium.click("no_5");
		selenium.click("no_6");
		selenium.click("yesAnswer_7");
		selenium.type("chargeAmount_7", "10");
		selenium.click("no_8");
		selenium.click("yesAnswer_9");
		selenium.click("isExcessiveDamageDone_9");
		selenium.type("usageInNumberId", "100");
		return this;
	}

	/**
	 * Click continue button.
	 *
	 * @return the check in agreement action
	 */
	public CheckInAgreementAction clickContinueButton() {
		selenium.click(Constants.CheckInAgreement.CONTINUE_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new CheckInAgreementAction(selenium);
	}
}
