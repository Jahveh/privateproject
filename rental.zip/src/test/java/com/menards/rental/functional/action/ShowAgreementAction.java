/*
 * ShowAgreementAction.java
 */
package com.menards.rental.functional.action;

import org.junit.Assert;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: deep Date: 18 May, 2010 Time: 6:07:12 PM To
 * change this template use File | Settings | File Templates.
 */
public class ShowAgreementAction {

	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new show agreement action.
	 *
	 * @param selenium the selenium
	 */
	public ShowAgreementAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Verify page rendered.
	 *
	 * @return the show agreement action
	 */
	public ShowAgreementAction verifyPageRendered() {
		Assert.assertTrue(selenium.getBodyText().contains("Electronic Rental Agreements - Agreement Summary"));
		return this;
	}

	/**
	 * Click cancel button.
	 *
	 * @return the search agreements action
	 */
	public SearchAgreementsAction clickCancelButton() {
		selenium.click(Constants.ShowAgreement.CANCEL_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new SearchAgreementsAction(selenium);
	}
}
