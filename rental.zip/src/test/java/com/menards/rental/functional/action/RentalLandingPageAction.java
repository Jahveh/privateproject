/*
 * RentalLandingPageAction.java
 */
package com.menards.rental.functional.action;

import com.thoughtworks.selenium.Selenium;

/**
 * The Class RentalLandingPageAction.
 *
 * @param <T> the generic type
 */
public abstract class RentalLandingPageAction<T> {

	/** The selenium. */
	protected Selenium selenium;

	/**
	 * Instantiates a new rental landing page action.
	 *
	 * @param selenium the selenium
	 */
	public RentalLandingPageAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Open.
	 *
	 * @return the t
	 */
	public T open() {
		selenium.open(""); // Root of web app
		return (T) this;
	}
}
