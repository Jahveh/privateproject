/*
 * CreateReservationTest.java
 */
package com.menards.rental.functional;

import com.menards.rental.functional.action.BeginReservationAction;
import com.menards.rental.functional.action.ReservationSummaryAction;
import com.menards.rental.functional.action.ReserveGuestInfoAction;
import com.menards.rental.functional.action.StartReservationAction;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Aug 9, 2010 Time: 12:38:17 PM To
 * change this template use File | Settings | File Templates.
 */
public class CreateReservationTest extends BaseFunctionalTestCase {

	/**
	 * Test to create item reservation.
	 */
	public void testToCreateItemReservation() {

		final BeginReservationAction beginReservationAction = new StartReservationAction(selenium).open()
		        .clickStartCreateReservation();

		beginReservationAction.verifyBeginReservationScreen("Electronic Reservations - Begin Reservation")
		        .selectItemToReserve().clickSelectButton().verifyItemStatus("Available").clickReserveButton()
		        .verifyAddReservationPopup("reserveDialog").selectChkOutTime().selectReturnDate();

		final ReserveGuestInfoAction reserveGuestInfoAction = beginReservationAction.clickPopupReserveButton();

		reserveGuestInfoAction.verifyReserveGuesInfoScreen("Electronic Reservations - Guest Information").FillForm();

		final ReservationSummaryAction reservationSummaryAction = reserveGuestInfoAction.clickContinueButton();

		reservationSummaryAction.verifyReservationSummaryScreen("Electronic Reservations - Summary").verifyItemPresent(
		        "100-1014: Product-4").clickSavePrintButton();

		final StartReservationAction startReservationAction = reservationSummaryAction.clickExitButton();

		startReservationAction.verifyStartSearchScreen("Electronic Rental Agreements - Start/Search")
		        .verifyReservationDisplayedInList("RESERVATION, TEST");

	}

}
