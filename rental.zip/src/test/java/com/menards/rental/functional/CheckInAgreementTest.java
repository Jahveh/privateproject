/*
 * CheckInAgreementTest.java
 */
package com.menards.rental.functional;

import com.menards.rental.functional.action.ChargesSummaryAction;
import com.menards.rental.functional.action.CheckInAgreementAction;
import com.menards.rental.functional.action.CheckListAction;
import com.menards.rental.functional.action.QtyOverrideAction;
import com.menards.rental.functional.action.SearchAgreementsAction;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Jul 27, 2010 Time: 12:22:00 PM
 * To change this template use File | Settings | File Templates.
 */

// Testcase for verifying Rental item Check-in feature.
// Screens covered are: begincheck-in,checklist,chages summary,qty qverride
public class CheckInAgreementTest extends BaseFunctionalTestCase {

	/**
	 * Test check in agreement.
	 *
	 * @throws Exception the exception
	 */
	public void testCheckInAgreement() throws Exception {

		new SearchAgreementsAction(selenium).open();

		final SearchAgreementsAction searchAgreementsAction = new CheckInAgreementAction(selenium)
		        .selectBeginCheckInOption();

		final CheckInAgreementAction checkinAgreementAction = new CheckInAgreementAction(selenium)
		        .clickAgreementsSelectButton().verifyBeginCheckInScreenText("Electronic Rental Agreements - Begin Check In");

		final CheckListAction checklistAction = new CheckInAgreementAction(selenium).clickChecklistCheckbox();

		final CheckListAction checklistAction1 = new CheckListAction(selenium).verifyCheckListScreenText(
		        "Electronic Rental Agreements - Checklist").fillForm();

		final CheckInAgreementAction checkInAgreementAction1 = new CheckListAction(selenium).clickContinueButton();

		final CheckInAgreementAction checkInAgreementAction2 = new CheckInAgreementAction(selenium)
		        .verifyBeginCheckInScreenText("Electronic Rental Agreements - Begin Check In").verifyCheckboxChecked();

		final ChargesSummaryAction chargesSummaryAction = new CheckInAgreementAction(selenium).clickContinueCheckInButton();

		final ChargesSummaryAction chargesSummaryAction1 = new ChargesSummaryAction(selenium)
		        .verifyChargesSummaryScreenText("Electronic Rental Agreements - Summary of Charges")
		        .verifyItemRecordPresent();

		final QtyOverrideAction qtyOverrideAction = new ChargesSummaryAction(selenium).clickQtyOverrideButton();

		final QtyOverrideAction qtyOverrideAction1 = new QtyOverrideAction(selenium).verifyQtyOverrideScreenText(
		        "Electronic Rental Agreements - Rental Hours/Qty Override").FillInformation();

		final ChargesSummaryAction chargesSummaryAction2 = new QtyOverrideAction(selenium).clickSubmitButton();

		chargesSummaryAction2.verifyOverridedQtyMatch();
		chargesSummaryAction2.clickSaveAndPrintButton();
		chargesSummaryAction2.closePrintView();

		final SearchAgreementsAction searchAgreementsAction1 = new ChargesSummaryAction(selenium).clickCancelButton();

		final SearchAgreementsAction searchAgreementsAction2 = new ChargesSummaryAction(selenium)
		        .verifyStartScreenText("Electronic Rental Agreements - Start/Search");

		final SearchAgreementsAction searchAgreementsAction3 = new CheckInAgreementAction(selenium)
		        .selectBeginCheckInOption();

		final CheckInAgreementAction checkinAgreementAction1 = new CheckInAgreementAction(selenium)
		        .clickAgreementsSelectButton().verifyBeginCheckInScreenText("Electronic Rental Agreements - Begin Check In")
		        .verifyRentalSKUPresent().verifyItemStatus();

	}
}
