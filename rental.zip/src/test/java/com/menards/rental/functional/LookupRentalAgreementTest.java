/*
 * LookupRentalAgreementTest.java
 */
package com.menards.rental.functional;

import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.functional.action.RentalAgreementLookupAction;
import com.menards.rental.functional.action.RentalAgreementSearchResultsAction;
import com.menards.rental.functional.action.RentalAgreementSummaryAction;
import com.menards.rental.functional.action.StoreUtilityLandingAction;

/**
 * User: Rasika Date: 22nd Jun, 2010 Time: 1:30 PM.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
public class LookupRentalAgreementTest extends BaseFunctionalTestCase {

	// Test to search for specific Agreement(with ph no,last name and first
	// name)

	/**
	 * Test to search specific agreement.
	 */
	public void testToSearchSpecificAgreement() {

		final RentalAgreementLookupAction rentalAgreementLookupAction = new StoreUtilityLandingAction(selenium).open()
		        .clickLookupRentalAgreement();

		final RentalAgreementSearchResultsAction rentalAgreementSearchResultsAction = rentalAgreementLookupAction
		        .typePhoneNumber("123-999-4567").typeLastName("Lane").typeFirstName("Geoff").clickSearch();

		final StoreUtilityLandingAction storeUtilityLandingAction = rentalAgreementSearchResultsAction.verifySearchResults(
		        "24578").verifySearchResults("Lane").verifySearchResults("Geoff").clickExit();

		storeUtilityLandingAction.verifyTextPresent("Electronic Rental Agreements - Store Rental Utility");

	}

	// Test to search for all Agreements with blank search criteria

	/**
	 * Test to search all agreement.
	 */
	public void testToSearchAllAgreement() {

		final RentalAgreementLookupAction rentalAgreementLookupAction1 = new StoreUtilityLandingAction(selenium).open()
		        .clickLookupRentalAgreement();

		final RentalAgreementSearchResultsAction rentalAgreementSearchResultsAction1 = rentalAgreementLookupAction1
		        .clickSearch();

		final StoreUtilityLandingAction storeUtilityLandingAction1 = rentalAgreementSearchResultsAction1
		        .verifySearchResults("Lane, Geoff").verifySearchResults("how r, Hi").clickExit();

		storeUtilityLandingAction1.verifyTextPresent("Electronic Rental Agreements - Store Rental Utility");

		// .VerifyAllAgreementsSearchResults();
	}

	// Test to search for existing rental agreement no.

	/**
	 * Test for rental agreement lookup.
	 */
	public void testForRentalAgreementLookup() {

		final RentalAgreementLookupAction rentalAgreementLookupAction1 = new StoreUtilityLandingAction(selenium).open()
		        .clickLookupRentalAgreement();

		final RentalAgreementSummaryAction rentalAgreementSummaryAction = rentalAgreementLookupAction1.typeAgreementNumber(
		        "1234-24578-003").clickLookup();

		rentalAgreementSummaryAction.verifyTextPage("Electronic Rental Agreements - Agreement Summary");
	}

	// Test to verify proper error message is displayed if agreement no. is not
	// found in the database

	/**
	 * Test to verify no search errors.
	 */
	public void testToVerifyNoSearchErrors() {

		final RentalAgreementLookupAction rentalAgreementLookupAction2 = new StoreUtilityLandingAction(selenium).open()
		        .clickLookupRentalAgreement();

		final StoreUtilityLandingAction storeUtilityLandingAction2 = rentalAgreementLookupAction2.typeAgreementNumber("XYZ")
		        .clickLookupForErrorMessage().verifyTextMessage(
		                "Could not find the agreement with the given search criteria").clickCancel();

		storeUtilityLandingAction2.verifyTextPresent("Electronic Rental Agreements - Store Rental Utility");
	}

}
