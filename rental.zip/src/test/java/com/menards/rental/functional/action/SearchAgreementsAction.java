/*
 * SearchAgreementsAction.java
 */
package com.menards.rental.functional.action;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * The Class SearchAgreementsAction.
 */
public class SearchAgreementsAction extends RentalLandingPageAction<SearchAgreementsAction> {

	/** The Constant AGREEMENT_NUMBER. */
	public static final String AGREEMENT_NUMBER = "1234-23456-001";
	
	/** The Constant AGREEMENT_NUMBER2. */
	public static final String AGREEMENT_NUMBER2 = "1234-24578-003";
	
	/** The Constant AGREEMENT_NUMBER_FROM_OTHER_STORE. */
	private static final String AGREEMENT_NUMBER_FROM_OTHER_STORE = "5432-25435-007";

	/** The Constant SELECT_BUTTON_SELECTOR. */
	private static final String SELECT_BUTTON_SELECTOR = "link=Select";
	
	/** The Constant SEARCH_BY_AGREEMENT_TB. */
	private static final String SEARCH_BY_AGREEMENT_TB = "id=agreementNumber";

	/**
	 * Instantiates a new search agreements action.
	 *
	 * @param selenium the selenium
	 */
	public SearchAgreementsAction(final Selenium selenium) {
		super(selenium);
	}

	/**
	 * Verify no search results.
	 *
	 * @return the search agreements action
	 */
	public SearchAgreementsAction verifyNoSearchResults() {
		assertFalse(selenium.getBodyText().contains(AGREEMENT_NUMBER));
		assertFalse(selenium.isElementPresent(SELECT_BUTTON_SELECTOR));
		return this;
	}

	/**
	 * Search all agreements.
	 *
	 * @return the search agreements action
	 */
	public SearchAgreementsAction searchAllAgreements() {
		selenium.click(Constants.ListAgreement.SEARCH_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Search by agreement number.
	 *
	 * @param agreementNumber the agreement number
	 * @return the search agreements action
	 */
	public SearchAgreementsAction searchByAgreementNumber(final String agreementNumber) {
		selenium.type(SEARCH_BY_AGREEMENT_TB, agreementNumber);
		selenium.click(Constants.ListAgreement.SEARCH_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Verify all search results.
	 *
	 * @return the search agreements action
	 */
	public SearchAgreementsAction verifyAllSearchResults() {
		assertTrue(selenium.getBodyText().contains(AGREEMENT_NUMBER));
		assertTrue(selenium.getBodyText().contains(AGREEMENT_NUMBER2));
		assertTrue(selenium.isElementPresent(SELECT_BUTTON_SELECTOR));
		verifyAgreementNotOnPage(AGREEMENT_NUMBER_FROM_OTHER_STORE);

		return this;
	}

	/**
	 * Verify search results.
	 *
	 * @param agreementNumber the agreement number
	 * @return the search agreements action
	 */
	public SearchAgreementsAction verifySearchResults(final String agreementNumber) {
		assertTrue(selenium.getBodyText().contains(agreementNumber));
		assertTrue(selenium.isElementPresent(SELECT_BUTTON_SELECTOR));
		verifyAgreementNotOnPage(AGREEMENT_NUMBER_FROM_OTHER_STORE);

		return this;
	}

	/**
	 * Verify agreement not on page.
	 *
	 * @param agreementNumber the agreement number
	 * @return the search agreements action
	 */
	public SearchAgreementsAction verifyAgreementNotOnPage(final String agreementNumber) {
		// Confirm we're limiting by the store number
		assertFalse(selenium.getBodyText().contains(agreementNumber));
		return this;
	}

	/**
	 * Verify search results.
	 *
	 * @return the search agreements action
	 */
	public SearchAgreementsAction verifySearchResults() {
		return verifySearchResults(AGREEMENT_NUMBER);
	}

	/**
	 * Select first agreement.
	 *
	 * @return the show agreement action
	 */
	public ShowAgreementAction selectFirstAgreement() {
		selenium.click(SELECT_BUTTON_SELECTOR);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new ShowAgreementAction(selenium);
	}
}
