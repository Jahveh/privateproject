/*
 * ConfirmRentalItemsAction.java
 */
package com.menards.rental.functional.action;

import static junit.framework.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/*
 *User: Rasika
 * Date: 21st Jun, 2010
 * Time: 11:48 AM
 */

/**
 * The Class ConfirmRentalItemsAction.
 */
public class ConfirmRentalItemsAction {
	
	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new confirm rental items action.
	 *
	 * @param selenium the selenium
	 */
	public ConfirmRentalItemsAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Verify text present.
	 *
	 * @param text the text
	 * @return the confirm rental items action
	 */
	public ConfirmRentalItemsAction verifyTextPresent(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Click submit.
	 *
	 * @return the store utility landing action
	 */
	public StoreUtilityLandingAction clickSubmit() {
		selenium.click(Constants.ConfirmRentalItemsPage.SUBMIT_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new StoreUtilityLandingAction(selenium);
	}

}
