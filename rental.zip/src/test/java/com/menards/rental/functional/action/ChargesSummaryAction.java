/*
 * ChargesSummaryAction.java
 */
package com.menards.rental.functional.action;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Jul 28, 2010 Time: 11:33:01 AM
 * To change this template use File | Settings | File Templates.
 */
public class ChargesSummaryAction {

	/** The selenium. */
	private final Selenium selenium;
	
	/** The Constant Rental_SKU_ID. */
	public static final String Rental_SKU_ID = "100-1014";
	
	/** The Constant Qty_Override_Value. */
	public static final String Qty_Override_Value = "1 + 1[2]";

	/**
	 * Instantiates a new charges summary action.
	 *
	 * @param selenium the selenium
	 */
	public ChargesSummaryAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Verify item record present.
	 *
	 * @return the charges summary action
	 */
	public ChargesSummaryAction verifyItemRecordPresent() {
		assertTrue(selenium.getBodyText().contains(Rental_SKU_ID));
		return this;
	}

	/**
	 * Verify charges summary screen text.
	 *
	 * @param text the text
	 * @return the charges summary action
	 */
	public ChargesSummaryAction verifyChargesSummaryScreenText(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Click qty override button.
	 *
	 * @return the qty override action
	 */
	public QtyOverrideAction clickQtyOverrideButton() {
		selenium.click(Constants.ChargesSummary.QTYOVERRIDE_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new QtyOverrideAction(selenium);
	}

	/**
	 * Verify overrided qty match.
	 *
	 * @return the charges summary action
	 */
	public ChargesSummaryAction verifyOverridedQtyMatch() {
		assertEquals(Qty_Override_Value, selenium.getText("//form[@id='summaryForm']/div[1]/table/tbody/tr[1]/td[5]"));
		return this;
	}

	/**
	 * Click save and print button.
	 *
	 * @return the charges summary action
	 */
	public ChargesSummaryAction clickSaveAndPrintButton() {
		selenium.click(Constants.ChargesSummary.SAVEPRINT_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Close print view.
	 *
	 * @return the charges summary action
	 */
	public ChargesSummaryAction closePrintView() {
		selenium.selectWindow(null);
		return this;
	}

	/**
	 * Click cancel button.
	 *
	 * @return the search agreements action
	 */
	public SearchAgreementsAction clickCancelButton() {
		selenium.click(Constants.ChargesSummary.CANCEL_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new SearchAgreementsAction(selenium);
	}

	/**
	 * Verify start screen text.
	 *
	 * @param text the text
	 * @return the search agreements action
	 */
	public SearchAgreementsAction verifyStartScreenText(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return new SearchAgreementsAction(selenium);
	}

}
