/*
 * QtyOverrideAction.java
 */
package com.menards.rental.functional.action;

import static org.junit.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Jul 28, 2010 Time: 12:25:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class QtyOverrideAction {

	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new qty override action.
	 *
	 * @param selenium the selenium
	 */
	public QtyOverrideAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Verify qty override screen text.
	 *
	 * @param text the text
	 * @return the qty override action
	 */
	public QtyOverrideAction verifyQtyOverrideScreenText(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Fill information.
	 *
	 * @return the qty override action
	 */
	public QtyOverrideAction FillInformation() {
		selenium.select("reason_0", "index=1");
		selenium.type("reasonText_0", "Reduce Override");
		selenium.type("incrementalTimeUnits_0", "2");
		selenium.select("managerName", "index=1");
		return this;
	}

	/**
	 * Click submit button.
	 *
	 * @return the charges summary action
	 */
	public ChargesSummaryAction clickSubmitButton() {
		selenium.click(Constants.QtyOverride.SUBMIT_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new ChargesSummaryAction(selenium);

	}
}
