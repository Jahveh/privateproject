/*
 * AddRentalItemsAction.java
 */
package com.menards.rental.functional.action;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/*
 *User: Rasika
 * Date: 21st Jun, 2010
 * Time: 11:48 AM
 */

/**
 * The Class AddRentalItemsAction.
 */
public class AddRentalItemsAction {
	
	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new adds the rental items action.
	 *
	 * @param selenium the selenium
	 */
	public AddRentalItemsAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Select sku.
	 *
	 * @param SKUValue the sKU value
	 * @return the adds the rental items action
	 */
	public AddRentalItemsAction selectSKU(final String SKUValue) {
		selenium.select(Constants.AddRentalItemsPage.SKU_ID, SKUValue);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Type manufacture serial number.
	 *
	 * @param SerialNumberValue the serial number value
	 * @return the adds the rental items action
	 */
	public AddRentalItemsAction typeManufactureSerialNumber(final String SerialNumberValue) {
		selenium.type(Constants.AddRentalItemsPage.SERIAL_NUMBER_ID, SerialNumberValue);
		return this;
	}

	/**
	 * Type description.
	 *
	 * @param DescriptionValue the description value
	 * @return the adds the rental items action
	 */
	public AddRentalItemsAction typeDescription(final String DescriptionValue) {
		selenium.type(Constants.AddRentalItemsPage.DESCRIPTION_ID, DescriptionValue);
		return this;
	}

	/**
	 * Type fleet number.
	 *
	 * @param FleetNumberValue the fleet number value
	 * @return the adds the rental items action
	 */
	public AddRentalItemsAction typeFleetNumber(final String FleetNumberValue) {
		selenium.type(Constants.AddRentalItemsPage.FLEET_NUMBER_ID, FleetNumberValue);
		return this;
	}

	/**
	 * Type vehicle make.
	 *
	 * @param VehicleMakeValue the vehicle make value
	 * @return the adds the rental items action
	 */
	public AddRentalItemsAction typeVehicleMake(final String VehicleMakeValue) {
		selenium.type(Constants.AddRentalItemsPage.VEHICLE_MAKE_ID, VehicleMakeValue);
		return this;
	}

	/**
	 * Type vehicle model.
	 *
	 * @param VehicleModelValue the vehicle model value
	 * @return the adds the rental items action
	 */
	public AddRentalItemsAction typeVehicleModel(final String VehicleModelValue) {
		selenium.type(Constants.AddRentalItemsPage.VEHICLE_MODEL_ID, VehicleModelValue);
		return this;
	}

	/**
	 * Type license number.
	 *
	 * @param LicenseNumberValue the license number value
	 * @return the adds the rental items action
	 */
	public AddRentalItemsAction typeLicenseNumber(final String LicenseNumberValue) {
		selenium.type(Constants.AddRentalItemsPage.LICENSE_NUMBER_ID, LicenseNumberValue);
		return this;
	}

	/**
	 * Type license state.
	 *
	 * @param LicenseStateValue the license state value
	 * @return the adds the rental items action
	 */
	public AddRentalItemsAction typeLicenseState(final String LicenseStateValue) {
		selenium.type(Constants.AddRentalItemsPage.LICENSE_STATE_ID, LicenseStateValue);
		return this;
	}

	/**
	 * Click continue.
	 *
	 * @return the confirm rental items action
	 */
	public ConfirmRentalItemsAction clickContinue() {
		selenium.click(Constants.AddRentalItemsPage.CONTINUE_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new ConfirmRentalItemsAction(selenium);
	}

}
