/*
 * StartAgreementAction.java
 */
package com.menards.rental.functional.action;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * The Class StartAgreementAction.
 */
public class StartAgreementAction extends RentalLandingPageAction<StartAgreementAction> {

	/**
	 * Instantiates a new start agreement action.
	 *
	 * @param selenium the selenium
	 */
	public StartAgreementAction(final Selenium selenium) {
		super(selenium);
	}

	/**
	 * Click start new agreement.
	 *
	 * @return the creates the agreement action
	 */
	public CreateAgreementAction clickStartNewAgreement() {
		selenium.click("start");
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new CreateAgreementAction(selenium);
	}

}
