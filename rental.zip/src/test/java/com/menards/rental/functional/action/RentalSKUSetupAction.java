/*
 * RentalSKUSetupAction.java
 */
package com.menards.rental.functional.action;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: deep Date: 14 Jun, 2010 Time: 11:45:32 AM To
 * change this template use File | Settings | File Templates. Updated by :
 * Rasika Date: 21st Jun 2010 Time: 12.30 PM
 */
public class RentalSKUSetupAction {

	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new rental sku setup action.
	 *
	 * @param selenium the selenium
	 */
	public RentalSKUSetupAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Select base sku.
	 *
	 * @param baseSKUValue the base sku value
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction selectBaseSKU(final String baseSKUValue) {
		selenium.select(Constants.RentalSKUSetupPage.BASE_SKU_ID, baseSKUValue);
		return this;
	}

	/**
	 * Select base sku time.
	 *
	 * @param baseSKUTimeValue the base sku time value
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction selectBaseSKUTime(final String baseSKUTimeValue) {
		selenium.select(Constants.RentalSKUSetupPage.BASE_SKU_TIME_ID, baseSKUTimeValue);
		return this;
	}

	/**
	 * Select additional sku.
	 *
	 * @param addSKUValue the add sku value
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction selectAdditionalSKU(final String addSKUValue) {
		selenium.select(Constants.RentalSKUSetupPage.ADDITIONAL_SKU_ID, addSKUValue);
		return this;
	}

	/**
	 * Select additional sku time.
	 *
	 * @param addSKUTimeValue the add sku time value
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction selectAdditionalSKUTime(final String addSKUTimeValue) {
		selenium.select(Constants.RentalSKUSetupPage.ADDITIONAL_SKU_TIME_ID, addSKUTimeValue);
		return this;
	}

	/**
	 * Select selling sku.
	 *
	 * @param sellSKUValue the sell sku value
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction selectSellingSKU(final String sellSKUValue) {
		selenium.select(Constants.RentalSKUSetupPage.SELLING_SKU_ID, sellSKUValue);
		return this;
	}

	/**
	 * Click sale allowed sku.
	 *
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction clickSaleAllowedSKU() {
		selenium.click(Constants.RentalSKUSetupPage.SALE_ALLOW_ID);
		return this;
	}

	/**
	 * Select surcharge sku.
	 *
	 * @param surchargeSKUValue the surcharge sku value
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction selectSurchargeSKU(final String surchargeSKUValue) {
		selenium.select(Constants.RentalSKUSetupPage.SURCHARGE_SKU_ID, surchargeSKUValue);
		return this;
	}

	/**
	 * Select min age.
	 *
	 * @param minAgeValue the min age value
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction selectMinAge(final String minAgeValue) {
		selenium.select(Constants.RentalSKUSetupPage.MIN_AGE_ID, minAgeValue);
		return this;
	}

	/**
	 * Type vendor email.
	 *
	 * @param vendorEmailValue the vendor email value
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction typeVendorEmail(final String vendorEmailValue) {
		selenium.type(Constants.RentalSKUSetupPage.VENDOR_EMAIL_ID, vendorEmailValue);
		return this;
	}

	/**
	 * Click drivers license.
	 *
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction clickDriversLicense() {
		selenium.click(Constants.RentalSKUSetupPage.DRIVERS_LICENSE_ID);
		return this;
	}

	/**
	 * Click insurance required.
	 *
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction clickInsuranceRequired() {
		selenium.click(Constants.RentalSKUSetupPage.INSURANCE_ID);
		return this;
	}

	/**
	 * Click damage waiver.
	 *
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction clickDamageWaiver() {
		selenium.click(Constants.RentalSKUSetupPage.DAMAGE_WAIVER_ID);
		return this;
	}

	/**
	 * Click usage tracking.
	 *
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction clickUsageTracking() {
		selenium.click(Constants.RentalSKUSetupPage.USAGE_TRACKING_ID);
		return this;
	}

	/**
	 * Type usage tracking text.
	 *
	 * @param usageTrackingTextValue the usage tracking text value
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction typeUsageTrackingText(final String usageTrackingTextValue) {
		selenium.type(Constants.RentalSKUSetupPage.USAGE_TRACKING_TEXT_ID, usageTrackingTextValue);
		return this;
	}

	/**
	 * Type rental prompt.
	 *
	 * @param rentalPromptValue the rental prompt value
	 * @return the rental sku setup action
	 */
	public RentalSKUSetupAction typeRentalPrompt(final String rentalPromptValue) {
		selenium.type(Constants.RentalSKUSetupPage.RENTAL_PROMPT_ID, rentalPromptValue);
		return this;
	}

	/**
	 * Click continue.
	 *
	 * @return the general office utility landing action
	 */
	public GeneralOfficeUtilityLandingAction clickContinue() {
		selenium.click(Constants.RentalSKUSetupPage.CONTINUE_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new GeneralOfficeUtilityLandingAction(selenium);
	}
}
