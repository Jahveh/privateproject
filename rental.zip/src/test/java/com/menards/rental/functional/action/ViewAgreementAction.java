/*
 * ViewAgreementAction.java
 */
package com.menards.rental.functional.action;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Jul 27, 2010 Time: 4:08:00 PM To
 * change this template use File | Settings | File Templates.
 */
public class ViewAgreementAction {

	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new view agreement action.
	 *
	 * @param selenium the selenium
	 */
	public ViewAgreementAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Verify view option selected.
	 *
	 * @return the search agreements action
	 */
	public SearchAgreementsAction verifyViewOptionSelected() {
		assertEquals("on", selenium.getValue("_view_agreement"));
		return new SearchAgreementsAction(selenium);
	}

	/**
	 * Click agreements select button.
	 *
	 * @param agreement_no the agreement_no
	 * @return the view agreement action
	 */
	public ViewAgreementAction clickAgreementsSelectButton(final String agreement_no) {
		selenium.click(agreement_no);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Verify view in screen text.
	 *
	 * @param text the text
	 * @return the rental agreement summary action
	 */
	public RentalAgreementSummaryAction verifyViewInScreenText(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return new RentalAgreementSummaryAction(selenium);
	}

}
