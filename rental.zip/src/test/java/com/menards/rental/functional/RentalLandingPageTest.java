/*
 * RentalLandingPageTest.java
 */
package com.menards.rental.functional;

import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.functional.action.SearchAgreementsAction;

/**
 * The Class RentalLandingPageTest.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
public class RentalLandingPageTest extends BaseFunctionalTestCase {

	/**
	 * Test list agreement.
	 */
	public void testListAgreement() {
		new SearchAgreementsAction(selenium).open().verifyAllSearchResults() // Search
																			 // results
																			 // displayed
																			 // by
																			 // default
		        .searchByAgreementNumber(SearchAgreementsAction.AGREEMENT_NUMBER) // Search
																				  // for
																				  // a
																				  // specific
																				  // agreement,
																				  // and
																				  // it's
																				  // found
																				  // but
																				  // others
																				  // are
																				  // not
		        .verifySearchResults(SearchAgreementsAction.AGREEMENT_NUMBER).verifyAgreementNotOnPage(
		                SearchAgreementsAction.AGREEMENT_NUMBER2);
	}
}
