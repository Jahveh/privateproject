/*
 * CancelAgreementTest.java
 */
package com.menards.rental.functional;

import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.functional.action.SearchAgreementsAction;
import com.menards.rental.functional.action.ShowAgreementAction;

/**
 * The Class CancelAgreementTest.
 *
 * @author geoff
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
public class CancelAgreementTest extends BaseFunctionalTestCase {

	/**
	 * Test cancel agreement.
	 *
	 * @throws Exception the exception
	 */
	public void testCancelAgreement() throws Exception {
		final ShowAgreementAction showAgreementAction = new SearchAgreementsAction(selenium).open().searchAllAgreements()
		        .verifySearchResults().selectFirstAgreement();

		showAgreementAction.clickCancelButton().verifySearchResults(SearchAgreementsAction.AGREEMENT_NUMBER2)
		        .verifySearchResults();
	}
}
