/*
 * StartReservationAction.java
 */
package com.menards.rental.functional.action;

import static org.junit.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Aug 9, 2010 Time: 3:18:19 PM To
 * change this template use File | Settings | File Templates.
 */

public class StartReservationAction extends RentalLandingPageAction<StartReservationAction> {

	/**
	 * Instantiates a new start reservation action.
	 *
	 * @param selenium the selenium
	 */
	public StartReservationAction(final Selenium selenium) {
		super(selenium);
	}

	/**
	 * Click start create reservation.
	 *
	 * @return the begin reservation action
	 */
	public BeginReservationAction clickStartCreateReservation() {
		selenium.click(Constants.StartReservation.START_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new BeginReservationAction(selenium);
	}

	/**
	 * Verify start search screen.
	 *
	 * @param text the text
	 * @return the start reservation action
	 */
	public StartReservationAction verifyStartSearchScreen(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Verify reservation displayed in list.
	 *
	 * @param text the text
	 * @return the start reservation action
	 */
	public StartReservationAction verifyReservationDisplayedInList(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Click reservation select button.
	 *
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction clickReservationSelectButton() {
		selenium.click(Constants.StartReservation.SELECT_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new ReservationSummaryAction(selenium);
	}

	/**
	 * Verify reservation guest name present.
	 *
	 * @param text the text
	 * @return the start reservation action
	 */
	public StartReservationAction verifyReservationGuestNamePresent(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Select view reservation option.
	 *
	 * @return the start reservation action
	 */
	public StartReservationAction selectViewReservationOption() {
		selenium.click(Constants.StartReservation.VIEWRESERVATION_RADIOBUTTON_ID);
		// selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Click cancel reservation option.
	 *
	 * @return the start reservation action
	 */
	public StartReservationAction clickCancelReservationOption() {
		selenium.click(Constants.StartReservation.CANCELRESERVATION_RADIOBUTTON_ID);
		return this;
	}

	/**
	 * Click cancel reservation select button.
	 *
	 * @return the start reservation action
	 */
	public StartReservationAction clickCancelReservationSelectButton() {
		selenium.click(Constants.StartReservation.SELECT_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Verify cancel popup message.
	 *
	 * @return the start reservation action
	 */
	public StartReservationAction verifyCancelPopupMessage() {
		assertTrue(selenium.getConfirmation().matches("^Do you want to cancel the Reservation[\\s\\S]$"));
		return this;
	}

	/**
	 * Click popup ok button.
	 *
	 * @return the start reservation action
	 */
	public StartReservationAction clickPopupOKButton() {
		selenium.getConfirmation();
		selenium.chooseOkOnNextConfirmation();
		return this;
	}

	/**
	 * Verify reservation not displayed in list.
	 *
	 * @param text the text
	 * @return the start reservation action
	 */
	public StartReservationAction verifyReservationNotDisplayedInList(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}
}
