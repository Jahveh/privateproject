/*
 * CancelAgreementAction.java
 */
package com.menards.rental.functional.action;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Jul 26, 2010 Time: 12:00:00 PM
 * To change this template use File | Settings | File Templates.
 */

public class CancelAgreementAction {

	/** The selenium. */
	private final Selenium selenium;
	
	/** The Constant AGREEMENT_NUMBER. */
	private static final String AGREEMENT_NUMBER = "1234-21235-001";

	/**
	 * Instantiates a new cancel agreement action.
	 *
	 * @param selenium the selenium
	 */
	public CancelAgreementAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Select cancel void option.
	 *
	 * @return the search agreements action
	 */
	public SearchAgreementsAction selectCancelVoidOption() {
		selenium.click(Constants.CancelAgreement.CANCEL_RADIOBUTTON_ID);
		return new SearchAgreementsAction(selenium);
	}

	/**
	 * Click agreements select button.
	 *
	 * @return the cancel agreement action
	 */
	public CancelAgreementAction clickAgreementsSelectButton() {
		selenium.click(Constants.CancelAgreement.SELECT_EXISTINGAGREEMENT_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Verify text present.
	 *
	 * @return the cancel agreement action
	 */
	public CancelAgreementAction verifyTextPresent() {
		assertTrue(selenium.getBodyText().contains("Are you sure you want to Cancel the following Rental Agreement?"));
		return this;
	}

	/**
	 * Click cancel agreement button.
	 *
	 * @return the search agreements action
	 */
	public SearchAgreementsAction clickCancelAgreementButton() {
		selenium.click(Constants.CancelAgreement.CANCELAGREEMENT_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new SearchAgreementsAction(selenium);
	}

	/**
	 * Verify agreement not in search results.
	 *
	 * @return the search agreements action
	 */
	public SearchAgreementsAction verifyAgreementNotInSearchResults() {
		assertFalse(selenium.getBodyText().contains(AGREEMENT_NUMBER));
		return new SearchAgreementsAction(selenium);
	}

}
