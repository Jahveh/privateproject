/*
 * CancelVoidAgreementTest.java
 */
package com.menards.rental.functional;

//import com.menards.rental.functional.action.CreateAgreementAction;
//import com.menards.rental.functional.action.GuestInformationAction;

import com.menards.rental.functional.action.CancelAgreementAction;
import com.menards.rental.functional.action.SearchAgreementsAction;
import com.menards.rental.functional.action.VoidAgreementAction;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Jul 26, 2010 Time: 12:00:00 PM
 * To change this template use File | Settings | File Templates.
 */

// Testcase for verifying Cancel/Void Agreement feature
public class CancelVoidAgreementTest extends BaseFunctionalTestCase {

	/**
	 * Test cancel existing agreement.
	 *
	 * @throws Exception the exception
	 */
	public void testCancelExistingAgreement() throws Exception {

		new SearchAgreementsAction(selenium).open();

		final SearchAgreementsAction searchAgreementsAction = new CancelAgreementAction(selenium).selectCancelVoidOption();

		final CancelAgreementAction cancelAgreementAction = new CancelAgreementAction(selenium)
		        .clickAgreementsSelectButton().verifyTextPresent();

		final SearchAgreementsAction searchAgreementsAction1 = new CancelAgreementAction(selenium)
		        .clickCancelAgreementButton();

		final SearchAgreementsAction searchAgreementsAction2 = new CancelAgreementAction(selenium)
		        .verifyAgreementNotInSearchResults();

	}

	/**
	 * Test void existing agreement.
	 *
	 * @throws Exception the exception
	 */
	public void testVoidExistingAgreement() throws Exception {

		new SearchAgreementsAction(selenium).open();

		final SearchAgreementsAction searchAgreementsAction = new CancelAgreementAction(selenium).selectCancelVoidOption();

		final VoidAgreementAction voidAgreementAction = new VoidAgreementAction(selenium).clickAgreementsSelectButton()
		        .verifyTextPresent().clickVoidAgreementButton().verifyErrorForApproval().selectApprover();

		final SearchAgreementsAction searchAgreementsAction1 = new CancelAgreementAction(selenium)
		        .clickCancelAgreementButton();

		final SearchAgreementsAction searchAgreementsAction2 = new VoidAgreementAction(selenium)
		        .verifyAgreementNotInSearchResults();

	}

}
