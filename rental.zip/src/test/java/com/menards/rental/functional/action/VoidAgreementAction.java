/*
 * VoidAgreementAction.java
 */
package com.menards.rental.functional.action;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Jul 26, 2010 Time: 3:00:00 PM To
 * change this template use File | Settings | File Templates.
 */

public class VoidAgreementAction {

	/** The selenium. */
	private final Selenium selenium;
	
	/** The Constant AGREEMENT_NUMBER. */
	private static final String AGREEMENT_NUMBER = "1234-23456-001";

	/**
	 * Instantiates a new void agreement action.
	 *
	 * @param selenium the selenium
	 */
	public VoidAgreementAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Click agreements select button.
	 *
	 * @return the void agreement action
	 */
	public VoidAgreementAction clickAgreementsSelectButton() {
		selenium.click(Constants.VoidAgreement.SELECT_EXISTINGAGREEMENT_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Verify text present.
	 *
	 * @return the void agreement action
	 */
	public VoidAgreementAction verifyTextPresent() {
		assertTrue(selenium.getBodyText().contains("Are you sure you want to Void the following Rental Agreement?"));
		return this;
	}

	/**
	 * Click void agreement button.
	 *
	 * @return the void agreement action
	 */
	public VoidAgreementAction clickVoidAgreementButton() {
		selenium.click(Constants.VoidAgreement.VOIDAGREEMENT_BUTTON_ID);
		return this;
	}

	/**
	 * Verify error for approval.
	 *
	 * @return the void agreement action
	 */
	public VoidAgreementAction verifyErrorForApproval() {
		assertTrue(selenium.getBodyText().contains("Void Approved By is required"));
		return this;
	}

	/**
	 * Select approver.
	 *
	 * @return the void agreement action
	 */
	public VoidAgreementAction selectApprover() {
		selenium.select("managerSelector", "index=1");
		return this;
	}

	/**
	 * Verify agreement not in search results.
	 *
	 * @return the search agreements action
	 */
	public SearchAgreementsAction verifyAgreementNotInSearchResults() {
		assertFalse(selenium.getBodyText().contains(AGREEMENT_NUMBER));
		return new SearchAgreementsAction(selenium);
	}

}
