/*
 * RentalAgreementSummaryAction.java
 */
package com.menards.rental.functional.action;

import static junit.framework.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * User: Rasika Date: 22nd Jun, 2010 Time: 1:30 PM.
 */

public class RentalAgreementSummaryAction {

	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new rental agreement summary action.
	 *
	 * @param selenium the selenium
	 */
	public RentalAgreementSummaryAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Verify text page.
	 *
	 * @param text the text
	 * @return the rental agreement summary action
	 */
	public RentalAgreementSummaryAction verifyTextPage(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	// verify print button is present when agreement status is other than
	// pending
	/**
	 * Verify print button.
	 *
	 * @return the rental agreement summary action
	 */
	public RentalAgreementSummaryAction verifyPrintButton() {
		assertTrue(selenium.isElementPresent(Constants.RentalAgreementSummary.PRINT_BUTTON_ID));
		return this;

	}

	/**
	 * Verify agreement no.
	 *
	 * @param text the text
	 * @return the rental agreement summary action
	 */
	public RentalAgreementSummaryAction verifyAgreementNo(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Click print button.
	 *
	 * @return the rental agreement summary action
	 */
	public RentalAgreementSummaryAction clickPrintButton() {
		selenium.click(Constants.RentalAgreementSummary.PRINT_BUTTON_ID);
		// selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Verify print reprot button.
	 *
	 * @return the rental agreement summary action
	 */
	public RentalAgreementSummaryAction verifyPrintReprotButton() {

		selenium.waitForPopUp(Constants.RentalAgreementSummary.WINDOW_ID, "5000");
		selenium.selectPopUp(Constants.RentalAgreementSummary.WINDOW_ID);

		assertTrue(selenium.isElementPresent("//input[@value='Print']"));
		return this;
	}

	/**
	 * Verify save print button.
	 *
	 * @return the rental agreement summary action
	 */
	public RentalAgreementSummaryAction verifySavePrintButton() {
		assertTrue(selenium.isElementPresent(Constants.RentalAgreementSummary.SAVEPRINT_BUTTON_ID));
		return this;
	}

	/**
	 * Click save print button.
	 *
	 * @return the rental agreement summary action
	 */
	public RentalAgreementSummaryAction clickSavePrintButton() {
		selenium.click(Constants.RentalAgreementSummary.SAVEPRINT_BUTTON_ID);
		// selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Verify print reprot button_ pending.
	 *
	 * @return the rental agreement summary action
	 */
	public RentalAgreementSummaryAction verifyPrintReprotButton_Pending() {

		selenium.waitForPageToLoad("3000");

		selenium.waitForPopUp("AgreementSummaryReport", "20000");
		selenium.selectPopUp(Constants.RentalAgreementSummary.WINDOW_ID);

		assertTrue(selenium.isElementPresent("//input[@value='Print']"));
		return this;
	}

}
