/*
 * BaseFunctionalTestCase.java
 */
package com.menards.rental.functional;

import java.io.IOException;
import java.util.Properties;

import org.h2.tools.RunScript;
import org.springframework.core.io.ClassPathResource;

import com.menards.rental.db.DB;
import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.SeleneseTestCase;

/**
 * Created by IntelliJ IDEA. User: deep Date: 18 May, 2010 Time: 1:36:31 PM To
 * change this template use File | Settings | File Templates.
 */
public abstract class BaseFunctionalTestCase extends SeleneseTestCase {
	
	/** The db. */
	final DB db = new DB();

    /**
     * {@inheritDoc}
     */
	@Override
	public void setUp() throws Exception {
		db.createSchema();
		db.cleanInsert();
		final Properties properties = new Properties();
		properties.load(new ClassPathResource("serverinfo.properties").getInputStream());
		setUp(properties.getProperty(Constants.URL), "*chrome");
	}

	/**
	 * Gets the form data values.
	 *
	 * @return the form data values
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	protected Properties getFormDataValues() throws IOException {
		final Properties properties = new Properties();
		properties.load(new ClassPathResource(getFormDataFileName()).getInputStream());
		return properties;
	}

	/**
	 * Gets the form data file name.
	 *
	 * @return the form data file name
	 */
	private String getFormDataFileName() {
		return this.getClass().getSimpleName() + "." + getName() + ".properties";
	}
}
