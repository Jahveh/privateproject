/*
 * GuestInformationAction.java
 */
package com.menards.rental.functional.action;

import java.util.Properties;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: deep Date: 18 May, 2010 Time: 2:14:26 PM To
 * change this template use File | Settings | File Templates.
 */
public class GuestInformationAction {
	
	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new guest information action.
	 *
	 * @param selenium the selenium
	 */
	public GuestInformationAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Fill form.
	 *
	 * @param formDataInputValues the form data input values
	 * @return the guest information action
	 */
	public GuestInformationAction fillForm(final Properties formDataInputValues) {
		for (final Object key : formDataInputValues.keySet()) {
			selenium.type(key.toString(), formDataInputValues.getProperty(key.toString()));
		}
		return this;
	}

	/**
	 * Click proceed.
	 *
	 * @return the show agreement action
	 */
	public ShowAgreementAction clickProceed() {
		selenium.click(Constants.PROCEED_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new ShowAgreementAction(selenium);
	}

	/**
	 * Search guest by phone number.
	 *
	 * @param phoneNumber the phone number
	 * @return the guest information action
	 */
	public GuestInformationAction searchGuestByPhoneNumber(final String phoneNumber) {
		selenium.type(Constants.GuestInformation.PHONE_NUMBER_ID, phoneNumber);
		selenium.click(Constants.GuestInformation.SEARCH_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		selenium.click("guest_2");
		return this;
	}
}
