/*
 * CreateAgreementAction.java
 */
package com.menards.rental.functional.action;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: deep Date: 18 May, 2010 Time: 2:13:45 PM To
 * change this template use File | Settings | File Templates.
 */
public class CreateAgreementAction {
	
	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new creates the agreement action.
	 *
	 * @param selenium the selenium
	 */
	public CreateAgreementAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Click continue.
	 *
	 * @return the guest information action
	 */
	public GuestInformationAction clickContinue() {
		selenium.click(Constants.PROCEED_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new GuestInformationAction(selenium);
	}

	/**
	 * Adds the item with bar code.
	 *
	 * @param barcode the barcode
	 * @return the adds the item popup action
	 */
	public AddItemPopupAction addItemWithBarCode(final String barcode) {
		selenium.type(Constants.CreateAgreement.BAR_CODE_ID, barcode);
		selenium.click(Constants.CreateAgreement.ADD_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new AddItemPopupAction(selenium);
	}
}
