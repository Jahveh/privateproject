/*
 * ReservationSummaryAction.java
 */
package com.menards.rental.functional.action;

import static junit.framework.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Aug 10, 2010 Time: 11:52:08 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReservationSummaryAction {

	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new reservation summary action.
	 *
	 * @param selenium the selenium
	 */
	public ReservationSummaryAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Verify reservation summary screen.
	 *
	 * @param text the text
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction verifyReservationSummaryScreen(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Verify item present.
	 *
	 * @param text the text
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction verifyItemPresent(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Click save print button.
	 *
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction clickSavePrintButton() {
		selenium.click(Constants.ReservationSummary.SAVEPRINT_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Click exit button.
	 *
	 * @return the start reservation action
	 */
	public StartReservationAction clickExitButton() {
		selenium.click(Constants.ReservationSummary.EXIT_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new StartReservationAction(selenium);

	}

	/**
	 * Verify reservation guest name displayed.
	 *
	 * @param text the text
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction verifyReservationGuestNameDisplayed(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Verify modify guest info screen.
	 *
	 * @param text the text
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction verifyModifyGuestInfoScreen(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Click modify guest info screen.
	 *
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction clickModifyGuestInfoScreen() {
		selenium.click(Constants.ReservationSummary.MODIFYGUESTINFO_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Click guest info continue button.
	 *
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction clickGuestInfoContinueButton() {
		selenium.click(Constants.ReservationSummary.MODIFYGUESTINFO_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Click add reservation notes button.
	 *
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction clickAddReservationNotesButton() {
		selenium.click(Constants.AddReserveNotesPopup.ADDNOTES_BUTTON_ID);
		// selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;

	}

	/**
	 * Verify add reservation notes popup.
	 *
	 * @param text the text
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction verifyAddReservationNotesPopup(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Click add reservation notes cancel button.
	 *
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction clickAddReservationNotesCancelButton() {
		selenium.click(Constants.AddReserveNotesPopup.CANCEL_BUTTON_ID);
		// selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;

	}

	/**
	 * Click add item button.
	 *
	 * @return the begin reservation action
	 */
	public BeginReservationAction clickAddItemButton() {
		selenium.click(Constants.ReservationSummary.ADDITEM_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new BeginReservationAction(selenium);
	}

	/**
	 * Click remove item button.
	 *
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction clickRemoveItemButton() {
		selenium.click(Constants.ReservationSummary.REMOVEITEM_BUTTON_NAME);
		return this;
	}

	/**
	 * Click remove popup cancel button.
	 *
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction clickRemovePopupCancelButton() {
		selenium.getConfirmation();
		selenium.chooseCancelOnNextConfirmation();
		return this;
	}

	/**
	 * Verify save print button exists.
	 *
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction verifySavePrintButtonExists() {
		assertTrue(selenium.isElementPresent(Constants.ReservationSummary.SAVEPRINT_BUTTON_ID));
		return this;
	}

	/**
	 * Verify exit button exists.
	 *
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction verifyExitButtonExists() {
		assertTrue(selenium.isElementPresent(Constants.ReservationSummary.EXIT_BUTTON_ID));
		return this;
	}
}
