/*
 * EnterGuestInformationTest.java
 */
package com.menards.rental.functional;

import java.util.Date;
import java.util.Properties;

import com.menards.rental.functional.action.CreateAgreementAction;
import com.menards.rental.functional.action.GuestInformationAction;
import com.menards.rental.functional.action.StartAgreementAction;
import com.menards.rental.functional.util.Constants;

/**
 * Created by IntelliJ IDEA. User: deep Date: 17 May, 2010 Time: 3:29:45 PM To
 * change this template use File | Settings | File Templates.
 */
public class EnterGuestInformationTest extends BaseFunctionalTestCase {

	/**
	 * Test create agreement and enter guest information.
	 *
	 * @throws Exception the exception
	 */
	public void testCreateAgreementAndEnterGuestInformation() throws Exception {
		final CreateAgreementAction createAgreementAction = new StartAgreementAction(selenium).open()
		        .clickStartNewAgreement();

		final GuestInformationAction guestInformationAction = createAgreementAction.addItemWithBarCode("104")
		        .enterDueByDate(new Date()).enterUsageTracking(22).clickContinue().addItemWithBarCode("106").enterDueByDate(
		                new Date()).enterUsageTracking(22).clickContinue().clickContinue();

		final Properties inputDataValues = getFormDataValues();
		guestInformationAction.searchGuestByPhoneNumber(
		        inputDataValues.getProperty(Constants.GuestInformation.PHONE_NUMBER_ID)).fillForm(inputDataValues)
		        .clickProceed().verifyPageRendered();
	}
}
