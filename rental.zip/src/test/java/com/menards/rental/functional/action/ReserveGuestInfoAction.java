/*
 * ReserveGuestInfoAction.java
 */
package com.menards.rental.functional.action;

import static org.junit.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Aug 9, 2010 Time: 5:32:22 PM To
 * change this template use File | Settings | File Templates.
 */
public class ReserveGuestInfoAction {

	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new reserve guest info action.
	 *
	 * @param selenium the selenium
	 */
	public ReserveGuestInfoAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Verify reserve gues info screen.
	 *
	 * @param text the text
	 * @return the reserve guest info action
	 */
	public ReserveGuestInfoAction verifyReserveGuesInfoScreen(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Fill form.
	 *
	 * @return the reserve guest info action
	 */
	public ReserveGuestInfoAction FillForm() {
		selenium.type(Constants.ReserveGuestInfo.PHONE_NUMBER_ID, "576-857-8748");
		selenium.type(Constants.ReserveGuestInfo.FIRST_NAME_ID, "TEST");
		selenium.type(Constants.ReserveGuestInfo.LAST_NAME_ID, "RESERVATION");
		selenium.click(Constants.ReserveGuestInfo.DATE_BIRTH_ID);
		selenium.click("//input[@name='_email_exists' and @value='YES']");
		selenium.type(Constants.ReserveGuestInfo.EMAIL_ADDRESS_ID, "test@123.com");
		return this;
	}

	/**
	 * Click continue button.
	 *
	 * @return the reservation summary action
	 */
	public ReservationSummaryAction clickContinueButton() {
		selenium.click(Constants.ReserveGuestInfo.CONTINUE_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new ReservationSummaryAction(selenium);
	}
}
