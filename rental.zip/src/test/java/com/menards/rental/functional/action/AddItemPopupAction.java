/*
 * AddItemPopupAction.java
 */
package com.menards.rental.functional.action;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: deep Date: 13 Jun, 2010 Time: 2:30:39 PM To
 * change this template use File | Settings | File Templates.
 */
public class AddItemPopupAction {
	
	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new adds the item popup action.
	 *
	 * @param selenium the selenium
	 */
	public AddItemPopupAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Enter due by date.
	 *
	 * @param date the date
	 * @return the adds the item popup action
	 */
	public AddItemPopupAction enterDueByDate(final Date date) {
		selenium.type(Constants.CreateAgreement.DUE_BY_ID, new SimpleDateFormat("MM/dd/yyyy hh:mm aaa").format(date));
		return this;
	}

	/**
	 * Click continue.
	 *
	 * @return the creates the agreement action
	 */
	public CreateAgreementAction clickContinue() {
		selenium.click(Constants.CreateAgreement.CONTINUE_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new CreateAgreementAction(selenium);
	}

	/**
	 * Enter usage tracking.
	 *
	 * @param mileageOrHours the mileage or hours
	 * @return the adds the item popup action
	 */
	public AddItemPopupAction enterUsageTracking(final int mileageOrHours) {
		selenium.type(Constants.CreateAgreement.USATE_NUMBER_ID, String.valueOf(mileageOrHours));
		return this;
	}
}
