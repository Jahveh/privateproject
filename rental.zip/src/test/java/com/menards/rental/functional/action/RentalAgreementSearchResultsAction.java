/*
 * RentalAgreementSearchResultsAction.java
 */
package com.menards.rental.functional.action;

import static junit.framework.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * User: Rasika Date: 22nd Jun, 2010 Time: 1:30 PM.
 */

public class RentalAgreementSearchResultsAction {

	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new rental agreement search results action.
	 *
	 * @param selenium the selenium
	 */
	public RentalAgreementSearchResultsAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Verify search results.
	 *
	 * @param text the text
	 * @return the rental agreement search results action
	 */
	public RentalAgreementSearchResultsAction verifySearchResults(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Click exit.
	 *
	 * @return the store utility landing action
	 */
	public StoreUtilityLandingAction clickExit() {
		selenium.click(Constants.RentalAgreementSearchResultsPage.EXIT_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new StoreUtilityLandingAction(selenium);
	}

	/**
	 * Click new search.
	 *
	 * @return the rental agreement lookup action
	 */
	public RentalAgreementLookupAction clickNewSearch() {
		selenium.click(Constants.RentalAgreementSearchResultsPage.NEW_SEARCH_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new RentalAgreementLookupAction(selenium);
	}

	/**
	 * Click view print.
	 *
	 * @return the rental agreement summary action
	 */
	public RentalAgreementSummaryAction clickViewPrint() {
		selenium.click(Constants.RentalAgreementSearchResultsPage.VIEW_PRINT_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new RentalAgreementSummaryAction(selenium);
	}
}
