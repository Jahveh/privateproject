/*
 * CreateNewProductTest.java
 */
package com.menards.rental.functional;

import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.functional.action.GeneralOfficeUtilityLandingAction;
import com.menards.rental.functional.action.RentalSKUSetupAction;

/**
 * Created by IntelliJ IDEA. User: deep Date: 14 Jun, 2010 Time: 11:33:28 AM To
 * change this template use File | Settings | File Templates. Updated by :
 * Rasika Date: 21st Jun 2010 Time: 12.30 PM
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
public class CreateNewProductTest extends BaseFunctionalTestCase {

	/**
	 * Test should create a new product.
	 */
	public void testShouldCreateANewProduct() {
		final RentalSKUSetupAction rentalSKUSetupAction = new GeneralOfficeUtilityLandingAction(selenium).open()
		        .clickRentalSKUSetup();

		final GeneralOfficeUtilityLandingAction generalOfficeUtilityLandingAction = rentalSKUSetupAction.selectBaseSKU(
		        "100-1012: Rug Doctor").selectBaseSKUTime("75 min").selectAdditionalSKU("100-1013: Rug Doctor")
		        .selectAdditionalSKUTime("75 min").selectSellingSKU("100-1014: Rug Doctor").clickSaleAllowedSKU()
		        .selectSurchargeSKU("100-1011: Fuel Surcharge").selectMinAge("18").typeVendorEmail("test@123.com")
		        .clickDriversLicense().clickInsuranceRequired().clickDamageWaiver().clickUsageTracking()
		        .typeUsageTrackingText("21 Miles").typeRentalPrompt("Comments are listed here").clickContinue();

		generalOfficeUtilityLandingAction.verifyTextPresent("Electronic Rental Agreements - General Office Utility");
	}

}
