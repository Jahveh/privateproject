/*
 * BeginReservationAction.java
 */
package com.menards.rental.functional.action;

import static org.junit.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Aug 9, 2010 Time: 12:54:14 PM To
 * change this template use File | Settings | File Templates.
 */
public class BeginReservationAction {

	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new begin reservation action.
	 *
	 * @param selenium the selenium
	 */
	public BeginReservationAction(final Selenium selenium) {
		this.selenium = selenium;

	}

	/**
	 * Verify begin reservation screen.
	 *
	 * @param text the text
	 * @return the begin reservation action
	 */
	public BeginReservationAction verifyBeginReservationScreen(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Select item to reserve.
	 *
	 * @return the begin reservation action
	 */
	public BeginReservationAction selectItemToReserve() {
		selenium.select("productId", "label=100-1014: Product-4");
		return this;
	}

	/**
	 * Click select button.
	 *
	 * @return the begin reservation action
	 */
	public BeginReservationAction clickSelectButton() {
		selenium.click(Constants.BeginReservation.SELECT_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Verify item status.
	 *
	 * @param text the text
	 * @return the begin reservation action
	 */
	public BeginReservationAction verifyItemStatus(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Click reserve button.
	 *
	 * @return the begin reservation action
	 */
	public BeginReservationAction clickReserveButton() {
		selenium.click(Constants.BeginReservation.RESERVE_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Verify add reservation popup.
	 *
	 * @param text the text
	 * @return the begin reservation action
	 */
	public BeginReservationAction verifyAddReservationPopup(final String text) {
		assertTrue(selenium.isElementPresent(text));
		return this;
	}

	/**
	 * Select chk out time.
	 *
	 * @return the begin reservation action
	 */
	public BeginReservationAction selectChkOutTime() {
		selenium.click("checkOutTimeStamp");
		return this;
	}

	/**
	 * Select return date.
	 *
	 * @return the begin reservation action
	 */
	public BeginReservationAction selectReturnDate() {
		selenium.click("checkInTimeStamp");
		return this;
	}

	/**
	 * Click popup reserve button.
	 *
	 * @return the reserve guest info action
	 */
	public ReserveGuestInfoAction clickPopupReserveButton() {
		selenium.click(Constants.AddReservePopup.RESERVE_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new ReserveGuestInfoAction(selenium);
	}

	/**
	 * Click cancel button.
	 *
	 * @return the start reservation action
	 */
	public StartReservationAction clickCancelButton() {
		selenium.click(Constants.BeginReservation.CANCEL_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new StartReservationAction(selenium);
	}
}
