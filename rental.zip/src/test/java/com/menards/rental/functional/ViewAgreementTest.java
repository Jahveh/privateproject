/*
 * ViewAgreementTest.java
 */
package com.menards.rental.functional;

import com.menards.rental.functional.action.RentalAgreementSummaryAction;
import com.menards.rental.functional.action.SearchAgreementsAction;
import com.menards.rental.functional.action.ViewAgreementAction;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Jul 28, 2010 Time: 4:02:48 PM To
 * change this template use File | Settings | File Templates.
 */

// view agreement and verify that 'Save and print' button is displayed for
// Pending agreements
// and only 'print' button is displayed for all the agreement with status other
// than Pending.
public class ViewAgreementTest extends BaseFunctionalTestCase {

	// verify only print button is present
	/**
	 * Test view agreement non pending.
	 *
	 * @throws Exception the exception
	 */
	public void testViewAgreementNonPending() throws Exception {

		new SearchAgreementsAction(selenium).open();

		final SearchAgreementsAction searchAgreementsAction = new ViewAgreementAction(selenium).verifyViewOptionSelected();

		final ViewAgreementAction viewAgreementAction = new ViewAgreementAction(selenium)
		        .clickAgreementsSelectButton("performActionOn_21234");

		final RentalAgreementSummaryAction rentalAgreementSummaryAction = new ViewAgreementAction(selenium)
		        .verifyViewInScreenText("Electronic Rental Agreements - Agreement Summary");

		rentalAgreementSummaryAction.verifyPrintButton();
		rentalAgreementSummaryAction.verifyAgreementNo("21234-001");
		rentalAgreementSummaryAction.clickPrintButton();
		rentalAgreementSummaryAction.verifyPrintReprotButton();

	}

	// verify save and print button is present
	/**
	 * Test view agreement pending.
	 *
	 * @throws Exception the exception
	 */
	public void testViewAgreementPending() throws Exception {

		new SearchAgreementsAction(selenium).open();

		final SearchAgreementsAction searchAgreementsAction = new ViewAgreementAction(selenium).verifyViewOptionSelected();

		final ViewAgreementAction viewAgreementAction = new ViewAgreementAction(selenium)
		        .clickAgreementsSelectButton("performActionOn_21235");

		final RentalAgreementSummaryAction rentalAgreementSummaryAction = new ViewAgreementAction(selenium)
		        .verifyViewInScreenText("Electronic Rental Agreements - Agreement Summary");

		rentalAgreementSummaryAction.verifySavePrintButton();
		rentalAgreementSummaryAction.verifyAgreementNo("21235-001");
		rentalAgreementSummaryAction.clickSavePrintButton();
		rentalAgreementSummaryAction.verifyPrintReprotButton_Pending();

	}

}
