/**
 *
 */
package com.menards.rental.functional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.functional.action.AddRentalItemsAction;
import com.menards.rental.functional.action.ConfirmRentalItemsAction;
import com.menards.rental.functional.action.StoreUtilityLandingAction;

/**
 * User: Rasika Date: 21st Jun, 2010 Time: 11:48 AM.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
public class CreateStoreItemTest extends BaseFunctionalTestCase {

	/**
	 * Test to create new store item.
	 */
	@Test
	public void testToCreateNewStoreItem() {
		final AddRentalItemsAction addRentalItemsAction = new StoreUtilityLandingAction(selenium).open()
		        .clickAddNewRentalItem();

		final ConfirmRentalItemsAction confirmRentalItemsAction = addRentalItemsAction.selectSKU("100-1011: Pick up Truck")
		        .typeManufactureSerialNumber("123").typeDescription("Test Vehicle Item").typeFleetNumber("450")
		        .typeVehicleMake("100").typeVehicleModel("abc120").typeLicenseNumber("asdf1234").typeLicenseState("MA")
		        .clickContinue();

		final StoreUtilityLandingAction storeUtilityLandingAction = new ConfirmRentalItemsAction(selenium)
		        .verifyTextPresent("Pick up Truck").verifyTextPresent("123").verifyTextPresent("Test Vehicle Item")
		        .verifyTextPresent("450").verifyTextPresent("100").verifyTextPresent("abc120").verifyTextPresent("asdf1234")
		        .verifyTextPresent("MA").clickSubmit();

		storeUtilityLandingAction.verifyTextPresent("Electronic Rental Agreements - Store Rental Utility");

	}

}
