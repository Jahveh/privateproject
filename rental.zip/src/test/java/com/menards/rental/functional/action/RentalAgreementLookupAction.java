/*
 * RentalAgreementLookupAction.java
 */
package com.menards.rental.functional.action;

//import com.menards.rental.functional.RentalAgreementSearchResultsAction;

import static org.junit.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * User: Rasika Date: 22nd Jun, 2010 Time: 1:30 PM.
 */

public class RentalAgreementLookupAction {
	
	/** The selenium. */
	private final Selenium selenium;

	/**
	 * Instantiates a new rental agreement lookup action.
	 *
	 * @param selenium the selenium
	 */
	public RentalAgreementLookupAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Type phone number.
	 *
	 * @param phonenumber the phonenumber
	 * @return the rental agreement lookup action
	 */
	public RentalAgreementLookupAction typePhoneNumber(final String phonenumber) {
		selenium.type(Constants.RentalAgreementLookupPage.PHONE_NUMBER_ID, phonenumber);
		return this;
	}

	/**
	 * Type last name.
	 *
	 * @param lastname the lastname
	 * @return the rental agreement lookup action
	 */
	public RentalAgreementLookupAction typeLastName(final String lastname) {
		selenium.type(Constants.RentalAgreementLookupPage.LAST_NAME_ID, lastname);
		return this;
	}

	/**
	 * Type first name.
	 *
	 * @param firstname the firstname
	 * @return the rental agreement lookup action
	 */
	public RentalAgreementLookupAction typeFirstName(final String firstname) {
		selenium.type(Constants.RentalAgreementLookupPage.FIRST_NAME_ID, firstname);
		return this;
	}

	/**
	 * Click search.
	 *
	 * @return the rental agreement search results action
	 */
	public RentalAgreementSearchResultsAction clickSearch() {
		selenium.click(Constants.RentalAgreementLookupPage.SEARCH_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new RentalAgreementSearchResultsAction(selenium);
	}

	/**
	 * Type agreement number.
	 *
	 * @param agreementno the agreementno
	 * @return the rental agreement lookup action
	 */
	public RentalAgreementLookupAction typeAgreementNumber(final String agreementno) {
		selenium.type(Constants.RentalAgreementLookupPage.AGREEMENT_NUMBER_ID, agreementno);
		return this;
	}

	/**
	 * Click lookup.
	 *
	 * @return the rental agreement summary action
	 */
	public RentalAgreementSummaryAction clickLookup() {
		selenium.click(Constants.RentalAgreementLookupPage.LOOKUP_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new RentalAgreementSummaryAction(selenium);
	}

	/**
	 * Click lookup for error message.
	 *
	 * @return the rental agreement lookup action
	 */
	public RentalAgreementLookupAction clickLookupForErrorMessage() {
		selenium.click(Constants.RentalAgreementLookupPage.LOOKUP_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Verify text message.
	 *
	 * @param text the text
	 * @return the rental agreement lookup action
	 */
	public RentalAgreementLookupAction verifyTextMessage(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Click cancel.
	 *
	 * @return the store utility landing action
	 */
	public StoreUtilityLandingAction clickCancel() {
		selenium.click(Constants.RentalAgreementLookupPage.CANCEL_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new StoreUtilityLandingAction(selenium);

	}

}
