/*
 * CheckInAgreementAction.java
 */
package com.menards.rental.functional.action;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.menards.rental.functional.util.Constants;
import com.thoughtworks.selenium.Selenium;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Jul 27, 2010 Time: 12:30:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class CheckInAgreementAction {

	/** The selenium. */
	private final Selenium selenium;
	
	/** The Constant Rental_SKU_ID. */
	public static final String Rental_SKU_ID = "100-1014";

	/**
	 * Instantiates a new check in agreement action.
	 *
	 * @param selenium the selenium
	 */
	public CheckInAgreementAction(final Selenium selenium) {
		this.selenium = selenium;
	}

	/**
	 * Select begin check in option.
	 *
	 * @return the search agreements action
	 */
	public SearchAgreementsAction selectBeginCheckInOption() {
		selenium.click(Constants.CheckInAgreement.CHECKIN_RADIOBUTTON_ID);
		return new SearchAgreementsAction(selenium);
	}

	/**
	 * Click agreements select button.
	 *
	 * @return the check in agreement action
	 */
	public CheckInAgreementAction clickAgreementsSelectButton() {
		selenium.click(Constants.CheckInAgreement.SELECT_EXISTINGAGREEMENT_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return this;
	}

	/**
	 * Verify begin check in screen text.
	 *
	 * @param text the text
	 * @return the check in agreement action
	 */
	public CheckInAgreementAction verifyBeginCheckInScreenText(final String text) {
		assertTrue(selenium.getBodyText().contains(text));
		return this;
	}

	/**
	 * Click checklist checkbox.
	 *
	 * @return the check list action
	 */
	public CheckListAction clickChecklistCheckbox() {
		selenium.click(Constants.CheckInAgreement.SELECT_ITEMCHECKBOX_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new CheckListAction(selenium);
	}

	/**
	 * Verify checkbox checked.
	 *
	 * @return the check in agreement action
	 */
	public CheckInAgreementAction verifyCheckboxChecked() {
		assertEquals("on", selenium.getValue(Constants.CheckInAgreement.SELECT_ITEMCHECKBOX_ID));
		return this;
	}

	/**
	 * Click continue check in button.
	 *
	 * @return the charges summary action
	 */
	public ChargesSummaryAction clickContinueCheckInButton() {
		selenium.click(Constants.CheckInAgreement.CONTINUECHECKIN_BUTTON_ID);
		selenium.waitForPageToLoad(Constants.MAX_TIME_OUT_FOR_PAGE_LOAD);
		return new ChargesSummaryAction(selenium);
	}

	/**
	 * Verify rental sku present.
	 *
	 * @return the check in agreement action
	 */
	public CheckInAgreementAction verifyRentalSKUPresent() {
		assertTrue(selenium.getBodyText().contains(Rental_SKU_ID));
		return this;
	}

	/**
	 * Verify item status.
	 *
	 * @return the check in agreement action
	 */
	public CheckInAgreementAction verifyItemStatus() {
		assertEquals("Returned", selenium.getText("//form[@id='checkinForm']/div[2]/table/tbody/tr/td[1]"));
		return this;
	}
}
