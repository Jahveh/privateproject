/*
 * ViewReservationTest.java
 */
package com.menards.rental.functional;

import com.menards.rental.functional.action.BeginReservationAction;
import com.menards.rental.functional.action.ReservationSummaryAction;
import com.menards.rental.functional.action.ReserveGuestInfoAction;
import com.menards.rental.functional.action.StartReservationAction;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Aug 10, 2010 Time: 1:24:18 PM To
 * change this template use File | Settings | File Templates.
 */
public class ViewReservationTest extends BaseFunctionalTestCase {

	/**
	 * Test to verify view reservation screen.
	 */
	public void testToVerifyViewReservationScreen() {

		final ReservationSummaryAction reservationSummaryAction = new StartReservationAction(selenium).open()
		        .selectViewReservationOption().verifyReservationGuestNamePresent("how r, Hi").clickReservationSelectButton();

		reservationSummaryAction.verifyReservationSummaryScreen("Electronic Reservations - Summary")
		        .verifyReservationGuestNameDisplayed("how r, Hi").verifyItemPresent("100-1008: Wasp Filberglass Blower")
		        .clickModifyGuestInfoScreen().verifyModifyGuestInfoScreen("Electronic Reservations - Guest Information"); // to
																														  // test
																														  // the
																														  // modifyguestinfo
																														  // button
																														  // click
																														  // opens
																														  // the
																														  // guest
																														  // info
																														  // screen

		final ReservationSummaryAction reservationSummaryAction1 = new ReserveGuestInfoAction(selenium)
		        .clickContinueButton();

		reservationSummaryAction1.verifyReservationSummaryScreen("Electronic Reservations - Summary"); // chk
																									   // that
																									   // we
																									   // are
																									   // back
																									   // to
																									   // summary
																									   // screen

		final BeginReservationAction beginReservationAction = new ReservationSummaryAction(selenium).clickAddItemButton();

		beginReservationAction.verifyBeginReservationScreen("Electronic Reservations - Begin Reservation");

		final StartReservationAction startReservationAction = beginReservationAction.clickCancelButton();

		final ReservationSummaryAction reservationSummaryAction2 = new StartReservationAction(selenium)
		        .selectViewReservationOption().verifyReservationGuestNamePresent("how r, Hi").clickReservationSelectButton();

		reservationSummaryAction2.verifyReservationSummaryScreen("Electronic Reservations - Summary")
		        .verifySavePrintButtonExists() // verify save and print button
											   // exists
		        .verifyExitButtonExists() // verify exit button exists
		        .clickRemoveItemButton().clickRemovePopupCancelButton(); // test
																		 // remove
																		 // popup
																		 // message
																		 // box
																		 // is
																		 // displayed

	}

	/**
	 * Test to verify add reservation notes button feature.
	 */
	public void testToVerifyAddReservationNotesButtonFeature() {

		final ReservationSummaryAction reservationSummaryAction = new StartReservationAction(selenium).open()
		        .selectViewReservationOption().verifyReservationGuestNamePresent("how r, Hi").clickReservationSelectButton();

		reservationSummaryAction.verifyReservationSummaryScreen("Electronic Reservations - Summary")
		        .clickAddReservationNotesButton().verifyAddReservationNotesPopup("Reservation Notes") // test
																									  // reservation
																									  // notes
																									  // popup
																									  // is
																									  // displayed
																									  // on
																									  // button
																									  // click
		        .clickAddReservationNotesCancelButton();

	}
}
