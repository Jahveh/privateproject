/*
 * CancelReservationTest.java
 */
package com.menards.rental.functional;

import com.menards.rental.functional.action.StartReservationAction;

/**
 * Created by IntelliJ IDEA. User: Rasika Date: Aug 11, 2010 Time: 12:12:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class CancelReservationTest extends BaseFunctionalTestCase {

	/**
	 * Test to verify cancel reservation.
	 */
	public void testToVerifyCancelReservation() {

		final StartReservationAction startReservationAction = new StartReservationAction(selenium).open()
		        .clickCancelReservationOption().verifyReservationGuestNamePresent("how r, Hi")
		        .clickCancelReservationSelectButton().clickPopupOKButton().verifyReservationNotDisplayedInList(
		                "No Reservations found");
	}

}
