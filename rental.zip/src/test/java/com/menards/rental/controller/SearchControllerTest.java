/*
 * SearchControllerTest.java
 */
package com.menards.rental.controller;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.whenNew;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.ui.ModelMap;

import com.menards.rental.builder.AgreementBuilder;
import com.menards.rental.controller.command.SearchAgreementsCommand;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.ArchivedAgreement;
import com.menards.rental.service.ContextService;

/**
 * User: deep Date: 14 Jun, 2010 Time: 2:40:03 PM.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest( { Agreement.class, SearchController.class })
public class SearchControllerTest {
	
	/** The controller. */
	private SearchController controller;
	
	/** The service. */
	private ContextService service;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		controller = new SearchController();
		service = mock(ContextService.class);
		controller.setContextService(service);
	}

	/**
	 * Should return the index view when index action is requested.
	 */
	@Test
	public void shouldReturnTheIndexViewWhenIndexActionIsRequested() {
		assertEquals("search/index", controller.index(new ModelMap()));
	}

	/**
	 * Should return empty search agreement object in the model map.
	 */
	@Test
	public void shouldReturnEmptySearchAgreementObjectInTheModelMap() throws Exception {
		final ModelMap modelMap = new ModelMap();
        final SearchAgreementsCommand searchAgreementsCommand = mock(SearchAgreementsCommand.class);
        whenNew(SearchAgreementsCommand.class).withNoArguments().thenReturn(searchAgreementsCommand);

		controller.index(modelMap);

        assertSame(searchAgreementsCommand, modelMap.get("searchAgreement"));
        verify(service).applyStoreContext(searchAgreementsCommand);
	}

	/**
	 * Should redirect user to view flow if agreement with the given number is found.
	 */
	@Test
	public void shouldRedirectUserToViewFlowIfAgreementWithTheGivenNumberIsFound() {
		final SearchAgreementsCommand mockedCommand = mock(SearchAgreementsCommand.class);
		final Agreement expectedAgreement = new AgreementBuilder().withId(1233L).buildAgreement();
		mockStatic(Agreement.class);

		when(mockedCommand.getAgreementNumber()).thenReturn("1234-400001-001");
		when(Agreement.findAgreementByAgreementNumber("1234-400001-001")).thenReturn(expectedAgreement);

		assertEquals("redirect:/agreementflow/show?agreementId=1233", controller.lookupAgreement(mockedCommand,
		        new ModelMap()));
	}

	/**
	 * Should populate error in model map if agreement with the given id is not found.
	 */
	@Test
	public void shouldPopulateErrorInModelMapIfAgreementWithTheGivenIdIsNotFound() {
		final SearchAgreementsCommand mockedCommand = mock(SearchAgreementsCommand.class);
		mockStatic(Agreement.class);

		when(mockedCommand.getAgreementNumber()).thenReturn("1234-400001-001");
		when(Agreement.findAgreementByAgreementNumber("1234-400001-001")).thenReturn(null);

		final ModelMap modelMap = new ModelMap();
		final String view = controller.lookupAgreement(mockedCommand, modelMap);
		assertTrue((Boolean) modelMap.get("agreementNotFound"));
		assertEquals("search/index", view);
	}

	/**
	 * Should render search results view if agreements matching the search criteria found.
	 */
	@Test
	public void shouldRenderSearchResultsViewIfAgreementsMatchingTheSearchCriteriaFound() {
		final SearchAgreementsCommand mockedCommand = mock(SearchAgreementsCommand.class);

		final ArrayList<ArchivedAgreement> agreements = new ArrayList<ArchivedAgreement>();
		agreements.add(new ArchivedAgreement());

		when(mockedCommand.findArchivedAgreementsBySearchCriteria()).thenReturn(agreements);

		assertEquals("search/results", controller.searchAgreements(mockedCommand, new ModelMap()));
	}

	/**
	 * Should add the agreements found via the search criteria in the model map.
	 */
	@Test
	public void shouldAddTheAgreementsFoundViaTheSearchCriteriaInTheModelMap() {
		final SearchAgreementsCommand mockedCommand = mock(SearchAgreementsCommand.class);

		final ArrayList<ArchivedAgreement> agreements = new ArrayList<ArchivedAgreement>();
		agreements.add(new ArchivedAgreement());

		when(mockedCommand.findArchivedAgreementsBySearchCriteria()).thenReturn(agreements);

		final ModelMap modelMap = new ModelMap();
		controller.searchAgreements(mockedCommand, modelMap);

		assertSame(agreements, modelMap.get("agreements"));
	}

	/**
	 * Should add error flag to the model map if no agreements found matching the search criteria.
	 */
	@Test
	public void shouldAddErrorFlagToTheModelMapIfNoAgreementsFoundMatchingTheSearchCriteria() {
		final SearchAgreementsCommand mockedCommand = mock(SearchAgreementsCommand.class);
		when(mockedCommand.findArchivedAgreementsBySearchCriteria()).thenReturn(new ArrayList<ArchivedAgreement>());

		final ModelMap modelMap = new ModelMap();
		controller.searchAgreements(mockedCommand, modelMap);

		assertTrue((Boolean) modelMap.get("agreementNotFound"));
	}

	/**
	 * Should return index view if agreement matching the search criteria not found.
	 */
	@Test
	public void shouldReturnIndexViewIfAgreementMatchingTheSearchCriteriaNotFound() {
		final SearchAgreementsCommand mockedCommand = mock(SearchAgreementsCommand.class);
		when(mockedCommand.findArchivedAgreementsBySearchCriteria()).thenReturn(new ArrayList<ArchivedAgreement>());

		assertEquals("search/index", controller.searchAgreements(mockedCommand, new ModelMap()));
	}
}
