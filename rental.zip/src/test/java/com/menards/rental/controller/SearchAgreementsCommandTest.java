/*
 * SearchAgreementsCommandTest.java
 */
package com.menards.rental.controller;

import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.menards.rental.domain.ArchivedAgreement;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.SimpleExpression;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.builder.GuestBuilder;
import com.menards.rental.controller.command.SearchAgreementsCommand;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementStatus;

/**
 * User: deep Date: 14 Jun, 2010 Time: 3:42:46 PM.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest( { Agreement.class, DetachedCriteria.class, AgreementStatus.class, ArchivedAgreement.class })
public class SearchAgreementsCommandTest {

	/**
	 * Should return the agreements matching the search criteria.
	 */
	@Test
	public void shouldReturnTheAgreementsMatchingTheSearchCriteria() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);
		final ArrayList<Agreement> expectedAgreements = new ArrayList<Agreement>();
		when(Agreement.findAgreementsBySearchCriteria(mockedDetachedCriteria)).thenReturn(expectedAgreements);

		assertSame(expectedAgreements, new SearchAgreementsCommand().findAgreementsBySearchCriteria());
	}

	/**
	 * Should create the search criteria with start date.
	 */
	@Test
	public void shouldCreateTheSearchCriteriaWithStartDate() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
		final Date expectedDate = new Date();
		searchAgreementsCommand.setStartDate(expectedDate);

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedDetachedCriteria).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				final Calendar calendar = Calendar.getInstance();
				calendar.setTime(expectedDate);
				return o.toString().contains("rentalDate>=" + calendar.toString());
			}
		}));
	}

	/**
	 * Should create the search criteria with store number.
	 */
	@Test
	public void shouldCreateTheSearchCriteriaWithStoreNumber() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedStoreNumberDetachedCriteria = mock(DetachedCriteria.class);
		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
		final int expectedStoreNumber = 12312;
		searchAgreementsCommand.setStoreNumber(expectedStoreNumber);

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedDetachedCriteria).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().equals("store.storeNumber=" + expectedStoreNumber);
			}
		}));
	}

	/**
	 * Should create the search criteria to show only pending and active agreements.
	 */
	@Test
	public void shouldCreateTheSearchCriteriaToShowOnlyPendingAndActiveAgreements() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		final AgreementStatus canceled = new AgreementStatus(AgreementStatus.Code.CANCELLED.getCode());
		final AgreementStatus voided = new AgreementStatus(AgreementStatus.Code.VOIDED.getCode());
		final AgreementStatus completed = new AgreementStatus(AgreementStatus.Code.COMPLETED.getCode());
		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);
		when(AgreementStatus.findVoided()).thenReturn(voided);
		when(AgreementStatus.findCancelled()).thenReturn(canceled);
		when(AgreementStatus.findCompleted()).thenReturn(completed);

		new SearchAgreementsCommand().findAgreementsBySearchCriteria();

		verify(mockedDetachedCriteria).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().equals("not agreementStatus in (N, V, C)");
			}
		}));
	}

	/**
	 * Should not add start date to search criteria if its null.
	 */
	@Test
	public void shouldNotAddStartDateToSearchCriteriaIfItsNull() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedDetachedCriteria, never()).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().startsWith("rentalDate>=");
			}
		}));
	}

	/**
	 * Should create the search criteria with end date.
	 */
	@Test
	public void shouldCreateTheSearchCriteriaWithEndDate() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
		final Date expectedDate = new Date();
		searchAgreementsCommand.setEndDate(expectedDate);

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedDetachedCriteria).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				final Calendar calendar = Calendar.getInstance();
				calendar.setTime(expectedDate);
                calendar.set(Calendar.HOUR, 23);
                calendar.set(Calendar.MINUTE, 59);
                calendar.set(Calendar.SECOND, 59);
				return o.toString().equals("rentalDate<=" + calendar.toString());
			}
		}));
	}

	/**
	 * Should not add end date to search criteria if its null.
	 */
	@Test
	public void shouldNotAddEndDateToSearchCriteriaIfItsNull() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedDetachedCriteria, never()).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().startsWith("rentalDate<=");
			}
		}));
	}

	/**
	 * Should create the search criteria with base sku number.
	 */
	@Test
	public void shouldCreateTheSearchCriteriaWithBaseSKUNumber() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
		searchAgreementsCommand.setBaseSKUNumber("123-123131");

		final DetachedCriteria mockedAgreementItemCriteria = mock(DetachedCriteria.class);
		final DetachedCriteria mockedItemCriteria = mock(DetachedCriteria.class);
		final DetachedCriteria mockedProductCriteria = mock(DetachedCriteria.class);
		final DetachedCriteria mockedBaseSKUCriteria = mock(DetachedCriteria.class);
		when(mockedDetachedCriteria.createCriteria("items")).thenReturn(mockedAgreementItemCriteria);
		when(mockedAgreementItemCriteria.createCriteria("item")).thenReturn(mockedItemCriteria);
		when(mockedItemCriteria.createCriteria("product")).thenReturn(mockedProductCriteria);
		when(mockedProductCriteria.createCriteria("skuInfo.baseSKU")).thenReturn(mockedBaseSKUCriteria);

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedBaseSKUCriteria).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().equals("value=123123131");
			}
		}));
	}

	/**
	 * Should not add base sku to search criteria if its null.
	 */
	@Test
	public void shouldNotAddBaseSKUToSearchCriteriaIfItsNull() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();

		searchAgreementsCommand.setBaseSKUNumber("");
		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedDetachedCriteria, never()).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().startsWith("value=");
			}
		}));
	}

	/**
	 * Should create the search criteria with guest phone number.
	 */
	@Test
	public void shouldCreateTheSearchCriteriaWithGuestPhoneNumber() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
		searchAgreementsCommand.setGuest(new GuestBuilder().withPhoneNumber("123-456-7654").buildGuest());

		final DetachedCriteria mockedGuestCriteria = mock(DetachedCriteria.class);
		when(mockedDetachedCriteria.createCriteria("guest")).thenReturn(mockedGuestCriteria);

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedGuestCriteria).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().equals("phoneNumber=123-456-7654");
			}
		}));
	}

	/**
	 * Should not add guest phone number to search criteria if its null.
	 */
	@Test
	public void shouldNotAddGuestPhoneNumberToSearchCriteriaIfItsNull() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
		searchAgreementsCommand.setGuest(new GuestBuilder().withPhoneNumber("").buildGuest());

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedDetachedCriteria, never()).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().startsWith("phoneNumber=");
			}
		}));
	}

	/**
	 * Should create the search criteria with guest first name.
	 */
	@Test
	public void shouldCreateTheSearchCriteriaWithGuestFirstName() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
		searchAgreementsCommand.setGuest(new GuestBuilder().withFirstName("Hello").buildGuest());

		final DetachedCriteria mockedGuestCriteria = mock(DetachedCriteria.class);
		when(mockedDetachedCriteria.createCriteria("guest")).thenReturn(mockedGuestCriteria);

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedGuestCriteria).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().equals("firstName ilike Hello");
			}
		}));
	}

	/**
	 * Should not add guest first name to search criteria if its null.
	 */
	@Test
	public void shouldNotAddGuestFirstNameToSearchCriteriaIfItsNull() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
		searchAgreementsCommand.setGuest(new GuestBuilder().withFirstName("").buildGuest());

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedDetachedCriteria, never()).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().startsWith("firstName");
			}
		}));
	}

	/**
	 * Should create the search criteria with guest last name.
	 */
	@Test
	public void shouldCreateTheSearchCriteriaWithGuestLastName() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
		searchAgreementsCommand.setGuest(new GuestBuilder().withLastName("World").buildGuest());

		final DetachedCriteria mockedGuestCriteria = mock(DetachedCriteria.class);
		when(mockedDetachedCriteria.createCriteria("guest")).thenReturn(mockedGuestCriteria);

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedGuestCriteria).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().equals("lastName ilike World");
			}
		}));
	}

	/**
	 * Should not add guest last name to search criteria if its null.
	 */
	@Test
	public void shouldNotAddGuestLastNameToSearchCriteriaIfItsNull() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
		searchAgreementsCommand.setGuest(new GuestBuilder().withLastName("").buildGuest());

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedDetachedCriteria, never()).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().startsWith("lastName");
			}
		}));
	}

	/**
	 * Should create the search criteria with guest company name.
	 */
	@Test
	public void shouldCreateTheSearchCriteriaWithGuestCompanyName() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
		searchAgreementsCommand.setGuest(new GuestBuilder().withCompanyName("SpiderLogic").buildGuest());

		final DetachedCriteria mockedGuestCriteria = mock(DetachedCriteria.class);
		when(mockedDetachedCriteria.createCriteria("guest")).thenReturn(mockedGuestCriteria);

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedGuestCriteria).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().equals("companyName ilike SpiderLogic");
			}
		}));
	}

	/**
	 * Should not add guest company name to search criteria if its null.
	 */
	@Test
	public void shouldNotAddGuestCompanyNameToSearchCriteriaIfItsNull() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
		searchAgreementsCommand.setGuest(new GuestBuilder().withCompanyName("").buildGuest());

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedDetachedCriteria, never()).add(argThat(new ArgumentMatcher<SimpleExpression>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().startsWith("companyName");
			}
		}));
	}

	/**
	 * Should add order by agreement number.
	 */
	@Test
	public void shouldAddOrderByAgreementNumber() {
		mockStatic(DetachedCriteria.class);

		final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);
		when(DetachedCriteria.forClass(Agreement.class)).thenReturn(mockedDetachedCriteria);
		when(mockedDetachedCriteria.createCriteria("store")).thenReturn(mockedDetachedCriteria);

		mockStatic(Agreement.class);
		mockStatic(AgreementStatus.class);

		final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();

		searchAgreementsCommand.findAgreementsBySearchCriteria();

		verify(mockedDetachedCriteria).addOrder(argThat(new ArgumentMatcher<Order>() {

			@Override
			public boolean matches(final Object o) {
				return o.toString().equals("agreementNumber asc");
			}
		}));
	}
    
    @Test
    public void shouldAddFormattedAgreementNumberToTheSearchCriteria() {
        final DetachedCriteria mockedDetachedCriteria = mock(DetachedCriteria.class);

        mockStatic(DetachedCriteria.class);
        when(DetachedCriteria.forClass(ArchivedAgreement.class)).thenReturn(mockedDetachedCriteria);

        mockStatic(ArchivedAgreement.class);

        final SearchAgreementsCommand searchAgreementsCommand = new SearchAgreementsCommand();
        searchAgreementsCommand.setAgreementNumber("49599009");

        searchAgreementsCommand.findArchivedAgreementsBySearchCriteria();

        verify(mockedDetachedCriteria).add(argThat(new ArgumentMatcher<SimpleExpression>() {

            @Override
            public boolean matches(final Object o) {
                return o.toString().equals("agreementNumber ilike %49599-009%");
            }
        }));
    }
}
