/*
 * IndexControllerTest.java
 */
package com.menards.rental.controller;

import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.powermock.api.mockito.PowerMockito.doAnswer;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.ui.ModelMap;

import com.menards.rental.builder.ItemBuilder;
import com.menards.rental.controller.command.SearchAgreementsCommand;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementStatus;
import com.menards.rental.domain.Item;
import com.menards.rental.domain.ReservationAgreement;
import com.menards.rental.domain.Store;
import com.menards.rental.service.ContextService;
import com.menards.rental.service.MenardsService;

/**
 * The Class IndexControllerTest.
 *
 * @author Geoff Lane
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest( { Agreement.class, Item.class, AgreementStatus.class, ReservationAgreement.class })
public class IndexControllerTest {

	/** The Constant STORE_NUMBER. */
	private static final Integer STORE_NUMBER = 1234;

	/** The controller. */
	private IndexController controller;
	
	/** The context service mock. */
	private ContextService contextServiceMock;
	
	/** The menards service mock. */
	private MenardsService menardsServiceMock;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		contextServiceMock = mock(ContextService.class);
		menardsServiceMock = mock(MenardsService.class);
		controller = new IndexController();
		controller.setContextService(contextServiceMock);
		controller.setMenardsService(menardsServiceMock);
	}

	/**
	 * Should return list view containing agreements in model map.
	 */
	@Test
	public void shouldReturnListViewContainingAgreementsInModelMap() {
		final SearchAgreementsCommand agreement = new SearchAgreementsCommand();

		final AgreementStatus canceled = new AgreementStatus(AgreementStatus.Code.CANCELLED.getCode());
		final AgreementStatus voided = new AgreementStatus(AgreementStatus.Code.VOIDED.getCode());

		mockStatic(AgreementStatus.class);
		when(AgreementStatus.findVoided()).thenReturn(voided);
		when(AgreementStatus.findCancelled()).thenReturn(canceled);

		mockStatic(Agreement.class);

		new SearchAgreementsCommand().findAgreementsBySearchCriteria();

		assertAgreementsFoundByStoreNumberAreSetInModelMap(agreement);
	}

	/**
	 * Should return agreements in the model map if search by agreement number.
	 */
	@Test
	public void shouldReturnAgreementsInTheModelMapIfSearchByAgreementNumber() {
		final SearchAgreementsCommand agreement = new SearchAgreementsCommand();
		agreement.setAgreementNumber("xxx123");

		final List<Agreement> agreements = new ArrayList<Agreement>();
		mockStatic(AgreementStatus.class);
		mockStatic(ReservationAgreement.class);
		mockStatic(Agreement.class);
		when(Agreement.findAgreementsBySearchCriteria(Matchers.any(DetachedCriteria.class))).thenReturn(agreements);
		whenApplyStoreNumber(agreement);

		final ModelMap modelMap = new ModelMap();
		controller.list(agreement, modelMap);

		assertSame(agreements, modelMap.get("agreements"));
	}

	/**
	 * Should return agreements in the model map if search by phone number.
	 */
	@Test
	public void shouldReturnAgreementsInTheModelMapIfSearchByPhoneNumber() {
		final SearchAgreementsCommand agreement = new SearchAgreementsCommand();
		agreement.setPhoneNumber("414-555-1212");

		final List<Agreement> agreements = new ArrayList<Agreement>();
		mockStatic(ReservationAgreement.class);
		mockStatic(AgreementStatus.class);
		mockStatic(Agreement.class);
		when(Agreement.findAgreementsBySearchCriteria(Matchers.any(DetachedCriteria.class))).thenReturn(agreements);
		whenApplyStoreNumber(agreement);

		final ModelMap modelMap = new ModelMap();
		controller.list(agreement, modelMap);

		assertSame(agreements, modelMap.get("agreements"));
	}

	/**
	 * Should return agreements in the model map if search by serial number.
	 */
	@Test
	public void shouldReturnAgreementsInTheModelMapIfSearchBySerialNumber() {
		final SearchAgreementsCommand agreement = new SearchAgreementsCommand();
		agreement.setSerialNumber(123L);

		mockStatic(ReservationAgreement.class);
		mockStatic(Item.class);
		when(Item.findItemBySerialNumber(agreement.getSerialNumber())).thenReturn(null);

		final List<Agreement> agreements = new ArrayList<Agreement>();
		mockStatic(AgreementStatus.class);
		mockStatic(Agreement.class);
		when(Agreement.findAgreementsBySearchCriteria(Matchers.any(DetachedCriteria.class))).thenReturn(agreements);
		whenApplyStoreNumber(agreement);

		final ModelMap modelMap = new ModelMap();
		controller.list(agreement, modelMap);

		assertSame(agreements, modelMap.get("agreements"));
	}

	/**
	 * Should return to index view with an error stating that agreement is not from this store.
	 */
	@Test
	public void shouldReturnToIndexViewWithAnErrorStatingThatAgreementIsNotFromThisStore() {
		final SearchAgreementsCommand agreement = new SearchAgreementsCommand();
		agreement.setSerialNumber(123L);
		agreement.setStoreNumber(1233);

		final Item item = new ItemBuilder().withStoreNumber(7866).buildItem();
		mockStatic(Item.class);
		when(Item.findItemBySerialNumber(agreement.getSerialNumber())).thenReturn(item);

		final ModelMap modelMap = new ModelMap();
		controller.list(agreement, modelMap);

		assertTrue((Boolean) modelMap.get("agreementNotFromThisStore"));
	}

	/**
	 * Should return to index view if item is not from this store.
	 */
	@Test
	public void shouldReturnToIndexViewIfItemIsNotFromThisStore() {
		final SearchAgreementsCommand agreement = new SearchAgreementsCommand();
		agreement.setSerialNumber(123L);
		agreement.setStoreNumber(1233);

		final Item item = new ItemBuilder().withStoreNumber(7866).buildItem();
		mockStatic(Item.class);
		when(Item.findItemBySerialNumber(agreement.getSerialNumber())).thenReturn(item);

		final ModelMap modelMap = new ModelMap();
		assertEquals("/index", controller.list(agreement, modelMap));
	}

	/**
	 * Should populate store information in the model map if item scanned is not from the same store.
	 */
	@Test
	public void shouldPopulateStoreInformationInTheModelMapIfItemScannedIsNotFromTheSameStore() {
		final SearchAgreementsCommand agreement = new SearchAgreementsCommand();
		agreement.setSerialNumber(123L);
		agreement.setStoreNumber(1233);

		final Item item = new ItemBuilder().withStoreNumber(7866).buildItem();

		mockStatic(Item.class);
		when(Item.findItemBySerialNumber(123L)).thenReturn(item);

		final Store expectedStore = new Store();
		when(menardsServiceMock.getStoreByStoreNumber(7866)).thenReturn(expectedStore);
		final ModelMap modelMap = new ModelMap();

		controller.list(agreement, modelMap);

		assertSame(expectedStore, modelMap.get("store"));
	}

	/**
	 * Should return all agreements in the model map if empty agreement number.
	 */
	@Test
	public void shouldReturnAllAgreementsInTheModelMapIfEmptyAgreementNumber() {
		final SearchAgreementsCommand agreement = new SearchAgreementsCommand();
		agreement.setAgreementNumber("");

		assertAgreementsFoundByStoreNumberAreSetInModelMap(agreement);
	}

	/**
	 * Should return all in the model map if null agreement number.
	 */
	@Test
	public void shouldReturnAllInTheModelMapIfNullAgreementNumber() {
		final SearchAgreementsCommand agreement = new SearchAgreementsCommand();
		agreement.setAgreementNumber(null);

		assertAgreementsFoundByStoreNumberAreSetInModelMap(agreement);
	}

	/**
	 * Should return the active reservation agreements in the model map.
	 */
	@Test
	public void shouldReturnTheActiveReservationAgreementsInTheModelMap() {
		final SearchAgreementsCommand agreement = new SearchAgreementsCommand();

		final ModelMap modelMap = new ModelMap();

		mockStatic(ReservationAgreement.class);
		mockStatic(AgreementStatus.class);
		mockStatic(Agreement.class);
		final List<ReservationAgreement> reservationAgreements = new ArrayList<ReservationAgreement>();
		final Store store = new Store();

		when(menardsServiceMock.getCurrentStore()).thenReturn(store);
		when(ReservationAgreement.findAllOpenReservationAgreementsByStore(store)).thenReturn(reservationAgreements);

		controller.list(agreement, modelMap);

		assertSame(reservationAgreements, modelMap.get("reservationAgreements"));
	}

	/**
	 * Assert agreements found by store number are set in model map.
	 *
	 * @param agreement the agreement
	 */
	private void assertAgreementsFoundByStoreNumberAreSetInModelMap(final SearchAgreementsCommand agreement) {
		final List<Agreement> agreements = new ArrayList<Agreement>();
		mockStatic(ReservationAgreement.class);
		mockStatic(AgreementStatus.class);
		mockStatic(Agreement.class);
		when(Agreement.findAgreementsBySearchCriteria(Matchers.any(DetachedCriteria.class))).thenReturn(agreements);
		whenApplyStoreNumber(agreement);

		final ModelMap modelMap = new ModelMap();
		controller.list(agreement, modelMap);

		assertSame(agreements, modelMap.get("agreements"));
	}

	/**
	 * When apply store number.
	 *
	 * @param agreement the agreement
	 */
	private void whenApplyStoreNumber(final SearchAgreementsCommand agreement) {
		doAnswer(new Answer() {
			public Object answer(final InvocationOnMock invocation) {
				final SearchAgreementsCommand a = (SearchAgreementsCommand) invocation.getArguments()[0];
				a.setStoreNumber(STORE_NUMBER);
				return null;
			}
		}).when(contextServiceMock).applyStoreContext(agreement);
	}

}
