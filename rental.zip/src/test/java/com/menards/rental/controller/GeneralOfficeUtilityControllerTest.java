/*
 * GeneralOfficeUtilityControllerTest.java
 */
package com.menards.rental.controller;

import static junit.framework.Assert.assertEquals;

import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: deep Date: 10 Jun, 2010 Time: 12:01:02 PM To
 * change this template use File | Settings | File Templates.
 */
public class GeneralOfficeUtilityControllerTest {

	/**
	 * Should return the index view for the general office utility controller.
	 */
	@Test
	public void shouldReturnTheIndexViewForTheGeneralOfficeUtilityController() {
		assertEquals("generalofficeutility/index", new GeneralOfficeUtilityController().index());
	}
}
