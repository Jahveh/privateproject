/*
 * StoreUtilityIndexControllerTest.java
 */
package com.menards.rental.controller;

import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.mock;

import org.junit.Before;
import org.junit.Test;
import org.springframework.ui.ModelMap;

import com.menards.rental.service.ContextService;
import com.menards.rental.service.ReportService;

/**
 * The Class StoreUtilityIndexControllerTest.
 */
public class StoreUtilityIndexControllerTest {

	/** The store utility index controller. */
	private StoreUtilityIndexController storeUtilityIndexController;
	
	/** The store report service. */
	private ReportService storeReportService;
	
	/** The context service. */
	private ContextService contextService;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		storeUtilityIndexController = new StoreUtilityIndexController();
		storeReportService = mock(ReportService.class);

		storeUtilityIndexController.setReportService(storeReportService);
		contextService = mock(ContextService.class);
		storeUtilityIndexController.setContextService(contextService);
	}

	/**
	 * Should return store index view when store utility is called.
	 */
	@Test
	public void shouldReturnStoreIndexViewWhenStoreUtilityIsCalled() {
		assertEquals("/storeutility/index", storeUtilityIndexController.storeUtility());
	}

	/**
	 * Should return request report view on request report.
	 */
	@Test
	public void shouldReturnRequestReportViewOnRequestReport() {
		assertEquals("/storeutility/requestreport", storeUtilityIndexController.requestReport(new ModelMap()));
	}

	/**
	 * Should set the instance of report command in the model map.
	 */
	@Test
	public void shouldSetTheInstanceOfReportCommandInTheModelMap() {
		final ModelMap modelMap = new ModelMap();
		storeUtilityIndexController.requestReport(modelMap);

		assertNotNull("report", modelMap.get("report"));
	}

    @Test
    public void shouldSyncTheInventoryWithTheKioskServer() {
        
    }

}
