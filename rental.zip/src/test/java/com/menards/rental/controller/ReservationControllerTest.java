/*
 * ReservationControllerTest.java
 */
package com.menards.rental.controller;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.domain.ReservationAgreement;

/**
 * Created by IntelliJ IDEA. User: deep Date: 27 Jul, 2010 Time: 1:17:49 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest(ReservationAgreement.class)
public class ReservationControllerTest {

	/**
	 * Should find the reservation with the given id and remove it from the db.
	 */
	@Test
	public void shouldFindTheReservationWithTheGivenIdAndRemoveItFromTheDB() {
		final ReservationAgreement mockedReservationAgreement = mock(ReservationAgreement.class);

		mockStatic(ReservationAgreement.class);
		when(ReservationAgreement.findReservationAgreement(1233L)).thenReturn(mockedReservationAgreement);

		new ReservationController().cancel(1233L);

		verify(mockedReservationAgreement).cancel();
	}

	/**
	 * Should redirect to index page after removing the reservation agreement.
	 */
	@Test
	public void shouldRedirectToIndexPageAfterRemovingTheReservationAgreement() {
		final ReservationAgreement mockedReservationAgreement = mock(ReservationAgreement.class);

		mockStatic(ReservationAgreement.class);
		when(ReservationAgreement.findReservationAgreement(1233L)).thenReturn(mockedReservationAgreement);

		assertEquals("redirect:/", new ReservationController().cancel(1233L));
	}

	/**
	 * Should redirect to index page if reservation agreement with the given id is not found.
	 */
	@Test
	public void shouldRedirectToIndexPageIfReservationAgreementWithTheGivenIdIsNotFound() {
		mockStatic(ReservationAgreement.class);

		assertEquals("redirect:/", new ReservationController().cancel(1233L));
	}
}
