/*
 * ItemControllerTest.java
 */
package com.menards.rental.controller;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.expectReturn;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.playback;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.mock.staticmock.MockStaticEntityMethods;
import org.springframework.ui.ModelMap;

import com.menards.rental.decorator.LazyItemList;
import com.menards.rental.domain.Item;
import com.menards.rental.domain.ItemStatus;
import com.menards.rental.domain.Product;
import com.menards.rental.service.ContextService;
import com.menards.rental.service.ItemService;
import com.menards.rental.service.ReservationService;
import com.menards.rental.service.external.KioskCommunicationException;
import com.menards.rental.utils.Constants;

/**
 * The Class ItemControllerTest.
 */
@MockStaticEntityMethods
@PrepareForTest(Product.class)
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
public class ItemControllerTest {

	/** The controller. */
	private ItemController controller;
	
	/** The context service. */
	private ContextService contextService;
	
	/** The reservation service. */
	private ReservationService reservationService;
    private ItemService itemService;

    /**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		controller = new ItemController();
		contextService = mock(ContextService.class);

		controller.setContextService(contextService);

		reservationService = mock(ReservationService.class);
		controller.setReservationService(reservationService);

        itemService = mock(ItemService.class);
        controller.setItemService(itemService);
	}

	/**
	 * Check up rental status of item returns update rental status.
	 */
	@Test
	public void checkUpRentalStatusOfItemReturnsUpdateRentalStatus() {

		final List<Product> productList = new ArrayList<Product>();
		Product.findAllProducts();
		expectReturn(productList);
		playback();

		final ModelMap modelMap = new ModelMap();

		assertEquals("/item/updateRentalStatus", controller.updateRentalStatusOfItem(modelMap));
		assertEquals(productList, modelMap.get("productList"));
	}

	/**
	 * Gets the list of rental items for product returns update rental status.
	 *
	 * @return the list of rental items for product returns update rental status
	 */
	@Test
	public void getListOfRentalItemsForProductReturnsUpdateRentalStatus() {
		final Long productId = 1L;
		final Integer storeNumber = 1234;

		final Product product = new Product();
		final List<Item> itemList = new ArrayList<Item>();
		final ModelMap modelMap = new ModelMap();
		final List<Product> productList = new ArrayList<Product>();
		final List<ItemStatus> statusList = new ArrayList<ItemStatus>();

		Product.findProduct(productId);
		expectReturn(product);
		Item.findAllItemsByProductAndStoreNumber(product, storeNumber);
		expectReturn(itemList);
		Product.findAllProducts();
		expectReturn(productList);
		ItemStatus.findAllItemStatuses();
		expectReturn(statusList);
		playback();

		when(contextService.getStoreNumber()).thenReturn(storeNumber);

		assertEquals("/item/updateRentalStatus", controller.getListOfRentalItemsForProduct(productId, modelMap));
		assertEquals(productList, modelMap.get("productList"));
		assertEquals(productId, modelMap.get("productId"));
		assertEquals(LazyItemList.class.toString(), modelMap.get("itemList").getClass().toString());
	}

	/**
	 * Update item status updates status.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldRedirectToStoreUtilityIfNoExceptionsAreThrownByTheService() throws Exception {
		final LazyItemList lazyItemList = new LazyItemList();

        doNothing().when(itemService).updateItemStatus(lazyItemList);

		assertEquals("redirect:/storeutility", controller.updateItemStatus(lazyItemList, new ModelMap()));
	}

    @Test
    public void shouldPopulateKioskErrorAndNavigateToUpdateItemStatusPageIfKioskExceptionIsThrown() {
        final LazyItemList itemList = new LazyItemList();

        mockStatic(Product.class);
        final ArrayList<Product> products = new ArrayList<Product>();
        when(Product.findAllProducts()).thenReturn(products);
        doThrow(new KioskCommunicationException(new RuntimeException())).when(itemService).updateItemStatus(itemList);

        final ModelMap map = new ModelMap();
        assertEquals("/item/updateRentalStatus", controller.updateItemStatus(itemList, map));
        assertTrue((Boolean) map.get(Constants.Agreement.KIOSK_ERROR));
        assertSame(products, map.get("productList"));
    }

    @Test
    public void shouldPopulateRentalExceededErrorAndNavigateToUpdateItemStatusPageIfIllegalStateIsThrown() {
        final LazyItemList itemList = new LazyItemList();

        doThrow(new IllegalStateException()).when(itemService).updateItemStatus(itemList);
        mockStatic(Product.class);
        final ArrayList<Product> products = new ArrayList<Product>();
        when(Product.findAllProducts()).thenReturn(products);

        final ModelMap map = new ModelMap();
        assertEquals("/item/updateRentalStatus", controller.updateItemStatus(itemList, map));
        assertTrue((Boolean) map.get(Constants.Agreement.RENTABLE_ITEMS_EXCEEDED_KIOSK_ERROR));
        assertSame(products, map.get("productList"));
    }
}
