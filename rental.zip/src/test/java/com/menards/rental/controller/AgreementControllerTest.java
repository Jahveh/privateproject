/*
 * AgreementControllerTest.java
 */
package com.menards.rental.controller;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.mockito.InOrder;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.mock.staticmock.MockStaticEntityMethods;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;

import com.menards.rental.barcode.Barcode;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementStatus;
import com.menards.rental.domain.StoreUserInfo;
import com.menards.rental.service.AgreementService;
import com.menards.rental.service.BarcodeService;
import com.menards.rental.service.BarcodeTypeStrategy;
import com.menards.rental.service.GuestService;
import com.menards.rental.service.external.KioskService;
import com.menards.rental.service.external.TeamService;
import com.menards.rental.utils.Constants;

/**
 * User: deep Date: 18 Jun, 2010 Time: 4:59:50 PM.
 */
@MockStaticEntityMethods
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*", "org.springframework.util.*"})
@PrepareForTest({Agreement.class, FileCopyUtils.class})
public class AgreementControllerTest {

    /**
     * The controller.
     */
    private AgreementController controller;

    /**
     * The kiosk Service
     */
    private KioskService mockedKioskService;
    private TeamService teamService;
    private AgreementService agreementService;
    private BarcodeService barcodeService;
    private BarcodeTypeStrategy code39BarcodeTypeStrategy;
    private BarcodeTypeStrategy interleaved25BarcodeTypeStrategy;
    private GuestService guestService;

    /**
     * Sets the up.
     */
    @Before
    public void setUp() {
        controller = new AgreementController();

        mockedKioskService = mock(KioskService.class);

        teamService = mock(TeamService.class);
        controller.setTeamService(teamService);
        agreementService = mock(AgreementService.class);
        controller.setAgreementService(agreementService);
        barcodeService = mock(BarcodeService.class);
        controller.setBarcodeService(barcodeService);
        code39BarcodeTypeStrategy = mock(BarcodeTypeStrategy.class);
        controller.setCode39BarcodeTypeStrategy(code39BarcodeTypeStrategy);
        interleaved25BarcodeTypeStrategy = mock(BarcodeTypeStrategy.class);
        controller.setInterleaved25BarcodeTypeStrategy(interleaved25BarcodeTypeStrategy);
        guestService = mock(GuestService.class);
        controller.setGuestService(guestService);
    }

    /**
     * Should redirect to home page if agreement with the given id not found.
     */
    @Test
    public void shouldRedirectToHomePageIfAgreementWithTheGivenIdNotFound() {
        mockStatic(Agreement.class);

        assertEquals("redirect:/", controller.cancelOrVoid(1231L, new ModelMap()));
    }

    /**
     * Should return the cancel agreement view if agreement status is not paid.
     */
    @Test
    public void shouldReturnTheCancelAgreementViewIfAgreementStatusIsNotPaid() {
        final Agreement agreement = mock(Agreement.class);
        mockStatic(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(agreement);

        final AgreementStatus status = mock(AgreementStatus.class);
        when(status.isPending()).thenReturn(true);

        when(agreement.getAgreementStatus()).thenReturn(status);
        assertEquals("agreement/cancel", controller.cancelOrVoid(1233L, new ModelMap()));
    }

    /**
     * Should return the void agreement view if agreement status is paid.
     */
    @Test
    public void shouldReturnTheVoidAgreementViewIfAgreementStatusIsPaid() {
        mockStatic(Agreement.class);
        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);
        when(mockedAgreement.isCompleted()).thenReturn(true);

        final AgreementStatus status = mock(AgreementStatus.class);
        when(status.isActive()).thenReturn(true);

        when(mockedAgreement.getAgreementStatus()).thenReturn(status);

        final ArrayList<StoreUserInfo> managers = new ArrayList<StoreUserInfo>();
        final TeamService mockedTeamService = mock(TeamService.class);
        when(mockedTeamService.getGeneralManagerForCurrentStore()).thenReturn(managers);
        controller.setTeamService(mockedTeamService);

        assertEquals("agreement/void", controller.cancelOrVoid(1233L, new ModelMap()));
    }

    /**
     * Test cancel agreement should redirect to home page if agreement with the given id not found.
     */
    @Test
    public void testCancelAgreementShouldRedirectToHomePageIfAgreementWithTheGivenIdNotFound() {
    	try{
	        mockStatic(Agreement.class);
	        final ModelMap modelMap = new ModelMap();
	        assertEquals("redirect:/", controller.cancelAgreement(1231L, modelMap));
    	}
    	catch (Exception e){
    		e.printStackTrace();
    	}
    }

    /**
     * Test cancel agreement.
     */
    @Test
    public void testCancelAgreement() {
        mockStatic(Agreement.class);
        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);

        final ModelMap modelMap = new ModelMap();
        controller.cancelAgreement(1233L, modelMap);

        Mockito.verify(mockedAgreement).cancelAgreement();
    }

    @Test
    public void testCancelAgreementShouldPopulateTheKioskErrorIfCancelingAgreementFailsToSendItToKiosk() {
        mockStatic(Agreement.class);
        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);

        final ModelMap modelMap = new ModelMap();
        when(agreementService.cancelAgreement(mockedAgreement)).thenReturn(false);

        controller.cancelAgreement(1233L, modelMap);

        assertTrue((Boolean) modelMap.get(Constants.Agreement.KIOSK_ERROR));
    }

    @Test
    public void testRemoveArchivedRecordsWhileCancellingTheAgreement() {
        mockStatic(Agreement.class);
        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);

        final ModelMap modelMap = new ModelMap();

        controller.cancelAgreement(1233L, modelMap);

        verify(agreementService).removeArchiveFor(argThat(new ArgumentMatcher<List<Agreement>>() {

            @Override
            public boolean matches(Object o) {
                return ((List<Agreement>)o).contains(mockedAgreement);
            }
        }));
    }

    @Test
    public void testCancelAgreementShouldNotPopulateTheKioskErrorIfCancelingAgreementSucceedsToSendItToKiosk() {
        mockStatic(Agreement.class);
        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);

        final ModelMap modelMap = new ModelMap();
        when(agreementService.cancelAgreement(mockedAgreement)).thenReturn(true);

        controller.cancelAgreement(1233L, modelMap);

        assertNull(modelMap.get(Constants.Agreement.KIOSK_ERROR));
    }

    /**
     * Test cancel agreement should redirect to home page after cancelling agreement.
     */
    @Test
    public void testCancelAgreementShouldRedirectToHomePageAfterCancellingAgreement() {
        mockStatic(Agreement.class);
        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);
        final ModelMap modelMap = new ModelMap();
        assertEquals("redirect:/", controller.cancelAgreement(1231L, modelMap));
    }

    /**
     * Test void agreement should redirect to home page if agreement with the given id not found.
     */
    @Test
    public void testVoidAgreementShouldRedirectToHomePageIfAgreementWithTheGivenIdNotFound() {
        mockStatic(Agreement.class);
        final ModelMap modelMap = new ModelMap();
        assertEquals("redirect:/", controller.voidAgreement(1231L, 7866, modelMap));
    }

    /**
     * Checks if is void approved by name being set while doing void agreement.
     */
    @Test
    public void isVoidApprovedByNameBeingSetWhileDoingVoidAgreement() {
        mockStatic(Agreement.class);
        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);
        final ModelMap modelMap = new ModelMap();
        controller.voidAgreement(1233L, 7866, modelMap);

        Mockito.verify(mockedAgreement).setVoidApprovedTeamMemberNumber(7866);
    }

    /**
     * Test void agreement.
     */
    @Test
    public void testVoidAgreement() {
        mockStatic(Agreement.class);
        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);
        final ModelMap modelMap = new ModelMap();
        controller.voidAgreement(1233L, 7866, modelMap);

        Mockito.verify(agreementService).voidAgreement(mockedAgreement);
    }

    @Test
    public void shouldPopulateKioskErrorIfVoidingAnAgreementFails() {
        mockStatic(Agreement.class);
        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);
        final ModelMap modelMap = new ModelMap();
        when(agreementService.sendVoidedAgreementToKiosk(Matchers.<Agreement>anyObject(), anyString())).thenReturn(false);

        final ArrayList<StoreUserInfo> managers = new ArrayList<StoreUserInfo>();
        when(teamService.getGeneralManagerForCurrentStore()).thenReturn(managers);
        controller.voidAgreement(1233L, 7866, modelMap);

        assertTrue((Boolean) modelMap.get("kioskError"));
        assertSame(managers, modelMap.get("managerNames"));
    }

    @Test
    public void shouldNotPopulateKioskErrorIfVoidingAnAgreementSucceeds() {
        mockStatic(Agreement.class);
        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);
        when(mockedAgreement.getAgreementNumber()).thenReturn("8888-42321-001");
        final ModelMap modelMap = new ModelMap();
        when(agreementService.sendVoidedAgreementToKiosk(mockedAgreement, "8888-42321-001")).thenReturn(true);
        controller.voidAgreement(1233L, 7866, modelMap);

        assertNull(modelMap.get("kioskError"));
    }

    /**
     * Test void agreement should redirect to home page after void agreement.
     */
    @Test
    public void testVoidAgreementShouldRedirectToHomePageAfterVoidAgreement() {
        mockStatic(Agreement.class);
        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);
        final ModelMap modelMap = new ModelMap();
        assertEquals("redirect:/", controller.voidAgreement(1231L, 7866, modelMap));
    }

    /**
     * Test report agreement returns agreement report view.
     */
    @Ignore
    @Test
    public void testReportAgreementReturnsAgreementReportView() {
        mockStatic(Agreement.class);
        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.loadFull(1233L)).thenReturn(mockedAgreement);

        final ModelMap modelMap = new ModelMap();

        assertEquals("/WEB-INF/views/reports/agreement.jspx", controller.report(1233L, modelMap));
        assertEquals(mockedAgreement, modelMap.get("agreement"));
    }

//    @Test
//    public void showPopulateTheTMNameFromNumberWhenReportIsRendered() {
//        mockStatic(Agreement.class);
//        final Agreement mockedAgreement = mock(Agreement.class);
//        //when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);
//        //when(Agreement.loadFull(1233L)).thenReturn(mockedAgreement);
//
//        controller.report(1233L, new ModelMap());
//        verify(agreementService).populateTMNameFromTMNumber(mockedAgreement);
//    }

    /**
     * Test agreement bar code written to response stream.
     *
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void testAgreementBarCodeWrittenToResponseStream() throws IOException {
        final Agreement agreement = new Agreement();
        agreement.setAgreementNumber("1234-23456-002");

        final byte[] byteImage = new byte[4];
        final Barcode barcode = new Barcode("image/x-png", byteImage);

        mockStatic(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(agreement);

        final BarcodeService barcodeService = mock(BarcodeService.class);
        controller.setBarcodeService(barcodeService);
        when(barcodeService.getPNGImageBarCode("23456002", code39BarcodeTypeStrategy)).thenReturn(barcode);

        mockStatic(FileCopyUtils.class);
        final HttpServletResponse response = mock(HttpServletResponse.class);
        when(response.getOutputStream()).thenReturn(mock(ServletOutputStream.class));

        controller.agreementBarCode("1233", response);
        verify(response).setContentType("image/x-png");
        verify(response).setContentLength(4);

        // verify that the static method was called
        PowerMockito.verifyStatic();
        FileCopyUtils.copy(barcode.getImage(), response.getOutputStream());
    }

    /**
     * Should do nothing if agreement with the given id is not found.
     */
    @Test
    public void shouldDoNothingIfAgreementWithTheGivenIdIsNotFound() {
        mockStatic(Agreement.class);

        when(Agreement.findAgreement(1231L)).thenReturn(null);
        controller.addNotes(1231, null);
    }

    /**
     * Should update the overall comment of the agreement.
     */
    @Test
    public void shouldUpdateTheOverallCommentOfTheAgreement() {
        mockStatic(Agreement.class);

        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);

        controller.addNotes(1233, "Hello World");

        verify(mockedAgreement).setOverallComment("Hello World");
    }

    /**
     * Should save the agreement when adding notes.
     */
    @Test
    public void shouldSaveTheAgreementWhenAddingNotes() {
        mockStatic(Agreement.class);

        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);

        controller.addNotes(1233, "Hello World");

        verify(mockedAgreement).persist();
    }

    /**
     * Should save the agreement after updating the overall comment when adding notes.
     */
    @Test
    public void shouldSaveTheAgreementAfterUpdatingTheOverallCommentWhenAddingNotes() {
        mockStatic(Agreement.class);

        final Agreement mockedAgreement = mock(Agreement.class);
        when(Agreement.findAgreement(1233L)).thenReturn(mockedAgreement);

        controller.addNotes(1233, "Hello World");

        final InOrder orderVerifier = inOrder(mockedAgreement);
        orderVerifier.verify(mockedAgreement).setOverallComment("Hello World");
        orderVerifier.verify(mockedAgreement).persist();
    }

//    @Test
//    public void shouldGenerateTheTransactionIdentifierBarcode() throws IOException {
//        final Agreement agreement = mock(Agreement.class);
//        mockStatic(Agreement.class);
//        when(Agreement.findAgreement(1233L)).thenReturn(agreement);
//        when(agreement.getFullTransactionIdentifier()).thenReturn("8888102710099999");
//
//        final HttpServletResponse response = mock(HttpServletResponse.class);
//        final Barcode barcode = mock(Barcode.class);
//        when(barcode.getImage()).thenReturn(new byte[0]);
//        
//        // This mock is not being invoked or is not working properly
//        when(barcodeService.getPNGImageBarCode("8888102710099999", interleaved25BarcodeTypeStrategy))
//                .thenReturn(barcode);
//
//        mockStatic(FileCopyUtils.class);
//        when(response.getOutputStream()).thenReturn(mock(ServletOutputStream.class));
//        controller.transactionBarCode("1233", response);
//
//        verify(barcodeService).getPNGImageBarCode("8888102710099999", interleaved25BarcodeTypeStrategy);
//    }

//    @Test
//    public void shouldPublishTheBarcodeToTheServletResponse() throws IOException {
//        final Agreement agreement = mock(Agreement.class);
//        mockStatic(Agreement.class);
//        when(Agreement.findAgreement(1233L)).thenReturn(agreement);
//        when(agreement.getFullTransactionIdentifier()).thenReturn("8888102710099999");
//
//        final HttpServletResponse response = mock(HttpServletResponse.class);
//        final Barcode barcode = mock(Barcode.class);
//        when(barcode.getImage()).thenReturn(new byte[0]);
//        
//        // This mock is not being invoked or is not working properly
//        when(barcodeService.getPNGImageBarCode("8888102710099999", interleaved25BarcodeTypeStrategy))
//                .thenReturn(barcode);
//        final byte[] imageBytes = new byte[2];
//        when(barcode.getImage()).thenReturn(imageBytes);
//        when(barcode.getImageType()).thenReturn("hello/world");
//        when(response.getOutputStream()).thenReturn(mock(ServletOutputStream.class));
//        controller.transactionBarCode("1233", response);
//
//        verify(response).setContentType("hello/world");
//        verify(response).setContentLength(2);
//
//        verifyStatic();
//        FileCopyUtils.copy(imageBytes, response.getOutputStream());
//
//    }
}
