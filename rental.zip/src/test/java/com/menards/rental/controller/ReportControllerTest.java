/*
 * ReportControllerTest.java
 */
package com.menards.rental.controller;

import static org.mockito.Mockito.mock;

import org.junit.Before;
import org.junit.Test;

import com.menards.rental.report.ReportPublisher;
import com.menards.rental.service.ContextService;
import com.menards.rental.service.ReportService;

/**
 * User: sudarshan Date: Jun 29, 2010 Time: 6:42:18 PM.
 */
public class ReportControllerTest {
	
	/** The report controller. */
	private ReportController reportController;
	
	/** The mocked report service. */
	private ReportService mockedReportService;
	
	/** The mocked report publisher. */
	private ReportPublisher mockedReportPublisher;
	
	/** The mocked context service. */
	private ContextService mockedContextService;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		reportController = new ReportController();

		mockedReportService = mock(ReportService.class);
		reportController.setReportService(mockedReportService);
		mockedReportPublisher = mock(ReportPublisher.class);
		mockedContextService = mock(ContextService.class);
		reportController.setContextService(mockedContextService);
	}

	/**
	 * Test something.
	 */
	@Test
	public void testSomething() {
		// FIXME
	}

}
