package com.menards.rental.db;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.dataset.DataSetException;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;

/**
 * This class is used to extract the database into plain data.xml for DbUnit purpose
 * This does not generate the XML in the insertion order at the moment so ordering
 * of XML is required to build the right insertion order
 * @author lalit
 *
 */
public class DBExportToXML {
	
	/** The Constant logger. */
	protected static final Log logger = LogFactory.getLog(DB.class);

	/**
	 * @param args
	 * @throws DataSetException 
	 */
	public static void main(String[] args) throws DataSetException {
     
	  DatabaseConnection connection= null;
	  
      try{
    	  final Properties properties = new Properties();
		  properties.load(new FileInputStream(new File("src/test/resources/database.properties")));
		Class.forName(properties.getProperty("database.driverClassName"));
		final Connection jdbcConnection = 
			  DriverManager.getConnection(properties.getProperty("database.url"), 
					                      properties.getProperty("database.username"), 
					                      properties.getProperty("database.password"));
		connection = new DatabaseConnection(jdbcConnection);
		// full database export
        IDataSet fullDataSet = connection.createDataSet();        
        FlatXmlDataSet.write(fullDataSet, new FileOutputStream("database.xml"));
	} catch (final ClassNotFoundException e) {
		logger.error(e.fillInStackTrace());
	} catch (final SQLException e) {
		logger.error(e.fillInStackTrace());
	} catch (final IOException e) {
		logger.error(e.fillInStackTrace());
	}finally{
		if(connection != null){
			try {
				connection.close();
			} catch (SQLException e) {
				logger.error(e.fillInStackTrace());
			}
		}
	}
}

}
