/*
 * DB.java
 */
package com.menards.rental.db;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dbunit.DatabaseUnitException;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.dataset.DataSetException;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.operation.DatabaseOperation;
import org.h2.tools.RunScript;
import org.h2.tools.Server;
import org.springframework.core.io.ClassPathResource;

/**
 * Created by IntelliJ IDEA. User: deep Date: 20 May, 2010 Time: 4:23:39 PM To
 * change this template use File | Settings | File Templates.
 */
public class DB {

	/** The Constant logger. */
	protected static final Log logger = LogFactory.getLog(DB.class.toString());
	
	/** The connection. */
	private static Connection jdbcConnection;
	private static DatabaseConnection connection;

	/** The data set. */
	private static FlatXmlDataSet dataSet;

	static {
		try {
			final Properties properties = new Properties();
			properties.load(new FileInputStream(new File("src/test/resources/database.properties")));
			String driverClass = properties.getProperty("database.driverClassName");
			Class.forName(driverClass);
			String url = properties.getProperty("database.url");
			String user = properties.getProperty("database.username");
			String pwd = properties.getProperty("database.password");
			jdbcConnection = DriverManager.getConnection(url, user, pwd);
			connection = new DatabaseConnection(jdbcConnection);
			ClassPathResource res = new ClassPathResource("data.xml");
			InputStream is = res.getInputStream();
			dataSet = new FlatXmlDataSet(is);
		} 
		catch (final ClassNotFoundException e) {
			logger.error(e.fillInStackTrace());
		} 
		catch (final SQLException e) {
			logger.error(e.fillInStackTrace());
		} 
		catch (final DataSetException e) {
			logger.error(e.fillInStackTrace());
		} 
		catch (final IOException e) {
			logger.error(e.fillInStackTrace());
		}
	}

	/**
	 * Clean insert.
	 */
	public void cleanInsert() {
		try {
			DatabaseOperation.CLEAN_INSERT.execute(connection, dataSet);
		} 
		catch (final DatabaseUnitException e) {
			logger.error(e.fillInStackTrace());
		} 
		catch (final SQLException e) {
			logger.error(e.fillInStackTrace());
		}
	}

	public void createSchema() {
		try {
			Reader schemaReader = new FileReader("src/test/resources/schema.sql");
			RunScript.execute(jdbcConnection, schemaReader);
		} 
		catch (final FileNotFoundException e) {
			logger.error(e.fillInStackTrace());
		}
		catch (final SQLException e) {
			logger.error(e.fillInStackTrace());
		}
	}
	
	/*
	 * Main method to insert the data into database without calling the test
	 * cases
	 */

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(final String[] args) throws IOException, SQLException {
		DB db = new DB();
		db.createSchema();
		db.cleanInsert();
		Server server = Server.createTcpServer().start();
		System.out.println("URL: jdbc:h2:" + server.getURL() + "/mem:test");
		System.out.println("Press [Enter] to stop.");
        System.in.read();
        System.out.println("Stopping server and closing the connection");
        server.stop();
	}
}
