/*
 * SimpleTimePeriodFormatterTest.java
 */
package com.menards.rental.format;

import static junit.framework.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: deep Date: 24 Jun, 2010 Time: 12:28:34 PM To
 * change this template use File | Settings | File Templates.
 */
public class SimpleTimePeriodFormatterTest {
	
	/** The formatter. */
	private SimpleTimePeriodFormatter formatter;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		formatter = new SimpleTimePeriodFormatter();
	}

	/**
	 * Should return only the hours part if the time period has no minutes part.
	 */
	@Test
	public void shouldReturnOnlyTheHoursPartIfTheTimePeriodHasNoMinutesPart() {
		assertEquals("3 Hr ", formatter.format(3.0));
	}

	/**
	 * Should return only the minutes part if time period has no hours part.
	 */
	@Test
	public void shouldReturnOnlyTheMinutesPartIfTimePeriodHasNoHoursPart() {
		assertEquals("27 Min. ", formatter.format(0.45));
	}

	/**
	 * Should return both the min and hours part if time period has both min and hours part.
	 */
	@Test
	public void shouldReturnBothTheMinAndHoursPartIfTimePeriodHasBothMinAndHoursPart() {
		assertEquals("5 Hr 27 Min. ", formatter.format(5.45));
	}

}
