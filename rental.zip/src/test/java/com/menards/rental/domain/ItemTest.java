/*
 * ItemTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.spy;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.stub;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.builder.ItemBuilder;

/**
 * Created by IntelliJ IDEA. User: deep Date: 11 May, 2010 Time: 3:51:29 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest( { Item.class, ItemStatus.class, Agreement.class, AgreementItem.class })
@PowerMockIgnore(value = { "org.apache.log4j.*" })
public class ItemTest {
	
	/** The item. */
	private Item item;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		item = new Item();
	}

	/**
	 * Should return rental sku.
	 */
	@Test
	public void shouldReturnRentalSKU() {
		final Product product = mock(Product.class);
		when(product.getFormattedBaseSKU()).thenReturn("100-10008");
		item.setProduct(product);

		assertEquals("100-10008", item.getRentalSKU());
	}

	/**
	 * Should return description from product.
	 */
	@Test
	public void shouldReturnDescriptionFromProduct() {
		final Product product = mock(Product.class);
		final String expectedDescription = "Hello Product Description";
		when(product.getDescription()).thenReturn(expectedDescription);

		item.setProduct(product);

		assertEquals(expectedDescription, item.getProduct().getDescription());
	}

	/**
	 * Should return true if item needs drivers license info.
	 */
	@Test
	public void shouldReturnTrueIfItemNeedsDriversLicenseInfo() {
		final Product mockedProduct = mock(Product.class);
		when(mockedProduct.isInsuranceAdditionalDriverLicenseRequired()).thenReturn(true);
		item.setProduct(mockedProduct);

		assertTrue(item.isInsuranceAdditionalDriverLicenseRequired());
	}

	/**
	 * Should return false if item does not need license info.
	 */
	@Test
	public void shouldReturnFalseIfItemDoesNotNeedLicenseInfo() {
		item.setProduct(mock(Product.class));

		assertFalse(item.isInsuranceAdditionalDriverLicenseRequired());
	}

	/**
	 * Should return false if item status is not available.
	 */
	@Test
	public void shouldReturnFalseIfItemStatusIsNotAvailable() {
		item.setItemStatus(mock(ItemStatus.class));
		assertFalse(item.isAvailable());
	}

	/**
	 * Should return true if item status is available.
	 */
	@Test
	public void shouldReturnTrueIfItemStatusIsAvailable() {
		final ItemStatus mockedItemStatus = mock(ItemStatus.class);

		when(mockedItemStatus.isAvailable()).thenReturn(true);

		item.setItemStatus(mockedItemStatus);
		assertTrue(item.isAvailable());
	}

	/**
	 * Should return false if item status is not available.
	 */
	@Test
	public void shouldReturnFalseIfItemStatusIsNotRented() {
		item.setItemStatus(mock(ItemStatus.class));
		assertFalse(item.isRented());
	}

	/**
	 * Should return true if item status is available.
	 */
	@Test
	public void shouldReturnTrueIfItemStatusIsRented() {
		final ItemStatus mockedItemStatus = mock(ItemStatus.class);

		when(mockedItemStatus.isRented()).thenReturn(true);

		item.setItemStatus(mockedItemStatus);
		assertTrue(item.isRented());
	}

	/**
	 * Should return true if serial numbers match.
	 */
	@Test
	public void shouldReturnTrueIfSerialNumbersMatch() {
		assertTrue(new ItemBuilder().withSerialNumber(100L).buildItem().matches(100L));
	}

	/**
	 * Should return false if serial numbers dont match.
	 */
	@Test
	public void shouldReturnFalseIfSerialNumbersDontMatch() {
		assertFalse(new ItemBuilder().withSerialNumber(108L).buildItem().matches(100L));
	}

	/**
	 * Return null for null or invalid serial number.
	 */
	@Test
	public void returnNullForNullOrInvalidSerialNumber() {
		assertNull(Item.findItemBySerialNumber(null));
		assertNull(Item.findItemBySerialNumber(0L));
	}

	/**
	 * Should update the item status to available.
	 */
	@Test
	public void shouldUpdateTheItemStatusToAvailable() {
		final ItemStatus expectedStatus = new ItemStatus();

		mockStatic(ItemStatus.class);
		when(ItemStatus.findAvailable()).thenReturn(expectedStatus);

		item = spy(item);
		doNothing().when(item).merge();

		item.actualCheckin();

		assertSame(expectedStatus, item.getItemStatus());
	}

	/**
	 * Should merge the item while actual checkin.
	 */
	@Test
	public void shouldMergeTheItemWhileActualCheckin() {
		mockStatic(ItemStatus.class);

		item = spy(item);
		doNothing().when(item).merge();

		item.actualCheckin();

		verify(item).merge();
	}

	/**
	 * Should return true if guest meets the minimum age requirement.
	 */
	@Test
	public void shouldReturnTrueIfGuestMeetsTheMinimumAgeRequirement() {
		final Agreement agreement = new Agreement();
		final Product mockedProduct = mock(Product.class);
		when(mockedProduct.isDriverAgeGreaterThanMinimumRentalAge(agreement)).thenReturn(true);

		item.setProduct(mockedProduct);

		assertTrue(item.isDriverAgeGreaterThanMinimumRentalAge(agreement));
	}

	/**
	 * Should return false if guest does not meet the minimum age requirement.
	 */
	@Test
	public void shouldReturnFalseIfGuestDoesNotMeetTheMinimumAgeRequirement() {
		final Agreement agreement = new Agreement();
		final Product mockedProduct = mock(Product.class);
		when(mockedProduct.isDriverAgeGreaterThanMinimumRentalAge(agreement)).thenReturn(false);

		item.setProduct(mockedProduct);

		assertFalse(item.isDriverAgeGreaterThanMinimumRentalAge(agreement));
	}

	/**
	 * Return item when serial number is valid.
	 */
	@Test
	public void returnItemWhenSerialNumberIsValid() {
		final EntityManager entityManager = mock(EntityManager.class);
		stub(method(Item.class, "entityManager")).andReturn(entityManager);

		final Item item = new Item();

		final Query query = mock(Query.class);

		when(entityManager.createQuery(Matchers.anyString())).thenReturn(query);
		when(query.setParameter("serialNumber", 123L)).thenReturn(query);
		when(query.getSingleResult()).thenReturn(item);

		assertEquals(item, Item.findItemBySerialNumber(123L));
	}

	/**
	 * Return null when serial number is invalid.
	 */
	@Test
	public void returnNullWhenSerialNumberIsInvalid() {
		final Item item = mock(Item.class);
		mockStatic(Item.class);
		final EntityManager entityManager = mock(EntityManager.class);
		final Query query = mock(Query.class);

		stub(method(Item.class, "entityManager")).andReturn(entityManager);

		when(entityManager.createQuery(Matchers.anyString())).thenReturn(query);
		when(query.setParameter("serialNumber", 123L)).thenReturn(query);
		when(query.getSingleResult()).thenReturn(item);
		when(query.getSingleResult()).thenThrow(new NonUniqueResultException());
		assertEquals(null, Item.findItemBySerialNumber(123L));

	}

	/**
	 * Should return true if product has any reservations.
	 */
	@Test
	public void shouldReturnTrueIfProductHasAnyReservations() {
		final Product mockedProduct = mock(Product.class);
		when(mockedProduct.hasAnyReservationsFor(1233)).thenReturn(true);

		assertTrue(new ItemBuilder().withStoreNumber(1233).withProduct(mockedProduct).buildItem().hasAnyReservations());
	}

	/**
	 * Should return false if product does not have any reservations.
	 */
	@Test
	public void shouldReturnFalseIfProductDoesNotHaveAnyReservations() {
		final Product mockedProduct = mock(Product.class);
		when(mockedProduct.hasAnyReservationsFor(anyInt())).thenReturn(false);

		assertFalse(new ItemBuilder().withProduct(mockedProduct).buildItem().hasAnyReservations());
	}

	/**
	 * Should return true if product has overlapping reservations.
	 */
	@Test
	public void shouldReturnTrueIfProductHasOverlappingReservations() {
		final Product mockedProduct = mock(Product.class);
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();
		when(mockedProduct.hasOverlappingReservationsFor(1233, outDate, inDate)).thenReturn(true);

		assertTrue(new ItemBuilder().withStoreNumber(1233).withProduct(mockedProduct).buildItem()
		        .hasOverlappingReservations(outDate, inDate));
	}

	/**
	 * Should return false if product does not have overlapping reservations.
	 */
	@Test
	public void shouldReturnFalseIfProductDoesNotHaveOverlappingReservations() {
		final Product mockedProduct = mock(Product.class);
		when(
		        mockedProduct.hasOverlappingReservationsFor(anyInt(), Matchers.<Calendar> anyObject(), Matchers
		                .<Calendar> anyObject())).thenReturn(false);

		assertFalse(new ItemBuilder().withProduct(mockedProduct).buildItem().hasOverlappingReservations(null, null));
	}

	/**
	 * Should find all items based on store number product and item status.
	 */
	@Test
	public void shouldFindAllItemsBasedOnStoreNumberProductAndItemStatus() {
		final ArrayList<Item> expectedItems = new ArrayList<Item>();
		stub(
		        method(Item.class, "findAllItemsByStoreNumberAndProductAndItemStatus", Integer.class, Product.class,
		                ItemStatus.class)).andReturn(expectedItems);

		assertSame(expectedItems, Item.findAllItemsByStoreNumberAndProductAndItemStatus(1233, new Product(),
		        new ItemStatus()));
	}

	/**
	 * Should count overlapping reservations.
	 */
	@Test
	public void shouldCountOverlappingReservations() {
		final Product mockedProduct = mock(Product.class);
		item = new ItemBuilder().withProduct(mockedProduct).withStoreNumber(7866).buildItem();

		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

		when(mockedProduct.countActuallyOverlappingReservationsForStore(7866, outDate, inDate)).thenReturn(9);

		assertEquals(9, item.countActuallyOverlappingReservations(outDate, inDate));
	}

	/**
	 * Should get all the overlapping reservations for the given product.
	 */
	@Test
	public void shouldGetAllTheOverlappingReservationsForTheGivenProduct() {
		final Product mockedProduct = mock(Product.class);
		item = new ItemBuilder().withProduct(mockedProduct).withStoreNumber(1233).buildItem();

		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();
		final List<List<Reservation>> expectedReservations = new ArrayList<List<Reservation>>();
		when(mockedProduct.getNonOverlappingReservationsListForStore(1233, outDate, inDate))
		        .thenReturn(expectedReservations);

		assertSame(expectedReservations, item.getNonOverlappingReservationsList(outDate, inDate));
	}

	/**
	 * Should return true if item belongs to the same store.
	 */
	@Test
	public void shouldReturnTrueIfItemBelongsToTheSameStore() {
		item.setStoreNumber(1);
		assertTrue(item.isBelongingToThisStore(1));
	}

	/**
	 * Should return false if item does not belongs to the same store.
	 */
	@Test
	public void shouldReturnFalseIfItemDoesNotBelongsToTheSameStore() {
		item.setStoreNumber(1);
		assertFalse(item.isBelongingToThisStore(2));
	}

	/**
	 * Should return null if item status is not rented.
	 */
	@Test
	public void shouldReturnNullIfItemStatusIsNotRented() {
		final ItemStatus itemStatus = mock(ItemStatus.class);
		when(itemStatus.isRented()).thenReturn(false);
		item.setItemStatus(itemStatus);

		assertNull(item.getCurrentAgreementItemToWhichIBelong());
	}

	/**
	 * Should return the agreement item if the item is rented.
	 */
	@Test
	public void shouldReturnTheAgreementItemIfTheItemIsRented() {
		final ItemStatus itemStatus = mock(ItemStatus.class);
		when(itemStatus.isRented()).thenReturn(true);
		item.setItemStatus(itemStatus);

		final AgreementItem expectedAgreement = new AgreementItem();

		mockStatic(AgreementItem.class);
		when(AgreementItem.findCheckedOutAndPaidAgreementItemFor(item)).thenReturn(expectedAgreement);

		assertEquals(expectedAgreement, item.getCurrentAgreementItemToWhichIBelong());
	}

	/**
	 * Should return null agreement if item status is not rented.
	 */
	@Test
	public void shouldReturnNullAgreementIfItemStatusIsNotRented() {
		final ItemStatus itemStatus = mock(ItemStatus.class);
		when(itemStatus.isRented()).thenReturn(false);
		item.setItemStatus(itemStatus);

		assertNull(item.getCurrentAgreementToWhichItemBelongs());
	}

	/**
	 * Should return the agreement if the item is rented.
	 */
	@Test
	public void shouldReturnTheAgreementIfTheItemIsRented() {
		final ItemStatus itemStatus = mock(ItemStatus.class);
		when(itemStatus.isRented()).thenReturn(true);
		item.setItemStatus(itemStatus);

		final Agreement expectedAgreement = new Agreement();

		mockStatic(Agreement.class);
		when(Agreement.findActiveAgreementAssociatedWithItem(item)).thenReturn(expectedAgreement);

		assertEquals(expectedAgreement, item.getCurrentAgreementToWhichItemBelongs());
	}

	/**
	 * Should return overlapping reservations for the given date range.
	 */
	@Test
	public void shouldReturnOverlappingReservationsForTheGivenDateRange() {
		final Product mockedProduct = mock(Product.class);
		item.setProduct(mockedProduct);
		item.setStoreNumber(1233);

		final List<Reservation> expectedReservations = new ArrayList<Reservation>();
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();
		when(mockedProduct.getOverlappingOpenReservationsForStore(1233, outDate, inDate)).thenReturn(expectedReservations);

		assertSame(expectedReservations, item.getOverlappingOpenReservationsFor(outDate, inDate));
	}

	/**
	 * Should create the charge amount.
	 */
	@Test
	public void shouldCreateTheChargeAmount() {
		final Product product = mock(Product.class);

		final ChargeInfo expectedChargeInfo = new ChargeInfo();
		when(product.createChargeInfo()).thenReturn(expectedChargeInfo);
		item.setProduct(product);

		assertSame(expectedChargeInfo, item.createChargeInfo());
	}

    @Test
    public void shouldGetTheCountOfAllTheRentalItemsCurrentlyInTheStore() {
        final EntityManager entityManager = mock(EntityManager.class);
        stub(method(Item.class, "entityManager", null)).andReturn(entityManager);
        final Query query = mock(Query.class);
        when(entityManager.createQuery("select count(o) from Item o where o.product=:product and o.storeNumber=:storeNumber"))
                .thenReturn(query);
        final Product product = new Product();
        when(query.setParameter("product", product)).thenReturn(query);
        when(query.setParameter("storeNumber", 1233)).thenReturn(query);
        when(query.getSingleResult()).thenReturn(7866L);

        assertEquals(7866L, Item.countItemsByProductAndStoreNumber(product, 1233));
    }

    @Test
    public void shouldReturnTheCountOfRentableItemsForAGivenProductForAGivenStore() {
        final EntityManager entityManager = mock(EntityManager.class);
        stub(method(Item.class, "entityManager", null)).andReturn(entityManager);

        mockStatic(ItemStatus.class);
        final List<ItemStatus> rentableStatusList = new ArrayList<ItemStatus>();
        when(ItemStatus.findAllRentableStatuses()).thenReturn(rentableStatusList);

        final Query query = mock(Query.class);
        when(entityManager.createQuery("select count(o) from Item o where o.storeNumber=:storeNumber and o.itemStatus in (:statusList) and o.product=:product"))
                .thenReturn(query);
        when(query.setParameter("storeNumber", 1233)).thenReturn(query);
        when(query.setParameter("statusList", rentableStatusList)).thenReturn(query);
        final Product product = new Product();
        when(query.setParameter("product", product)).thenReturn(query);
        when(query.getSingleResult()).thenReturn(89892L);

        assertEquals(89892L, Item.countRentableItemsByProductAndStoreNumber(product, 1233));        
    }

    @Test
    public void shouldReturnTheCountOfItemsForAGivenProductForAGivenStoreForAGivenStatus() {
        final EntityManager entityManager = mock(EntityManager.class);
        stub(method(Item.class, "entityManager", null)).andReturn(entityManager);

        final Query query = mock(Query.class);
        when(entityManager.createQuery("select count(o) from Item o where o.product=:product and o.storeNumber=:storeNumber and o.itemStatus=:itemStatus"))
                .thenReturn(query);
        final Product product = new Product();
        when(query.setParameter("product", product)).thenReturn(query);
        when(query.setParameter("storeNumber", 1233)).thenReturn(query);
        final ItemStatus itemStatus = new ItemStatus();
        when(query.setParameter("itemStatus", itemStatus)).thenReturn(query);
        when(query.getSingleResult()).thenReturn(89892L);

        assertEquals(89892L, Item.countItemsByProductAndStoreNumberAndItemStatus(product, 1233, itemStatus));
    }
}
