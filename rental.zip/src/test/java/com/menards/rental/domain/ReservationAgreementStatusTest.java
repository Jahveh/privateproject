/*
 * ReservationAgreementStatusTest.java
 */
package com.menards.rental.domain;

import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.stub;

import javax.persistence.Query;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Created by IntelliJ IDEA. User: deep Date: 26 Jul, 2010 Time: 1:15:05 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest(ReservationAgreementStatus.class)
public class ReservationAgreementStatusTest {

	/**
	 * Should return the open status code.
	 */
	@Test
	public void shouldReturnTheOpenStatusCode() {
		final Query mockedQuery = mock(Query.class);
		stub(method(ReservationAgreementStatus.class, "findReservationAgreementStatusesByCode", String.class)).andReturn(
		        mockedQuery);

		final ReservationAgreementStatus expectedStuats = new ReservationAgreementStatus();
		when(mockedQuery.getSingleResult()).thenReturn(expectedStuats);

		assertSame(expectedStuats, ReservationAgreementStatus.findOpen());
	}
}
