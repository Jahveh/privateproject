/*
 * DateRangeTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;

import java.util.Calendar;

import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: deep Date: 13 Jul, 2010 Time: 6:37:33 PM To
 * change this template use File | Settings | File Templates.
 */
public class DateRangeTest {

	/**
	 * Should return true if both lower and upper dates are on the same day.
	 */
	@Test
	public void shouldReturnTrueIfBothLowerAndUpperDatesAreOnTheSameDay() {
		assertTrue(new DateRange(Calendar.getInstance(), Calendar.getInstance()).isOnSameDay());
	}

	@Test
	public void shouldReturnFalseIfBothLowerAndUpperDatesAreOnTheSameDayButDifferentMonth() {
        final Calendar upper = Calendar.getInstance();
        upper.add(Calendar.MONTH, 1);
        assertFalse(new DateRange(Calendar.getInstance(), upper).isOnSameDay());
	}

	@Test
	public void shouldReturnFalseIfBothLowerAndUpperDatesAreOnTheSameDayAndSameMonthButDifferentYear() {
        final Calendar upper = Calendar.getInstance();
        upper.add(Calendar.YEAR, 1);
        assertFalse(new DateRange(Calendar.getInstance(), upper).isOnSameDay());
	}

	/**
	 * Should return false if the dates are not on the same day.
	 */
	@Test
	public void shouldReturnFalseIfTheDatesAreNotOnTheSameDay() {
		final Calendar lower = Calendar.getInstance();
		lower.add(Calendar.DATE, -1);
		assertFalse(new DateRange(lower, Calendar.getInstance()).isOnSameDay());
	}

	/**
	 * Should return total duration in hours.
	 */
	@Test
	public void shouldReturnTotalDurationInHours() {
		final Calendar lower = Calendar.getInstance();
		lower.add(Calendar.HOUR, -2);
		lower.add(Calendar.MINUTE, -30);
		assertEquals(2.50, new DateRange(lower, Calendar.getInstance()).getTotalDurationInHours(), 0.01);
	}

	/**
	 * Should return true if total duration is less than the given value.
	 */
	@Test
	public void shouldReturnTrueIfTotalDurationIsLessThanTheGivenValue() {
		final Calendar lower = Calendar.getInstance();
		lower.add(Calendar.HOUR, -2);
		lower.add(Calendar.MINUTE, -30);
		assertTrue(new DateRange(lower, Calendar.getInstance()).isTotalDurationLessThan(4.0));
	}

	/**
	 * Should return false if total duration is not less than the given value.
	 */
	@Test
	public void shouldReturnFalseIfTotalDurationIsNotLessThanTheGivenValue() {
		final Calendar lower = Calendar.getInstance();
		lower.add(Calendar.HOUR, -5);
		lower.add(Calendar.MINUTE, -30);
		assertFalse(new DateRange(lower, Calendar.getInstance()).isTotalDurationLessThan(5.0));
	}

	/**
	 * Should subtract the given quantity from the total hours.
	 */
	@Test
	public void shouldSubtractTheGivenQuantityFromTheTotalHours() {
		final Calendar lower = Calendar.getInstance();
		lower.add(Calendar.HOUR, -5);
		lower.add(Calendar.MINUTE, -30);
		assertEquals(1.5, new DateRange(lower, Calendar.getInstance()).subtractHoursFromTotalDuration(4.0), 0.01);
	}

    @Test
    public void shouldReturnTrueIfTheGiveDateIsInRange() {
        final Calendar calendar = Calendar.getInstance();
        calendar.set(2010, 5, 12);
        assertTrue(new DateRange("01/01/2010", "12/31/2010").isDateInRange(calendar));
    }

    @Test
    public void shouldReturnFalseIfTheGiveDateIsNotInRange() {
        assertFalse(new DateRange("01/01/2008", "12/31/2009").isDateInRange(Calendar.getInstance()));
    }
}
