/*
 * AgreementItemOverrideTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Created by IntelliJ IDEA. User: deep Date: 1 Jul, 2010 Time: 2:26:17 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest(OverrideReason.class)
public class AgreementItemOverrideTest {
	
	/** The agreement item override. */
	private AgreementItemOverride agreementItemOverride;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		agreementItemOverride = new AgreementItemOverride();
	}

	/**
	 * Should return new null agreement item override if agreement item override is null.
	 */
	@Test
	public void shouldReturnNewNullAgreementItemOverrideIfAgreementItemOverrideIsNull() {
		agreementItemOverride.setPriceOverrideReason(null);
		assertNotNull(agreementItemOverride.getNotNullPriceOverrideReason());
	}

	/**
	 * Should return same agreement item override if agreement item override is not null.
	 */
	@Test
	public void shouldReturnSameAgreementItemOverrideIfAgreementItemOverrideIsNotNull() {
		final OverrideReason expectedOverrideReason = new OverrideReason();
		agreementItemOverride.setPriceOverrideReason(expectedOverrideReason);
		assertEquals(expectedOverrideReason, agreementItemOverride.getNotNullPriceOverrideReason());
	}

	/**
	 * Should set the value of agreement item override if it was null while getting not null override.
	 */
	@Test
	public void shouldSetTheValueOfAgreementItemOverrideIfItWasNullWhileGettingNotNullOverride() {
		agreementItemOverride.setPriceOverrideReason(null);
		final OverrideReason expectedOverride = agreementItemOverride.getNotNullPriceOverrideReason();

		assertSame(expectedOverride, agreementItemOverride.getPriceOverrideReason());
	}

	/**
	 * Should return agreement item override.
	 */
	@Test
	public void shouldReturnAgreementItemOverride() {
		final OverrideReason expectedOverride = new OverrideReason();
		agreementItemOverride.setNotNullPriceOverrideReason(expectedOverride);
		assertSame(expectedOverride, agreementItemOverride.getPriceOverrideReason());
	}

	/**
	 * Should return new null agreement qty item override if agreement item qty override is null.
	 */
	@Test
	public void shouldReturnNewNullAgreementQtyItemOverrideIfAgreementItemQtyOverrideIsNull() {
		agreementItemOverride.setQuantityOverrideReason(null);
		assertNotNull(agreementItemOverride.getNotNullQuantityOverrideReason());
	}

	/**
	 * Should return same agreement item qty override if agreement item qty override is not null.
	 */
	@Test
	public void shouldReturnSameAgreementItemQtyOverrideIfAgreementItemQtyOverrideIsNotNull() {
		final OverrideReason expectedOverrideReason = new OverrideReason();
		agreementItemOverride.setQuantityOverrideReason(expectedOverrideReason);
		assertEquals(expectedOverrideReason, agreementItemOverride.getNotNullQuantityOverrideReason());
	}

	/**
	 * Should set the value of agreement item qty override if it was null while getting not null qty override.
	 */
	@Test
	public void shouldSetTheValueOfAgreementItemQtyOverrideIfItWasNullWhileGettingNotNullQtyOverride() {
		agreementItemOverride.setQuantityOverrideReason(null);
		final OverrideReason expectedOverride = agreementItemOverride.getNotNullQuantityOverrideReason();

		assertSame(expectedOverride, agreementItemOverride.getQuantityOverrideReason());
	}

	/**
	 * Should return agreement item quantity override.
	 */
	@Test
	public void shouldReturnAgreementItemQuantityOverride() {
		final OverrideReason expectedOverride = new OverrideReason();
		agreementItemOverride.setNotNullQuantityOverrideReason(expectedOverride);
		assertSame(expectedOverride, agreementItemOverride.getQuantityOverrideReason());
	}

	/**
	 * Should reset values of price override reason and name if price override status is null.
	 */
	@Test
	public void shouldResetValuesOfPriceOverrideReasonAndNameIfPriceOverrideStatusIsNull() {
		agreementItemOverride.setPriceOverrideByNumber(1234);
		agreementItemOverride.updateOverrideReason();

		assertNull(agreementItemOverride.getPriceOverrideByNumber());
		assertNull(agreementItemOverride.getPriceOverrideReason());
	}

	/**
	 * Should reset values of has price override if price override status is null.
	 */
	@Test
	public void shouldResetValuesOfHasPriceOverrideIfPriceOverrideStatusIsNull() {
		agreementItemOverride.setHasPriceOverride(true);
		agreementItemOverride.updateOverrideReason();

		assertFalse(agreementItemOverride.getHasPriceOverride());
	}

	/**
	 * Should reset values of price override reason and name if price override status has null id.
	 */
	@Test
	public void shouldResetValuesOfPriceOverrideReasonAndNameIfPriceOverrideStatusHasNullId() {
		agreementItemOverride.setPriceOverrideByNumber(1233);
		agreementItemOverride.setPriceOverrideReason(new OverrideReason());
		agreementItemOverride.updateOverrideReason();

		assertNull(agreementItemOverride.getPriceOverrideByNumber());
		assertNull(agreementItemOverride.getPriceOverrideReason());
	}

	/**
	 * Should set the value of price override reason from db.
	 */
	@Test
	public void shouldSetTheValueOfPriceOverrideReasonFromDB() {
		agreementItemOverride.setPriceOverrideByNumber(1233);
		final OverrideReason priceOverrideReason = new OverrideReason();
		priceOverrideReason.setId(1233L);
		agreementItemOverride.setPriceOverrideReason(priceOverrideReason);

		final OverrideReason expectedPriceOverrideReason = new OverrideReason();
		mockStatic(OverrideReason.class);
		when(OverrideReason.findOverrideReason(1233L)).thenReturn(expectedPriceOverrideReason);

		agreementItemOverride.updateOverrideReason();

		assertSame(expectedPriceOverrideReason, agreementItemOverride.getPriceOverrideReason());
		assertEquals(1233, agreementItemOverride.getPriceOverrideByNumber().intValue());
	}

	/**
	 * Should set has price override flag.
	 */
	@Test
	public void shouldSetHasPriceOverrideFlag() {
		final OverrideReason priceOverrideReason = new OverrideReason();
		priceOverrideReason.setId(1233L);
		agreementItemOverride.setPriceOverrideReason(priceOverrideReason);

		final OverrideReason overrideReason = new OverrideReason();
		mockStatic(OverrideReason.class);
		when(OverrideReason.findOverrideReason(1233L)).thenReturn(overrideReason);

		agreementItemOverride.updateOverrideReason();

		assertTrue(agreementItemOverride.getHasPriceOverride());
	}

	/**
	 * Should reset values of quantity override reason and name if quantity override status is null.
	 */
	@Test
	public void shouldResetValuesOfQuantityOverrideReasonAndNameIfQuantityOverrideStatusIsNull() {
		agreementItemOverride.setPriceOverrideByNumber(1233);
		agreementItemOverride.updateOverrideReason();

		assertNull(agreementItemOverride.getQuantityOverrideByNumber());
		assertNull(agreementItemOverride.getQuantityOverrideReason());
	}

	/**
	 * Should reset values of quantity override reason and name if quantity override status has null id.
	 */
	@Test
	public void shouldResetValuesOfQuantityOverrideReasonAndNameIfQuantityOverrideStatusHasNullId() {
		agreementItemOverride.setQuantityOverrideByNumber(1233);
		agreementItemOverride.setQuantityOverrideReason(new OverrideReason());
		agreementItemOverride.updateOverrideReason();

		assertNull(agreementItemOverride.getQuantityOverrideByNumber());
		assertNull(agreementItemOverride.getQuantityOverrideReason());
	}

	/**
	 * Should set the value of quantity override reason from db.
	 */
	@Test
	public void shouldSetTheValueOfQuantityOverrideReasonFromDB() {
		agreementItemOverride.setQuantityOverrideByNumber(1233);
		final OverrideReason quantityOverrideReason = new OverrideReason();
		quantityOverrideReason.setId(7866L);
		agreementItemOverride.setQuantityOverrideReason(quantityOverrideReason);

		final OverrideReason expectedQuantityOverrideReason = new OverrideReason();
		mockStatic(OverrideReason.class);
		when(OverrideReason.findOverrideReason(7866L)).thenReturn(expectedQuantityOverrideReason);

		agreementItemOverride.updateOverrideReason();

		assertSame(expectedQuantityOverrideReason, agreementItemOverride.getQuantityOverrideReason());
		assertEquals(1233, agreementItemOverride.getQuantityOverrideByNumber().intValue());
	}

	/**
	 * Should reset values of has quantity override if price override status is null.
	 */
	@Test
	public void shouldResetValuesOfHasQuantityOverrideIfPriceOverrideStatusIsNull() {
		agreementItemOverride.setHasQuantityOverride(true);
		agreementItemOverride.updateOverrideReason();

		assertFalse(agreementItemOverride.getHasQuantityOverride());
	}

	/**
	 * Should set has quantity override flag.
	 */
	@Test
	public void shouldSetHasQuantityOverrideFlag() {
		final OverrideReason priceOverrideReason = new OverrideReason();
		priceOverrideReason.setId(1233L);

		agreementItemOverride.setQuantityOverrideReason(priceOverrideReason);

		final OverrideReason overrideReason = new OverrideReason();
		mockStatic(OverrideReason.class);
		when(OverrideReason.findOverrideReason(1233L)).thenReturn(overrideReason);

		agreementItemOverride.updateOverrideReason();

		assertTrue(agreementItemOverride.getHasQuantityOverride());
	}

	/**
	 * Should return true if reservation override by name is not null.
	 */
	@Test
	public void shouldReturnTrueIfReservationOverrideByNameIsNotNull() {
		agreementItemOverride.setReservationOverrideByNumber(1233);
		assertTrue(agreementItemOverride.getHasReservationOverride());
	}

	/**
	 * Should return false if reservation override by name is null.
	 */
	@Test
	public void shouldReturnFalseIfReservationOverrideByNameIsNull() {
		agreementItemOverride.setReservationOverrideByName(null);
		assertFalse(agreementItemOverride.getHasReservationOverride());
	}
}
