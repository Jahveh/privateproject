/*
 * SKUsTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: deep Date: 10 Jun, 2010 Time: 4:11:02 PM To
 * change this template use File | Settings | File Templates.
 */
public class SKUsTest {

	/**
	 * Should return an empty list if list of all sk us dont have any base sku.
	 */
	@Test
	public void shouldReturnAnEmptyListIfListOfAllSKUsDontHaveAnyBaseSKU() {
		final List<RentalSKU> baseSKUs = new SKUCollection(new ArrayList<RentalSKU>()).getBaseSKUs();
		assertNotNull(baseSKUs);
		assertEquals(0, baseSKUs.size());
	}

	/**
	 * Should return list of base sk us.
	 */
	@Test
	public void shouldReturnListOfBaseSKUs() {
		final ArrayList<RentalSKU> allSKUs = new ArrayList<RentalSKU>();
		final RentalSKU baseSKU = new RentalSKU("BASE", new BigDecimal("10.8"), 0);
		allSKUs.add(baseSKU);
		allSKUs.add(new RentalSKU("ADDITIONAL", null, 0));
		final List<RentalSKU> baseSKUs = new SKUCollection(allSKUs).getBaseSKUs();
		assertNotNull(baseSKUs);
		assertEquals(1, baseSKUs.size());
		assertTrue(baseSKUs.contains(baseSKU));
	}

	/**
	 * Should return an empty list if list of all sk us dont have any additional sku.
	 */
	@Test
	public void shouldReturnAnEmptyListIfListOfAllSKUsDontHaveAnyAdditionalSKU() {
		final List<RentalSKU> additionalSKUs = new SKUCollection(new ArrayList<RentalSKU>()).getIncrementalSKUs();
		assertNotNull(additionalSKUs);
		assertEquals(0, additionalSKUs.size());
	}

	/**
	 * Should return list of additional sk us.
	 */
	@Test
	public void shouldReturnListOfAdditionalSKUs() {
		final ArrayList<RentalSKU> allSKUs = new ArrayList<RentalSKU>();
		final RentalSKU additionalSKU = new RentalSKU("ADDITIONAL", new BigDecimal("10.8"), 0);
		allSKUs.add(new RentalSKU("SURCHARGE", null, 0));
		allSKUs.add(additionalSKU);
		final List<RentalSKU> additionalSKUs = new SKUCollection(allSKUs).getIncrementalSKUs();
		assertNotNull(additionalSKUs);
		assertEquals(1, additionalSKUs.size());
		assertTrue(additionalSKUs.contains(additionalSKU));
	}

	/**
	 * Should return an empty list if list of all sk us dont have any surcharge sku.
	 */
	@Test
	public void shouldReturnAnEmptyListIfListOfAllSKUsDontHaveAnySurchargeSKU() {
		final List<RentalSKU> surchargeSKUs = new SKUCollection(new ArrayList<RentalSKU>()).getSurchargeSKUs();
		assertNotNull(surchargeSKUs);
		assertEquals(0, surchargeSKUs.size());
	}

	/**
	 * Should return list of surcharge sk us.
	 */
	@Test
	public void shouldReturnListOfSurchargeSKUs() {
		final ArrayList<RentalSKU> allSKUs = new ArrayList<RentalSKU>();
		final RentalSKU surchargeSKU = new RentalSKU("SURCHARGE", new BigDecimal("10.8"), 0);
		allSKUs.add(new RentalSKU("SELLING", null, 0));
		allSKUs.add(surchargeSKU);
		final List<RentalSKU> surchargeSKUs = new SKUCollection(allSKUs).getSurchargeSKUs();
		assertNotNull(surchargeSKUs);
		assertEquals(1, surchargeSKUs.size());
		assertTrue(surchargeSKUs.contains(surchargeSKU));
	}

	/**
	 * Should return an empty list if list of all sk us dont have any selling sku.
	 */
	@Test
	public void shouldReturnAnEmptyListIfListOfAllSKUsDontHaveAnySellingSKU() {
		final List<RentalSKU> sellingSKUs = new SKUCollection(new ArrayList<RentalSKU>()).getSellingSKUs();
		assertNotNull(sellingSKUs);
		assertEquals(0, sellingSKUs.size());
	}

	/**
	 * Should return list of selling sk us.
	 */
	@Test
	public void shouldReturnListOfSellingSKUs() {
		final ArrayList<RentalSKU> allSKUs = new ArrayList<RentalSKU>();
		final RentalSKU sellingSKU = new RentalSKU("SELLING", new BigDecimal("10.8"), 0);
		allSKUs.add(sellingSKU);
		allSKUs.add(new RentalSKU("BASE", null, 0));
		final List<RentalSKU> sellingSKUs = new SKUCollection(allSKUs).getSellingSKUs();
		assertNotNull(sellingSKUs);
		assertEquals(1, sellingSKUs.size());
		assertTrue(sellingSKUs.contains(sellingSKU));
	}

}
