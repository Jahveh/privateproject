/*
 * Max12HoursPerDayRoundingStrategyTest.java
 */
package com.menards.rental.domain.strategy;

import static junit.framework.Assert.assertEquals;

import org.junit.Test;

/**
 * User: deep Date: 14 Jul, 2010 Time: 4:10:19 PM.
 */
public class Max12HoursPerDayRoundingStrategyTest {

	/**
	 * Should round off to the ceiling value if total hours is less than12 in a day.
	 */
	@Test
	public void shouldRoundOffToTheCeilingValueIfTotalHoursIsLessThan12InADay() {
		assertEquals(4.5, new Max12HoursPerDayRoundingStrategy().calculateRoundedIncrementalHoursAfterSubtractingBaseHours(
		        4, 0.75, 8), 0.001);
	}

	/**
	 * Should round off to the ceiling value if total hours is less than12 in a day but actual duration is greater than12.
	 */
	@Test
	public void shouldRoundOffToTheCeilingValueIfTotalHoursIsLessThan12InADayButActualDurationIsGreaterThan12() {
		assertEquals(9, new Max12HoursPerDayRoundingStrategy().calculateRoundedIncrementalHoursAfterSubtractingBaseHours(3,
		        1, 14), 0.001);
	}

	/**
	 * Should round off to the floor value if total hours is greater than12 in a day.
	 */
	@Test
	public void shouldRoundOffToTheFloorValueIfTotalHoursIsGreaterThan12InADay() {
		assertEquals(7.5, new Max12HoursPerDayRoundingStrategy().calculateRoundedIncrementalHoursAfterSubtractingBaseHours(
		        4, 0.75, 12), 0.001);
	}

	/**
	 * Should round off to the floor value if total hours is greater than12 in a day and actual hours is greater than12.
	 */
	@Test
	public void shouldRoundOffToTheFloorValueIfTotalHoursIsGreaterThan12InADayAndActualHoursIsGreaterThan12() {
		assertEquals(6.75, new Max12HoursPerDayRoundingStrategy().calculateRoundedIncrementalHoursAfterSubtractingBaseHours(
		        5, 0.75, 15.0), 0.001);
	}
}
