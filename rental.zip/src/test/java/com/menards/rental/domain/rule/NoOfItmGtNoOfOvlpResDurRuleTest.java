/*
 * NumberOfItemsGreaterThanNumberOfOverlappingReservationDurationReservationRuleTest.java
 */
package com.menards.rental.domain.rule;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.expectReturn;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.playback;

import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.staticmock.MockStaticEntityMethods;

import com.menards.rental.domain.Item;
import com.menards.rental.domain.ItemStatus;
import com.menards.rental.domain.Product;

/**
 * User: deep Date: 8 Jul, 2010 Time: 4:48:22 PM.
 */
@MockStaticEntityMethods
public class NoOfItmGtNoOfOvlpResDurRuleTest {
	
	/** The reservation rule. */
	private ItemCountGreaterThanOverlapingReservationsRule reservationRule;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		reservationRule = new ItemCountGreaterThanOverlapingReservationsRule();
	}

	/**
	 * Should return true if number of items available in the system is greater than number of overlapping reservations.
	 */
	@Test
	public void shouldReturnTrueIfNumberOfItemsAvailableInTheSystemIsGreaterThanNumberOfOverlappingReservations() {
		final Item mockedItem = mock(Item.class);
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();
		final Product product = new Product();
		final ItemStatus itemStatus = new ItemStatus();
		final ArrayList<Item> items = new ArrayList<Item>();
		items.add(new Item());
		items.add(new Item());
		items.add(new Item());
		items.add(new Item());
		items.add(new Item());
		items.add(new Item());

		when(mockedItem.getStoreNumber()).thenReturn(1233);
		when(mockedItem.countActuallyOverlappingReservations(outDate, inDate)).thenReturn(5);
		when(mockedItem.getProduct()).thenReturn(product);

		ItemStatus.findAvailable();
		expectReturn(itemStatus);
		Item.findAllItemsByStoreNumberAndProductAndItemStatus(1233, product, itemStatus);
		expectReturn(items);
		playback();

		assertTrue(reservationRule.hasNoConflictingReservation(mockedItem, outDate, inDate));
	}

	/**
	 * Should return false if number of items available in the system is equal to the number of overlapping reservations.
	 */
	@Test
	public void shouldReturnFalseIfNumberOfItemsAvailableInTheSystemIsEqualToTheNumberOfOverlappingReservations() {
		final Item mockedItem = mock(Item.class);
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();
		final Product product = new Product();
		final ItemStatus itemStatus = new ItemStatus();
		final ArrayList<Item> items = new ArrayList<Item>();
		items.add(new Item());
		items.add(new Item());
		items.add(new Item());
		items.add(new Item());
		items.add(new Item());

		when(mockedItem.getStoreNumber()).thenReturn(1233);
		when(mockedItem.countActuallyOverlappingReservations(outDate, inDate)).thenReturn(5);
		when(mockedItem.getProduct()).thenReturn(product);

		ItemStatus.findAvailable();
		expectReturn(itemStatus);
		Item.findAllItemsByStoreNumberAndProductAndItemStatus(1233, product, itemStatus);
		expectReturn(items);
		playback();

		assertFalse(reservationRule.hasNoConflictingReservation(mockedItem, outDate, inDate));
	}

	/**
	 * Should return false if number of items available in the system is less than to the number of overlapping reservations.
	 */
	@Test
	public void shouldReturnFalseIfNumberOfItemsAvailableInTheSystemIsLessThanToTheNumberOfOverlappingReservations() {
		final Item mockedItem = mock(Item.class);
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();
		final Product product = new Product();
		final ItemStatus itemStatus = new ItemStatus();
		final ArrayList<Item> items = new ArrayList<Item>();
		items.add(new Item());
		items.add(new Item());
		items.add(new Item());
		items.add(new Item());

		when(mockedItem.getStoreNumber()).thenReturn(1233);
		when(mockedItem.countActuallyOverlappingReservations(outDate, inDate)).thenReturn(5);
		when(mockedItem.getProduct()).thenReturn(product);

		ItemStatus.findAvailable();
		expectReturn(itemStatus);
		Item.findAllItemsByStoreNumberAndProductAndItemStatus(1233, product, itemStatus);
		expectReturn(items);
		playback();

		assertFalse(reservationRule.hasNoConflictingReservation(mockedItem, outDate, inDate));
	}
}
