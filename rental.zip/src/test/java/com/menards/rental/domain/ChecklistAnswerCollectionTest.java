/*
 * ChecklistAnswersTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: deep Date: 23 Jun, 2010 Time: 11:56:37 AM To
 * change this template use File | Settings | File Templates.
 */
public class ChecklistAnswerCollectionTest {

	/**
	 * Should create answers corresponding to the questions passed as argument.
	 */
	@Test
	public void shouldCreateAnswersCorrespondingToTheQuestionsPassedAsArgument() {
		final List<ChecklistAnswer> answers = new ArrayList<ChecklistAnswer>();

		final ChecklistAnswerCollection checklistAnswerCollection = new ChecklistAnswerCollection(answers);
		final ArrayList<Question> questions = new ArrayList<Question>();
		questions.add(new Question("Did you have lunch today?"));
		questions.add(new Question("Do you drink and drive?"));

		final AgreementItem expectedItem = new AgreementItem();
		checklistAnswerCollection.createEmptyAnswers(questions, expectedItem);

		assertEquals(2, answers.size());
		assertEquals("Did you have lunch today?", answers.get(0).getQuestionText());
		assertEquals("Do you drink and drive?", answers.get(1).getQuestionText());
		assertSame(expectedItem, answers.get(0).getAgreementItem());
		assertSame(expectedItem, answers.get(1).getAgreementItem());
	}

	/**
	 * Should return the total of all the charge amounts.
	 */
	@Test
	public void shouldReturnTheTotalOfAllTheChargeAmounts() {
		final Set<ChecklistAnswer> answers = new HashSet<ChecklistAnswer>();

		answers.add(new ChecklistAnswer(null, new BigDecimal("0")));
		answers.add(new ChecklistAnswer(null, new BigDecimal("3.6")));
		answers.add(new ChecklistAnswer(null, new BigDecimal("6.3")));
		answers.add(new ChecklistAnswer(null, new BigDecimal("0")));
		answers.add(new ChecklistAnswer(null, new BigDecimal("2.7")));
		answers.add(new ChecklistAnswer(null, new BigDecimal("0")));

		assertEquals(new BigDecimal("12.6").doubleValue(), new ChecklistAnswerCollection(answers).getTotalChargeAmount().doubleValue(),
		        0.001);
	}

	/**
	 * Should return true if answer is an yes answer.
	 */
	@Test
	public void shouldReturnTrueIfAnswerIsAnYesAnswer() {
		final ChecklistAnswer checklistAnswer = new ChecklistAnswer();
		checklistAnswer.setAnswer(ChecklistAnswer.AnswerCode.YES.getCode());
		assertTrue(checklistAnswer.isYesAnswer());
	}

	/**
	 * Should return false if answer is anything other than yes answer.
	 */
	@Test
	public void shouldReturnFalseIfAnswerIsAnythingOtherThanYesAnswer() {
		final ChecklistAnswer checklistAnswer = new ChecklistAnswer();
		checklistAnswer.setAnswer(ChecklistAnswer.AnswerCode.NA.getCode());
		assertFalse(checklistAnswer.isYesAnswer());
	}

	/**
	 * Should return false if answer is null.
	 */
	@Test
	public void shouldReturnFalseIfAnswerIsNull() {
		assertFalse(new ChecklistAnswer().isYesAnswer());
	}
}
