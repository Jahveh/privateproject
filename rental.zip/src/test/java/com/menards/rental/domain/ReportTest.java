package com.menards.rental.domain;

import com.menards.rental.utils.Constants;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: deep
 * Date: 25 Aug, 2010
 * Time: 4:43:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReportTest {

    @Test
    public void shouldReturnTheTemplateWithoutCSVSuffixIfReportMediumIsEMAIL() {
        final Report report = new Report();
        report.setReportMedium(Constants.ReportMedium.EMAIL);
        report.setType(Report.Type.RENTAL_OVERRIDE_NOTIFICATION_REPORT);
        
        assertEquals("mailTemplates/RENTAL_OVERRIDE_NOTIFICATION_REPORT.vm", report.getTemplateName());
    }

    @Test
    public void shouldReturnTheTemplateWithCSVSuffixIfReportMediumIsDownload() {
        final Report report = new Report();
        report.setReportMedium(Constants.ReportMedium.DOWNLOAD);
        report.setType(Report.Type.OVERDUE_RENTAL_REPORT);

        assertEquals("mailTemplates/OVERDUE_RENTAL_REPORT_CSV.vm", report.getTemplateName());
    }

    @Test
    public void shouldReturnTrueIfReportIsToBeDownloaded() {
        final Report report = new Report();
        report.setReportMedium(Constants.ReportMedium.DOWNLOAD);
        assertTrue(report.isToBeDownloaded());
    }

    @Test
    public void shouldReturnFalseIfReportIsNotToBeDownloaded() {
        final Report report = new Report();
        report.setReportMedium(Constants.ReportMedium.EMAIL);
        assertFalse(report.isToBeDownloaded());
    }
}
