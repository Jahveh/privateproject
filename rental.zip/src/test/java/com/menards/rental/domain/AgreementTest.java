/*
 * AgreementTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.*;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.stub;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.builder.AgreementBuilder;
import com.menards.rental.builder.AgreementNumberBuilder;

/**
 * Created by IntelliJ IDEA. User: deep Date: 13 May, 2010 Time: 6:37:11 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest( { Agreement.class, AgreementStatus.class, ItemStatus.class, AgreementItemStatus.class })
public class AgreementTest {

	/**
	 * Should find and return vehicle rental detail associated with the chosen agreement items.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldFindAndReturnVehicleRentalDetailAssociatedWithTheChosenAgreementItems() throws Exception {
		final AgreementItemCollection agreementItemsMock = mock(AgreementItemCollection.class);
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();
		final VehicleRentalDetail expectedRentalDetail = new VehicleRentalDetail();

		whenNew(AgreementItemCollection.class).withArguments(agreementItems).thenReturn(agreementItemsMock);
		when(agreementItemsMock.getFirstVehicleRentalDetail()).thenReturn(expectedRentalDetail);

		final Agreement agreement = new Agreement();
		agreement.setItems(agreementItems);

		assertSame(expectedRentalDetail, agreement.getVehicleRentalDetail());
	}

	/**
	 * Should return vehicle rental detail if value is not null.
	 */
	@Test
	public void shouldReturnVehicleRentalDetailIfValueIsNotNull() {
		final VehicleRentalDetail vehicleRentalDetail = new VehicleRentalDetail();

		assertSame(vehicleRentalDetail, new AgreementBuilder().withVehicleRentalDetail(vehicleRentalDetail).buildAgreement()
		        .getVehicleRentalDetail());
	}

	/**
	 * Should merge the vehicle rental detail in agreement items.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldMergeTheVehicleRentalDetailInAgreementItems() throws Exception {

		final AgreementItemCollection agreementItemsMock = mock(AgreementItemCollection.class);
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();

		whenNew(AgreementItemCollection.class).withArguments(items).thenReturn(agreementItemsMock);

		final Guest mockedGuest = mock(Guest.class);

		final Agreement agreement = new AgreementBuilder().withItems(items).withGuest(mockedGuest).withVehicleRentalDetail(
		        new VehicleRentalDetail()).buildAgreement();
		agreement.mergeVehicleRentalDetails();

		verify(agreementItemsMock).merge(agreement.getVehicleRentalDetail());
	}

	/**
	 * Should return the same instance of vehicle rental detail the second time get method is invoked.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTheSameInstanceOfVehicleRentalDetailTheSecondTimeGetMethodIsInvoked() throws Exception {
		final AgreementItemCollection agreementItemsMock = mock(AgreementItemCollection.class);
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();
		final VehicleRentalDetail expectedRentalDetail = new VehicleRentalDetail();

		whenNew(AgreementItemCollection.class).withArguments(agreementItems).thenReturn(agreementItemsMock);
		when(agreementItemsMock.getFirstVehicleRentalDetail()).thenReturn(expectedRentalDetail);

		final Agreement agreement = new Agreement();
		agreement.setItems(agreementItems);

		agreement.getVehicleRentalDetail();

		// Making the second call
		assertSame(expectedRentalDetail, agreement.getVehicleRentalDetail());
	}

	/**
	 * Should add agreement item to the set.
	 */
	@Test
	public void shouldAddAgreementItemToTheSet() {
		final AgreementItem expectedAgreementItem = new AgreementItem();
		final Agreement agreement = new Agreement();
		agreement.addToItems(expectedAgreementItem);

		assertTrue(agreement.getItems().contains(expectedAgreementItem));
	}

	/**
	 * Should set agreement in the passed agreement item.
	 */
	@Test
	public void shouldSetAgreementInThePassedAgreementItem() {
		final AgreementItem expectedAgreementItem = new AgreementItem();
		final Agreement agreement = new Agreement();
		agreement.addToItems(expectedAgreementItem);

		assertSame(agreement, expectedAgreementItem.getAgreement());
	}

	/**
	 * Should return true if agreement items has vehicle.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTrueIfAgreementItemsHasVehicle() throws Exception {
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();

		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreementItems).thenReturn(mockedAgreementItems);
		final Agreement agreement = new Agreement();

		agreement.setItems(agreementItems);
		when(mockedAgreementItems.isInsuranceAdditionalDriverLicenseRequired()).thenReturn(true);
		assertTrue(agreement.isInsuranceAdditionalDriverLicenseRequired());
	}

	/**
	 * Should return false if agreement items has vehicle.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnFalseIfAgreementItemsHasVehicle() throws Exception {
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();

		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreementItems).thenReturn(mockedAgreementItems);
		final Agreement agreement = new Agreement();

		agreement.setItems(agreementItems);
		when(mockedAgreementItems.isInsuranceAdditionalDriverLicenseRequired()).thenReturn(false);
		assertFalse(agreement.isInsuranceAdditionalDriverLicenseRequired());
	}

	/**
	 * Should set todays date in agreement.
	 */
	@Test
	public void shouldSetTodaysDateInAgreement() {
		final Agreement agreement = new Agreement();
		final Date currentDate = new Date();
		agreement.setTodaysDate();

		assertTrue(currentDate.compareTo(agreement.getRentalDate().getTime()) <= 0);
	}

	/**
	 * Should return zero if agreement items not found.
	 */
	@Test
	public void shouldReturnZeroIfAgreementItemsNotFound() {
		assertEquals(0.0, new Agreement().getDamageWaiverTotal().doubleValue());
	}

	/**
	 * Should get the damage waiver total via invoking agreement items.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldGetTheDamageWaiverTotalViaInvokingAgreementItems() throws Exception {
		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		final AgreementStatus agreementStatus = mock(AgreementStatus.class);

		when(agreementStatus.isVoided()).thenReturn(false);
		when(agreementStatus.isPending()).thenReturn(true);
		final Agreement agreement = new AgreementBuilder().withItem(new AgreementItem()).buildAgreement();
		whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(mockedAgreementItems);
		when(mockedAgreementItems.getDamageWaiverTotal()).thenReturn(new BigDecimal("108.99"));
		agreement.setAgreementStatus(agreementStatus);

		assertEquals(108.99, agreement.getDamageWaiverTotal().doubleValue());
	}

	/**
	 * Should return true if all items are available.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTrueIfAllItemsAreAvailable() throws Exception {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(items).thenReturn(mockedAgreementItems);
		when(mockedAgreementItems.isEveryItemAvailableRightNow()).thenReturn(true);

		assertTrue(new AgreementBuilder().withItems(items).buildAgreement().isEveryItemAvailableRightNow());
	}

	/**
	 * Should return false if not all items are available.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnFalseIfNotAllItemsAreAvailable() throws Exception {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(items).thenReturn(mockedAgreementItems);
		when(mockedAgreementItems.isEveryItemAvailableRightNow()).thenReturn(false);

		assertFalse(new AgreementBuilder().withItems(items).buildAgreement().isEveryItemAvailableRightNow());
	}

	/**
	 * Should update the status of all items.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldUpdateTheStatusOfAllItems() throws Exception {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(items).thenReturn(mockedAgreementItems);

		final ItemStatus itemStatus = new ItemStatus();
		new AgreementBuilder().withItems(items).buildAgreement().updateItemsStatus(itemStatus);

		verify(mockedAgreementItems).updateItemsStatus(itemStatus);
	}

	/**
	 * Should generate new agreement number using agreement builder.
	 */
	@Test
	public void shouldGenerateNewAgreementNumberUsingAgreementBuilder() {
		final AgreementNumberBuilder agreementNumberBuilder = mock(AgreementNumberBuilder.class);
		final Store store = new Store();
		store.setStoreNumber(1234);
		new AgreementBuilder().withStore(store).buildAgreement().generateNewNumber(agreementNumberBuilder);
		verify(agreementNumberBuilder).build(1234);
	}

	/**
	 * Should set the newly generated agreement number in the model.
	 */
	@Test
	public void shouldSetTheNewlyGeneratedAgreementNumberInTheModel() {
		final AgreementNumberBuilder agreementNumberBuilder = mock(AgreementNumberBuilder.class);
		when(agreementNumberBuilder.build(1234)).thenReturn("1234-0101010-001");
		final Store store = new Store();
		store.setStoreNumber(1234);
		final Agreement agreement = new AgreementBuilder().withStore(store).buildAgreement();
		agreement.generateNewNumber(agreementNumberBuilder);

		assertEquals("1234-0101010-001", agreement.getAgreementNumber());
	}

	/**
	 * Should increment agreement number using agreement builder.
	 */
	@Test
	public void shouldIncrementAgreementNumberUsingAgreementBuilder() {
		final AgreementNumberBuilder agreementNumberBuilder = mock(AgreementNumberBuilder.class);
		new AgreementBuilder().withAgreementNumber("HAHA-2342-1").buildAgreement().incrementNumber(agreementNumberBuilder);
		verify(agreementNumberBuilder).buildNextIncrement("HAHA-2342-1");
	}

	/**
	 * Should set the incremented agreement number in the model.
	 */
	@Test
	public void shouldSetTheIncrementedAgreementNumberInTheModel() {
		final AgreementNumberBuilder agreementNumberBuilder = mock(AgreementNumberBuilder.class);
		when(agreementNumberBuilder.buildNextIncrement("HAHA-2342-1")).thenReturn("HAHA-2342-002");
		final Agreement agreement = new AgreementBuilder().withAgreementNumber("HAHA-2342-1").buildAgreement();
		agreement.incrementNumber(agreementNumberBuilder);

		assertEquals("HAHA-2342-002", agreement.getAgreementNumber());
	}

	/**
	 * Should return null if item with given serial number not found.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnNullIfItemWithGivenSerialNumberNotFound() throws Exception {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();

		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(items).thenReturn(mockedAgreementItems);
		when(mockedAgreementItems.findItemBySerialNumber(1010L)).thenReturn(null);

		assertNull(new AgreementBuilder().withItems(items).buildAgreement().removeItemBySerialNumber(1010L));
	}

	/**
	 * Should remove the item from the items if item with the given serial number found.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldRemoveTheItemFromTheItemsIfItemWithTheGivenSerialNumberFound() throws Exception {
		final AgreementItem expectedAgreementItem = new AgreementItem();
		final Agreement agreement = new AgreementBuilder().withItem(expectedAgreementItem).buildAgreement();

		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(mockedAgreementItems);
		when(mockedAgreementItems.findItemBySerialNumber(1010L)).thenReturn(expectedAgreementItem);

		agreement.removeItemBySerialNumber(1010L);

		verify(mockedAgreementItems).remove(expectedAgreementItem);
	}

	/**
	 * Should return the removed agreement item.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTheRemovedAgreementItem() throws Exception {
		final AgreementItem expectedAgreementItem = new AgreementItem();
		final Agreement agreement = new AgreementBuilder().withItem(expectedAgreementItem).buildAgreement();

		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(mockedAgreementItems);
		when(mockedAgreementItems.findItemBySerialNumber(1010L)).thenReturn(expectedAgreementItem);

		assertSame(expectedAgreementItem, agreement.removeItemBySerialNumber(1010L));
	}

    /**
	 * Should return list of agreements for the matching search criteria.
	 */
	@Test
	public void shouldReturnListOfAgreementsForTheMatchingSearchCriteria() {
		final EntityManager mockedEntityManager = mock(EntityManager.class);
		stub(method(Agreement.class, "entityManager")).andReturn(mockedEntityManager);

		final Session mockedSession = mock(Session.class);
		when(mockedEntityManager.getDelegate()).thenReturn(mockedSession);

		final DetachedCriteria mockedSearchCriteria = mock(DetachedCriteria.class);

		final Criteria mockedCriteria = mock(Criteria.class);
		when(mockedSearchCriteria.getExecutableCriteria(mockedSession)).thenReturn(mockedCriteria);

		final ArrayList<Agreement> expectedAgreements = new ArrayList<Agreement>();
		when(mockedCriteria.list()).thenReturn(expectedAgreements);

		assertSame(expectedAgreements, Agreement.findAgreementsBySearchCriteria(mockedSearchCriteria));
	}

	/**
	 * Should return agreement number as is if it does not follow the convention.
	 */
	@Test
	public void shouldReturnAgreementNumberAsIsIfItDoesNotFollowTheConvention() {
		assertEquals("XXFDDFD2323", new AgreementBuilder().withAgreementNumber("XXFDDFD2323").buildAgreement()
		        .getAgreementNumberOnly());
	}

	/**
	 * Should return the second part of the agreement number.
	 */
	@Test
	public void shouldReturnTheSecondPartOfTheAgreementNumber() {
		assertEquals("120202", new AgreementBuilder().withAgreementNumber("XXFDDFD2323-120202").buildAgreement()
		        .getAgreementNumberOnly());
	}

	/**
	 * Should return true if agreement status is paid.
	 */
	@Test
	public void shouldReturnTrueIfAgreementStatusIsPaid() {
		final AgreementStatus mockedAgreementStatus = mock(AgreementStatus.class);
		when(mockedAgreementStatus.isCompleted()).thenReturn(true);
		assertTrue(new AgreementBuilder().withAgreementStatus(mockedAgreementStatus).buildAgreement().isCompleted());
	}

	/**
	 * Should return false if agreement status is not paid.
	 */
	@Test
	public void shouldReturnFalseIfAgreementStatusIsNotPaid() {
		assertFalse(new AgreementBuilder().withAgreementStatus(mock(AgreementStatus.class)).buildAgreement().isCompleted());
	}

	/**
	 * Should return the item that matches the given serial number.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTheItemThatMatchesTheGivenSerialNumber() throws Exception {
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();
		final AgreementItem expectedAgreementItem = new AgreementItem();

		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreementItems).thenReturn(mockedAgreementItems);
		when(mockedAgreementItems.findItemBySerialNumber(1233L)).thenReturn(expectedAgreementItem);

		assertSame(expectedAgreementItem, new AgreementBuilder().withItems(agreementItems).buildAgreement()
		        .findItemBySerialNumber(1233));
	}

	/**
	 * Should agreement status is cancelled after cancelling agreement.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldAgreementStatusIsCancelledAfterCancellingAgreement() throws Exception {
		final AgreementStatus agreementStatus = new AgreementStatus();
		final Set<AgreementItem> agreementItems = new HashSet<AgreementItem>();

		final Agreement agreement = spy(new AgreementBuilder().withItems(agreementItems).buildAgreement());
		agreement.setItems(agreementItems);
		doNothing().when(agreement).persist();

		mockStatic(AgreementStatus.class);
		when(AgreementStatus.findCancelled()).thenReturn(agreementStatus);

		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreementItems).thenReturn(mockedAgreementItems);

		agreement.cancelAgreement();

		assertSame(agreement.getAgreementStatus(), agreementStatus);
	}

	/**
	 * Checks if is mark agreement item status as available called while cancelling agreement.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void isMarkAgreementItemStatusAsAvailableCalledWhileCancellingAgreement() throws Exception {
		final AgreementStatus agreementStatus = new AgreementStatus();
		final Set<AgreementItem> agreementItems = new HashSet<AgreementItem>();

		final Agreement agreement = spy(new AgreementBuilder().withItems(agreementItems).buildAgreement());
		agreement.setItems(agreementItems);
		doNothing().when(agreement).persist();

		mockStatic(AgreementStatus.class);
		when(AgreementStatus.findCancelled()).thenReturn(agreementStatus);

		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreementItems).thenReturn(mockedAgreementItems);

		agreement.cancelAgreement();

		Mockito.verify(mockedAgreementItems).markAgreementItemStatusAsAvailable();
	}

	/**
	 * Should agreement status is voided after voiding agreement.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldAgreementStatusIsVoidedAfterVoidingAgreement() throws Exception {
		final AgreementStatus agreementStatus = new AgreementStatus();
		final Set<AgreementItem> agreementItems = new HashSet<AgreementItem>();

		final Agreement agreement = spy(new AgreementBuilder().withItems(agreementItems).buildAgreement());
		agreement.setItems(agreementItems);
		doNothing().when(agreement).persist();

		mockStatic(AgreementStatus.class);
		when(AgreementStatus.findVoided()).thenReturn(agreementStatus);

		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreementItems).thenReturn(mockedAgreementItems);

		agreement.voidAgreement();

		assertSame(agreement.getAgreementStatus(), agreementStatus);
	}

	/**
	 * Should mark agreement item status as available called while voiding agreement.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldMarkAgreementItemStatusAsAvailableCalledWhileVoidingAgreement() throws Exception {
		final AgreementStatus agreementStatus = new AgreementStatus();
		final Set<AgreementItem> agreementItems = new HashSet<AgreementItem>();

		final Agreement agreement = spy(new AgreementBuilder().withItems(agreementItems).buildAgreement());
		agreement.setItems(agreementItems);
		doNothing().when(agreement).persist();

		mockStatic(AgreementStatus.class);
		when(AgreementStatus.findVoided()).thenReturn(agreementStatus);

		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreementItems).thenReturn(mockedAgreementItems);

		agreement.voidAgreement();

		Mockito.verify(mockedAgreementItems).markAgreementItemStatusAsAvailable();
	}

	/**
	 * Should return the total additional charges of items currently checkedin.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTheTotalAdditionalChargesOfItemsCurrentlyCheckedinWithDamageWaiverCredit() throws Exception {
		final Agreement agreement = new AgreementBuilder().withItems(new HashSet<AgreementItem>()).buildAgreement();

		final AgreementItemCollection mockedItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(mockedItems);
		when(mockedItems.getTotalAdditionalChargeAmountOfItemsCurrentlyCheckedin()).thenReturn(new BigDecimal("27.9"));
		when(mockedItems.getTotalDamageWaiverCreditOfItemsCurrentlyCheckedin()).thenReturn(new BigDecimal("-2.5"));

		assertEquals(25.4, agreement.getTotalAdditionalChargeAmountOfItemsCurrentlyCheckedin().doubleValue(), 0.001);
	}

	/**
	 * Should checkin the marked items.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCheckinTheMarkedItems() throws Exception {
		final Agreement agreement = new AgreementBuilder().withItems(new HashSet<AgreementItem>()).buildAgreement();

		final AgreementItemCollection mockedItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(mockedItems);

		agreement.checkinMarkedItems();

		verify(mockedItems).checkinMarkedItems();
	}

	/**
	 * Should return true if guests meets minimum age requirement for all the items.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTrueIfGuestsMeetsMinimumAgeRequirementForAllTheItems() throws Exception {
		final Agreement agreement = new AgreementBuilder().withItems(new HashSet<AgreementItem>()).buildAgreement();
		final AgreementItemCollection mockedItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(mockedItems);

		when(mockedItems.isDriverAgeGreaterThanMinimumRentalAge(agreement)).thenReturn(true);

		assertTrue(agreement.isDriverAgeGreaterThanMinimumRentalAge());
	}

	/**
	 * Should return false if guests does not meets minimum age requirement for all the items.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnFalseIfGuestsDoesNotMeetsMinimumAgeRequirementForAllTheItems() throws Exception {
		final Agreement agreement = new AgreementBuilder().withItems(new HashSet<AgreementItem>()).buildAgreement();
		final AgreementItemCollection mockedItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(mockedItems);

		final Agreement otherAgreement = new Agreement();
		when(mockedItems.isDriverAgeGreaterThanMinimumRentalAge(otherAgreement)).thenReturn(false);

		assertFalse(agreement.isDriverAgeGreaterThanMinimumRentalAge());
	}

	/**
	 * Should calculate the damage waiver charges for each of the items.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCalculateTheDamageWaiverChargesForEachOfTheItems() throws Exception {
		final Agreement agreement = new AgreementBuilder().withItems(new HashSet<AgreementItem>()).buildAgreement();

		final AgreementItemCollection mockedItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(mockedItems);

		agreement.calculateDamageWaiverCharges();

		verify(mockedItems).calculateDamageWaiverCharges();
	}

	/**
	 * Should return false if guest age is less than minimum age to rent.
	 */
	@Test
	public void shouldReturnFalseIfGuestAgeIsLessThanMinimumAgeToRent() {
		final Guest mockedGuest = mock(Guest.class);
		final VehicleRentalDetail mockedVehicleRentalDetail = mock(VehicleRentalDetail.class);
		final Agreement agreement = new AgreementBuilder().withGuest(mockedGuest).withVehicleRentalDetail(
		        mockedVehicleRentalDetail).buildAgreement();

		when(mockedVehicleRentalDetail.isDriverAgeGreaterThanMinimumRentalAge(27)).thenReturn(true);
		when(mockedGuest.isDriverAgeGreaterThanMinimumRentalAge(27)).thenReturn(false);

		assertFalse(agreement.isDriverAgeGreaterThanMinimumRentalAge(27));
	}

	/**
	 * Should return false if extra driver age is less than minimum age to rent.
	 */
	@Test
	public void shouldReturnFalseIfExtraDriverAgeIsLessThanMinimumAgeToRent() {
		final VehicleRentalDetail mockedVehicleRentalDetail = mock(VehicleRentalDetail.class);
		final Guest mockedGuest = mock(Guest.class);
		final Agreement agreement = new AgreementBuilder().withVehicleRentalDetail(mockedVehicleRentalDetail).withGuest(
		        mockedGuest).buildAgreement();

		when(mockedVehicleRentalDetail.isDriverAgeGreaterThanMinimumRentalAge(27)).thenReturn(false);
		when(mockedGuest.isDriverAgeGreaterThanMinimumRentalAge(27)).thenReturn(true);

		assertFalse(agreement.isDriverAgeGreaterThanMinimumRentalAge(27));
	}

	/**
	 * Should return true if both guest age and extra driver age is greater than minimum rental age.
	 */
	@Test
	public void shouldReturnTrueIfBothGuestAgeAndExtraDriverAgeIsGreaterThanMinimumRentalAge() {
		final Guest mockedGuest = mock(Guest.class);
		final VehicleRentalDetail mockedVehicleRentalDetail = mock(VehicleRentalDetail.class);
		final Agreement agreement = new AgreementBuilder().withGuest(mockedGuest).withVehicleRentalDetail(
		        mockedVehicleRentalDetail).buildAgreement();

		when(mockedGuest.isDriverAgeGreaterThanMinimumRentalAge(24)).thenReturn(true);
		when(mockedVehicleRentalDetail.isDriverAgeGreaterThanMinimumRentalAge(24)).thenReturn(true);

		assertTrue(agreement.isDriverAgeGreaterThanMinimumRentalAge(24));
	}

	/**
	 * Should update the status if item status was null earlier.
	 */
	@Test
	public void shouldUpdateTheStatusIfItemStatusWasNullEarlier() {
		final Agreement agreement = new Agreement();
		final AgreementStatus expectedAgreementStatus = new AgreementStatus();
		agreement.updateStatusIfRequired(expectedAgreementStatus);

		assertSame(expectedAgreementStatus, agreement.getAgreementStatus());
	}

	/**
	 * Should not update the status if item status was not null earlier.
	 */
	@Test
	public void shouldNotUpdateTheStatusIfItemStatusWasNotNullEarlier() {
		final AgreementStatus expectedAgreementStatus = new AgreementStatus();
		final Agreement agreement = new AgreementBuilder().withAgreementStatus(expectedAgreementStatus).buildAgreement();
		final AgreementStatus agreementStatus = new AgreementStatus();

		agreement.updateStatusIfRequired(agreementStatus);

		assertSame(expectedAgreementStatus, agreement.getAgreementStatus());
	}

	/**
	 * Should should set the price override approved by manager name.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldShouldSetThePriceOverrideApprovedByManagerName() throws Exception {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final Agreement agreement = new AgreementBuilder().withItems(items).buildAgreement();

		final AgreementItemCollection mockedItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(items).thenReturn(mockedItems);

		agreement.setPriceOverrideApprovedBy(1233);

		verify(mockedItems).setPriceOverrideApprovedBy(1233);
	}

	/**
	 * Should should set the quantity override approved by manager name.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldShouldSetTheQuantityOverrideApprovedByManagerName() throws Exception {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final Agreement agreement = new AgreementBuilder().withItems(items).buildAgreement();

		final AgreementItemCollection mockedItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(items).thenReturn(mockedItems);

		agreement.setQuantityOverrideApprovedBy(1233);

		verify(mockedItems).setQuantityOverrideApprovedBy(1233);
	}

	/**
	 * Should return the price override approved by manager name.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnThePriceOverrideApprovedByManagerName() throws Exception {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final Agreement agreement = new AgreementBuilder().withItems(items).buildAgreement();

		final AgreementItemCollection mockedItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(items).thenReturn(mockedItems);
		when(mockedItems.getPriceOverrideApprovedBy()).thenReturn(1233);

		assertEquals(1233, agreement.getPriceOverrideApprovedBy().intValue());
	}

	/**
	 * Should return the quantity override approved by manager name.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTheQuantityOverrideApprovedByManagerName() throws Exception {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final Agreement agreement = new AgreementBuilder().withItems(items).buildAgreement();

		final AgreementItemCollection mockedItems = mock(AgreementItemCollection.class);
		whenNew(AgreementItemCollection.class).withArguments(items).thenReturn(mockedItems);
		when(mockedItems.getQuantityOverrideApprovedBy()).thenReturn(1233);

		assertEquals(1233, agreement.getQuantityOverrideApprovedBy().intValue());
	}

	/**
	 * Should do nothing if the string has no new line chars.
	 */
	@Test
	public void shouldDoNothingIfTheStringHasNoNewLineChars() {
		final Agreement agreement = new Agreement();
		agreement.setOverallComment("Hello world");
		assertEquals("Hello world", agreement.getDisplayOverallComment());
	}

	/**
	 * Should escape the new line chars if there are there in overall comment.
	 */
	@Test
	public void shouldEscapeTheNewLineCharsIfThereAreThereInOverallComment() {
		final Agreement agreement = new Agreement();
		agreement.setOverallComment("Hello world\nTesting another one\n\n\n");
		assertEquals("Hello world\\n\\\n" + "Testing another one\\n\\\n" + "\\n\\\n" + "\\n\\".trim(), agreement
		        .getDisplayOverallComment().trim());
	}

	/**
	 * Should return the agreements that match the status and store number and rental date.
	 */
	@Test
	public void shouldReturnTheAgreementsThatMatchTheStatusAndStoreNumberAndRentalDate() {
		final EntityManager mockedEntityManager = mock(EntityManager.class);
		stub(method(Agreement.class, "entityManager")).andReturn(mockedEntityManager);

		final Query mockedQuery = mock(Query.class);
		when(
		        mockedEntityManager
		                .createQuery("from Agreement a where a.agreementStatus = :status and a.store.storeNumber = :storeNumber "
		                        + "and a.rentalDate between :startDate and :endDate")).thenReturn(mockedQuery);

		final ArrayList<Agreement> expectedAgreement = new ArrayList<Agreement>();
		when(mockedQuery.getResultList()).thenReturn(expectedAgreement);

		assertSame(expectedAgreement, Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(
		        new AgreementStatus(), 1233, Calendar.getInstance(), Calendar.getInstance()));
	}

	/**
	 * Should set the agreement status in the parameters.
	 */
	@Test
	public void shouldSetTheAgreementStatusInTheParameters() {
		final EntityManager mockedEntityManager = mock(EntityManager.class);
		stub(method(Agreement.class, "entityManager")).andReturn(mockedEntityManager);

		final Query mockedQuery = mock(Query.class);
		when(
		        mockedEntityManager
		                .createQuery("from Agreement a where a.agreementStatus = :status and a.store.storeNumber = :storeNumber "
		                        + "and a.rentalDate between :startDate and :endDate")).thenReturn(mockedQuery);

		final ArrayList<Agreement> expectedAgreement = new ArrayList<Agreement>();
		when(mockedQuery.getResultList()).thenReturn(expectedAgreement);

		final AgreementStatus expectedStatus = new AgreementStatus();
		Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(expectedStatus, 1233, Calendar.getInstance(),
		        Calendar.getInstance());

		verify(mockedQuery).setParameter("status", expectedStatus);
	}

	/**
	 * Should set the store number in the parameters.
	 */
	@Test
	public void shouldSetTheStoreNumberInTheParameters() {
		final EntityManager mockedEntityManager = mock(EntityManager.class);
		stub(method(Agreement.class, "entityManager")).andReturn(mockedEntityManager);

		final Query mockedQuery = mock(Query.class);
		when(
		        mockedEntityManager
		                .createQuery("from Agreement a where a.agreementStatus = :status and a.store.storeNumber = :storeNumber "
		                        + "and a.rentalDate between :startDate and :endDate")).thenReturn(mockedQuery);

		final ArrayList<Agreement> expectedAgreement = new ArrayList<Agreement>();
		when(mockedQuery.getResultList()).thenReturn(expectedAgreement);

		final AgreementStatus expectedStatus = new AgreementStatus();
		Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(expectedStatus, 1233, Calendar.getInstance(),
		        Calendar.getInstance());

		verify(mockedQuery).setParameter("storeNumber", 1233);
	}

	/**
	 * Should set the rental date in the parameters.
	 */
	@Test
	public void shouldSetTheRentalDateInTheParameters() {
		final EntityManager mockedEntityManager = mock(EntityManager.class);
		stub(method(Agreement.class, "entityManager")).andReturn(mockedEntityManager);

		final Query mockedQuery = mock(Query.class);
		when(
		        mockedEntityManager
		                .createQuery("from Agreement a where a.agreementStatus = :status and a.store.storeNumber = :storeNumber "
		                        + "and a.rentalDate between :startDate and :endDate")).thenReturn(mockedQuery);

		final ArrayList<Agreement> expectedAgreement = new ArrayList<Agreement>();
		when(mockedQuery.getResultList()).thenReturn(expectedAgreement);

		final Calendar expectedDate = Calendar.getInstance();
		Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(new AgreementStatus(), 1233, expectedDate,
		        expectedDate);

		verify(mockedQuery).setParameter("startDate", expectedDate);
		verify(mockedQuery).setParameter("endDate", expectedDate);
	}

	/**
	 * Should return true if agreement status is pending.
	 */
	@Test
	public void shouldReturnTrueIfAgreementStatusIsPending() {
		final AgreementStatus mockedStatus = mock(AgreementStatus.class);
		when(mockedStatus.isPending()).thenReturn(true);
		assertTrue(new AgreementBuilder().withAgreementStatus(mockedStatus).buildAgreement().isEditable());
	}

	/**
	 * Should return false if agreement status is not pending.
	 */
	@Test
	public void shouldReturnFalseIfAgreementStatusIsNotPending() {
		final AgreementStatus mockedStatus = mock(AgreementStatus.class);
		when(mockedStatus.isPending()).thenReturn(false);
		assertFalse(new AgreementBuilder().withAgreementStatus(mockedStatus).buildAgreement().isEditable());
	}

	/**
	 * Should use agreements to fulfill reservations associated with them.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldUseAgreementsToFulfillReservationsAssociatedWithThem() throws Exception {
		final AgreementItemCollection mockedAgreementItems = mock(AgreementItemCollection.class);
		final Set<AgreementItem> agreementItems = new HashSet<AgreementItem>();

		whenNew(AgreementItemCollection.class).withArguments(agreementItems).thenReturn(mockedAgreementItems);
		final Agreement agreement = new Agreement();
		agreement.setItems(agreementItems);

		agreement.fulfillReservations();

		verify(mockedAgreementItems).fulfillReservations();
	}

	/**
	 * Should return true if agreement is voided.
	 */
	@Test
	public void shouldReturnTrueIfAgreementIsVoided() {
		final AgreementStatus agreementStatus = mock(AgreementStatus.class);
		when(agreementStatus.isVoided()).thenReturn(true);

		assertTrue(new AgreementBuilder().withAgreementStatus(agreementStatus).buildAgreement().isVoided());
	}

	/**
	 * Should return false if agreement is not voided.
	 */
	@Test
	public void shouldReturnFalseIfAgreementIsNotVoided() {
		final AgreementStatus agreementStatus = mock(AgreementStatus.class);
		when(agreementStatus.isVoided()).thenReturn(false);

		assertFalse(new AgreementBuilder().withAgreementStatus(agreementStatus).buildAgreement().isVoided());
	}

	/**
	 * Should return the agreement id that has rented the item passed.
	 */
	@Test
	public void shouldReturnTheAgreementIdThatHasRentedTheItemPassed() {
		final EntityManager entityManager = mock(EntityManager.class);
		stub(method(Agreement.class, "entityManager")).andReturn(entityManager);

		final Query mockedQuery = mock(Query.class);
		when(
		        entityManager.createQuery("select a from Agreement a inner join a.items ai "
                        + "where a.agreementStatus = :status and ai.item = :item and ai.status = :checkedout_and_paid"))
                .thenReturn(mockedQuery);

		final AgreementStatus agreementStatus = new AgreementStatus();
		final AgreementItemStatus agreementItemStatus = new AgreementItemStatus();
		mockStatic(AgreementStatus.class);
		when(AgreementStatus.findActive()).thenReturn(agreementStatus);

		mockStatic(AgreementItemStatus.class);
		when(AgreementItemStatus.findCheckedOutAndPaidInitial()).thenReturn(agreementItemStatus);

		final Item item = new Item();
		when(mockedQuery.setParameter("status", agreementStatus)).thenReturn(mockedQuery);
		when(mockedQuery.setParameter("item", item)).thenReturn(mockedQuery);
		when(mockedQuery.setParameter("checkedout_and_paid", agreementItemStatus)).thenReturn(mockedQuery);
		final ArrayList<Agreement> agreements = new ArrayList<Agreement>();
		final Agreement expectedAgreement = new Agreement();
		agreements.add(expectedAgreement);
		when(mockedQuery.getResultList()).thenReturn(agreements);

		assertEquals(expectedAgreement, Agreement.findActiveAgreementAssociatedWithItem(item));
	}

	/**
	 * Should return new calendar instance if no checkin date existed before.
	 */
	@Test
	public void shouldReturnNullIfNoCheckinDateExistedBefore() {
		assertNull(new Agreement().getCheckinDate());
	}

	/**
	 * Should return existing checkin date if it existed before.
	 */
	@Test
	public void shouldReturnExistingCheckinDateIfItExistedBefore() {
		final Agreement agreement = new Agreement();
        final Calendar checkinTime = Calendar.getInstance();
        agreement.setCheckinDate(checkinTime);
		assertSame(checkinTime, agreement.getCheckinDate());
		final Calendar currentDate = Calendar.getInstance();
		assertTrue(currentDate.compareTo(checkinTime) >= 0);
	}

    @Test
    public void shouldReturnTheNextSerialNumberToAnswerChecklist() throws Exception {
        final Agreement agreement = new Agreement();
        final AgreementItemCollection agreementItems = mock(AgreementItemCollection.class);
        whenNew(AgreementItemCollection.class).withArguments(agreement.getItemList()).thenReturn(agreementItems);

        when(agreementItems.getNextItemSerialNumberToAnswerChecklist()).thenReturn(12312L);

        assertEquals(12312L, agreement.getNextItemSerialNumberToAnswerChecklist().longValue());
    }
    
    @Test
    public void shouldReturnTrueIfAgreementItemsHasAVehicleRented() throws Exception {
        final Agreement agreement = new Agreement();
        final AgreementItemCollection agreementItemCollection = mock(AgreementItemCollection.class);
        whenNew(AgreementItemCollection.class).withArguments(agreement.getItems())
                .thenReturn(agreementItemCollection);

        when(agreementItemCollection.isVehicleRented()).thenReturn(true);

        assertTrue(agreement.isVehicleRented());
    }

    @Test
    public void shouldReturnFalseIfAgreementItemsDoesNotHaveAVehicle() throws Exception {
        final Agreement agreement = new Agreement();
        final AgreementItemCollection agreementItemCollection = mock(AgreementItemCollection.class);
        whenNew(AgreementItemCollection.class).withArguments(agreement.getItems())
                .thenReturn(agreementItemCollection);

        when(agreementItemCollection.isVehicleRented()).thenReturn(false);

        assertFalse(agreement.isVehicleRented());
    }

    @Test
    public void shouldReturnTrueIfAgreementIsPending() {
        final AgreementStatus mockedAgreementStatus = mock(AgreementStatus.class);
        when(mockedAgreementStatus.isPending()).thenReturn(true);
        assertTrue(new AgreementBuilder().withAgreementStatus(mockedAgreementStatus).buildAgreement().isPending());
    }

    @Test
    public void shouldReturnFalseIfAgreementIsNotPending() {
        final AgreementStatus mockedAgreementStatus = mock(AgreementStatus.class);
        when(mockedAgreementStatus.isPending()).thenReturn(false);
        assertFalse(new AgreementBuilder().withAgreementStatus(mockedAgreementStatus).buildAgreement().isPending());
    }

    @Test
    public void shouldReturnTrueIfAgreementIsActive() {
        final AgreementStatus mockedAgreementStatus = mock(AgreementStatus.class);
        when(mockedAgreementStatus.isActive()).thenReturn(true);
        assertTrue(new AgreementBuilder().withAgreementStatus(mockedAgreementStatus).buildAgreement().isActive());
    }

    @Test
    public void shouldReturnFalseIfAgreementIsNotActive() {
        final AgreementStatus mockedAgreementStatus = mock(AgreementStatus.class);
        when(mockedAgreementStatus.isActive()).thenReturn(false);
        assertFalse(new AgreementBuilder().withAgreementStatus(mockedAgreementStatus).buildAgreement().isActive());
    }

    @Test
    public void shouldUpdateTheCheckoutDate() throws Exception {
        final AgreementItemCollection agreementItemCollection = mock(AgreementItemCollection.class);
        final Agreement agreement = new Agreement();
        whenNew(AgreementItemCollection.class)
                .withArguments(agreement.getItems()).thenReturn(agreementItemCollection);
        
        final Calendar transactionDate = Calendar.getInstance();
        agreement.updateCheckoutDate(transactionDate);

        verify(agreementItemCollection).updateCheckoutDate(transactionDate);
    }

    @Test
    public void shouldUpdateTheStutasOfItemsThatWereReturnedOnly() throws Exception {
        final AgreementItemCollection agreementItemCollection = mock(AgreementItemCollection.class);
        final Agreement agreement = new Agreement();
        whenNew(AgreementItemCollection.class)
                .withArguments(agreement.getItems()).thenReturn(agreementItemCollection);

        final AgreementItemStatus agreementItemStatus = new AgreementItemStatus();
        agreement.updateAgreementItemForReturnedItems(agreementItemStatus);

        verify(agreementItemCollection).updateAgreementItemForReturnedItems(
                agreementItemStatus
        );
    }

    @Test
    public void shouldUpdateTheStatusOnlyIfAllItemsAreInReturnedAndCompletedState() throws Exception {
        final AgreementItemCollection agreementItemCollection = mock(AgreementItemCollection.class);
        final Agreement agreement = new Agreement();
        whenNew(AgreementItemCollection.class)
                .withArguments(agreement.getItems()).thenReturn(agreementItemCollection);

        when(agreementItemCollection.isEveryItemReturnedAndPaid()).thenReturn(true);

        final AgreementStatus completedStatus = new AgreementStatus();
        agreement.updateStatusToCompletedIfAllItemsReturned(completedStatus);

        assertSame(completedStatus, agreement.getAgreementStatus());
    }

    @Test
    public void shouldNotUpdateTheStatusIfNotAllItemsAreInReturnedAndCompletedState() throws Exception {
        final AgreementItemCollection agreementItemCollection = mock(AgreementItemCollection.class);
        final Agreement agreement = new Agreement();
        whenNew(AgreementItemCollection.class)
                .withArguments(agreement.getItems()).thenReturn(agreementItemCollection);

        when(agreementItemCollection.isEveryItemReturnedAndPaid()).thenReturn(false);

        final AgreementStatus completedStatus = new AgreementStatus();
        agreement.updateStatusToCompletedIfAllItemsReturned(completedStatus);

        assertFalse(completedStatus == agreement.getAgreementStatus());
    }

    @Test
    public void shouldReturnTrueIfAgreementHasItemsOtherThanOnesThatRequireAdditionalDriver() throws Exception {
        final Agreement agreement = new Agreement();
        final AgreementItemCollection items = mock(AgreementItemCollection.class);
        whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(items);

        when(items.getHasOtherItemsThatDoNotRequireAdditionalDriver()).thenReturn(true);

        assertTrue(agreement.getHasOtherItemsThatDoNotRequireAdditionalDriver());
    }

    @Test
    public void shouldReturnFalseIfAgreementDoesNotHaveItemsOtherThanOnesThatRequireAdditionalDriver() throws Exception {
        final Agreement agreement = new Agreement();
        final AgreementItemCollection items = mock(AgreementItemCollection.class);
        whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(items);

        when(items.getHasOtherItemsThatDoNotRequireAdditionalDriver()).thenReturn(false);

        assertFalse(agreement.getHasOtherItemsThatDoNotRequireAdditionalDriver());
    }

    @Test
    public void shouldReturnTrueIfAgreementHasItemsThatAreReturnedButNotPaid() throws Exception {
        final Agreement agreement = new Agreement();
        final AgreementItemCollection items = mock(AgreementItemCollection.class);
        
        whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(items);

        when(items.hasItemsThatAreReturnedButNotPaid()).thenReturn(true);

        assertTrue(agreement.hasItemsThatAreReturnedButNotPaid());
    }

    @Test
    public void shouldReturnFalseIfAgreementDoesNotHaveItemsThatAreReturnedButNotPaid() throws Exception {
        final Agreement agreement = new Agreement();
        final AgreementItemCollection items = mock(AgreementItemCollection.class);

        whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(items);

        when(items.hasItemsThatAreReturnedButNotPaid()).thenReturn(false);

        assertFalse(agreement.hasItemsThatAreReturnedButNotPaid());
    }

    @Test
    public void shouldReturnTrueIfAgreementHasNonEmptyItems() {
        assertTrue(new AgreementBuilder().withItem(new AgreementItem()).buildAgreement().hasItems());
    }

    @Test
    public void shouldReturnFalseIfAgreementHasEmptyItems() {
        assertFalse(new Agreement().hasItems());
    }

    @Test
    public void shouldReturnTrueIfAgreementHasNotTotalAdditionalCharge() {
        final Agreement agreement = spy(new Agreement());
        doReturn(new BigDecimal(0.0001)).when(agreement).getTotalAdditionalChargeAmount();

        assertTrue(agreement.isNoTotalAdditionalChargeApplicable());
    }

    @Test
    public void shouldReturnTrueIfAgreementHasNotTotalAdditionalChargeAndItsLessThanTheDesiredValue() {
        final Agreement agreement = spy(new Agreement());
        doReturn(new BigDecimal(-0.0001)).when(agreement).getTotalAdditionalChargeAmount();

        assertTrue(agreement.isNoTotalAdditionalChargeApplicable());
    }

    @Test
    public void shouldReturnTrueIfAgreementHasNotTotalAdditionalChargeAndItsEqualToZero() {
        final Agreement agreement = spy(new Agreement());
        doReturn(new BigDecimal(0.0)).when(agreement).getTotalAdditionalChargeAmount();

        assertTrue(agreement.isNoTotalAdditionalChargeApplicable());
    }

    @Test
    public void shouldReturnFalseIfAgreementHasTotalAdditionalCharge() {
        final Agreement agreement = spy(new Agreement());
        doReturn(new BigDecimal(0.01)).when(agreement).getTotalAdditionalChargeAmount();

        assertFalse(agreement.isNoTotalAdditionalChargeApplicable());
    }
    
    @Test
    public void shouldReturnFalseIfTheAgreementIsNotInActiveOrPendingState() {
        final AgreementStatus agreementStatus = mock(AgreementStatus.class);
        final Agreement agreement = new AgreementBuilder().withAgreementStatus(agreementStatus).buildAgreement();

        when(agreementStatus.isActive()).thenReturn(false);
        when(agreementStatus.isPending()).thenReturn(false);

        assertFalse(agreement.getCancelorVoidAllowed());
    }

    @Test
    public void shouldReturnTrueIfTheAgreementIsInActiveStateAndNoneOfTheItemsHaveBeenReturnedYet() throws Exception {
        final AgreementStatus agreementStatus = mock(AgreementStatus.class);
        final Agreement agreement = new AgreementBuilder().withAgreementStatus(agreementStatus).buildAgreement();

        when(agreementStatus.isActive()).thenReturn(true);
        final AgreementItemCollection agreementItemCollection = mock(AgreementItemCollection.class);
        whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(agreementItemCollection);

        when(agreementItemCollection.isEveryItemCheckedOutOrCheckedOutAndPaidInitial()).thenReturn(true);

        assertTrue(agreement.getCancelorVoidAllowed());
    }

    @Test
    public void shouldReturnTrueIfTheAgreementIsInPendingStateAndNoneOfTheItemsHaveBeenReturnedYet() throws Exception {
        final AgreementStatus agreementStatus = mock(AgreementStatus.class);
        final Agreement agreement = new AgreementBuilder().withAgreementStatus(agreementStatus).buildAgreement();

        when(agreementStatus.isPending()).thenReturn(true);
        final AgreementItemCollection agreementItemCollection = mock(AgreementItemCollection.class);
        whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(agreementItemCollection);

        when(agreementItemCollection.isEveryItemCheckedOutOrCheckedOutAndPaidInitial()).thenReturn(true);

        assertTrue(agreement.getCancelorVoidAllowed());
    }

    @Test
    public void shouldReturnFalseIfTheAgreementIsInPendingStateButItemsHaveBeenReturned() throws Exception {
        final AgreementStatus agreementStatus = mock(AgreementStatus.class);
        final Agreement agreement = new AgreementBuilder().withAgreementStatus(agreementStatus).buildAgreement();

        when(agreementStatus.isPending()).thenReturn(true);
        final AgreementItemCollection agreementItemCollection = mock(AgreementItemCollection.class);
        whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(agreementItemCollection);

        when(agreementItemCollection.isEveryItemCheckedOutOrCheckedOutAndPaidInitial()).thenReturn(false);

        assertFalse(agreement.getCancelorVoidAllowed());
    }

    @Test
    public void shouldReturnFalseIfTheAgreementIsInActiveStateButItemsHaveBeenReturned() throws Exception {
        final AgreementStatus agreementStatus = mock(AgreementStatus.class);
        final Agreement agreement = new AgreementBuilder().withAgreementStatus(agreementStatus).buildAgreement();

        when(agreementStatus.isActive()).thenReturn(true);
        final AgreementItemCollection agreementItemCollection = mock(AgreementItemCollection.class);
        whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(agreementItemCollection);

        when(agreementItemCollection.isEveryItemCheckedOutOrCheckedOutAndPaidInitial()).thenReturn(false);

        assertFalse(agreement.getCancelorVoidAllowed());
    }

    @Test
    public void shouldReturnTheValueToUserNameIfStoreUserIsNotNull() {
        final StoreUserInfo storeUser = new StoreUserInfo();
        storeUser.setName("Hello SU");
        final Agreement agreement = new Agreement();
        agreement.setStoreUser(storeUser);

        assertEquals("Hello SU", agreement.getCreatedByTeamMemberName());
    }

    @Test
    public void shouldReturnTheCreatedByTeamMemberNumberValueIfStoreUserIsNotSet() {
        final Agreement agreement = new Agreement();
        agreement.setCreatedByTeamMemberNumber(1233);
        assertEquals("1233", agreement.getCreatedByTeamMemberName());
	}

	@Test
    public void shouldFindTheListOfAgreementsThatAreOlderThanTheGivenThresholdValue() {
        final Query query = mock(Query.class);
        final Calendar threshold = Calendar.getInstance();
        final AgreementStatus pendingStatus = new AgreementStatus();
        mockStatic(AgreementStatus.class);
        when(AgreementStatus.findPending()).thenReturn(pendingStatus);

        stub(method(Agreement.class, "findAgreementsByAgreementStatusAndLastUpdateDateLessThan",
                AgreementStatus.class, Calendar.class)).andReturn(query);

        final ArrayList<Agreement> oldAgreements = new ArrayList<Agreement>();
        when(query.getResultList()).thenReturn(oldAgreements);

        assertSame(oldAgreements, Agreement.findAllPendingAgreementsOlderThan(threshold));
    }

    @Test
    public void shouldReturnTheNextUpcomingDueByDate() throws Exception {
        final Agreement agreement = new Agreement();
        final AgreementItemCollection agreementItemCollection = mock(AgreementItemCollection.class);
        whenNew(AgreementItemCollection.class).withArguments(agreement.getItems())
                .thenReturn(agreementItemCollection);

        final Calendar expectedDueBy = Calendar.getInstance();
        when(agreementItemCollection.getUpcomingDueBy()).thenReturn(expectedDueBy);

        assertSame(expectedDueBy, agreement.getUpcomingDueBy());
    }

    @Test
    public void shouldUpdateTheLastUpdatedDateOfTheAgreement() {
        final Calendar currentDate = Calendar.getInstance();
        final Agreement agreement = new Agreement();
        agreement.updateLastUpdatedDate();

        assertTrue(currentDate.compareTo(agreement.getLastUpdateDate()) <= 0);
    }

    @Test
    public void shouldAppendTheCommentIfAlreadyThereIsSomeComment() {
        final Agreement agreement = new Agreement();
        agreement.setOverallComment("Hello");
        agreement.appendComment(" World");

        assertEquals("Hello World", agreement.getOverallComment());
    }

    @Test
    public void shouldNotAddNullToCommentIfNoCommentExists() {
        final Agreement agreement = new Agreement();
        agreement.appendComment(" World");

        assertEquals(" World", agreement.getOverallComment());
    }

    @Test
    public void shouldReturnTrueIfTheIdIsNull() {
        assertTrue(new Agreement().isTransient());
    }

    @Test
    public void shouldReturnFalseIfTheIdIsNotNull() {
        final Agreement agreement = new Agreement();
        agreement.setId(1233L);
        assertFalse(agreement.isTransient());
    }

    @Test
    public void shouldCopyTheUnMaskedValueOfTheIdentificationNumber() {
        final Guest guest1 = mock(Guest.class);
        final Guest guest2 = mock(Guest.class);

        new AgreementBuilder().withGuest(guest1).buildAgreement().copyTransientInformationFrom(
                new AgreementBuilder().withGuest(guest2).buildAgreement());

        verify(guest1).copyTransientInformationFrom(guest2);
    }

    @Test
    public void shouldReturnTrueIfTotalDamageWaiverCreditedIsNegative() {
        final Agreement agreement = spy(new Agreement());
        doReturn(new BigDecimal(-1.0)).when(agreement).getTotalDamageWaiverCreditOfItemsCurrentlyCheckedin();
        assertTrue(agreement.isDamageWaiverToBeCredited());
    }

    @Test
    public void shouldReturnFalseIfTotalDamageWaiverCreditedIsZero() {
        final Agreement agreement = spy(new Agreement());
        doReturn(new BigDecimal("0.0")).when(agreement).getTotalDamageWaiverCreditOfItemsCurrentlyCheckedin();
        assertFalse(agreement.isDamageWaiverToBeCredited());
    }

    @Test
    public void shouldReturnFalseIfTotalDamageWaiverCreditedIsGreaterThanZero() {
        final Agreement agreement = spy(new Agreement());
        doReturn(new BigDecimal(1.0)).when(agreement).getTotalDamageWaiverCreditOfItemsCurrentlyCheckedin();
        assertFalse(agreement.isDamageWaiverToBeCredited());
    }
    
    @Test
    public void shouldConstructTheFullTransactionNumber() {
        final Agreement agreement = new Agreement();
        final Store store = new Store();
        final Calendar initialPaidDate = Calendar.getInstance();
        initialPaidDate.set(2010, 10, 10);
        store.setStoreNumber(8888);
        agreement.setStore(store);
        agreement.setInitialPaidDate(initialPaidDate);
        agreement.setRegisterNumber("09");
        agreement.setTransactionNumber("0345");
        assertEquals("8888" + (initialPaidDate.get(Calendar.MONTH) + 1)
                + initialPaidDate.get(Calendar.DATE) + String.valueOf(initialPaidDate.get(Calendar.YEAR)).substring(2)
         + "090345", agreement.getFullTransactionIdentifier());
    }
    
    @Test
    public void shouldNotRemoveZerosFromTheDatesWhileConstructingTheFullTransactionNumber() {
        final Agreement agreement = new Agreement();
        final Store store = new Store();
        final Calendar initialPaidDate = Calendar.getInstance();
        initialPaidDate.set(2010, 1, 1, 1, 1);

        store.setStoreNumber(8888);
        agreement.setStore(store);
        agreement.setInitialPaidDate(initialPaidDate);
        agreement.setRegisterNumber("09");
        agreement.setTransactionNumber("0345");
        assertEquals("8888020110090345", agreement.getFullTransactionIdentifier());
    }

    @Test
    public void shouldReturnListOfCurrentlyCheckedinItems() throws Exception {
        final Agreement agreement = new Agreement();
        final AgreementItemCollection agreementItemCollection = mock(AgreementItemCollection.class);
        final AgreementItemCollection newAgreementItemCollection = mock(AgreementItemCollection.class);
        whenNew(AgreementItemCollection.class).withArguments(agreement.getItems()).thenReturn(agreementItemCollection);
        when(agreementItemCollection.getCurrentlyCheckedInItems()).thenReturn(newAgreementItemCollection);
        assertSame(newAgreementItemCollection, agreement.getCurrentlyCheckedInItems());
    }
}