package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest(ReservationAgreementStatus.class)
public class ReservationAgreementCollectionTest {

    @Test
    public void shouldUpdateTheStatusOfTheReservationAgreementToCanceled() {
        final ReservationAgreementStatus status = new ReservationAgreementStatus();
        mockStatic(ReservationAgreementStatus.class);
        when(ReservationAgreementStatus.findCancelled()).thenReturn(status);

        final ArrayList<ReservationAgreement> reservationAgreements = new ArrayList<ReservationAgreement>();
        final ReservationAgreement first = new ReservationAgreement();
        final ReservationAgreement second = new ReservationAgreement();
        reservationAgreements.add(first);
        reservationAgreements.add(second);

        new ReservationAgreementCollection(reservationAgreements).cancel();

        assertSame(status, first.getStatus());
        assertSame(status, second.getStatus());
    }

    @Test
    public void shouldUpdateTheOverallCommentOfCancelledReservations() {
        final ReservationAgreementStatus status = new ReservationAgreementStatus();
        mockStatic(ReservationAgreementStatus.class);
        when(ReservationAgreementStatus.findCancelled()).thenReturn(status);

        final ArrayList<ReservationAgreement> reservationAgreements = new ArrayList<ReservationAgreement>();
        final ReservationAgreement first = new ReservationAgreement();
        final ReservationAgreement second = new ReservationAgreement();
        second.setOverallComment("HelloWorld");
        reservationAgreements.add(first);
        reservationAgreements.add(second);

        new ReservationAgreementCollection(reservationAgreements).cancel();

        
        assertEquals(" Reservation was cancelled by System - Past Reservation Time", first.getOverallComment());
        assertEquals("HelloWorld Reservation was cancelled by System - Past Reservation Time",
                second.getOverallComment());
    }
}
