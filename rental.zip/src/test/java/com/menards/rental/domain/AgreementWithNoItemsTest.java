/*
 * AgreementWithNoItemsTest.java
 */
package com.menards.rental.domain;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * Test for agreement in a state with no items.
 *
 * @author geoff
 * @since May 26, 2010
 */
public class AgreementWithNoItemsTest {
	
	/** The agreement. */
	private Agreement agreement;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		agreement = new Agreement();
		agreement.setItems(null);
	}

	/**
	 * Should have sub total of zero.
	 */
	@Test
	public void shouldHaveSubTotalOfZero() {
		assertEquals(0.0, agreement.getSubTotal().doubleValue(), 0.0001);
	}

	/**
	 * Should have rental total of zero.
	 */
	@Test
	public void shouldHaveRentalTotalOfZero() {
		assertEquals(0.0, agreement.getEffectiveRentalTotalExcludingDamageWaiver().doubleValue(), 0.0001);
	}

	/**
	 * Should have damage waiver total of zero.
	 */
	@Test
	public void shouldHaveDamageWaiverTotalOfZero() {
		assertEquals(0.0, agreement.getDamageWaiverTotal().doubleValue(), 0.0001);
	}
}
