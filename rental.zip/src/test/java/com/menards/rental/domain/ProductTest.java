/*
 * ProductTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.*;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.doReturn;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.spy;
import static org.powermock.api.mockito.PowerMockito.verifyPrivate;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.whenNew;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.stub;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.builder.ProductBuilder;

import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 * Created by IntelliJ IDEA. User: deep Date: 11 Jun, 2010 Time: 5:27:59 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest( { Product.class })
public class ProductTest {
	
	/** The product. */
	private Product product;
    private SKUInfo skuInfo;

    /**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		product = new Product();
        skuInfo = mock(SKUInfo.class);
        product.setSkuInfo(skuInfo);
	}

    /**
	 * Should copy description from sku info.
	 */
	@Test
	public void shouldCopyDescriptionFromSKUInfo() {
		final SKUInfo mockedSKUInfo = mock(SKUInfo.class);
		when(mockedSKUInfo.getDescription()).thenReturn("Hello Description");

		final Product product = new ProductBuilder().withSkuInfo(mockedSKUInfo).buildProduct();

		product.copyDescription();

		assertEquals("Hello Description", product.getDescription());
	}

	/**
	 * Should copy values.
	 */
	@Test
	public void shouldCopyValues() {
		final Product product = spy(new Product());

		doNothing().when(product).copyDescription();

		product.copyValuesFromSKU();

		verify(product).copyDescription();
	}

    /**
	 * Should return true if guests age is greater than minimum required.
	 */
	@Test
	public void shouldReturnTrueIfGuestsAgeIsGreaterThanMinimumRequired() {
		final Agreement mockedAgreement = mock(Agreement.class);

		when(mockedAgreement.isDriverAgeGreaterThanMinimumRentalAge(24)).thenReturn(true);

		product.setMinimumAgeToRent(24);

		assertTrue(product.isDriverAgeGreaterThanMinimumRentalAge(mockedAgreement));
	}

	/**
	 * Should return false if guests age is less than minimum required.
	 */
	@Test
	public void shouldReturnFalseIfGuestsAgeIsLessThanMinimumRequired() {
		final Agreement mockedAgreement = mock(Agreement.class);

		when(mockedAgreement.isDriverAgeGreaterThanMinimumRentalAge(24)).thenReturn(false);

		product.setMinimumAgeToRent(24);

		assertFalse(product.isDriverAgeGreaterThanMinimumRentalAge(mockedAgreement));
	}

	@Test
	public void shouldReturnTrueIfGuestsAgeIsGreaterThanMinimumLimit() {
		final Guest guest = mock(Guest.class);

		when(guest.isDriverAgeGreaterThanMinimumRentalAge(24)).thenReturn(true);

		product.setMinimumAgeToRent(24);

		assertTrue(product.isGuestAgeGreaterThanMinimumAge(guest));
	}

	@Test
	public void shouldReturnFalseIfGuestsAgeIsLessThanMinimumLimit() {
		final Guest guest = mock(Guest.class);

		when(guest.isDriverAgeGreaterThanMinimumRentalAge(24)).thenReturn(false);

		product.setMinimumAgeToRent(24);

		assertFalse(product.isGuestAgeGreaterThanMinimumAge(guest));
	}

	/**
	 * Should return true if reservation is present for given store.
	 *
	 * @throws Exception the exception
	 */
	// Commented out since reservations are no longer supported
//	@Test
//	public void shouldReturnTrueIfReservationIsPresentForGivenStore() throws Exception {
//		final Set<Reservation> reservations = new HashSet<Reservation>();
//		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
//
//		whenNew(ReservationCollection.class).withArguments(argThat(new ArgumentMatcher<Collection<Reservation>>() {
//
//			@Override
//			public boolean matches(final Object o) {
//				return ((Collection<Reservation>) o).isEmpty();
//			}
//		})).thenReturn(mockedReservations);
//		when(mockedReservations.isAnyReservationForStore(1233)).thenReturn(true);
//		assertTrue(new ProductBuilder().withReservations(reservations).buildProduct().hasAnyReservationsFor(1233));
//	}

	/**
	 * Should return false if reservation is not found for the given store.
	 *
	 * @throws Exception the exception
	 */
	// Commented out since reservations are no longer supported
//	@Test
//	public void shouldReturnFalseIfReservationIsNotFoundForTheGivenStore() throws Exception {
//		final Set<Reservation> reservations = new HashSet<Reservation>();
//		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
//
//		whenNew(ReservationCollection.class).withArguments(argThat(new ArgumentMatcher<Collection<Reservation>>() {
//
//			@Override
//			public boolean matches(final Object o) {
//				return ((Collection<Reservation>) o).isEmpty();
//			}
//		})).thenReturn(mockedReservations);
//		when(mockedReservations.isAnyReservationForStore(1233)).thenReturn(false);
//		assertFalse(new ProductBuilder().withReservations(reservations).buildProduct().hasAnyReservationsFor(1233));
//	}

	/**
	 * Should return true if reservation overlap the given time period.
	 *
	 * @throws Exception the exception
	 */
	// Commented out since reservations are no longer supported
//	@Test
//	public void shouldReturnTrueIfReservationOverlapTheGivenTimePeriod() throws Exception {
//		final Set<Reservation> reservations = new HashSet<Reservation>();
//		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
//		final Calendar outDate = Calendar.getInstance();
//		final Calendar inDate = Calendar.getInstance();
//
//		whenNew(ReservationCollection.class).withArguments(argThat(new ArgumentMatcher<Collection<Reservation>>() {
//
//			@Override
//			public boolean matches(final Object o) {
//				return ((Collection<Reservation>) o).isEmpty();
//			}
//		})).thenReturn(mockedReservations);
//		when(mockedReservations.isAnyReservationOverlappingForStore(1233, outDate, inDate)).thenReturn(true);
//		assertTrue(new ProductBuilder().withReservations(reservations).buildProduct().hasOverlappingReservationsFor(1233,
//		        outDate, inDate));
//	}

	/**
	 * Should return false if reservation do not overlap the given time period.
	 *
	 * @throws Exception the exception
	 */
	// Commented out since reservations are no longer supported
//	@Test
//	public void shouldReturnFalseIfReservationDoNotOverlapTheGivenTimePeriod() throws Exception {
//		final Set<Reservation> reservations = new HashSet<Reservation>();
//		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
//
//		whenNew(ReservationCollection.class).withArguments(argThat(new ArgumentMatcher<Collection<Reservation>>() {
//
//			@Override
//			public boolean matches(final Object o) {
//				return ((Collection<Reservation>) o).isEmpty();
//			}
//		})).thenReturn(mockedReservations);
//		when(
//		        mockedReservations.isAnyReservationOverlappingForStore(anyInt(), Matchers.<Calendar> anyObject(), Matchers
//		                .<Calendar> anyObject())).thenReturn(false);
//		assertFalse(new ProductBuilder().withReservations(reservations).buildProduct().hasOverlappingReservationsFor(1233,
//		        null, null));
//	}

	/**
	 * Should count overlapping reservations for the given time period.
	 *
	 * @throws Exception the exception
	 */
	// Commented out since reservations are no longer supported
//	@Test
//	public void shouldCountOverlappingReservationsForTheGivenTimePeriod() throws Exception {
//		final Set<Reservation> reservations = new HashSet<Reservation>();
//		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
//		final Calendar outDate = Calendar.getInstance();
//		final Calendar inDate = Calendar.getInstance();
//
//		whenNew(ReservationCollection.class).withArguments(argThat(new ArgumentMatcher<Collection<Reservation>>() {
//
//			@Override
//			public boolean matches(final Object o) {
//				return ((Collection<Reservation>) o).isEmpty();
//			}
//		})).thenReturn(mockedReservations);
//		when(
//		        mockedReservations.countMinimumNumberOfItemsRequiredToFulfillCurrentReservationsForAStoreForGivenDuration(
//		                1233, outDate, inDate)).thenReturn(18);
//		assertEquals(18, new ProductBuilder().withReservations(reservations).buildProduct()
//		        .countActuallyOverlappingReservationsForStore(1233, outDate, inDate));
//	}

	/**
	 * Should return overlapping reservations.
	 *
	 * @throws Exception the exception
	 */
	// Commented out since reservations are no longer supported
//	@Test
//	public void shouldReturnOverlappingReservations() throws Exception {
//		final Set<Reservation> reservations = new HashSet<Reservation>();
//		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
//		final Calendar outDate = Calendar.getInstance();
//		final Calendar inDate = Calendar.getInstance();
//
//		whenNew(ReservationCollection.class).withArguments(argThat(new ArgumentMatcher<Collection<Reservation>>() {
//
//			@Override
//			public boolean matches(final Object o) {
//				return ((Collection<Reservation>) o).isEmpty();
//			}
//		})).thenReturn(mockedReservations);
//		final List<List<Reservation>> expectedReservations = new ArrayList<List<Reservation>>();
//		when(mockedReservations.getNonOverlappingReservationsListForStore(1233, outDate, inDate)).thenReturn(
//		        expectedReservations);
//		assertEquals(expectedReservations, new ProductBuilder().withReservations(reservations).buildProduct()
//		        .getNonOverlappingReservationsListForStore(1233, outDate, inDate));
//
//	}

	/**
	 * Should operate only on sorted open reservations.
	 *
	 * @throws Exception the exception
	 */
	// Commented out since reservations are no longer supported
//	@Test
//	public void shouldOperateOnlyOnSortedOpenReservations() throws Exception {
//		final Set<Reservation> reservations = new HashSet<Reservation>();
//		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
//
//		whenNew(ReservationCollection.class).withArguments(argThat(new ArgumentMatcher<Collection<Reservation>>() {
//
//			@Override
//			public boolean matches(final Object o) {
//				return ((Collection<Reservation>) o).isEmpty();
//			}
//		})).thenReturn(mockedReservations);
//		when(mockedReservations.isAnyReservationForStore(1233)).thenReturn(true);
//		product = spy(new Product());
//		//product.setReservations(reservations);
//
//		doReturn(new ArrayList<Reservation>()).when(product, "getSortedOpenReservations");
//
//		product.hasAnyReservationsFor(1233);
//
//		verifyPrivate(product).invoke("getSortedOpenReservations");
//	}

	/**
	 * Should return open reservations for store.
	 *
	 * @throws Exception the exception
	 */
	// Commented out since reservations are no longer supported
//	@Test
//	public void shouldReturnOpenReservationsForStore() throws Exception {
//		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
//		final Set<Reservation> reservations = new HashSet<Reservation>();
//		whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockedReservations);
//		final List<Reservation> expectedReservations = new ArrayList<Reservation>();
//		when(mockedReservations.getOpenReservationsFor(1233)).thenReturn(expectedReservations);
//
//		assertSame(expectedReservations, new ProductBuilder().withReservations(reservations).buildProduct()
//		        .getOpenReservationsFor(1233));
//	}

	/**
	 * Should return overlapping open reservations for the given store.
	 *
	 * @throws Exception the exception
	 */
	// Commented out since reservations are no longer supported
//	@Test
//	public void shouldReturnOverlappingOpenReservationsForTheGivenStore() throws Exception {
//		final Set<Reservation> reservations = new HashSet<Reservation>();
//		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
//		whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockedReservations);
//
//		//product.setReservations(reservations);
//
//		final Calendar outDate = Calendar.getInstance();
//		final Calendar inDate = Calendar.getInstance();
//		final List<Reservation> expectedReservations = new ArrayList<Reservation>();
//		when(mockedReservations.getOverlappingOpenReservationsForStore(1233, outDate, inDate)).thenReturn(
//		        expectedReservations);
//
//		assertSame(expectedReservations, product.getOverlappingOpenReservationsForStore(1233, outDate, inDate));
//	}

	/**
	 * Should return true if id matching the one passed in.
	 */
	@Test
	public void shouldReturnTrueIfIdMatchingTheOnePassedIn() {
		product.setId(1233L);
		assertTrue(product.isIdMatching(1233L));
	}

	/**
	 * Should return false if id do not match.
	 */
	@Test
	public void shouldReturnFalseIfIdDoNotMatch() {
		product.setId(1233L);
		assertFalse(product.isIdMatching(7866L));
	}

	/**
	 * Should create the charge amount.
	 */
	@Test
	public void shouldCreateTheChargeAmount() {
		final SKUInfo skuInfo = mock(SKUInfo.class);

		final ChargeInfo expectedChargeInfo = new ChargeInfo();
		when(skuInfo.createChargeInfo()).thenReturn(expectedChargeInfo);
		product.setSkuInfo(skuInfo);

		assertSame(expectedChargeInfo, product.createChargeInfo());
	}

    @Test
    public void shouldReturnNullIfNoProductsExistsForTheChosendBaseSKU() {
        final EntityManager entityManager = mock(EntityManager.class);
        stub(method(Product.class, "entityManager", null)).andReturn(entityManager);

        final Query query = mock(Query.class);
        when(entityManager.createQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), anyLong())).thenReturn(query);
        when(query.getResultList()).thenReturn(new ArrayList<Product>());

        assertNull(Product.findProductByBaseSKUId(1233L));
    }
    
    @Test
    public void shouldReturnTheFirstProductMatchingTheBaseSKUValue() {
        final EntityManager entityManager = mock(EntityManager.class);
        stub(method(Product.class, "entityManager", null)).andReturn(entityManager);

        final Query query = mock(Query.class);
        when(entityManager.createQuery("from Product p where p.skuInfo.baseSKU.id=:baseSKUId")).thenReturn(query);
        when(query.setParameter("baseSKUId", 1233L)).thenReturn(query);
        final ArrayList<Product> products = new ArrayList<Product>();
        final Product expectedProduct = new Product();
        products.add(expectedProduct);
        when(query.getResultList()).thenReturn(products);

        assertSame(expectedProduct, Product.findProductByBaseSKUId(1233L));
    }

    @Test
    public void shouldCopyTheUsageTrackingFlag() {
        final Product other = new Product();
        other.setUsageTrackingFlag(true);

        product.copyOtherInformationFrom(other);

        assertTrue(product.getUsageTrackingFlag());
    }

    @Test
    public void shouldCopyTheUsageTrackingText() {
        final Product other = new Product();
        other.setUsageTrackingText("Hello Usage Tracking");

        product.copyOtherInformationFrom(other);

        assertEquals("Hello Usage Tracking", product.getUsageTrackingText());
    }

    @Test
    public void shouldCopyTheRentalPromptText() {
        final Product other = new Product();
        other.setRentalPromptText("Hello Rental Prompt");

        product.copyOtherInformationFrom(other);

        assertEquals("Hello Rental Prompt", product.getRentalPromptText());
    }

    @Test
    public void shouldCopyTheIsDriverLicenseRequired() {
        final Product other = new Product();
        other.setIsDriverLicenseRequired(false);

        product.copyOtherInformationFrom(other);

        assertFalse(product.isDriverLicenseRequired());
    }

    @Test
    public void shouldCopyTheIsInsuranceAdditionalDriverLicenseRequired() {
        final Product other = new Product();
        other.setInsuranceAdditionalDriverLicenseRequired(true);

        product.copyOtherInformationFrom(other);

        assertTrue(product.isInsuranceAdditionalDriverLicenseRequired());
    }

    @Test
    public void shouldCopyTheIsSaleAllowed() {
        final Product other = new Product();
        other.setIsSaleAllowed(true);

        product.copyOtherInformationFrom(other);

        assertTrue(product.getIsSaleAllowed());
    }

    @Test
    public void shouldCopyTheMinimumAgeToRent() {
        final Product other = new Product();
        other.setMinimumAgeToRent(54);

        product.copyOtherInformationFrom(other);

        assertEquals(54, product.getMinimumAgeToRent());
    }

    @Test
    public void shouldCopyTheVendorEmail() {
        final Product other = new Product();
        other.setVendorEmail("hi@hi.com");

        product.copyOtherInformationFrom(other);

        assertEquals("hi@hi.com", product.getVendorEmail());
    }

    @Test
    public void shouldCopyTheIsDamageWaiverAvailable() {
        final Product other = new Product();
        other.setIsDamageWaiverAvailable(true);

        product.copyOtherInformationFrom(other);

        assertTrue(product.getIsDamageWaiverAvailable());
    }

    @Test
    public void shouldCopySkuInforFrom() {
        final Product other = new Product();
        final SKUInfo otherSkuInfo = new SKUInfo();
        other.setSkuInfo(otherSkuInfo);

        product.copyOtherInformationFrom(other);

        verify(skuInfo).copyHoursFrom(otherSkuInfo);
    }

    @Test
    public void shouldReturnListOfProductWithVendorEmailSetup() {
        final Query query = mock(Query.class);
        final EntityManager entityManager = mock(EntityManager.class);
        stub(method(Product.class, "entityManager", null))
                .andReturn(entityManager);
        when(entityManager.createQuery("SELECT Product FROM Product AS product " +
                        "WHERE product.vendorEmail IS NOT NULL  AND product.vendorEmail != :vendorEmail"))
                .thenReturn(query);
        when(query.setParameter("vendorEmail", "")).thenReturn(query);
        final ArrayList<Product> products = new ArrayList<Product>();
        when(query.getResultList()).thenReturn(products);

        assertSame(products, Product.findAllProductsByVendorEmailNotNullOrEmpty());
    }

    @Test
    public void shouldReturnTheCountOfAvailableItems() throws Exception {
        final ItemCollection itemCollection = mock(ItemCollection.class);
        whenNew(ItemCollection.class).withArguments(product.getItems()).thenReturn(itemCollection);

        when(itemCollection.countAvailable()).thenReturn(7866);

        assertEquals(7866, product.getAvailableCount());
    }

    @Test
    public void shouldReturnSortedListOfItemsBySerialNumber() throws Exception {
        final ItemCollection itemCollection = mock(ItemCollection.class);
        whenNew(ItemCollection.class).withArguments(product.getItems()).thenReturn(itemCollection);

        final ArrayList<Item> items = new ArrayList<Item>();
        when(itemCollection.getSortedListBySerialNumber()).thenReturn(items);
        assertSame(items, product.getItemsBySerialNumber());
    }
}
