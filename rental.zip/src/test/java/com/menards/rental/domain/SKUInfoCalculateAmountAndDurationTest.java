/*
 * SKUInfoCalculateAmountAndDurationTest.java
 */
package com.menards.rental.domain;

import static org.mockito.Matchers.eq;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.whenNew;

import java.util.Calendar;

import com.menards.rental.domain.rule.IncrementalHoursCalculationRuleComposite;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Created by IntelliJ IDEA. User: deep Date: 13 Jun, 2010 Time: 6:47:03 AM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
public class SKUInfoCalculateAmountAndDurationTest {

    /**
	 * Gets the mock incremental hours calculation rules.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @param incrementalSkuHrQty the incremental sku hr qty
	 * @param totalRentalDurationInHours the total rental duration in hours
	 * @return the mock incremental hours calculation rules
	 * @throws Exception the exception
	 */
	private IncrementalHoursCalculationRuleComposite getMockIncrementalHoursCalculationRules(final double baseSkuHrQty,
	        final double incrementalSkuHrQty, final double totalRentalDurationInHours) throws Exception {
		final IncrementalHoursCalculationRuleComposite mockedIncrementalHoursCalculationRules = mock(IncrementalHoursCalculationRuleComposite.class);
		whenNew(IncrementalHoursCalculationRuleComposite.class).withArguments(eq(baseSkuHrQty), eq(incrementalSkuHrQty),
		        Matchers.<StoreHourBasedRentalDateRange> anyObject()).thenReturn(mockedIncrementalHoursCalculationRules);

		final StoreHourBasedRentalDateRange rentalDateRange = mock(StoreHourBasedRentalDateRange.class);
		whenNew(StoreHourBasedRentalDateRange.class).withArguments(Matchers.<Calendar> anyObject(),
		        Matchers.<Calendar> anyObject()).thenReturn(rentalDateRange);
		when(rentalDateRange.getActualDurationInHours()).thenReturn(totalRentalDurationInHours);
		return mockedIncrementalHoursCalculationRules;
	}

	/**
	 * Gets the calendar.
	 *
	 * @param field the field
	 * @param amount the amount
	 * @return the calendar
	 */
	private Calendar getCalendar(final int field, final int amount) {
		final Calendar calendar = Calendar.getInstance();
		calendar.add(field, amount);
		return calendar;
	}
}
