/*
 * SKUTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.stub;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Created by IntelliJ IDEA. User: deep Date: 10 Jun, 2010 Time: 3:58:54 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest(RentalSKU.class)
public class SKUTest {

	/**
	 * Should return list of all sk us ordered by type and value.
	 */
	@Test
	public void shouldReturnListOfAllSKUsOrderedByTypeAndValue() {
		final EntityManager entityManager = mock(EntityManager.class);
		stub(method(RentalSKU.class, "entityManager")).andReturn(entityManager);

		final Query mockedQuery = mock(Query.class);
		when(entityManager.createQuery("select o from RentalSKU o order by o.type, o.value")).thenReturn(mockedQuery);

		final ArrayList<RentalSKU> expectedSKUs = new ArrayList<RentalSKU>();
		when(mockedQuery.getResultList()).thenReturn(expectedSKUs);

		assertSame(expectedSKUs, RentalSKU.findAllSKUSOrderedByTypeAndValue());
	}

	/**
	 * Should return true if type passed in matches the type of the sku.
	 */
	@Test
	public void shouldReturnTrueIfTypePassedInMatchesTheTypeOfTheSKU() {
		assertTrue(new RentalSKU("BASE", null, 0).matches(RentalSKU.Type.BASE));
	}

	/**
	 * Should return false if type passed in does not match the type of the sku.
	 */
	@Test
	public void shouldReturnFalseIfTypePassedInDoesNotMatchTheTypeOfTheSKU() {
		assertFalse(new RentalSKU("ADDITIONAL", null, 0).matches(RentalSKU.Type.BASE));
	}

	/**
	 * Should return formatted value of the sku.
	 */
	@Test
	public void shouldReturnFormattedValueOfTheSKU() {
		assertEquals("100-1991", new RentalSKU(null, null, 1001991).getFormattedValue());
	}

	/**
	 * Should return formatted information string about the sku.
	 */
	@Test
	public void shouldReturnFormattedInformationStringAboutTheSKU() {
		final RentalSKU sku = new RentalSKU(null, null, 1001991);
		sku.setDescription("Hello world");
		assertEquals("100-1991: Hello world", sku.getInfo());
	}
}
