/*
 * DifferentDaysIncrementalHoursCalculationRuleTest.java
 */
package com.menards.rental.domain.rule;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Test;

import com.menards.rental.domain.StoreHourBasedRentalDateRange;

/**
 * Created by IntelliJ IDEA. User: deep Date: 15 Jul, 2010 Time: 11:25:41 AM To
 * change this template use File | Settings | File Templates.
 */
public class DiffDaysIncreHrsCalcRuleTest {

	/**
	 * Should calculate the incremental hours when hours in first day are greater than base hours.
	 *//*
	@Test
	public void shouldCalculateTheIncrementalHoursWhenHoursInFirstDayAreGreaterThanBaseHours() {
		final StoreHourBasedRentalDateRange dateRange = getMockedStoreHourBasedRentalDateRange(5, 1, 1);

		assertEquals(15.0, new DiffDaysIncreHrsCalcRule(4, 0.75, dateRange).calculate(), 0.001);
	}

	*//**
	 * Should calculate the incremental hours when hours in first day are lesser than base hours.
	 *//*
	@Test
	public void shouldCalculateTheIncrementalHoursWhenHoursInFirstDayAreLesserThanBaseHours() {
		final StoreHourBasedRentalDateRange dateRange = getMockedStoreHourBasedRentalDateRange(2, 2, 7);

		assertEquals(29.25, new DiffDaysIncreHrsCalcRule(4, 0.75, dateRange).calculate(), 0.001);
	}

	*//**
	 * Should calculate the incremental hours when hours in first day are equal than base hours with zero days.
	 *//*
	@Test
	public void shouldCalculateTheIncrementalHoursWhenHoursInFirstDayAreEqualThanBaseHoursWithZeroDays() {
		final StoreHourBasedRentalDateRange dateRange = getMockedStoreHourBasedRentalDateRange(4, 0, 7);

		assertEquals(7.5, new DiffDaysIncreHrsCalcRule(4, 0.75, dateRange).calculate(), 0.001);
	}

	*//**
	 * Should calculate the incremental hours when hours in first day are lesser than base hours with zero days.
	 *//*
	@Test
	public void shouldCalculateTheIncrementalHoursWhenHoursInFirstDayAreLesserThanBaseHoursWithZeroDays() {
		final StoreHourBasedRentalDateRange dateRange = getMockedStoreHourBasedRentalDateRange(0, 0, 14);

		assertEquals(7.5, new DiffDaysIncreHrsCalcRule(4, 0.75, dateRange).calculate(), 0.001);
	}

	*//**
	 * Should calculate the incremental hours when hours in first day are zero with one day and next day1 hour.
	 *//*
	@Test
	public void shouldCalculateTheIncrementalHoursWhenHoursInFirstDayAreZeroWithOneDayAndNextDay1Hour() {
		final StoreHourBasedRentalDateRange dateRange = getMockedStoreHourBasedRentalDateRange(0, 1, 1);

		assertEquals(11.0, new DiffDaysIncreHrsCalcRule(2, 0.25, dateRange).calculate(), 0.001);
	}

	*//**
	 * Should calculate the incremental hours when actual duration is less than12 hours.
	 *//*
	@Test
	public void shouldCalculateTheIncrementalHoursWhenActualDurationIsLessThan12Hours() {
		final StoreHourBasedRentalDateRange dateRange = getMockedStoreHourBasedRentalDateRange(2, 0, 4);

		assertEquals(2.25, new DiffDaysIncreHrsCalcRule(4, 0.75, dateRange).calculate(), 0.001);
	}

	*//**
	 * Gets the mocked store hour based rental date range.
	 *
	 * @param checkoutHours the checkout hours
	 * @param numberOfFullDays the number of full days
	 * @param checkinHours the checkin hours
	 * @return the mocked store hour based rental date range
	 *//*
	private StoreHourBasedRentalDateRange getMockedStoreHourBasedRentalDateRange(final double checkoutHours,
	        final int numberOfFullDays, final double checkinHours) {
		final StoreHourBasedRentalDateRange rentalDateRange = mock(StoreHourBasedRentalDateRange.class);
		when(rentalDateRange.getNumberOfCheckoutHours()).thenReturn(checkoutHours);
		when(rentalDateRange.getNumberOfCheckinHours()).thenReturn(checkinHours);
		when(rentalDateRange.countNumberOfFullDays()).thenReturn(numberOfFullDays);
		return rentalDateRange;
	}*/
	
	/**
	 * The actual Duration in hours during renting items by user is greater than the based rented hours.
	 */
	@Test
	public void ActualDurationInHoursIsGreaterThanBasedHours() {
		final StoreHourBasedRentalDateRange dateRange = getMockedStoreHourBasedRentalDateRange(12);
		
		assertEquals(8.0, new DiffDaysIncreHrsCalcRule(4, 1.0, dateRange).calculate(), 0.001);
	}
	
	/**
	 * The actual Duration in hours during renting items by user is less than the based rented hours.
	 */
	@Test
	public void ActualDurationInHoursIsLessThanBasedHours() {
		final StoreHourBasedRentalDateRange dateRange = getMockedStoreHourBasedRentalDateRange(2);
		
		assertEquals(0.0, new DiffDaysIncreHrsCalcRule(4, 1.0, dateRange).calculate(), 0.001);
	}
	
	/**
	 * Gets the mocked store hour based rental date range.
	 * 
	 * @param actualDurationInHours the actual duration hours
	 * @return the mocked store hour based rental date range
	 */
	private StoreHourBasedRentalDateRange getMockedStoreHourBasedRentalDateRange(final double actualDurationInHours) {
		final StoreHourBasedRentalDateRange rentalDateRange = mock(StoreHourBasedRentalDateRange.class);
		when(rentalDateRange.getActualDurationInHours()).thenReturn(actualDurationInHours);
		return rentalDateRange;
	}
}
