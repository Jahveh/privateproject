/*
 * ItemWillBeAvaliableReservationRuleTest.java
 */
package com.menards.rental.domain.rule;

import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: deep Date: 8 Jul, 2010 Time: 6:47:13 PM To
 * change this template use File | Settings | File Templates.
 */

public class ItemWillBeAvaliableReservationRuleTest {

	/**
	 * Should return true if agreement items found that would be returned before the first reservation period.
	 */
	@Test
	public void shouldReturnTrueIfAgreementItemsFoundThatWouldBeReturnedBeforeTheFirstReservationPeriod() {

	}
}
