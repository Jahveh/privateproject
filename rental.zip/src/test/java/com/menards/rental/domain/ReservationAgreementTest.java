/*
 * ReservationAgreementTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.spy;
import static org.powermock.api.mockito.PowerMockito.whenNew;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.stub;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Created by IntelliJ IDEA. User: deep Date: 21 Jul, 2010 Time: 12:03:44 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest( { ReservationAgreement.class, ReservationAgreementStatus.class, ReservationStatus.class })
public class ReservationAgreementTest {
	
	/** The agreement. */
	private ReservationAgreement agreement;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		agreement = new ReservationAgreement();
	}

	/**
	 * Should return true if store number matches.
	 */
	@Test
	public void shouldReturnTrueIfStoreNumberMatches() {
		final Store mockedStore = mock(Store.class);
		agreement.setStore(mockedStore);

		when(mockedStore.isMatching(1233)).thenReturn(true);

		assertTrue(agreement.isForStore(1233));
	}

	/**
	 * Should return false if store number does not match.
	 */
	@Test
	public void shouldReturnFalseIfStoreNumberDoesNotMatch() {
		final Store mockedStore = mock(Store.class);
		agreement.setStore(mockedStore);

		when(mockedStore.isMatching(1233)).thenReturn(false);

		assertFalse(agreement.isForStore(1233));
	}

	/**
	 * Should return new instance of guest info if guest is null.
	 */
	@Test
	public void shouldReturnNewInstanceOfGuestInfoIfGuestIsNull() {
		assertNotNull(agreement.getGuest());
	}

	/**
	 * Should set the value of guest info if guest was null initially.
	 */
	@Test
	public void shouldSetTheValueOfGuestInfoIfGuestWasNullInitially() {
		agreement.getGuest();
		assertNotNull(agreement.getGuest());
	}

	/**
	 * Should return the same instance of guest info if it was not null.
	 */
	@Test
	public void shouldReturnTheSameInstanceOfGuestInfoIfItWasNotNull() {
		final Guest guest = new Guest();
		agreement.setGuest(guest);
		assertSame(guest, agreement.getGuest());
	}

	/**
	 * Should add the reservation to the agreement.
	 */
	@Test
	public void shouldAddTheReservationToTheAgreement() {
		final Reservation reservation = new Reservation();
		agreement.addReservation(reservation);

		assertTrue(agreement.getReservations().contains(reservation));
		assertSame(agreement, reservation.getAgreement());
	}

	/**
	 * Should remove the reservation for the given product.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldRemoveTheReservationForTheGivenProduct() throws Exception {
		final Set<Reservation> reservations = new HashSet<Reservation>();
		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
		whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockedReservations);

		agreement.setReservations(reservations);

		agreement.removeReservationFor(1233L);

		verify(mockedReservations).removeReservationFor(1233L);
	}

	/**
	 * Should return true if reservation agreement is transient.
	 */
	@Test
	public void shouldReturnTrueIfReservationAgreementIsTransient() {
		assertTrue(agreement.isTransient());
	}

	/**
	 * Should return false if reservation agreement is not transient.
	 */
	@Test
	public void shouldReturnFalseIfReservationAgreementIsNotTransient() {
		agreement.setId(123123L);
		assertFalse(agreement.isTransient());
	}

	/**
	 * Should load the entire reservation agreement with all due respect.
	 */
	@Test
	public void shouldLoadTheEntireReservationAgreementWithAllDueRespect() {
		final ReservationAgreement expectedAgreement = new ReservationAgreement();

		final EntityManager entityManager = mock(EntityManager.class);
		stub(method(ReservationAgreement.class, "entityManager")).andReturn(entityManager);

		final Query mockedQuery = mock(Query.class);
		when(
		        entityManager.createQuery("select a from ReservationAgreement a left join fetch a.reservations r "
		                + "left join fetch a.guest g " + "left join fetch a.status st " + "left join fetch r.product p "
		                + "left join fetch r.status rst " + "left join fetch p.skuInfo.baseSKU b " + "where a.id=:agreementId"))
		        .thenReturn(mockedQuery);

		when(mockedQuery.setParameter("agreementId", 1233L)).thenReturn(mockedQuery);
		when(mockedQuery.getSingleResult()).thenReturn(expectedAgreement);

		assertSame(expectedAgreement, ReservationAgreement.loadFull(1233L));
	}

	/**
	 * Should return true if the reservation for the choosen product already exists.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTrueIfTheReservationForTheChoosenProductAlreadyExists() throws Exception {
		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
		final Set<Reservation> reservations = new HashSet<Reservation>();
		whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockedReservations);

		final ReservationAgreement reservationAgreement = new ReservationAgreement();
		reservationAgreement.setReservations(reservations);

		final Product product = new Product();
		when(mockedReservations.isReservationPresentFor(product)).thenReturn(true);

		assertTrue(reservationAgreement.isReservationPresentFor(product));
	}

	/**
	 * Should return false if the reservation for the choosen product does not exists.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnFalseIfTheReservationForTheChoosenProductDoesNotExists() throws Exception {
		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
		final Set<Reservation> reservations = new HashSet<Reservation>();
		whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockedReservations);

		final ReservationAgreement reservationAgreement = new ReservationAgreement();
		reservationAgreement.setReservations(reservations);

		final Product product = new Product();
		when(mockedReservations.isReservationPresentFor(product)).thenReturn(false);

		assertFalse(reservationAgreement.isReservationPresentFor(product));
	}

	/**
	 * Should return open reservations for the given store.
	 */
	@Test
	public void shouldReturnOpenReservationsForTheGivenStore() {
		final Query mockedQuery = mock(Query.class);
        final EntityManager entityManager = mock(EntityManager.class);
        stub(
		        method(ReservationAgreement.class, "entityManager",
		                null)).andReturn(entityManager);
        when(entityManager
            .createQuery("SELECT ReservationAgreement FROM ReservationAgreement AS reservationagreement " +
               "WHERE reservationagreement.status = :status AND reservationagreement.store.storeNumber = :storeNumber"))
            .thenReturn(mockedQuery);


		final ReservationAgreementStatus reservationAgreementStatus = new ReservationAgreementStatus();

		mockStatic(ReservationAgreementStatus.class);
		when(ReservationAgreementStatus.findOpen()).thenReturn(reservationAgreementStatus);

		final List<ReservationAgreement> reservationAgreements = new ArrayList<ReservationAgreement>();
		when(mockedQuery.getResultList()).thenReturn(reservationAgreements);

        final Store store = new Store();
        store.setStoreNumber(7866);
        assertSame(reservationAgreements, ReservationAgreement.findAllOpenReservationAgreementsByStore(store));
        verify(mockedQuery).setParameter("status", reservationAgreementStatus);
        verify(mockedQuery).setParameter("storeNumber", 7866);
	}

	/**
	 * Should return true if number of reservations is greater than0.
	 */
	@Test
	public void shouldReturnTrueIfNumberOfReservationsIsGreaterThan0() {
		final ReservationAgreement reservationAgreement = new ReservationAgreement();
		reservationAgreement.addReservation(new Reservation());
		assertTrue(reservationAgreement.hasReservations());
	}

	/**
	 * Should return false if number of reservations is zero.
	 */
	@Test
	public void shouldReturnFalseIfNumberOfReservationsIsZero() {
		assertFalse(new ReservationAgreement().hasReservations());
	}

	/**
	 * Should updte the status of the agreement.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldUpdteTheStatusOfTheAgreement() throws Exception {
		final ReservationAgreement reservationAgreement = spy(new ReservationAgreement());
		doNothing().when(reservationAgreement).merge();

		final ReservationAgreementStatus expectedStatus = new ReservationAgreementStatus();
		mockStatic(ReservationAgreementStatus.class);
		when(ReservationAgreementStatus.findCancelled()).thenReturn(expectedStatus);
		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
		whenNew(ReservationCollection.class).withArguments(anyObject()).thenReturn(mockedReservations);

		reservationAgreement.cancel();
		assertSame(expectedStatus, reservationAgreement.getStatus());
	}

	/**
	 * Should call merge on the reservation.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCallMergeOnTheReservation() throws Exception {
		final ReservationAgreement reservationAgreement = spy(new ReservationAgreement());
		doNothing().when(reservationAgreement).merge();

		final ReservationAgreementStatus expectedStatus = new ReservationAgreementStatus();
		mockStatic(ReservationAgreementStatus.class);
		when(ReservationAgreementStatus.findCancelled()).thenReturn(expectedStatus);
		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
		whenNew(ReservationCollection.class).withArguments(anyObject()).thenReturn(mockedReservations);

		reservationAgreement.cancel();

		verify(reservationAgreement).merge();
	}

	/**
	 * Should cancle the other reservations.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCancleTheOtherReservations() throws Exception {
		final ReservationAgreement reservationAgreement = spy(new ReservationAgreement());
		doNothing().when(reservationAgreement).merge();

		final ReservationAgreementStatus expectedStatus = new ReservationAgreementStatus();
		mockStatic(ReservationAgreementStatus.class);
		when(ReservationAgreementStatus.findCancelled()).thenReturn(expectedStatus);
		final Set<Reservation> reservations = new HashSet<Reservation>();

		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
		whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockedReservations);

		reservationAgreement.setReservations(reservations);

		reservationAgreement.cancel();

		verify(mockedReservations).cancel();
	}

	/**
	 * Should find the reservation by id.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldFindTheReservationById() throws Exception {
		final Set<Reservation> reservations = new HashSet<Reservation>();
		final ReservationCollection mockedReservations = mock(ReservationCollection.class);

		whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockedReservations);
		final Reservation reservation = new Reservation();
		when(mockedReservations.findReservationById(1233L)).thenReturn(reservation);

		assertEquals(reservation, new ReservationAgreement().findReservationById(1233L));
	}

	/**
	 * Should mark the reservation agreement as fulfilled if non of the reservations are open.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldMarkTheReservationAgreementAsFulfilledIfNonOfTheReservationsAreOpen() throws Exception {
		final Set<Reservation> reservations = new HashSet<Reservation>();
		final ReservationCollection mockedReservations = mock(ReservationCollection.class);

		whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockedReservations);
		when(mockedReservations.isAnyReservationOpen()).thenReturn(false);

		final ReservationAgreementStatus status = new ReservationAgreementStatus();
		mockStatic(ReservationAgreementStatus.class);
		when(ReservationAgreementStatus.findFulfilled()).thenReturn(status);

		final ReservationAgreement reservationAgreement = new ReservationAgreement();
		reservationAgreement.setReservations(reservations);

		reservationAgreement.fulfillIfAllReservationsFulfilledOrCancelled();

		assertSame(status, reservationAgreement.getStatus());
	}

	/**
	 * Should not mark the reservation agreement as fulfilled if some of the reservations are open.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldNotMarkTheReservationAgreementAsFulfilledIfSomeOfTheReservationsAreOpen() throws Exception {
		final Set<Reservation> reservations = new HashSet<Reservation>();
		final ReservationCollection mockedReservations = mock(ReservationCollection.class);

		whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockedReservations);
		when(mockedReservations.isAnyReservationOpen()).thenReturn(true);

		final ReservationAgreement reservationAgreement = new ReservationAgreement();
		reservationAgreement.setReservations(reservations);

		reservationAgreement.fulfillIfAllReservationsFulfilledOrCancelled();

		assertNull(reservationAgreement.getStatus());
	}

    @Test
    public void shouldReturnTheTotalEstimatedChargeAmount() throws Exception {
        final HashSet<Reservation> reservations = new HashSet<Reservation>();
        final ReservationCollection mockReservations = mock(ReservationCollection.class);
        whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockReservations);
        final BigDecimal totalEstimatedChargeAmount = new BigDecimal("10.8");

        when(mockReservations.getTotalEstimatedChargeAmount()).thenReturn(totalEstimatedChargeAmount);

        final ReservationAgreement reservationAgreement = new ReservationAgreement();
        reservationAgreement.setReservations(reservations);
        assertSame(totalEstimatedChargeAmount, reservationAgreement.getTotalEstimatedChargeAmount());
    }

    @Test
    public void shouldReturnTheTotalEstimatedDamageWaiver() throws Exception {
        final HashSet<Reservation> reservations = new HashSet<Reservation>();
        final ReservationCollection mockReservations = mock(ReservationCollection.class);
        whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockReservations);
        final BigDecimal totalEstimatedChargeAmount = new BigDecimal("1.8");

        when(mockReservations.getTotalDamageWaiver()).thenReturn(totalEstimatedChargeAmount);

        final ReservationAgreement reservationAgreement = new ReservationAgreement();
        reservationAgreement.setReservations(reservations);
        assertSame(totalEstimatedChargeAmount, reservationAgreement.getTotalDamageWaiver());
    }

    @Test
    public void shouldReturnTheTotalOfEstimatedChargeAmountAndDamageWaiverCharges() throws Exception {
        final HashSet<Reservation> reservations = new HashSet<Reservation>();
        final ReservationCollection mockReservations = mock(ReservationCollection.class);
        whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockReservations);
        final BigDecimal totalEstimatedChargeAmount = new BigDecimal("10.8");
        final BigDecimal totalEstimatedDamageWaiver = new BigDecimal("1.8");

        when(mockReservations.getTotalEstimatedChargeAmount()).thenReturn(totalEstimatedChargeAmount);
        when(mockReservations.getTotalDamageWaiver()).thenReturn(totalEstimatedDamageWaiver);

        final ReservationAgreement reservationAgreement = new ReservationAgreement();
        reservationAgreement.setReservations(reservations);
        assertEquals(totalEstimatedChargeAmount.add(totalEstimatedDamageWaiver).doubleValue(),
                reservationAgreement.getTotalEstimatedPlusDamageWaiverChargeAmount().doubleValue(), 0.001);
    }

    @Test
    public void shouldDoNothingIfReservationIsNull() {
        final ReservationAgreement reservationAgreement = new ReservationAgreement();
        reservationAgreement.addReservation(new Reservation());

        assertEquals(1, reservationAgreement.getReservations().size());
        reservationAgreement.removeReservation(null);
        assertEquals(1, reservationAgreement.getReservations().size());
    }

    @Test
    public void shouldRemoveTheReservationFromTheAgreement() {
        final ReservationAgreement reservationAgreement = new ReservationAgreement();
        final Reservation reservation = new Reservation();
        reservationAgreement.addReservation(reservation);

        assertNotNull(reservation.getAgreement());
        assertEquals(1, reservationAgreement.getReservations().size());

        reservationAgreement.removeReservation(reservation);

        assertTrue(reservationAgreement.getReservations().isEmpty());
        assertNull(reservation.getAgreement());
    }

    @Test
    public void shouldReturnTheValueToUserNameIfStoreUserIsNotNull() {
        final StoreUserInfo storeUser = new StoreUserInfo();
        storeUser.setName("Hello SU");
        final ReservationAgreement agreement = new ReservationAgreement();
        agreement.setStoreUser(storeUser);

        assertEquals("Hello SU", agreement.getCreatedByTeamMemberName());
    }

    @Test
    public void shouldFindAllTheReservationAgreementsThatAreOpenAndHaveNoOpenReservations() {
        final ReservationAgreementStatus reservationAgreementStatus = new ReservationAgreementStatus();
        final ReservationStatus reservationStatus = new ReservationStatus();
        mockStatic(ReservationAgreementStatus.class);
        when(ReservationAgreementStatus.findOpen()).thenReturn(reservationAgreementStatus);

        mockStatic(ReservationStatus.class);
        when(ReservationStatus.findOpen()).thenReturn(reservationStatus);

        final EntityManager entityManager = mock(EntityManager.class);
        stub(method(ReservationAgreement.class, "entityManager", null)).andReturn(entityManager);

        final Query query = mock(Query.class);
        when(entityManager.createQuery("select ra from ReservationAgreement ra where ra.status = :openStatus " +
                "and :openReservationStatus <> all(select r.status from Reservation r where r.agreement = ra)"))
                .thenReturn(query);

        when(query.setParameter("openStatus", reservationAgreementStatus)).thenReturn(query);
        when(query.setParameter("openReservationStatus", reservationStatus)).thenReturn(query);

        final ArrayList<ReservationAgreement> agreements = new ArrayList<ReservationAgreement>();
        when(query.getResultList()).thenReturn(agreements);

        assertSame(agreements, ReservationAgreement.findAllOpenReservationAgreementsThatHaveNoOpenReservation());
    }

    @Test
    public void shouldSetTheValueOfCreatedByTMNameIfStoreUserIsNotNull() {
        final StoreUserInfo storeUserInfo = new StoreUserInfo();
        storeUserInfo.setName("HelloManager");
        final ReservationAgreement reservationAgreement = new ReservationAgreement();
        reservationAgreement.setStoreUser(storeUserInfo);
        assertEquals("HelloManager", reservationAgreement.getCreatedByTeamMemberName());
    }

    @Test
    public void shouldSetTheValueOfCreatedByTMNameToTeamMemberNumberIfStoreUserIsNull() {
        final ReservationAgreement reservationAgreement = new ReservationAgreement();
        reservationAgreement.setCreatedByTeamMemberNumber(1233);
        reservationAgreement.setStoreUser(null);
        assertEquals("1233", reservationAgreement.getCreatedByTeamMemberName());
    }

    @Test
    public void shouldReturnTrueIfGuestAgeIsGreaterThanMinimumRentalAgeForAllTheRentalsSelected() throws Exception {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final ReservationCollection mockedReservations = mock(ReservationCollection.class);
        whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockedReservations);
        final ReservationAgreement reservationAgreement = new ReservationAgreement();
        reservationAgreement.setReservations(reservations);

        final Guest guest = new Guest();
        reservationAgreement.setGuest(guest);
        when(mockedReservations.isGuestAgeGreaterThanMinimumAge(guest)).thenReturn(true);

        assertTrue(reservationAgreement.isGuestAgeGreaterThanMinimumAge());
    }

    @Test
    public void shouldReturnFlaseIfGuestAgeIsLessThanMinimumRentalAgeForAllTheRentalsSelected() throws Exception {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final ReservationCollection mockedReservations = mock(ReservationCollection.class);
        whenNew(ReservationCollection.class).withArguments(reservations).thenReturn(mockedReservations);
        final ReservationAgreement reservationAgreement = new ReservationAgreement();
        reservationAgreement.setReservations(reservations);

        final Guest guest = new Guest();
        reservationAgreement.setGuest(guest);
        when(mockedReservations.isGuestAgeGreaterThanMinimumAge(guest)).thenReturn(false);

        assertFalse(reservationAgreement.isGuestAgeGreaterThanMinimumAge());
    }
}
