/*
 * VehicleRentalDetailTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotSame;
import static junit.framework.Assert.assertNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.whenNew;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.builder.VehicleRentalDetailBuilder;

/**
 * User: deep Date: 13 May, 2010 Time: 7:03:02 PM.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest(VehicleRentalDetail.class)
public class VehicleRentalDetailTest {

	/**
	 * Should return first additional driver from additional drivers list.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnFirstAdditionalDriverFromAdditionalDriversList() throws Exception {
		final Set<AdditionalDriver> drivers = new HashSet<AdditionalDriver>();
		final AdditionalDriver expectedAdditionalDriver = new AdditionalDriver();

		final AdditionalDriverCollection additionalDriverCollectionMock = mock(AdditionalDriverCollection.class);
		whenNew(AdditionalDriverCollection.class).withArguments(drivers).thenReturn(additionalDriverCollectionMock);
		when(additionalDriverCollectionMock.getFirstAdditionalDriver()).thenReturn(expectedAdditionalDriver);

		final VehicleRentalDetail rentalDetail = new VehicleRentalDetail();
		rentalDetail.setAdditionalDrivers(drivers);

		assertSame(expectedAdditionalDriver, rentalDetail.getAdditionalDriver());
	}

	/**
	 * Should return first additional driver from additional drivers list second time as well.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnFirstAdditionalDriverFromAdditionalDriversListSecondTimeAsWell() throws Exception {
		final Set<AdditionalDriver> drivers = new HashSet<AdditionalDriver>();
		final AdditionalDriver expectedAdditionalDriver = new AdditionalDriver();

		final AdditionalDriverCollection additionalDriverCollectionMock = mock(AdditionalDriverCollection.class);
		whenNew(AdditionalDriverCollection.class).withArguments(drivers).thenReturn(additionalDriverCollectionMock);
		when(additionalDriverCollectionMock.getFirstAdditionalDriver()).thenReturn(expectedAdditionalDriver);

		final VehicleRentalDetail rentalDetail = new VehicleRentalDetail();
		rentalDetail.setAdditionalDrivers(drivers);

		rentalDetail.getAdditionalDriver();
		// Making the second call
		assertSame(expectedAdditionalDriver, rentalDetail.getAdditionalDriver());
	}

	/**
	 * Should return additional driver set in the field if its not null.
	 */
	@Test
	public void shouldReturnAdditionalDriverSetInTheFieldIfItsNotNull() {
		final VehicleRentalDetail vehicleRentalDetail = new VehicleRentalDetail();
		final AdditionalDriver expectedAdditionalDriver = new AdditionalDriver();
		vehicleRentalDetail.setAdditionalDriver(expectedAdditionalDriver);

		assertSame(expectedAdditionalDriver, vehicleRentalDetail.getAdditionalDriver());
	}

	/**
	 * Should update vehicle from the item.
	 */
	@Test
	public void shouldUpdateVehicleFromTheItem() {
		final Item item = new Item();
		final Vehicle expectedVehicle = new Vehicle();
		item.setVehicle(expectedVehicle);
		final VehicleRentalDetail rentalDetail = new VehicleRentalDetail();

		rentalDetail.merge(item, new VehicleRentalDetail());

		assertSame(expectedVehicle, rentalDetail.getVehicle());
	}

	/**
	 * Should not add additional driver if extra driver flag is not set.
	 */
	@Test
	public void shouldNotAddAdditionalDriverIfExtraDriverFlagIsNotSet() {
		final VehicleRentalDetail rentalDetail = new VehicleRentalDetailBuilder().withAdditionalDriver(
		        new AdditionalDriver()).buildVehicleRentalDetail();

		rentalDetail.merge(new Item(), new VehicleRentalDetail());

		assertEquals(0, rentalDetail.getAdditionalDrivers().size());
	}

	/**
	 * Should set additional driver info in the set if extra driver required flag is set.
	 */
	@Test
	public void shouldSetAdditionalDriverInfoInTheSetIfExtraDriverRequiredFlagIsSet() {
		final AdditionalDriver expectedAdditionalDriver = new AdditionalDriver();
		final VehicleRentalDetail rentalDetail = new VehicleRentalDetail();

		rentalDetail.merge(new Item(), new VehicleRentalDetailBuilder().withAdditionalDriver(expectedAdditionalDriver)
		        .withExtraDriverNeeded(true).buildVehicleRentalDetail());

		assertEquals(1, rentalDetail.getAdditionalDrivers().size());

		assertTrue(rentalDetail.getAdditionalDrivers().contains(expectedAdditionalDriver));
		assertSame(rentalDetail, expectedAdditionalDriver.getVehicleRentalDetail());
	}

	/**
	 * Should reset the extra driver version and id while setting additional driver info in the set.
	 */
	@Test
	public void shouldResetTheExtraDriverVersionAndIdWhileSettingAdditionalDriverInfoInTheSet() {
		final AdditionalDriver expectedAdditionalDriver = new AdditionalDriver();
		expectedAdditionalDriver.setId(1233L);
		expectedAdditionalDriver.setVersion(1233);
		final VehicleRentalDetail rentalDetail = new VehicleRentalDetail();

		rentalDetail.merge(new Item(), new VehicleRentalDetailBuilder().withAdditionalDriver(expectedAdditionalDriver)
		        .withExtraDriverNeeded(true).buildVehicleRentalDetail());

		assertEquals(1, rentalDetail.getAdditionalDrivers().size());

		assertNull(rentalDetail.getAdditionalDriver().getId());
		assertNull(rentalDetail.getAdditionalDriver().getVersion());
	}

	/**
	 * Should clear the set before adding additional driver if extra driver required flag is set.
	 */
	@Test
	public void shouldClearTheSetBeforeAddingAdditionalDriverIfExtraDriverRequiredFlagIsSet() {
		final AdditionalDriver expectedAdditionalDriver = new AdditionalDriver();
		final VehicleRentalDetail rentalDetail = new VehicleRentalDetail();
		rentalDetail.getAdditionalDrivers().add(new AdditionalDriver());

		rentalDetail.merge(new Item(), new VehicleRentalDetailBuilder().withAdditionalDriver(expectedAdditionalDriver)
		        .withExtraDriverNeeded(true).buildVehicleRentalDetail());

		assertEquals(1, rentalDetail.getAdditionalDrivers().size());

		assertTrue(rentalDetail.getAdditionalDrivers().contains(expectedAdditionalDriver));
		assertSame(rentalDetail, expectedAdditionalDriver.getVehicleRentalDetail());
	}

	/**
	 * Should clear the additional drivers even if extra driver needed flag is not set.
	 */
	@Test
	public void shouldClearTheAdditionalDriversEvenIfExtraDriverNeededFlagIsNotSet() {
		final VehicleRentalDetail rentalDetail = new VehicleRentalDetailBuilder().withExtraDriverNeeded(false)
		        .buildVehicleRentalDetail();
		rentalDetail.getAdditionalDrivers().add(new AdditionalDriver());

		rentalDetail.merge(new Item(), new VehicleRentalDetail());

		assertEquals(0, rentalDetail.getAdditionalDrivers().size());
	}

	/**
	 * Should clear the additional driver reference.
	 */
	@Test
	public void shouldClearTheAdditionalDriverReference() {
		final VehicleRentalDetail rentalDetail = new VehicleRentalDetailBuilder().withExtraDriverNeeded(false)
		        .buildVehicleRentalDetail();
		final AdditionalDriver expectedDriver = new AdditionalDriver();
		rentalDetail.getAdditionalDrivers().add(expectedDriver);

		assertSame(expectedDriver, rentalDetail.getAdditionalDriver());

		rentalDetail.merge(new Item(), new VehicleRentalDetail());

		assertNotSame(expectedDriver, rentalDetail.getAdditionalDriver());
	}

	/**
	 * Should set insurance while merging the vehicle rental detail.
	 */
	@Test
	public void shouldSetInsuranceWhileMergingTheVehicleRentalDetail() {
		final VehicleRentalDetail rentalDetail = new VehicleRentalDetail();

		final Insurance expectedInsurance = new Insurance();
		rentalDetail.merge(new Item(), new VehicleRentalDetailBuilder().withInsurance(expectedInsurance)
		        .buildVehicleRentalDetail());

		assertSame(expectedInsurance, rentalDetail.getInsurance());
	}

	/**
	 * Should reset the extra driver needed while merging the vehicle rental detail.
	 */
	@Test
	public void shouldResetTheExtraDriverNeededWhileMergingTheVehicleRentalDetail() {
		final VehicleRentalDetail rentalDetail = new VehicleRentalDetail();

		rentalDetail.setExtraDriverNeeded(true);
		rentalDetail.merge(new Item(), new VehicleRentalDetail());

		assertFalse(rentalDetail.isExtraDriverNeeded());
	}

	/**
	 * Should set the extra driver needed while merging the vehicle rental detail.
	 */
	@Test
	public void shouldSetTheExtraDriverNeededWhileMergingTheVehicleRentalDetail() {
		final VehicleRentalDetail rentalDetail = new VehicleRentalDetail();

		rentalDetail.merge(new Item(), new VehicleRentalDetailBuilder().withExtraDriverNeeded(true)
		        .buildVehicleRentalDetail());

		assertTrue(rentalDetail.isExtraDriverNeeded());
	}

	/**
	 * Should return true if extra driver is not needed.
	 */
	@Test
	public void shouldReturnTrueIfExtraDriverIsNotNeeded() {
		final VehicleRentalDetail vehicleRentalDetail = new VehicleRentalDetail();

		vehicleRentalDetail.setExtraDriverNeeded(false);

		assertTrue(vehicleRentalDetail.isDriverAgeGreaterThanMinimumRentalAge(22));
	}

	/**
	 * Should return true if extra driver is needed and extra driver age is greater than minimum age for rental item.
	 */
	@Test
	public void shouldReturnTrueIfExtraDriverIsNeededAndExtraDriverAgeIsGreaterThanMinimumAgeForRentalItem() {
		final VehicleRentalDetail vehicleRentalDetail = new VehicleRentalDetail();
		final AdditionalDriver mockedAdditionalDriver = mock(AdditionalDriver.class);

		vehicleRentalDetail.setExtraDriverNeeded(true);
		vehicleRentalDetail.setAdditionalDriver(mockedAdditionalDriver);

		when(mockedAdditionalDriver.isDriverAgeGreaterThanMinimumRentalAge(27)).thenReturn(true);
		assertTrue(vehicleRentalDetail.isDriverAgeGreaterThanMinimumRentalAge(27));
	}

	/**
	 * Should return false if extra driver is needed and extra driver age is less than minimum age for rental item.
	 */
	@Test
	public void shouldReturnFalseIfExtraDriverIsNeededAndExtraDriverAgeIsLessThanMinimumAgeForRentalItem() {
		final VehicleRentalDetail vehicleRentalDetail = new VehicleRentalDetail();
		final AdditionalDriver mockedAdditionalDriver = mock(AdditionalDriver.class);

		vehicleRentalDetail.setExtraDriverNeeded(true);
		vehicleRentalDetail.setAdditionalDriver(mockedAdditionalDriver);

		when(mockedAdditionalDriver.isDriverAgeGreaterThanMinimumRentalAge(81)).thenReturn(false);
		assertFalse(vehicleRentalDetail.isDriverAgeGreaterThanMinimumRentalAge(81));
	}
}
