/*
 * NoReservationsFoundReservationRuleTest.java
 */
package com.menards.rental.domain.rule;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Test;

import com.menards.rental.domain.Item;

/**
 * User: deep Date: 8 Jul, 2010 Time: 1:30:56 PM.
 */
public class NoReservationsFoundReservationRuleTest {

	/**
	 * Should return false if item has reservations associated with the product.
	 */
	@Test
	public void shouldReturnFalseIfItemHasReservationsAssociatedWithTheProduct() {
		final Item mockedItem = mock(Item.class);
		when(mockedItem.hasAnyReservations()).thenReturn(true);
		assertFalse(new NoReservationsFoundReservationRule().hasNoConflictingReservation(mockedItem, null, null));
	}

	/**
	 * Should return true if item has no reservations associated with the product.
	 */
	@Test
	public void shouldReturnTrueIfItemHasNoReservationsAssociatedWithTheProduct() {
		final Item mockedItem = mock(Item.class);
		when(mockedItem.hasAnyReservations()).thenReturn(false);
		assertTrue(new NoReservationsFoundReservationRule().hasNoConflictingReservation(mockedItem, null, null));
	}
}
