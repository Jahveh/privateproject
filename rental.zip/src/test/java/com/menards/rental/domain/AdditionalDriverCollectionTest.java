/*
 * AdditionalDriversTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;

import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: deep Date: 13 May, 2010 Time: 7:23:42 PM To
 * change this template use File | Settings | File Templates.
 */
public class AdditionalDriverCollectionTest {

	/**
	 * Should return new object if empty collection is passed.
	 */
	@Test
	public void shouldReturnNewObjectIfEmptyCollectionIsPassed() {
		assertNotNull(new AdditionalDriverCollection(new HashSet<AdditionalDriver>()).getFirstAdditionalDriver());
	}

	/**
	 * Should return first additional driver.
	 */
	@Test
	public void shouldReturnFirstAdditionalDriver() {
		final ArrayList<AdditionalDriver> drivers = new ArrayList<AdditionalDriver>();
		final AdditionalDriver expectedAdditionalDriver = new AdditionalDriver();
		drivers.add(expectedAdditionalDriver);
		drivers.add(new AdditionalDriver());

		assertSame(expectedAdditionalDriver, new AdditionalDriverCollection(drivers).getFirstAdditionalDriver());
	}

	/**
	 * Should return true if driver age is greater than the minimum age for a rental item.
	 */
	@Test
	public void shouldReturnTrueIfDriverAgeIsGreaterThanTheMinimumAgeForARentalItem() {
		final AdditionalDriver additionalDriver = new AdditionalDriver();
		final Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.YEAR, -25);
		additionalDriver.setDateOfBirth(calendar.getTime());

		assertTrue(additionalDriver.isDriverAgeGreaterThanMinimumRentalAge(24));
	}

	/**
	 * Should return true if driver age is equal to the minimum age for a rental item.
	 */
	@Test
	public void shouldReturnTrueIfDriverAgeIsEqualToTheMinimumAgeForARentalItem() {
		final AdditionalDriver additionalDriver = new AdditionalDriver();
		final Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.YEAR, -24);
		additionalDriver.setDateOfBirth(calendar.getTime());

		assertTrue(additionalDriver.isDriverAgeGreaterThanMinimumRentalAge(24));
	}

	/**
	 * Should return false if driver age is less than the minimum age for a rental item.
	 */
	@Test
	public void shouldReturnFalseIfDriverAgeIsLessThanTheMinimumAgeForARentalItem() {
		final AdditionalDriver additionalDriver = new AdditionalDriver();
		final Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.YEAR, -23);
		additionalDriver.setDateOfBirth(calendar.getTime());

		assertFalse(additionalDriver.isDriverAgeGreaterThanMinimumRentalAge(24));
	}
}
