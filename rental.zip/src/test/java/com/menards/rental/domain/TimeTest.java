/*
 * TimeTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;

import java.util.Calendar;

import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: deep Date: 14 Jul, 2010 Time: 3:40:33 PM To
 * change this template use File | Settings | File Templates.
 */
public class TimeTest {

	/**
	 * Should calculate the difference in hours if date is after the given time.
	 */
	@Test
	public void shouldCalculateTheDifferenceInHoursIfDateIsAfterTheGivenTime() {
		final Calendar postDate = Calendar.getInstance();
		postDate.set(Calendar.HOUR_OF_DAY, 12);
		postDate.set(Calendar.MINUTE, 25);
		assertEquals(3.916, new Time("08:30").calculateDifferenceInHours(postDate), 0.001);
	}

	/**
	 * Should calculate the difference in hours if date is before the given time.
	 */
	@Test
	public void shouldCalculateTheDifferenceInHoursIfDateIsBeforeTheGivenTime() {
		final Calendar postDate = Calendar.getInstance();
		postDate.set(Calendar.HOUR_OF_DAY, 19);
		postDate.set(Calendar.MINUTE, 20);
		assertEquals(3.166, new Time("22:30").calculateDifferenceInHours(postDate), 0.001);
	}

	/**
	 * Should set the time when new instance is created.
	 */
	@Test
	public void shouldSetTheTimeWhenNewInstanceIsCreated() {
		assertEquals(8, new Time("08:05").getHour());
		assertEquals(5, new Time("08:05").getMinutes());
	}
    
    @Test
    public void shouldIgnoreTheSecondsPartOfTheTime() {
        assertEquals(8, new Time("08:05:20").getHour());
        assertEquals(5, new Time("08:05:30").getMinutes());
    }
}
