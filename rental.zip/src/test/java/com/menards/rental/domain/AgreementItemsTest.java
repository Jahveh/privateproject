/*
 * AgreementItemsTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.builder.AgreementItemBuilder;
import com.menards.rental.builder.ItemBuilder;

/**
 * Created by IntelliJ IDEA. User: deep Date: 13 May, 2010 Time: 6:52:49 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest( { Item.class, ItemStatus.class, AgreementItemStatus.class })
public class AgreementItemsTest {

	/**
	 * Should return first vehicle rental detail found in agreement items.
	 */
	@Test
	public void shouldReturnFirstVehicleRentalDetailFoundInAgreementItems() {
		final ArrayList<AgreementItem> items = new ArrayList<AgreementItem>();
		items.add(new AgreementItemBuilder().buildVehicleAgreementItem());
		final VehicleRentalDetail expectedVehicleRentalDetail = new VehicleRentalDetail();
		items.add(new AgreementItemBuilder().withVehicleRentalDetail(expectedVehicleRentalDetail)
		        .buildVehicleAgreementItem());
		items.add(new AgreementItemBuilder().withVehicleRentalDetail(new VehicleRentalDetail()).buildVehicleAgreementItem());

		assertSame(expectedVehicleRentalDetail, new AgreementItemCollection(items).getFirstVehicleRentalDetail());
	}

	/**
	 * Should return new object if no vehicle rental detail found in any of the agreement items.
	 */
	@Test
	public void shouldReturnNewObjectIfNoVehicleRentalDetailFoundInAnyOfTheAgreementItems() {
		final ArrayList<AgreementItem> items = new ArrayList<AgreementItem>();
		items.add(new AgreementItemBuilder().buildVehicleAgreementItem());
		items.add(new AgreementItemBuilder().buildVehicleAgreementItem());
		items.add(new AgreementItemBuilder().buildVehicleAgreementItem());

		assertNotNull(new AgreementItemCollection(items).getFirstVehicleRentalDetail());
	}

	/**
	 * Should return new object if no agreement items are present.
	 */
	@Test
	public void shouldReturnNewObjectIfNoAgreementItemsArePresent() {
		assertNotNull(new AgreementItemCollection(new HashSet<AgreementItem>()).getFirstVehicleRentalDetail());
	}

	/**
	 * Should not do anything if none of the items have vehicle rental detail associated.
	 */
	@Test
	public void shouldNotDoAnythingIfNoneOfTheItemsHaveVehicleRentalDetailAssociated() {
		final ArrayList<AgreementItem> items = new ArrayList<AgreementItem>();
		final AgreementItem itemMock = mock(AgreementItem.class);

		when(itemMock.isInsuranceAdditionalDriverLicenseRequired()).thenReturn(false);

		items.add(itemMock);

		new AgreementItemCollection(items).merge(new VehicleRentalDetail());

		verify(itemMock, never()).merge(Matchers.<VehicleRentalDetail> anyObject());
	}

	/**
	 * Should merge the vehicle rental detail of items that have vehicle rental detail.
	 */
	@Test
	public void shouldMergeTheVehicleRentalDetailOfItemsThatHaveVehicleRentalDetail() {
		final ArrayList<AgreementItem> items = new ArrayList<AgreementItem>();
		final AgreementItem itemMock1 = mock(AgreementItem.class);
		final AgreementItem itemMock2 = mock(AgreementItem.class);

		when(itemMock2.isInsuranceAdditionalDriverLicenseRequired()).thenReturn(true);

		items.add(itemMock1);
		items.add(itemMock2);

		final VehicleRentalDetail expectedVehicleRentalDetail = new VehicleRentalDetail();
		new AgreementItemCollection(items).merge(expectedVehicleRentalDetail);

		verify(itemMock2).merge(expectedVehicleRentalDetail);
	}

	/**
	 * Should return true if any of the items is a vehicle.
	 */
	@Test
	public void shouldReturnTrueIfAnyOfTheItemsIsAVehicle() {
		final ArrayList<AgreementItem> items = new ArrayList<AgreementItem>();
		final AgreementItem itemMock1 = mock(AgreementItem.class);
		final AgreementItem itemMock2 = mock(AgreementItem.class);

		when(itemMock2.isInsuranceAdditionalDriverLicenseRequired()).thenReturn(true);

		items.add(itemMock1);
		items.add(itemMock2);

		assertTrue(new AgreementItemCollection(items).isInsuranceAdditionalDriverLicenseRequired());
	}

	/**
	 * Should return false if none of the items is a vehicle.
	 */
	@Test
	public void shouldReturnFalseIfNoneOfTheItemsIsAVehicle() {
		final ArrayList<AgreementItem> items = new ArrayList<AgreementItem>();
		final AgreementItem itemMock1 = mock(AgreementItem.class);
		final AgreementItem itemMock2 = mock(AgreementItem.class);

		items.add(itemMock1);
		items.add(itemMock2);

		assertFalse(new AgreementItemCollection(items).isInsuranceAdditionalDriverLicenseRequired());
	}

	/**
	 * Should return the total damage waiver amount of all the items.
	 */
	@Test
	public void shouldReturnTheTotalDamageWaiverAmountOfAllTheItemsConsideringDamageWaiverAvailable() {

		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);
		items.add(first);
		items.add(second);
		
		when(first.getIsDamageWaiverAvailable()).thenReturn(true);
		when(second.getIsDamageWaiverAvailable()).thenReturn(false);

		when(first.getDamageWaiverAmount()).thenReturn(new BigDecimal("99.0"));
		when(second.getDamageWaiverAmount()).thenReturn(new BigDecimal("9.0"));

		assertEquals(99.0, new AgreementItemCollection(items).getDamageWaiverTotal().doubleValue());
	}

	/**
	 * Should return false if there are no items in the collection.
	 */
	@Test
	public void shouldReturnFalseIfThereAreNoItemsInTheCollection() {
		assertFalse(new AgreementItemCollection(new HashSet<AgreementItem>()).isEveryItemAvailableRightNow());
	}

	/**
	 * Should return false if any one of the item is not available.
	 */
	@Test
	public void shouldReturnFalseIfAnyOneOfTheItemIsNotAvailable() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		final Item item1 = mock(Item.class);
		final Item item2 = mock(Item.class);

		when(first.getItemId()).thenReturn(1233L);
		when(second.getItemId()).thenReturn(7866L);

		when(first.isTransient()).thenReturn(true);
		when(second.isTransient()).thenReturn(true);

		mockStatic(Item.class);
		when(Item.findItem(1233L)).thenReturn(item1);
		when(Item.findItem(7866L)).thenReturn(item2);

		when(item1.isAvailable()).thenReturn(true);
		when(item2.isAvailable()).thenReturn(false);

		items.add(first);
		items.add(second);

		assertFalse(new AgreementItemCollection(items).isEveryItemAvailableRightNow());
	}

	/**
	 * Should return true if all the items from the collection are available.
	 */
	@Test
	public void shouldReturnTrueIfAllTheItemsFromTheCollectionAreAvailable() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		final Item item1 = mock(Item.class);
		final Item item2 = mock(Item.class);

		when(first.getItemId()).thenReturn(1233L);
		when(second.getItemId()).thenReturn(7866L);

		when(first.isTransient()).thenReturn(true);
		when(second.isTransient()).thenReturn(true);

		mockStatic(Item.class);
		when(Item.findItem(1233L)).thenReturn(item1);
		when(Item.findItem(7866L)).thenReturn(item2);

		when(item1.isAvailable()).thenReturn(true);
		when(item2.isAvailable()).thenReturn(true);

		items.add(first);
		items.add(second);

		assertTrue(new AgreementItemCollection(items).isEveryItemAvailableRightNow());
	}

	/**
	 * Should return true if all the items are not transient but their status is not available.
	 */
	@Test
	public void shouldReturnTrueIfAllTheItemsAreNotTransientButTheirStatusIsNotAvailable() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		final Item item1 = mock(Item.class);
		final Item item2 = mock(Item.class);

		when(first.getItemId()).thenReturn(1233L);
		when(second.getItemId()).thenReturn(7866L);

		when(first.isTransient()).thenReturn(false);
		when(second.isTransient()).thenReturn(true);

		mockStatic(Item.class);
		when(Item.findItem(1233L)).thenReturn(item1);
		when(Item.findItem(7866L)).thenReturn(item2);

		when(item1.isAvailable()).thenReturn(false);
		when(item2.isAvailable()).thenReturn(true);

		items.add(first);
		items.add(second);

		assertTrue(new AgreementItemCollection(items).isEveryItemAvailableRightNow());
	}

	/**
	 * Sets the the item found from the db while finding whether the item is available or not.
	 */
	@Test
	public void setTheItemFoundFromTheDBWhileFindingWhetherTheItemIsAvailableOrNot() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		final Item item1 = mock(Item.class);
		final Item item2 = mock(Item.class);

		when(first.getItemId()).thenReturn(1233L);
		when(second.getItemId()).thenReturn(7866L);

		when(first.isTransient()).thenReturn(false);
		when(second.isTransient()).thenReturn(true);

		mockStatic(Item.class);
		when(Item.findItem(1233L)).thenReturn(item1);
		when(Item.findItem(7866L)).thenReturn(item2);

		when(item1.isAvailable()).thenReturn(false);
		when(item2.isAvailable()).thenReturn(true);

		items.add(first);
		items.add(second);

		new AgreementItemCollection(items).isEveryItemAvailableRightNow();

		verify(first).setItem(item1);
		verify(second).setItem(item2);
	}

	/**
	 * Should call update status on all the items.
	 */
	@Test
	public void shouldCallUpdateStatusOnAllTheItems() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);
		final Item firstItem = mock(Item.class);
		final Item secondItem = mock(Item.class);

		when(first.getItemId()).thenReturn(1233L);
		when(second.getItemId()).thenReturn(108L);

		mockStatic(Item.class);
		when(Item.findItem(1233L)).thenReturn(firstItem);
		when(Item.findItem(108L)).thenReturn(secondItem);

		final ItemStatus expectedItemStatus = new ItemStatus();
		new AgreementItemCollection(items).updateItemsStatus(expectedItemStatus);

		verify(firstItem).setItemStatus(expectedItemStatus);
		verify(secondItem).setItemStatus(expectedItemStatus);
		verify(firstItem).merge();
		verify(secondItem).merge();
	}

	/**
	 * Should return null if no matching agreement items found.
	 */
	@Test
	public void shouldReturnNullIfNoMatchingAgreementItemsFound() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		items.add(mock(AgreementItem.class));
		items.add(mock(AgreementItem.class));

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		assertNull(agreementItems.findItemBySerialNumber(1000L));
	}

	/**
	 * Should return the matching agreement item.
	 */
	@Test
	public void shouldReturnTheMatchingAgreementItem() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		items.add(mock(AgreementItem.class));
		final AgreementItem second = mock(AgreementItem.class);
		items.add(second);

		when(second.matches(1233L)).thenReturn(true);

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		assertSame(second, agreementItems.findItemBySerialNumber(1233L));
	}

	/**
	 * Should add the item to the list.
	 */
	@Test
	public void shouldAddTheItemToTheList() {
		final AgreementItemCollection agreementItems = new AgreementItemCollection(new ArrayList<AgreementItem>());
		agreementItems.add(new AgreementItem());

		assertEquals(1, agreementItems.size());
	}

	/**
	 * Should not do anything if removed item list is null.
	 */
	@Test
	public void shouldNotDoAnythingIfRemovedItemListIsNull() {
		final AgreementItemCollection items = new AgreementItemCollection(null);
		items.removeAll(null);
	}

	/**
	 * Should no remove any items if ids dont match in two collections.
	 */
	@Test
	public void shouldNoRemoveAnyItemsIfIdsDontMatchInTwoCollections() {
		final HashSet<AgreementItem> first = new HashSet<AgreementItem>();
		first.add(new AgreementItemBuilder().withId(1233L).buildAgreementItem());
		final HashSet<AgreementItem> second = new HashSet<AgreementItem>();
		second.add(new AgreementItemBuilder().withId(108L).buildAgreementItem());

		new AgreementItemCollection(first).removeAll(new AgreementItemCollection(second));

		assertEquals(1, first.size());
		assertEquals(1, second.size());
	}

	/**
	 * Should remove the items that have matching ids.
	 */
	@Test
	public void shouldRemoveTheItemsThatHaveMatchingIds() {
		final HashSet<AgreementItem> first = new HashSet<AgreementItem>();
		first.add(new AgreementItemBuilder().withId(1233L).buildAgreementItem());
		final AgreementItem itemToRemove = new AgreementItemBuilder().withId(127L).buildAgreementItem();
		first.add(itemToRemove);
		final HashSet<AgreementItem> second = new HashSet<AgreementItem>();
		second.add(new AgreementItemBuilder().withId(127L).buildAgreementItem());

		new AgreementItemCollection(first).removeAll(new AgreementItemCollection(second));

		assertEquals(1, first.size());
		assertFalse(first.contains(itemToRemove));
		assertEquals(1, second.size());
	}

	/**
	 * Should remove the agreement reference of items that have matching ids.
	 */
	@Test
	public void shouldRemoveTheAgreementReferenceOfItemsThatHaveMatchingIds() {
		final HashSet<AgreementItem> first = new HashSet<AgreementItem>();
		first.add(new AgreementItemBuilder().withId(1233L).buildAgreementItem());
		final AgreementItem itemToRemove = new AgreementItemBuilder().withId(127L).withAgreement(new Agreement())
		        .buildAgreementItem();

		first.add(itemToRemove);
		final HashSet<AgreementItem> second = new HashSet<AgreementItem>();
		second.add(new AgreementItemBuilder().withId(127L).buildAgreementItem());

		new AgreementItemCollection(first).removeAll(new AgreementItemCollection(second));

		assertNull(itemToRemove.getAgreement());
	}

	/**
	 * Should remove the item from the list.
	 */
	@Test
	public void shouldRemoveTheItemFromTheList() {
		final List mockedItems = mock(List.class);
		final AgreementItem expectedAgreementItem = new AgreementItem();
		new AgreementItemCollection(mockedItems).remove(expectedAgreementItem);

		verify(mockedItems).remove(expectedAgreementItem);
	}

	/**
	 * Should clear the agreement reference from the set.
	 */
	@Test
	public void shouldClearTheAgreementReferenceFromTheSet() {
		final List mockedItems = mock(List.class);
		final AgreementItem expectedAgreementItem = new AgreementItemBuilder().withAgreement(new Agreement())
		        .buildAgreementItem();
		new AgreementItemCollection(mockedItems).remove(expectedAgreementItem);

		assertNull(expectedAgreementItem.getAgreement());
	}

	/**
	 * Should return false if item with serial number was not found.
	 */
	@Test
	public void shouldReturnFalseIfItemWithSerialNumberWasNotFound() {
		final HashSet<AgreementItem> first = new HashSet<AgreementItem>();
		final AgreementItem mockedItem = mock(AgreementItem.class);
		first.add(mockedItem);
		final Item item = new ItemBuilder().withSerialNumber(100L).buildItem();

		when(mockedItem.matches(100L)).thenReturn(false);

		assertFalse(new AgreementItemCollection(first).containsBySerialNumber(item));
	}

	/**
	 * Should return true if item with serial number was found.
	 */
	@Test
	public void shouldReturnTrueIfItemWithSerialNumberWasFound() {
		final HashSet<AgreementItem> first = new HashSet<AgreementItem>();
		final AgreementItem mockedItem = mock(AgreementItem.class);
		first.add(mock(AgreementItem.class));
		first.add(mockedItem);
		final Item item = new ItemBuilder().withSerialNumber(100L).buildItem();

		when(mockedItem.matches(100L)).thenReturn(true);

		assertTrue(new AgreementItemCollection(first).containsBySerialNumber(item));
	}

	/**
	 * Checks if is item status update called while marking agreement item status as available.
	 */
	@Test
	public void isItemStatusUpdateCalledWhileMarkingAgreementItemStatusAsAvailable() {
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();
		final AgreementItem firstMockedItem = mock(AgreementItem.class);
		agreementItems.add(firstMockedItem);

		final ItemStatus itemStatus = new ItemStatus();
		mockStatic(ItemStatus.class);
		mockStatic(AgreementItemStatus.class);
		when(ItemStatus.findAvailable()).thenReturn(itemStatus);

		final AgreementItemCollection aa = new AgreementItemCollection(agreementItems);
		aa.markAgreementItemStatusAsAvailable();

		verify(firstMockedItem).updateItemStatus(itemStatus);

		PowerMockito.verifyStatic();
		AgreementItemStatus.findReturned();
	}

	/**
	 * Checks if is persist item called while marking agreement item status as available.
	 */
	@Test
	public void isPersistItemCalledWhileMarkingAgreementItemStatusAsAvailable() {
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();
		final AgreementItem firstMockedItem = mock(AgreementItem.class);
		agreementItems.add(firstMockedItem);

		final ItemStatus itemStatus = new ItemStatus();
		mockStatic(ItemStatus.class);
		mockStatic(AgreementItemStatus.class);
		when(ItemStatus.findAvailable()).thenReturn(itemStatus);

		final AgreementItemCollection aa = new AgreementItemCollection(agreementItems);
		aa.markAgreementItemStatusAsAvailable();

		verify(firstMockedItem).persistItem();

		PowerMockito.verifyStatic();
		AgreementItemStatus.findReturned();
	}

    @Test
    public void shouldSetTheCheckinDateToCurrentDateWhenWeMarkAllItemsAvailable() {
        final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();
        final AgreementItem firstMockedItem = mock(AgreementItem.class);
        agreementItems.add(firstMockedItem);

        final ItemStatus itemStatus = new ItemStatus();
        mockStatic(ItemStatus.class);
        mockStatic(AgreementItemStatus.class);
        when(ItemStatus.findAvailable()).thenReturn(itemStatus);

        final AgreementItemCollection aa = new AgreementItemCollection(agreementItems);

        final Calendar currentDate = Calendar.getInstance();

        aa.markAgreementItemStatusAsAvailable();

        verify(firstMockedItem).setCheckinDate(argThat(new ArgumentMatcher<Calendar>() {

            @Override
            public boolean matches(Object o) {
                return ((Calendar)o).compareTo(currentDate) >= 0;
            }
        }));
    }

	/**
	 * Should sum up the total additional charges of all the items.
	 */
	@Test
	public void shouldSumUpTheTotalAdditionalChargesOfAllTheItems() {
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();
		final AgreementItem firstMockedItem = mock(AgreementItem.class);
		final AgreementItem secondMockedItem = mock(AgreementItem.class);
		agreementItems.add(firstMockedItem);
		agreementItems.add(secondMockedItem);

		when(firstMockedItem.isCheckedin()).thenReturn(true);
		when(secondMockedItem.isCheckedin()).thenReturn(true);

		when(firstMockedItem.getTotalAdditionalChargeAmount()).thenReturn(new BigDecimal(1.8));
		when(secondMockedItem.getTotalAdditionalChargeAmount()).thenReturn(new BigDecimal(3.6));

		assertEquals(new BigDecimal(5.4).doubleValue(), new AgreementItemCollection(agreementItems)
		        .getTotalAdditionalChargeAmountOfItemsCurrentlyCheckedin().doubleValue(), 0.001);
	}

	/**
	 * Should sum up the total additional charges of all the items that are been checked in and return them.
	 */
	@Test
	public void shouldSumUpTheTotalAdditionalChargesOfAllTheItemsThatAreBeenCheckedInAndReturnThem() {
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();
		final AgreementItem firstMockedItem = mock(AgreementItem.class);
		final AgreementItem secondMockedItem = mock(AgreementItem.class);
		final AgreementItem thirdMockedItem = mock(AgreementItem.class);
		agreementItems.add(firstMockedItem);
		agreementItems.add(secondMockedItem);
		agreementItems.add(thirdMockedItem);

		when(firstMockedItem.isCheckedin()).thenReturn(true);
		when(secondMockedItem.isCheckedin()).thenReturn(false);
		when(thirdMockedItem.isCheckedin()).thenReturn(true);

		when(firstMockedItem.getTotalAdditionalChargeAmount()).thenReturn(new BigDecimal("1.8"));
		when(secondMockedItem.getTotalAdditionalChargeAmount()).thenReturn(new BigDecimal("3.6"));
		when(thirdMockedItem.getTotalAdditionalChargeAmount()).thenReturn(new BigDecimal("2.7"));

		assertEquals(new BigDecimal("4.5").doubleValue(), new AgreementItemCollection(agreementItems)
		        .getTotalAdditionalChargeAmountOfItemsCurrentlyCheckedin().doubleValue(), 0.001);
	}

	/**
	 * Should save the items.
	 */
	@Test
	public void shouldSaveTheItems() {
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();
		final AgreementItem firstMockedItem = mock(AgreementItem.class);
		final AgreementItem secondMockedItem = mock(AgreementItem.class);
		agreementItems.add(firstMockedItem);
		agreementItems.add(secondMockedItem);

		when(firstMockedItem.isCheckedin()).thenReturn(true);
		when(secondMockedItem.isCheckedin()).thenReturn(true);

		new AgreementItemCollection(agreementItems).checkinMarkedItems();

		verify(firstMockedItem).actualCheckin();
		verify(secondMockedItem).actualCheckin();
	}

	/**
	 * Should checkin only marked items.
	 */
	@Test
	public void shouldCheckinOnlyMarkedItems() {
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();
		final AgreementItem firstMockedItem = mock(AgreementItem.class);
		final AgreementItem secondMockedItem = mock(AgreementItem.class);
		agreementItems.add(firstMockedItem);
		agreementItems.add(secondMockedItem);

		when(firstMockedItem.isCheckedin()).thenReturn(true);
		when(secondMockedItem.isCheckedin()).thenReturn(false);

		new AgreementItemCollection(agreementItems).checkinMarkedItems();

		verify(firstMockedItem).actualCheckin();
		verify(secondMockedItem, never()).actualCheckin();
	}

	/**
	 * Should return true if guest meets minimum age for all the rental items.
	 */
	@Test
	public void shouldReturnTrueIfGuestMeetsMinimumAgeForAllTheRentalItems() {
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();
		final AgreementItem firstMockedItem = mock(AgreementItem.class);
		final AgreementItem secondMockedItem = mock(AgreementItem.class);
		agreementItems.add(firstMockedItem);
		agreementItems.add(secondMockedItem);

		final Agreement agreement = new Agreement();
		when(firstMockedItem.isDriverAgeGreaterThanMinimumRentalAge(agreement)).thenReturn(true);
		when(secondMockedItem.isDriverAgeGreaterThanMinimumRentalAge(agreement)).thenReturn(true);

		assertTrue(new AgreementItemCollection(agreementItems).isDriverAgeGreaterThanMinimumRentalAge(agreement));
	}

	/**
	 * Should return false if guest does not meet minimum age for any one of the rental items.
	 */
	@Test
	public void shouldReturnFalseIfGuestDoesNotMeetMinimumAgeForAnyOneOfTheRentalItems() {
		final HashSet<AgreementItem> agreementItems = new HashSet<AgreementItem>();
		final AgreementItem firstMockedItem = mock(AgreementItem.class);
		final AgreementItem secondMockedItem = mock(AgreementItem.class);
		agreementItems.add(firstMockedItem);
		agreementItems.add(secondMockedItem);

		final Agreement agreement = new Agreement();
		when(firstMockedItem.isDriverAgeGreaterThanMinimumRentalAge(agreement)).thenReturn(true);
		when(secondMockedItem.isDriverAgeGreaterThanMinimumRentalAge(agreement)).thenReturn(false);

		assertFalse(new AgreementItemCollection(agreementItems).isDriverAgeGreaterThanMinimumRentalAge(agreement));
	}

	/**
	 * Should return true if rental agreement has no items.
	 */
	@Test
	public void shouldReturnTrueIfRentalAgreementHasNoItems() {
		final Agreement agreement = new Agreement();
		assertTrue(new AgreementItemCollection(new HashSet<AgreementItem>()).isDriverAgeGreaterThanMinimumRentalAge(agreement));
	}

	/**
	 * Should calculate the damage waiver charges for all the items.
	 */
	@Test
	public void shouldCalculateTheDamageWaiverChargesForAllTheItems() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);
		agreementItems.calculateDamageWaiverCharges();

		verify(first).calculateDamageWaiverCharges();
		verify(second).calculateDamageWaiverCharges();
	}

	/**
	 * Should set price override manager name for items that have price override value.
	 */
	@Test
	public void shouldSetPriceOverrideManagerNameForItemsThatHavePriceOverrideValue() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);

		when(first.getHasPriceOverride()).thenReturn(false);
		when(second.getHasPriceOverride()).thenReturn(true);

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		agreementItems.setPriceOverrideApprovedBy(1233);

		verify(first, never()).setPriceOverrideByNumber(anyInt());
		verify(second).setPriceOverrideByNumber(1233);
	}

	/**
	 * Should set quantity override manager name for items that have quantity override value.
	 */
	@Test
	public void shouldSetQuantityOverrideManagerNameForItemsThatHaveQuantityOverrideValue() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);

		when(first.getHasQuantityOverride()).thenReturn(true);
		when(second.getHasQuantityOverride()).thenReturn(false);

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		agreementItems.setQuantityOverrideApprovedBy(1233);

		verify(first).setQuantityOverrideByNumber(1233);
		verify(second, never()).setPriceOverrideByNumber(anyInt());
	}

	/**
	 * Should return the first items price override manager name.
	 */
	@Test
	public void shouldReturnTheFirstItemsPriceOverrideManagerName() {
		final List<AgreementItem> items = new ArrayList<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);

		when(first.getPriceOverrideByNumber()).thenReturn(1233);
		when(second.getPriceOverrideByNumber()).thenReturn(7866);

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		assertEquals(1233, agreementItems.getPriceOverrideApprovedBy().intValue());
	}

	/**
	 * Should return null if none of the items have price override manager name.
	 */
	@Test
	public void shouldReturnNullIfNoneOfTheItemsHavePriceOverrideManagerName() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);
        when(first.getPriceOverrideByNumber()).thenReturn(null);
        when(second.getPriceOverrideByNumber()).thenReturn(null);

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		assertNull(agreementItems.getPriceOverrideApprovedBy());
	}

	/**
	 * Should return the first items quantity override manager name.
	 */
	@Test
	public void shouldReturnTheFirstItemsQuantityOverrideManagerName() {
		final List<AgreementItem> items = new ArrayList<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);

		when(first.getQuantityOverrideByNumber()).thenReturn(1233);
		when(second.getQuantityOverrideByNumber()).thenReturn(7866);

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		assertEquals(1233, agreementItems.getQuantityOverrideApprovedBy().intValue());
	}

	/**
	 * Should return null if none of the items have quantity override manager name.
	 */
	@Test
	public void shouldReturnNullIfNoneOfTheItemsHaveQuantityOverrideManagerName() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

        when(first.getQuantityOverrideByNumber()).thenReturn(null);
        when(second.getQuantityOverrideByNumber()).thenReturn(null);
		items.add(first);
		items.add(second);

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		assertNull(agreementItems.getQuantityOverrideApprovedBy());
	}

	/**
	 * Should fulfill reservations associated with the agreement items.
	 */
	@Test
	public void shouldFulfillReservationsAssociatedWithTheAgreementItems() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		agreementItems.fulfillReservations();

		verify(first).fulfillReservation();
		verify(second).fulfillReservation();
	}

	/**
	 * Should return zero if all items are in returned and paid complete state.
	 */
	@Test
	public void shouldReturnZeroIfAllItemsAreInReturnedAndPaidCompleteState() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);

		when(first.isReturnedAndPaidComplete()).thenReturn(true);
		when(second.isReturnedAndPaidComplete()).thenReturn(true);

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		assertEquals(0.0, agreementItems.getEffectiveRentalTotalExcludingDamageWaiver().doubleValue(), 0.001);

	}

	/**
	 * Should return negative charge amouts if the agreement is voided.
	 */
	@Test
	public void shouldReturnNegativeChargeAmoutsIfTheAgreementIsVoided() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);

		when(first.isAgreementVoided()).thenReturn(true);
		when(second.isAgreementVoided()).thenReturn(true);

		when(first.getTotalEstimatedChargeAmount()).thenReturn(new BigDecimal("1.8"));
		when(second.getTotalEstimatedChargeAmount()).thenReturn(new BigDecimal("2.7"));

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		assertEquals(-4.5, agreementItems.getEffectiveRentalTotalExcludingDamageWaiver().doubleValue(), 0.001);

	}

	/**
	 * Should return estimated charge amount if the item is checked out.
	 */
	@Test
	public void shouldReturnEstimatedChargeAmountIfTheItemIsCheckedOut() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);

		when(first.isCheckedOut()).thenReturn(true);
		when(second.isCheckedOut()).thenReturn(true);

		when(first.getTotalEstimatedChargeAmount()).thenReturn(new BigDecimal("1.8"));
		when(second.getTotalEstimatedChargeAmount()).thenReturn(new BigDecimal("2.7"));

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		assertEquals(4.5, agreementItems.getEffectiveRentalTotalExcludingDamageWaiver().doubleValue(), 0.001);

	}

	/**
	 * Should return actual charge amount if the item is checked out.
	 */
	@Test
	public void shouldReturnActualChargeAmountIfTheItemIsCheckedOut() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);

		when(first.isReturned()).thenReturn(true);
		when(second.isReturned()).thenReturn(true);

		when(first.getTotalAdditionalChargeAmount()).thenReturn(new BigDecimal("3.6"));
		when(second.getTotalAdditionalChargeAmount()).thenReturn(new BigDecimal("2.7"));

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		assertEquals(6.3, agreementItems.getEffectiveRentalTotalExcludingDamageWaiver().doubleValue(), 0.001);
	}

	/**
	 * Should return total effective charge as the sum of expected and actual charges.
	 */
	@Test
	public void shouldReturnTotalEffectiveChargeAsTheSumOfExpectedAndActualCharges() {
		final HashSet<AgreementItem> items = new HashSet<AgreementItem>();
		final AgreementItem first = mock(AgreementItem.class);
		final AgreementItem second = mock(AgreementItem.class);

		items.add(first);
		items.add(second);

		when(first.isCheckedOut()).thenReturn(true);
		when(second.isReturned()).thenReturn(true);

		when(first.getTotalEstimatedChargeAmount()).thenReturn(new BigDecimal("9.81"));
		when(second.getTotalAdditionalChargeAmount()).thenReturn(new BigDecimal("2.7"));

		final AgreementItemCollection agreementItems = new AgreementItemCollection(items);

		assertEquals(12.51, agreementItems.getEffectiveRentalTotalExcludingDamageWaiver().doubleValue(), 0.001);
	}
    
    @Test
    public void shouldReturnNullIfAllItemsHaveBeenCheckedin() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();
        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        when(first.isToBeCheckedin()).thenReturn(false);
        when(second.isToBeCheckedin()).thenReturn(false);

        assertNull(new AgreementItemCollection(items).getNextItemSerialNumberToAnswerChecklist());
    }

    @Test
    public void shouldReturnTheItemSerialNumberOfTheFirstItemThatIsToBeCheckedin() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();
        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);
        final AgreementItem third = mock(AgreementItem.class);

        items.add(first);
        items.add(second);
        items.add(third);

        when(first.isToBeCheckedin()).thenReturn(false);
        when(second.isToBeCheckedin()).thenReturn(true);
        when(third.isToBeCheckedin()).thenReturn(true);

        when(second.getSerialNumber()).thenReturn(7866L);
        when(third.getSerialNumber()).thenReturn(1233L);

        assertEquals(7866L, new AgreementItemCollection(items).getNextItemSerialNumberToAnswerChecklist().longValue());
    }

    @Test
    public void shouldReturnTrueIfItemsHaveAVehicle() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();
        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);
        final AgreementItem third = mock(AgreementItem.class);

        items.add(first);
        items.add(second);
        items.add(third);

        when(first.getVehicleRentalDetail()).thenReturn(null);
        when(second.getVehicleRentalDetail()).thenReturn(null);
        when(third.getVehicleRentalDetail()).thenReturn(new VehicleRentalDetail());

        assertTrue(new AgreementItemCollection(items).isVehicleRented());
    }

    @Test
    public void shouldReturnFalseIfItemsDoNotHaveAVehicle() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();
        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);
        final AgreementItem third = mock(AgreementItem.class);

        items.add(first);
        items.add(second);
        items.add(third);

        when(first.getVehicleRentalDetail()).thenReturn(null);
        when(second.getVehicleRentalDetail()).thenReturn(null);
        when(third.getVehicleRentalDetail()).thenReturn(null);

        assertFalse(new AgreementItemCollection(items).isVehicleRented());
    }

    @Test
    public void shouldUpdateTheCheckoutDateToTheCurrentDate() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        final Calendar transactionDate = Calendar.getInstance();
        new AgreementItemCollection(items).updateCheckoutDate(transactionDate);

        verify(first).updateCheckoutDate(transactionDate);
        verify(second).updateCheckoutDate(transactionDate);
    }

    @Test
    public void shouldUpdateTheAgreementItemStatusIfCurrentlyItsInReturnedState() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        when(first.isReturned()).thenReturn(true);
        when(second.isReturned()).thenReturn(false);

        final AgreementItemStatus agreementItemStatus = new AgreementItemStatus();

        new AgreementItemCollection(items).updateAgreementItemForReturnedItems(
                agreementItemStatus
        );

        verify(first).setStatus(agreementItemStatus);

        verify(second, never()).setStatus(agreementItemStatus);
    }
    
    @Test
    public void shouldReturnTrueIfEveryItemIsRetunedAndPaidComplete() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        when(first.isReturnedAndPaidComplete()).thenReturn(true);
        when(second.isReturnedAndPaidComplete()).thenReturn(true);

        assertTrue(new AgreementItemCollection(items).isEveryItemReturnedAndPaid());
    }

    @Test
    public void shouldReturnFalseIfNotEveryItemIsRetunedAndPaidComplete() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        when(first.isReturnedAndPaidComplete()).thenReturn(false);
        when(second.isReturnedAndPaidComplete()).thenReturn(true);

        assertFalse(new AgreementItemCollection(items).isEveryItemReturnedAndPaid());
    }

    @Test
    public void shouldReturnTrueIfAgreementHasItemsOtherThanPickAndGoTruck() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        when(first.isInsuranceAdditionalDriverLicenseRequired()).thenReturn(false);
        when(second.isInsuranceAdditionalDriverLicenseRequired()).thenReturn(true);

        assertTrue(new AgreementItemCollection(items).getHasOtherItemsThatDoNotRequireAdditionalDriver());
    }

    @Test
    public void shouldReturnFlaseIfAgreementDoesNotHaveItemsOtherThanPickAndGoTruck() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        when(first.isInsuranceAdditionalDriverLicenseRequired()).thenReturn(true);
        when(second.isInsuranceAdditionalDriverLicenseRequired()).thenReturn(true);

        assertFalse(new AgreementItemCollection(items).getHasOtherItemsThatDoNotRequireAdditionalDriver());
    }
    
    @Test
    public void shouldReturnTrueIfThereAreItemsThatAreReturnedButNotPaid() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        when(first.isReturned()).thenReturn(false);
        when(second.isReturned()).thenReturn(true);

        assertTrue(new AgreementItemCollection(items).hasItemsThatAreReturnedButNotPaid());
    }

    @Test
    public void shouldReturnFalseIfThereAreNoItemsThatAreReturnedButNotPaid() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        when(first.isReturned()).thenReturn(false);
        when(second.isReturned()).thenReturn(false);

        assertFalse(new AgreementItemCollection(items).hasItemsThatAreReturnedButNotPaid());
    }
    
    @Test
    public void shouldReturnTrueIfAllItemsAreInCheckedOutOrCheckedOutAndPaidInitialState() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        when(first.isReturned()).thenReturn(false);
        when(first.isReturnedAndPaidComplete()).thenReturn(false);

        when(second.isReturned()).thenReturn(false);
        when(second.isReturnedAndPaidComplete()).thenReturn(false);

        assertTrue(new AgreementItemCollection(items).isEveryItemCheckedOutOrCheckedOutAndPaidInitial());
    }

    @Test
    public void shouldReturnFalseIfAtleastOneItemIsInReturnedState() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        when(first.isReturned()).thenReturn(false);
        when(first.isReturnedAndPaidComplete()).thenReturn(false);

        when(second.isReturned()).thenReturn(true);
        when(second.isReturnedAndPaidComplete()).thenReturn(false);

        assertFalse(new AgreementItemCollection(items).isEveryItemCheckedOutOrCheckedOutAndPaidInitial());
    }

    @Test
    public void shouldReturnFalseIfAtleastOneItemIsInReturnedAndPaidState() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        when(first.isReturned()).thenReturn(false);
        when(first.isReturnedAndPaidComplete()).thenReturn(true);

        when(second.isReturned()).thenReturn(false);
        when(second.isReturnedAndPaidComplete()).thenReturn(false);

        assertFalse(new AgreementItemCollection(items).isEveryItemCheckedOutOrCheckedOutAndPaidInitial());
    }

    @Test
    public void shouldReturnFalseIfMoreThanOneItemsAreInReturnedState() {
        final List<AgreementItem> items = new ArrayList<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        when(first.isReturned()).thenReturn(true);
        when(first.isReturnedAndPaidComplete()).thenReturn(false);

        when(second.isReturned()).thenReturn(false);
        when(second.isReturnedAndPaidComplete()).thenReturn(true);

        assertFalse(new AgreementItemCollection(items).isEveryItemCheckedOutOrCheckedOutAndPaidInitial());
    }
    
    @Test
    public void shouldReturnTheEarliersDueByDateOfItem() {
        final HashSet<AgreementItem> items = new HashSet<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        final Calendar laterDueBy = Calendar.getInstance();
        laterDueBy.add(Calendar.HOUR, 1);
        final Calendar upcomingDueBy = Calendar.getInstance();
        when(first.getDueBy()).thenReturn(laterDueBy);
        when(second.getDueBy()).thenReturn(upcomingDueBy);

        assertSame(upcomingDueBy, new AgreementItemCollection(items).getUpcomingDueBy());        
    }

    @Test
    public void shouldReturnTheEarliersDueByDateOfItemForItemsThatHaveNotBeenReturned() {
        final HashSet<AgreementItem> items = new HashSet<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        final Calendar laterDueBy = Calendar.getInstance();
        laterDueBy.add(Calendar.HOUR, 1);
        final Calendar upcomingDueBy = Calendar.getInstance();
        when(first.getDueBy()).thenReturn(laterDueBy);
        when(second.getDueBy()).thenReturn(upcomingDueBy);
        when(second.isReturned()).thenReturn(true);
        when(first.isReturned()).thenReturn(false);

        assertSame(laterDueBy, new AgreementItemCollection(items).getUpcomingDueBy());
    }

    @Test
    public void shouldReturnTheEarliersDueByDateOfItemForItemsThatHaveNotBeenReturnedAndPaid() {
        final HashSet<AgreementItem> items = new HashSet<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        items.add(first);
        items.add(second);

        final Calendar laterDueBy = Calendar.getInstance();
        laterDueBy.add(Calendar.HOUR, 1);
        final Calendar upcomingDueBy = Calendar.getInstance();
        when(first.getDueBy()).thenReturn(laterDueBy);
        when(second.getDueBy()).thenReturn(upcomingDueBy);
        when(second.isReturnedAndPaidComplete()).thenReturn(true);
        when(first.isReturnedAndPaidComplete()).thenReturn(false);

        assertSame(laterDueBy, new AgreementItemCollection(items).getUpcomingDueBy());
    }

    @Test
    public void shouldReturnListOfCurrentlyCheckedinItems() {
        final HashSet<AgreementItem> items = new HashSet<AgreementItem>();

        final AgreementItem first = mock(AgreementItem.class);
        final AgreementItem second = mock(AgreementItem.class);

        when(first.isCheckedin()).thenReturn(false);
        when(second.isCheckedin()).thenReturn(true);
        items.add(first);
        items.add(second);

        final AgreementItemCollection currentlyCheckedInItems = new AgreementItemCollection(items)
                .getCurrentlyCheckedInItems();
        assertEquals(1, currentlyCheckedInItems.size());
        assertTrue(currentlyCheckedInItems.contains(second));
    }
}
