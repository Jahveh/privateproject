/*
 * IncrementalHoursCalculationRulesTest.java
 */
package com.menards.rental.domain.rule;

import static junit.framework.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.whenNew;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.domain.StoreHourBasedRentalDateRange;

/**
 * Created by IntelliJ IDEA. User: deep Date: 13 Jun, 2010 Time: 8:05:09 AM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest(IncrementalHoursCalculationRuleComposite.class)
public class IncrementalHoursCalculationRuleCompositeTest {

	/**
	 * Should delegate the calculation to zero incremental hours calculation rule if total rental duration is less than base sku hr qty.
	 *
	 * @throws Exception the exception
	 *//*
	@Test
	public void shouldDelegateTheCalculationToZeroIncrementalHoursCalculationRuleIfTotalRentalDurationIsLessThanBaseSkuHrQty()
	        throws Exception {
		final StoreHourBasedRentalDateRange mockedRentalDateRange = mock(StoreHourBasedRentalDateRange.class);
		when(mockedRentalDateRange.isTotalDurationLessThan(4.0)).thenReturn(true);

		final ZeroIncrementalHoursCalculationRule mockedZeroIncrementalHoursCalculationRule = mock(ZeroIncrementalHoursCalculationRule.class);
		whenNew(ZeroIncrementalHoursCalculationRule.class).withArguments(4.0, mockedRentalDateRange).thenReturn(
		        mockedZeroIncrementalHoursCalculationRule);
		when(mockedZeroIncrementalHoursCalculationRule.calculate()).thenReturn(0.0);

		assertEquals(0.0, new IncrementalHoursCalculationRuleComposite(4.0, 1.0, mockedRentalDateRange).calculate());
	}

	*//**
	 * Should delegate the calculation to difference of total and base hours incremental hours calculation rule if base sku hr qty is greater than12.
	 *
	 * @throws Exception the exception
	 *//*
	@Test
	public void shouldDelegateTheCalculationToDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRuleIfBaseSkuHrQtyIsGreaterThan12()
	        throws Exception {
		final StoreHourBasedRentalDateRange mockedRentalDateRange = mock(StoreHourBasedRentalDateRange.class);

		final DiffOfTotalAndBaseHrsAndIncrHrsCalcRule mockedDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule = mock(DiffOfTotalAndBaseHrsAndIncrHrsCalcRule.class);
		whenNew(DiffOfTotalAndBaseHrsAndIncrHrsCalcRule.class).withArguments(14.0,
		        mockedRentalDateRange).thenReturn(mockedDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule);
		when(mockedDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule.calculate()).thenReturn(10.0);

		assertEquals(10.0, new IncrementalHoursCalculationRuleComposite(14.0, 2.0, mockedRentalDateRange).calculate());
	}

	*//**
	 * Should delegate the calculation to zero incremental hours calculation rule if actual rental duration is less than base sku hr qty.
	 *
	 * @throws Exception the exception
	 *//*
	@Test
	public void shouldDelegateTheCalculationToZeroIncrementalHoursCalculationRuleIfActualRentalDurationIsLessThanBaseSkuHrQty()
	        throws Exception {
		final StoreHourBasedRentalDateRange mockedRentalDateRange = mock(StoreHourBasedRentalDateRange.class);
		when(mockedRentalDateRange.isTotalDurationLessThan(4.0)).thenReturn(false);
		when(mockedRentalDateRange.isActualDurationLessThan(4.0)).thenReturn(true);

		final ZeroIncrementalHoursCalculationRule mockedZeroIncrementalHoursCalculationRule = mock(ZeroIncrementalHoursCalculationRule.class);
		whenNew(ZeroIncrementalHoursCalculationRule.class).withArguments(4.0, mockedRentalDateRange).thenReturn(
		        mockedZeroIncrementalHoursCalculationRule);
		when(mockedZeroIncrementalHoursCalculationRule.calculate()).thenReturn(0.0);

		assertEquals(0.0, new IncrementalHoursCalculationRuleComposite(4.0, 1.0, mockedRentalDateRange).calculate());
	}

	*//**
	 * Should delegate the calculation to difference of value and base hours with rounding incremental hours calculation rule if rental date is on the same day.
	 *
	 * @throws Exception the exception
	 *//*
	@Test
	public void shouldDelegateTheCalculationToDifferenceOfValueAndBaseHoursWithRoundingIncrementalHoursCalculationRuleIfRentalDateIsOnTheSameDay()
	        throws Exception {
		final StoreHourBasedRentalDateRange mockedRentalDateRange = mock(StoreHourBasedRentalDateRange.class);
		when(mockedRentalDateRange.isOnSameDay()).thenReturn(true);

		final DiffOfValAndBaseHrsWithRndIncreHrsCalcRule mockedDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule = mock(DiffOfValAndBaseHrsWithRndIncreHrsCalcRule.class);
		whenNew(DiffOfValAndBaseHrsWithRndIncreHrsCalcRule.class).withArguments(4.0, 2.0,
		        mockedRentalDateRange).thenReturn(mockedDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule);

		when(mockedDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule.calculate()).thenReturn(6.0);

		assertEquals(6.0, new IncrementalHoursCalculationRuleComposite(4.0, 2.0, mockedRentalDateRange).calculate());
	}

	*//**
	 * Should delegate the calculation to different days incremental hours calculation rule if rental date is on different days and actual duration is less than24.
	 *
	 * @throws Exception the exception
	 *//*
	@Test
	public void shouldDelegateTheCalculationToDifferentDaysIncrementalHoursCalculationRuleIfRentalDateIsOnDifferentDaysAndActualDurationIsLessThan24()
	        throws Exception {
		final StoreHourBasedRentalDateRange mockedRentalDateRange = mock(StoreHourBasedRentalDateRange.class);
		when(mockedRentalDateRange.isActualDurationLessThan(24.0)).thenReturn(true);

		final DiffDaysIncreHrsCalcRule mockedDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule = mock(DiffDaysIncreHrsCalcRule.class);
		whenNew(DiffDaysIncreHrsCalcRule.class).withArguments(4.0, 2.0, mockedRentalDateRange)
		        .thenReturn(mockedDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule);

		when(mockedDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule.calculate()).thenReturn(6.0);

		assertEquals(6.0, new IncrementalHoursCalculationRuleComposite(4.0, 2.0, mockedRentalDateRange).calculate());
	}*/
	
	@Test
	public void calculateTheIncrementalHours() throws Exception {
		final StoreHourBasedRentalDateRange mockedRentalDateRange = mock(StoreHourBasedRentalDateRange.class);
		
		final DiffDaysIncreHrsCalcRule mockedDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule = mock(DiffDaysIncreHrsCalcRule.class);
		whenNew(DiffDaysIncreHrsCalcRule.class).withArguments(4.0, 2.0, mockedRentalDateRange)
		        .thenReturn(mockedDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule);

		when(mockedDifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule.calculate()).thenReturn(6.0);

		assertEquals(6.0, new IncrementalHoursCalculationRuleComposite(4.0, 2.0, mockedRentalDateRange).calculate());
	}
}
