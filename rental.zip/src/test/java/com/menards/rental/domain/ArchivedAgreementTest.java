package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.stub;

import java.util.ArrayList;

import javax.persistence.Query;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.builder.AgreementBuilder;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest(ArchivedAgreement.class)
public class ArchivedAgreementTest {

    @Test
    public void shouldReturnNullIfNoAgreementMatchingTheAgreementNumberIsFound() {
        final Query query = mock(Query.class);
        stub(method(ArchivedAgreement.class, "findArchivedAgreementsByAgreementNumber", String.class))
                .andReturn(query);
        when(query.getResultList()).thenReturn(new ArrayList<ArchivedAgreement>());

        assertNull(ArchivedAgreement.findArchivedAgreementByAgreementNumber("1231-23424-001"));
    }

    @Test
    public void shouldReturnTheReferenceOfTheMatchingAgreementArchive() {
        final ArchivedAgreement archivedAgreement = new ArchivedAgreement();
        final Query query = mock(Query.class);
        stub(method(ArchivedAgreement.class, "findArchivedAgreementsByAgreementNumber", String.class))
                .andReturn(query);
        final ArrayList<ArchivedAgreement> archivedAgreements = new ArrayList<ArchivedAgreement>();
        archivedAgreements.add(archivedAgreement);
        when(query.getResultList()).thenReturn(archivedAgreements);

        assertSame(archivedAgreement, ArchivedAgreement.findArchivedAgreementByAgreementNumber("1231-23424-001"));
    }

    @Test
    public void shouldReturnTheVersionOfTheAgreement() {
        final ArchivedAgreement archivedAgreement = new ArchivedAgreement();
        archivedAgreement.setAgreementNumber("8888-01001-009");
        assertEquals("009",
                archivedAgreement.getAgreementVersion());
    }

    @Test
    public void shouldReturnTheVersioNumberAsTheFirstValueIfTheAgreementNumberDoesNotHaveThreeParts() {
        final ArchivedAgreement archivedAgreement = new ArchivedAgreement();
        archivedAgreement.setAgreementNumber("8888-01001009");
        assertEquals("8888",
                archivedAgreement.getAgreementVersion());
    }

    @Test
    public void shouldReturnTrueIfTheAgreementNumberMatchesTheAgreementNumber() {
        final ArchivedAgreement archivedAgreement = new ArchivedAgreement();
        final Agreement agreement = new AgreementBuilder().withAgreementNumber("8888-01001-009").buildAgreement();
        archivedAgreement.setAgreement(agreement);
        assertTrue(archivedAgreement.isLatest());
    }

    @Test
    public void shouldReturnFalseIfTheAgreementIsNotTheLatest() {
        final ArchivedAgreement archivedAgreement = new ArchivedAgreement();
        final Agreement agreement = new AgreementBuilder().withAgreementNumber("8888-01001-009").buildAgreement();
        archivedAgreement.setAgreement(agreement);
        archivedAgreement.setAgreementNumber("8888-01001-008");
        assertFalse(archivedAgreement.isLatest());
    }
}
