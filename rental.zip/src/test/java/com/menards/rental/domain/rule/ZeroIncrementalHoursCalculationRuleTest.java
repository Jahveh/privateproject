/*
 * ZeroIncrementalHoursCalculationRuleTest.java
 */
package com.menards.rental.domain.rule;

import static junit.framework.Assert.assertEquals;

import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: deep Date: 13 Jun, 2010 Time: 1:34:33 PM To
 * change this template use File | Settings | File Templates.
 */
public class ZeroIncrementalHoursCalculationRuleTest {

	/**
	 * Should return0 no matter what is the base and total duration.
	 */
	@Test
	public void shouldReturn0NoMatterWhatIsTheBaseAndTotalDuration() {
		assertEquals(0.0, new ZeroIncrementalHoursCalculationRule(10.0, null).calculate());
	}
}
