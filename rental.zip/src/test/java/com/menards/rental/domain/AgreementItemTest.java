/*
 * AgreementItemTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.spy;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.whenNew;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.stub;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.builder.AgreementItemBuilder;
import com.menards.rental.builder.ItemBuilder;
import com.menards.rental.format.SimpleTimePeriodFormatter;

/**
 * Created by IntelliJ IDEA. User: deep Date: 11 May, 2010 Time: 3:36:00 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest( { Item.class, AgreementItem.class, AgreementItemStatus.class })
public class AgreementItemTest {
	
	/** The agreement item. */
	private AgreementItem agreementItem;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		agreementItem = new AgreementItem();
	}

	/**
	 * Should return the rental sku using the items.
	 */
	@Test
	public void shouldReturnTheRentalSKUUsingTheItems() {
		final Item item = mock(Item.class);
		final String expectedRentalSKU = "Hello World";
		when(item.getRentalSKU()).thenReturn(expectedRentalSKU);

		agreementItem.setItem(item);

		assertEquals(expectedRentalSKU, agreementItem.getRentalSKU());
	}

	/**
	 * Should return item description.
	 */
	@Test
	public void shouldReturnItemDescription() {
		final Item item = mock(Item.class);
		final String expectedDescription = "Hello Description";
		when(item.getDescription()).thenReturn(expectedDescription);

		agreementItem.setItem(item);

		assertEquals(expectedDescription, agreementItem.getDescription());
	}

	/**
	 * Should replace vehicle rental detail.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReplaceVehicleRentalDetail() throws Exception {
		final VehicleRentalDetail vehicleRentalDetailMock = mock(VehicleRentalDetail.class);
		whenNew(VehicleRentalDetail.class).withNoArguments().thenReturn(vehicleRentalDetailMock);
		agreementItem.merge(vehicleRentalDetailMock);

		assertSame(vehicleRentalDetailMock, agreementItem.getVehicleRentalDetail());
	}

	/**
	 * Should call update fields on vehicle rental detail.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCallUpdateFieldsOnVehicleRentalDetail() throws Exception {
		final VehicleRentalDetail vehicleRentalDetail = mock(VehicleRentalDetail.class);
		whenNew(VehicleRentalDetail.class).withNoArguments().thenReturn(vehicleRentalDetail);
		agreementItem.setItem(new Item());

		agreementItem.merge(vehicleRentalDetail);

		verify(vehicleRentalDetail).merge(agreementItem.getItem(), vehicleRentalDetail);
	}

	/**
	 * Should not set passed in vehicle rental detail as we already have one and simple merge new details.
	 */
	@Test
	public void shouldNotSetPassedInVehicleRentalDetailAsWeAlreadyHaveOneAndSimpleMergeNewDetails() {
		final VehicleRentalDetail vehicleRentalDetail = mock(VehicleRentalDetail.class);
		agreementItem.setItem(new Item());
		final VehicleRentalDetail originalVehicleRentalDetail = mock(VehicleRentalDetail.class);
		agreementItem.setVehicleRentalDetail(originalVehicleRentalDetail);

		agreementItem.merge(vehicleRentalDetail);

		verify(originalVehicleRentalDetail).merge(agreementItem.getItem(), vehicleRentalDetail);
	}

	/**
	 * Should return true if item is a vehicle.
	 */
	@Test
	public void shouldReturnTrueIfItemIsAVehicle() {
		final Item item = mock(Item.class);

		when(item.isInsuranceAdditionalDriverLicenseRequired()).thenReturn(true);

		agreementItem.setItem(item);

		assertTrue(agreementItem.isInsuranceAdditionalDriverLicenseRequired());
	}

	/**
	 * Should return false if item is not a vehicle.
	 */
	@Test
	public void shouldReturnFalseIfItemIsNotAVehicle() {
		final Item item = mock(Item.class);

		when(item.isInsuranceAdditionalDriverLicenseRequired()).thenReturn(false);

		agreementItem.setItem(item);

		assertFalse(agreementItem.isInsuranceAdditionalDriverLicenseRequired());
	}

	/**
	 * Should set agreement passed.
	 */
	@Test
	public void shouldSetAgreementPassed() {
		mockStatic(AgreementItemStatus.class);
		when(AgreementItemStatus.findCheckedOut()).thenReturn(null);

		final Agreement expectedAgreement = new Agreement();
		assertSame(expectedAgreement, new AgreementItem(null, expectedAgreement).getAgreement());
	}

	/**
	 * Should set item passed.
	 */
	@Test
	public void shouldSetItemPassed() {
		mockStatic(AgreementItemStatus.class);
		when(AgreementItemStatus.findCheckedOut()).thenReturn(null);

		final Item expectedItem = new Item();
		assertSame(expectedItem, new AgreementItem(expectedItem, null).getItem());
	}

	/**
	 * Should invoke update status on the item.
	 */
	@Test
	public void shouldInvokeUpdateStatusOnTheItem() {
		final ItemStatus expectedItemStatus = new ItemStatus();
		final Item mockedItem = mock(Item.class);
		new AgreementItemBuilder().withItem(mockedItem).buildAgreementItem().updateItemStatus(expectedItemStatus);

		verify(mockedItem).setItemStatus(expectedItemStatus);
	}

	/**
	 * Should return damage waiver total.
	 */
	@Test
	public void shouldReturnDamageWaiverTotal() {
		assertEquals(99.99, new AgreementItemBuilder().withDamageWaiver(new DamageWaiver(false, new BigDecimal("99.99")))
		        .buildAgreementItem().getDamageWaiverAmount().doubleValue(), 0.001);
	}

	/**
	 * Should return false if item is not available.
	 */
	@Test
	public void shouldReturnFalseIfItemIsNotAvailable() {
		assertFalse(new AgreementItemBuilder().withItem(mock(Item.class)).buildAgreementItem().isAvailable());
	}

	/**
	 * Should return true if item is available.
	 */
	@Test
	public void shouldReturnTrueIfItemIsAvailable() {
		final Item mockedItem = mock(Item.class);
		when(mockedItem.isAvailable()).thenReturn(true);

		assertTrue(new AgreementItemBuilder().withItem(mockedItem).buildAgreementItem().isAvailable());
	}

	/**
	 * Should calculate the estimated charges and duration.
	 */
	@Test
	public void shouldCalculateTheEstimatedChargesAndDuration() {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);

		agreementItem.calculateEstimatedChargesAndDuration();

		verify(chargeInfo).calculateEstimatedChargesAndDuration();
	}

	/**
	 * Should return the additional incremental time units.
	 */
	@Test
	public void shouldReturnTheAdditionalIncrementalTimeUnits() {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);
		when(chargeInfo.getActualIncrementalTimeUnits()).thenReturn(25);
		assertEquals(25, agreementItem.getOverrideIncrementalTimeUnits());
	}

	/**
	 * Should return the actual incremental time units.
	 */
	@Test
	public void shouldReturnTheActualIncrementalTimeUnits() {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);
		when(chargeInfo.getActualIncrementalTimeUnits()).thenReturn(25);
		assertEquals(25, agreementItem.getActualIncrementalTimeUnits().intValue());
	}

	/**
	 * Should return the actual incremental charge amount.
	 */
	@Test
	public void shouldReturnTheActualIncrementalChargeAmount() {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);
		when(chargeInfo.getActualIncrementalChargeAmount()).thenReturn(new BigDecimal(18.9));

		assertEquals(new BigDecimal("18.9").doubleValue(), agreementItem.getActualIncrementalChargeAmount().doubleValue(),
		        0.001);
	}

	/**
	 * Should return true if id of the item is zero.
	 */
	@Test
	public void shouldReturnTrueIfIdOfTheItemIsZero() {
		assertTrue(new AgreementItem().isTransient());
	}

	/**
	 * Should return false if id of the agreement is not zero.
	 */
	@Test
	public void shouldReturnFalseIfIdOfTheAgreementIsNotZero() {
		agreementItem.setId(1233L);
		assertFalse(agreementItem.isTransient());
	}

	/**
	 * Should return true if the serial number of item matches that passed in.
	 */
	@Test
	public void shouldReturnTrueIfTheSerialNumberOfItemMatchesThatPassedIn() {
		agreementItem.setItem(new ItemBuilder().withSerialNumber(1233L).buildItem());

		assertTrue(agreementItem.matches(1233L));
	}

	/**
	 * Should return false if the serial number of item does not match that passed in.
	 */
	@Test
	public void shouldReturnFalseIfTheSerialNumberOfItemDoesNotMatchThatPassedIn() {
		agreementItem.setItem(new ItemBuilder().withSerialNumber(1234L).buildItem());

		assertFalse(agreementItem.matches(1233L));
	}

	/**
	 * Should return the total charge amount as the sum of charge amount and damage waiver fee.
	 */
	@Test
	public void shouldReturnTheTotalChargeAmountAsTheSumOfChargeAmountAndDamageWaiverFee() {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);
		when(chargeInfo.getTotalEstimatedChargeAmount()).thenReturn(new BigDecimal(3.6));

		assertEquals(new BigDecimal(3.6).doubleValue(), agreementItem.getTotalEstimatedChargeAmount().doubleValue(), 0.01);
	}

	/**
	 * Test persis item.
	 */
	@Test
	public void testPersisItem() {
		final Item mockedItem = mock(Item.class);

		final AgreementItem partiallyMockedAgreementItem = spy(new AgreementItem());
		partiallyMockedAgreementItem.setItem(mockedItem);
		partiallyMockedAgreementItem.persistItem();

		verify(mockedItem).persist();
	}

	/**
	 * Should return the same damage info as the original property if the original property is not null.
	 */
	@Test
	public void shouldReturnTheSameDamageInfoAsTheOriginalPropertyIfTheOriginalPropertyIsNotNull() {
		final DamageInfo expectedDamageInfo = new DamageInfo();
		assertSame(expectedDamageInfo, new AgreementItemBuilder().withDamageInfo(expectedDamageInfo).buildAgreementItem()
		        .getNotNullDamageInfo());
	}

	/**
	 * Should create a new damage info instance if the property is set to null.
	 */
	@Test
	public void shouldCreateANewDamageInfoInstanceIfThePropertyIsSetToNull() {
		assertNotNull(new AgreementItem().getNotNullDamageInfo());
	}

	/**
	 * Should set the not null damage info to the parent property.
	 */
	@Test
	public void shouldSetTheNotNullDamageInfoToTheParentProperty() {
		final DamageInfo expectedDamageInfo = new DamageInfo();
		final AgreementItem item = new AgreementItem();

		item.setNotNullDamageInfo(expectedDamageInfo);
		assertSame(expectedDamageInfo, item.getDamageInfo());
	}

	/**
	 * Should not do anything if both the questions and answers are empty.
	 */
	@Test
	public void shouldNotDoAnythingIfBothTheQuestionsAndAnswersAreEmpty() {
		agreementItem = new AgreementItem();
		agreementItem.createEmptyAnswersIfRequired(new ArrayList<Question>());

		assertEquals(0, agreementItem.getAnswerList().size());
	}

	/**
	 * Should not do anything if questions size is same as answer list size.
	 */
	@Test
	public void shouldNotDoAnythingIfQuestionsSizeIsSameAsAnswerListSize() {
		final ChecklistAnswer expectedAnswer = new ChecklistAnswer();
		agreementItem = new AgreementItemBuilder().withChecklistAnswer(expectedAnswer).buildAgreementItem();
		final ArrayList<Question> questions = new ArrayList<Question>();
		questions.add(new Question());

		agreementItem.createEmptyAnswersIfRequired(questions);

		assertEquals(1, agreementItem.getAnswerList().size());
		assertSame(expectedAnswer, agreementItem.getAnswerList().get(0));
	}

	/**
	 * Should create dummy answers for the questions passed in.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCreateDummyAnswersForTheQuestionsPassedIn() throws Exception {
		agreementItem = new AgreementItem();
		final List<Question> questions = new ArrayList<Question>();
		questions.add(new Question());

		final ChecklistAnswerCollection mockedChecklistAnswerCollection = mock(ChecklistAnswerCollection.class);
		whenNew(ChecklistAnswerCollection.class).withArguments(agreementItem.getAnswerList()).thenReturn(mockedChecklistAnswerCollection);

		agreementItem.createEmptyAnswersIfRequired(questions);

		verify(mockedChecklistAnswerCollection).createEmptyAnswers(questions, agreementItem);
	}

	/**
	 * Should add all the answers to the answer list if answer list is empty.
	 */
	@Test
	public void shouldAddAllTheAnswersToTheAnswerListIfAnswerListIsEmpty() {
		final ChecklistAnswer expectedAnswer = new ChecklistAnswer();
		agreementItem = new AgreementItemBuilder().withChecklistAnswer(expectedAnswer).buildAgreementItem();

		assertEquals(1, agreementItem.getAnswerList().size());
		assertSame(expectedAnswer, agreementItem.getAnswerList().get(0));
	}

	/**
	 * Should not add the answers again if already the answer list has values.
	 */
	@Test
	public void shouldNotAddTheAnswersAgainIfAlreadyTheAnswerListHasValues() {
		agreementItem = new AgreementItem();
		final ArrayList<ChecklistAnswer> answerList = new ArrayList<ChecklistAnswer>();

		final ChecklistAnswer expectedAnswer = new ChecklistAnswer();
		answerList.add(expectedAnswer);

		agreementItem.setAnswerList(answerList);

		assertEquals(1, agreementItem.getAnswerList().size());
		assertSame(expectedAnswer, agreementItem.getAnswerList().get(0));
	}

	/**
	 * Should clear any existing answers and copy the new answers from the answers list.
	 */
	@Test
	public void shouldClearAnyExistingAnswersAndCopyTheNewAnswersFromTheAnswersList() {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);

		agreementItem.markToCheckin();

		verify(chargeInfo).markToCheckin();
	}

	/**
	 * Should set the checkin boolean to true after checkin.
	 */
	@Test
	public void shouldSetTheCheckinBooleanToTrueAfterCheckin() {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);

		agreementItem.markToCheckin();
		assertTrue(agreementItem.isCheckedin());
	}

	/**
	 * Should format the rental duration using the simple time period formatter.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldFormatTheRentalDurationUsingTheSimpleTimePeriodFormatter() throws Exception {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		when(chargeInfo.getEstimatedRentalDuration()).thenReturn(0.5);
		agreementItem.setChargeInfo(chargeInfo);

		final SimpleTimePeriodFormatter mockedSimpleTimePeriodFormatter = mock(SimpleTimePeriodFormatter.class);
		whenNew(SimpleTimePeriodFormatter.class).withNoArguments().thenReturn(mockedSimpleTimePeriodFormatter);

		when(mockedSimpleTimePeriodFormatter.format(0.5)).thenReturn("30 Min");

		assertEquals("30 Min", agreementItem.getRentalDurationDisplay());
	}

	/**
	 * Should return the base duration display.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTheBaseDurationDisplay() throws Exception {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);
		when(chargeInfo.getBaseSkuHrQty()).thenReturn(2.75);

		final SimpleTimePeriodFormatter mockedSimpleTimePeriodFormatter = mock(SimpleTimePeriodFormatter.class);
		whenNew(SimpleTimePeriodFormatter.class).withNoArguments().thenReturn(mockedSimpleTimePeriodFormatter);

		when(mockedSimpleTimePeriodFormatter.format(2.75)).thenReturn("2 Hr 45 Min ");

		assertEquals("2 Hr 45 Min ", agreementItem.getBaseDurationDisplay());
	}

	/**
	 * Should return the total additional charge as the sum of all the additional charges.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTheTotalAdditionalChargeAsTheSumOfAllTheAdditionalCharges() throws Exception {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);
		when(chargeInfo.getTotalAdditionalChargeAmount()).thenReturn(new BigDecimal(2.7));
		assertEquals(new BigDecimal("2.7").doubleValue(), agreementItem.getTotalAdditionalChargeAmount().doubleValue(), 0.001);
	}

	/**
	 * Should calculate charge amount based on the actual checkin time stamp.
	 */
	@Test
	public void shouldCalculateChargeAmountBasedOnTheActualCheckinTimeStamp() {
		final Item mockedItem = mock(Item.class);
		agreementItem = spy(agreementItem);
		agreementItem.setItem(mockedItem);
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

		mockStatic(AgreementItemStatus.class);
		final AgreementItemStatus agreementItemStatus = mock(AgreementItemStatus.class);
		when(AgreementItemStatus.findReturned()).thenReturn(agreementItemStatus);

        agreementItem.setAgreement(mock(Agreement.class));
		agreementItem.setCheckoutDate(outDate);
		agreementItem.setCheckinDate(inDate);
		agreementItem.setDamageWaiver(mock(DamageWaiver.class));

		doNothing().when(agreementItem).merge();

		agreementItem.actualCheckin();
	}

	/**
	 * Should calculate rental duration based on the actual checkin time stamp.
	 */
	@Test
	public void shouldCalculateRentalDurationBasedOnTheActualCheckinTimeStamp() {
		final Item mockedItem = mock(Item.class);
		agreementItem = spy(agreementItem);
		agreementItem.setItem(mockedItem);
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

        agreementItem.setAgreement(mock(Agreement.class));
		agreementItem.setCheckoutDate(outDate);
		agreementItem.setCheckinDate(inDate);
		agreementItem.setDamageWaiver(mock(DamageWaiver.class));

		doNothing().when(agreementItem).merge();

		mockStatic(AgreementItemStatus.class);
		final AgreementItemStatus agreementItemStatus = mock(AgreementItemStatus.class);
		when(AgreementItemStatus.findReturned()).thenReturn(agreementItemStatus);

		agreementItem.actualCheckin();
	}

	/**
	 * Should merge the agreement item with the db.
	 */
	@Test
	public void shouldMergeTheAgreementItemWithTheDB() {
		final Item mockedItem = mock(Item.class);
		agreementItem = spy(agreementItem);
		agreementItem.setItem(mockedItem);
		agreementItem.setDamageWaiver(mock(DamageWaiver.class));

		doNothing().when(agreementItem).merge();

		mockStatic(AgreementItemStatus.class);
		final AgreementItemStatus agreementItemStatus = mock(AgreementItemStatus.class);
		when(AgreementItemStatus.findReturned()).thenReturn(agreementItemStatus);

		agreementItem.actualCheckin();

		verify(agreementItem).merge();
	}

	/**
	 * Should update the overrides.
	 */
	@Test
	public void shouldUpdateTheOverrides() {
		agreementItem = spy(agreementItem);
		agreementItem.setItem(mock(Item.class));
		agreementItem.setDamageWaiver(mock(DamageWaiver.class));

		doNothing().when(agreementItem).updateOverrides();
		doNothing().when(agreementItem).merge();

		mockStatic(AgreementItemStatus.class);

		agreementItem.actualCheckin();

		verify(agreementItem).updateOverrides();
	}

	/**
	 * Should delegate the actual checkin call to the item as well.
	 */
	@Test
	public void shouldDelegateTheActualCheckinCallToTheItemAsWell() {
		final Item mockedItem = mock(Item.class);
		agreementItem = spy(agreementItem);
		agreementItem.setItem(mockedItem);
		agreementItem.setDamageWaiver(mock(DamageWaiver.class));

		doNothing().when(agreementItem).merge();

		mockStatic(AgreementItemStatus.class);
		final AgreementItemStatus agreementItemStatus = mock(AgreementItemStatus.class);
		when(AgreementItemStatus.findReturned()).thenReturn(agreementItemStatus);

		agreementItem.actualCheckin();

		verify(mockedItem).actualCheckin();
	}

	/**
	 * Should return false if item has a check in date.
	 */
	@Test
	public void shouldReturnFalseIfItemHasACheckInDate() {
        agreementItem.setAgreement(mock(Agreement.class));
		agreementItem.setCheckinDate(Calendar.getInstance());
		assertFalse(agreementItem.isNotCheckedIn());
	}

	/**
	 * Should return true if item does not have a checkin date.
	 */
	@Test
	public void shouldReturnTrueIfItemDoesNotHaveACheckinDate() {
		assertTrue(agreementItem.isNotCheckedIn());
	}

	/**
	 * Should return true if guest meets the minimum age requirement.
	 */
	@Test
	public void shouldReturnTrueIfGuestMeetsTheMinimumAgeRequirement() {
		final Agreement agreement = new Agreement();
		final Item mockedItem = mock(Item.class);
		when(mockedItem.isDriverAgeGreaterThanMinimumRentalAge(agreement)).thenReturn(true);

		agreementItem.setItem(mockedItem);

		assertTrue(agreementItem.isDriverAgeGreaterThanMinimumRentalAge(agreement));
	}

	/**
	 * Should return false if guest does not meet the minimum age requirement.
	 */
	@Test
	public void shouldReturnFalseIfGuestDoesNotMeetTheMinimumAgeRequirement() {
		final Agreement agreement = new Agreement();
		final Item mockedItem = mock(Item.class);
		when(mockedItem.isDriverAgeGreaterThanMinimumRentalAge(agreement)).thenReturn(false);

		agreementItem.setItem(mockedItem);

		assertFalse(agreementItem.isDriverAgeGreaterThanMinimumRentalAge(agreement));
	}

	/**
	 * Should calculate the damage waiver charge.
	 */
	@Test
	public void shouldCalculateTheDamageWaiverCharge() {
		final ChargeInfo mockedDamageWaiver = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(mockedDamageWaiver);
		
		final Item mockedItem = mock(Item.class);
		final Product mockedProduct = mock(Product.class);
		
		when(mockedItem.getProduct()).thenReturn(mockedProduct);
		when(mockedProduct.getIsDamageWaiverAvailable()).thenReturn(true);
		
	    agreementItem.setItem(mockedItem);
	    
		agreementItem.calculateDamageWaiverCharges();

		verify(mockedDamageWaiver).calculateDamageWaiverCharges();
	}

	/**
	 * Should return new null agreement item override if agreement item override is null.
	 */
	@Test
	public void shouldReturnNewNullAgreementItemOverrideIfAgreementItemOverrideIsNull() {
		agreementItem.setOverride(null);
		assertNotNull(agreementItem.getNotNullOverride());
	}

	/**
	 * Should return same agreement item override if agreement item override is not null.
	 */
	@Test
	public void shouldReturnSameAgreementItemOverrideIfAgreementItemOverrideIsNotNull() {
		final AgreementItemOverride expectedOverride = new AgreementItemOverride();
		agreementItem.setOverride(expectedOverride);
		assertEquals(expectedOverride, agreementItem.getNotNullOverride());
	}

	/**
	 * Should set the value of agreement item override if it was null while getting not null override.
	 */
	@Test
	public void shouldSetTheValueOfAgreementItemOverrideIfItWasNullWhileGettingNotNullOverride() {
		agreementItem.setOverride(null);
		final AgreementItemOverride expectedOverride = agreementItem.getNotNullOverride();

		assertSame(expectedOverride, agreementItem.getOverride());
	}

	/**
	 * Should return agreement item override.
	 */
	@Test
	public void shouldReturnAgreementItemOverride() {
		final AgreementItemOverride expectedOverride = new AgreementItemOverride();
		agreementItem.setNotNullOverride(expectedOverride);
		assertSame(expectedOverride, agreementItem.getOverride());
	}

	/**
	 * Should return true if the item status is returned.
	 */
	@Test
	public void shouldReturnTrueIfTheItemStatusIsReturned() {
		final AgreementItemStatus mockedAgreementItemStatus = mock(AgreementItemStatus.class);
		agreementItem.setStatus(mockedAgreementItemStatus);

		when(mockedAgreementItemStatus.isReturned()).thenReturn(true);

		assertTrue(agreementItem.isReturned());
	}

	/**
	 * Should return true if the item status is returned and paid.
	 */
	@Test
	public void shouldReturnTrueIfTheItemStatusIsReturnedAndPaid() {
		final AgreementItemStatus mockedAgreementItemStatus = mock(AgreementItemStatus.class);
		agreementItem.setStatus(mockedAgreementItemStatus);

		when(mockedAgreementItemStatus.isReturnedAndPaidComplete()).thenReturn(true);

		assertTrue(agreementItem.isReturnedAndPaidComplete());
	}

	/**
	 * Should return false if the item status is not returned and not returned and paid.
	 */
	@Test
	public void shouldReturnFalseIfTheItemStatusIsNotReturnedAndNotReturnedAndPaid() {
		final AgreementItemStatus mockedAgreementItemStatus = mock(AgreementItemStatus.class);
		agreementItem.setStatus(mockedAgreementItemStatus);

		when(mockedAgreementItemStatus.isReturned()).thenReturn(false);
		when(mockedAgreementItemStatus.isReturnedAndPaidComplete()).thenReturn(false);

		assertFalse(agreementItem.isReturned());
	}

	/**
	 * Should get the formatted value for incremental time units.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldGetTheFormattedValueForIncrementalTimeUnits() throws Exception {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);
		final SimpleTimePeriodFormatter mockedSimpleTimePeriodFormatter = mock(SimpleTimePeriodFormatter.class);
		whenNew(SimpleTimePeriodFormatter.class).withNoArguments().thenReturn(mockedSimpleTimePeriodFormatter);

		when(chargeInfo.getActualIncrementalDuration()).thenReturn(7 * 1.25);

		when(mockedSimpleTimePeriodFormatter.format(7 * 1.25)).thenReturn("8hr 45 min");

		assertEquals("8hr 45 min", agreementItem.getActualIncrementalDurationDisplay());
	}

	/**
	 * Should return true if reservation fulfillment is in progress.
	 */
	@Test
	public void shouldReturnTrueIfReservationFulfillmentIsInProgress() {
		agreementItem.setReservationAgainstProduct(new Reservation());
		assertTrue(agreementItem.isReservationBeingFulfilledOrHasReservationOverride());
	}

	/**
	 * Should return false if reservation fulfillment is not in progress.
	 */
	@Test
	public void shouldReturnFalseIfReservationFulfillmentIsNotInProgress() {
		agreementItem.setReservationAgainstProduct(null);
		assertFalse(agreementItem.isReservationBeingFulfilledOrHasReservationOverride());
	}

	/**
	 * Should fulfill reservation if its under process.
	 */
	@Test
	public void shouldFulfillReservationIfItsUnderProcess() {
		final Reservation mockedReservation = mock(Reservation.class);
		agreementItem.setReservationAgainstProduct(mockedReservation);

		agreementItem.fulfillReservation();

		verify(mockedReservation).fulfill();
	}

	/**
	 * Should not do anything if reservation is not under process.
	 */
	@Test
	public void shouldNotDoAnythingIfReservationIsNotUnderProcess() {
		agreementItem.fulfillReservation();
	}

	/**
	 * Should copy the charge info.
	 */
	@Test
	public void shouldCopyTheChargeInfo() {
		final Item mockedItem = mock(Item.class);
		agreementItem.setItem(mockedItem);

		final ChargeInfo expectedChargeInfo = new ChargeInfo();
		when(mockedItem.createChargeInfo()).thenReturn(expectedChargeInfo);

		agreementItem.copyChargeInfo();

		assertSame(expectedChargeInfo, agreementItem.getChargeInfo());
	}

	/**
	 * Should return true if agreement item is returned and paid.
	 */
	@Test
	public void shouldReturnTrueIfAgreementItemIsReturnedAndPaid() {
		final AgreementItemStatus itemStatus = mock(AgreementItemStatus.class);
		when(itemStatus.isReturnedAndPaidComplete()).thenReturn(true);
		agreementItem.setStatus(itemStatus);

		assertTrue(agreementItem.isReturnedAndPaidComplete());
	}

	/**
	 * Should return false if agreement item is not returned and paid.
	 */
	@Test
	public void shouldReturnFalseIfAgreementItemIsNotReturnedAndPaid() {
		final AgreementItemStatus itemStatus = mock(AgreementItemStatus.class);
		when(itemStatus.isReturnedAndPaidComplete()).thenReturn(false);
		agreementItem.setStatus(itemStatus);

		assertFalse(agreementItem.isReturnedAndPaidComplete());
	}

	/**
	 * Should return true if agreement item is checked out.
	 */
	@Test
	public void shouldReturnTrueIfAgreementItemIsCheckedOut() {
		final AgreementItemStatus itemStatus = mock(AgreementItemStatus.class);
		when(itemStatus.isCheckedOut()).thenReturn(true);
		agreementItem.setStatus(itemStatus);

		assertTrue(agreementItem.isCheckedOut());
	}

	/**
	 * Should return false if agreement item is not checkedout.
	 */
	@Test
	public void shouldReturnFalseIfAgreementItemIsNotCheckedout() {
		final AgreementItemStatus itemStatus = mock(AgreementItemStatus.class);
		when(itemStatus.isCheckedOut()).thenReturn(false);
		agreementItem.setStatus(itemStatus);

		assertFalse(agreementItem.isCheckedOut());
	}

	/**
	 * Should return true if agreement is voided.
	 */
	@Test
	public void shouldReturnTrueIfAgreementIsVoided() {
		final Agreement agreement = mock(Agreement.class);
		when(agreement.isVoided()).thenReturn(true);
		agreementItem.setAgreement(agreement);

		assertTrue(agreementItem.isAgreementVoided());
	}

	/**
	 * Should return false if agreement is not voided.
	 */
	@Test
	public void shouldReturnFalseIfAgreementIsNotVoided() {
		final Agreement agreement = mock(Agreement.class);
		when(agreement.isVoided()).thenReturn(false);
		agreementItem.setAgreement(agreement);

		assertFalse(agreementItem.isAgreementVoided());
	}

	/**
	 * Should return estimated charge amout without surcharge.
	 */
	@Test
	public void shouldReturnEstimatedChargeAmoutWithoutSurcharge() {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);
		final BigDecimal estimatedChargeAmountWithoutSurcharge = new BigDecimal("2.7");
		when(chargeInfo.getEstimatedChargeAmountWithoutSurcharge()).thenReturn(estimatedChargeAmountWithoutSurcharge);

		assertSame(estimatedChargeAmountWithoutSurcharge, agreementItem.getEstimatedChargeAmountWithoutSurcharge());
	}

	/**
	 * Should return estimated incremental time units.
	 */
	@Test
	public void shouldReturnEstimatedIncrementalTimeUnits() {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);
		when(chargeInfo.getIncrementalTimeUnits()).thenReturn(108);

		assertSame(108, agreementItem.getEstimatedIncrementalTimeUnits());
	}

	/**
	 * Should do quantity override when someone tries to set the actual incremental time units.
	 */
	@Test
	public void shouldDoQuantityOverrideWhenSomeoneTriesToSetTheActualIncrementalTimeUnits() {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);

		agreementItem.setOverrideIncrementalTimeUnits(1233);

		verify(chargeInfo).doQuantityOverride(1233);
	}

	/**
	 * Should do price override when someone sets the estimated charge amount.
	 */
	@Test
	public void shouldDoPriceOverrideWhenSomeoneSetsTheEstimatedChargeAmount() {
		final ChargeInfo chargeInfo = mock(ChargeInfo.class);
		agreementItem.setChargeInfo(chargeInfo);

		final BigDecimal estimatedChargeAmountWithoutSurcharge = new BigDecimal("1233.7866");
		agreementItem.setEstimatedChargeAmountWithoutSurcharge(estimatedChargeAmountWithoutSurcharge);

		verify(chargeInfo).doPriceOverride(estimatedChargeAmountWithoutSurcharge);
	}

	/**
	 * Should return the agreement item that is current in checked out and paid state and has the given item.
	 */
	@Test
	public void shouldReturnTheAgreementItemThatIsCurrentInCheckedOutAndPaidStateAndHasTheGivenItem() {
		final Query query = mock(Query.class);
		stub(method(AgreementItem.class, "findAgreementItemsByStatusAndItem", AgreementItemStatus.class, Item.class))
		        .andReturn(query);

		final AgreementItemStatus status = new AgreementItemStatus();
		mockStatic(AgreementItemStatus.class);
		when(AgreementItemStatus.findCheckedOutAndPaidInitial()).thenReturn(status);

		final List<AgreementItem> itemArrayList = new ArrayList<AgreementItem>();
		final AgreementItem expectedAgreementItem = new AgreementItem();
		itemArrayList.add(expectedAgreementItem);
		when(query.getResultList()).thenReturn(itemArrayList);

		assertSame(expectedAgreementItem, AgreementItem.findCheckedOutAndPaidAgreementItemFor(new Item()));
	}

	/**
	 * Should return null no agreement item was found.
	 */
	@Test
	public void shouldReturnNullNoAgreementItemWasFound() {
		final Query query = mock(Query.class);
		stub(method(AgreementItem.class, "findAgreementItemsByStatusAndItem", AgreementItemStatus.class, Item.class))
		        .andReturn(query);

		final AgreementItemStatus status = new AgreementItemStatus();
		mockStatic(AgreementItemStatus.class);
		when(AgreementItemStatus.findCheckedOutAndPaidInitial()).thenReturn(status);

		final List<AgreementItem> itemArrayList = new ArrayList<AgreementItem>();
		when(query.getResultList()).thenReturn(itemArrayList);

		assertNull(AgreementItem.findCheckedOutAndPaidAgreementItemFor(new Item()));
	}
    
    @Test
    public void shouldReturnFalseIfIsCheckedinIsFalse() {
        assertFalse(agreementItem.isCheckedin());
    }

    @Test
    public void shouldReturnFalseIfIsCheckedinIsTrueButChecklistQuestionsHaveBeenAnswered() {
        agreementItem.setCheckedin(true);
        final List<ChecklistAnswer> answerList = new ArrayList<ChecklistAnswer>();
        answerList.add(new ChecklistAnswer());

        agreementItem.setAnswerList(answerList);

        assertFalse(agreementItem.isToBeCheckedin());
    }

    @Test
    public void shouldReturnTrueIfIsCheckedinIsTrueButChecklistQuestionsHaveBeenAnswered() {
        agreementItem.setCheckedin(true);
        final List<ChecklistAnswer> answerList = new ArrayList<ChecklistAnswer>();

        agreementItem.setAnswerList(answerList);

        assertTrue(agreementItem.isToBeCheckedin());
    }

    @Test
    public void shouldParseTheDoulbeValueWithCommas() throws ParseException {
        NumberFormat.getInstance().parse("10,000");
    }
    
    @Test
    public void shouldUpdateTheCheckoutDate() {
        final Calendar transactionDate = Calendar.getInstance();
        agreementItem.setItem(mock(Item.class));
        agreementItem.updateCheckoutDate(transactionDate);

        assertSame(transactionDate, agreementItem.getCheckoutDate());
    }

    @Test
    public void shouldUpdateTheLastRentedDateForTheItem() {
        final Calendar transactionDate = Calendar.getInstance();
        final Item item = mock(Item.class);
        agreementItem.setItem(item);
        agreementItem.updateCheckoutDate(transactionDate);

        verify(item).setLastRentedDate(transactionDate);
    }

    @Test
    public void shouldCopyTheBaseChargeAmountFromKioskDetails() {
        final KioskProductDetail kioskProductDetail = mock(KioskProductDetail.class);
        final BigDecimal expectedPriceAmount = new BigDecimal(14.4);
        when(kioskProductDetail.getBaseSKUChargeAmount()).thenReturn(expectedPriceAmount);

        agreementItem.copyPriceFrom(kioskProductDetail);

        assertSame(expectedPriceAmount, agreementItem.getBasePriceAmount());
    }

    @Test
    public void shouldCopyTheIncrementalChargeAmountFromKioskDetails() {
        final KioskProductDetail kioskProductDetail = mock(KioskProductDetail.class);
        final BigDecimal expectedPriceAmount = new BigDecimal(14.4);
        when(kioskProductDetail.getIncrementalSKUChargeAmount()).thenReturn(expectedPriceAmount);

        agreementItem.copyPriceFrom(kioskProductDetail);

        assertSame(expectedPriceAmount, agreementItem.getIncrementalPriceAmount());
    }

    @Test
    public void shouldCopyTheSurchargeChargeAmountFromKioskDetails() {
        final KioskProductDetail kioskProductDetail = mock(KioskProductDetail.class);
        final BigDecimal expectedPriceAmount = new BigDecimal(14.4);
        when(kioskProductDetail.getSurchargeSKUChargeAmount()).thenReturn(expectedPriceAmount);

        agreementItem.copyPriceFrom(kioskProductDetail);

        assertSame(expectedPriceAmount, agreementItem.getSurchargePriceAmount());
    }
}
