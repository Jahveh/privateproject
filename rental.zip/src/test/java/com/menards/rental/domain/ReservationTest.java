/*
 * ReservationTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.*;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.*;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.builder.ReservationBuilder;

import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 * Created by IntelliJ IDEA. User: deep Date: 8 Jul, 2010 Time: 1:59:22 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest({ReservationStatus.class, Reservation.class })
public class ReservationTest {
	
	/** The reservation. */
	private Reservation reservation;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		reservation = new Reservation();
	}

	/**
	 * Should return false if store numbers dont match.
	 */
	@Test
	public void shouldReturnFalseIfStoreNumbersDontMatch() {
		assertFalse(new ReservationBuilder().withAgreement(getMockedReservationAgreement(7866, false)).buildReservation()
		        .isForStore(7866));
	}

	/**
	 * Should return true if reservations for the same store.
	 */
	@Test
	public void shouldReturnTrueIfReservationsForTheSameStore() {
		assertTrue(new ReservationBuilder().withAgreement(getMockedReservationAgreement(7866, true)).buildReservation()
		        .isForStore(7866));
	}

	/**
	 * Should return false if reservation is not for current store.
	 */
	@Test
	public void shouldReturnFalseIfReservationIsNotForCurrentStore() {
		assertFalse(new ReservationBuilder().withAgreement(getMockedReservationAgreement(7866, false)).buildReservation()
		        .isOverlappingForStore(7866, null, null));
	}

	/**
	 * Should return false if both in date and out date are lesser than reservation checkout and checkin date.
	 */
	@Test
	public void shouldReturnFalseIfBothInDateAndOutDateAreLesserThanReservationCheckoutAndCheckinDate() {
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();
		outDate.add(Calendar.HOUR, 1);
		inDate.add(Calendar.HOUR, 2);

		reservation = new ReservationBuilder().withAgreement(getMockedReservationAgreement(1233, true))
		        .withCheckoutTimeStamp(outDate).withCheckinTimeStamp(inDate).buildReservation();

		assertFalse(reservation.isOverlappingForStore(1233, Calendar.getInstance(), Calendar.getInstance()));
	}

	/**
	 * Should return false if both in date and out date are greater than reservation checkout and checkin date.
	 */
	@Test
	public void shouldReturnFalseIfBothInDateAndOutDateAreGreaterThanReservationCheckoutAndCheckinDate() {
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();
		outDate.add(Calendar.HOUR, -1);
		inDate.add(Calendar.HOUR, -2);

		reservation = new ReservationBuilder().withAgreement(getMockedReservationAgreement(1233, true))
		        .withCheckoutTimeStamp(outDate).withCheckinTimeStamp(inDate).buildReservation();

		assertFalse(reservation.isOverlappingForStore(1233, Calendar.getInstance(), Calendar.getInstance()));
	}

	/**
	 * Should return true in all other cases.
	 */
	@Test
	public void shouldReturnTrueInAllOtherCases() {
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();
		outDate.add(Calendar.HOUR, -1);
		inDate.add(Calendar.HOUR, 2);

		reservation = new ReservationBuilder().withAgreement(getMockedReservationAgreement(1233, true))
		        .withCheckoutTimeStamp(outDate).withCheckinTimeStamp(inDate).buildReservation();

		assertTrue(reservation.isOverlappingForStore(1233, Calendar.getInstance(), Calendar.getInstance()));
	}

	/**
	 * Should return false if the other reservation is not for current store.
	 */
	@Test
	public void shouldReturnFalseIfTheOtherReservationIsNotForCurrentStore() {
		final ReservationAgreement mockedOtherAgreement = mock(ReservationAgreement.class);
		when(mockedOtherAgreement.getStoreNumber()).thenReturn(7866);
		assertFalse(new ReservationBuilder().withAgreement(getMockedReservationAgreement(7866, false)).buildReservation()
		        .isOverlapping(new ReservationBuilder().withAgreement(mockedOtherAgreement).buildReservation()));
	}

	/**
	 * Should return false if other reservations in date and out date are lesser than reservation checkout and checkin date.
	 */
	@Test
	public void shouldReturnFalseIfOtherReservationsInDateAndOutDateAreLesserThanReservationCheckoutAndCheckinDate() {
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();
		outDate.add(Calendar.HOUR, 1);
		inDate.add(Calendar.HOUR, 2);

		final ReservationAgreement mockedOtherAgreement = mock(ReservationAgreement.class);
		when(mockedOtherAgreement.getStoreNumber()).thenReturn(1233);

		reservation = new ReservationBuilder().withAgreement(getMockedReservationAgreement(1233, true))
		        .withCheckoutTimeStamp(outDate).withCheckinTimeStamp(inDate).buildReservation();

		assertFalse(reservation.isOverlapping(new ReservationBuilder().withAgreement(mockedOtherAgreement)
		        .withCheckoutTimeStamp(Calendar.getInstance()).withCheckinTimeStamp(Calendar.getInstance())
		        .buildReservation()));
	}

	/**
	 * Should return false if other reservations in date and out date are greater than reservation checkout and checkin date.
	 */
	@Test
	public void shouldReturnFalseIfOtherReservationsInDateAndOutDateAreGreaterThanReservationCheckoutAndCheckinDate() {
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();
		outDate.add(Calendar.HOUR, -1);
		inDate.add(Calendar.HOUR, -2);

		final ReservationAgreement mockedOtherAgreement = mock(ReservationAgreement.class);
		when(mockedOtherAgreement.getStoreNumber()).thenReturn(1233);

		reservation = new ReservationBuilder().withAgreement(getMockedReservationAgreement(1233, true))
		        .withCheckoutTimeStamp(outDate).withCheckinTimeStamp(inDate).buildReservation();

		assertFalse(reservation.isOverlapping(new ReservationBuilder().withAgreement(mockedOtherAgreement)
		        .withCheckoutTimeStamp(Calendar.getInstance()).withCheckinTimeStamp(Calendar.getInstance())
		        .buildReservation()));
	}

	/**
	 * Should return true if other reservation is overlapping.
	 */
	@Test
	public void shouldReturnTrueIfOtherReservationIsOverlapping() {
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();
		outDate.add(Calendar.HOUR, -1);
		inDate.add(Calendar.HOUR, 2);

		final ReservationAgreement mockedOtherAgreement = mock(ReservationAgreement.class);
		when(mockedOtherAgreement.getStoreNumber()).thenReturn(1233);

		reservation = new ReservationBuilder().withAgreement(getMockedReservationAgreement(1233, true))
		        .withCheckoutTimeStamp(outDate).withCheckinTimeStamp(inDate).buildReservation();

		assertTrue(reservation.isOverlapping(new ReservationBuilder().withAgreement(mockedOtherAgreement)
		        .withCheckoutTimeStamp(Calendar.getInstance()).withCheckinTimeStamp(Calendar.getInstance())
		        .buildReservation()));
	}

	/**
	 * Should return true if reservation status is open.
	 */
	@Test
	public void shouldReturnTrueIfReservationStatusIsOpen() {
		final ReservationStatus mockedStatus = mock(ReservationStatus.class);
		when(mockedStatus.isOpen()).thenReturn(true);
		assertTrue(new ReservationBuilder().withStatus(mockedStatus).buildReservation().isOpen());
	}

	/**
	 * Should return false if reservation status is not open.
	 */
	@Test
	public void shouldReturnFalseIfReservationStatusIsNotOpen() {
		final ReservationStatus mockedStatus = mock(ReservationStatus.class);
		when(mockedStatus.isOpen()).thenReturn(false);
		assertFalse(new ReservationBuilder().withStatus(mockedStatus).buildReservation().isOpen());
	}

	/**
	 * Should get empty string if checkout time stamp is null.
	 */
	@Test
	public void shouldGetEmptyStringIfCheckoutTimeStampIsNull() {
		assertEquals("", reservation.getFormattedCheckOutTime());
	}

	/**
	 * Should get empty string if checkin time stamp is null.
	 */
	@Test
	public void shouldGetEmptyStringIfCheckinTimeStampIsNull() {
		assertEquals("", reservation.getFormattedCheckInTime());
	}

	/**
	 * Should get formatted string if checkout time stamp is not null.
	 */
	@Test
	public void shouldGetFormattedStringIfCheckoutTimeStampIsNotNull() {
		final Calendar outTimeStamp = Calendar.getInstance();
		reservation.setCheckOutTimeStamp(outTimeStamp);
		assertEquals(new SimpleDateFormat("MM/dd/yyyy hh:mm aa").format(outTimeStamp.getTime()), reservation
		        .getFormattedCheckOutTime());
	}

	/**
	 * Should get formatted string if checkin time stamp is not null.
	 */
	@Test
	public void shouldGetFormattedStringIfCheckinTimeStampIsNotNull() {
		final Calendar inTimeStamp = Calendar.getInstance();
		reservation.setCheckInTimeStamp(inTimeStamp);
		assertEquals(new SimpleDateFormat("MM/dd/yyyy hh:mm aa").format(inTimeStamp.getTime()), reservation
		        .getFormattedCheckInTime());
	}

    /**
	 * Should return the rental sku.
	 */
	@Test
	public void shouldReturnTheRentalSKU() {
		final Product mockedProduct = mock(Product.class);
		when(mockedProduct.getFormattedBaseSKU()).thenReturn("Hello-Base");
		reservation.setProduct(mockedProduct);
		assertEquals("Hello-Base", reservation.getRentalSKU());
	}

	/**
	 * Should return the surcharge sku.
	 */
	@Test
	public void shouldReturnTheSurchargeSKU() {
		final Product mockedProduct = mock(Product.class);
		when(mockedProduct.getFormattedSurchargeSKU()).thenReturn("Hello-Surcharge");
		reservation.setProduct(mockedProduct);
		assertEquals("Hello-Surcharge", reservation.getSurchargeSKU());
	}

	/**
	 * Should return the formatted name.
	 */
	@Test
	public void shouldReturnTheFormattedName() {
		final Product mockedProduct = mock(Product.class);
		when(mockedProduct.getDescriptionEscaped()).thenReturn("Hello-Name");
		reservation.setProduct(mockedProduct);
		assertEquals("Hello-Name", reservation.getDescription());
	}

	/**
	 * Should return the formatted rental duration.
	 */
	@Test
	public void shouldReturnTheFormattedRentalDuration() {
        reservation.setEstimatedRentalDuration(2.75);
		assertEquals("2 Hr 45 Min.", reservation.getRentalDurationDisplay().trim());
	}

	/**
	 * Should return true if product id matches.
	 */
	@Test
	public void shouldReturnTrueIfProductIdMatches() {
		final Product mockedProduct = mock(Product.class);
		when(mockedProduct.isIdMatching(1233L)).thenReturn(true);
		reservation.setProduct(mockedProduct);

		assertTrue(reservation.isForProduct(1233));
	}

	/**
	 * Should return false if product id does not matches.
	 */
	@Test
	public void shouldReturnFalseIfProductIdDoesNotMatches() {
		final Product mockedProduct = mock(Product.class);
		when(mockedProduct.isIdMatching(1233L)).thenReturn(false);
		reservation.setProduct(mockedProduct);

		assertFalse(reservation.isForProduct(1233));
	}

	/**
	 * Should return true if reservation is fulfilled.
	 */
	@Test
	public void shouldReturnTrueIfReservationIsFulfilled() {
		final ReservationStatus mockedStatus = mock(ReservationStatus.class);
		when(mockedStatus.isFulfilled()).thenReturn(true);
		assertTrue(new ReservationBuilder().withStatus(mockedStatus).buildReservation().isFulfilled());
	}

	/**
	 * Should return flase if reservation is not fulfilled.
	 */
	@Test
	public void shouldReturnFlaseIfReservationIsNotFulfilled() {
		final ReservationStatus mockedStatus = mock(ReservationStatus.class);
		when(mockedStatus.isFulfilled()).thenReturn(false);
		assertFalse(new ReservationBuilder().withStatus(mockedStatus).buildReservation().isFulfilled());
	}

	/**
	 * Should return true if reservation is cancelled.
	 */
	@Test
	public void shouldReturnTrueIfReservationIsCancelled() {
		final ReservationStatus mockedStatus = mock(ReservationStatus.class);
		when(mockedStatus.isCancelled()).thenReturn(true);
		assertTrue(new ReservationBuilder().withStatus(mockedStatus).buildReservation().isCancelled());
	}

	/**
	 * Should return flase if reservation is not cancelled.
	 */
	@Test
	public void shouldReturnFlaseIfReservationIsNotCancelled() {
		final ReservationStatus mockedStatus = mock(ReservationStatus.class);
		when(mockedStatus.isCancelled()).thenReturn(false);
		assertFalse(new ReservationBuilder().withStatus(mockedStatus).buildReservation().isCancelled());
	}

	/**
	 * Should copy expected checkin date.
	 */
	@Test
	public void shouldCopyExpectedCheckinDate() {
		final Calendar inDate = Calendar.getInstance();
		reservation = new ReservationBuilder().withCheckinTimeStamp(inDate).buildReservation();

		final AgreementItem agreementItem = new AgreementItem();
		reservation.prepareAgreementItem(agreementItem);

		assertSame(inDate, agreementItem.getDueBy());
	}

	/**
	 * Should set the flag that the reservation fulfillment is underway.
	 */
	@Test
	public void shouldSetTheFlagThatTheReservationFulfillmentIsUnderway() {
		reservation = new ReservationBuilder().buildReservation();

		final AgreementItem agreementItem = new AgreementItem();
		reservation.prepareAgreementItem(agreementItem);

		assertTrue(agreementItem.isReservationFulfillInProgress());
	}

	/**
	 * Should start processing of the reservation.
	 */
	@Test
	public void shouldStartProcessingOfTheReservation() {
		reservation.startProcessing();
		assertTrue(reservation.isInProcess());
	}

	/**
	 * Should return true if product match the product in the agreement item.
	 */
	@Test
	public void shouldReturnTrueIfProductMatchTheProductInTheAgreementItem() {
		final Product mockedProduct = mock(Product.class);
		reservation.setProduct(mockedProduct);
		when(mockedProduct.isIdMatching(7866L)).thenReturn(true);
		final AgreementItem agreementItem = mock(AgreementItem.class);
		when(agreementItem.getProductId()).thenReturn(7866L);
		assertTrue(reservation.isForSameProduct(agreementItem));
	}

	/**
	 * Should return false if product do not match the product in the agreement item.
	 */
	@Test
	public void shouldReturnFalseIfProductDoNotMatchTheProductInTheAgreementItem() {
		final Product mockedProduct = mock(Product.class);
		reservation.setProduct(mockedProduct);
		when(mockedProduct.isIdMatching(7866L)).thenReturn(false);
		final AgreementItem agreementItem = mock(AgreementItem.class);
		when(agreementItem.getProductId()).thenReturn(7866L);
		assertFalse(reservation.isForSameProduct(agreementItem));
	}

	/**
	 * Should find the fulfill reservation status and update the status.
	 */
	@Test
	public void shouldFindTheFulfillReservationStatusAndUpdateTheStatus() {
		final ReservationStatus reservationStatus = new ReservationStatus();
		mockStatic(ReservationStatus.class);
		when(ReservationStatus.findFulfilled()).thenReturn(reservationStatus);

		reservation.fulfill();
		assertSame(reservationStatus, reservation.getStatus());
	}

    @Test
    public void shouldCalculateEstimagedChargesAndDuration() throws Exception {
        final Product product = mock(Product.class);
        when(product.getIsDamageWaiverAvailable()).thenReturn(true);
        reservation.setProduct(product);

        final Calendar checkOutTimeStamp = Calendar.getInstance();
        final Calendar checkInTimeStamp = Calendar.getInstance();
        checkInTimeStamp.add(Calendar.HOUR, 4);
        checkInTimeStamp.add(Calendar.MINUTE, 59);

        reservation.setCheckOutTimeStamp(checkOutTimeStamp);
        reservation.setCheckInTimeStamp(checkInTimeStamp);
        reservation.setBasePriceAmount(new BigDecimal(2));
        reservation.setIncrementalPriceAmount(new BigDecimal(1));
        reservation.setSurchargePriceAmount(new BigDecimal(2.7));
        reservation.setBaseSkuHrQty(4.0);
        reservation.setIncrementalSkuHrQty(1.0);

        final ChargeCalculator calculator = mock(ChargeCalculator.class);
        whenNew(ChargeCalculator.class).withArguments(reservation.getBasePriceAmount(),
                reservation.getIncrementalPriceAmount(),
                reservation.getBaseSkuHrQty(), reservation.getIncrementalSkuHrQty(),
                reservation.getCheckOutTimeStamp(), reservation.getCheckInTimeStamp()).thenReturn(calculator);

        when(calculator.getChargeAmount()).thenReturn(new BigDecimal(3));
        when(calculator.getRentalDuration()).thenReturn(5.0);

        reservation.calculateEstimatedChargesAndDuration();

        verify(calculator).calculate();

        assertEquals(3, reservation.getEstimatedChargeAmount().doubleValue(), 0.001);
        assertEquals(5, reservation.getEstimatedRentalDuration(), 0.001);
        assertEquals(0.3, reservation.getEstimatedDamageWaiver().doubleValue(), 0.001);
        assertEquals(2.7, reservation.getEstimatedSurchargePriceAmount().doubleValue(), 0.001);
    }

    @Test
    public void shouldSetTheDamageWaiverValueOnlyIfDamageWaiverIsAvailable() throws Exception {
        final Product product = mock(Product.class);
        when(product.getIsDamageWaiverAvailable()).thenReturn(false);
        reservation.setProduct(product);

        final Calendar checkOutTimeStamp = Calendar.getInstance();
        final Calendar checkInTimeStamp = Calendar.getInstance();
        checkInTimeStamp.add(Calendar.HOUR, 4);
        checkInTimeStamp.add(Calendar.MINUTE, 59);

        reservation.setCheckOutTimeStamp(checkOutTimeStamp);
        reservation.setCheckInTimeStamp(checkInTimeStamp);
        reservation.setBasePriceAmount(new BigDecimal(2));
        reservation.setIncrementalPriceAmount(new BigDecimal(1));
        reservation.setBaseSkuHrQty(4.0);
        reservation.setIncrementalSkuHrQty(1.0);

        final ChargeCalculator calculator = mock(ChargeCalculator.class);
        whenNew(ChargeCalculator.class).withArguments(reservation.getBasePriceAmount(),
                reservation.getIncrementalPriceAmount(),
                reservation.getBaseSkuHrQty(), reservation.getIncrementalSkuHrQty(),
                reservation.getCheckOutTimeStamp(), reservation.getCheckInTimeStamp()).thenReturn(calculator);

        when(calculator.getChargeAmount()).thenReturn(new BigDecimal(3));
        when(calculator.getRentalDuration()).thenReturn(5.0);

        reservation.calculateEstimatedChargesAndDuration();

        verify(calculator).calculate();

        assertEquals(0.0, reservation.getEstimatedDamageWaiver().doubleValue(), 0.001);
    }

    @Test
    public void shouldGetTheTotalEstimatedChargeAmountPlusSurchargeAmount() {
        reservation.setEstimatedChargeAmount(new BigDecimal("2.7"));
        reservation.setEstimatedSurchargePriceAmount(new BigDecimal("0.9"));

        assertEquals(3.6, reservation.getTotalEstimatedChargeAmountPlusSurchargeAmount().doubleValue(), 0.001);
    }

    @Test
    public void shouldGetTheTotalEstimatedChargeAmountPlusSurchargeAmountEvenIfSurChargeIsNull() {
        reservation.setEstimatedChargeAmount(new BigDecimal("2.7"));

        assertEquals(2.7, reservation.getTotalEstimatedChargeAmountPlusSurchargeAmount().doubleValue(), 0.001);        
    }

    @Test
    public void shouldCopyAllTheValuesFromProduct() {
        final Product product = mock(Product.class);
        when(product.getBaseSkuHrQty()).thenReturn(4.0);
        when(product.getIncrementalSkuHrQty()).thenReturn(5.0);
        when(product.isSurchargeSKUSetup()).thenReturn(true);
        reservation.setProduct(product);

        reservation.copyChargeInfo();

        assertEquals(4.0, reservation.getBaseSkuHrQty(), 0.001);
        assertEquals(5.0, reservation.getIncrementalSkuHrQty(), 0.001);
    }

    @Test
    public void shouldCopyAllTheValuesFromKioskProduct() {
        final KioskProductDetail product = mock(KioskProductDetail.class);
        when(product.getBaseSKUChargeAmount()).thenReturn(new BigDecimal(1));
        when(product.getIncrementalSKUChargeAmount()).thenReturn(new BigDecimal(2));
        when(product.getSurchargeSKUChargeAmount()).thenReturn(new BigDecimal(3));

        reservation.copyPriceFrom(product);

        assertEquals(1, reservation.getBasePriceAmount().doubleValue(), 0.001);
        assertEquals(2, reservation.getIncrementalPriceAmount().doubleValue(), 0.001);
        assertEquals(3, reservation.getSurchargePriceAmount().doubleValue(), 0.001);
    }
    
    @Test
    public void shouldFindAllOpenReservationsWhithCheckoutTimeEarlierThanTheThreshold() {
        final EntityManager entityManager = mock(EntityManager.class);
        stub(method(Reservation.class, "entityManager", null)).andReturn(entityManager);
        final Query query = mock(Query.class);
        when(entityManager.createQuery("select r from Reservation r " +
                "where r.status = :openStatus and r.checkOutTimeStamp < :threshold")).thenReturn(query);
        final ReservationStatus reservationStatus = new ReservationStatus();
        mockStatic(ReservationStatus.class);
        when(ReservationStatus.findOpen()).thenReturn(reservationStatus);
        when(query.setParameter("openStatus", reservationStatus)).thenReturn(query);
        final Calendar threshold = Calendar.getInstance();
        when(query.setParameter("threshold", threshold)).thenReturn(query);
        final ArrayList<Reservation> reservations = new ArrayList<Reservation>();

        when(query.getResultList()).thenReturn(reservations);

        assertSame(reservations, Reservation.findAllOpenReservationsThatAreOlderThan(threshold));
    }

    @Test
    public void shouldReturnTrueIfGuestMeetsTheAgeLimit() {
        final Product product = mock(Product.class);
        reservation.setProduct(product);

        final Guest guest = new Guest();
        when(product.isGuestAgeGreaterThanMinimumAge(guest)).thenReturn(true);
        assertTrue(reservation.isGuestAgeGreaterThanMinimumAge(guest));
    }

    @Test
    public void shouldReturnFalseIfGuestDoesNotMeetTheAgeLimit() {
        final Product product = mock(Product.class);
        reservation.setProduct(product);

        final Guest guest = new Guest();
        when(product.isGuestAgeGreaterThanMinimumAge(guest)).thenReturn(false);
        assertFalse(reservation.isGuestAgeGreaterThanMinimumAge(guest));
    }

	/**
	 * Gets the mocked reservation agreement.
	 *
	 * @param storeNumber the store number
	 * @param returnValue the return value
	 * @return the mocked reservation agreement
	 */
	private ReservationAgreement getMockedReservationAgreement(final Integer storeNumber, final boolean returnValue) {
		final ReservationAgreement mockedAgreement = mock(ReservationAgreement.class);
		when(mockedAgreement.isForStore(storeNumber)).thenReturn(returnValue);
		return mockedAgreement;
	}
}
