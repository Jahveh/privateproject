/*
 * AddressTest.java
 */
package com.menards.rental.domain;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * The Class AddressTest.
 *
 * @author geoff
 * @since Jun 4, 2010
 */
public class AddressTest {

	/**
	 * Should format city state zip.
	 */
	@Test
	public void shouldFormatCityStateZip() {
		final Address a = new Address();
		a.setCity("Milwaukee");
		a.setState("WI");
		a.setZipCode("53212");
		assertEquals("Milwaukee, WI 53212", a.getCityStateZip());
	}
}
