/*
 * ChargeInfoTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.whenNew;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.builder.ChargeInfoBuilder;
import com.menards.rental.domain.rule.IncrementalHoursCalculationRuleComposite;

/**
 * Created by IntelliJ IDEA. User: deep Date: 2 Aug, 2010 Time: 2:09:34 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest({ChargeCalculator.class, ChargeInfo.class})
public class ChargeInfoTest {
	
	/** The charge info. */
	private ChargeInfo chargeInfo;
	
	/** The checked out date. */
	private Calendar checkedOutDate;
	
	/** The due date. */
	private Calendar dueDate;
	
	/** The check in date. */
	private Calendar checkInDate;
	
	/** The mocked damage waiver. */
	private DamageWaiver mockedDamageWaiver;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		checkedOutDate = Calendar.getInstance();
		dueDate = Calendar.getInstance();
		checkInDate = Calendar.getInstance();

		mockedDamageWaiver = mock(DamageWaiver.class);
		chargeInfo = new ChargeInfoBuilder().withCheckoutDate(checkedOutDate).withDueBy(dueDate)
		        .withCheckinDate(checkInDate).withBasePriceAmount(10.8).withIncrementalPriceAmount(5.4)
		        .withBaseSkuHrQty(1.5).withIncrementalSkuHrQty(0.5).withDamageWaiver(mockedDamageWaiver).buildChargeInfo();
	}

	/**
	 * Should calculate the base charge amount.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCalculateTheBaseChargeAmount() throws Exception {
		final IncrementalHoursCalculationRuleComposite calculationRules = mock(IncrementalHoursCalculationRuleComposite.class);

		final StoreHourBasedRentalDateRange mockedDateRange = mock(StoreHourBasedRentalDateRange.class);

		whenNew(StoreHourBasedRentalDateRange.class).withArguments(checkedOutDate, dueDate).thenReturn(mockedDateRange);

		whenNew(IncrementalHoursCalculationRuleComposite.class).withArguments(1.5, 0.5, mockedDateRange)
		        .thenReturn(calculationRules);

		when(calculationRules.calculate()).thenReturn(5.0);

		chargeInfo.calculateEstimatedChargesAndDuration();

		assertEquals(10.8, chargeInfo.getBaseChargeAmount().doubleValue(), 0.001);
	}

	/**
	 * Should calculate the incremental amount.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCalculateTheIncrementalAmount() throws Exception {
		final IncrementalHoursCalculationRuleComposite calculationRules = mock(IncrementalHoursCalculationRuleComposite.class);

		final StoreHourBasedRentalDateRange mockedDateRange = mock(StoreHourBasedRentalDateRange.class);

		whenNew(StoreHourBasedRentalDateRange.class).withArguments(checkedOutDate, dueDate).thenReturn(mockedDateRange);

		whenNew(IncrementalHoursCalculationRuleComposite.class).withArguments(1.5, 0.5, mockedDateRange)
		        .thenReturn(calculationRules);

		when(calculationRules.calculate()).thenReturn(5.0);

		chargeInfo.calculateEstimatedChargesAndDuration();

		assertEquals(54, chargeInfo.getIncrementalChargeAmount().doubleValue(), 0.001);
	}

	/**
	 * Should set estimated the base time units.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldSetEstimatedTheBaseTimeUnits() throws Exception {
		final IncrementalHoursCalculationRuleComposite calculationRules = mock(IncrementalHoursCalculationRuleComposite.class);

		final StoreHourBasedRentalDateRange mockedDateRange = mock(StoreHourBasedRentalDateRange.class);

		whenNew(StoreHourBasedRentalDateRange.class).withArguments(checkedOutDate, dueDate).thenReturn(mockedDateRange);

		whenNew(IncrementalHoursCalculationRuleComposite.class).withArguments(1.5, 0.5, mockedDateRange)
		        .thenReturn(calculationRules);

		when(calculationRules.calculate()).thenReturn(51.0);

		chargeInfo.calculateEstimatedChargesAndDuration();

		assertEquals(1, chargeInfo.getBaseTimeUnits().intValue());
	}

	/**
	 * Should set estimated the incremental time units.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldSetEstimatedTheIncrementalTimeUnits() throws Exception {
		final IncrementalHoursCalculationRuleComposite calculationRules = mock(IncrementalHoursCalculationRuleComposite.class);

		final StoreHourBasedRentalDateRange mockedDateRange = mock(StoreHourBasedRentalDateRange.class);

		whenNew(StoreHourBasedRentalDateRange.class).withArguments(checkedOutDate, dueDate).thenReturn(mockedDateRange);

		whenNew(IncrementalHoursCalculationRuleComposite.class).withArguments(1.5, 0.5, mockedDateRange)
		        .thenReturn(calculationRules);

		when(calculationRules.calculate()).thenReturn(51.0);

		chargeInfo.calculateEstimatedChargesAndDuration();

		assertEquals(102, chargeInfo.getIncrementalTimeUnits().intValue());
	}

	/**
	 * Should set the estimated damage waiver charges.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldSetTheEstimatedDamageWaiverCharges() throws Exception {
		final IncrementalHoursCalculationRuleComposite calculationRules = mock(IncrementalHoursCalculationRuleComposite.class);

		final StoreHourBasedRentalDateRange mockedDateRange = mock(StoreHourBasedRentalDateRange.class);

		whenNew(StoreHourBasedRentalDateRange.class).withArguments(checkedOutDate, dueDate).thenReturn(mockedDateRange);

		whenNew(IncrementalHoursCalculationRuleComposite.class).withArguments(1.5, 0.5, mockedDateRange)
		        .thenReturn(calculationRules);

		when(calculationRules.calculate()).thenReturn(5.0);

		chargeInfo.calculateEstimatedChargesAndDuration();

		verify(mockedDamageWaiver).calculate(argThat(new ArgumentMatcher<BigDecimal>() {

			@Override
			public boolean matches(final Object o) {
				assertEquals(new BigDecimal("64.8").doubleValue(), ((BigDecimal) o).doubleValue(), 0.001);
				return true;
			}
		}));
	}

	/**
	 * Should calculate the estimated rental duration.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCalculateTheEstimatedRentalDuration() throws Exception {
		final IncrementalHoursCalculationRuleComposite calculationRules = mock(IncrementalHoursCalculationRuleComposite.class);

		final StoreHourBasedRentalDateRange mockedDateRange = mock(StoreHourBasedRentalDateRange.class);

		whenNew(StoreHourBasedRentalDateRange.class).withArguments(checkedOutDate, dueDate).thenReturn(mockedDateRange);

		whenNew(IncrementalHoursCalculationRuleComposite.class).withArguments(1.5, 0.5, mockedDateRange)
		        .thenReturn(calculationRules);

		when(calculationRules.calculate()).thenReturn(5.0);

		chargeInfo.calculateEstimatedChargesAndDuration();

		assertEquals(1.5 + 5.0, chargeInfo.getEstimatedRentalDuration());
	}

	/**
	 * Should calculate additional incremental time units.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCalculateAdditionalIncrementalTimeUnits() throws Exception {
		final IncrementalHoursCalculationRuleComposite actualIncrementalRules = mock(IncrementalHoursCalculationRuleComposite.class);

		final StoreHourBasedRentalDateRange actualDateRange = mock(StoreHourBasedRentalDateRange.class);

		whenNew(StoreHourBasedRentalDateRange.class).withArguments(checkedOutDate, checkInDate).thenReturn(actualDateRange);

		whenNew(IncrementalHoursCalculationRuleComposite.class).withArguments(1.5, 0.5, actualDateRange).thenReturn(
		        actualIncrementalRules);

		when(actualIncrementalRules.calculate()).thenReturn(4.0);

		chargeInfo.setIncrementalTimeUnits(10);
		chargeInfo.setBaseTimeUnits(1);

		chargeInfo.markToCheckin();

		assertEquals(-2, chargeInfo.getAdditionalIncrementalTimeUnits().intValue());
	}

	/**
	 * Should calculate additional incremental charge amount.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCalculateAdditionalIncrementalChargeAmount() throws Exception {
		final IncrementalHoursCalculationRuleComposite actualIncrementalRules = mock(IncrementalHoursCalculationRuleComposite.class);

		final StoreHourBasedRentalDateRange actualDateRange = mock(StoreHourBasedRentalDateRange.class);

		whenNew(StoreHourBasedRentalDateRange.class).withArguments(checkedOutDate, checkInDate).thenReturn(actualDateRange);

		whenNew(IncrementalHoursCalculationRuleComposite.class).withArguments(1.5, 0.5, actualDateRange).thenReturn(
		        actualIncrementalRules);

		when(actualIncrementalRules.calculate()).thenReturn(6.0);

		chargeInfo.setIncrementalTimeUnits(10);
		chargeInfo.setBaseTimeUnits(1);

		chargeInfo.markToCheckin();

		assertEquals(2 * 5.4, chargeInfo.getAdditionalIncrementalChargeAmount().doubleValue(), 0.001);
	}

	/**
	 * Should calculate additional rental duration.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldCalculateAdditionalRentalDuration() throws Exception {
		final IncrementalHoursCalculationRuleComposite actualIncrementalRules = mock(IncrementalHoursCalculationRuleComposite.class);

		final StoreHourBasedRentalDateRange actualDateRange = mock(StoreHourBasedRentalDateRange.class);

		whenNew(StoreHourBasedRentalDateRange.class).withArguments(checkedOutDate, checkInDate).thenReturn(actualDateRange);

		whenNew(IncrementalHoursCalculationRuleComposite.class).withArguments(1.5, 0.5, actualDateRange).thenReturn(
		        actualIncrementalRules);

		when(actualIncrementalRules.calculate()).thenReturn(6.0);

		chargeInfo.setIncrementalTimeUnits(10);
		chargeInfo.setBaseTimeUnits(1);

		chargeInfo.markToCheckin();

		assertEquals(7.5, chargeInfo.getActualRentalDuration(), 0.001);
	}

	/**
	 * Should calculate checklist answers charge amout as well.
	 *
	 * @throws Exception the exception
	 */
	@Ignore
	@Test
	public void shouldCalculateChecklistAnswersChargeAmoutAsWell() throws Exception {
		final IncrementalHoursCalculationRuleComposite actualIncrementalRules = mock(IncrementalHoursCalculationRuleComposite.class);

		final StoreHourBasedRentalDateRange actualDateRange = mock(StoreHourBasedRentalDateRange.class);

		whenNew(StoreHourBasedRentalDateRange.class).withArguments(checkedOutDate, checkInDate).thenReturn(actualDateRange);

		whenNew(IncrementalHoursCalculationRuleComposite.class).withArguments(1.5, 0.5, actualDateRange).thenReturn(
		        actualIncrementalRules);

		when(actualIncrementalRules.calculate()).thenReturn(6.0);

		final ChecklistAnswerCollection checklistAnswerCollection = mock(ChecklistAnswerCollection.class);
		whenNew(ChecklistAnswerCollection.class).withArguments(chargeInfo.getAnswers()).thenReturn(checklistAnswerCollection);

		final BigDecimal expectedAmount = new BigDecimal("10.8");
		when(checklistAnswerCollection.getTotalChargeAmount()).thenReturn(expectedAmount);

		chargeInfo.setIncrementalTimeUnits(10);
		chargeInfo.setBaseTimeUnits(1);

		chargeInfo.markToCheckin();

		assertSame(expectedAmount, chargeInfo.getChecklistAnswersChargeAmount());
	}

	/**
	 * Should clear the existing answers and populate the new ones.
	 *
	 * @throws Exception the exception
	 */
	@Ignore
	@Test
	public void shouldClearTheExistingAnswersAndPopulateTheNewOnes() throws Exception {
		chargeInfo.getAnswers().add(new ChecklistAnswer());
		final List<ChecklistAnswer> answerList = new ArrayList<ChecklistAnswer>();

		final ChecklistAnswer expectedChecklistAnswer = new ChecklistAnswer();
		answerList.add(expectedChecklistAnswer);
		chargeInfo.setAnswerList(answerList);

		final IncrementalHoursCalculationRuleComposite actualIncrementalRules = mock(IncrementalHoursCalculationRuleComposite.class);

		final StoreHourBasedRentalDateRange actualDateRange = mock(StoreHourBasedRentalDateRange.class);

		whenNew(StoreHourBasedRentalDateRange.class).withArguments(checkedOutDate, checkInDate).thenReturn(actualDateRange);

		whenNew(IncrementalHoursCalculationRuleComposite.class).withArguments(1.5, 0.5, actualDateRange).thenReturn(
		        actualIncrementalRules);

		when(actualIncrementalRules.calculate()).thenReturn(6.0);
		chargeInfo.setIncrementalTimeUnits(10);
		chargeInfo.setBaseTimeUnits(1);

		chargeInfo.markToCheckin();

		assertEquals(1, chargeInfo.getAnswers().size());
		assertTrue(chargeInfo.getAnswers().contains(expectedChecklistAnswer));
	}

	/**
	 * Should get all the checklist answers added to the answer list.
	 */
	@Test
	public void shouldGetAllTheChecklistAnswersAddedToTheAnswerList() {
		final List<ChecklistAnswer> answerList = new ArrayList<ChecklistAnswer>();
		final ChecklistAnswer answer = new ChecklistAnswer();
		answerList.add(answer);
		chargeInfo.setAnswerList(answerList);

		assertSame(answerList, chargeInfo.getAnswerList());
		assertTrue(chargeInfo.getAnswerList().contains(answer));
		assertEquals(1, chargeInfo.getAnswerList().size());
	}

	/**
	 * Should get all list of all the answers if current size is zero.
	 */
	@Test
	public void shouldGetAllListOfAllTheAnswersIfCurrentSizeIsZero() {
		final Set<ChecklistAnswer> answerList = new HashSet<ChecklistAnswer>();
		final ChecklistAnswer answer = new ChecklistAnswer();
		answerList.add(answer);
		chargeInfo.setAnswers(answerList);

		assertTrue(chargeInfo.getAnswerList().contains(answer));
		assertEquals(1, chargeInfo.getAnswerList().size());
	}

	/**
	 * Should calculate the damage waiver charge.
	 */
	@Test
	public void shouldCalculateTheDamageWaiverCharge() {
		final DamageWaiver damageWaiver = mock(DamageWaiver.class);

		chargeInfo.setDamageWaiver(damageWaiver);
		chargeInfo.setBaseChargeAmount(new BigDecimal("10.8"));
		chargeInfo.setIncrementalChargeAmount(new BigDecimal("1.8"));
		chargeInfo.calculateDamageWaiverCharges();

		verify(damageWaiver).calculate(argThat(new ArgumentMatcher<BigDecimal>() {

			@Override
			public boolean matches(final Object o) {
				assertEquals(((BigDecimal) o).doubleValue(), new BigDecimal(10.8 + 1.8).doubleValue(), 0.001);
				return true;
			}
		}));
	}

	/**
	 * Should get the damage waiver amount.
	 */
	@Test
	public void shouldGetTheDamageWaiverAmount() {
		final DamageWaiver damageWaiver = mock(DamageWaiver.class);
		chargeInfo.setDamageWaiver(damageWaiver);

		final BigDecimal chargeAmount = new BigDecimal("10.998");
		when(damageWaiver.getAmount()).thenReturn(chargeAmount);

		assertSame(chargeAmount, chargeInfo.getDamageWaiverAmount());
	}

	/**
	 * Should get the actual incremental units.
	 */
	@Test
	public void shouldGetTheActualIncrementalUnits() {
		chargeInfo.setAdditionalIncrementalTimeUnits(7866);
		chargeInfo.setIncrementalTimeUnits(1233);

		assertEquals(9099, chargeInfo.getActualIncrementalTimeUnits().intValue());
	}

	/**
	 * Should should return actual incremental charge.
	 */
	@Test
	public void shouldShouldReturnActualIncrementalCharge() {
		chargeInfo = new ChargeInfoBuilder().withIncrementalChargeAmount(10).withBaseChargeAmount(20)
		        .withIncrementalPriceAmount(5).withAdditionalIncrementalTimeUnits(-2).buildChargeInfo();

		assertEquals(30 + (-10), chargeInfo.getActualIncrementalChargeAmount().doubleValue(), 0.001);
	}

	/**
	 * Should get total additional charge amount.
	 */
	@Test
	public void shouldGetTotalAdditionalChargeAmount() {
		chargeInfo.setAdditionalIncrementalChargeAmount(new BigDecimal("10.8"));
		chargeInfo.setChecklistAnswersChargeAmount(new BigDecimal("0.9"));

		assertEquals(11.7, chargeInfo.getTotalAdditionalChargeAmount().doubleValue(), 0.001);
	}

	/**
	 * Should return the total estimated charge amount.
	 */
	@Test
	public void shouldReturnTheTotalEstimatedChargeAmount() {
		chargeInfo.setBaseChargeAmount(new BigDecimal("4"));
		chargeInfo.setIncrementalChargeAmount(new BigDecimal("1"));
		chargeInfo.setSurchargePriceAmount(new BigDecimal("4"));

		assertEquals(9, chargeInfo.getTotalEstimatedChargeAmount().doubleValue(), 0.001);
	}

	/**
	 * Should return the sum of base plus incremental charge amount.
	 */
	@Test
	public void shouldReturnTheSumOfBasePlusIncrementalChargeAmount() {
		chargeInfo.setBaseChargeAmount(new BigDecimal("2.7"));
		chargeInfo.setIncrementalChargeAmount(new BigDecimal("1.8"));

		assertEquals(4.5, chargeInfo.getEstimatedChargeAmountWithoutSurcharge().doubleValue(), 0.001);
	}

	/**
	 * Should update the additional incremental time units with the difference of actual and estimated time units.
	 */
	@Test
	public void shouldUpdateTheAdditionalIncrementalTimeUnitsWithTheDifferenceOfActualAndEstimatedTimeUnits() {
		chargeInfo.setIncrementalTimeUnits(5);
		chargeInfo.setAdditionalIncrementalTimeUnits(1230);
		chargeInfo.doQuantityOverride(1233);

		assertEquals(1228, chargeInfo.getAdditionalIncrementalTimeUnits().intValue());
	}

	/**
	 * Should update the additional incremental charge amount after quantity override.
	 */
	@Test
	public void shouldUpdateTheAdditionalIncrementalChargeAmountAfterQuantityOverride() {
		chargeInfo.setIncrementalPriceAmount(new BigDecimal("9"));
		chargeInfo.setIncrementalTimeUnits(5);
		chargeInfo.setAdditionalIncrementalTimeUnits(1230);
		chargeInfo.doQuantityOverride(1233);

		assertEquals(new BigDecimal(1228 * 9).doubleValue(),
		        chargeInfo.getAdditionalIncrementalChargeAmount().doubleValue(), 0.001);
	}

	/**
	 * Should update the base charge amount by the same percentage by which the price override has been done.
	 */
	@Test
	public void shouldUpdateTheBaseChargeAmountByTheSamePercentageByWhichThePriceOverrideHasBeenDone() {
		chargeInfo.setBaseChargeAmount(new BigDecimal("10.0"));
		chargeInfo.setIncrementalChargeAmount(new BigDecimal("0"));
		chargeInfo.setIncrementalTimeUnits(0);

		chargeInfo.doPriceOverride(new BigDecimal("9.0"));

		assertEquals(9.0, chargeInfo.getBaseChargeAmount().doubleValue(), 0.001);
		assertEquals(9.0, chargeInfo.getBasePriceAmount().doubleValue(), 0.001);
	}

	/**
	 * Should update the incremental charge amount by the same percentage by which the price override has been done.
	 */
	@Test
	public void shouldUpdateTheIncrementalChargeAmountByTheSamePercentageByWhichThePriceOverrideHasBeenDone() {
		chargeInfo.setBaseChargeAmount(new BigDecimal("5.4"));
		chargeInfo.setIncrementalChargeAmount(new BigDecimal("10.8"));
		chargeInfo.setIncrementalTimeUnits(5);

		chargeInfo.doPriceOverride(new BigDecimal("15.3"));

		assertEquals(10.20, chargeInfo.getIncrementalChargeAmount().doubleValue(), 0.001);
		assertEquals(2.04, chargeInfo.getIncrementalPriceAmount().doubleValue(), 0.001);
	}

	/**
	 * Should update the incremental and base charge amount by the same percentage by which the price override has been done.
	 */
	@Test
	public void shouldUpdateTheIncrementalAndBaseChargeAmountByTheSamePercentageByWhichThePriceOverrideHasBeenDone() {
		chargeInfo.setBaseChargeAmount(new BigDecimal("6.3"));
		chargeInfo.setIncrementalChargeAmount(new BigDecimal("1.8"));
		chargeInfo.setIncrementalTimeUnits(1);

		chargeInfo.doPriceOverride(new BigDecimal("7"));

		assertEquals(5.44, chargeInfo.getBaseChargeAmount().doubleValue(), 0.001);
		assertEquals(5.44, chargeInfo.getBasePriceAmount().doubleValue(), 0.001);
		assertEquals(1.56, chargeInfo.getIncrementalChargeAmount().doubleValue(), 0.001);
		assertEquals(1.56, chargeInfo.getIncrementalPriceAmount().doubleValue(), 0.001);
	}
}