package com.menards.rental.domain;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Set;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
public class OutOfStockAuditTrailCollectionTest {

    @Test
    public void shouldGetTheDistinctStoreNumbersFromTheListOfOutOfStockAuditTrails() {
        final ArrayList<OutOfStockAuditTrail> entities = new ArrayList<OutOfStockAuditTrail>();
        final OutOfStockAuditTrail trail1 = new OutOfStockAuditTrail();
        final OutOfStockAuditTrail trail2 = new OutOfStockAuditTrail();
        final OutOfStockAuditTrail trail3 = new OutOfStockAuditTrail();
        trail1.setStoreNumber(1233);
        trail2.setStoreNumber(1233);
        trail3.setStoreNumber(7866);
        entities.add(trail1);
        entities.add(trail2);
        entities.add(trail3);
        final OutOfStockAuditTrailCollection auditTrailCollection = new OutOfStockAuditTrailCollection(entities);
        final Set<Integer> distinctStoreNumbers = auditTrailCollection.getDistinctStoreNumbers();
        assertEquals(2, distinctStoreNumbers.size());
        assertTrue(distinctStoreNumbers.contains(1233));
        assertTrue(distinctStoreNumbers.contains(7866));
    }

    @Test
    public void shouldGetTheDistinctProductIdsFromTheListOfOutOfStockAuditTrails() {
        final ArrayList<OutOfStockAuditTrail> entities = new ArrayList<OutOfStockAuditTrail>();
        final OutOfStockAuditTrail trail1 = new OutOfStockAuditTrail();
        final OutOfStockAuditTrail trail2 = new OutOfStockAuditTrail();
        final OutOfStockAuditTrail trail3 = new OutOfStockAuditTrail();
        final Product product1 = new Product();
        final Product product2 = new Product();
        trail1.setProduct(product1);
        trail2.setProduct(product1);
        trail3.setProduct(product2);
        entities.add(trail1);
        entities.add(trail2);
        entities.add(trail3);
        final OutOfStockAuditTrailCollection auditTrailCollection = new OutOfStockAuditTrailCollection(entities);
        final Set<Product> distinctProductIds = auditTrailCollection.getDistinctProducts();
        assertEquals(2, distinctProductIds.size());
        assertTrue(distinctProductIds.contains(product1));
        assertTrue(distinctProductIds.contains(product2));
    }
}
