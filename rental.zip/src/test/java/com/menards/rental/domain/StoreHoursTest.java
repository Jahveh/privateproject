/*
 * StoreHoursTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.Calendar;

import org.junit.Test;

import com.menards.rental.builder.StoreHoursBuilder;

/**
 * Created by IntelliJ IDEA. User: deep Date: 14 Jul, 2010 Time: 2:57:39 PM To
 * change this template use File | Settings | File Templates.
 */
public class StoreHoursTest {

	/**
	 * Should calculate the number of checkout hours.
	 */
	@Test
	public void shouldCalculateTheNumberOfCheckoutHours() {
		final Calendar outDate = Calendar.getInstance();
		outDate.setTime(Calendar.getInstance().getTime());
		outDate.set(Calendar.HOUR_OF_DAY, 18);
		outDate.set(Calendar.MINUTE, 9);
		assertEquals(3.85, new StoreHoursBuilder().withOpen(new Time("08:00")).withClose(new Time("22:00")).buildStoreHours()
		        .getNumberOfCheckoutHours(outDate), 0.001);
	}

    @Test
    public void shouldCalculateTheCheckoutHoursFromTheStoreOpenHoursIfTheCheckoutDateWasEarlierThanStoreOpen() {
        final Calendar outDate = Calendar.getInstance();
        outDate.setTime(Calendar.getInstance().getTime());
        outDate.set(Calendar.HOUR_OF_DAY, 1);
        outDate.set(Calendar.MINUTE, 9);
        assertEquals(14.0, new StoreHoursBuilder().withOpen(new Time("08:00")).withClose(new Time("22:00"))
                .buildStoreHours()
                .getNumberOfCheckoutHours(outDate), 0.001);
    }

    @Test
    public void shouldZeroIfTheCheckoutDateWasLaterThanStoreClose() {
        final Calendar outDate = Calendar.getInstance();
        outDate.setTime(Calendar.getInstance().getTime());
        outDate.set(Calendar.HOUR_OF_DAY, 22);
        outDate.set(Calendar.MINUTE, 30);
        assertEquals(0.0, new StoreHoursBuilder().withOpen(new Time("08:00")).withClose(new Time("22:00"))
                .buildStoreHours()
                .getNumberOfCheckoutHours(outDate), 0.001);
    }

	/**
	 * Should calculate the number of checkin hours.
	 */
	@Test
	public void shouldCalculateTheNumberOfCheckinHours() {
		final Calendar outDate = Calendar.getInstance();
		outDate.setTime(Calendar.getInstance().getTime());
		outDate.set(Calendar.HOUR_OF_DAY, 9);
		outDate.set(Calendar.MINUTE, 27);
		assertEquals(1.45, new StoreHoursBuilder().withOpen(new Time("08:00")).withClose(new Time("22:00")).buildStoreHours()
		        .getNumberOfCheckinHours(outDate), 0.001);
	}

	/**
	 * Should calculate the number of checkin hours.
	 */
	@Test
	public void shouldCalculateTheNumberOfCheckinHoursFromTheStoreHoursCloseTimeIfCloseTimeIsEarlierThanCheckinTime() {
		final Calendar outDate = Calendar.getInstance();
		outDate.setTime(Calendar.getInstance().getTime());
		outDate.set(Calendar.HOUR_OF_DAY, 22);
		outDate.set(Calendar.MINUTE, 27);
		assertEquals(14.0, new StoreHoursBuilder().withOpen(new Time("08:00")).withClose(new Time("22:00")).buildStoreHours()
		        .getNumberOfCheckinHours(outDate), 0.001);
	}

	/**
	 * Should calculate the number of checkin hours.
	 */
	@Test
	public void shouldZeroIfOpenTimeIsLaterThanCheckinTime() {
		final Calendar outDate = Calendar.getInstance();
		outDate.setTime(Calendar.getInstance().getTime());
		outDate.set(Calendar.HOUR_OF_DAY, 07);
		outDate.set(Calendar.MINUTE, 30);
		assertEquals(0.0, new StoreHoursBuilder().withOpen(new Time("08:00")).withClose(new Time("22:00")).buildStoreHours()
		        .getNumberOfCheckinHours(outDate), 0.001);
	}

	/**
	 * Should calculate the number of checkout hours for the given day.
	 */
	@Test
	public void shouldCalculateTheNumberOfCheckoutHoursForTheGivenDay() {
		final Calendar outDate = Calendar.getInstance();
		outDate.set(2010, 6, 18);
		outDate.set(Calendar.HOUR_OF_DAY, 18);
		outDate.set(Calendar.MINUTE, 9);

		final StoreHour storeHours = new StoreHour();
		storeHours.setSundayOpen(new Time("08:00"));
		storeHours.setSundayClose(new Time("22:00"));

		assertEquals(3.85, storeHours.getNumberOfCheckoutHours(outDate), 0.001);
	}

	/**
	 * Should calculate the number of checkin hours for the given day.
	 */
	@Test
	public void shouldCalculateTheNumberOfCheckinHoursForTheGivenDay() {
		final Calendar outDate = Calendar.getInstance();
		outDate.set(2010, 6, 14);
		outDate.set(Calendar.HOUR_OF_DAY, 9);
		outDate.set(Calendar.MINUTE, 27);

		final StoreHour storeHours = new StoreHour();
		storeHours.setWednesdayOpen(new Time("08:00"));
		storeHours.setWednesdayClose(new Time("22:00"));

		assertEquals(1.45, storeHours.getNumberOfCheckinHours(outDate), 0.001);
	}

	/**
	 * Should return true if date range is on the same day.
	 */
	@Test
	public void shouldReturnTrueIfDateRangeIsOnTheSameDay() {
		final DateRange mockedDateRange = mock(DateRange.class);
		when(mockedDateRange.isOnSameDay()).thenReturn(true);
		assertTrue(new StoreHour().isDateRangeWithinStoreHours(mockedDateRange));
	}

	/**
	 * Should return false if date range is not on the same day.
	 */
	@Test
	public void shouldReturnFalseIfDateRangeIsNotOnTheSameDay() {
		final DateRange mockedDateRange = mock(DateRange.class);
		when(mockedDateRange.isOnSameDay()).thenReturn(false);
		assertFalse(new StoreHour().isDateRangeWithinStoreHours(mockedDateRange));
	}

    @Test
    public void shouldReturnTheDifferenceOfHoursIfTheUpperAndLowerAreWithinTheStoreHours() {
        final DateRange mockedDateRange = mock(DateRange.class);

        final Calendar outDate = Calendar.getInstance();
        final Calendar inDate = Calendar.getInstance();
        outDate.set(2010, 6, 14);
        inDate.set(2010, 6, 14);
        outDate.set(Calendar.HOUR_OF_DAY, 9);
        outDate.set(Calendar.MINUTE, 0);
        inDate.set(Calendar.HOUR_OF_DAY, 15);
        inDate.set(Calendar.MINUTE, 0);

        final StoreHour storeHours = new StoreHour();
        storeHours.setWednesdayOpen(new Time("08:00"));
        storeHours.setWednesdayClose(new Time("22:00"));

        when(mockedDateRange.getUpper()).thenReturn(inDate);
        when(mockedDateRange.getLower()).thenReturn(outDate);

        assertEquals(6.0, storeHours.getTotalDurationInHours(mockedDateRange), 0.001);
    }

    @Test
    public void shouldReturnTheDifferenceOfStoreOpenHoursAndLowerIfUpperIsEarlierThanTheStoreOpen() {
        final DateRange mockedDateRange = mock(DateRange.class);

        final Calendar outDate = Calendar.getInstance();
        final Calendar inDate = Calendar.getInstance();
        outDate.set(2010, 6, 14);
        inDate.set(2010, 6, 14);
        outDate.set(Calendar.HOUR_OF_DAY, 5);
        outDate.set(Calendar.MINUTE, 0);
        inDate.set(Calendar.HOUR_OF_DAY, 15);
        inDate.set(Calendar.MINUTE, 0);

        final StoreHour storeHours = new StoreHour();
        storeHours.setWednesdayOpen(new Time("08:00"));
        storeHours.setWednesdayClose(new Time("22:00"));

        when(mockedDateRange.getUpper()).thenReturn(inDate);
        when(mockedDateRange.getLower()).thenReturn(outDate);

        assertEquals(7.0, storeHours.getTotalDurationInHours(mockedDateRange), 0.1);
    }

    @Test
    public void shouldReturnTheDifferenceOfUpperAndStoreCloseIfLowerIsLaterThanTheStoreClose() {
        final DateRange mockedDateRange = mock(DateRange.class);

        final Calendar outDate = Calendar.getInstance();
        final Calendar inDate = Calendar.getInstance();
        outDate.set(2010, 6, 14);
        inDate.set(2010, 6, 14);
        outDate.set(Calendar.HOUR_OF_DAY, 9);
        outDate.set(Calendar.MINUTE, 0);
        inDate.set(Calendar.HOUR_OF_DAY, 23);
        inDate.set(Calendar.MINUTE, 0);

        final StoreHour storeHours = new StoreHour();
        storeHours.setWednesdayOpen(new Time("08:00"));
        storeHours.setWednesdayClose(new Time("22:00"));

        when(mockedDateRange.getUpper()).thenReturn(inDate);
        when(mockedDateRange.getLower()).thenReturn(outDate);

        assertEquals(13.0, storeHours.getTotalDurationInHours(mockedDateRange), 0.1);
    }

    @Test
    public void shouldReturnTheDifferenceOfStoreOpenAndCloseIfUpperIsEarlierThanOpenAndLowerIsLaterThanClose() {
        final DateRange mockedDateRange = mock(DateRange.class);

        final Calendar outDate = Calendar.getInstance();
        final Calendar inDate = Calendar.getInstance();
        outDate.set(2010, 6, 14);
        inDate.set(2010, 6, 14);
        outDate.set(Calendar.HOUR_OF_DAY, 4);
        outDate.set(Calendar.MINUTE, 0);
        inDate.set(Calendar.HOUR_OF_DAY, 23);
        inDate.set(Calendar.MINUTE, 0);

        final StoreHour storeHours = new StoreHour();
        storeHours.setWednesdayOpen(new Time("08:00"));
        storeHours.setWednesdayClose(new Time("22:00"));

        when(mockedDateRange.getUpper()).thenReturn(inDate);
        when(mockedDateRange.getLower()).thenReturn(outDate);

        assertEquals(14.0, storeHours.getTotalDurationInHours(mockedDateRange), 0.001);
    }

    @Test
    public void shouldZeroIfCheckinAndCheckoutTimesAreBeforeStoreOpens() {
        final DateRange mockedDateRange = mock(DateRange.class);

        final Calendar outDate = Calendar.getInstance();
        final Calendar inDate = Calendar.getInstance();
        outDate.set(2010, 6, 14);
        inDate.set(2010, 6, 14);
        outDate.set(Calendar.HOUR_OF_DAY, 4);
        outDate.set(Calendar.MINUTE, 0);
        inDate.set(Calendar.HOUR_OF_DAY, 5);
        inDate.set(Calendar.MINUTE, 0);

        final StoreHour storeHours = new StoreHour();
        storeHours.setWednesdayOpen(new Time("08:00"));
        storeHours.setWednesdayClose(new Time("22:00"));

        when(mockedDateRange.getUpper()).thenReturn(inDate);
        when(mockedDateRange.getLower()).thenReturn(outDate);

        assertEquals(0.0, storeHours.getTotalDurationInHours(mockedDateRange), 0.001);
    }

    @Test
    public void shouldZeroIfCheckinAndCheckoutTimesAreAfterStoreCloses() {
        final DateRange mockedDateRange = mock(DateRange.class);

        final Calendar outDate = Calendar.getInstance();
        final Calendar inDate = Calendar.getInstance();
        outDate.set(2010, 6, 14);
        inDate.set(2010, 6, 14);
        outDate.set(Calendar.HOUR_OF_DAY, 22);
        outDate.set(Calendar.MINUTE, 20);
        inDate.set(Calendar.HOUR_OF_DAY, 23);
        inDate.set(Calendar.MINUTE, 30);

        final StoreHour storeHours = new StoreHour();
        storeHours.setWednesdayOpen(new Time("08:00"));
        storeHours.setWednesdayClose(new Time("22:00"));

        when(mockedDateRange.getUpper()).thenReturn(inDate);
        when(mockedDateRange.getLower()).thenReturn(outDate);

        assertEquals(0.0, storeHours.getTotalDurationInHours(mockedDateRange), 0.001);
    }    
}
