package com.menards.rental.domain;

import static junit.framework.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.stub;

import java.util.ArrayList;
import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest(OutOfStockAuditTrail.class)
public class OutOfStockAuditTrailTest {

    @Test
    public void shouldFindOutOfStockAuditTrailByProductAndStoreNumberAndEndTimeIsNull() {
        final Query query = mock(Query.class);
        stub(method(OutOfStockAuditTrail.class, "findOutOfStockAuditTrailsByProductAndStoreNumberAndEndTimeIsNull",
                Product.class, Integer.class)).andReturn(query);

        final ArrayList<OutOfStockAuditTrail> auditTrails = new ArrayList<OutOfStockAuditTrail>();
        final OutOfStockAuditTrail trail = new OutOfStockAuditTrail();
        auditTrails.add(trail);
        when(query.getResultList()).thenReturn(auditTrails);

        assertSame(trail, OutOfStockAuditTrail.findOutOfStockAuditTrailByProductAndStoreNumberAndEndTimeIsNull(
                new Product(), 1233));
    }

    @Test
    public void shouldReturnNullIfNoAuditTrailIsFoundForTheMatchingCriteria() {
        final Query query = mock(Query.class);
        stub(method(OutOfStockAuditTrail.class, "findOutOfStockAuditTrailsByProductAndStoreNumberAndEndTimeIsNull",
                Product.class, Integer.class)).andReturn(query);

        final ArrayList<OutOfStockAuditTrail> auditTrails = new ArrayList<OutOfStockAuditTrail>();
        when(query.getResultList()).thenReturn(auditTrails);

        assertNull(OutOfStockAuditTrail.findOutOfStockAuditTrailByProductAndStoreNumberAndEndTimeIsNull(
                new Product(), 1233));
    }

    @Test
    public void shouldReturnTheListOfAuditTrailsThatReBetweenTheGivenDatesAndOrderedByStoreNumberAndProductId() {
        final EntityManager entityManager = mock(EntityManager.class);
        stub(method(OutOfStockAuditTrail.class, "entityManager", null)).andReturn(entityManager);
        final Query query = mock(Query.class);
        when(entityManager.createQuery("select o from OutOfStockAuditTrail o inner join fetch o.product p "
                + " where o.startTime between :startDate and :endDate"
                + " order by o.storeNumber, o.product.id"))
                .thenReturn(query);

        final Calendar startDate = Calendar.getInstance();
        final Calendar endDate = Calendar.getInstance();
        when(query.setParameter("startDate", startDate)).thenReturn(query);
        when(query.setParameter("endDate", endDate)).thenReturn(query);
        when(query.setParameter("storeNumber", 8888)).thenReturn(query);

        final ArrayList<OutOfStockAuditTrail> expectedList = new ArrayList<OutOfStockAuditTrail>();
        when(query.getResultList()).thenReturn(expectedList);

        assertSame(expectedList, OutOfStockAuditTrail
                .findOutOfStockAuditTrailsByStartDateBetweenOrderByProduct(startDate, endDate));
    }
}
