/*
 * AgreementWithItemsTest.java
 */
package com.menards.rental.domain;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import com.menards.rental.builder.AgreementBuilder;
import com.menards.rental.builder.AgreementItemBuilder;

/**
 * Test for agreement in a state with no items.
 *
 * @author geoff
 * @since May 26, 2010
 */
public class AgreementWithItemsTest {
	
	/** The agreement. */
	private Agreement agreement;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		final AgreementItemBuilder itemBuilder = new AgreementItemBuilder();
		final AgreementBuilder agreementBuilder = new AgreementBuilder();
		agreement = agreementBuilder.withItem(itemBuilder.buildAgreementItem(new BigDecimal("1.50"))).withItem(
		        itemBuilder.buildAgreementItem(new BigDecimal("10.50"))).withItem(
		        itemBuilder.buildAgreementItem(new BigDecimal("1.0"))).buildAgreement();

	}

	/**
	 * Should have sub total of zero.
	 */
	@Test
	public void shouldHaveSubTotalOfZero() {
		final Agreement mockedAgreement = spy(agreement);
		doReturn(new BigDecimal("108.0")).when(mockedAgreement).getEffectiveRentalTotalExcludingDamageWaiver();
		doReturn(new BigDecimal("99.99")).when(mockedAgreement).getDamageWaiverTotal();

		assertEquals(207.99, mockedAgreement.getSubTotal().doubleValue(), 0.0001);
	}

	/**
	 * Should have rental total of zero.
	 */
	@Test
	public void shouldHaveRentalTotalOfZero() {
		final Agreement mockedAgreement = spy(agreement);
		doReturn(new BigDecimal("13.0")).when(mockedAgreement).getEffectiveRentalTotalExcludingDamageWaiver();

		assertEquals(new BigDecimal("13.0").doubleValue(), mockedAgreement.getEffectiveRentalTotalExcludingDamageWaiver()
		        .doubleValue(), 0.0001);
	}

	/**
	 * Should have damage waiver total of zero.
	 */
	@Test
	public void shouldHaveDamageWaiverTotalOfZero() {
		assertEquals(0.0, agreement.getDamageWaiverTotal().doubleValue(), 0.0001);
	}

}
