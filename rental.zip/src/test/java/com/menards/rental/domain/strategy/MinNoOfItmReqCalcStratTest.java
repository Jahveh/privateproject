/*
 * MinimumNumberOfItemsRequiredCalculationStrategyTest.java
 */
package com.menards.rental.domain.strategy;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.menards.rental.domain.Reservation;

/**
 * User: deep Date: 9 Jul, 2010 Time: 7:44:42 PM.
 */
public class MinNoOfItmReqCalcStratTest {

	/**
	 * Should return total number of overlapping reservations.
	 */
	@Test
	public void shouldReturnTotalNumberOfOverlappingReservations() {
		final List<Reservation> reservations = new ArrayList<Reservation>();

		final Reservation second = mock(Reservation.class);
		final Reservation third = mock(Reservation.class);
		reservations.add(second);
		reservations.add(third);

		when(second.isOverlapping(third)).thenReturn(true);

		assertEquals(2, new MinimumItmsRequiredCalculationStrategy(reservations).count());
	}

	/**
	 * Should return actual number of overlapping reservations when there are8 reservations.
	 */
	@Test
	public void shouldReturnActualNumberOfOverlappingReservationsWhenThereAre8Reservations() {
		final List<Reservation> reservations = new ArrayList<Reservation>();

		final Reservation r1 = mock(Reservation.class);
		final Reservation r2 = mock(Reservation.class);
		final Reservation r3 = mock(Reservation.class);
		final Reservation r4 = mock(Reservation.class);
		final Reservation r5 = mock(Reservation.class);
		final Reservation r6 = mock(Reservation.class);
		final Reservation r7 = mock(Reservation.class);
		final Reservation r8 = mock(Reservation.class);
		reservations.add(r1);
		reservations.add(r2);
		reservations.add(r3);
		reservations.add(r4);
		reservations.add(r5);
		reservations.add(r6);
		reservations.add(r7);
		reservations.add(r8);

		when(r1.isOverlapping(r2)).thenReturn(false);
		when(r1.isOverlapping(r3)).thenReturn(false);
		when(r1.isOverlapping(r4)).thenReturn(false);
		when(r1.isOverlapping(r5)).thenReturn(false);
		when(r1.isOverlapping(r6)).thenReturn(false);
		when(r1.isOverlapping(r7)).thenReturn(false);
		when(r1.isOverlapping(r8)).thenReturn(false);

		when(r2.isOverlapping(r3)).thenReturn(false);
		when(r2.isOverlapping(r4)).thenReturn(true);
		when(r2.isOverlapping(r5)).thenReturn(true);
		when(r2.isOverlapping(r6)).thenReturn(true);
		when(r2.isOverlapping(r7)).thenReturn(false);
		when(r2.isOverlapping(r8)).thenReturn(false);

		when(r3.isOverlapping(r4)).thenReturn(false);
		when(r3.isOverlapping(r5)).thenReturn(false);
		when(r3.isOverlapping(r6)).thenReturn(false);
		when(r3.isOverlapping(r7)).thenReturn(false);
		when(r3.isOverlapping(r8)).thenReturn(true);

		when(r4.isOverlapping(r5)).thenReturn(true);
		when(r4.isOverlapping(r6)).thenReturn(false);
		when(r4.isOverlapping(r7)).thenReturn(false);
		when(r4.isOverlapping(r8)).thenReturn(false);

		when(r5.isOverlapping(r6)).thenReturn(true);
		when(r5.isOverlapping(r7)).thenReturn(true);
		when(r5.isOverlapping(r8)).thenReturn(false);

		when(r6.isOverlapping(r7)).thenReturn(true);
		when(r6.isOverlapping(r8)).thenReturn(true);

		when(r7.isOverlapping(r8)).thenReturn(true);

		assertEquals(3, new MinimumItmsRequiredCalculationStrategy(reservations).count());
	}

	/**
	 * Should return actual number of overlapping reservations when there are4 reservations.
	 */
	@Test
	public void shouldReturnActualNumberOfOverlappingReservationsWhenThereAre4Reservations() {
		final List<Reservation> reservations = new ArrayList<Reservation>();

		final Reservation r1 = mock(Reservation.class);
		final Reservation r2 = mock(Reservation.class);
		final Reservation r3 = mock(Reservation.class);
		final Reservation r4 = mock(Reservation.class);
		reservations.add(r1);
		reservations.add(r2);
		reservations.add(r3);
		reservations.add(r4);

		when(r1.isOverlapping(r2)).thenReturn(true);
		when(r1.isOverlapping(r3)).thenReturn(false);
		when(r1.isOverlapping(r4)).thenReturn(false);

		when(r2.isOverlapping(r3)).thenReturn(true);
		when(r2.isOverlapping(r4)).thenReturn(true);

		when(r3.isOverlapping(r4)).thenReturn(false);

		assertEquals(2, new MinimumItmsRequiredCalculationStrategy(reservations).count());
	}

	/**
	 * Should return the list of list of non overlapping reservations.
	 */
	@Test
	public void shouldReturnTheListOfListOfNonOverlappingReservations() {
		final List<Reservation> reservations = new ArrayList<Reservation>();

		final Reservation r1 = mock(Reservation.class);
		final Reservation r2 = mock(Reservation.class);
		final Reservation r3 = mock(Reservation.class);
		final Reservation r4 = mock(Reservation.class);
		final Reservation r5 = mock(Reservation.class);
		final Reservation r6 = mock(Reservation.class);
		final Reservation r7 = mock(Reservation.class);
		final Reservation r8 = mock(Reservation.class);
		reservations.add(r1);
		reservations.add(r2);
		reservations.add(r3);
		reservations.add(r4);
		reservations.add(r5);
		reservations.add(r6);
		reservations.add(r7);
		reservations.add(r8);

		when(r1.isOverlapping(r2)).thenReturn(false);
		when(r1.isOverlapping(r3)).thenReturn(false);
		when(r1.isOverlapping(r4)).thenReturn(false);
		when(r1.isOverlapping(r5)).thenReturn(false);
		when(r1.isOverlapping(r6)).thenReturn(false);
		when(r1.isOverlapping(r7)).thenReturn(false);
		when(r1.isOverlapping(r8)).thenReturn(false);

		when(r2.isOverlapping(r3)).thenReturn(false);
		when(r2.isOverlapping(r4)).thenReturn(true);
		when(r2.isOverlapping(r5)).thenReturn(true);
		when(r2.isOverlapping(r6)).thenReturn(true);
		when(r2.isOverlapping(r7)).thenReturn(false);
		when(r2.isOverlapping(r8)).thenReturn(false);

		when(r3.isOverlapping(r4)).thenReturn(false);
		when(r3.isOverlapping(r5)).thenReturn(false);
		when(r3.isOverlapping(r6)).thenReturn(false);
		when(r3.isOverlapping(r7)).thenReturn(false);
		when(r3.isOverlapping(r8)).thenReturn(true);

		when(r4.isOverlapping(r5)).thenReturn(true);
		when(r4.isOverlapping(r6)).thenReturn(false);
		when(r4.isOverlapping(r7)).thenReturn(false);
		when(r4.isOverlapping(r8)).thenReturn(false);

		when(r5.isOverlapping(r6)).thenReturn(true);
		when(r5.isOverlapping(r7)).thenReturn(true);
		when(r5.isOverlapping(r8)).thenReturn(false);

		when(r6.isOverlapping(r7)).thenReturn(true);
		when(r6.isOverlapping(r8)).thenReturn(true);

		when(r7.isOverlapping(r8)).thenReturn(true);

		final List<List<Reservation>> nonOverlappingReservationsList = new MinimumItmsRequiredCalculationStrategy(
		        reservations).getNonOverlappingReservationsList();
		assertEquals(3, nonOverlappingReservationsList.size());

		assertEquals(4, nonOverlappingReservationsList.get(0).size());
		assertTrue(nonOverlappingReservationsList.get(0).contains(r1));
		assertTrue(nonOverlappingReservationsList.get(0).contains(r2));
		assertTrue(nonOverlappingReservationsList.get(0).contains(r3));
		assertTrue(nonOverlappingReservationsList.get(0).contains(r7));

		assertEquals(2, nonOverlappingReservationsList.get(1).size());
		assertTrue(nonOverlappingReservationsList.get(1).contains(r4));
		assertTrue(nonOverlappingReservationsList.get(1).contains(r6));

		assertEquals(2, nonOverlappingReservationsList.get(1).size());
		assertTrue(nonOverlappingReservationsList.get(2).contains(r5));
		assertTrue(nonOverlappingReservationsList.get(2).contains(r8));
	}
}
