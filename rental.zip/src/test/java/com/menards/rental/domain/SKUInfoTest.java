/*
 * SKUInfoTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.builder.SKUInfoBuilder;

/**
 * Created by IntelliJ IDEA. User: deep Date: 11 Jun, 2010 Time: 5:44:23 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
public class SKUInfoTest {

    /**
	 * Should create an instance of charge info and copy hours in it.
	 */
	@Test
	public void shouldCreateAnInstanceOfChargeInfoAndCopyHoursInIt() {
		final SKUInfo skuInfo = new SKUInfoBuilder().withBaseSkuHrQty(1.15).withIncrementalSkuHrQty(1.5).buildSKUInfo();

		final ChargeInfo chargeInfo = skuInfo.createChargeInfo();
		assertNotNull(chargeInfo);
		assertEquals(1.15, chargeInfo.getBaseSkuHrQty(), 0.001);
		assertEquals(1.5, chargeInfo.getIncrementalSkuHrQty(), 0.001);
	}
    
    @Test
    public void shouldCopyBaseHoursFromOtherSkuInfo() {
        final SKUInfo skuInfo = new SKUInfo();
        skuInfo.copyHoursFrom(new SKUInfoBuilder().withBaseSkuHrQty(24.0).buildSKUInfo());
        assertEquals(24.0, skuInfo.getBaseSkuHrQty(), 0.001);
    }

    @Test
    public void shouldCopyIncrementalHoursFromOtherSkuInfo() {
        final SKUInfo skuInfo = new SKUInfo();
        skuInfo.copyHoursFrom(new SKUInfoBuilder().withIncrementalSkuHrQty(1.0).buildSKUInfo());
        assertEquals(1.0, skuInfo.getIncrementalSkuHrQty(), 0.001);
    }
}
