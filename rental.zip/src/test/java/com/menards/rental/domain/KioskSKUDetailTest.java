package com.menards.rental.domain;

import org.junit.Test;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
public class KioskSKUDetailTest {

    @Test
    public void shouldReturnFalseIfNoItemsHaveBeenSetupInKiosk() {
        assertFalse(new KioskSKUDetail().isAtLeastOneItemSetup());
    }

    @Test
    public void shouldReturnTrueIfItemsHaveBeenSetupInKiosk() {
        final KioskSKUDetail kioskSKUDetail = new KioskSKUDetail();
        kioskSKUDetail.setNumberOfItems(1233);
        assertTrue(kioskSKUDetail.isAtLeastOneItemSetup());
    }
}
