/*
 * DifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRuleTest.java
 */
package com.menards.rental.domain.rule;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Test;

import com.menards.rental.domain.StoreHourBasedRentalDateRange;

/**
 * User: deep Date: 13 Jun, 2010 Time: 1:35:50 PM.
 */
public class DiffOfTotalAndBaseHrsAndIncrHrsCalcRuleTest {

	/**
	 * Should return the difference of total duration and base sku hour.
	 */
	@Test
	public void shouldReturnTheDifferenceOfTotalDurationAndBaseSkuHour() {
		final StoreHourBasedRentalDateRange mockedRentalDateRange = getMockedRentalDateRange(27.0);
		when(mockedRentalDateRange.subtractHoursFromTotalDuration(24.0)).thenReturn(3.0);

		assertEquals(3.0, new DiffOfTotalAndBaseHrsAndIncrHrsCalcRule(24.0, mockedRentalDateRange)
		        .calculate());
	}

	/**
	 * Gets the mocked rental date range.
	 *
	 * @param totalDurationInHours the total duration in hours
	 * @return the mocked rental date range
	 */
	private StoreHourBasedRentalDateRange getMockedRentalDateRange(final double totalDurationInHours) {
		final StoreHourBasedRentalDateRange mockedRentalDateRange = mock(StoreHourBasedRentalDateRange.class);
		when(mockedRentalDateRange.getTotalDurationInHours()).thenReturn(totalDurationInHours);
		return mockedRentalDateRange;
	}
}
