/*
 * RentalDurationDoNotOverlapExistingReservationDurationReservaionRuleTest.java
 */
package com.menards.rental.domain.rule;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Calendar;

import org.junit.Test;

import com.menards.rental.domain.Item;

/**
 * Created by IntelliJ IDEA. User: deep Date: 8 Jul, 2010 Time: 2:18:56 PM To
 * change this template use File | Settings | File Templates.
 */
public class RentalDurationDoNotOverlapExistingReservationDurationReservaionRuleTest {

	/**
	 * Should return true if item has reservation that do not overlap current rental duration.
	 */
	@Test
	public void shouldReturnTrueIfItemHasReservationThatDoNotOverlapCurrentRentalDuration() {
		final Item mockedItem = mock(Item.class);
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

		when(mockedItem.hasOverlappingReservations(outDate, inDate)).thenReturn(false);

		assertTrue(new DurationDoNotOverlpReservationDurationRule().hasNoConflictingReservation(
		        mockedItem, outDate, inDate));
	}

	/**
	 * Should return false if item has reservation that do overlap current rental duration.
	 */
	@Test
	public void shouldReturnFalseIfItemHasReservationThatDoOverlapCurrentRentalDuration() {
		final Item mockedItem = mock(Item.class);
		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

		when(mockedItem.hasOverlappingReservations(outDate, inDate)).thenReturn(true);

		assertFalse(new DurationDoNotOverlpReservationDurationRule().hasNoConflictingReservation(
		        mockedItem, outDate, inDate));
	}
}
