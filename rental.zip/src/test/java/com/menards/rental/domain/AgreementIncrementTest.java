/*
 * AgreementIncrementTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.spy;
import static org.powermock.api.mockito.PowerMockito.verifyPrivate;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.whenNew;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.stub;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.utils.Constants;

/**
 * Created by IntelliJ IDEA. User: deep Date: 1 Jun, 2010 Time: 10:09:13 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest( { AgreementIncrement.class, AgreementIncrementTest.class })
public class AgreementIncrementTest {

	/**
	 * Should return the incremented agreement number for the given store number.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTheIncrementedAgreementNumberForTheGivenStoreNumber() throws Exception {
		final AgreementIncrement expectedAgreementIncrement = mock(AgreementIncrement.class);
		final Query mockedQuery = mock(Query.class);
		stub(method(AgreementIncrement.class, "findAgreementIncrementsByStoreNumber", Integer.class)).andReturn(mockedQuery);
		when(mockedQuery.getSingleResult()).thenReturn(expectedAgreementIncrement);
		when(expectedAgreementIncrement.getCurrentNumber()).thenReturn(9090);

		assertEquals(9090, AgreementIncrement.getNextAgreementNumberForStoreNumber(1234));
		verifyPrivate(expectedAgreementIncrement).invoke("incrementCurrentNumber");
		verify(expectedAgreementIncrement).persist();
	}

	/**
	 * Should persist new agreement increment if agreement increment for given store not found.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldPersistNewAgreementIncrementIfAgreementIncrementForGivenStoreNotFound() throws Exception {
		final AgreementIncrement expectedAgreementIncrement = mock(AgreementIncrement.class);
		final Query mockedQuery = mock(Query.class);
		stub(method(AgreementIncrement.class, "findAgreementIncrementsByStoreNumber", Integer.class)).andReturn(mockedQuery);
		when(mockedQuery.getSingleResult()).thenThrow(
		        new NoResultException("Could not find the store with the given number"));
		whenNew(AgreementIncrement.class).withArguments(1234).thenReturn(expectedAgreementIncrement);

		AgreementIncrement.getNextAgreementNumberForStoreNumber(1234);

		verifyPrivate(expectedAgreementIncrement).invoke("incrementCurrentNumber");
		verify(expectedAgreementIncrement).persist();
	}

	/**
	 * Should increment the current number if agreement increment for given store found.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldIncrementTheCurrentNumberIfAgreementIncrementForGivenStoreFound() throws Exception {
		final AgreementIncrement expectedAgreementIncrement = spy(new AgreementIncrement());
		expectedAgreementIncrement.setCurrentNumber(1232);
		final Query mockedQuery = mock(Query.class);
		stub(method(AgreementIncrement.class, "findAgreementIncrementsByStoreNumber", Integer.class)).andReturn(mockedQuery);
		when(mockedQuery.getSingleResult()).thenReturn(expectedAgreementIncrement);
		doNothing().when(expectedAgreementIncrement).persist();

		assertEquals(1233, AgreementIncrement.getNextAgreementNumberForStoreNumber(1234));
	}

	/**
	 * Should return the current agreement increment for newly created agreement increment.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTheCurrentAgreementIncrementForNewlyCreatedAgreementIncrement() throws Exception {
		final AgreementIncrement expectedAgreementIncrement = mock(AgreementIncrement.class);
		final Query mockedQuery = mock(Query.class);
		stub(method(AgreementIncrement.class, "findAgreementIncrementsByStoreNumber", Integer.class)).andReturn(mockedQuery);
		when(mockedQuery.getSingleResult()).thenThrow(
		        new NoResultException("Could not find the store with the given number"));
		whenNew(AgreementIncrement.class).withArguments(1234).thenReturn(expectedAgreementIncrement);
		when(expectedAgreementIncrement.getCurrentNumber()).thenReturn(9999);

		assertEquals(9999, AgreementIncrement.getNextAgreementNumberForStoreNumber(1234));
	}

	/**
	 * Verify new increment number starts with2.
	 */
	@Test
	public void verifyNewIncrementNumberStartsWith2() {
		final AgreementIncrement agreementIncrement = new AgreementIncrement(1234);

		assertEquals(Constants.Agreement.AGREEMENT_NUMBER_INITIAL_VALUE, agreementIncrement.getCurrentNumber().intValue());
	}
}
