/*
 * StoreHourBasedRentalDateRangeTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.internal.verification.VerificationModeFactory.times;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.Calendar;

import com.menards.rental.service.ContextService;
import org.junit.Test;

import com.menards.rental.service.external.StoreService;

/**
 * Created by IntelliJ IDEA. User: deep Date: 14 Jul, 2010 Time: 1:34:35 PM To
 * change this template use File | Settings | File Templates.
 */
public class StoreHourBasedRentalDateRangeTest {

	/**
	 * Should calculate actual duration in hours when lower and upper are within the store hours.
	 */
	@Test
	public void shouldCalculateActualDurationInHoursWhenLowerAndUpperAreWithinTheStoreHours() {
		final Calendar lower = Calendar.getInstance();
		final Calendar upper = Calendar.getInstance();

		updateTime(lower, new Time("08:00"));
		updateTime(upper, new Time("15:30"));

		final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);

		final StoreHour mockedStoreHours = mock(StoreHour.class);

		when(storeHourBasedRentalDateRange.getStoreHourService().getStoreHourByStoreNumber(1233)).thenReturn(mockedStoreHours);

		when(mockedStoreHours.isDateRangeWithinStoreHours(storeHourBasedRentalDateRange)).thenReturn(true);
        when(mockedStoreHours.getTotalDurationInHours(storeHourBasedRentalDateRange)).thenReturn(7.5);

		assertEquals(7.50, storeHourBasedRentalDateRange.getActualDurationInHours(), 0.01);
	}
    
	/**
	 * Should no invoke the store hours service again and again even if the method is invoked multiple times.
	 */
	@Test
	public void shouldNoInvokeTheStoreHoursServiceAgainAndAgainEvenIfTheMethodIsInvokedMultipleTimes() {
		final Calendar lower = Calendar.getInstance();
		final Calendar upper = Calendar.getInstance();

		updateTime(lower, new Time("08:00"));
		updateTime(upper, new Time("15:30"));

		final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);

		final StoreHour mockedStoreHours = mock(StoreHour.class);

		when(storeHourBasedRentalDateRange.getStoreHourService().getStoreHourByStoreNumber(1233)).thenReturn(mockedStoreHours);

		when(mockedStoreHours.isDateRangeWithinStoreHours(storeHourBasedRentalDateRange)).thenReturn(true);

		storeHourBasedRentalDateRange.getActualDurationInHours();

		verify(storeHourBasedRentalDateRange.getStoreHourService(), times(1)).getStoreHourByStoreNumber(1233);
	}

	/**
	 * Should calculate actual duration in hours when dates span for more than store hours.
	 */
	@Test
	public void shouldCalculateActualDurationInHoursWhenDatesSpanForMoreThanStoreHours() {
		final Calendar lower = Calendar.getInstance();
		final Calendar upper = Calendar.getInstance();
		upper.add(Calendar.DATE, 1);
		updateTime(lower, new Time("17:30"));
		updateTime(upper, new Time("09:30"));

		final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);

		final StoreHour mockedStoreHours = mock(StoreHour.class);

		when(storeHourBasedRentalDateRange.getStoreHourService().getStoreHourByStoreNumber(1233)).thenReturn(mockedStoreHours);
		
		when(mockedStoreHours.getTotalStoreOpenHours(lower, upper)).thenReturn(6.0);

		assertEquals(6.0, storeHourBasedRentalDateRange.getActualDurationInHours(), 0.01);
	}

	/**
	 * Should calculate actual duration in hours when dates span for more than a day and for each day12 hours should be added.
	 *//*
	@Test
	public void shouldCalculateActualDurationInHoursWhenDatesSpanForMoreThanADayAndForEachDay12HoursShouldBeAdded() {
		final Calendar lower = Calendar.getInstance();
		final Calendar upper = Calendar.getInstance();

		upper.add(Calendar.DATE, 3);
		updateTime(lower, new Time("11:30"));
		updateTime(upper, new Time("09:30"));

		final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);

		final StoreHour mockedStoreHours = mock(StoreHour.class);

		when(storeHourBasedRentalDateRange.getStoreHourService().getStoreHourByStoreNumber(1233)).thenReturn(mockedStoreHours);

		when(mockedStoreHours.getNumberOfCheckoutHours(lower)).thenReturn(10.50);
		when(mockedStoreHours.getNumberOfCheckinHours(upper)).thenReturn(1.50);

		assertEquals(36.0, storeHourBasedRentalDateRange.getActualDurationInHours(), 0.01);
	}

	*//**
	 * Should calculate actual duration in hours when dates span for more than a day and for each day12 hours should be added.
	 *//*
	@Test
	public void shouldCalculateActualDurationInHoursWhenDatesAreMoreThanADayApart() {
		final Calendar lower = Calendar.getInstance();
		final Calendar upper = Calendar.getInstance();

		upper.add(Calendar.DATE, 3);
		updateTime(lower, new Time("08:30"));
		updateTime(upper, new Time("09:30"));

		final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);

		final StoreHour mockedStoreHours = mock(StoreHour.class);

		when(storeHourBasedRentalDateRange.getStoreHourService().getStoreHourByStoreNumber(1233)).thenReturn(mockedStoreHours);

		when(mockedStoreHours.getNumberOfCheckoutHours(lower)).thenReturn(12.0);
		when(mockedStoreHours.getNumberOfCheckinHours(upper)).thenReturn(1.50);

		assertEquals(37.5, storeHourBasedRentalDateRange.getActualDurationInHours(), 0.01);
	}*/

	/**
	 * Should calculate actual duration in hours when dates don't come from a valid range.
	 */
	@Test
	public void shouldCalculateActualDurationInHoursWhenDatesDoNotFormAValidRange() {
		final Calendar lower = Calendar.getInstance();
		final Calendar upper = Calendar.getInstance();

		updateTime(lower, new Time("10:30"));
		updateTime(upper, new Time("09:30"));

		final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);

		assertEquals(-1, storeHourBasedRentalDateRange.countNumberOfFullDays());
	}

	/**
	 * Should return true if actual hours is less than the given value.
	 */
	@Test
	public void shouldReturnTrueIfActualHoursIsLessThanTheGivenValue() {
		final Calendar lower = Calendar.getInstance();
		final Calendar upper = Calendar.getInstance();

		upper.add(Calendar.DATE, 3);
		updateTime(lower, new Time("11:30"));
		updateTime(upper, new Time("09:30"));

		final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);

		final StoreHour mockedStoreHours = mock(StoreHour.class);

		when(storeHourBasedRentalDateRange.getStoreHourService().getStoreHourByStoreNumber(1233)).thenReturn(mockedStoreHours);

//		when(mockedStoreHours.getNumberOfCheckoutHours(lower)).thenReturn(10.50);
//		when(mockedStoreHours.getNumberOfCheckinHours(upper)).thenReturn(1.50);
		when(mockedStoreHours.getTotalStoreOpenHours(lower, upper)).thenReturn(43.0);

		assertTrue(storeHourBasedRentalDateRange.isActualDurationLessThan(50.0));
	}

	/**
	 * Should return false if actual hours is less than the given value.
	 */
	@Test
	public void shouldReturnFalseIfActualHoursIsLessThanTheGivenValue() {
		final Calendar lower = Calendar.getInstance();
		final Calendar upper = Calendar.getInstance();

		upper.add(Calendar.DATE, 3);
		updateTime(lower, new Time("11:30"));
		updateTime(upper, new Time("09:30"));

		final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);

		final StoreHour mockedStoreHours = mock(StoreHour.class);

		when(storeHourBasedRentalDateRange.getStoreHourService().getStoreHourByStoreNumber(1233)).thenReturn(mockedStoreHours);

//		when(mockedStoreHours.getNumberOfCheckoutHours(lower)).thenReturn(10.50);
//		when(mockedStoreHours.getNumberOfCheckinHours(upper)).thenReturn(1.50);
		when(mockedStoreHours.getTotalStoreOpenHours(lower, upper)).thenReturn(43.0);

		assertFalse(storeHourBasedRentalDateRange.isActualDurationLessThan(20.0));
	}

	/**
	 * Should return total number of full days.
	 */
	@Test
	public void shouldReturnTotalNumberOfFullDays() {
		final Calendar lower = Calendar.getInstance();
		final Calendar upper = Calendar.getInstance();

		upper.add(Calendar.DATE, 3);
		updateTime(lower, new Time("11:30"));
		updateTime(upper, new Time("09:30"));

		final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);
		assertEquals(2, storeHourBasedRentalDateRange.countNumberOfFullDays());
	}

	/**
	 * Should return total number of full when return time is later than current time days.
	 */
	@Test
	public void shouldReturnTotalNumberOfFullWhenReturnTimeIsLaterThanCurrentTimeDays() {
		final Calendar lower = Calendar.getInstance();
		final Calendar upper = Calendar.getInstance();

		upper.add(Calendar.DATE, 3);
		updateTime(lower, new Time("11:30"));
		updateTime(upper, new Time("11:31"));

		final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);
		assertEquals(2, storeHourBasedRentalDateRange.countNumberOfFullDays());
	}

    @Test
    public void shouldReturnTheTotalNumberOfFullDatesBetweenTwoDatesSeperatedByAYear() {
        final Calendar lower = Calendar.getInstance();
        final Calendar upper = Calendar.getInstance();

        upper.add(Calendar.DATE, 366);
        updateTime(lower, new Time("11:30"));
        updateTime(upper, new Time("11:31"));

        final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);
        assertEquals(365, storeHourBasedRentalDateRange.countNumberOfFullDays());
    }

    @Test
    public void shouldReturnTheTotalNumberOfFullDatesBetweenTwoDatesSeperatedByAMonth() {
        final Calendar lower = Calendar.getInstance();
        final Calendar upper = Calendar.getInstance();

        upper.add(Calendar.DATE, 35);
        updateTime(lower, new Time("11:30"));
        updateTime(upper, new Time("11:31"));

        final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);
        assertEquals(34, storeHourBasedRentalDateRange.countNumberOfFullDays());
    }

    @Test
    public void shouldReturnTheTotalNumberOfFullDatesWhenUpperDateIsOnTheNextDayLesserThanCurrentTime() {
        final Calendar lower = Calendar.getInstance();
        final Calendar upper = Calendar.getInstance();

        upper.add(Calendar.DATE, 1);
        updateTime(lower, new Time("11:30"));
        updateTime(upper, new Time("11:29"));

        final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);
        assertEquals(0, storeHourBasedRentalDateRange.countNumberOfFullDays());
    }

    @Test
    public void shouldReturnMinusOneIfTheDatesAreSame() {
        final Calendar lower = Calendar.getInstance();
        final Calendar upper = Calendar.getInstance();

        updateTime(lower, new Time("11:30"));
        updateTime(upper, new Time("12:29"));

        final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);
        assertEquals(-1, storeHourBasedRentalDateRange.countNumberOfFullDays());
    }

    @Test
    public void shouldReturnTotalFullDaysAs1IfCheckoutAndCheckinAfterAfterAndBeforeStoreHoursButOneDayIsExtraInBetween() {
        final Calendar lower = Calendar.getInstance();
        final Calendar upper = Calendar.getInstance();

        upper.add(Calendar.DATE, 2);
        updateTime(lower, new Time("22:30"));
        updateTime(upper, new Time("01:00"));

        final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = getStoreHourBasedRentalDateRange(
                lower, upper, 1233);
        assertEquals(1, storeHourBasedRentalDateRange.countNumberOfFullDays());
    }

    @Test
    public void shouldInitializeTheStoreNumberIfItsNull() {
        final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = new StoreHourBasedRentalDateRange(null, null);
        final ContextService contextService = mock(ContextService.class);
        storeHourBasedRentalDateRange.setContextService(contextService);
        storeHourBasedRentalDateRange.initializeStoreNumberIfNotDoneAlready();
        verify(contextService).applyStoreContext(storeHourBasedRentalDateRange);
    }

    @Test
    public void shouldNotInitializeTheStoreNumberIfItsNotNull() {
        final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = new StoreHourBasedRentalDateRange(null, null, 1233);
        final ContextService contextService = mock(ContextService.class);
        storeHourBasedRentalDateRange.setContextService(contextService);
        storeHourBasedRentalDateRange.initializeStoreNumberIfNotDoneAlready();
        verify(contextService, never()).applyStoreContext(storeHourBasedRentalDateRange);
    }

	/**
	 * Update time.
	 *
	 * @param calendar the calendar
	 * @param time the time
	 */
	private void updateTime(final Calendar calendar, final Time time) {
		calendar.set(Calendar.HOUR_OF_DAY, time.getHour());
		calendar.set(Calendar.MINUTE, time.getMinutes());
	}

	/**
	 * Gets the store hour based rental date range.
	 *
	 * @param lower the lower
	 * @param upper the upper
	 * @param storeNumber the store number.
     * @return the store hour based rental date range
	 */
	private StoreHourBasedRentalDateRange getStoreHourBasedRentalDateRange(final Calendar lower, final Calendar upper,
                                                                           final Integer storeNumber) {
		final StoreHourBasedRentalDateRange storeHourBasedRentalDateRange = new StoreHourBasedRentalDateRange(lower,
                upper, storeNumber);
		storeHourBasedRentalDateRange.setStoreHourService(mock(StoreService.class));
		return storeHourBasedRentalDateRange;
	}
}
