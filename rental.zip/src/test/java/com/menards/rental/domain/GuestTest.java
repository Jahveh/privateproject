/*
 * GuestTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

import com.menards.rental.builder.GuestBuilder;

/**
 * Created by IntelliJ IDEA. User: deep Date: 20 May, 2010 Time: 5:47:01 PM To
 * change this template use File | Settings | File Templates.
 */
public class GuestTest {

	/**
	 * Should return true if driver age is greater than the minimum age for a rental item.
	 */
	@Test
	public void shouldReturnTrueIfDriverAgeIsGreaterThanTheMinimumAgeForARentalItem() {
		final Guest guest = new Guest();
		final Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.YEAR, -25);
		guest.setDateOfBirth(calendar.getTime());

		assertTrue(guest.isDriverAgeGreaterThanMinimumRentalAge(24));
	}

	/**
	 * Should return true if driver age is equal to the minimum age for a rental item.
	 */
	@Test
	public void shouldReturnTrueIfDriverAgeIsEqualToTheMinimumAgeForARentalItem() {
		final Guest guest = new Guest();
		final Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.YEAR, -24);
		guest.setDateOfBirth(calendar.getTime());

		assertTrue(guest.isDriverAgeGreaterThanMinimumRentalAge(24));
	}

	/**
	 * Should return false if driver age is less than the minimum age for a rental item.
	 */
	@Test
	public void shouldReturnFalseIfDriverAgeIsLessThanTheMinimumAgeForARentalItem() {
		final Guest guest = new Guest();
		final Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.YEAR, -23);
		guest.setDateOfBirth(calendar.getTime());

		assertFalse(guest.isDriverAgeGreaterThanMinimumRentalAge(24));
	}

	/**
	 * Should return the string representation of the date.
	 */
	@Test
	public void shouldReturnTheStringRepresentationOfTheDate() {
		final Guest guest = new Guest();
		guest.setDateOfBirth(null);
		assertEquals("", guest.getDateOfBirthStr());

		final Date currentDate = Calendar.getInstance().getTime();
		guest.setDateOfBirth(currentDate);
		assertEquals(new SimpleDateFormat("MM/dd/yyyy").format(currentDate), guest.getDateOfBirthStr());
	}

	/**
	 * Should set the string date.
	 */
	@Test
	public void shouldSetTheStringDate() {
		final Guest guest = new Guest();
		final Calendar currentDate = Calendar.getInstance();
		currentDate.set(Calendar.HOUR_OF_DAY, 0);
		currentDate.set(Calendar.MINUTE, 0);
		currentDate.set(Calendar.SECOND, 0);
		currentDate.set(Calendar.MILLISECOND, 0);
		guest.setDateOfBirthStr(new SimpleDateFormat("MM/dd/yyyy").format(currentDate.getTime()));
		assertEquals(currentDate.getTime(), guest.getDateOfBirth());
	}

	/**
	 * Should copy first name.
	 */
	@Test
	public void shouldCopyFirstName() {
		final Guest guest = new Guest();
		guest.copyFrom(new GuestBuilder().withFirstName("Hello").buildGuest());
		assertEquals("Hello", guest.getFirstName());
	}

	/**
	 * Should copy last name.
	 */
	@Test
	public void shouldCopyLastName() {
		final Guest guest = new Guest();
		guest.copyFrom(new GuestBuilder().withLastName("World").buildGuest());
		assertEquals("World", guest.getLastName());
	}

	/**
	 * Should copy date of birth.
	 */
	@Test
	public void shouldCopyDateOfBirth() {
		final Guest guest = new Guest();
		final Date dateOfBirth = new Date();
		guest.copyFrom(new GuestBuilder().withDateOfBirth(dateOfBirth).buildGuest());
		assertSame(dateOfBirth, guest.getDateOfBirth());
	}

	/**
	 * Should copy phone number.
	 */
	@Test
	public void shouldCopyPhoneNumber() {
		final Guest guest = new Guest();
		guest.copyFrom(new GuestBuilder().withPhoneNumber("123-456-7890").buildGuest());
		assertEquals("123-456-7890", guest.getPhoneNumber());
	}

	/**
	 * Should copy email.
	 */
	@Test
	public void shouldCopyEmail() {
		final Guest guest = new Guest();
		guest.copyFrom(new GuestBuilder().withEmail("hi@hi.com").buildGuest());
		assertEquals("hi@hi.com", guest.getEmail());
	}

	/**
	 * Should copy company name.
	 */
	@Test
	public void shouldCopyCompanyName() {
		final Guest guest = new Guest();
		guest.copyFrom(new GuestBuilder().withCompanyName("SL").buildGuest());
		assertEquals("SL", guest.getCompanyName());
	}

    @Test
    public void shouldReturnFalseIfEmailIsNullOrBlank() {
        final Guest guest = new Guest();
        assertFalse(guest.isEmailProvided());
        guest.setEmail("");
        assertFalse(guest.isEmailProvided());
    }

    @Test
    public void shouldReturnTrueIfEmailIsProvided() {
        final Guest guest = new Guest();
        guest.setEmail("Hello@World.com");
        assertTrue(guest.isEmailProvided());
    }

    @Test
    public void shouldReturnTrueIfMaskedIdentificationValueIsNull() {
        assertTrue(new Guest().isNoIdentificationProvided());
    }

    @Test
    public void shouldReturnTrueIfMaskedIdentificationValueIsEmpty() {
        final Guest guest = new Guest();
        guest.setMaskedIdentificationNumber("");
        assertTrue(guest.isNoIdentificationProvided());
    }

    @Test
    public void shouldReturnFalseIfMaskedIdentificationValueIsNotEmpty() {
        final Guest guest = new Guest();
        guest.setMaskedIdentificationNumber("XXXX1221");
        assertFalse(guest.isNoIdentificationProvided());
    }

    @Test
    public void shouldReturnFalseIfUnMaskedIdentificationValueIsNull() {
        assertFalse(new Guest().isUnMaskedIdentificationAvailable());
    }

    @Test
    public void shouldReturnTrueIfUnMaskedIdentificationValueIsNotEmpty() {
        final Guest guest = new Guest();
        guest.setUnMaskedIdentificationNumber("902101");
        assertTrue(guest.isUnMaskedIdentificationAvailable());
    }

    @Test
    public void shouldCopyTheUnmaskedValue() {
        final Guest guest1 = new Guest();
        guest1.setUnMaskedIdentificationNumber("HelloWOrld");
        final Guest guest2 = new Guest();
        guest2.copyTransientInformationFrom(guest1);
        assertEquals("HelloWOrld", guest2.getUnMaskedIdentificationNumber());
    }
}
