package com.menards.rental.domain;

import com.menards.rental.service.external.KioskService;
import com.menards.rental.service.external.exception.KioskException;
import com.menards.rental.utils.Constants;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
public class AgreementCollectionTest {

    @Test
    public void shouldReturnListOfAgreementThatHaveReturnedItems() {
        final Agreement first = mock(Agreement.class);
        final Agreement second = mock(Agreement.class);

        final ArrayList<Agreement> agreements = new ArrayList<Agreement>();
        agreements.add(first);
        agreements.add(second);

        when(first.hasItemsThatAreReturnedButNotPaid()).thenReturn(true);
        when(second.hasItemsThatAreReturnedButNotPaid()).thenReturn(false);

        final List<Agreement> agreementsHavingReturnedItems =
                new AgreementCollection(agreements).findAgreementsThatHaveReturnedItems();

        assertEquals(1, agreementsHavingReturnedItems.size());
        assertSame(first, agreementsHavingReturnedItems.get(0));
    }

    @Test
    public void shouldCancelTheAgreements() {
        final Agreement first = mock(Agreement.class);
        final Agreement second = mock(Agreement.class);

        final ArrayList<Agreement> agreements = new ArrayList<Agreement>();
        agreements.add(first);
        agreements.add(second);

        final AgreementCollection agreementCollection = new AgreementCollection(agreements);
        agreementCollection.setKioskService(mock(KioskService.class));
        agreementCollection.cancel();

        verify(first).cancelAgreement();
        verify(second).cancelAgreement();
    }

    @Test
    public void shouldSendCancelRequestToKioskServer() {
        final Agreement first = mock(Agreement.class);
        final Agreement second = mock(Agreement.class);

        final ArrayList<Agreement> agreements = new ArrayList<Agreement>();
        agreements.add(first);
        agreements.add(second);

        final AgreementCollection agreementCollection = new AgreementCollection(agreements);
        final KioskService kioskService = mock(KioskService.class);
        agreementCollection.setKioskService(kioskService);
        agreementCollection.cancel();

        verify(kioskService).cancelAgreement(first);
        verify(kioskService).cancelAgreement(second);
    }

    @Test
    public void shouldAppendTheOverallCommentWhileCancelingTheAgreements() {
        final Agreement first = mock(Agreement.class);

        final ArrayList<Agreement> agreements = new ArrayList<Agreement>();
        agreements.add(first);

        final AgreementCollection agreementCollection = new AgreementCollection(agreements);
        agreementCollection.setKioskService(mock(KioskService.class));
        agreementCollection.cancel();

        verify(first).appendComment(Constants.Agreement.AGREEMENT_CANCELED_BY_SYSTEM_COMMENT);
    }

    @Test
    public void shouldNotThrowExceptionIfKioskServiceFailsToCancelTheAgreement() {
        final Agreement first = mock(Agreement.class);
        final Agreement second = mock(Agreement.class);

        final ArrayList<Agreement> agreements = new ArrayList<Agreement>();
        agreements.add(first);
        agreements.add(second);

        final AgreementCollection agreementCollection = new AgreementCollection(agreements);
        final KioskService kioskService = mock(KioskService.class);
        doThrow(new KioskException()).when(kioskService).cancelAgreement(first);

        agreementCollection.setKioskService(kioskService);
        agreementCollection.cancel();

        verify(second).cancelAgreement();
        verify(kioskService).cancelAgreement(second);
    }

    @Test
    public void shouldReturnTheListOfAgreementsByStoreNumber() {
        final ArrayList<Agreement> agreements = new ArrayList<Agreement>();
        final Agreement agreement1 = mock(Agreement.class);
        agreements.add(agreement1);
        final Agreement agreement2 = mock(Agreement.class);
        agreements.add(agreement2);

        when(agreement1.getStoreNumber()).thenReturn(1233);
        when(agreement2.getStoreNumber()).thenReturn(7866);

        final List<List<Agreement>> agreementsGroupedByStore = new AgreementCollection(agreements).getAgreementsGroupedByStore();
        assertEquals(2, agreementsGroupedByStore.size());
        assertEquals(1, agreementsGroupedByStore.get(0).size());
        assertEquals(1, agreementsGroupedByStore.get(1).size());
        assertTrue(agreementsGroupedByStore.get(0).contains(agreement1));
        assertTrue(agreementsGroupedByStore.get(1).contains(agreement2));
    }
}
