package com.menards.rental.domain.entity;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import org.junit.Ignore;
import org.junit.Test;

import com.menards.rental.domain.questions.QuestionCategoryMap;
import com.menards.rental.domain.questions.Quiz;

public class QuestionTest {
	@Ignore
	@Test
	public void testQuestion() {
		EntityManager em = Persistence.createEntityManagerFactory("testPU").createEntityManager();
		em.getTransaction().begin();
		Quiz question = (Quiz)em.find(Quiz.class, new Integer(1));
		List<QuestionCategoryMap> list = question.getQuestionCategoryMaps();
		System.out.println("=====================> " + question.getQuestionText());
		for (QuestionCategoryMap map : list) {
			System.out.println(map.getQuestionCategory().getCategoryName());
		}
		em.getTransaction().commit();
	}
	
	
}
