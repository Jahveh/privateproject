/*
 * ReservationsTest.java
 */
package com.menards.rental.domain;

import com.menards.rental.builder.ReservationBuilder;
import com.menards.rental.domain.strategy.MinimumItmsRequiredCalculationStrategy;
import com.menards.rental.utils.Constants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

import static junit.framework.Assert.*;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.*;

/**
 * Created by IntelliJ IDEA. User: deep Date: 8 Jul, 2010 Time: 4:00:55 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest({ReservationCollection.class, ReservationStatus.class})
public class ReservationsTest {

    /**
     * Should return true if reservations are present for the given store.
     */
    @Test
    public void shouldReturnTrueIfReservationsArePresentForTheGivenStore() {
        final Set<Reservation> reservations = new HashSet<Reservation>();

        reservations.add(mock(Reservation.class));
        final Reservation mockedReservation = mock(Reservation.class);
        reservations.add(mockedReservation);

        when(mockedReservation.isForStore(1233)).thenReturn(true);

        assertTrue(new ReservationCollection(reservations).isAnyReservationForStore(1233));
    }

    /**
     * Should return false if no reservations exist.
     */
    @Test
    public void shouldReturnFalseIfNoReservationsExist() {
        final Set<Reservation> reservations = new HashSet<Reservation>();

        assertFalse(new ReservationCollection(reservations).isAnyReservationForStore(1233));
    }

    /**
     * Should return false if reservations exist but none for the given store.
     */
    @Test
    public void shouldReturnFalseIfReservationsExistButNoneForTheGivenStore() {
        final Set<Reservation> reservations = new HashSet<Reservation>();

        reservations.add(mock(Reservation.class));
        reservations.add(mock(Reservation.class));

        assertFalse(new ReservationCollection(reservations).isAnyReservationForStore(1233));
    }

    /**
     * Should return true if reservations over lap for the given time period.
     */
    @Test
    public void shouldReturnTrueIfReservationsOverLapForTheGivenTimePeriod() {
        final Set<Reservation> reservations = new HashSet<Reservation>();

        reservations.add(mock(Reservation.class));
        final Reservation mockedReservation = mock(Reservation.class);
        reservations.add(mockedReservation);

        final Calendar outDate = Calendar.getInstance();
        final Calendar inDate = Calendar.getInstance();

        when(mockedReservation.isOverlappingForStore(1233, outDate, inDate)).thenReturn(true);

        assertTrue(new ReservationCollection(reservations).isAnyReservationOverlappingForStore(1233, outDate, inDate));
    }

    /**
     * Should return false if reservations exist but do not overlap for the given store.
     */
    @Test
    public void shouldReturnFalseIfReservationsExistButDoNotOverlapForTheGivenStore() {
        final Set<Reservation> reservations = new HashSet<Reservation>();

        reservations.add(mock(Reservation.class));
        reservations.add(mock(Reservation.class));

        assertFalse(new ReservationCollection(reservations).isAnyReservationForStore(1233));
    }

    /**
     * Should return the count using the minimum number of items required calculation strategy.
     *
     * @throws Exception the exception
     */
    @Test
    public void shouldReturnTheCountUsingTheMinimumNumberOfItemsRequiredCalculationStrategy() throws Exception {
        final List<Reservation> reservations = new ArrayList<Reservation>();

        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);
        final Reservation third = mock(Reservation.class);
        reservations.add(first);
        reservations.add(second);
        reservations.add(third);

        final Calendar outDate = Calendar.getInstance();
        final Calendar inDate = Calendar.getInstance();

        when(first.isOverlappingForStore(1233, outDate, inDate)).thenReturn(false);
        when(second.isOverlappingForStore(1233, outDate, inDate)).thenReturn(true);
        when(third.isOverlappingForStore(1233, outDate, inDate)).thenReturn(true);

        final MinimumItmsRequiredCalculationStrategy mockedStrategy = mock(MinimumItmsRequiredCalculationStrategy.class);
        whenNew(MinimumItmsRequiredCalculationStrategy.class).withArguments(
                argThat(new ArgumentMatcher<List<Reservation>>() {

                    @Override
                    public boolean matches(final Object o) {
                        final List<Reservation> reservations = (List<Reservation>) o;
                        return reservations.contains(second) && reservations.contains(third);
                    }
                })).thenReturn(mockedStrategy);

        when(mockedStrategy.count()).thenReturn(4);

        assertEquals(4, new ReservationCollection(reservations)
                .countMinimumNumberOfItemsRequiredToFulfillCurrentReservationsForAStoreForGivenDuration(1233, outDate,
                        inDate));
    }

    /**
     * Should return all the non overlapping reservations list.
     *
     * @throws Exception the exception
     */
    @Test
    public void shouldReturnAllTheNonOverlappingReservationsList() throws Exception {
        final List<Reservation> reservations = new ArrayList<Reservation>();

        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);
        final Reservation third = mock(Reservation.class);
        reservations.add(first);
        reservations.add(second);
        reservations.add(third);

        final Calendar outDate = Calendar.getInstance();
        final Calendar inDate = Calendar.getInstance();

        when(first.isOverlappingForStore(1233, outDate, inDate)).thenReturn(false);
        when(second.isOverlappingForStore(1233, outDate, inDate)).thenReturn(true);
        when(third.isOverlappingForStore(1233, outDate, inDate)).thenReturn(true);

        final MinimumItmsRequiredCalculationStrategy mockedStrategy = mock(MinimumItmsRequiredCalculationStrategy.class);
        whenNew(MinimumItmsRequiredCalculationStrategy.class).withArguments(
                argThat(new ArgumentMatcher<List<Reservation>>() {

                    @Override
                    public boolean matches(final Object o) {
                        final List<Reservation> reservations = (List<Reservation>) o;
                        return reservations.contains(second) && reservations.contains(third);
                    }
                })).thenReturn(mockedStrategy);

        final List<List<Reservation>> expectedNonOverlappingReservationsList = new ArrayList<List<Reservation>>();
        when(mockedStrategy.getNonOverlappingReservationsList()).thenReturn(expectedNonOverlappingReservationsList);

        assertSame(expectedNonOverlappingReservationsList, new ReservationCollection(reservations)
                .getNonOverlappingReservationsListForStore(1233, outDate, inDate));
    }

    /**
     * Should return list of sorted reservations.
     */
    @Test
    public void shouldReturnListOfSortedReservations() {
        final List<Reservation> reservations = new ArrayList<Reservation>();
        final Calendar older = Calendar.getInstance();
        older.add(Calendar.DATE, 2);
        final Calendar newer = Calendar.getInstance();
        newer.add(Calendar.DATE, 1);

        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        when(first.getCheckOutTimeStamp()).thenReturn(older);
        when(second.getCheckOutTimeStamp()).thenReturn(newer);

        when(first.isOpen()).thenReturn(true);
        when(second.isOpen()).thenReturn(true);

        reservations.add(first);
        reservations.add(second);

        final List<Reservation> sortedReservations = new ReservationCollection(reservations).getSortedOpenReservations();
        assertSame(newer, sortedReservations.get(0).getCheckOutTimeStamp());
        assertSame(older, sortedReservations.get(1).getCheckOutTimeStamp());
    }

    /**
     * Should return list of sorted open reservations.
     */
    @Test
    public void shouldReturnListOfSortedOpenReservations() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Calendar older = Calendar.getInstance();
        older.add(Calendar.DATE, 2);
        final Calendar newer = Calendar.getInstance();
        newer.add(Calendar.DATE, 1);

        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        when(first.getCheckOutTimeStamp()).thenReturn(older);
        when(second.getCheckOutTimeStamp()).thenReturn(newer);

        when(first.isOpen()).thenReturn(false);
        when(second.isOpen()).thenReturn(true);

        reservations.add(first);
        reservations.add(second);

        final List<Reservation> sortedReservations = new ReservationCollection(reservations).getSortedOpenReservations();
        assertEquals(1, sortedReservations.size());
        assertSame(newer, sortedReservations.get(0).getCheckOutTimeStamp());
    }

    /**
     * Should return the first checkout date of the reservations list.
     */
    @Test
    public void shouldReturnTheFirstCheckoutDateOfTheReservationsList() {
        final Calendar newer = Calendar.getInstance();
        newer.add(Calendar.DATE, 1);
        final Calendar older = Calendar.getInstance();
        older.add(Calendar.DATE, 2);

        final List<Reservation> reservations = new ArrayList<Reservation>();
        reservations.add(new ReservationBuilder().withCheckoutTimeStamp(newer).buildReservation());
        reservations.add(new ReservationBuilder().withCheckoutTimeStamp(older).buildReservation());

        assertEquals(newer, new ReservationCollection(reservations).getFirstCheckouDate());
    }

    /**
     * Should return open reservations for given store.
     */
    @Test
    public void shouldReturnOpenReservationsForGivenStore() {
        final List<Reservation> reservations = new ArrayList<Reservation>();
        final Calendar older = Calendar.getInstance();
        older.add(Calendar.DATE, 2);
        final Calendar newer = Calendar.getInstance();
        newer.add(Calendar.DATE, 1);

        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        when(first.getCheckOutTimeStamp()).thenReturn(older);
        when(second.getCheckOutTimeStamp()).thenReturn(newer);

        when(first.isOpen()).thenReturn(false);
        when(second.isOpen()).thenReturn(true);
        when(first.isForStore(1233)).thenReturn(true);
        when(second.isForStore(1233)).thenReturn(true);

        reservations.add(first);
        reservations.add(second);

        final List<Reservation> openReservationsForStore = new ReservationCollection(reservations).getOpenReservationsFor(1233);
        assertEquals(1, openReservationsForStore.size());
        assertSame(second, openReservationsForStore.get(0));
    }

    /**
     * Should return open reservations for if store number passed matches.
     */
    @Test
    public void shouldReturnOpenReservationsForIfStoreNumberPassedMatches() {
        final List<Reservation> reservations = new ArrayList<Reservation>();
        final Calendar older = Calendar.getInstance();
        older.add(Calendar.DATE, 2);
        final Calendar newer = Calendar.getInstance();
        newer.add(Calendar.DATE, 1);

        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        when(first.getCheckOutTimeStamp()).thenReturn(older);
        when(second.getCheckOutTimeStamp()).thenReturn(newer);

        when(first.isOpen()).thenReturn(true);
        when(second.isOpen()).thenReturn(true);
        when(first.isForStore(1233)).thenReturn(true);
        when(second.isForStore(1233)).thenReturn(false);

        reservations.add(first);
        reservations.add(second);

        final List<Reservation> openReservationsForStore = new ReservationCollection(reservations).getOpenReservationsFor(1233);
        assertEquals(1, openReservationsForStore.size());
        assertSame(first, openReservationsForStore.get(0));
    }

    /**
     * Should get the open reservations for the current store.
     */
    @Test
    public void shouldGetTheOpenReservationsForTheCurrentStore() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        reservations.add(mock(Reservation.class));
        reservations.add(first);
        reservations.add(second);

        for (final Reservation reservation : reservations) {
            when(reservation.isForStore(1233)).thenReturn(true);
        }

        when(first.isOpen()).thenReturn(true);
        when(second.isOpen()).thenReturn(true);

        final Calendar outDate = Calendar.getInstance();
        final Calendar inDate = Calendar.getInstance();
        when(first.isOverlappingForStore(1233, outDate, inDate)).thenReturn(true);
        when(second.isOverlappingForStore(1233, outDate, inDate)).thenReturn(true);

        final List<Reservation> openReservations = new ReservationCollection(reservations).getOverlappingOpenReservationsForStore(
                1233, outDate, inDate);
        assertEquals(2, openReservations.size());
        assertTrue(openReservations.contains(first));
        assertTrue(openReservations.contains(second));
    }

    /**
     * Should get the reservations for current store only.
     */
    @Test
    public void shouldGetTheReservationsForCurrentStoreOnly() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        final Reservation third = mock(Reservation.class);
        reservations.add(third);
        reservations.add(first);
        reservations.add(second);

        when(first.isForStore(1233)).thenReturn(true);
        when(second.isForStore(1233)).thenReturn(true);

        when(first.isOpen()).thenReturn(true);
        when(second.isOpen()).thenReturn(true);
        when(third.isOpen()).thenReturn(true);

        final Calendar outDate = Calendar.getInstance();
        final Calendar inDate = Calendar.getInstance();
        when(first.isOverlappingForStore(1233, outDate, inDate)).thenReturn(true);
        when(second.isOverlappingForStore(1233, outDate, inDate)).thenReturn(true);

        final List<Reservation> openReservations = new ReservationCollection(reservations).getOverlappingOpenReservationsForStore(
                1233, outDate, inDate);
        assertEquals(2, openReservations.size());
        assertTrue(openReservations.contains(first));
        assertTrue(openReservations.contains(second));
    }

    /**
     * Should get the open and overlapping reservations for current store only.
     */
    @Test
    public void shouldGetTheOpenAndOverlappingReservationsForCurrentStoreOnly() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        reservations.add(first);
        reservations.add(second);

        when(first.isForStore(1233)).thenReturn(true);
        when(second.isForStore(1233)).thenReturn(true);

        when(first.isOpen()).thenReturn(true);
        when(second.isOpen()).thenReturn(true);

        final Calendar outDate = Calendar.getInstance();
        final Calendar inDate = Calendar.getInstance();
        when(first.isOverlappingForStore(1233, outDate, inDate)).thenReturn(true);
        when(second.isOverlappingForStore(1233, outDate, inDate)).thenReturn(false);

        final List<Reservation> openReservations = new ReservationCollection(reservations).getOverlappingOpenReservationsForStore(
                1233, outDate, inDate);
        assertEquals(1, openReservations.size());
        assertTrue(openReservations.contains(first));
    }

    /**
     * Should remove the reservation for the given product id.
     */
    @Test
    public void shouldRemoveTheReservationForTheGivenProductId() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        when(first.isForProduct(1233L)).thenReturn(true);
        when(second.isForProduct(1233L)).thenReturn(false);

        reservations.add(first);
        reservations.add(second);

        new ReservationCollection(reservations).removeReservationFor(1233L);

        assertEquals(1, reservations.size());
        assertTrue(reservations.contains(second));
    }

    /**
     * Should return true if reservations exists for the choosen product.
     */
    @Test
    public void shouldReturnTrueIfReservationsExistsForTheChoosenProduct() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        when(first.isForProduct(1233L)).thenReturn(true);
        when(second.isForProduct(1233L)).thenReturn(false);

        reservations.add(first);
        reservations.add(second);

        final Product product = new Product();
        product.setId(1233L);

        assertTrue(new ReservationCollection(reservations).isReservationPresentFor(product));
    }

    /**
     * Should return flase if reservations does not exists for the choosen product.
     */
    @Test
    public void shouldReturnFlaseIfReservationsDoesNotExistsForTheChoosenProduct() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        when(first.isForProduct(1233L)).thenReturn(false);
        when(second.isForProduct(1233L)).thenReturn(false);

        reservations.add(first);
        reservations.add(second);

        final Product product = new Product();
        product.setId(1233L);

        assertFalse(new ReservationCollection(reservations).isReservationPresentFor(product));
    }

    /**
     * Should update the status of all the reservations.
     */
    @Test
    public void shouldUpdateTheStatusOfAllTheReservations() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        reservations.add(first);
        reservations.add(second);

        when(first.isOpen()).thenReturn(true);
        when(second.isOpen()).thenReturn(true);

        final ReservationStatus expectedStatus = new ReservationStatus();
        mockStatic(ReservationStatus.class);
        when(ReservationStatus.findCancelled()).thenReturn(expectedStatus);

        new ReservationCollection(reservations).cancel();

        verify(first).setStatus(expectedStatus);
        verify(second).setStatus(expectedStatus);
    }

    /**
     * Should update the status of only the open reservations.
     */
    @Test
    public void shouldUpdateTheStatusOfOnlyTheOpenReservations() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        reservations.add(first);
        reservations.add(second);

        when(first.isOpen()).thenReturn(true);
        when(second.isOpen()).thenReturn(false);

        final ReservationStatus expectedStatus = new ReservationStatus();
        mockStatic(ReservationStatus.class);
        when(ReservationStatus.findCancelled()).thenReturn(expectedStatus);

        new ReservationCollection(reservations).cancel();

        verify(first).setStatus(expectedStatus);
        verify(second, never()).setStatus(expectedStatus);
    }

    /**
     * Should find the reservation with the matching id.
     */
    @Test
    public void shouldFindTheReservationWithTheMatchingId() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        reservations.add(first);
        reservations.add(second);

        when(first.getId()).thenReturn(1233L);
        when(second.getId()).thenReturn(7866L);

        assertSame(second, new ReservationCollection(reservations).findReservationById(7866L));
    }

    /**
     * Should return true if any reservation is open.
     */
    @Test
    public void shouldReturnTrueIfAnyReservationIsOpen() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        reservations.add(first);
        reservations.add(second);

        when(first.isOpen()).thenReturn(false);
        when(second.isOpen()).thenReturn(true);

        assertTrue(new ReservationCollection(reservations).isAnyReservationOpen());
    }

    /**
     * Should return false if none of the reservations are open.
     */
    @Test
    public void shouldReturnFalseIfNoneOfTheReservationsAreOpen() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        reservations.add(first);
        reservations.add(second);

        when(first.isOpen()).thenReturn(false);
        when(second.isOpen()).thenReturn(false);

        assertFalse(new ReservationCollection(reservations).isAnyReservationOpen());
    }

    @Test
    public void shouldReturnTheCSVOfAllTheCheckoutDates() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        reservations.add(first);
        reservations.add(second);

        final Calendar firstCheckout = Calendar.getInstance();
        final Calendar secondCheckout = Calendar.getInstance();

        when(first.getCheckOutTimeStamp()).thenReturn(firstCheckout);
        when(second.getCheckOutTimeStamp()).thenReturn(secondCheckout);

        assertEquals(new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT).format(firstCheckout.getTime())
                + ","
                + new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT).format(secondCheckout.getTime()),
                new ReservationCollection(reservations).getCSVCheckoutDates());
    }

    @Test
    public void shouldReturnEmptyStringIfNoReservationsExist() {
        final Set<Reservation> reservations = new HashSet<Reservation>();

        assertEquals("", new ReservationCollection(reservations).getCSVCheckoutDates());
    }

    @Test
    public void shouldReturnTotalEstimatedChargeAmount() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        reservations.add(first);
        reservations.add(second);

        when(first.getTotalEstimatedChargeAmountPlusSurchargeAmount()).thenReturn(new BigDecimal("10.8"));
        when(second.getTotalEstimatedChargeAmountPlusSurchargeAmount()).thenReturn(new BigDecimal("3.6"));

        assertEquals(10.8+3.6, new ReservationCollection(reservations).getTotalEstimatedChargeAmount().doubleValue(), 0.001);
    }

    @Test
    public void shouldReturnTotalEstimatedDamageWaiverAmount() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        reservations.add(first);
        reservations.add(second);

        when(first.getEstimatedDamageWaiver()).thenReturn(new BigDecimal("1.8"));
        when(second.getEstimatedDamageWaiver()).thenReturn(new BigDecimal(".36"));

        assertEquals(1.8+.36, new ReservationCollection(reservations).getTotalDamageWaiver().doubleValue(), 0.001);
    }

    @Test
    public void shouldReturnTrueIfGuestAgeIsGreaterThanTheMinimumRentalAgeForAllProducts() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        reservations.add(first);
        reservations.add(second);

        final Guest guest = new Guest();
        when(first.isGuestAgeGreaterThanMinimumAge(guest)).thenReturn(true);
        when(second.isGuestAgeGreaterThanMinimumAge(guest)).thenReturn(true);

        assertTrue(new ReservationCollection(reservations).isGuestAgeGreaterThanMinimumAge(guest));
    }

    @Test
    public void shouldReturnFlaseIfGuestAgeIsLessThanTheMinimumRentalAgeAtleastOneProducts() {
        final Set<Reservation> reservations = new HashSet<Reservation>();
        final Reservation first = mock(Reservation.class);
        final Reservation second = mock(Reservation.class);

        reservations.add(first);
        reservations.add(second);

        final Guest guest = new Guest();
        when(first.isGuestAgeGreaterThanMinimumAge(guest)).thenReturn(true);
        when(second.isGuestAgeGreaterThanMinimumAge(guest)).thenReturn(false);

        assertFalse(new ReservationCollection(reservations).isGuestAgeGreaterThanMinimumAge(guest));
    }
}
