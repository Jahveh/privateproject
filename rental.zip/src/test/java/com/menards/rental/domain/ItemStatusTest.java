/*
 * ItemStatusTest.java
 */
package com.menards.rental.domain;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import java.util.ArrayList;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.stub;

/**
 * Created by IntelliJ IDEA. User: deep Date: 2 Jun, 2010 Time: 9:51:32 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest(ItemStatus.class)
public class ItemStatusTest {

    /**
     * Should return the available item status.
     */
    public void shouldReturnTheAvailableItemStatus() {
        final Query mockedQuery = mock(Query.class);
        stub(method(ItemStatus.class, "findItemStatusesByStatusCode", String.class)).andReturn(mockedQuery);

        final ItemStatus expectedItemStatus = new ItemStatus();
        when(mockedQuery.getSingleResult()).thenReturn(expectedItemStatus);

        assertSame(expectedItemStatus, ItemStatus.findAvailable());
    }

    /**
     * Should return the on host item status.
     */
    public void shouldReturnTheOnHostItemStatus() {
        final Query mockedQuery = mock(Query.class);
        stub(method(ItemStatus.class, "findItemStatusesByStatusCode", String.class)).andReturn(mockedQuery);

        final ItemStatus expectedItemStatus = new ItemStatus();
        when(mockedQuery.getSingleResult()).thenReturn(expectedItemStatus);

        assertSame(expectedItemStatus, ItemStatus.findOnHold());
    }

    /**
     * Should return true if item status is available.
     */
    @Test
    public void shouldReturnTrueIfItemStatusIsAvailable() {
        final ItemStatus itemStatus = new ItemStatus();
        itemStatus.setStatusCode(ItemStatus.Code.AVAILABLE.getCode());

        assertTrue(itemStatus.isAvailable());
    }

    /**
     * Should return false if item status is null.
     */
    @Test
    public void shouldReturnFalseIfItemStatusIsNull() {
        final ItemStatus itemStatus = new ItemStatus();

        assertFalse(itemStatus.isAvailable());
    }

    /**
     * Should return true if item status is any thing other than available.
     */
    @Test
    public void shouldReturnTrueIfItemStatusIsAnyThingOtherThanAvailable() {
        final ItemStatus itemStatus = new ItemStatus();

        assertFalse(itemStatus.isAvailable());
    }

    @Ignore
    @Test
    public void shouldReturnListOfRentableStates() {
        final EntityManager entityManager = mock(EntityManager.class);
        stub(method(ItemStatus.class, "entityManager", null)).andReturn(entityManager);

        final Query query = mock(Query.class);
        when(entityManager.createQuery("select s from ItemStatus s where s.statusCode in ('A', 'H', 'R')"))
                .thenReturn(query);

        final ArrayList<ItemStatus> itemStatuses = new ArrayList<ItemStatus>();
        when(query.getResultList()).thenReturn(itemStatuses);

        assertSame(itemStatuses, ItemStatus.findAllRentableStatuses());
    }
}
