/*
 * DamageWaiverTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;

import java.math.BigDecimal;

import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: deep Date: 2 Jun, 2010 Time: 7:53:55 AM To
 * change this template use File | Settings | File Templates.
 */
public class DamageWaiverTest {

	/**
	 * Should reset the value of amount if the is declined flag is set.
	 */
	@Test
	public void shouldResetTheValueOfAmountIfTheIsDeclinedFlagIsSet() {
		final DamageWaiver damageWaiver = new DamageWaiver(false, new BigDecimal("10.0"));
		damageWaiver.merge(new DamageWaiver(true, new BigDecimal("90.0")), null);

		assertEquals(0.0, damageWaiver.getAmount().doubleValue());
		assertTrue(damageWaiver.isDeclined());
	}

	/**
	 * Should set the value of amount to default value if the is declined flag is not set.
	 */
	@Test
	public void shouldSetTheValueOfAmountToDefaultValueIfTheIsDeclinedFlagIsNotSet() {
		final DamageWaiver damageWaiver = new DamageWaiver(true, new BigDecimal("10.0"));
		damageWaiver.merge(new DamageWaiver(false, new BigDecimal("90.0")), new BigDecimal("8.1"));

		assertEquals(0.81, damageWaiver.getAmount().doubleValue(), 0.001);
		assertFalse(damageWaiver.isDeclined());
	}

	/**
	 * Should calculate the damage waiver amount.
	 */
	@Test
	public void shouldCalculateTheDamageWaiverAmount() {
		final DamageWaiver damageWaiver = new DamageWaiver();
		damageWaiver.calculate(new BigDecimal("2.7"));

		assertEquals(new BigDecimal("0.27").doubleValue(), damageWaiver.getAmount().doubleValue(), 0.001);
	}

	/**
	 * Should update the damage waiver charges to zero if guest has declined to pay the damage waiver charges.
	 */
	@Test
	public void shouldUpdateTheDamageWaiverChargesToZeroIfGuestHasDeclinedToPayTheDamageWaiverCharges() {
		final DamageWaiver damageWaiver = new DamageWaiver();
		damageWaiver.setDeclined(true);
		damageWaiver.setAmount(new BigDecimal("9"));

		damageWaiver.calculate(new BigDecimal("8.1"));

		assertEquals(new BigDecimal("0").doubleValue(), damageWaiver.getAmount().doubleValue(), 0.001);
	}
}
