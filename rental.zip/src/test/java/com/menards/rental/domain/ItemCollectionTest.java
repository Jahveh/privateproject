package com.menards.rental.domain;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
public class ItemCollectionTest {

    @Test
    public void shouldReturnCountOfItemsThatAreAvailable() {
        final ArrayList<Item> items = new ArrayList<Item>();
        final Item first = mock(Item.class);
        final Item second = mock(Item.class);
        final Item third = mock(Item.class);
        items.add(first);
        items.add(second);
        items.add(third);

        when(first.isAvailable()).thenReturn(false);
        when(second.isAvailable()).thenReturn(true);
        when(third.isAvailable()).thenReturn(true);

        assertEquals(2, new ItemCollection(items).countAvailable());
    }

    @Test
    public void shouldReturnASortedListOfItemsBySerialNumber() {
        final ArrayList<Item> items = new ArrayList<Item>();
        final Item first = mock(Item.class);
        final Item second = mock(Item.class);
        final Item third = mock(Item.class);
        items.add(first);
        items.add(second);
        items.add(third);

        when(first.getSerialNumber()).thenReturn(1233L);
        when(second.getSerialNumber()).thenReturn(7866L);
        when(third.getSerialNumber()).thenReturn(4455L);

        final List<Item> sortedItems = new ItemCollection(items).getSortedListBySerialNumber();

        assertSame(first, sortedItems.get(0));
        assertSame(third, sortedItems.get(1));
        assertSame(second, sortedItems.get(2));
    }
}
