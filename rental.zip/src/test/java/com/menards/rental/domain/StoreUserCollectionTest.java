package com.menards.rental.domain;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.AssertFalse;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
public class StoreUserCollectionTest {

    @Test
    public void shouldReturnTheListOfStringsThatRepresentTheUserNames() {
        final ArrayList<StoreUserInfo> storeUsers = new ArrayList<StoreUserInfo>();
        final StoreUserInfo storeUserInfo1 = new StoreUserInfo();
        final StoreUserInfo storeUserInfo2 = new StoreUserInfo();
        final StoreUserInfo storeUserInfo3 = new StoreUserInfo();
        storeUserInfo1.setName("N1");
        storeUserInfo1.setPosition("GM");
        storeUserInfo2.setName("N2");
        storeUserInfo2.setPosition("PM");
        storeUserInfo3.setName("N3");
        storeUserInfo3.setPosition("AGM");
        storeUsers.add(storeUserInfo1);
        storeUsers.add(storeUserInfo2);
        storeUsers.add(storeUserInfo3);
        final List<StoreUserInfo> userNames = new StoreUserCollection(storeUsers, 1233).getGeneralManagers();
        assertEquals(2, userNames.size());
        assertTrue(userNames.contains(storeUserInfo1));
        assertFalse(userNames.contains(storeUserInfo2));
        assertTrue(userNames.contains(storeUserInfo3));
    }

    @Test
    public void shouldFindTheMatchingStoreUserByTheUserId() {
        final ArrayList<StoreUserInfo> storeUsers = new ArrayList<StoreUserInfo>();
        final StoreUserInfo storeUserInfo1 = new StoreUserInfo();
        final StoreUserInfo storeUserInfo2 = new StoreUserInfo();
        storeUserInfo1.setName("N1");
        storeUserInfo1.setPosition("GM");
        storeUserInfo1.setId(1233);
        storeUserInfo2.setName("N2");
        storeUserInfo2.setPosition("PM");
        storeUserInfo2.setId(7866);
        storeUsers.add(storeUserInfo1);
        storeUsers.add(storeUserInfo2);
        assertSame(storeUserInfo2, new StoreUserCollection(storeUsers, 1233).getStoreUserById(7866));
    }
}
