/*
 * DifferenceOfValueAndBaseHoursWithRoundingIncrementalHoursCalculationRuleTest.java
 */
package com.menards.rental.domain.rule;

import static junit.framework.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.whenNew;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.domain.StoreHourBasedRentalDateRange;
import com.menards.rental.domain.strategy.Max12HoursPerDayRoundingStrategy;

/**
 * Created by IntelliJ IDEA. User: deep Date: 14 Jul, 2010 Time: 3:55:40 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest(DiffOfValAndBaseHrsWithRndIncreHrsCalcRule.class)
public class DiffOfValAndBaseHrsWithRndIncreHrsCalcRuleTest {

	/**
	 * Should return rounded value using the max12 hours per day rounding strategy.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnRoundedValueUsingTheMax12HoursPerDayRoundingStrategy() throws Exception {
		final Max12HoursPerDayRoundingStrategy max12HoursPerDayRoundingStrategy = mock(Max12HoursPerDayRoundingStrategy.class);
		whenNew(Max12HoursPerDayRoundingStrategy.class).withNoArguments().thenReturn(max12HoursPerDayRoundingStrategy);

		when(max12HoursPerDayRoundingStrategy.calculateRoundedIncrementalHoursAfterSubtractingBaseHours(4, 1, 14.0))
		        .thenReturn(8.0);

		assertEquals(8.0, new DiffOfValAndBaseHrsWithRndIncreHrsCalcRule(4, 1,
		        getMockedRentalDateRange(14.0)).calculate());
	}

	/**
	 * Should return rounded value using the max12 hours per day rounding strategy if total is less than12.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnRoundedValueUsingTheMax12HoursPerDayRoundingStrategyIfTotalIsLessThan12() throws Exception {
		final Max12HoursPerDayRoundingStrategy max12HoursPerDayRoundingStrategy = mock(Max12HoursPerDayRoundingStrategy.class);
		whenNew(Max12HoursPerDayRoundingStrategy.class).withNoArguments().thenReturn(max12HoursPerDayRoundingStrategy);

		when(max12HoursPerDayRoundingStrategy.calculateRoundedIncrementalHoursAfterSubtractingBaseHours(4.5, 1.8, 8.1))
		        .thenReturn(4.5);

		assertEquals(4.5, new DiffOfValAndBaseHrsWithRndIncreHrsCalcRule(4.5, 1.8,
		        getMockedRentalDateRange(8.1)).calculate());
	}

	/**
	 * Gets the mocked rental date range.
	 *
	 * @param actualDurationInHours the actual duration in hours
	 * @return the mocked rental date range
	 */
	private StoreHourBasedRentalDateRange getMockedRentalDateRange(final double actualDurationInHours) {
		final StoreHourBasedRentalDateRange rentalDateRange = mock(StoreHourBasedRentalDateRange.class);
		when(rentalDateRange.getActualDurationInHours()).thenReturn(actualDurationInHours);
		return rentalDateRange;
	}
}
