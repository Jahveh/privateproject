/*
 * AgreementStatusTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertTrue;

import org.junit.Test;

/**
 * User: deep Date: 18 Jun, 2010 Time: 5:18:25 PM.
 */
public class AgreementStatusTest {

	/**
	 * Should return true if code is pending.
	 */
	@Test
	public void shouldReturnTrueIfCodeIsPending() {
		final AgreementStatus agreementStatus = new AgreementStatus('P');
		assertTrue(agreementStatus.isPending());
	}

	/**
	 * Should return true if code is active.
	 */
	@Test
	public void shouldReturnTrueIfCodeIsActive() {
		final AgreementStatus agreementStatus = new AgreementStatus('A');
		assertTrue(agreementStatus.isActive());
	}

	/**
	 * Should return true if code is completed.
	 */
	@Test
	public void shouldReturnTrueIfCodeIsCompleted() {
		final AgreementStatus agreementStatus = new AgreementStatus('C');
		assertTrue(agreementStatus.isCompleted());
	}

	/**
	 * Should return true if code is voided.
	 */
	@Test
	public void shouldReturnTrueIfCodeIsVoided() {
		final AgreementStatus agreementStatus = new AgreementStatus('V');
		assertTrue(agreementStatus.isVoided());
	}

	/**
	 * Should return true if code is cancelled.
	 */
	@Test
	public void shouldReturnTrueIfCodeIsCancelled() {
		final AgreementStatus agreementStatus = new AgreementStatus('N');
		assertTrue(agreementStatus.isCancelled());
	}

}
