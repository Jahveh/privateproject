/*
 * StoreTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Created by IntelliJ IDEA. User: deep Date: 20 Jul, 2010 Time: 12:01:49 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest(Store.class)
public class StoreTest {

	/*
	 * @Test public void shouldFindActiveStoreByStoreNumber() { final Store
	 * expectedStore = new Store(); final Query mockedQuery = mock(Query.class);
	 * stub(method(Store.class, "findStoresByStoreNumberAndIsActive",
	 * Integer.class, Boolean.class)) .andReturn(mockedQuery);
	 * 
	 * when(mockedQuery.getSingleResult()).thenReturn(expectedStore);
	 * 
	 * assertSame(expectedStore, Store.findActiveStoreByStoreNumber(1233)); }
	 */
	/**
	 * Should return true if the store number matches.
	 */
	@Test
	public void shouldReturnTrueIfTheStoreNumberMatches() {
		final Store store = new Store();
		store.setStoreNumber(1233);
		assertTrue(store.isMatching(1233));
	}

	/**
	 * Should return false if the store number does not match.
	 */
	@Test
	public void shouldReturnFalseIfTheStoreNumberDoesNotMatch() {
		final Store store = new Store();
		store.setStoreNumber(7866);
		assertFalse(store.isMatching(1233));

	}
}
