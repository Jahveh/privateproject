/*
 * ReservationStatusTest.java
 */
package com.menards.rental.domain;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.stub;

import javax.persistence.Query;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Created by IntelliJ IDEA. User: deep Date: 22 Jul, 2010 Time: 11:54:27 AM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest(ReservationStatus.class)
public class ReservationStatusTest {

	/**
	 * Should return true if code is open.
	 */
	@Test
	public void shouldReturnTrueIfCodeIsOpen() {
		final ReservationStatus reservationStatus = new ReservationStatus();
		reservationStatus.setCode("O");
		assertTrue(reservationStatus.isOpen());
	}

	/**
	 * Should return false if code is not open.
	 */
	@Test
	public void shouldReturnFalseIfCodeIsNotOpen() {
		final ReservationStatus reservationStatus = new ReservationStatus();
		reservationStatus.setCode("F");
		assertFalse(reservationStatus.isOpen());
	}

	/**
	 * Should return true if code is fulflled.
	 */
	@Test
	public void shouldReturnTrueIfCodeIsFulflled() {
		final ReservationStatus reservationStatus = new ReservationStatus();
		reservationStatus.setCode("F");
		assertTrue(reservationStatus.isFulfilled());
	}

	/**
	 * Should return false if code is not fulfilled.
	 */
	@Test
	public void shouldReturnFalseIfCodeIsNotFulfilled() {
		final ReservationStatus reservationStatus = new ReservationStatus();
		reservationStatus.setCode("C");
		assertFalse(reservationStatus.isFulfilled());
	}

	/**
	 * Should return true if code is cancelled.
	 */
	@Test
	public void shouldReturnTrueIfCodeIsCancelled() {
		final ReservationStatus reservationStatus = new ReservationStatus();
		reservationStatus.setCode("C");
		assertTrue(reservationStatus.isCancelled());
	}

	/**
	 * Should return false if code is not cancelled.
	 */
	@Test
	public void shouldReturnFalseIfCodeIsNotCancelled() {
		final ReservationStatus reservationStatus = new ReservationStatus();
		reservationStatus.setCode("O");
		assertFalse(reservationStatus.isCancelled());
	}

	/**
	 * Should return the open status code.
	 */
	@Test
	public void shouldReturnTheOpenStatusCode() {
		final Query mockedQuery = mock(Query.class);
		stub(method(ReservationStatus.class, "findReservationStatusesByCode", String.class)).andReturn(mockedQuery);

		final ReservationStatus expectedStuats = new ReservationStatus();
		when(mockedQuery.getSingleResult()).thenReturn(expectedStuats);

		assertSame(expectedStuats, ReservationStatus.findOpen());
	}
}
