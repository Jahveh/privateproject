package com.menards.rental.domain;

import org.apache.commons.codec.binary.Base64;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Calendar;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
public class GuestArchiveInfoTest {

    @Test
    @Ignore("This is the test case that can give us the base 64 encoded value of any image.")
    public void shouldEncodeTheSignatureImage() throws IOException {
        BufferedImage img = ImageIO.read(new ClassPathResource("signature.bmp").getInputStream());
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "bmp", baos);
        baos.flush();
        String encodedImage = Base64.encodeBase64String(baos.toByteArray());
        baos.close(); // should be inside a finally block
        System.out.println(encodedImage);

        byte[] bytes = Base64.decodeBase64(encodedImage);
        BufferedImage image = ImageIO.read(new ByteArrayInputStream(bytes));
    }

    @Test
    public void shouldDecodeTheImage() {
        assertNotNull(new GuestArchiveInfo("400100001", Calendar.getInstance(), new Store(), "Signature",
                "Legal", "S:    1118465\n" +
                        "S:   66786944\n" +
                        "S:   84934994\n" +
                        "S:  549487614\n" +
                        "S:-2096356792\n" +
                        "S:-2025996280\n" +
                        "S:- 545661057\n" +
                        "S:-  18308741\n" +
                        "S:  404884528\n" +
                        "S:- 264863616\n" +
                        "S:- 134066429\n" +
                        "S:  571220160\n" +
                        "S:-  15842280\n" +
                        "S:  822014082\n" +
                        "S: 1122517512\n" +
                        "S:- 268203983\n" +
                        "S: 1107832826\n" +
                        "S:  186746392\n" +
                        "S:- 264642430\n" +
                        "S:-2147467276\n" +
                        "S:  136547377\n" +
                        "S:-1645015304\n" +
                        "S:-1942978320\n" +
                        "S:  532152386\n" +
                        "S:-2011675764\n" +
                        "S:- 396261615\n" +
                        "S:-2088301254\n" +
                        "S:      49400\n" +
                        "S:          0").getSignatureData());
    }

    @Test
    public void shouldReturnNullIfGuestSignatureIsNullOrEmpty() {
        assertNull(new GuestArchiveInfo("400100001", Calendar.getInstance(), new Store(),
                "Signature", "Legal", "").getSignatureData());
        assertNull(new GuestArchiveInfo("400100001", Calendar.getInstance(), new Store(),
                "Signature", "Legal", null).getSignatureData());
    }
}
