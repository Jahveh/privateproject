/*
 * ItemWillBeAvaliableAtEveryOverlappingReservationPeriodReservationRuleTest.java
 */
package com.menards.rental.domain.rule;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.whenNew;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.Item;
import com.menards.rental.domain.ItemStatus;
import com.menards.rental.domain.Product;
import com.menards.rental.domain.Reservation;
import com.menards.rental.domain.ReservationCollection;

/**
 * Created by IntelliJ IDEA. User: deep Date: 8 Jul, 2010 Time: 6:47:13 PM To
 * change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = { "org.apache.log4j.*" })
@PrepareForTest( { Item.class, ItemStatus.class, AgreementItem.class,
        ItemAvailableAtOverlappingReservationRule.class })
public class ItemAvailableAtOverlappingReservationRuleTest {
	
	/** The reservation rule. */
	private ItemAvailableAtOverlappingReservationRule reservationRule;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		reservationRule = new ItemAvailableAtOverlappingReservationRule();
	}

	/**
	 * Should return true if one item will be returned before the first reservation starts and there is just one overlapping reservation.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTrueIfOneItemWillBeReturnedBeforeTheFirstReservationStartsAndThereIsJustOneOverlappingReservation()
	        throws Exception {
		final Item mockedItem = getMockedItem();

		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

		mockNonOverlappingReservations(mockedItem, outDate, inDate, 1);

		final ItemStatus itemStatus = new ItemStatus();

		mockItemStatus(itemStatus);

		mockStatic(Item.class);
		when(
		        Item.findAllItemsByStoreNumberAndProductAndItemStatus(mockedItem.getStoreNumber(), mockedItem.getProduct(),
		                itemStatus)).thenReturn(new ArrayList<Item>());

		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
		whenNew(ReservationCollection.class).withArguments(mockedItem.getNonOverlappingReservationsList(outDate, inDate).get(0))
		        .thenReturn(mockedReservations);
		final Calendar firstCheckoutDate = Calendar.getInstance();
		when(mockedReservations.getFirstCheckouDate()).thenReturn(firstCheckoutDate);

		final List<AgreementItem> itemsReturnedBeforeFirstReservation = new ArrayList<AgreementItem>();
		itemsReturnedBeforeFirstReservation.add(new AgreementItem());

		mockStatic(AgreementItem.class);
		when(
		        AgreementItem.findAllOpenAgreementItemsByProductHavingDueByDateLessThan(mockedItem.getProduct(),
		                firstCheckoutDate)).thenReturn(itemsReturnedBeforeFirstReservation);

		assertTrue(reservationRule.hasNoConflictingReservation(mockedItem, outDate, inDate));
	}

	/**
	 * Should return true if two item will be returned and one item is available before the second reservation starts and there is just two overlapping reservation.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnTrueIfTwoItemWillBeReturnedAndOneItemIsAvailableBeforeTheSecondReservationStartsAndThereIsJustTwoOverlappingReservation()
	        throws Exception {
		final Item mockedItem = getMockedItem();

		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

		mockNonOverlappingReservations(mockedItem, outDate, inDate, 2);

		mockItemStatus(new ItemStatus());

		final List<Item> itemsCurrentlyAvailable = new ArrayList<Item>();
		itemsCurrentlyAvailable.add(new Item());

		mockItem(itemsCurrentlyAvailable);

		final ReservationCollection mockedReservations = mock(ReservationCollection.class);
		final List<Reservation> nonOverlappingReservations = mockedItem.getNonOverlappingReservationsList(outDate, inDate)
		        .get(1);

		whenNew(ReservationCollection.class).withArguments(nonOverlappingReservations).thenReturn(mockedReservations);

		final Calendar firstCheckoutDate = Calendar.getInstance();
		when(mockedReservations.getFirstCheckouDate()).thenReturn(firstCheckoutDate);

		final List<AgreementItem> itemsReturnedBeforeFirstReservation = new ArrayList<AgreementItem>();
		itemsReturnedBeforeFirstReservation.add(new AgreementItem());
		itemsReturnedBeforeFirstReservation.add(new AgreementItem());

		mockStatic(AgreementItem.class);
		when(
		        AgreementItem.findAllOpenAgreementItemsByProductHavingDueByDateLessThan(mockedItem.getProduct(),
		                firstCheckoutDate)).thenReturn(itemsReturnedBeforeFirstReservation);

		assertTrue(reservationRule.hasNoConflictingReservation(mockedItem, outDate, inDate));
	}

	/**
	 * Should return false if one item will be returned and one item is available before the second reservation starts and there is three overlapping reservation.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void shouldReturnFalseIfOneItemWillBeReturnedAndOneItemIsAvailableBeforeTheSecondReservationStartsAndThereIsThreeOverlappingReservation()
	        throws Exception {
		final Item mockedItem = getMockedItem();

		final Calendar outDate = Calendar.getInstance();
		final Calendar inDate = Calendar.getInstance();

		mockNonOverlappingReservations(mockedItem, outDate, inDate, 3);

		mockItemStatus(new ItemStatus());

		final List<Item> itemsCurrentlyAvailable = new ArrayList<Item>();
		itemsCurrentlyAvailable.add(new Item());

		mockItem(itemsCurrentlyAvailable);

		final ReservationCollection first = mock(ReservationCollection.class);
		final ReservationCollection second = mock(ReservationCollection.class);
		final List<Reservation> nonOverlappingReservations1 = mockedItem.getNonOverlappingReservationsList(outDate, inDate)
		        .get(1);
		final List<Reservation> nonOverlappingReservations2 = mockedItem.getNonOverlappingReservationsList(outDate, inDate)
		        .get(2);

		whenNew(ReservationCollection.class).withArguments(nonOverlappingReservations1).thenReturn(first);

		whenNew(ReservationCollection.class).withArguments(nonOverlappingReservations2).thenReturn(second);

		final Calendar firstCheckoutDate = Calendar.getInstance();
		when(first.getFirstCheckouDate()).thenReturn(firstCheckoutDate);
		when(second.getFirstCheckouDate()).thenReturn(null);

		final List<AgreementItem> itemsReturnedBeforeFirstReservation = new ArrayList<AgreementItem>();
		itemsReturnedBeforeFirstReservation.add(new AgreementItem());

		mockStatic(AgreementItem.class);
		when(
		        AgreementItem.findAllOpenAgreementItemsByProductHavingDueByDateLessThan(mockedItem.getProduct(),
		                firstCheckoutDate)).thenReturn(itemsReturnedBeforeFirstReservation);

		assertFalse(reservationRule.hasNoConflictingReservation(mockedItem, outDate, inDate));
	}

	/**
	 * Mock item.
	 *
	 * @param itemsCurrentlyAvailable the items currently available
	 */
	private void mockItem(final List<Item> itemsCurrentlyAvailable) {
		mockStatic(Item.class);
		when(
		        Item.findAllItemsByStoreNumberAndProductAndItemStatus(Matchers.<Integer> anyObject(), Matchers
		                .<Product> anyObject(), Matchers.<ItemStatus> anyObject())).thenReturn(itemsCurrentlyAvailable);
	}

	/**
	 * Mock non overlapping reservations.
	 *
	 * @param mockedItem the mocked item
	 * @param outDate the out date
	 * @param inDate the in date
	 * @param countOfNonOverlappingReservation the count of non overlapping reservation
	 */
	private void mockNonOverlappingReservations(final Item mockedItem, final Calendar outDate, final Calendar inDate,
	        final int countOfNonOverlappingReservation) {
		final List<List<Reservation>> nonOverlappingReservationsList = new ArrayList<List<Reservation>>();
		for (int i = 0; i < countOfNonOverlappingReservation; i++) {
			nonOverlappingReservationsList.add(new ArrayList<Reservation>());
		}
		when(mockedItem.getNonOverlappingReservationsList(outDate, inDate)).thenReturn(nonOverlappingReservationsList);
	}

	/**
	 * Mock item status.
	 *
	 * @param itemStatus the item status
	 */
	private void mockItemStatus(final ItemStatus itemStatus) {
		mockStatic(ItemStatus.class);
		when(ItemStatus.findAvailable()).thenReturn(itemStatus);
	}

	/**
	 * Gets the mocked item.
	 *
	 * @return the mocked item
	 */
	private Item getMockedItem() {
		final Item mockedItem = mock(Item.class);
		when(mockedItem.getStoreNumber()).thenReturn(1233);
		when(mockedItem.getProduct()).thenReturn(new Product());
		return mockedItem;
	}

}
