/*
 * OutOfStockReportDaoTest.java
 */
package com.menards.rental.dao;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.whenNew;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.domain.OutOfStockAuditTrail;
import com.menards.rental.domain.Product;
import com.menards.rental.domain.StoreHourBasedRentalDateRange;
import com.menards.rental.dto.OutOfStockReportDto;
import com.menards.rental.service.external.StoreService;

/**
 * User: sudarshan Date: Jun 29, 2010 Time: 2:17:38 PM.
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest({OutOfStockAuditTrail.class, OutOfStockReportDao.class})
public class OutOfStockReportDaoTest {

    private OutOfStockReportDao dao;
    private StoreService storeService;

    @Before
    public void setUp() {
        dao = new OutOfStockReportDao();
        storeService = mock(StoreService.class);
        dao.setStoreService(storeService);
    }

    @Test
    public void shouldReturnAnEmptyListIfOutOfStockAuditTrailsReturnsAnEmptyList() {
        mockStatic(OutOfStockAuditTrail.class);
        final Calendar reportStartDate = Calendar.getInstance();
        final Calendar reportEndDate = Calendar.getInstance();
        final ArrayList<OutOfStockAuditTrail> auditTrails = new ArrayList<OutOfStockAuditTrail>();
        when(OutOfStockAuditTrail.findOutOfStockAuditTrailsByStartDateBetweenOrderByProduct(reportStartDate,
                reportEndDate)).thenReturn(auditTrails);

        assertTrue(dao.getOutOfStockReportData(reportStartDate, reportEndDate).isEmpty());
    }

    @Test
    public void shouldReturnTheDataInTheOutOfStockReport() throws Exception {
        final Calendar reportStartDate = Calendar.getInstance();
        final Calendar reportEndDate = Calendar.getInstance();
        final ArrayList<OutOfStockAuditTrail> auditTrails = new ArrayList<OutOfStockAuditTrail>();
        final Calendar startTime = Calendar.getInstance();
        startTime.add(Calendar.DATE, -1);
        final Calendar endTime = Calendar.getInstance();
        endTime.add(Calendar.DATE, 1);
        final Product product = getMockedProduct(6786L, "Hello Product Description");
        auditTrails.add(getAuditTrail(product, 1233, startTime, endTime));
        mockStatic(OutOfStockAuditTrail.class);
        when(OutOfStockAuditTrail.findOutOfStockAuditTrailsByStartDateBetweenOrderByProduct(reportStartDate,
                reportEndDate)).thenReturn(auditTrails);

        stubStoreHourBasedRentalDateRange(reportStartDate, reportEndDate, 1233, 90.0);
        stubStoreHourBasedRentalDateRange(startTime, endTime, 1233, 10.0);

        final List<OutOfStockReportDto> reportData = dao.getOutOfStockReportData(reportStartDate, reportEndDate);
        assertEquals(1, reportData.size());
        assertDto(6786L, "Hello Product Description", 1233, 100.0/9.0, reportData.get(0));
    }

    @Test
    public void shouldReturnAddedUpTotalHoursForSameProductAndSameStoreInTheOutOfStockReport() throws Exception {
        final Calendar reportStartDate = Calendar.getInstance();
        final Calendar reportEndDate = Calendar.getInstance();
        final ArrayList<OutOfStockAuditTrail> auditTrails = new ArrayList<OutOfStockAuditTrail>();
        final Calendar startTime = Calendar.getInstance();
        final Calendar endTime = Calendar.getInstance();
        startTime.add(Calendar.DATE, -1);
        endTime.add(Calendar.DATE, 1);
        final Product product = getMockedProduct(6786L, "Hello Product Description");
        auditTrails.add(getAuditTrail(product, 1233, startTime, endTime));
        auditTrails.add(getAuditTrail(product, 1233, startTime, null));
        mockStatic(OutOfStockAuditTrail.class);
        when(OutOfStockAuditTrail.findOutOfStockAuditTrailsByStartDateBetweenOrderByProduct(reportStartDate,
                reportEndDate)).thenReturn(auditTrails);

        stubStoreHourBasedRentalDateRange(reportStartDate, reportEndDate, 1233, 90.0);
        stubStoreHourBasedRentalDateRange(startTime, endTime, 1233, 10.0);
        stubStoreHourBasedRentalDateRange(startTime, reportEndDate, 1233, 5.0);

        final List<OutOfStockReportDto> reportData = dao.getOutOfStockReportData(reportStartDate, reportEndDate);
        assertEquals(1, reportData.size());

        assertDto(6786L, "Hello Product Description", 1233, 150.0/9.0, reportData.get(0));
    }

    @Test
    public void shouldReturnSeperateRecordsForTwoProductsOfSameStore() throws Exception {
        final Calendar reportStartDate = Calendar.getInstance();
        final Calendar reportEndDate = Calendar.getInstance();
        final ArrayList<OutOfStockAuditTrail> auditTrails = new ArrayList<OutOfStockAuditTrail>();
        final Calendar startTime = Calendar.getInstance();
        final Calendar endTime = Calendar.getInstance();
        startTime.add(Calendar.DATE, -1);
        endTime.add(Calendar.DATE, 1);
        final Product product1 = getMockedProduct(6786L, "Hello PD1");
        final Product product2 = getMockedProduct(1233L, "Hello PD2");
        auditTrails.add(getAuditTrail(product1, 1233, startTime, null));
        auditTrails.add(getAuditTrail(product2, 1233, startTime, endTime));
        mockStatic(OutOfStockAuditTrail.class);
        when(OutOfStockAuditTrail.findOutOfStockAuditTrailsByStartDateBetweenOrderByProduct(reportStartDate,
                reportEndDate)).thenReturn(auditTrails);

        stubStoreHourBasedRentalDateRange(reportStartDate, reportEndDate, 1233, 108.0);
        stubStoreHourBasedRentalDateRange(startTime, reportEndDate, 1233, 9.0);
        stubStoreHourBasedRentalDateRange(startTime, endTime, 1233, 18.0);

        final List<OutOfStockReportDto> reportData = dao.getOutOfStockReportData(reportStartDate, reportEndDate);
        assertEquals(2, reportData.size());

        assertDto(6786L, "Hello PD1", 1233, 900.0/108.0, reportData.get(0));
        assertDto(1233L, "Hello PD2", 1233, 1800.0/108.0, reportData.get(1));
    }

    @Test
    public void shouldReturnSeperateRecordsForTwoStoresHavingSameProduct() throws Exception {
        final Calendar reportStartDate = Calendar.getInstance();
        final Calendar reportEndDate = Calendar.getInstance();
        final ArrayList<OutOfStockAuditTrail> auditTrails = new ArrayList<OutOfStockAuditTrail>();
        final Calendar startTime = Calendar.getInstance();
        final Calendar endTime = Calendar.getInstance();
        startTime.add(Calendar.DATE, -1);
        endTime.add(Calendar.DATE, 1);
        final Product product1 = getMockedProduct(6786L, "Hello PD1");
        auditTrails.add(getAuditTrail(product1, 1233, startTime, null));
        auditTrails.add(getAuditTrail(product1, 7866, startTime, endTime));
        mockStatic(OutOfStockAuditTrail.class);
        when(OutOfStockAuditTrail.findOutOfStockAuditTrailsByStartDateBetweenOrderByProduct(reportStartDate,
                reportEndDate)).thenReturn(auditTrails);

        stubStoreHourBasedRentalDateRange(reportStartDate, reportEndDate, 1233, 45.0);
        stubStoreHourBasedRentalDateRange(reportStartDate, reportEndDate, 7866, 9.0);
        stubStoreHourBasedRentalDateRange(startTime, reportEndDate, 1233, 9.0);
        stubStoreHourBasedRentalDateRange(startTime, endTime, 7866, 0.9);

        final List<OutOfStockReportDto> reportData = dao.getOutOfStockReportData(reportStartDate, reportEndDate);
        assertEquals(2, reportData.size());
        assertDto(6786L, "Hello PD1", 1233, 900.0/45.0, reportData.get(0));
        assertDto(6786L, "Hello PD1", 7866, 90.0/9.0, reportData.get(1));
    }

    @Test
    public void shouldReturnSeperateRecordsForTwoStoresHavingDifferentProducts() throws Exception {
        final Calendar reportStartDate = Calendar.getInstance();
        final Calendar reportEndDate = Calendar.getInstance();
        final ArrayList<OutOfStockAuditTrail> auditTrails = new ArrayList<OutOfStockAuditTrail>();
        final Calendar startTime1 = Calendar.getInstance();
        final Calendar endTime1 = Calendar.getInstance();
        final Calendar startTime2 = Calendar.getInstance();
        final Calendar endTime2 = Calendar.getInstance();
        startTime1.add(Calendar.DATE, -1);
        endTime1.add(Calendar.DATE, 1);
        startTime2.add(Calendar.DATE, -2);
        endTime2.add(Calendar.DATE, 2);
        final Product product1 = getMockedProduct(6786L, "Hello PD1");
        final Product product2 = getMockedProduct(1233L, "Hello PD2");
        auditTrails.add(getAuditTrail(product1, 1233, startTime1, endTime1));
        auditTrails.add(getAuditTrail(product1, 1233, startTime1, null));
        auditTrails.add(getAuditTrail(product1, 7866, startTime2, null));
        auditTrails.add(getAuditTrail(product2, 7866, startTime2, endTime2));
        mockStatic(OutOfStockAuditTrail.class);
        when(OutOfStockAuditTrail.findOutOfStockAuditTrailsByStartDateBetweenOrderByProduct(reportStartDate,
                reportEndDate)).thenReturn(auditTrails);

        stubStoreHourBasedRentalDateRange(reportStartDate, reportEndDate, 1233, 126.0);
        stubStoreHourBasedRentalDateRange(reportStartDate, reportEndDate, 7866, 234.0);
        stubStoreHourBasedRentalDateRange(startTime1, endTime1, 1233, 27.9);
        stubStoreHourBasedRentalDateRange(startTime1, reportEndDate, 1233, 0.9);
        stubStoreHourBasedRentalDateRange(startTime2, reportEndDate, 7866, 36.81);
        stubStoreHourBasedRentalDateRange(startTime2, endTime2, 7866, 0.27);

        final List<OutOfStockReportDto> reportData = dao.getOutOfStockReportData(reportStartDate, reportEndDate);
        assertEquals(3, reportData.size());
        assertDto(6786L, "Hello PD1", 1233, (27.9 + 0.9)*100/126.0, reportData.get(0));
        assertDto(6786L, "Hello PD1", 7866, (36.81*100)/234.0, reportData.get(1));
        assertDto(1233L, "Hello PD2", 7866, (0.27*100)/234.0, reportData.get(2));
    }

    private void assertDto(long skuValue, String description, int storeNumber,
                                      double percentage, OutOfStockReportDto dto) {
        assertEquals(skuValue, dto.getSkuValue());
        assertEquals(description, dto.getSkuDescription());
        assertEquals(storeNumber, dto.getStoreNumber());
        assertEquals(percentage, dto.getPercentageOutOfStockValue(), 0.001);
    }

    private void stubStoreHourBasedRentalDateRange(final Calendar reportStartDate, final Calendar reportEndDate,
                                                  final int storeNumber, final double actualDuration)
            throws Exception {
        final StoreHourBasedRentalDateRange storeHours = mock(StoreHourBasedRentalDateRange.class);
        whenNew(StoreHourBasedRentalDateRange.class).withArguments(reportStartDate, reportEndDate, storeNumber)
                .thenReturn(
                storeHours);
        when(storeHours.getActualDurationInHours()).thenReturn(actualDuration);
    }

    private Product getMockedProduct(final long baseSKU, final String description) {
        final Product product = mock(Product.class);
        when(product.getBaseSkuValue()).thenReturn(baseSKU);
        when(product.getDescription()).thenReturn(description);
        return product;
    }

    private OutOfStockAuditTrail getAuditTrail(final Product product, final Integer storeNumber,
                                               final Calendar startTime, final Calendar endTime) {
        final OutOfStockAuditTrail outOfStockAuditTrail = new OutOfStockAuditTrail();
        outOfStockAuditTrail.setProduct(product);
        outOfStockAuditTrail.setStoreNumber(storeNumber);
        outOfStockAuditTrail.setStartTime(startTime);
        outOfStockAuditTrail.setEndTime(endTime);
        return outOfStockAuditTrail;
    }
}
