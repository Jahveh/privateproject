/*
 * VoidRentalReportDaoTest.java
 */
package com.menards.rental.dao;

import static org.junit.Assert.assertSame;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.expectReturn;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.playback;

import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Test;
import org.springframework.mock.staticmock.MockStaticEntityMethods;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementStatus;

/**
 * User: deep Date: 7 Jul, 2010 Time: 6:58:16 PM.
 */
@MockStaticEntityMethods
public class VoidRentalReportDaoTest {

	/**
	 * Should return agreements that were voided today.
	 */
	@Test
	public void shouldReturnAgreementsThatWereVoidedToday() {
		final Calendar date = Calendar.getInstance();
		final AgreementStatus voidedStatus = new AgreementStatus();
		AgreementStatus.findVoided();
		expectReturn(voidedStatus);

		final ArrayList<Agreement> expectedAgreements = new ArrayList<Agreement>();
		Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(voidedStatus, 1233, date, date);
		expectReturn(expectedAgreements);
		playback();

		assertSame(expectedAgreements, new VoidRentalReportDao().getVoidedAgreementsBetweenTwoPeriod(1233, date, date));
	}
}
