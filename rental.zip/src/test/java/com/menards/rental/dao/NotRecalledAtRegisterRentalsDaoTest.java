package com.menards.rental.dao;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementStatus;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest({Agreement.class, AgreementStatus.class})
public class NotRecalledAtRegisterRentalsDaoTest {

    private NotRecalledAtRegisterRentalsDao dao;

    @Before
    public void setUp() {
        dao = new NotRecalledAtRegisterRentalsDao();
    }

    @Test
    public void shouldFindAndAddCancledAgreementsToTheList() {
        final AgreementStatus canceled = new AgreementStatus();
        final AgreementStatus active = new AgreementStatus();
        final Agreement agreement = new Agreement();
        mockStatic(AgreementStatus.class);
        when(AgreementStatus.findCancelled()).thenReturn(canceled);
        when(AgreementStatus.findActive()).thenReturn(active);
        mockStatic(Agreement.class);
        final Calendar startDate = Calendar.getInstance();
        final Calendar endDate = Calendar.getInstance();
        final ArrayList<Agreement> canceledAgreements = new ArrayList<Agreement>();
        canceledAgreements.add(agreement);
        when(Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(canceled, 1233,
                startDate,
                endDate)).thenReturn(canceledAgreements);

        when(Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(
                active, 1233, startDate, endDate)).thenReturn(new ArrayList<Agreement>());

        final List<Agreement> list = dao.getNotRecalledAtRegisterRentalsForATimePeriod(1233, startDate, endDate);
        assertTrue(list.contains(agreement));
    }

    @Test
    public void shouldFindAndActiveAgreementsToTheList() {
        final AgreementStatus canceled = new AgreementStatus();
        final AgreementStatus active = new AgreementStatus();
        final Agreement agreement = mock(Agreement.class);
        mockStatic(AgreementStatus.class);
        when(AgreementStatus.findCancelled()).thenReturn(canceled);
        when(AgreementStatus.findActive()).thenReturn(active);
        mockStatic(Agreement.class);
        final Calendar startDate = Calendar.getInstance();
        final Calendar endDate = Calendar.getInstance();
        final ArrayList<Agreement> activeAgreements = new ArrayList<Agreement>();
        activeAgreements.add(agreement);
        when(Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(canceled, 1233,
                startDate,
                endDate)).thenReturn(new ArrayList<Agreement>());

        when(agreement.hasItemsThatAreReturnedButNotPaid()).thenReturn(true);
        when(Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(
                active, 1233, startDate, endDate)).thenReturn(activeAgreements);

        final List<Agreement> list = dao.getNotRecalledAtRegisterRentalsForATimePeriod(1233, startDate, endDate);
        assertTrue(list.contains(agreement));
    }

    @Test
    public void shouldFindAndActiveAgreementsToTheListThatHaveReturnedItems() {
        final AgreementStatus canceled = new AgreementStatus();
        final AgreementStatus active = new AgreementStatus();
        final Agreement agreement1 = mock(Agreement.class);
        final Agreement agreement2 = mock(Agreement.class);
        mockStatic(AgreementStatus.class);
        when(AgreementStatus.findCancelled()).thenReturn(canceled);
        when(AgreementStatus.findActive()).thenReturn(active);
        mockStatic(Agreement.class);
        final Calendar startDate = Calendar.getInstance();
        final Calendar endDate = Calendar.getInstance();
        final ArrayList<Agreement> activeAgreements = new ArrayList<Agreement>();
        activeAgreements.add(agreement1);
        activeAgreements.add(agreement2);
        when(Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(canceled, 1233,
                startDate,
                endDate)).thenReturn(new ArrayList<Agreement>());

        when(agreement1.hasItemsThatAreReturnedButNotPaid()).thenReturn(false);
        when(agreement2.hasItemsThatAreReturnedButNotPaid()).thenReturn(true);
        when(Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(
                active, 1233, startDate, endDate)).thenReturn(activeAgreements);

        final List<Agreement> list = dao.getNotRecalledAtRegisterRentalsForATimePeriod(1233, startDate, endDate);
        assertTrue(list.contains(agreement2));
        assertFalse(list.contains(agreement1));
    }

    @Test
    public void shouldFindAndActiveAndCanceledAgreementsToTheList() {
        final AgreementStatus canceled = new AgreementStatus();
        final AgreementStatus active = new AgreementStatus();
        final Agreement agreement1 = mock(Agreement.class);
        final Agreement agreement2 = mock(Agreement.class);
        mockStatic(AgreementStatus.class);
        when(AgreementStatus.findCancelled()).thenReturn(canceled);
        when(AgreementStatus.findActive()).thenReturn(active);
        mockStatic(Agreement.class);
        final Calendar startDate = Calendar.getInstance();
        final Calendar endDate = Calendar.getInstance();
        final ArrayList<Agreement> activeAgreements = new ArrayList<Agreement>();
        final ArrayList<Agreement> canceledAgreements = new ArrayList<Agreement>();
        activeAgreements.add(agreement1);
        canceledAgreements.add(agreement2);
        when(Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(canceled, 1233,
                startDate,
                endDate)).thenReturn(canceledAgreements);

        when(agreement1.hasItemsThatAreReturnedButNotPaid()).thenReturn(true);
        when(Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(
                active, 1233, startDate, endDate)).thenReturn(activeAgreements);

        final List<Agreement> list = dao.getNotRecalledAtRegisterRentalsForATimePeriod(1233, startDate, endDate);
        assertTrue(list.contains(agreement2));
        assertTrue(list.contains(agreement1));
    }
}
