package com.menards.rental.dao;

import static junit.framework.Assert.assertSame;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.ArrayList;

import javax.persistence.EntityManager;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Filter;
import org.hibernate.Session;
import org.hibernate.criterion.SQLCriterion;
import org.hibernate.criterion.SimpleExpression;
import org.hibernate.transform.DistinctRootEntityResultTransformer;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.domain.Product;
import com.menards.rental.domain.RentalSKU;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest(Product.class)
public class SearchDaoTest {

    private EntityManager entityManager;
    private Session session;
    private Filter filter;
    private SearchDao dao;

    @Before
    public void setUp() {
        dao = new SearchDao();
    }

    @Test
    public void shouldEnableTheFilterForTheStoreNumber() {
        final Criteria criteria = stubCreateCriteria();
        final ArrayList<Product> products = new ArrayList<Product>();
        when(criteria.list()).thenReturn(products);

        assertSame(products, dao.getAllMatchingProductsForStore(1233, null));
        verify(criteria).setFetchMode("items", FetchMode.JOIN);
        verify(criteria).setResultTransformer(Matchers.<DistinctRootEntityResultTransformer>anyObject());
    }

    @Test
    public void shouldEnableBaseSkuValueIfValueIsNotNull() {
        final Criteria criteria = stubCreateCriteria();
        final Criteria baseSKUCriteria = mock(Criteria.class);
        when(criteria.createCriteria("skuInfo.baseSKU")).thenReturn(baseSKUCriteria);

        final ArrayList<Product> products = new ArrayList<Product>();
        when(criteria.list()).thenReturn(products);

        final RentalSKU sku = new RentalSKU();
        sku.setValue(123123L);
        assertSame(products, dao.getAllMatchingProductsForStore(1233, sku));

        verify(baseSKUCriteria).add(argThat(new ArgumentMatcher<SQLCriterion>() {

            @Override
            public boolean matches(Object o) {
                return o.toString().equals("concat('', {alias}.sku) like ?");
            }
        }));
    }

    @Test
    public void shouldEnableBaseSkuDescriptionIfDescriptionIsNotNull() {
        final Criteria criteria = stubCreateCriteria();
        final Criteria baseSKUCriteria = mock(Criteria.class);
        when(criteria.createCriteria("skuInfo.baseSKU")).thenReturn(baseSKUCriteria);

        final ArrayList<Product> products = new ArrayList<Product>();
        when(criteria.list()).thenReturn(products);

        final RentalSKU sku = new RentalSKU();
        sku.setDescription("Hello World");
        assertSame(products, dao.getAllMatchingProductsForStore(1233, sku));

        verify(baseSKUCriteria).add(argThat(new ArgumentMatcher<SimpleExpression>() {

            @Override
            public boolean matches(Object o) {
                return o.toString().equals("description ilike %Hello World%");
            }
        }));
    }

    @Test
    public void shouldEnableBothBaseSkuDescriptionAndValueIfBothAreNotNull() {
        final Criteria criteria = stubCreateCriteria();
        final Criteria baseSKUCriteria = mock(Criteria.class);
        when(criteria.createCriteria("skuInfo.baseSKU")).thenReturn(baseSKUCriteria);

        final ArrayList<Product> products = new ArrayList<Product>();
        when(criteria.list()).thenReturn(products);

        final RentalSKU sku = new RentalSKU();
        sku.setValue(7866L);
        sku.setDescription("Hello World");
        assertSame(products, dao.getAllMatchingProductsForStore(1233, sku));

        verify(baseSKUCriteria).add(argThat(new ArgumentMatcher<SQLCriterion>() {

            @Override
            public boolean matches(Object o) {
                return o.toString().equals("concat('', {alias}.sku) like ?");
            }
        }));
        verify(baseSKUCriteria).add(argThat(new ArgumentMatcher<SimpleExpression>() {

            @Override
            public boolean matches(Object o) {
                return o.toString().equals("description ilike %Hello World%");
            }
        }));
    }

    private Criteria stubCreateCriteria() {
        mockStatic(Product.class);
        entityManager = mock(EntityManager.class);
        when(Product.entityManager()).thenReturn(entityManager);
        session = mock(Session.class);
        when(entityManager.getDelegate()).thenReturn(session);

        filter = mock(Filter.class);
        when(session.enableFilter("currentStoreItems")).thenReturn(filter);
        when(filter.setParameter("storeNumber", 1233)).thenReturn(filter);

        final Criteria criteria = mock(Criteria.class);
        when(session.createCriteria(Product.class)).thenReturn(criteria);

        return criteria;
    }
}
