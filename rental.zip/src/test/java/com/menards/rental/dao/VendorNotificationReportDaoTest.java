package com.menards.rental.dao;

import static org.junit.Assert.assertSame;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.ArrayList;
import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.Product;
import com.menards.rental.dto.VendorNotificationReportDto;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore(value = {"org.apache.log4j.*"})
@PrepareForTest(AgreementItem.class)
public class VendorNotificationReportDaoTest {

    @Test
    public void shouldGetTheVendorNotificationDTOList() {
        mockStatic(AgreementItem.class);
        final EntityManager entityManager = mock(EntityManager.class);
        when(AgreementItem.entityManager()).thenReturn(entityManager);
        final Query query = mock(Query.class);
        when(entityManager.createQuery(VendorNotificationReportDao.reportDataQuery)).thenReturn(query);

        final Calendar startDate = Calendar.getInstance();
        when(query.setParameter("startDate", startDate)).thenReturn(query);
        final Calendar endDate = Calendar.getInstance();
        when(query.setParameter("endDate", endDate)).thenReturn(query);
        final Product product = new Product();
        when(query.setParameter("product", product)).thenReturn(query);

        final ArrayList<VendorNotificationReportDto> list = new ArrayList<VendorNotificationReportDto>();
        when(query.getResultList()).thenReturn(list);

        assertSame(list, new VendorNotificationReportDao().getVendorNotificationReportData(startDate, endDate, product));
    }
}
