/*
 * CalendarToStringConverterTest.java
 */
package com.menards.rental.converters;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;

import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;

/**
 * The Class CalendarToStringConverterTest.
 */
public class CalendarToStringConverterTest {

	/** The calendar to string converter. */
	private CalendarToStringConverter calendarToStringConverter;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		calendarToStringConverter = new CalendarToStringConverter();
	}

	/**
	 * Returns calendar instance on sending correct date and time.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void returnsCalendarInstanceOnSendingCorrectDateAndTime() throws Exception {
		final String dateText = "06/06/2010 09:10 AM";
		final Calendar calendar = (Calendar) calendarToStringConverter.toObject(dateText, Calendar.class);
		assertNotNull(calendar);
		assertEquals(2010, calendar.get(Calendar.YEAR));
		assertEquals(5, calendar.get(Calendar.MONTH));
		assertEquals(6, calendar.get(Calendar.DAY_OF_MONTH));
		assertEquals(9, calendar.get(Calendar.HOUR));
		assertEquals(10, calendar.get(Calendar.MINUTE));
		assertEquals(0, calendar.get(Calendar.AM_PM));
	}

	/**
	 * Returns null on sending wrong date and time.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void returnsNullOnSendingWrongDateAndTime() throws Exception {
		final String dateText = "I AM NOT A DATE";
		final Calendar calendar = (Calendar) calendarToStringConverter.toObject(dateText, Calendar.class);
		assertNull(calendar);
	}

	/**
	 * Return correct string format on sending calendar object.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void returnCorrectStringFormatOnSendingCalendarObject() throws Exception {
		final Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, 2011);
		calendar.set(Calendar.MONTH, 6);
		calendar.set(Calendar.DAY_OF_MONTH, 7);
		calendar.set(Calendar.HOUR, 10);
		calendar.set(Calendar.MINUTE, 6);
		calendar.set(Calendar.AM_PM, 1);

		final String textValue = calendarToStringConverter.toString(calendar);

		assertEquals("07/07/2011 10:06 PM", textValue);
	}

	/**
	 * Return empty string on sending null calendar object.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void returnEmptyStringOnSendingNullCalendarObject() throws Exception {

		assertEquals("", calendarToStringConverter.toString(null));
	}
}
