/*
 * ProductToStringConverterTest.java
 */
package com.menards.rental.converters;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.expectReturn;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.playback;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.staticmock.MockStaticEntityMethods;

import com.menards.rental.domain.Product;

/**
 * The Class ProductToStringConverterTest.
 */
@MockStaticEntityMethods
public class ProductToStringConverterTest {

	/** The product to string converter. */
	private ProductToStringConverter productToStringConverter;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		productToStringConverter = new ProductToStringConverter();
	}

	/**
	 * Return a product on product id valid.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void returnAProductOnProductIdValid() throws Exception {
		final Product mockProduct = mock(Product.class);

		Product.findProduct(1L);
		expectReturn(mockProduct);
		playback();

		assertEquals(mockProduct, productToStringConverter.toObject("1", Product.class));

	}

	/**
	 * Return null on product id not valid.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void returnNullOnProductIdNotValid() throws Exception {
		Product.findProduct(2L);
		expectReturn(null);
		playback();

		assertNull(productToStringConverter.toObject("2", Product.class));
	}

	/**
	 * Return null on product id not valid number.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void returnNullOnProductIdNotValidNumber() throws Exception {
		assertNull(productToStringConverter.toObject("NOT_A_NUMBER", Product.class));
	}

	/**
	 * Return product id on calling to string.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void returnProductIdOnCallingToString() throws Exception {
		final Product mockProduct = mock(Product.class);

		when(mockProduct.getId()).thenReturn(1L);

		assertEquals("1", productToStringConverter.toString(mockProduct));
	}

}
