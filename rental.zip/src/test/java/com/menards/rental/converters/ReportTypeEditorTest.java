/*
 * ReportTypeEditorTest.java
 */
package com.menards.rental.converters;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNull;
import static org.junit.Assert.assertSame;

import org.junit.Before;
import org.junit.Test;

import com.menards.rental.domain.Report;

/**
 * User: deep Date: 6 Jul, 2010 Time: 5:38:02 PM.
 */
public class ReportTypeEditorTest {
	
	/** The editor. */
	private ReportTypeEditor editor;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		editor = new ReportTypeEditor();
	}

	/**
	 * Should return null if value is null.
	 */
	@Test
	public void shouldReturnNullIfValueIsNull() {
		editor.setValue(null);
		assertNull(editor.getAsText());
	}

	/**
	 * Should return the value of code if the value is not null.
	 */
	@Test
	public void shouldReturnTheValueOfCodeIfTheValueIsNotNull() {
		editor.setValue(Report.Type.OVERDUE_RENTAL_REPORT);
		assertEquals("OVERDUE_RENTAL_REPORT", editor.getAsText());
	}

	/**
	 * Should set the object value to null if string is null.
	 */
	@Test
	public void shouldSetTheObjectValueToNullIfStringIsNull() {
		editor.setAsText(null);
		assertNull(editor.getValue());
	}

	/**
	 * Should set the value of correct type based on the code passed.
	 */
	@Test
	public void shouldSetTheValueOfCorrectTypeBasedOnTheCodePassed() {
		editor.setAsText(Report.Type.NOT_RECALLED_AT_REGISTER_REPORT.toString());
		assertSame(Report.Type.NOT_RECALLED_AT_REGISTER_REPORT, editor.getValue());
	}
}
