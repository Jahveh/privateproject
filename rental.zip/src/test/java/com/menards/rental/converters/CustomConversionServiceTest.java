/*
 * CustomConversionServiceTest.java
 */
package com.menards.rental.converters;

import static junit.framework.Assert.assertEquals;

import java.util.Calendar;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import com.menards.rental.domain.Product;

/**
 * The Class CustomConversionServiceTest.
 */
public class CustomConversionServiceTest {

	/** The custom conversion service. */
	private CustomConversionService customConversionService;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		customConversionService = new CustomConversionService();
	}

	/**
	 * Test if all converters are registered.
	 */
	@Test
	public void testIfAllConvertersAreRegistered() {
		customConversionService.addDefaultConverters();

		assertEquals(1, customConversionService.getConversionExecutors(Calendar.class).size());
		assertEquals(1, customConversionService.getConversionExecutors(Date.class).size());
		assertEquals(1, customConversionService.getConversionExecutors(Product.class).size());
		assertEquals(1, customConversionService.getConversionExecutors(Double.class).size());
	}

}
