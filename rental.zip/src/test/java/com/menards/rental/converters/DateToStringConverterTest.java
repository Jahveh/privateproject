/*
 * DateToStringConverterTest.java
 */
package com.menards.rental.converters;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;

import java.util.Calendar;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

/**
 * The Class DateToStringConverterTest.
 */
public class DateToStringConverterTest {

	/** The date to string converter. */
	private DateToStringConverter dateToStringConverter;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		dateToStringConverter = new DateToStringConverter();
	}

	/**
	 * Returns date instance on sending correct date.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void returnsDateInstanceOnSendingCorrectDate() throws Exception {
		final String dateText = "06/06/2010";
		final Date date = (Date) dateToStringConverter.toObject(dateText, Date.class);

		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);

		assertNotNull(date);
		assertEquals(2010, calendar.get(Calendar.YEAR));
		assertEquals(5, calendar.get(Calendar.MONTH));
		assertEquals(6, calendar.get(Calendar.DAY_OF_MONTH));
	}

	/**
	 * Returns null on sending wrong date.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void returnsNullOnSendingWrongDate() throws Exception {
		final String dateText = "I AM NOT A DATE";
		final Date date = (Date) dateToStringConverter.toObject(dateText, Date.class);
		assertNull(date);
	}

	/**
	 * Return correct string format on sending calendar object.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void returnCorrectStringFormatOnSendingCalendarObject() throws Exception {

		final Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, 2011);
		calendar.set(Calendar.MONTH, 6);
		calendar.set(Calendar.DAY_OF_MONTH, 7);

		final Date date = new Date(calendar.getTimeInMillis());
		final String textValue = dateToStringConverter.toString(date);

		assertEquals("07/07/2011", textValue);
	}

	/**
	 * Return correct pattern format.
	 */
	@Test
	public void returnCorrectPatternFormat() {
		assertEquals("MM/dd/yyyy", dateToStringConverter.getPattern());
	}

	/**
	 * Return empty string on sending null date object.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void returnEmptyStringOnSendingNullDateObject() throws Exception {

		assertEquals("", dateToStringConverter.toString(null));
	}

}
