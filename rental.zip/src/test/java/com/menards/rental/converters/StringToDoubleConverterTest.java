package com.menards.rental.converters;

import org.junit.Test;

import static junit.framework.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: deep
 * Date: 27 Aug, 2010
 * Time: 12:30:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class StringToDoubleConverterTest {

    @Test
    public void shouldConvertDoubleValueWithCommasToDoubleValue() throws Exception {
        assertEquals(10908.0, (Double) new StringToDoubleConverter().toObject("10,908", Double.class), 0.001);
    }
}
