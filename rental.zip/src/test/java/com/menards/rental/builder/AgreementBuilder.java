/*
 * AgreementBuilder.java
 */
package com.menards.rental.builder;

import java.util.HashSet;
import java.util.Set;

import com.menards.rental.domain.*;

/**
 * Created by IntelliJ IDEA. User: deep Date: 13 May, 2010 Time: 7:55:34 PM To
 * change this template use File | Settings | File Templates.
 */
public class AgreementBuilder {

	/** The guest. */
	private Guest guest;
	
	/** The items. */
	private Set<AgreementItem> items;
	
	/** The vehicle rental detail. */
	private VehicleRentalDetail vehicleRentalDetail;
	
	/** The id. */
	private long id = 1L;
	
	/** The store. */
	private Store store;
	
	/** The agreement number. */
	private String agreementNumber;
	
	/** The agreement status. */
	private AgreementStatus agreementStatus;

    /**
	 * Builds the agreement.
	 *
	 * @return the agreement
	 */
	public Agreement buildAgreement() {
		final Agreement agreement = new Agreement();
		agreement.setId(id);
		agreement.setGuest(guest);
		agreement.setItems(items);
		agreement.setVehicleRentalDetail(vehicleRentalDetail);
		agreement.setAgreementNumber(agreementNumber);
		agreement.setAgreementStatus(agreementStatus);
		agreement.setStore(store);
		return agreement;
	}

	/**
	 * With guest.
	 *
	 * @param guest the guest
	 * @return the agreement builder
	 */
	public AgreementBuilder withGuest(final Guest guest) {
		this.guest = guest;
		return this;
	}

	/**
	 * With items.
	 *
	 * @param items the items
	 * @return the agreement builder
	 */
	public AgreementBuilder withItems(final Set<AgreementItem> items) {
		this.items = items;
		return this;
	}

	/**
	 * With item.
	 *
	 * @param item the item
	 * @return the agreement builder
	 */
	public AgreementBuilder withItem(final AgreementItem item) {
		if (null == this.items) {
			this.items = new HashSet<AgreementItem>();
		}
		this.items.add(item);
		return this;
	}

	/**
	 * With vehicle rental detail.
	 *
	 * @param vehicleRentalDetail the vehicle rental detail
	 * @return the agreement builder
	 */
	public AgreementBuilder withVehicleRentalDetail(final VehicleRentalDetail vehicleRentalDetail) {
		this.vehicleRentalDetail = vehicleRentalDetail;
		return this;
	}

	/**
	 * With id.
	 *
	 * @param id the id
	 * @return the agreement builder
	 */
	public AgreementBuilder withId(final long id) {
		this.id = id;
		return this;
	}

	/**
	 * With store.
	 *
	 * @param store the store
	 * @return the agreement builder
	 */
	public AgreementBuilder withStore(final Store store) {
		this.store = store;
		return this;
	}

	/**
	 * With agreement number.
	 *
	 * @param agreementNumber the agreement number
	 * @return the agreement builder
	 */
	public AgreementBuilder withAgreementNumber(final String agreementNumber) {
		this.agreementNumber = agreementNumber;
		return this;
	}

	/**
	 * With agreement status.
	 *
	 * @param agreementStatus the agreement status
	 * @return the agreement builder
	 */
	public AgreementBuilder withAgreementStatus(final AgreementStatus agreementStatus) {
		this.agreementStatus = agreementStatus;
		return this;
	}
}
