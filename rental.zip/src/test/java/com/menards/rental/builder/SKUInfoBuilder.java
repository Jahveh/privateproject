/*
 * SKUInfoBuilder.java
 */
package com.menards.rental.builder;

import java.math.BigDecimal;

import com.menards.rental.domain.RentalSKU;
import com.menards.rental.domain.SKUInfo;

/**
 * Created by IntelliJ IDEA. User: deep Date: 11 Jun, 2010 Time: 11:15:28 AM To
 * change this template use File | Settings | File Templates.
 */
public class SKUInfoBuilder {
	
	/** The base sku hr qty. */
	private double baseSkuHrQty;
	
	/** The incremental sku hr qty. */
	private double incrementalSkuHrQty;
	
	/** The base sku. */
	private RentalSKU baseSKU;
	
	/** The incremental sku. */
	private RentalSKU incrementalSKU;
	
	/** The selling sku. */
	private RentalSKU sellingSKU;
	
	/** The surcharge sku. */
	private RentalSKU surchargeSKU;
	
	/**
	 * Builds the sku info.
	 *
	 * @return the sKU info
	 */
	public SKUInfo buildSKUInfo() {
		final SKUInfo skuInfo = new SKUInfo();
		skuInfo.setBaseSkuHrQty(baseSkuHrQty);
		skuInfo.setIncrementalSkuHrQty(incrementalSkuHrQty);
		skuInfo.setBaseSKU(baseSKU);
		skuInfo.setIncrementalSKU(incrementalSKU);
		skuInfo.setSellingSKU(sellingSKU);
		skuInfo.setSurchargeSKU(surchargeSKU);
		return skuInfo;
	}

	/**
	 * With base sku hr qty.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @return the sKU info builder
	 */
	public SKUInfoBuilder withBaseSkuHrQty(final double baseSkuHrQty) {
		this.baseSkuHrQty = baseSkuHrQty;
		return this;
	}

	/**
	 * With incremental sku hr qty.
	 *
	 * @param incrementalSkuHrQty the incremental sku hr qty
	 * @return the sKU info builder
	 */
	public SKUInfoBuilder withIncrementalSkuHrQty(final double incrementalSkuHrQty) {
		this.incrementalSkuHrQty = incrementalSkuHrQty;
		return this;
	}

    /**
	 * With base sku.
	 *
	 * @param baseSKU the base sku
	 * @return the sKU info builder
	 */
	public SKUInfoBuilder withBaseSKU(final RentalSKU baseSKU) {
		this.baseSKU = baseSKU;
		return this;
	}

	/**
	 * With incremental sku.
	 *
	 * @param incrementalSKU the incremental sku
	 * @return the sKU info builder
	 */
	public SKUInfoBuilder withIncrementalSKU(final RentalSKU incrementalSKU) {
		this.incrementalSKU = incrementalSKU;
		return this;
	}

	/**
	 * With selling sku.
	 *
	 * @param sellingSKU the selling sku
	 * @return the sKU info builder
	 */
	public SKUInfoBuilder withSellingSKU(final RentalSKU sellingSKU) {
		this.sellingSKU = sellingSKU;
		return this;
	}

	/**
	 * With surcharge sku.
	 *
	 * @param surchageSKU the surchage sku
	 * @return the sKU info builder
	 */
	public SKUInfoBuilder withSurchargeSKU(final RentalSKU surchageSKU) {
		this.surchargeSKU = surchageSKU;
		return this;
	}
}
