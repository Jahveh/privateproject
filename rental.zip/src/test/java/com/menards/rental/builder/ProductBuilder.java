/*
 * ProductBuilder.java
 */
package com.menards.rental.builder;

import java.util.Set;

import com.menards.rental.domain.Product;
import com.menards.rental.domain.Reservation;
import com.menards.rental.domain.SKUInfo;

/**
 * Created by IntelliJ IDEA. User: deep Date: 11 Jun, 2010 Time: 11:13:51 AM To
 * change this template use File | Settings | File Templates.
 */
public class ProductBuilder {
	
	/** The sku info. */
	private SKUInfo skuInfo;
	
	/** The reservations. */
	private Set<Reservation> reservations;

    /** The id. */
    private long id;

    /**
	 * With sku info.
	 *
	 * @param skuInfo the sku info
	 * @return the product builder
	 */
	public ProductBuilder withSkuInfo(final SKUInfo skuInfo) {
		this.skuInfo = skuInfo;
		return this;
	}

	/**
	 * Builds the product.
	 *
	 * @return the product
	 */
	public Product buildProduct() {
		final Product product = new Product();
		product.setSkuInfo(skuInfo);
		//product.setReservations(reservations);
        product.setId(id);
		return product;
	}

	/**
	 * With reservations.
	 *
	 * @param reservations the reservations.
	 * @return the product builder.
	 */
	public ProductBuilder withReservations(final Set<Reservation> reservations) {
		this.reservations = reservations;
		return this;
	}

    /**
     * Build a product with the given id.
     * @param id the id of the product.
     * @return the productbuilder reference.
     */
    public ProductBuilder withId(final long id) {
        this.id = id;
        return this;
    }
}
