/*
 * SKUBuilder.java
 */
package com.menards.rental.builder;

import com.menards.rental.domain.RentalSKU;

/**
 * Created by IntelliJ IDEA. User: deep Date: 11 Jun, 2010 Time: 4:53:20 PM To
 * change this template use File | Settings | File Templates.
 */
public class SKUBuilder {
	
	/** The id. */
	private long id;

	/**
	 * With id.
	 *
	 * @param id the id
	 * @return the sKU builder
	 */
	public SKUBuilder withId(final long id) {
		this.id = id;
		return this;
	}

	/**
	 * Builds the sku.
	 *
	 * @return the sKU
	 */
	public RentalSKU buildSKU() {
		final RentalSKU sku = new RentalSKU();
		sku.setId(id);
		return sku;
	}
}
