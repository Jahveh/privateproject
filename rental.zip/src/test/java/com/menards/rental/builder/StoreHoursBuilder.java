/*
 * StoreHoursBuilder.java
 */
package com.menards.rental.builder;

import com.menards.rental.domain.StoreHour;
import com.menards.rental.domain.Time;

/**
 * Created by IntelliJ IDEA. User: deep Date: 14 Jul, 2010 Time: 2:59:17 PM To
 * change this template use File | Settings | File Templates.
 */
public class StoreHoursBuilder {
	
	/** The open. */
	private Time open;
	
	/** The close. */
	private Time close;

	/**
	 * With open.
	 *
	 * @param open the open
	 * @return the store hours builder
	 */
	public StoreHoursBuilder withOpen(final Time open) {
		this.open = open;
		return this;
	}

	/**
	 * With close.
	 *
	 * @param close the close
	 * @return the store hours builder
	 */
	public StoreHoursBuilder withClose(final Time close) {
		this.close = close;
		return this;
	}

	/**
	 * Builds the store hours.
	 *
	 * @return the store hour
	 */
	public StoreHour buildStoreHours() {
		final StoreHour storeHours = new StoreHour();

		storeHours.setOpen(open);
		storeHours.setClose(close);
		return storeHours;
	}
}
