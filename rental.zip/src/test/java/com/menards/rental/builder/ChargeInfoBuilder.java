/*
 * ChargeInfoBuilder.java
 */
package com.menards.rental.builder;

import java.math.BigDecimal;
import java.util.Calendar;

import com.menards.rental.domain.ChargeInfo;
import com.menards.rental.domain.DamageWaiver;

/**
 * Created by IntelliJ IDEA. User: deep Date: 2 Aug, 2010 Time: 3:15:34 PM To
 * change this template use File | Settings | File Templates.
 */
public class ChargeInfoBuilder {
	
	/** The due by. */
	private Calendar dueBy;
	
	/** The check out date. */
	private Calendar checkOutDate;
	
	/** The base price amount. */
	private double basePriceAmount;
	
	/** The base sku hr qty. */
	private double baseSkuHrQty;
	
	/** The incremental sku hr qty. */
	private double incrementalSkuHrQty;
	
	/** The incremental price amount. */
	private double incrementalPriceAmount;
	
	/** The damage waiver. */
	private DamageWaiver damageWaiver;
	
	/** The checkin date. */
	private Calendar checkinDate;
	
	/** The additional incremental charge amount. */
	private double additionalIncrementalChargeAmount;
	
	/** The base charge amount. */
	private double baseChargeAmount;
	
	/** The additional incremental time units. */
	private Integer additionalIncrementalTimeUnits;
	
	/** The incremental charge amount. */
	private double incrementalChargeAmount;

	/**
	 * With due by.
	 *
	 * @param dueBy the due by
	 * @return the charge info builder
	 */
	public ChargeInfoBuilder withDueBy(final Calendar dueBy) {
		this.dueBy = dueBy;
		return this;
	}

	/**
	 * With checkout date.
	 *
	 * @param checkedOutDate the checked out date
	 * @return the charge info builder
	 */
	public ChargeInfoBuilder withCheckoutDate(final Calendar checkedOutDate) {
		this.checkOutDate = checkedOutDate;
		return this;
	}

	/**
	 * With base price amount.
	 *
	 * @param basePriceAmount the base price amount
	 * @return the charge info builder
	 */
	public ChargeInfoBuilder withBasePriceAmount(final double basePriceAmount) {
		this.basePriceAmount = basePriceAmount;
		return this;
	}

	/**
	 * Builds the charge info.
	 *
	 * @return the charge info
	 */
	public ChargeInfo buildChargeInfo() {
		final ChargeInfo chargeInfo = new ChargeInfo();
		chargeInfo.setCheckoutDate(checkOutDate);
		chargeInfo.setDueBy(dueBy);
		chargeInfo.setCheckinDate(checkinDate);
		chargeInfo.setBasePriceAmount(new BigDecimal(basePriceAmount));
		chargeInfo.setIncrementalPriceAmount(new BigDecimal(incrementalPriceAmount));
		chargeInfo.setAdditionalIncrementalChargeAmount(new BigDecimal(additionalIncrementalChargeAmount));
		chargeInfo.setBaseChargeAmount(new BigDecimal(baseChargeAmount));
		chargeInfo.setIncrementalChargeAmount(new BigDecimal(incrementalChargeAmount));
		chargeInfo.setBaseSkuHrQty(baseSkuHrQty);
		chargeInfo.setIncrementalSkuHrQty(incrementalSkuHrQty);
		chargeInfo.setDamageWaiver(damageWaiver);
		chargeInfo.setAdditionalIncrementalTimeUnits(additionalIncrementalTimeUnits);
		return chargeInfo;
	}

	/**
	 * With base sku hr qty.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @return the charge info builder
	 */
	public ChargeInfoBuilder withBaseSkuHrQty(final double baseSkuHrQty) {
		this.baseSkuHrQty = baseSkuHrQty;
		return this;
	}

	/**
	 * With incremental sku hr qty.
	 *
	 * @param incrementalSkuHrQty the incremental sku hr qty
	 * @return the charge info builder
	 */
	public ChargeInfoBuilder withIncrementalSkuHrQty(final double incrementalSkuHrQty) {
		this.incrementalSkuHrQty = incrementalSkuHrQty;
		return this;
	}

	/**
	 * With incremental price amount.
	 *
	 * @param incrementalPriceAmount the incremental price amount
	 * @return the charge info builder
	 */
	public ChargeInfoBuilder withIncrementalPriceAmount(final double incrementalPriceAmount) {
		this.incrementalPriceAmount = incrementalPriceAmount;
		return this;
	}

	/**
	 * With damage waiver.
	 *
	 * @param damageWaiver the damage waiver
	 * @return the charge info builder
	 */
	public ChargeInfoBuilder withDamageWaiver(final DamageWaiver damageWaiver) {
		this.damageWaiver = damageWaiver;
		return this;
	}

	/**
	 * With checkin date.
	 *
	 * @param checkinDate the checkin date
	 * @return the charge info builder
	 */
	public ChargeInfoBuilder withCheckinDate(final Calendar checkinDate) {
		this.checkinDate = checkinDate;
		return this;
	}

	/**
	 * With additional incremental charge amount.
	 *
	 * @param additionalIncrementalChargeAmount the additional incremental charge amount
	 * @return the charge info builder
	 */
	public ChargeInfoBuilder withAdditionalIncrementalChargeAmount(final double additionalIncrementalChargeAmount) {
		this.additionalIncrementalChargeAmount = additionalIncrementalChargeAmount;
		return this;
	}

	/**
	 * With base charge amount.
	 *
	 * @param baseChargeAmount the base charge amount
	 * @return the charge info builder
	 */
	public ChargeInfoBuilder withBaseChargeAmount(final double baseChargeAmount) {
		this.baseChargeAmount = baseChargeAmount;
		return this;
	}

	/**
	 * With additional incremental time units.
	 *
	 * @param additionalIncrementalTimeUnits the additional incremental time units
	 * @return the charge info builder
	 */
	public ChargeInfoBuilder withAdditionalIncrementalTimeUnits(final Integer additionalIncrementalTimeUnits) {
		this.additionalIncrementalTimeUnits = additionalIncrementalTimeUnits;
		return this;
	}

	/**
	 * With incremental charge amount.
	 *
	 * @param incrementalChargeAmount the incremental charge amount
	 * @return the charge info builder
	 */
	public ChargeInfoBuilder withIncrementalChargeAmount(final double incrementalChargeAmount) {
		this.incrementalChargeAmount = incrementalChargeAmount;
		return this;
	}
}
