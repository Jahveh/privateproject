/*
 * StoreNumberAndIncrementBasedAgreementNumberBuilderTest.java
 */
package com.menards.rental.builder;

import static junit.framework.Assert.assertEquals;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.expectReturn;
import static org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl.playback;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.staticmock.MockStaticEntityMethods;

import com.menards.rental.domain.AgreementIncrement;

/**
 * User: deep Date: 1 Jun, 2010 Time: 9:45:42 PM.
 */
@MockStaticEntityMethods
public class StoreNAndAgreementNumberBuilderTest {
	
	/** The agreement number builder. */
	private StoreAndAgreementNumberBuilder agreementNumberBuilder;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		agreementNumberBuilder = new StoreAndAgreementNumberBuilder();
	}

	/**
	 * Should build the agreement number using the agreement increment.
	 */
	@Test
	public void shouldBuildTheAgreementNumberUsingTheAgreementIncrement() {
		AgreementIncrement.getNextAgreementNumberForStoreNumber(1234);
		expectReturn(9999);
		playback();

		assertEquals("1234-09999-000", agreementNumberBuilder.build(1234));
	}

	/**
	 * Should pad the numbers to get us5 digit middle and3 digit last number.
	 */
	@Test
	public void shouldPadTheNumbersToGetUs5DigitMiddleAnd3DigitLastNumber() {
		AgreementIncrement.getNextAgreementNumberForStoreNumber(1234);
		expectReturn(108);
		playback();

		assertEquals("1234-00108-000", agreementNumberBuilder.build(1234));
	}

	/**
	 * Should not do anything if no number is found after the last index of dash.
	 */
	@Test
	public void shouldNotDoAnythingIfNoNumberIsFoundAfterTheLastIndexOfDash() {
		assertEquals("123-234-", agreementNumberBuilder.buildNextIncrement("123-234-"));
	}

	/**
	 * Should increment the last part of the number and return the new number.
	 */
	@Test
	public void shouldIncrementTheLastPartOfTheNumberAndReturnTheNewNumber() {
		assertEquals("123-00234-261", agreementNumberBuilder.buildNextIncrement("123-234-260"));
	}
    
    @Test
    public void shouldReturnTheAgreementNumberFromThePartsOfAgreementNumberPassed() {
        assertEquals("7866-23400-099", agreementNumberBuilder.build("7866", "23400099"));
    }

}
