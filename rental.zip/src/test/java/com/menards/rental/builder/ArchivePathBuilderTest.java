package com.menards.rental.builder;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.ArchivePath;
import com.menards.rental.utils.Constants;
import com.menards.rental.utils.MenardsProperties;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
public class ArchivePathBuilderTest {

    private ArchivePathBuilder archivePathBuilder;
    private MenardsProperties menardsProperties;

    @Before
    public void setUp() {
        archivePathBuilder = new ArchivePathBuilder();
        menardsProperties = mock(MenardsProperties.class);
        archivePathBuilder.setMenardsProperties(menardsProperties);
    }

    @Test
    public void shouldBuildTheArchivePathWithUrlFrom() {
        final Agreement agreement = mock(Agreement.class);
        when(agreement.getId()).thenReturn(1233L);

        when(menardsProperties.getApplicationURL()).thenReturn("http://localhost:8080/rental/");
        final ArchivePath archivePath = archivePathBuilder.build(agreement);
        assertEquals("http://localhost:8080/rental/agreement/report/1233", archivePath.getURLFrom());
    }
}
