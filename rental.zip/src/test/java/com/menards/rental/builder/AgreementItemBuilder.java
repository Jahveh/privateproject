/*
 * AgreementItemBuilder.java
 */
package com.menards.rental.builder;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.AgreementItemStatus;
import com.menards.rental.domain.ChecklistAnswer;
import com.menards.rental.domain.DamageInfo;
import com.menards.rental.domain.DamageWaiver;
import com.menards.rental.domain.Item;
import com.menards.rental.domain.VehicleRentalDetail;

/**
 * Created by IntelliJ IDEA. User: deep Date: 13 May, 2010 Time: 6:56:00 PM To
 * change this template use File | Settings | File Templates.
 */
public class AgreementItemBuilder {

	/** The vehicle rental detail. */
	private VehicleRentalDetail vehicleRentalDetail;
	
	/** The id. */
	private long id;
	
	/** The item. */
	private Item item;
	
	/** The damage waiver. */
	private DamageWaiver damageWaiver;
	
	/** The agreement. */
	private Agreement agreement;
	
	/** The damage info. */
	private DamageInfo damageInfo;
	
	/** The answers. */
	private final Set<ChecklistAnswer> answers = new HashSet<ChecklistAnswer>();

	/**
	 * With vehicle rental detail.
	 *
	 * @param vehicleRentalDetail the vehicle rental detail
	 * @return the agreement item builder
	 */
	public AgreementItemBuilder withVehicleRentalDetail(final VehicleRentalDetail vehicleRentalDetail) {
		this.vehicleRentalDetail = vehicleRentalDetail;
		return this;
	}

	/**
	 * Builds the agreement item.
	 *
	 * @param chargeAmount the charge amount
	 * @return the agreement item
	 */
	public AgreementItem buildAgreementItem(final BigDecimal chargeAmount) {
		final AgreementItem agreementItem = buildAgreementItem();
		final AgreementItemStatus status = new AgreementItemStatus();
		status.setStatusCode(AgreementItemStatus.AgreementItemStatusCode.CHECKED_OUT.getCode());
		final Item item = new Item();
		agreementItem.setItem(item);
		agreementItem.setStatus(status);
		return agreementItem;
	}

	/**
	 * Builds the agreement item.
	 *
	 * @return the agreement item
	 */
	public AgreementItem buildAgreementItem() {
		final AgreementItem agreementItem = new AgreementItem();
		agreementItem.setId(id);
		agreementItem.setVehicleRentalDetail(vehicleRentalDetail);
		agreementItem.setItem(item);
		agreementItem.setDamageWaiver(damageWaiver);
		agreementItem.setAgreement(agreement);
		agreementItem.setDamageInfo(damageInfo);
		agreementItem.setAnswers(answers);
		return agreementItem;
	}

	/**
	 * Builds the vehicle agreement item.
	 *
	 * @return the agreement item
	 */
	public AgreementItem buildVehicleAgreementItem() {
		return buildAgreementItem(new BigDecimal("25.0"));
	}

	/**
	 * With id.
	 *
	 * @param id the id
	 * @return the agreement item builder
	 */
	public AgreementItemBuilder withId(final long id) {
		this.id = id;
		return this;
	}

	/**
	 * With item.
	 *
	 * @param item the item
	 * @return the agreement item builder
	 */
	public AgreementItemBuilder withItem(final Item item) {
		this.item = item;
		return this;
	}

	/**
	 * With damage waiver.
	 *
	 * @param damageWaiver the damage waiver
	 * @return the agreement item builder
	 */
	public AgreementItemBuilder withDamageWaiver(final DamageWaiver damageWaiver) {
		this.damageWaiver = damageWaiver;
		return this;
	}

	/**
	 * With agreement.
	 *
	 * @param agreement the agreement
	 * @return the agreement item builder
	 */
	public AgreementItemBuilder withAgreement(final Agreement agreement) {
		this.agreement = agreement;
		return this;
	}

	/**
	 * With damage info.
	 *
	 * @param damageInfo the damage info
	 * @return the agreement item builder
	 */
	public AgreementItemBuilder withDamageInfo(final DamageInfo damageInfo) {
		this.damageInfo = damageInfo;
		return this;
	}

	/**
	 * With checklist answer.
	 *
	 * @param checklistAnswer the checklist answer
	 * @return the agreement item builder
	 */
	public AgreementItemBuilder withChecklistAnswer(final ChecklistAnswer checklistAnswer) {
		answers.add(checklistAnswer);
		return this;
	}

}