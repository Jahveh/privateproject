/*
 * GuestBuilder.java
 */
package com.menards.rental.builder;

import java.util.Date;

import com.menards.rental.domain.Address;
import com.menards.rental.domain.Guest;
import com.menards.rental.domain.Identification;

/**
 * Created by IntelliJ IDEA. User: deep Date: 20 May, 2010 Time: 5:48:33 PM To
 * change this template use File | Settings | File Templates.
 */
public class GuestBuilder {
	
	/** The first name. */
	private String firstName;
	
	/** The last name. */
	private String lastName;
	
	/** The phone number. */
	private String phoneNumber;
	
	/** The date of birth. */
	private Date dateOfBirth;
	
	/** The company name. */
	private String companyName;
	
	/** The email. */
	private String email;
	
	/** The address. */
	private Address address;
	
	/** The identification. */
	private Identification identification;
	
	/** The age. */
	private int age;

	/**
	 * With first name.
	 *
	 * @param firstName the first name
	 * @return the guest builder
	 */
	public GuestBuilder withFirstName(final String firstName) {
		this.firstName = firstName;
		return this;
	}

	/**
	 * Builds the guest.
	 *
	 * @return the guest
	 */
	public Guest buildGuest() {
		final Guest guest = new Guest();
		guest.setFirstName(firstName);
		guest.setLastName(lastName);
		guest.setCompanyName(companyName);
		guest.setEmail(email);
		guest.setPhoneNumber(phoneNumber);
		guest.setDateOfBirth(dateOfBirth);
		guest.setAddress(address);
		guest.setIdentification(identification);
		return guest;
	}

	/**
	 * With last name.
	 *
	 * @param lastName the last name
	 * @return the guest builder
	 */
	public GuestBuilder withLastName(final String lastName) {
		this.lastName = lastName;
		return this;
	}

	/**
	 * With phone number.
	 *
	 * @param phoneNumber the phone number
	 * @return the guest builder
	 */
	public GuestBuilder withPhoneNumber(final String phoneNumber) {
		this.phoneNumber = phoneNumber;
		return this;
	}

	/**
	 * With date of birth.
	 *
	 * @param dateOfBirth the date of birth
	 * @return the guest builder
	 */
	public GuestBuilder withDateOfBirth(final Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
		return this;
	}

	/**
	 * With company name.
	 *
	 * @param companyName the company name
	 * @return the guest builder
	 */
	public GuestBuilder withCompanyName(final String companyName) {
		this.companyName = companyName;
		return this;
	}

	/**
	 * With email.
	 *
	 * @param email the email
	 * @return the guest builder
	 */
	public GuestBuilder withEmail(final String email) {
		this.email = email;
		return this;
	}

	/**
	 * With address.
	 *
	 * @param address the address
	 * @return the guest builder
	 */
	public GuestBuilder withAddress(final Address address) {
		this.address = address;
		return this;
	}

	/**
	 * With identification.
	 *
	 * @param identification the identification
	 * @return the guest builder
	 */
	public GuestBuilder withLicense(final Identification identification) {
		this.identification = identification;
		return this;
	}

    public GuestBuilder withZipCode(String zipCode) {
        if(this.address == null) withAddress(new Address());
        this.address.setZipCode(zipCode);
        return this;
    }
}
