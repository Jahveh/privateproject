/*
 * ReservationBuilder.java
 */
package com.menards.rental.builder;

import java.util.Calendar;

import com.menards.rental.domain.Reservation;
import com.menards.rental.domain.ReservationAgreement;
import com.menards.rental.domain.ReservationStatus;

/**
 * Created by IntelliJ IDEA. User: deep Date: 8 Jul, 2010 Time: 4:24:37 PM To
 * change this template use File | Settings | File Templates.
 */
public class ReservationBuilder {
	
	/** The out date. */
	private Calendar outDate;
	
	/** The in date. */
	private Calendar inDate;
	
	/** The agreement. */
	private ReservationAgreement agreement;
	
	/** The reservation status. */
	private ReservationStatus reservationStatus;

	/**
	 * With checkout time stamp.
	 *
	 * @param outDate the out date
	 * @return the reservation builder
	 */
	public ReservationBuilder withCheckoutTimeStamp(final Calendar outDate) {
		this.outDate = outDate;
		return this;
	}

	/**
	 * With checkin time stamp.
	 *
	 * @param inDate the in date
	 * @return the reservation builder
	 */
	public ReservationBuilder withCheckinTimeStamp(final Calendar inDate) {
		this.inDate = inDate;
		return this;
	}

	/**
	 * Builds the reservation.
	 *
	 * @return the reservation
	 */
	public Reservation buildReservation() {
		final Reservation reservation = new Reservation();
		reservation.setCheckOutTimeStamp(outDate);
		reservation.setCheckInTimeStamp(inDate);
		reservation.setAgreement(agreement);
		reservation.setStatus(reservationStatus);
		return reservation;
	}

	/**
	 * With agreement.
	 *
	 * @param agreement the agreement
	 * @return the reservation builder
	 */
	public ReservationBuilder withAgreement(final ReservationAgreement agreement) {
		this.agreement = agreement;
		return this;
	}

	/**
	 * With status.
	 *
	 * @param reservationStatus the reservation status
	 * @return the reservation builder
	 */
	public ReservationBuilder withStatus(final ReservationStatus reservationStatus) {
		this.reservationStatus = reservationStatus;
		return this;
	}
}
