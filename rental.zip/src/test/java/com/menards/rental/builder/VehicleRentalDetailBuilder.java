/*
 * VehicleRentalDetailBuilder.java
 */
package com.menards.rental.builder;

import com.menards.rental.domain.AdditionalDriver;
import com.menards.rental.domain.Insurance;
import com.menards.rental.domain.VehicleRentalDetail;

/**
 * Created by IntelliJ IDEA. User: deep Date: 14 May, 2010 Time: 11:30:38 AM To
 * change this template use File | Settings | File Templates.
 */
public class VehicleRentalDetailBuilder {
	
	/** The insurance. */
	private Insurance insurance;
	
	/** The additional driver. */
	private AdditionalDriver additionalDriver;
	
	/** The extra driver needed. */
	private boolean extraDriverNeeded;

	/**
	 * With insurance.
	 *
	 * @param insurance the insurance
	 * @return the vehicle rental detail builder
	 */
	public VehicleRentalDetailBuilder withInsurance(final Insurance insurance) {
		this.insurance = insurance;
		return this;
	}

	/**
	 * Builds the vehicle rental detail.
	 *
	 * @return the vehicle rental detail
	 */
	public VehicleRentalDetail buildVehicleRentalDetail() {
		final VehicleRentalDetail vehicleRentalDetail = new VehicleRentalDetail();
		vehicleRentalDetail.setInsurance(insurance);
		vehicleRentalDetail.setAdditionalDriver(additionalDriver);
		vehicleRentalDetail.setExtraDriverNeeded(extraDriverNeeded);
		return vehicleRentalDetail;
	}

	/**
	 * With additional driver.
	 *
	 * @param additionalDriver the additional driver
	 * @return the vehicle rental detail builder
	 */
	public VehicleRentalDetailBuilder withAdditionalDriver(final AdditionalDriver additionalDriver) {
		this.additionalDriver = additionalDriver;
		return this;
	}

	/**
	 * With extra driver needed.
	 *
	 * @param extraDriverNeeded the extra driver needed
	 * @return the vehicle rental detail builder
	 */
	public VehicleRentalDetailBuilder withExtraDriverNeeded(final boolean extraDriverNeeded) {
		this.extraDriverNeeded = extraDriverNeeded;
		return this;
	}
}
