/*
 * ItemBuilder.java
 */
package com.menards.rental.builder;

import com.menards.rental.domain.Item;
import com.menards.rental.domain.Product;

/**
 * Created by IntelliJ IDEA. User: deep Date: 4 Jun, 2010 Time: 7:44:42 AM To
 * change this template use File | Settings | File Templates.
 */
public class ItemBuilder {
	
	/** The serial number. */
	private Long serialNumber;
	
	/** The product. */
	private Product product;
	
	/** The store number. */
	private int storeNumber;

	/**
	 * With serial number.
	 *
	 * @param serialNumber the serial number
	 * @return the item builder
	 */
	public ItemBuilder withSerialNumber(final Long serialNumber) {
		this.serialNumber = serialNumber;
		return this;
	}

	/**
	 * Builds the item.
	 *
	 * @return the item
	 */
	public Item buildItem() {
		final Item item = new Item();
		item.setSerialNumber(serialNumber);
		item.setProduct(product);
		item.setStoreNumber(storeNumber);
		return item;
	}

	/**
	 * With product.
	 *
	 * @param product the product
	 * @return the item builder
	 */
	public ItemBuilder withProduct(final Product product) {
		this.product = product;
		return this;
	}

	/**
	 * With store number.
	 *
	 * @param storeNumber the store number
	 * @return the item builder
	 */
	public ItemBuilder withStoreNumber(final int storeNumber) {
		this.storeNumber = storeNumber;
		return this;
	}
}
