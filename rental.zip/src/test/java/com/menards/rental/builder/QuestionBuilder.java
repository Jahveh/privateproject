package com.menards.rental.builder;

import com.menards.rental.domain.Question;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 *
 * @author deep
 */
public class QuestionBuilder {
    private BigDecimal chargeAmount;

    public QuestionBuilder withChargeAmount(BigDecimal chargeAmount) {
        this.chargeAmount = chargeAmount;
        return this;
    }

    public Question buildQuestion() {
        final Question question = new Question();
        question.setChargeAmount(chargeAmount);
        return question;
    }
}
