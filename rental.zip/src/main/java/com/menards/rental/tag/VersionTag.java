/*
 * VersionTag.java
 */
package com.menards.rental.tag;

import java.io.InputStream;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import com.menards.rental.utils.Constants;
import org.apache.log4j.Logger;

/**
 * Outputs the version number that is stored in the META-INF manifest so that
 * you can display the version and build number on a JSP page for QA and
 * informational purposes.
 * @author deep
 */
public class VersionTag extends TagSupport {

    /** The logger reference. */
    private static final Logger logger = Logger.getLogger(VersionTag.class);

    /**
     * {@inheritDoc}
     */
	@Override
	public int doStartTag() throws JspException {
		final InputStream stream = pageContext.getServletContext().getResourceAsStream(
		        Constants.Version.MANIFEST_PATH);
		try {
			final Attributes mainAttributes = new Manifest(stream).getMainAttributes();

			String buildNumber = mainAttributes.getValue(Constants.Version.APPLICATION_VERSION_KEY);

			if (null != mainAttributes.getValue(Constants.Version.APPLICATION_BUILD_NUMBER_KEY)) {
				buildNumber += "." + mainAttributes.getValue(Constants.Version.APPLICATION_BUILD_NUMBER_KEY);
			}

			pageContext.getOut().println("Build: " + buildNumber);
		} catch (final Exception e) {
			// Manifest file was not found may be do nothing.
            logger.debug(e.getMessage(), e);
		}
		return SKIP_BODY;
	}
}
