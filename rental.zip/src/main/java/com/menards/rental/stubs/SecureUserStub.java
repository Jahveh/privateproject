/*
 * SecureUserStub.java
 */
package com.menards.rental.stubs;

import com.menards.mymenards.integration.vo.SecureUser;

/**
 * The Class SecureUserStub.
 */
public class SecureUserStub {

	/**
	 * Gets the secure user.
	 *
	 * @return the secure user
	 */
	public static SecureUser getSecureUser() {
		return new SecureUser() {

			private static final long serialVersionUID = 1L;

			public String getAddress() {
				// TODO Auto-generated method stub
				return "4777 Menards Drive";
			}

			public String getAddress2() {
				// TODO Auto-generated method stub
				return "EAU ClAIRE WI";
			}

			public String getAliasId() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getCity() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getCreateDate() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getCurrentSystem() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getDefaultUser() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getDepartmentId() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getDepartmentName() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getDeptFax() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getDeptPhone() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getDisabled() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getEmail() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getFax() {
				// TODO Auto-generated method stub
				return "715-876-2562";
			}

			public String getFirstName() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getFullName() {
				// TODO Auto-generated method stub
				return "JAmes";
			}

			public String getGuestStatus() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getLastName() {
				// TODO Auto-generated method stub
				return "Bond";
			}

			public String getLastUpdatedBy() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getLastUpdatedDate() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getLocation() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getLoginName() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getMobile() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getPager() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getPhone() {
				// TODO Auto-generated method stub
				return "715-876-1234";
			}

			public String getPosition() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getSelector() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getState() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getStoreAbbreviation() {
				// TODO Auto-generated method stub
				return "TEST";
			}

			public String getStoreFax() {
				// TODO Auto-generated method stub
				return "715-876-2562";
			}

			public String getStoreName() {
				// TODO Auto-generated method stub
				return "EAU & CLAIRE";
			}

			public String getStoreNumber() {
				// TODO Auto-generated method stub
				return "8888";
			}

			public long getStorePerformExpireTime() {
				// TODO Auto-generated method stub
				return -1L;
			}

			public String getStorePerformRole() {
				// TODO Auto-generated method stub
				return null;
			}

			public int getStorePerformSequence() {
				// TODO Auto-generated method stub
				return -1;
			}

			public boolean getStorePerformTimestamp() {
				// TODO Auto-generated method stub
				return false;
			}

			public String getStorePerformUserId() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getStorePhone() {
				// TODO Auto-generated method stub
				return "715-876-1234";
			}

			public String getSubDept() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getTitle() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getUserId() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getUserName() {
				// TODO Auto-generated method stub
				return "TestUser";
			}

			public String getUserType() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getWebGroup() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getZip() {
				// TODO Auto-generated method stub
				return "54703";
			}

			public void setAddress(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setAddress2(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setAliasId(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setCity(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setCreateDate(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setCurrentSystem(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setDefaultUser(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setDepartmentId(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setDepartmentName(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setDeptFax(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setDeptPhone(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setDisabled(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setEmail(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setFax(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setFirstName(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setFullName(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setGuestStatus(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setLastName(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setLastUpdatedBy(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setLastUpdatedDate(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setLocation(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setLoginName(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setMobile(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setPager(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setPhone(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setPosition(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setSelector(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setState(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setStoreAbbreviation(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setStoreFax(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setStoreName(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setStoreNumber(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setStorePerformRole(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setStorePerformUserId(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setStorePhone(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setSubDept(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setTitle(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setUserId(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setUserName(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setUserType(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setWebGroup(final String arg0) {
				// TODO Auto-generated method stub

			}

			public void setZip(final String arg0) {

			}

			public String getRentalFlag()
			{
				// TODO Auto-generated method stub
				return null;
			}

			public String getRightsName()
			{
				// TODO Auto-generated method stub
				return null;
			}

			public void setRentalFlag(String arg0)
			{
				// TODO Auto-generated method stub
				
			}

			public void setRightsName(String arg0)
			{
				// TODO Auto-generated method stub
				
			}
		};
	}
}
