/*
 * StoreHourBasedRentalDateRange.java
 */
package com.menards.rental.domain;

import java.util.Calendar;

import javax.annotation.PostConstruct;

import org.joda.time.DateMidnight;
import org.joda.time.Days;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;

import com.menards.rental.service.ContextService;
import com.menards.rental.service.external.StoreService;

/**
 * The store hour based rental date range.  This date range specificaly accounts for the store open and close hours.
 * @author deep
 */
@Configurable
public class StoreHourBasedRentalDateRange extends DateRange implements ContextService.StoreNumberable {

	/** The store hour service. */
	@Autowired
	private StoreService storeHourService;

    /** The context service reference. */
    @Autowired
    private ContextService contextService;

    /** The store number. */
    private Integer storeNumber;

    /**
	 * Instantiates a new store hour based rental date range.
	 *
	 * @param lower the lower
	 * @param upper the upper
	 */
	public StoreHourBasedRentalDateRange(final Calendar lower, final Calendar upper) {
		super(lower, upper);
	}

    /**
     * The constructor that takes the store number as argument.
     * @param lower the lower date.
     * @param upper the upper date.
     * @param storeNumber the store number for which this date range will operate.
     */
    public StoreHourBasedRentalDateRange(final Calendar lower, final Calendar upper, final Integer storeNumber) {
        super(lower, upper);
        this.storeNumber = storeNumber;
    }

    /**
	 * Count number of full days.
	 *
	 * @return the int
	 */
	public int countNumberOfFullDays() {
        long lowerInMilliseconds = getLower().getTimeInMillis();
        long upperInMilliseconds = getUpper().getTimeInMillis();
        return Days.daysBetween(new DateMidnight(lowerInMilliseconds),
                new DateMidnight(upperInMilliseconds)).getDays() - 1;
	}

    /**
	 * Gets the actual duration in hours.
	 *
	 * @return the actual duration in hours
	 */
	public double getActualDurationInHours() {
		final StoreHour storeHours = getStoreHours();
		if (storeHours.isDateRangeWithinStoreHours(this)) {
			return storeHours.getTotalDurationInHours(this);
		}

		return storeHours.getTotalStoreOpenHours(getLower(), getUpper());
	}

	/**
	 * Gets the number of checkin hours.
	 *
	 * @return the number of checkin hours
	 */
	public double getNumberOfCheckinHours() {
		return getStoreHours().getNumberOfCheckinHours(getUpper());
	}

	/**
	 * Gets the number of checkout hours.
	 *
	 * @return the number of checkout hours
	 */
	public double getNumberOfCheckoutHours() {
		return getStoreHours().getNumberOfCheckoutHours(getLower());
	}

	/**
	 * Gets the store hour service.
	 *
	 * @return the store hour service
	 */
	public StoreService getStoreHourService() {
		return storeHourService;
	}

	/**
	 * Checks if is actual duration less than.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @return true, if is actual duration less than
	 */
	public boolean isActualDurationLessThan(final double baseSkuHrQty) {
		return (getActualDurationInHours() < baseSkuHrQty);
	}

	/**
	 * Sets the store hour service.
	 *
	 * @param storeHourService the new store hour service
	 */
	public void setStoreHourService(final StoreService storeHourService) {
		this.storeHourService = storeHourService;
	}

    /**
     * Initializes the store number if its null to the current store.
     */
    @PostConstruct
    public void initializeStoreNumberIfNotDoneAlready() {
        if (storeNumber == null) {
            contextService.applyStoreContext(this);
        }
    }

    /**
     * Setter for the store number.
     * @param storeNumber the new store number
     */
    public void setStoreNumber(final Integer storeNumber) {
        this.storeNumber = storeNumber;
    }

    /**
     * The context service setter.
     * @param contextService the value.
     */
    public void setContextService(final ContextService contextService) {
        this.contextService = contextService;
    }

	/**
	 * Gets the store hours.
	 *
	 * @return the store hours
	 */
	private StoreHour getStoreHours() {
		return storeHourService.getStoreHourByStoreNumber(storeNumber);
	}
}
