/*
 * Agent.java
 */
package com.menards.rental.domain;

import org.apache.commons.lang.StringEscapeUtils;

import java.io.Serializable;

import javax.persistence.Embeddable;

/**
 * The agent class.
 * @author deep
 */
@Embeddable
public class Agent implements Serializable {

	/** The name. */
	private String name;

	/** The address. */
	private Address address = new Address();

	/** The phone number. */
	private String phoneNumber;

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getNameEscaped() {
		return StringEscapeUtils.escapeHtml(name);
	}

	/**
	 * Gets the phone number.
	 *
	 * @return the phone number
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(final Address address) {
		this.address = address;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(final String name) {
		this.name = name;
	}

	/**
	 * Sets the phone number.
	 *
	 * @param phoneNumber the new phone number
	 */
	public void setPhoneNumber(final String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
}
