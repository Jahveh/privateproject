package com.menards.rental.domain.questions;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the question_category_map database table.
 * 
 */
@Embeddable
public class QuestionCategoryMapPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="question_id", insertable=false, updatable=false)
	private int questionId;

	@Column(name="question_category_id", insertable=false, updatable=false)
	private int questionCategoryId;

	@Column(name="question_type_id", insertable=false, updatable=false)
	private int questionTypeId;

	public QuestionCategoryMapPK() {
	}
	public int getQuestionId() {
		return this.questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public int getQuestionCategoryId() {
		return this.questionCategoryId;
	}
	public void setQuestionCategoryId(int questionCategoryId) {
		this.questionCategoryId = questionCategoryId;
	}
	public int getQuestionTypeId() {
		return this.questionTypeId;
	}
	public void setQuestionTypeId(int questionTypeId) {
		this.questionTypeId = questionTypeId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof QuestionCategoryMapPK)) {
			return false;
		}
		QuestionCategoryMapPK castOther = (QuestionCategoryMapPK)other;
		return 
			(this.questionId == castOther.questionId)
			&& (this.questionCategoryId == castOther.questionCategoryId)
			&& (this.questionTypeId == castOther.questionTypeId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.questionId;
		hash = hash * prime + this.questionCategoryId;
		hash = hash * prime + this.questionTypeId;
		
		return hash;
	}
}