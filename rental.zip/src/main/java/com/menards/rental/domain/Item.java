/*
 * Item.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.persistence.*;
import javax.validation.constraints.Digits;

import com.menards.rental.service.notification.ItemStatusNotifier;
import org.apache.log4j.Logger;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.ParamDef;
import org.hibernate.validator.constraints.Length;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

import com.menards.rental.utils.Constants;
import org.springframework.transaction.annotation.Transactional;

/**
 * The Class Item.
 * @author deep
 */
@Entity
@FilterDef(name = "currentStoreItems", parameters = @ParamDef(name = "storeNumber", type = "integer"))
@RooJavaBean
@Table(name = "item")
@RooEntity(identifierColumn = "item_id", finders = { "findItemsByStoreNumberAndProductAndItemStatus",
        "findItemsByProductAndStoreNumber"
})
public class Item implements Serializable {

	/** The log. */
	private static final Logger log = Logger.getLogger(Item.class);

	/** The serial number. */
	@Column(name = "serial_nbr")
	private Long serialNumber;

	/** The product. */
	@ManyToOne(targetEntity = Product.class, fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "product_id")
	private Product product;

	/** The item status. */
	@ManyToOne(targetEntity = ItemStatus.class, fetch = FetchType.EAGER, optional = true)
	@JoinColumn(name = "item_status_id")
	private ItemStatus itemStatus;

	/** The description. */
	@Column(name = "item_desc")
	@Length(max = 50)
	private String description;

	/** The usage number. */
	@Column(name = "usage_nbr")
	private BigDecimal usageNumber;

	/** The store number. */
	@Column(name = "store_nbr", nullable = false)
	@Digits(integer = 4, fraction = 0)
	private Integer storeNumber;

	/** The last rented date. */
	@Column(name = "last_rented_dt")
	@Temporal(TemporalType.TIMESTAMP)
	private java.util.Calendar lastRentedDate;

	/** The vehicle. */
	@OneToMany(targetEntity = Vehicle.class, 
			fetch = FetchType.LAZY,
            mappedBy = "item", cascade = CascadeType.ALL)
	private java.util.Set<Vehicle> vehicles = new HashSet<Vehicle>();

	/** The manufacture serial value. */
	@Column(name = "manufacture_serial_val")
	@Length(max = 25)
	private String manufactureSerialValue;

    /** The item status notifier reference. */
    @Autowired
    private transient ItemStatusNotifier itemStatusNotifier;

	/**
     * The method that returns the total number of items for the given product for the given store.
     * @param product the product whose count we have to find.
     * @param storeNumber the store number against which item count has to be found.
     * @return long value representing the count.
     */
    public static long countItemsByProductAndStoreNumber(final Product product, final Integer storeNumber) {
        return (Long) entityManager()
                .createQuery("select count(o) from Item o where o.product=:product and o.storeNumber=:storeNumber")
                .setParameter("product", product)
                .setParameter("storeNumber", storeNumber)
                .getSingleResult();
    }

    /**
	 * Find all items by product and store number.
	 *
	 * @param product the product
	 * @param storeNumer the store numer
	 * @return the list
	 */
	public static List<Item> findAllItemsByProductAndStoreNumber(final Product product, final Integer storeNumer) {
		return findItemsByProductAndStoreNumber(product, storeNumer).getResultList();
	}

	/**
	 * Find all items by store number and product and item status.
	 *
	 * @param storeNumber the store number
	 * @param product the product
	 * @param itemStatus the item status
	 * @return the list
	 */
	public static List<Item> findAllItemsByStoreNumberAndProductAndItemStatus(final Integer storeNumber,
	        final Product product, final ItemStatus itemStatus) {
		return findItemsByStoreNumberAndProductAndItemStatus(storeNumber, product, itemStatus).getResultList();
	}

	/**
	 * Find item by serial number.
	 *
	 * @param serialNumber the serial number
	 * @return the item
	 */
	public static Item findItemBySerialNumber(final Long serialNumber) {
		if ((null == serialNumber) || (serialNumber == 0)) {
			return null;
		}
		Item item = null;
		try {
			final String queryString = " select o from Item o inner join fetch o.product inner join fetch o.itemStatus " +
			                           " left join fetch o.vehicles " +
			                           "where o.serialNumber like :serialNumber";
			final Query query = entityManager().createQuery(queryString).setParameter("serialNumber", serialNumber);
			item = (Item) query.getSingleResult();
		} catch (final DataAccessException e) {
			log.error("Either duplicate entity or no entity found for " + serialNumber + "Exception thrown"
			        + e.getMessage(), e);
			return null;
		}
		return item;
	}

	/**
	 * Actual checkin.
	 */
	public void actualCheckin() {
		setItemStatus(ItemStatus.findAvailable());
		this.setLastRentedDate(Calendar.getInstance());
		merge();
	}

    /**
	 * Count actually overlapping reservations.
	 *
	 * @param outDate the out date
	 * @param inDate the in date
	 * @return the int
	 */
	public int countActuallyOverlappingReservations(final Calendar outDate, final Calendar inDate) {
		return product.countActuallyOverlappingReservationsForStore(storeNumber, outDate, inDate);
	}

	/**
	 * Creates the charge info.
	 *
	 * @return the charge info
	 */
	public ChargeInfo createChargeInfo() {
		return product.createChargeInfo();
	}

	/**
	 * Generate serial number.
	 */
	public void generateSerialNumber() {
		ItemSerialNumberIncrement serialNumberIncrementer;
		if ((null == this.storeNumber) || (null == this.product)) {
			return;
		}
		try {
			serialNumberIncrementer = (ItemSerialNumberIncrement) ItemSerialNumberIncrement
			        .findItemSerialNumberIncrementsByStoreNumberAndProduct(storeNumber, product).getSingleResult();
		} catch (final DataAccessException dae) {
			serialNumberIncrementer = ItemSerialNumberIncrement.createNewItemSerialNumberIncrement(storeNumber,
			        product);
		}
		final String serialNumberText = new StringBuilder().append(storeNumber).append(
		        product.getSkuInfo().getBaseSKU().getValue()).append(serialNumberIncrementer.getCurrentNumber())
		        .toString();
		this.serialNumber = Long.parseLong(serialNumberText);
		serialNumberIncrementer.setCurrentNumber(serialNumberIncrementer.getCurrentNumber() + 1);
		serialNumberIncrementer.persist();
	}

    /**
	 * Gets the base sku hr qty.
	 *
	 * @return the base sku hr qty
	 */
	public double getBaseSkuHrQty() {
		return product.getBaseSkuHrQty();
	}

	/**
     * Getter for base sku value.
     * @return base sku value.
     */
    public Long getBaseSkuValue() {
        return product.getBaseSkuValue();
    }

	/**
     * Getter for incremental sku value.
     * @return incremental sku value.
     */
    public Long getIncrementalSkuValue() {
        return product.getIncrementalSkuValue();
    }

    /**
     * Getter for selling sku value.
     * @return selling sku value.
     */
    public Long getSellingSkuValue() {
        return product.getSellingSkuValue();
    }

    /**
     * Getter for surcharge sku value.
     * @return surcharge sku value.
     */
    public Long getSurchargeSkuValue() {
        return product.getSurchargeSkuValue();
    }


	/**
	 * Gets the current agreement item to which i belong.
	 *
	 * @return the current agreement item to which i belong
	 */
	public AgreementItem getCurrentAgreementItemToWhichIBelong() {
		if (!itemStatus.isRented()) {
			return null;
		}

		return AgreementItem.findCheckedOutAndPaidAgreementItemFor(this);
	}

	/**
	 * Gets the current agreement item to which i belong.
	 *
	 * @return the current agreement item to which i belong
	 */
	public Date getCurrentAgreementItemToWhichIBelongDueDate() {
		if (!itemStatus.isRented()) {
			return null;
		}

		return AgreementItem.findCheckedOutAndPaidAgreementItemDueDateFor(this);
	}

	/**
	 * Gets the current on hold agreement item to which i belong.
	 *
	 * @return the current on hold agreement item to which i belong
	 */
	public AgreementItem getOnHoldAgreementItemToWhichIBelong() {
		if (!itemStatus.isOnHold()) {
			return null;
		}

		return AgreementItem.findCheckedOutAgreementItemFor(this);
	}

	/**
	 * Gets the current agreement to which item belongs.
	 *
	 * @return the current agreement to which item belongs
	 */
	public Agreement getCurrentAgreementToWhichItemBelongs() {
		if (!itemStatus.isRented()) {
			return null;
		}

		return Agreement.findActiveAgreementAssociatedWithItem(this);
	}

	/**
	 * Gets the current agreement to which item belongs.
	 *
	 * @return the current agreement to which item belongs
	 */
	public Long getCurrentAgreementIdToWhichItemBelongs() {
		if (!itemStatus.isRented()) {
			return null;
		}

		return Agreement.findActiveAgreementIdAssociatedWithItem(this);
	}

	/**
	 * Gets the formatted last rented date.
	 *
	 * @return the formatted last rented date
	 */
	public String getFormattedLastRentedDate() {
		if (null != lastRentedDate) {
			final SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_FORMAT);
			return sdf.format(lastRentedDate.getTime());
		}
		return "";
	}

    /**
	 * Gets the incremental sku hr qty.
	 *
	 * @return the incremental sku hr qty
	 */
	public double getIncrementalSkuHrQty() {
		return product.getIncrementalSkuHrQty();
	}

	/**
	 * Gets the non overlapping reservations list.
	 *
	 * @param outDate the out date
	 * @param inDate the in date
	 * @return the non overlapping reservations list
	 */
	public List<List<Reservation>> getNonOverlappingReservationsList(final Calendar outDate, final Calendar inDate) {
		return product.getNonOverlappingReservationsListForStore(storeNumber, outDate, inDate);
	}

	/**
	 * Gets the overlapping open reservations for.
	 *
	 * @param outDate the out date
	 * @param inDate the in date
	 * @return the overlapping open reservations for
	 */
	public List<Reservation> getOverlappingOpenReservationsFor(final Calendar outDate, final Calendar inDate) {
		return product.getOverlappingOpenReservationsForStore(storeNumber, outDate, inDate);
	}

	/**
	 * Gets the product id.
	 *
	 * @return the product id
	 */
	public Long getProductId() {
		return getProduct().getId();
	}

	/**
	 * Gets the rental sku.
	 *
	 * @return the rental sku
	 */
	public String getRentalSKU() {
		return product.getFormattedBaseSKU();
	}

	/**
	 * Gets the store number.
	 *
	 * @return the store number
	 */
	public Integer getStoreNumber() {
		return storeNumber;
	}

	/**
	 * Checks for any reservations.
	 *
	 * @return true, if successful
	 */
	public boolean hasAnyReservations() {
		return product.hasAnyReservationsFor(storeNumber);
	}

	/**
	 * Checks for overlapping reservations.
	 *
	 * @param outDate the out date
	 * @param inDate the in date
	 * @return true, if successful
	 */
	public boolean hasOverlappingReservations(final Calendar outDate, final Calendar inDate) {
		return product.hasOverlappingReservationsFor(storeNumber, outDate, inDate);
	}

	/**
	 * Checks if is available.
	 *
	 * @return true, if is available
	 */
	public boolean isAvailable() {
		return itemStatus.isAvailable();
	}

    /**
     * Should return true if the item is placed on hold.
     * @return true if the item is placed on hold.
     */
    public boolean isOnHold() {
        return itemStatus.isOnHold();
    }

    /**
     * Returns true if the item is rented.
     * @return true if the item is rented.
     */
    public boolean isRented() {
        return itemStatus.isRented();
    }

    /**
     * Should return true if the item status is unrentable or deleted.  Because both these statuses are unrentable.
     * @return true if the item is in unrentable status.
     */
    public boolean isUnRentable() {
        return itemStatus.isUnrentable() || itemStatus.isDeleted();
    }

    /**
     * Returns true if the item is in deleted status.
     * @return true if the item is in deleted status.
     */
    public boolean isDeleted() {
        return itemStatus.isDeleted();
    }

	/**
	 * Checks if is belonging to this store.
	 *
	 * @param storeNumber the store number
	 * @return true, if is belonging to this store
	 */
	public boolean isBelongingToThisStore(final Integer storeNumber) {
		return this.storeNumber.equals(storeNumber);
	}

	/**
	 * Checks if is driver age greater than minimum rental age.
	 *
	 * @param agreement the agreement
	 * @return true, if is driver age greater than minimum rental age
	 */
	public boolean isDriverAgeGreaterThanMinimumRentalAge(final Agreement agreement) {
		return product.isDriverAgeGreaterThanMinimumRentalAge(agreement);
	}

	/**
	 * Checks if is insurance additional driver license required.
	 *
	 * @return true, if is insurance additional driver license required
	 */
	public boolean isInsuranceAdditionalDriverLicenseRequired() {
		return product.isInsuranceAdditionalDriverLicenseRequired();
	}

	/**
	 * Checks if is usage tracking enabled.
	 *
	 * @return the boolean
	 */
	public Boolean isUsageTrackingEnabled() {
		return product.getUsageTrackingFlag();
	}

	/**
	 * Matches.
	 *
	 * @param item the item
	 * @return true, if successful
	 */
	public boolean matches(final Item item) {
		return serialNumber.equals(item.serialNumber);
	}

    /**
	 * Matches.
	 *
	 * @param serialNumber the serial number
	 * @return true, if successful
	 */
	public boolean matches(final Long serialNumber) {
		return this.serialNumber.equals(serialNumber);
	}

    /**
	 * Sets the item status.
	 *
	 * @param itemStatus the new item status
	 */
	public void setItemStatus(final ItemStatus itemStatus) {
		this.itemStatus = itemStatus;
	}

    /**
	 * Sets the store number.
	 *
	 * @param storeNumber the new store number
	 */
	public void setStoreNumber(final Integer storeNumber) {
		this.storeNumber = storeNumber;
	}

    /**
     * Returns the total number of rentable items for a given product for a store.
     * @param product the product for which we have to find the rentable items.
     * @param storeNumber the store number for which we have to find the rentable items.
     * @return Int value representing the total number of rentable items for that product.
     */
    public static long countRentableItemsByProductAndStoreNumber(final Product product, final Integer storeNumber) {
        return (Long) entityManager()
                .createQuery("select count(o) from Item o where o.storeNumber=:storeNumber "
                        + "and o.itemStatus in (:statusList) and o.product=:product")
                .setParameter("storeNumber", storeNumber)
                .setParameter("statusList", ItemStatus.findAllRentableStatuses())
                .setParameter("product", product)
                .getSingleResult();
    }

    /**
     * Returns the total number of currently rentable items for a given product for a store.
     * @param product the product for which we have to find the rentable items.
     * @param storeNumber the store number for which we have to find the rentable items.
     * @return Int value representing the total number of currently rentable items for that product.  This count
     * includes the count of items on hold + items available.
     */
    public static long countCurrentlyRentableItemsByProductAndStoreNumber(final Product product,
                                                                          final Integer storeNumber) {
        return (Long) entityManager()
                .createQuery("select count(o) from Item o where o.storeNumber=:storeNumber "
                        + "and o.itemStatus in (:statusList) and o.product=:product")
                .setParameter("storeNumber", storeNumber)
                .setParameter("statusList", ItemStatus.findAllCurrentlyRentableStatuses())
                .setParameter("product", product)
                .getSingleResult();
    }

    /**
     * Returns the count of items based on product, store number and item status.
     * @param product the product associated with the item.
     * @param storeNumber the store number associated with the item.
     * @param itemStatus the item status we want to search for.
     * @return long value representing the count of items in the given state.
     */
    public static long countItemsByProductAndStoreNumberAndItemStatus(final Product product,
                                                                      final Integer storeNumber,
                                                                      final ItemStatus itemStatus) {
        return (Long) entityManager()
                .createQuery("select count(o) from Item o where o.product=:product and o.storeNumber=:storeNumber "
                        + "and o.itemStatus=:itemStatus")
                .setParameter("product", product)
                .setParameter("storeNumber", storeNumber)
                .setParameter("itemStatus", itemStatus)
                .getSingleResult();
    }

    /**
     * The getter for the item status notifier.
     * @return the value.
     */
    public ItemStatusNotifier getItemStatusNotifier() {
        if (null == itemStatusNotifier) {
            itemStatusNotifier = new Item().itemStatusNotifier;
        }
        return itemStatusNotifier;
    }

    /**
     * The method that will be used to persist items.
     */
    @Transactional
    public void persist() {
        if (this.entityManager == null) {
            this.entityManager = entityManager();
        }
        this.entityManager.persist(this);
        getItemStatusNotifier().notifyUpdate(this);
    }

    /**
     * The method that will be used to merge the item with the db.
     */
    @Transactional
    public void merge() {
        if (this.entityManager == null) {
            this.entityManager = entityManager();
        }
        final Item merged = this.entityManager.merge(this);
        this.entityManager.flush();
        this.setId(merged.getId());
        getItemStatusNotifier().notifyUpdate(merged);
    }

    /**
     *
     * @return
     */
    public Vehicle getVehicle() {
        if(vehicles.isEmpty()) return new Vehicle();
        return vehicles.iterator().next();
    }

    public void setVehicle(final Vehicle vehicle) {
        vehicles.clear();
        vehicles.add(vehicle);
    }

    public Vehicle getVehicleToAdd() {
        final Vehicle vehicle = getVehicle();
        vehicles.add(vehicle);
        return vehicle;
    }
}
