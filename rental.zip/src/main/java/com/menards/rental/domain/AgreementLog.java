/*
 * AgreementLog.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Query;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
@Entity
@Table(name="agreement_log")
public class AgreementLog implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="log_id")
	/*the primary key*/
	private Long id;
	@OneToOne(targetEntity = Agreement.class, fetch = FetchType.EAGER, optional=false)
	@JoinColumn(name = "agreement_id", unique = true)
	/*the Agreement need to be logged*/
	private Agreement agreement;
	@Column(name = "pre_due_by")
	@Temporal(TemporalType.TIMESTAMP)
	/*the previous duyBy date*/
	private Calendar preDueBy;
	@Column(name = "cur_due_by")
	@Temporal(TemporalType.TIMESTAMP)
	/*the current due by date*/
	private Calendar curDuyBy;
	@Column(name = "demand_letter_status")
	/*the quantities of the demand letter which have been sent through email*/
	private int demandLetterStatus=0;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Calendar getPreDueBy() {
		return preDueBy;
	}
	public void setPreDueBy(Calendar preDueBy) {
		this.preDueBy = preDueBy;
	}
	public Calendar getCurDuyBy() {
		return curDuyBy;
	}
	public void setCurDuyBy(Calendar curDuyBy) {
		this.curDuyBy = curDuyBy;
	}
	public int getDemandLetterStatus() {
		return demandLetterStatus;
	}
	public void setDemandLetterStatus(int demandLetterStatus) {
		this.demandLetterStatus = demandLetterStatus;
	}
	
	public Agreement getAgreement() {
		return agreement;
	}
	public void setAgreement(Agreement agreement) {
		this.agreement = agreement;
	}
	public AgreementLog() {
	}
}
