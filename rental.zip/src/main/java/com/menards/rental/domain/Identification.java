/*
 * License.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * The Identification class.
 * @author deep
 */
@Embeddable
public class Identification implements Serializable {

	/** The number. */
	private String number;

    /** The unmased identification number value. */
    @Transient
    private String unMaskedNumber;

	/** The expiry date. */
	@Temporal(value = TemporalType.DATE)
	@DateTimeFormat(style = "S-")
	private Date expiryDate;

	/** The state. */
	private String state;

    /** The char value representing the identification type. */
    private String type = "D";

	/**
	 * Gets the expiry date.
	 *
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return expiryDate;
	}

	/**
	 * Gets the number.
	 *
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * Sets the expiry date.
	 *
	 * @param expiryDate the new expiry date
	 */
	public void setExpiryDate(final Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	/**
	 * Sets the number.
	 *
	 * @param number the new number
	 */
	public void setNumber(final String number) {
		this.number = number;
	}

	/**
	 * Sets the state.
	 *
	 * @param state the new state
	 */
	public void setState(final String state) {
		this.state = state;
	}

    /**
     * The getter for the type.
     * @return the value held.
     */
    public String getType() {
        return type;
    }

    /**
     * The setter for the type.
     * @param type the value to set.
     */
    public void setType(final String type) {
        this.type = type;
    }

    /**
     * Returns true if the identification is provided.  Which means this method returns true if atleast some id
     * is provided.
     * @return true if guest has provided some identification.
     */
    public boolean isProvided() {
        return !IdentificationType.NO_ID.matches(type);
    }

    /**
     * The unmasked identifcation number getter.
     * @return the string value representing the unmasked identification number.
     */
    public String getUnMaskedNumber() {
        return unMaskedNumber;
    }

    /**
     * The setter for the unmasked identification number.
     * @param unMaskedNumber the value to set.
     */
    public void setUnMaskedNumber(final String unMaskedNumber) {
        this.unMaskedNumber = unMaskedNumber;
    }

    /**
     * The identification type enum.
     * @author deep
     */
    public enum IdentificationType {

        /** The type which suggests this identification is of drivers license type. */
        DRIVERS_LICENSE('D', "Drivers License"),

        /** The type which suggests this identification is of miliotary id type. */
        MILITARY_ID('M', "Military ID"),

        /** The type which suggests this identification is of state id type. */
        STATE_ID('S', "State ID"),

        /** The type which suggests there is no identification provided. */
        NO_ID('N', "No ID");

        /** The code of identification type. */
        private char code;

        /** The description of the identification type. */
        private String description;

        /**
         * The constructor that takes the code and description as argument.
         * @param code the identification type code.
         * @param description the description of the identification code.
         */
        private IdentificationType(final char code, final String description) {
            this.code = code;
            this.description = description;
        }

        /**
         * The method that returns true if the type passed in matches the code of identification type.
         * @param type the type code selected by the user.
         * @return true if the identification matches the type selected.
         */
        public boolean matches(final String type) {
            return type.toCharArray()[0] == code;
        }
    }
}
