/*
 * OutOfStockAuditTrail.java
 */
package com.menards.rental.domain;

import javax.persistence.*;

import org.springframework.roo.addon.entity.RooEntity;

import java.util.Calendar;
import java.util.List;

/**
 * The out of stock audit trail class that will hold the out of stock trail for the items that go out of stock.
 * @author deep
 */
@Entity
@RooEntity(identifierColumn = "out_of_stock_audit_trail_id", finders = {
        "findOutOfStockAuditTrailsByProductAndStoreNumberAndEndTimeIsNull"
})
@Table(name = "out_of_stock_audit_trail")
public class OutOfStockAuditTrail {

    /** The product reference. */
    @ManyToOne(targetEntity = Product.class, fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id")
    private Product product;

    /** The store number reference. */
    @Column(name = "store_nbr", nullable = false)
    private Integer storeNumber;

    /** The out of stock start time. */
    @Column(name = "start_ts")
    @Temporal(TemporalType.TIMESTAMP)
    private Calendar startTime;

    /** The out of stock end time. */
    @Column(name = "end_ts")
    @Temporal(TemporalType.TIMESTAMP)
    private Calendar endTime;

    /**
     * Should return the out of stock audit trail that matches the passed product, store number and has end time null.
     * Tipically if the setup is correct we should only have one such record.
     * @param product the product for which we are interested in getting the audit trail.
     * @param storeNumber the store number for which we want to get the audit trail.
     * @return The out of stock audit trail record matching the criteria.  Null otherwise.
     */
    public static OutOfStockAuditTrail findOutOfStockAuditTrailByProductAndStoreNumberAndEndTimeIsNull(
            final Product product,
            final Integer storeNumber) {
        final List<OutOfStockAuditTrail> list =
                findOutOfStockAuditTrailsByProductAndStoreNumberAndEndTimeIsNull(product, storeNumber).getResultList();
        if (!list.isEmpty()) {
            return list.get(0);
        }
        return null;
    }

    /**
     * Finds the list of OutOfStockAuditTrail between the given start and end dates.
     *
     * @param startDate the start date for finding the audit trail.
     * @param endDate the end date for finding the audit trail.
     * @return List of out of stock audit trail that fall in the given criteria.
     */
    @SuppressWarnings("unchecked")
		public static List<OutOfStockAuditTrail> findOutOfStockAuditTrailsByStartDateBetweenOrderByProduct(
            final Calendar startDate,
            final Calendar endDate) {
    		final EntityManager entityManager = entityManager();
        final Query query = entityManager.createQuery("select o from OutOfStockAuditTrail o inner join fetch o.product p "
                + " where o.startTime between :startDate and :endDate"
                + " order by o.storeNumber, o.product.id");
        return query.setParameter("startDate", startDate)
                .setParameter("endDate", endDate)
                .getResultList();
    }

    /**
     * Getter for the product.
     * @return the product value.
     */
    public Product getProduct() {
        return product;
    }

    /**
     * Setter for the product.
     * @param product the value to set.
     */
    public void setProduct(final Product product) {
        this.product = product;
    }

    /**
     * The store number getter.
     * @return the store number.
     */
    public Integer getStoreNumber() {
        return storeNumber;
    }

    /**
     * The store number setter.
     * @param storeNumber the value to set.
     */
    public void setStoreNumber(final Integer storeNumber) {
        this.storeNumber = storeNumber;
    }

    /**
     * The start time getter.
     * @return the start time.
     */
    public Calendar getStartTime() {
        return startTime;
    }

    /**
     * The start time setter.
     * @param startTime the value to set.
     */
    public void setStartTime(final Calendar startTime) {
        this.startTime = startTime;
    }

    /**
     * The end time getter.
     * @return the end time.
     */
    public Calendar getEndTime() {
        return endTime;
    }

    /**
     * The end time setter.
     * @param endTime the value to set.
     */
    public void setEndTime(final Calendar endTime) {
        this.endTime = endTime;
    }
}
