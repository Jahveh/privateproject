/*
 * NoReservationsFoundReservationRule.java
 */
package com.menards.rental.domain.rule;

import java.util.Calendar;

import org.springframework.stereotype.Component;

import com.menards.rental.domain.Item;

/**
 * Checks if this item is not reserved on any reservation.
 * @author deep
 */
@Component(value = "noReservationsFoundReservationRule")
public class NoReservationsFoundReservationRule implements ReservationRule {

    /**
     * {@inheritDoc}
     */
	public boolean hasNoConflictingReservation(final Item item, final Calendar outDate, final Calendar inDate) {
		return !item.hasAnyReservations();
	}
}
