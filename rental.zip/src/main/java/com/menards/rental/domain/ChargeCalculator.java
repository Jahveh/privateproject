package com.menards.rental.domain;

import com.menards.rental.domain.rule.IncrementalHoursCalculationRuleComposite;

import java.math.BigDecimal;
import java.util.Calendar;

/**
 * The class that has the sole functionality of calculating various charges.
 *
 * @author deep
 */
public class ChargeCalculator {


    /** The base price amount. */
    private final BigDecimal basePriceAmount;

    /** The incremental price amount. */
    private final BigDecimal incrementalPriceAmount;

    /** The base sku hour quantity. */
    private final Double baseSkuHrQty;

    /** The incremental sku hour quantity. */
    private final Double incrementalSkuHrQty;

    /** The checkout date. */
    private Calendar checkoutDate;

    /** The checkin date. */
    private Calendar checkinDate;

    /** The incremental time units. */
    private Integer incrementalTimeUnits;

    /** The incremental charge amount. */
    private BigDecimal incrementalChargeAmount;

    /** The rental duration. */
    private Double rentalDuration;

    /** The charge amount. */
    private BigDecimal chargeAmount;

    /**
     * The constructor that takes in bse price and incremental prices and base and incremental hour quantity.
     * @param basePriceAmount The base price amount.
     * @param incrementalPriceAmount the incremental price amount.
     * @param baseSkuHrQty the base sku hour quantity.
     * @param incrementalSkuHrQty the incremental sku hour quantity.
     * @param checkoutDate the checkout date.
     * @param checkinDate the checkin date.
     */
    public ChargeCalculator(final BigDecimal basePriceAmount, final BigDecimal incrementalPriceAmount,
                            final Double baseSkuHrQty, final Double incrementalSkuHrQty,
                            final Calendar checkoutDate,
                            final Calendar checkinDate) {

        this.basePriceAmount = basePriceAmount;
        this.incrementalPriceAmount = incrementalPriceAmount;
        this.baseSkuHrQty = baseSkuHrQty;
        this.incrementalSkuHrQty = incrementalSkuHrQty;
        this.checkoutDate = checkoutDate;
        this.checkinDate = checkinDate;
    }

    /**
     * Should calculate the charges.
     */
    public void calculate() {
        setIncrementalTimeUnits(calculateIncrementalUnitsFor(checkoutDate, checkinDate));
        setIncrementalChargeAmount(calculateIncrementalChargeAmount());
        setRentalDuration(calculateRentalDuration());
        setChargeAmount(calculateChargeAmount());
    }

    /**
     * Getter for the charge amount.
     * @return the value.
     */
    public BigDecimal getChargeAmount() {
        return chargeAmount;
    }

    /**
     * The getter for the incremental charge amount.
     * @return the value.
     */
    public BigDecimal getIncrementalChargeAmount() {
        return incrementalChargeAmount;
    }

    /**
     * Getter for the incremental time units.
     * @return the value.
     */
    public int getIncrementalTimeUnits() {
        return incrementalTimeUnits;
    }

    /**
     * The rental duration.
     * @return the rental duration value.
     */
    public Double getRentalDuration() {
        return rentalDuration;
    }

    /**
     * Calculating the total chargeAmount which is baseAmount +
     * incrementalAmount * incrementalIncrementCount.
     *
     * @return the big decimal
     */
    private BigDecimal calculateChargeAmount() {
        return basePriceAmount.add(incrementalPriceAmount.multiply(new BigDecimal(incrementalTimeUnits)));
    }

    /**
     * Calculate incremental charge amount.
     *
     * @return the big decimal
     */
    private BigDecimal calculateIncrementalChargeAmount() {
        return incrementalPriceAmount.multiply(new BigDecimal(incrementalTimeUnits.toString()));
    }

    /**
     * Calculate incremental units for.
     *
     * @param outDate the out date
     * @param inDate the in date
     * @return the int
     */
    private int calculateIncrementalUnitsFor(final Calendar outDate, final Calendar inDate) {
        final double incrementalHours = new IncrementalHoursCalculationRuleComposite(baseSkuHrQty, incrementalSkuHrQty,
                new StoreHourBasedRentalDateRange(outDate, inDate)).calculate();
        return (int) Math.ceil(incrementalHours / incrementalSkuHrQty);
    }

    /**
     * Calculating the rental duration which is again nothing but baseHrs +
     * incrementalIncrementCount * incrementalSkuHrQty.
     *
     * @return the double
     */
    private Double calculateRentalDuration() {
        return baseSkuHrQty + incrementalTimeUnits * incrementalSkuHrQty;
    }

    /**
     * The setter for the charge amount.
     * @param chargeAmount the value.
     */
    private void setChargeAmount(final BigDecimal chargeAmount) {
        this.chargeAmount = chargeAmount;
    }

    /**
     * Setter for the incremental charge amount.
     * @param incrementalChargeAmount the incremental charge amount.
     */
    private void setIncrementalChargeAmount(final BigDecimal incrementalChargeAmount) {
        this.incrementalChargeAmount = incrementalChargeAmount;
    }

    /**
     * The setter for the incremental time units.
     * @param incrementalTimeUnits the value to set.
     */
    private void setIncrementalTimeUnits(final Integer incrementalTimeUnits) {
        this.incrementalTimeUnits = incrementalTimeUnits;
    }

    /**
     * Setter for the rental duration.
     * @param rentalDuration the value.
     */
    private void setRentalDuration(final Double rentalDuration) {
        this.rentalDuration = rentalDuration;
    }
}
