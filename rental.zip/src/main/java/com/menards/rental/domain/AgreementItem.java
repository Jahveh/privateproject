/*
 * AgreementItem.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Query;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringEscapeUtils;
import org.hibernate.annotations.Cascade;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

import com.menards.rental.dto.QuestionDto;
import com.menards.rental.format.SimpleTimePeriodFormatter;
import com.menards.rental.utils.Constants;

/**
 * The Class AgreementItem.
 */
@Entity
@RooJavaBean
@RooEntity(identifierColumn = "rental_detail_id", finders = { "findAgreementItemsByStatusAndItem" })
@Table(name = "rental_detail")
public class AgreementItem implements Serializable, Comparable<AgreementItem> {

	@Transient
	private List<QuestionDto> checkOutQuestionList = new ArrayList<QuestionDto>();

	@Transient
	private List<QuestionDto> checkInQuestionList = new ArrayList<QuestionDto>();
	
	@Transient
	public int numberOfYesCleanCheckInQuestions = 0;
	
	@Transient
	public boolean isCleanFeeCovered = false;
	
	/** The agreement. */
	@ManyToOne(targetEntity = Agreement.class, fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "agreement_id")
	private Agreement agreement;

	/** The usage in number. */
	@Column(name = "usage_in_nbr")
	private Double usageInNumber;

	/** The usage out number. */
	@Column(name = "usage_out_nbr")
	private Double usageOutNumber;

	/** The item. */
	@ManyToOne(targetEntity = Item.class, fetch = FetchType.EAGER, optional = false, cascade = { CascadeType.REFRESH })
	@JoinColumn(name = "item_id")
	private Item item;

	/** The overall comment. */
	@Column(name = "overall_comment")
	private String overallComment;

	/** The checkin team member. */
	@Column(name = "check_in_tm_number")
	private Integer checkinTeamMember;

	/** The override. */
	@Embedded
	private AgreementItemOverride override = new AgreementItemOverride();

	/** The vehicle rental detail. */
	@OneToOne(targetEntity = VehicleRentalDetail.class, optional = true, mappedBy = "agreementItem", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private VehicleRentalDetail vehicleRentalDetail;

	/** The damage info. */
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "damageComment", column = @Column(name = "damage_comment")),
			@AttributeOverride(name = "isExcessiveDamageDone", column = @Column(name = "excessive_damage_flg")),
			@AttributeOverride(name = "damageApprovedBy", column = @Column(name = "damage_approved_TM_number")) })
	private DamageInfo damageInfo = new DamageInfo();

	/** The status. */
	@ManyToOne(targetEntity = AgreementItemStatus.class, fetch = FetchType.EAGER, optional = true)
	@JoinColumn(name = "rental_detail_status_cd")
	private AgreementItemStatus status;

	/** The is checkedin. */
	@Transient
	private boolean isCheckedin;

	/** The reservation. */
	@Transient
	private Reservation reservation;

	/** The charge info. */
	@Embedded
	private ChargeInfo chargeInfo = new ChargeInfo();

	/**
	 * Instantiates a new agreement item.
	 */
	public AgreementItem() {
	}

	/**
	 * Instantiates a new agreement item.
	 *
	 * @param item
	 *            the item
	 * @param agreement
	 *            the agreement
	 */
	public AgreementItem(final Item item, final Agreement agreement) {

		this.item = item;
		this.agreement = agreement;

		// Set the status to checked out
		this.status = AgreementItemStatus.findCheckedOut();
	}

	/**
	 * Find all open agreement items by product having due by date less than.
	 *
	 * @param product
	 *            the product
	 * @param dueBy
	 *            the due by
	 * @return the list
	 */
	public static List<AgreementItem> findAllOpenAgreementItemsByProductHavingDueByDateLessThan(
			final Product product, final Calendar dueBy) {
		final Query query = entityManager()
				.createQuery(
						"from AgreementItem ai "
								+ "where ai.item.product = :product and ai.chargeInfo.dueBy < :dueBy "
								+ "and ai.status = :agreementItemStatus")
				.setParameter("product", product)
				.setParameter("dueBy", dueBy)
				.setParameter("agreementItemStatus",
						AgreementItemStatus.findCheckedOut());
		return query.getResultList();
	}

	/**
	 * Find checked out and paid agreement item for.
	 *
	 * @param item
	 *            the item
	 * @return the agreement item
	 */
	public static AgreementItem findCheckedOutAndPaidAgreementItemFor(
			final Item item) {
		final List<AgreementItem> agreementItems = findAgreementItemsByStatusAndItem(
				AgreementItemStatus.findCheckedOutAndPaidInitial(), item)
				.getResultList();
		if (agreementItems.isEmpty()) {
			return null;
		}
		return agreementItems.get(0);
	}

	/**
	 * Find checked out and paid agreement item for.
	 *
	 * @param item
	 *            the item
	 * @return the agreement item
	 */
	public static Date findCheckedOutAndPaidAgreementItemDueDateFor(
			final Item item) {
		final EntityManager manager = entityManager();
		final Query query = manager
				.createQuery("select a.chargeInfo.dueBy from AgreementItem a "
						+ "where a.status = :status and a.item = :item ");
		query.setParameter("status",
				AgreementItemStatus.findCheckedOutAndPaidInitial());
		query.setParameter("item", item);
		final List agreementItems = query.getResultList();
		if (agreementItems.isEmpty()) {
			return null;
		}
		return ((Calendar) agreementItems.get(0)).getTime();
	}

	/**
	 * Find checked out agreement item for.
	 *
	 * @param item
	 *            the item
	 * @return the agreement item
	 */
	public static AgreementItem findCheckedOutAgreementItemFor(final Item item) {
		final List<AgreementItem> agreementItems = findAgreementItemsByStatusAndItem(
				AgreementItemStatus.findCheckedOut(), item).getResultList();
		if (agreementItems.isEmpty()) {
			return null;
		}
		return agreementItems.get(0);
	}

	/**
	 * Actual checkin.
	 */
	public void actualCheckin() {
		item.actualCheckin();
		setStatus(AgreementItemStatus.findReturned());
		updateOverrides();
		merge();
	}

	/**
	 * Calculate damage waiver charges.
	 */
	public void calculateDamageWaiverCharges() {
		if (this.getIsDamageWaiverAvailable()) {
			chargeInfo.calculateDamageWaiverCharges();
		}
	}

	/**
	 * Based on the return time calculate the duration and charges. Currently
	 * guests are charged hourly for the entire time the store is open.
	 */
	public void calculateEstimatedChargesAndDuration() {
		getChargeInfo().calculateEstimatedChargesAndDuration();
	}

	/**
	 * Copy charge info.
	 */
	public void copyChargeInfo() {
		setChargeInfo(item.createChargeInfo());
	}

	/**
	 * Copyies the base price from the kiosk detail.
	 * 
	 * @param kioskProductDetail
	 *            the kiosk product detail from where we have to copy the
	 *            charges.
	 */
	public void copyPriceFrom(final KioskProductDetail kioskProductDetail) {
		getChargeInfo().setBasePriceAmount(
				kioskProductDetail.getBaseSKUChargeAmount());
		getChargeInfo().setIncrementalPriceAmount(
				kioskProductDetail.getIncrementalSKUChargeAmount());
		getChargeInfo().setSurchargePriceAmount(
				kioskProductDetail.getSurchargeSKUChargeAmount());
	}

	/**
	 * Creates the empty answers if required.
	 *
	 * @param questions
	 *            the questions
	 */
	public void createEmptyAnswersIfRequired(final List<Question> questions) {
		if (getAnswerList().size() != questions.size()) {
			new ChecklistAnswerCollection(getAnswerList()).createEmptyAnswers(
					questions, this);
		}
	}

	/**
	 * Fulfill reservation.
	 */
	public void fulfillReservation() {
		if (isReservationFulfillInProgress()) {
			reservation.fulfill();
		}
	}

	/**
	 * Gets the actual incremental charge amount.
	 *
	 * @return the actual incremental charge amount
	 */
	public BigDecimal getActualIncrementalChargeAmount() {
		return getChargeInfo().getActualIncrementalChargeAmount();
	}

	/**
	 * Gets the actual incremental duration display.
	 *
	 * @return the actual incremental duration display
	 */
	public String getActualIncrementalDurationDisplay() {
		return new SimpleTimePeriodFormatter().format(getChargeInfo()
				.getActualIncrementalDuration());
	}

	/**
	 * Gets the actual incremental time units.
	 *
	 * @return the actual incremental time units
	 */
	public Integer getActualIncrementalTimeUnits() {
		return getChargeInfo().getActualIncrementalTimeUnits();
	}

	/**
	 * Gets the agreement.
	 *
	 * @return the agreement
	 */
	public Agreement getAgreement() {
		return agreement;
	}

	/**
	 * Gets the answer list.
	 *
	 * @return the answer list
	 */
	public List<ChecklistAnswer> getAnswerList() {
		return getChargeInfo().getAnswerList();
	}

	/**
	 * Gets the answers.
	 *
	 * @return the answers
	 */
	public Set<ChecklistAnswer> getAnswers() {
		return getChargeInfo().getAnswers();
	}

	/**
	 * Gets the base duration display.
	 *
	 * @return the base duration display
	 */
	public String getBaseDurationDisplay() {
		return new SimpleTimePeriodFormatter().format(getChargeInfo()
				.getBaseSkuHrQty());
	}

	/**
	 * getter for the base price amount.
	 * 
	 * @return the value.
	 */
	public BigDecimal getBasePriceAmount() {
		return getChargeInfo().getBasePriceAmount();
	}

	/**
	 * Gets the base time units.
	 *
	 * @return the base time units
	 */
	public int getBaseTimeUnits() {
		return getChargeInfo().getBaseTimeUnits();
	}

	/**
	 * Gets the charge info.
	 *
	 * @return the charge info
	 */
	public ChargeInfo getChargeInfo() {
		return chargeInfo;
	}

	/**
	 * Gets the checkin date.
	 *
	 * @return the checkin date
	 */
	public Calendar getCheckinDate() {
		return getChargeInfo().getCheckinDate();
	}

	/**
	 * Gets the checkout date.
	 *
	 * @return the checkout date
	 */
	public Calendar getCheckoutDate() {
		return getChargeInfo().getCheckoutDate();
	}

	/**
	 * Gets the damage info.
	 *
	 * @return the damage info
	 */
	public DamageInfo getDamageInfo() {
		return damageInfo;
	}

	/**
	 * Gets the damage waiver.
	 *
	 * @return the damage waiver
	 */
	public DamageWaiver getDamageWaiver() {
		return getChargeInfo().getDamageWaiver();
	}

	/**
	 * Gets the damage waiver amount.
	 *
	 * @return the damage waiver amount
	 */
	public BigDecimal getDamageWaiverAmount() {
		return getChargeInfo().getDamageWaiverAmount();
	}

	/**
	 * Gets the total additional charge amount.
	 *
	 * @return the total additional charge amount
	 */
	public BigDecimal getDamageWaiverCredit() {
		return getChargeInfo().getDamageWaiver().getCreditAmount();
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return item.getDescription();
	}

	/**
	 * Gets the difference of estimated and actual incremental charge amount.
	 *
	 * @return the difference of estimated and actual incremental charge amount
	 */
	public BigDecimal getDifferenceOfEstimatedAndActualIncrementalChargeAmount() {
		return getChargeInfo().getAdditionalIncrementalChargeAmount();
	}

	/**
	 * Gets the difference of estimated and actual incremental time units.
	 *
	 * @return the difference of estimated and actual incremental time units
	 */
	public int getDifferenceOfEstimatedAndActualIncrementalTimeUnits() {
		return getChargeInfo().getAdditionalIncrementalTimeUnits();
	}

	/**
	 * Gets the due by.
	 *
	 * @return the due by
	 */
	public Calendar getDueBy() {
		return getChargeInfo().getDueBy();
	}

	/**
	 * Gets the estimated charge amount without surcharge.
	 *
	 * @return the estimated charge amount without surcharge
	 */
	public BigDecimal getEstimatedChargeAmountWithoutSurcharge() {
		return chargeInfo.getEstimatedChargeAmountWithoutSurcharge();
	}

	/**
	 * Gets the estimated incremental charge amount.
	 *
	 * @return the estimated incremental charge amount
	 */
	public BigDecimal getEstimatedIncrementalChargeAmount() {
		return getChargeInfo().getIncrementalChargeAmount();
	}

	/**
	 * Gets the estimated incremental time units.
	 *
	 * @return the estimated incremental time units
	 */
	public int getEstimatedIncrementalTimeUnits() {
		return getChargeInfo().getIncrementalTimeUnits();
	}

	/**
	 * Returns the Incremental time units based on status. If the item is
	 * checked out it will return estimaged times units If the item is returned
	 * and agreement is active it will return additional time units If the item
	 * is returned and agreement is voided it will return Estimated time units
	 * but negative.
	 *
	 * @return the Incremental time units by status.
	 */
	public int getIncrementalTimeUnitsByStatus() {
		if (isCheckedOut()) {
			return getEstimatedIncrementalTimeUnits();
		}
		if (isReturned() && !agreement.isVoided()) {
			return chargeInfo.getAdditionalIncrementalTimeUnits();
		}
		if (agreement.isVoided()) {
			return -1 * getEstimatedIncrementalTimeUnits();
		}
		return 0;
	}

	/**
	 * Returns the applicable damage waiver by status of the agreement item. If
	 * the item is checked out it will return estimaged damage waiver If the
	 * item is returned and agreement is active it will return damage waiver
	 * credit amount If the item is returned and agreement is voided it will
	 * return Estimated damage waiver but negative.
	 * 
	 * @return
	 */
	public BigDecimal getDamageWaiverAmountByStatus() {
		if (isCheckedOut()) {
			return getDamageWaiverAmount();
		}
		if (agreement.isVoided()) {
			return getDamageWaiverAmount().multiply(new BigDecimal("-1.0"));
		}
		if (isReturned()) {
			return getDamageWaiverCredit();
		}

		return Constants.DamageWaiver.DAMAGE_WAIVER_DEFAULT_AMOUNT;
	}

	/**
	 * Gets the checks for price override.
	 *
	 * @return the checks for price override
	 */
	public boolean getHasPriceOverride() {
		return getNotNullOverride().getHasPriceOverride();
	}

	/**
	 * Gets the checks for quantity override.
	 *
	 * @return the checks for quantity override
	 */
	public boolean getHasQuantityOverride() {
		return getNotNullOverride().getHasQuantityOverride();
	}

	/**
	 * Gets the incremental duration display.
	 *
	 * @return the incremental duration display
	 */
	public String getIncrementalDurationDisplay() {
		return new SimpleTimePeriodFormatter().format(getChargeInfo()
				.getIncrementalSkuHrQty());
	}

	/**
	 * Getter for the incremental price amount.
	 * 
	 * @return the value.
	 */
	public BigDecimal getIncrementalPriceAmount() {
		return getChargeInfo().getIncrementalPriceAmount();
	}

	/**
	 * Gets the damage waiver status.
	 *
	 * @return if damage waiver is available for the associated product
	 */
	public Boolean getIsDamageWaiverAvailable() {
		return item.getProduct().getIsDamageWaiverAvailable();
	}

	/**
	 * Gets the item.
	 *
	 * @return the item
	 */
	public Item getItem() {
		return item;
	}

	/**
	 * Gets the item id.
	 *
	 * @return the item id
	 */
	public Long getItemId() {
		return item.getId();
	}

	/**
	 * Gets the manufacture serial value.
	 *
	 * @return the manufacture serial value
	 */
	public String getManufactureSerialValue() {
		return item.getManufactureSerialValue();
	}

	/**
	 * Gets the not null damage info.
	 *
	 * @return the not null damage info
	 */
	public DamageInfo getNotNullDamageInfo() {
		if (null == getDamageInfo()) {
			setDamageInfo(new DamageInfo());
		}
		return getDamageInfo();
	}

	/**
	 * Gets the not null override.
	 *
	 * @return the not null override
	 */
	public AgreementItemOverride getNotNullOverride() {
		if (null != getOverride()) {
			return getOverride();
		}
		setOverride(new AgreementItemOverride());
		return getOverride();
	}

	/**
	 * Returns a list of overlapping open reservations. This list is for the
	 * checkout to due by date.
	 * 
	 * @return list of overlapping reservations.
	 */
	public List<Reservation> getOverlappingOpenReservations() {
		return item.getOverlappingOpenReservationsFor(getCheckoutDate(),
				getDueBy());
	}

	/**
	 * Gets the override incremental time units.
	 *
	 * @return the override incremental time units
	 */
	public int getOverrideIncrementalTimeUnits() {
		return getChargeInfo().getActualIncrementalTimeUnits();
	}

	/**
	 * Gets the price override by name.
	 *
	 * @return the price override by name
	 */
	public Integer getPriceOverrideByNumber() {
		return getNotNullOverride().getPriceOverrideByNumber();
	}

	/**
	 * Gets the product id.
	 *
	 * @return the product id
	 */
	public Long getProductId() {
		return getItem().getProductId();
	}

	/**
	 * Gets the quantity override by name.
	 *
	 * @return the quantity override by name
	 */
	public Integer getQuantityOverrideByNumber() {
		return getNotNullOverride().getQuantityOverrideByNumber();
	}

	/**
	 * As we store the rental duration in double hours, we need to build the
	 * display string for duration based on hour and minutes.
	 *
	 * @return the rental duration display
	 */
	public String getRentalDurationDisplay() {
		return new SimpleTimePeriodFormatter().format(getChargeInfo()
				.getEstimatedRentalDuration());
	}

	/**
	 * Gets the rental sku.
	 *
	 * @return the rental sku
	 */
	public String getRentalSKU() {
		return item.getRentalSKU();
	}

	/**
	 * Gets the reservation override by name.
	 *
	 * @return the reservation override by name
	 */
	public Integer getReservationOverrideByName() {
		return override.getReservationOverrideByNumber();
	}

	/**
	 * Gets the serial number.
	 *
	 * @return the serial number
	 */
	public Long getSerialNumber() {
		return item.getSerialNumber();
	}

	/**
	 * The getter for the surcharge price amount.
	 * 
	 * @return the value.
	 */
	public BigDecimal getSurchargePriceAmount() {
		return getChargeInfo().getSurchargePriceAmount();
	}

	/**
	 * Gets the total additional charge amount.
	 *
	 * @return the total additional charge amount
	 */
	public BigDecimal getTotalAdditionalChargeAmount() {
		return getChargeInfo().getTotalAdditionalChargeAmount();
	}

	/**
	 * Returns the total additional charge amount with the damage waiver credit
	 * if any.
	 * 
	 * @return the total additional charge plus the damage waiver credit if any.
	 */
	public BigDecimal getTotalAdditionalChargeAmountAndDamageWaiverCredit() {
		BigDecimal totalAdditionalChargeAmountWithDamageWaiver = getTotalAdditionalChargeAmount();
		if (getIsDamageWaiverAvailable()) {
			totalAdditionalChargeAmountWithDamageWaiver = totalAdditionalChargeAmountWithDamageWaiver
					.add(getDamageWaiverCredit());
		}
		return totalAdditionalChargeAmountWithDamageWaiver.setScale(
				Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
	}

	/**
	 * Gets the total estimated charge amount.
	 *
	 * @return the total estimated charge amount
	 */
	public BigDecimal getTotalEstimatedChargeAmount() {
		return getChargeInfo().getTotalEstimatedChargeAmount();
	}

	/**
	 * Gets the usage tracking enabled.
	 *
	 * @return the usage tracking enabled
	 */
	public Boolean getUsageTrackingEnabled() {
		return item.isUsageTrackingEnabled();
	}

	/**
	 * Gets the vehicle rental detail.
	 *
	 * @return the vehicle rental detail
	 */
	public VehicleRentalDetail getVehicleRentalDetail() {
		return vehicleRentalDetail;
	}

	/**
	 * Checks if is agreement voided.
	 *
	 * @return true, if is agreement voided
	 */
	public boolean isAgreementVoided() {
		return agreement.isVoided();
	}

	/**
	 * Checks if is available.
	 *
	 * @return true, if is available
	 */
	public boolean isAvailable() {
		return item.isAvailable();
	}

	/**
	 * Checks if is checkedin.
	 *
	 * @return true, if is checkedin
	 */
	public boolean isCheckedin() {
		return isCheckedin;
	}

	/**
	 * Checks if is checked out.
	 *
	 * @return true, if is checked out
	 */
	public boolean isCheckedOut() {
		return status.isCheckedOut();
	}

	/**
	 * Checks if item is checked out and paid.
	 *
	 * @return true, if is checked out and paid
	 */
	public boolean isCheckedOutAndPaid() {
		return status.isCheckedOutAndPaidInitial();
	}

	/**
	 * Checks if is driver age greater than minimum rental age.
	 *
	 * @param agreement
	 *            the agreement
	 * @return true, if is driver age greater than minimum rental age
	 */
	public boolean isDriverAgeGreaterThanMinimumRentalAge(
			final Agreement agreement) {
		return item.isDriverAgeGreaterThanMinimumRentalAge(agreement);
	}

	/**
	 * Checks if is insurance additional driver license required.
	 *
	 * @return true, if is insurance additional driver license required
	 */
	public boolean isInsuranceAdditionalDriverLicenseRequired() {
		return item.isInsuranceAdditionalDriverLicenseRequired();
	}

	/**
	 * Checks if is not checked in.
	 *
	 * @return true, if is not checked in
	 */
	public boolean isNotCheckedIn() {
		return (null == getCheckinDate());
	}

	/**
	 * Gets the checks for reservation override.
	 *
	 * @return the checks for reservation override
	 */
	public boolean isReservationBeingFulfilledOrHasReservationOverride() {
		return (isReservationFulfillInProgress() || isReservationOverridden());
	}

	/**
	 * Checks if is reservation fulfill in progress.
	 *
	 * @return true, if is reservation fulfill in progress
	 */
	public boolean isReservationFulfillInProgress() {
		return (null != reservation);
	}

	/**
	 * The method returns true ifthe reservation is overridden.
	 * 
	 * @return true if the reservation is overriden.
	 */
	public boolean isReservationOverridden() {
		return override.getHasReservationOverride();
	}

	/**
	 * Checks if is returned.
	 *
	 * @return true, if is returned
	 */
	public boolean isReturned() {
		return status.isReturned();
	}

	/**
	 * Checks if is returned and paid complete.
	 *
	 * @return true, if is returned and paid complete
	 */
	public boolean isReturnedAndPaidComplete() {
		return status.isReturnedAndPaidComplete();
	}

	/**
	 * Returns true if the item is marked for checkin and still the chekin
	 * questions have not been asked.
	 * 
	 * @return true if the item is marked for checkin but checklist question
	 *         have not be answered.
	 */
	public boolean isToBeCheckedin() {
		return (isCheckedin() && getAnswerList().isEmpty());
	}

	/**
	 * Checks if is transient.
	 *
	 * @return true, if is transient
	 */
	public boolean isTransient() {
		return (null == getId());
	}

	/**
	 * Mark to checkin.
	 */
	public void markToCheckin() {
		setCheckedin(true);
		chargeInfo.markToCheckin();
	}

	/**
	 * Matches.
	 *
	 * @param matchingItem
	 *            the matching item
	 * @return true, if successful
	 */
	public boolean matches(final AgreementItem matchingItem) {
		return getItem().matches(matchingItem.getItem());
	}

	/**
	 * Matches.
	 *
	 * @param serialNumber
	 *            the serial number
	 * @return the boolean
	 */
	public Boolean matches(final Long serialNumber) {
		return item.matches(serialNumber);
	}

	/**
	 * Merge.
	 *
	 * @param vehicleRentalDetail
	 *            the vehicle rental detail
	 */
	public void merge(final VehicleRentalDetail vehicleRentalDetail) {
		updateIfRequiredVehicleRentalDetail();
		getVehicleRentalDetail().merge(getItem(), vehicleRentalDetail);
	}

	/**
	 * Persist item.
	 */
	public void persistItem() {
		item.persist();
	}

	/**
	 * Sets the agreement.
	 *
	 * @param agreement
	 *            the new agreement
	 */
	public void setAgreement(final Agreement agreement) {
		this.agreement = agreement;
	}

	/**
	 * Sets the answer list.
	 *
	 * @param answerList
	 *            the new answer list
	 */
	public void setAnswerList(final List<ChecklistAnswer> answerList) {
		getChargeInfo().setAnswerList(answerList);
	}

	/**
	 * Sets the answers.
	 *
	 * @param answers
	 *            the new answers
	 */
	public void setAnswers(final Set<ChecklistAnswer> answers) {
		getChargeInfo().setAnswers(answers);
	}

	/**
	 * Sets the charge info.
	 *
	 * @param chargeInfo
	 *            the new charge info
	 */
	public void setChargeInfo(final ChargeInfo chargeInfo) {
		this.chargeInfo = chargeInfo;
	}

	/**
	 * Sets the checkedin.
	 *
	 * @param checkedin
	 *            the new checkedin
	 */
	public void setCheckedin(final boolean checkedin) {
		isCheckedin = checkedin;
	}

	/**
	 * Sets the checkin date.
	 *
	 * @param checkinDate
	 *            the new checkin date
	 */
	public void setCheckinDate(final Calendar checkinDate) {
		getChargeInfo().setCheckinDate(checkinDate);
		agreement.setCheckinDate(checkinDate);
	}

	/**
	 * Sets the checkout date.
	 *
	 * @param checkoutDate
	 *            the new checkout date
	 */
	public void setCheckoutDate(final Calendar checkoutDate) {
		getChargeInfo().setCheckoutDate(checkoutDate);
	}

	/**
	 * Sets the damage info.
	 *
	 * @param damageInfo
	 *            the new damage info
	 */
	public void setDamageInfo(final DamageInfo damageInfo) {
		this.damageInfo = damageInfo;
	}

	/**
	 * Sets the damage waiver.
	 *
	 * @param damageWaiver
	 *            the new damage waiver
	 */
	public void setDamageWaiver(final DamageWaiver damageWaiver) {
		getChargeInfo().setDamageWaiver(damageWaiver);
	}

	/**
	 * Sets the due by.
	 *
	 * @param dueBy
	 *            the new due by
	 */
	public void setDueBy(final Calendar dueBy) {
		getChargeInfo().setDueBy(dueBy);
	}

	/**
	 * Sets the estimated charge amount without surcharge.
	 *
	 * @param estimatedChargeAmountWithoutSurcharge
	 *            the new estimated charge amount without surcharge
	 */
	public void setEstimatedChargeAmountWithoutSurcharge(
			final BigDecimal estimatedChargeAmountWithoutSurcharge) {
		getChargeInfo().doPriceOverride(estimatedChargeAmountWithoutSurcharge);
	}

	/**
	 * Sets the item.
	 *
	 * @param item
	 *            the new item
	 */
	public void setItem(final Item item) {
		this.item = item;
	}

	/**
	 * Sets the not null damage info.
	 *
	 * @param damageInfo
	 *            the new not null damage info
	 */
	public void setNotNullDamageInfo(final DamageInfo damageInfo) {
		this.damageInfo = damageInfo;
	}

	/**
	 * Sets the not null override.
	 *
	 * @param override
	 *            the new not null override
	 */
	public void setNotNullOverride(final AgreementItemOverride override) {
		setOverride(override);
	}

	/**
	 * Sets the override incremental time units.
	 *
	 * @param overridenIncrementalTimeUnits
	 *            the new override incremental time units
	 */
	public void setOverrideIncrementalTimeUnits(
			final int overridenIncrementalTimeUnits) {
		getChargeInfo().doQuantityOverride(overridenIncrementalTimeUnits);
	}

	/**
	 * Sets the price override by name.
	 *
	 * @param managerNumber
	 *            the new price override by name
	 */
	public void setPriceOverrideByNumber(final Integer managerNumber) {
		override.setPriceOverrideByNumber(managerNumber);
	}

	/**
	 * Sets the quantity override by name.
	 *
	 * @param quantityOverrideManagerNumber
	 *            the new quantity override by name
	 */
	public void setQuantityOverrideByNumber(
			final Integer quantityOverrideManagerNumber) {
		override.setQuantityOverrideByNumber(quantityOverrideManagerNumber);
	}

	/**
	 * Sets the reservation against product.
	 *
	 * @param reservation
	 *            the new reservation against product
	 */
	public void setReservationAgainstProduct(final Reservation reservation) {
		this.reservation = reservation;
	}

	/**
	 * Sets the vehicle rental detail.
	 *
	 * @param vehicleRentalDetail
	 *            the new vehicle rental detail
	 */
	public void setVehicleRentalDetail(
			final VehicleRentalDetail vehicleRentalDetail) {
		this.vehicleRentalDetail = vehicleRentalDetail;
	}

	/**
	 * This method will update the checkout date of the agreement item.
	 * 
	 * @param transactionDate
	 *            the actual checkout date of the agreement item.
	 */
	public void updateCheckoutDate(final Calendar transactionDate) {
		setCheckoutDate(transactionDate);
		item.setLastRentedDate(transactionDate);
	}

	/**
	 * Update item status.
	 *
	 * @param itemStatus
	 *            the item status
	 */
	public void updateItemStatus(final ItemStatus itemStatus) {
		item.setItemStatus(itemStatus);
	}

	/**
	 * Update overrides.
	 */
	public void updateOverrides() {
		if (null != override) {
			override.updateOverrideReason();
		}
	}

	/**
	 * Returns the overll comment escaped html.
	 * 
	 * @return the overall comment value escaped html format.
	 */
	public String getOverallCommentEscaped() {
		return StringEscapeUtils.escapeHtml(overallComment);
	}

	/**
	 * The method that returns true if the initial charge i.e. base + surcharge
	 * is not applicable.
	 * 
	 * @return the method that returns true if base charge i.e. base + surcharge
	 *         is not applicable.
	 */
	public boolean isInitialChargeNotApplicable() {
		return !agreement.isVoided() && isReturned();
	}

	/**
	 * Update if required vehicle rental detail.
	 */
	private void updateIfRequiredVehicleRentalDetail() {
		if (null == getVehicleRentalDetail()) {
			final VehicleRentalDetail rentalDetail = new VehicleRentalDetail();
			rentalDetail.setAgreementItem(this);
			setVehicleRentalDetail(rentalDetail);
		}
	}

	public int compareTo(AgreementItem otherAgreementItem) {
		int result;

		if (this.getItem().getProduct().getBaseSkuValue().longValue() == otherAgreementItem
				.getItem().getProduct().getBaseSkuValue().longValue()) {
			result = 0;
		} else if (this.getItem().getProduct().getBaseSkuValue().longValue() > otherAgreementItem
				.getItem().getProduct().getBaseSkuValue().longValue()) {
			result = 1;
		} else {
			result = -1;
		}

		return result;
	}

	public List<QuestionDto> getCheckOutQuestionList() {
		return checkOutQuestionList;
	}

	public void setCheckOutQuestionList(List<QuestionDto> checkOutQuestionList) {
		this.checkOutQuestionList = checkOutQuestionList;
	}

	public List<QuestionDto> getCheckInQuestionList() {
		return checkInQuestionList;
	}

	public void setCheckInQuestionList(List<QuestionDto> checkInQuestionList) {
		this.checkInQuestionList = checkInQuestionList;
	}

	
}
