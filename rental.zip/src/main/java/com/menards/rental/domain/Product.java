/*
 * Product.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.*;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.*;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

/**
 * The Class Product.
 * @author deep
 */
@Entity
@RooJavaBean
@RooEntity(identifierColumn = "product_id")
@Table(name = "product")
public class Product implements Serializable {

	/** The items. */
    @Filter(name = "currentStoreItems", condition = "store_nbr = :storeNumber")
	@OneToMany(targetEntity = Item.class, 
			cascade = { CascadeType.ALL }, mappedBy = "product", fetch = FetchType.LAZY)
	@Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<Item> items = new HashSet<Item>();

	/** The sku info. */
	@Embedded
	private SKUInfo skuInfo = new SKUInfo();

	/*
	 * If the flag is not set in database, than consider it false and make that
	 * the default value.
	 */
	/** The usage tracking flag. */
	@Column(name = "usage_tracking_flg")
	@Type(type = "yes_no")
	private Boolean usageTrackingFlag = false;

	/** The usage tracking text. */
	@Column(name = "usage_tracking_txt")
	private String usageTrackingText;

	/** The description. */
	@Column(name = "product_desc", nullable = false)
	private String description;

	/** The rental prompt text. */
	@Column(name = "rental_prompt_txt", length = 410)
	private String rentalPromptText;

	/** The is driver license required. */
	@Column(name = "driver_license_required_flg")
	@Type(type = "yes_no")
	private Boolean isDriverLicenseRequired = true;

	/** The is insurance additional driver license required. */
	@Column(name = "insurance_additional_driver_flg")
	@Type(type = "yes_no")
	private Boolean isInsuranceAdditionalDriverLicenseRequired = false;

	/** The is sale allowed. */
	@Column(name = "allow_sale_flg")
	@Type(type = "yes_no")
	private Boolean isSaleAllowed = false;

	/** The minimum age to rent. */
	@Column(name = "min_age_rental_nbr")
	private int minimumAgeToRent;

	/** The vendor email. */
	@Column(name = "vendor_email_address")
	private String vendorEmail;

	/** The is damage waiver required. */
	@Column(name = "damage_waiver_flg")
	@Type(type = "yes_no")
	private Boolean isDamageWaiverAvailable = false;

	/**
	 * Instantiates a new product.
	 */
	public Product() {
	}

	/**
	 * Instantiates a new product.
	 *
	 * @param desc the desc
	 */
	public Product(final String desc) {
		this.description = desc;
	}

    /**
     * Returns the product based on the base sku value passed as argument.
     * @param baseSKUId the base sku value.
     * @return Product instance matching the base sku value.
     */
	public static Product findProductByBaseSKUId(final long baseSKUId) {
        final List<Product> products = entityManager()
                .createQuery("from Product p where p.skuInfo.baseSKU.id=:baseSKUId")
                .setParameter("baseSKUId", baseSKUId)
                .getResultList();

        if (products.isEmpty()) {
        	return null;
        }

        return products.get(0);
    }

    /**
	 * Copy description.
	 */
	public void copyDescription() {
		setDescription(getSkuInfo().getDescription());
	}

    /**
     * Copies information from the other product.
     * @param other the other product reference from which we have to copy the information.
     */
	public void copyOtherInformationFrom(final Product other) {
        setUsageTrackingFlag(other.getUsageTrackingFlag());
        setUsageTrackingText(other.getUsageTrackingText());
        setRentalPromptText(other.getRentalPromptText());
        setIsDriverLicenseRequired(other.getIsDriverLicenseRequired());
        setIsInsuranceAdditionalDriverLicenseRequired(other.getIsInsuranceAdditionalDriverLicenseRequired());
        setIsSaleAllowed(other.getIsSaleAllowed());
        setMinimumAgeToRent(other.getMinimumAgeToRent());
        setVendorEmail(other.getVendorEmail());
        setIsDamageWaiverAvailable(other.getIsDamageWaiverAvailable());
        skuInfo.copyHoursFrom(other.getSkuInfo());
    }

	/**
	 * Copy values from sku.
	 */
	public void copyValuesFromSKU() {
		copyDescription();
	}

	/**
	 * Count actually overlapping reservations for store.
	 *
	 * @param storeNumber the store number
	 * @param outDate the out date
	 * @param inDate the in date
	 * @return the int
	 */
	public int countActuallyOverlappingReservationsForStore(final Integer storeNumber, final Calendar outDate,
	        final Calendar inDate) {
		return new ReservationCollection(getSortedOpenReservations(storeNumber))
		        .countMinimumNumberOfItemsRequiredToFulfillCurrentReservationsForAStoreForGivenDuration(storeNumber,
		                outDate, inDate);
	}

	/**
	 * Creates the charge info.
	 *
	 * @return the charge info
	 */
	public ChargeInfo createChargeInfo() {
		return skuInfo.createChargeInfo();
	}

	/**
	 * Returns whether or not its allowable to sell this SKU
	 * 
	 * @return {@link Boolean} isSaleAllowed
	 */
	public boolean isSaleAllowed()
	{
		return isSaleAllowed;
	}
    /**
	 * Gets the base sku hr qty.
	 *
	 * @return the base sku hr qty
	 */
	public double getBaseSkuHrQty() {
		return skuInfo.getBaseSkuHrQty();
	}

	/**
     * Getter for base sku value.
     * @return base sku value.
     */
    public Long getBaseSkuValue() {
        return skuInfo.getBaseSkuValue();
    }

	/**
     * Getter for selling sku value.
     * @return selling sku value.
     */
    public Long getSellingSkuValue() {
        return skuInfo.getSellingSkuValue();
    }

	/**
	 * Gets the bask sku id.
	 *
	 * @return the bask sku id
	 */
	public Long getBaskSKUId() {
		return getSkuInfo().getBaseSKUId();
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

    /**
     * Returns the escaped description.
     * @return retus the escaped description value.
     */
    public String getDescriptionEscaped() {
        return StringEscapeUtils.escapeHtml(description);
    }

	/**
	 * Gets the formatted base sku.
	 *
	 * @return the formatted base sku
	 */
	public String getFormattedBaseSKU() {
		return getSkuInfo().getFormattedBaseSKU();
	}

	/**
	 * Gets the formatted name.
	 *
	 * @return the formatted name
	 */
	public String getFormattedName() {
		return skuInfo.getFormattedBaseSKU() + ": " + description;
	}

    /**
	 * Gets the incremental sku hr qty.
	 *
	 * @return the incremental sku hr qty
	 */
	public double getIncrementalSkuHrQty() {
		return skuInfo.getIncrementalSkuHrQty();
	}

	/**
	 * Gets the incremental sku id.
	 *
	 * @return the incremental sku id
	 */
	public Long getIncrementalSKUId() {
		return getSkuInfo().getIncrementalSKUId();
	}

	/**
     * The getter for the incremental sku value.
     * @return the value.
     */
    public Long getIncrementalSkuValue() {
        return skuInfo.getIncrementalSkuValue();
    }

	/**
	 * Gets the insurance additional driver license required.
	 *
	 * @return the insurance additional driver license required
	 */
	public Boolean getInsuranceAdditionalDriverLicenseRequired() {
		return isInsuranceAdditionalDriverLicenseRequired;
	}

	/**
	 * Gets the items.
	 *
	 * @return the items
	 */
	public Set<Item> getItems() {
		return items;
	}

    /**
     * Returns the sroted list of items held by the product by serial number.
     * @return the list of items sorted by serial number.
     */
    public List<Item> getItemsBySerialNumber() {
        return new ItemCollection(items).getSortedListBySerialNumber();
    }

	/**
	 * Gets the non overlapping reservations list for store.
	 *
	 * @param storeNumber the store number
	 * @param outDate the out date
	 * @param inDate the in date
	 * @return the non overlapping reservations list for store
	 */
	public List<List<Reservation>> getNonOverlappingReservationsListForStore(final Integer storeNumber,
	        final Calendar outDate, final Calendar inDate) {
		return new ReservationCollection(getSortedOpenReservations(storeNumber))
                .getNonOverlappingReservationsListForStore(storeNumber, outDate, inDate);
	}
	
	/**
	 * Gets the open reservations for.
	 *
	 * @param storeNumber the store number
	 * @return the open reservations for
	 */
	public List<Reservation> getOpenReservationsFor(final Integer storeNumber) {
		final List<Reservation> reservationList = entityManager()
		.createQuery("from Reservation r where r.agreement.store.storeNumber=:storeNumber and r.product.skuInfo.baseSKU.id=:baseSKUid")
		.setParameter("storeNumber", storeNumber)
		.setParameter("baseSKUid", this.skuInfo.getBaseSKUId())
		.getResultList();
		
		Set<Reservation> reservationSet = new HashSet<Reservation>(reservationList);
		
		return new ReservationCollection(reservationSet).getOpenReservations();
		
	}

	/**
	 * Gets the overlapping open reservations for store.
	 *
	 * @param storeNumber the store number
	 * @param outDate the out date
	 * @param inDate the in date
	 * @return the overlapping open reservations for store
	 */
	public List<Reservation> getOverlappingOpenReservationsForStore(final Integer storeNumber,
	        final Calendar outDate, final Calendar inDate) {
		return new ReservationCollection(getOpenReservationsFor(storeNumber)).getOverlappingOpenReservationsForStore(
                storeNumber, outDate, inDate);
	}


	/**
	 * Gets the selling sku id.
	 *
	 * @return the selling sku id
	 */
	public Long getSellingSKUId() {
		return getSkuInfo().getSellingSKUId();
	}

	/**
	 * Gets the sku info.
	 *
	 * @return the sku info.
	 */
	public SKUInfo getSkuInfo() {
		return skuInfo;
	}

    /**
	 * Gets the surcharge sku id.
	 *
	 * @return the surcharge sku id
	 */
	public Long getSurchargeSKUId() {
		return getSkuInfo().getSurchargeSKUId();
	}

	/**
     * The getter for the surcharge sku value.
     * @return the value.
     */
    public Long getSurchargeSkuValue() {
        return skuInfo.getSurchargeSkuValue();
    }

	/**
	 * Checks for any reservations for.
	 *
	 * @param storeNumber the store number
	 * @return true, if successful
	 */
	public boolean hasAnyReservationsFor(final Integer storeNumber) {
		return new ReservationCollection(getSortedOpenReservations(storeNumber)).isAnyReservationForStore(storeNumber);
	}

	/**
	 * Checks for overlapping reservations for.
	 *
	 * @param storeNumber the store number
	 * @param outDate the out date
	 * @param inDate the in date
	 * @return true, if successful
	 */
	public boolean hasOverlappingReservationsFor(final Integer storeNumber, final Calendar outDate,
	        final Calendar inDate) {
		return new ReservationCollection(getSortedOpenReservations(storeNumber))
                .isAnyReservationOverlappingForStore(storeNumber, outDate, inDate);
	}

	/**
	 * Checks if is driver age greater than minimum rental age.
	 *
	 * @param agreement the agreement
	 * @return true, if is driver age greater than minimum rental age
	 */
	public boolean isDriverAgeGreaterThanMinimumRentalAge(final Agreement agreement) {
		return agreement.isDriverAgeGreaterThanMinimumRentalAge(minimumAgeToRent);
	}

    /**
     * Returns true if the guest meets the age limit.
     * @param guest the guest under question.
     * @return true if the guest meets the age limit, false otherwise.
     */
    public boolean isGuestAgeGreaterThanMinimumAge(final Guest guest) {
        return guest.isDriverAgeGreaterThanMinimumRentalAge(minimumAgeToRent);
    }

	/**
	 * Checks if is driver license required.
	 *
	 * @return the boolean
	 */
	public Boolean isDriverLicenseRequired() {
		return isDriverLicenseRequired;
	}

	/**
	 * Checks if is id matching.
	 *
	 * @param productId the product id
	 * @return true, if is id matching
	 */
	public boolean isIdMatching(final long productId) {
		return getId() == productId;
	}

	/**
	 * Checks if is insurance additional driver license required.
	 *
	 * @return the boolean
	 */
	public Boolean isInsuranceAdditionalDriverLicenseRequired() {
		return isInsuranceAdditionalDriverLicenseRequired;
	}

	/**
     * Method to find whether the surcharge sku is setup or not.
     * @return true if surcharge sku is setup.
     */
    public boolean isSurchargeSKUSetup() {
        return skuInfo.isSurchargeSKUSetup();
    }

	/**
	 * Sets the base sku.
	 *
	 * @param baseSKU the new base sku
	 */
	public void setBaseSKU(final RentalSKU baseSKU) {
		getSkuInfo().setBaseSKU(baseSKU);
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(final String description) {
		this.description = description;
	}

	/**
	 * Sets the incremental sku.
	 *
	 * @param incrementalSKU the new incremental sku
	 */
	public void setIncrementalSKU(final RentalSKU incrementalSKU) {
		getSkuInfo().setIncrementalSKU(incrementalSKU);
	}

	/**
	 * Sets the insurance additional driver license required.
	 *
	 * @param insuranceAdditionalDriverLicenseRequired the new insurance additional driver license required
	 */
	public void setInsuranceAdditionalDriverLicenseRequired(final Boolean insuranceAdditionalDriverLicenseRequired) {
		isInsuranceAdditionalDriverLicenseRequired = insuranceAdditionalDriverLicenseRequired;
	}

    /**
	 * Sets the items.
	 *
	 * @param items the new items
	 */
	public void setItems(final Set<Item> items) {
		this.items = items;
	}

    /**
	 * Sets the selling sku.
	 *
	 * @param sellingSKU the new selling sku
	 */
	public void setSellingSKU(final RentalSKU sellingSKU) {
		getSkuInfo().setSellingSKU(sellingSKU);
	}

    /**
	 * Sets the sku info.
	 *
	 * @param skuInfo the new sku info
	 */
	public void setSkuInfo(final SKUInfo skuInfo) {
		this.skuInfo = skuInfo;
	}

    /**
	 * Sets the surcharge sku.
	 *
	 * @param surchargeSKU the new surcharge sku
	 */
	public void setSurchargeSKU(final RentalSKU surchargeSKU) {
		getSkuInfo().setSurchargeSKU(surchargeSKU);
	}

    /**
     * Gets the formatted surcharge sku.
     *
     * @return the formatted surcharge sku
     */
    public String getFormattedSurchargeSKU() {
        return skuInfo.getFormattedSurchargeSKU();
    }

    /**
     * {@inheritDoc}
     */
	@Override
	public String toString() {
		if (null != this.getId()) {
			return this.getId().toString();
		} else {
			return null;
		}
	}

    /**
     * Returns the list of products that have vendor email setup.
     * @return the list of product with vendor email setup.
     */
    public static List<Product> findAllProductsByVendorEmailNotNullOrEmpty() {
        final Query query = entityManager()
                .createQuery("SELECT Product FROM Product AS product "
                        + "WHERE product.vendorEmail IS NOT NULL  AND product.vendorEmail != :vendorEmail");
        query.setParameter("vendorEmail", "");
        return query.getResultList();
    }

    /**
     * Returns the count of availale items for the store.
     * @return the integer value representing the count of available items.
     */
    public int getAvailableCount() {
        return new ItemCollection(items).countAvailable();
    }

    /**
	 * Gets the sorted open reservations.
	 *
	 * @return the sorted open reservations
	 */
	private List<Reservation> getSortedOpenReservations(final int storeNbr) {
		return getOpenReservationsFor(storeNbr);
	}
}
