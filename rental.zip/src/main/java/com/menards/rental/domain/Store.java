/*
 * Store.java
 */
package com.menards.rental.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Transient;

import org.apache.commons.lang.StringEscapeUtils;

/**
 * The Class Store.
 */
@Embeddable
public class Store implements Serializable, Cachable {

	/** The store number. */
	@Column(name = "store_nbr")
	private Integer storeNumber;

	/** The store name. */
	@Column(name = "store_name")
	private String storeName;

	/** The store address1. */
	@Column(name = "store_address1")
	private String storeAddress1;

	/** The store address2. */
	@Column(name = "store_address2")
	private String storeAddress2;

	/** The store phone number. */
	@Column(name = "store_phone_nbr")
	private String storePhoneNumber;

	/** The store postal number. */
	@Column(name = "store_postal_cd")
	private Integer storePostalNumber;

	/** The store fax number. */
	@Column(name = "store_fax_nbr")
	private String storeFaxNumber;

    /** The store abbreviation. */
    @Column(name = "store_abbr")
    private String storeAbbreviation;

    /** The store kioskHost. */
    @Transient
    private String kioskHost;

    /**
     * The getter for store abbreviation.
     * @return the value.
     */
    public String getStoreAbbreviation() {
        return storeAbbreviation;
    }

	/**
	 * Gets the store address1.
	 *
	 * @return the store address1
	 */
	public String getStoreAddress1() {
		return storeAddress1;
	}

	/**
	 * Gets the store address2.
	 *
	 * @return the store address2
	 */
	public String getStoreAddress2() {
		return storeAddress2;
	}

	/**
	 * Gets the store fax number.
	 *
	 * @return the store fax number
	 */
	public String getStoreFaxNumber() {
		return storeFaxNumber;
	}

	/**
	 * Gets the store name.
	 *
	 * @return the store name
	 */
	public String getStoreName() {
		return storeName;
	}

	/**
	 * Gets the HTML escaped store name.
	 *
	 * @return the store name
	 */
	public String getStoreNameEscaped() {
		return StringEscapeUtils.escapeHtml(storeName);
	}
	
	/**
	 * Gets the store number.
	 *
	 * @return the store number
	 */
	public Integer getStoreNumber() {
		return storeNumber;
	}

	/**
	 * Gets the store phone number.
	 *
	 * @return the store phone number
	 */
	public String getStorePhoneNumber() {
		return storePhoneNumber;
	}

	/**
	 * Gets the store postal number.
	 *
	 * @return the store postal number
	 */
	public Integer getStorePostalNumber() {
		return storePostalNumber;
	}

	/**
	 * Checks if is matching.
	 *
	 * @param storeNumber the store number
	 * @return true, if is matching
	 */
	public boolean isMatching(final Integer storeNumber) {
		return this.storeNumber.equals(storeNumber);
	}

	/**
     * Setter for the store abbreviation.
     * @param storeAbbreviation the value.
     */
    public void setStoreAbbreviation(final String storeAbbreviation) {
        this.storeAbbreviation = storeAbbreviation;
    }

	/**
	 * Sets the store address1.
	 *
	 * @param storeAddress1 the new store address1
	 */
	public void setStoreAddress1(final String storeAddress1) {
		this.storeAddress1 = storeAddress1;
	}

	/**
	 * Sets the store address2.
	 *
	 * @param storeAddress2 the new store address2
	 */
	public void setStoreAddress2(final String storeAddress2) {
		this.storeAddress2 = storeAddress2;
	}

	/**
	 * Sets the store fax number.
	 *
	 * @param storeFaxNumber the new store fax number
	 */
	public void setStoreFaxNumber(final String storeFaxNumber) {
		this.storeFaxNumber = storeFaxNumber;
	}

	/**
	 * Sets the store name.
	 *
	 * @param storeName the new store name
	 */
	public void setStoreName(final String storeName) {
		this.storeName = storeName;
	}

	/**
	 * Sets the store number.
	 *
	 * @param storeNumber the new store number
	 */
	public void setStoreNumber(final Integer storeNumber) {
		this.storeNumber = storeNumber;
	}

    /**
	 * Sets the store phone number.
	 *
	 * @param storePhoneNumber the new store phone number
	 */
	public void setStorePhoneNumber(final String storePhoneNumber) {
		this.storePhoneNumber = storePhoneNumber;
	}

    /**
	 * Sets the store postal number.
	 *
	 * @param storePostalNumber the new store postal number
	 */
	public void setStorePostalNumber(final Integer storePostalNumber) {
		this.storePostalNumber = storePostalNumber;
	}

    /**
     * The setter for the kiosk host.
     * @param kioskHost the kiosk host for this store.
     */
    public void setKioskHost(final String kioskHost) {
        this.kioskHost = kioskHost;
    }

    /**
     * The getter for the kiosk host.
     * @return the kiosk host ip address.
     */
    public String getKioskHost() {
        return kioskHost;
    }

    /**
     * {@inheritDoc}
     */
    public Integer getKey() {
        return storeNumber;
    }
}
