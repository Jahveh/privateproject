/*
 * StoreHour.java
 */
package com.menards.rental.domain;

import com.menards.rental.utils.Constants;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * This class represents the store hours of any given store for all 7 days.
 *
 * @author deep
 */
public class StoreHour implements Serializable, Cachable {

    /**
     * The store number.
     */
    private Integer storeNumber;

    /**
     * The monday open.
     */
    private Time mondayOpen;

    /**
     * The monday close.
     */
    private Time mondayClose;

    /**
     * The tuesday open.
     */
    private Time tuesdayOpen;

    /**
     * The tuesday close.
     */
    private Time tuesdayClose;

    /**
     * The wednesday open.
     */
    private Time wednesdayOpen;

    /**
     * The wednesday close.
     */
    private Time wednesdayClose;

    /**
     * The thursday open.
     */
    private Time thursdayOpen;

    /**
     * The thursday close.
     */
    private Time thursdayClose;

    /**
     * The friday open.
     */
    private Time fridayOpen;

    /**
     * The friday close.
     */
    private Time fridayClose;

    /**
     * The saturday open.
     */
    private Time saturdayOpen;

    /**
     * The saturday close.
     */
    private Time saturdayClose;

    /**
     * The sunday open.
     */
    private Time sundayOpen;

    /**
     * The sunday close.
     */
    private Time sundayClose;

    /**
     * Gets the friday close.
     *
     * @return the friday close
     */
    public Time getFridayClose() {
        return fridayClose;
    }

    /**
     * Gets the friday open.
     *
     * @return the friday open
     */
    public Time getFridayOpen() {
        return fridayOpen;
    }

    /**
     * Gets the monday close.
     *
     * @return the monday close
     */
    public Time getMondayClose() {
        return mondayClose;
    }

    /**
     * Gets the monday open.
     *
     * @return the monday open
     */
    public Time getMondayOpen() {
        return mondayOpen;
    }

    /**
     * Gets the number of checkin hours.
     *
     * @param inDate the in date
     * @return the number of checkin hours
     */
    public double getNumberOfCheckinHours(final Calendar inDate) {
        final Calendar correctCheckinDate = getCheckinDateBaseOnStoreCloseHours(inDate);
        return getOpenFor(correctCheckinDate).calculateDifferenceInHours(correctCheckinDate);
    }

    /**
     * Gets the number of checkout hours.
     *
     * @param outDate the out date
     * @return the number of checkout hours
     */
    public double getNumberOfCheckoutHours(final Calendar outDate) {
        final Calendar correctCheckoutDate = getCheckoutDateBaseOnStoreOpenHours(outDate);
        return getCloseFor(correctCheckoutDate).calculateDifferenceInHours(correctCheckoutDate);
    }

    /**
     * returns the open hours for the day. Pass the static int define in
     * calendar class e.g. Calendar.MONDAY
     *
     * @param dayofWeek the dayof week
     * @return the open hours
     */
    public double getOpenHours(final int dayofWeek) {
        double openHours = 0.0;

        switch (dayofWeek) {
            case Calendar.MONDAY:
                openHours = mondayClose.getTimeInHoursFor24HourClock() - mondayOpen.getTimeInHoursFor24HourClock();
                break;
            case Calendar.TUESDAY:
                openHours = tuesdayClose.getTimeInHoursFor24HourClock() - tuesdayOpen.getTimeInHoursFor24HourClock();
                break;
            case Calendar.WEDNESDAY:
                openHours =
                        wednesdayClose.getTimeInHoursFor24HourClock() - wednesdayOpen.getTimeInHoursFor24HourClock();
                break;
            case Calendar.THURSDAY:
                openHours = thursdayClose.getTimeInHoursFor24HourClock() - thursdayOpen.getTimeInHoursFor24HourClock();
                break;
            case Calendar.FRIDAY:
                openHours = fridayClose.getTimeInHoursFor24HourClock() - fridayOpen.getTimeInHoursFor24HourClock();
                break;
            case Calendar.SATURDAY:
                openHours = saturdayClose.getTimeInHoursFor24HourClock() - saturdayOpen.getTimeInHoursFor24HourClock();
                break;
            case Calendar.SUNDAY:
                openHours = sundayClose.getTimeInHoursFor24HourClock() - sundayOpen.getTimeInHoursFor24HourClock();
                break;
        }

        return openHours;
    }

    /**
     * Gets the saturday close.
     *
     * @return the saturday close
     */
    public Time getSaturdayClose() {
        return saturdayClose;
    }

    /**
     * Gets the saturday open.
     *
     * @return the saturday open
     */
    public Time getSaturdayOpen() {
        return saturdayOpen;
    }

    /**
     * Gets the store number.
     *
     * @return the store number
     */
    public Integer getStoreNumber() {
        return storeNumber;
    }

    /**
     * Gets the sunday close.
     *
     * @return the sunday close
     */
    public Time getSundayClose() {
        return sundayClose;
    }

    /**
     * Gets the sunday open.
     *
     * @return the sunday open
     */
    public Time getSundayOpen() {
        return sundayOpen;
    }

    /**
     * Gets the thursday close.
     *
     * @return the thursday close
     */
    public Time getThursdayClose() {
        return thursdayClose;
    }

    /**
     * Gets the thursday open.
     *
     * @return the thursday open
     */
    public Time getThursdayOpen() {
        return thursdayOpen;
    }

    /**
     * Returns the total duration in hours for the given date range based on the store timings.
     * @param dateRange the date range for which we have to find total hours.
     * @return the double value representing total duration in hours.
     */
    public double getTotalDurationInHours(final DateRange dateRange) {
        return new DateRange(getCheckoutDateBaseOnStoreOpenHours(dateRange.getLower()),
                getCheckinDateBaseOnStoreCloseHours(dateRange.getUpper())).getTotalDurationInHours();
    }

    /**
     * Gets the total open hours for the week.
     *
     * @return the total open hours for the week
     */
    public double getTotalOpenHoursForTheWeek() {
        final double hours = getOpenHours(Calendar.MONDAY) + getOpenHours(Calendar.TUESDAY)
                + getOpenHours(Calendar.WEDNESDAY) + getOpenHours(Calendar.THURSDAY) + getOpenHours(Calendar.FRIDAY)
                + getOpenHours(Calendar.SATURDAY) + getOpenHours(Calendar.SUNDAY);

        return hours;
    }

    /**
     * Gets the total store open hours.
     *
     * @param startDate the start date
     * @param endDate   the end date
     * @return the total store open hours
     */
    public double getTotalStoreOpenHours(final Calendar startDate, final Calendar endDate) {

        if (endDate.before(startDate)) {
            throw new IllegalArgumentException("End date cannot be before start date");
        }

        double totalStoreHours = 0.0;

        // Let's first fast forward the startDate to the start date of next date
        // and
        // end Date to the end Date for previous date. This will yield us the
        // full days
        // than we can add the first day and last day store open hours to it.
        Calendar offsetStartDate = (Calendar) startDate.clone();
        offsetStartDate.add(Calendar.DATE, 1);
        offsetStartDate = this.getCalendarForOpenHour(offsetStartDate);

        Calendar offsetEndDate = (Calendar) endDate.clone();
        offsetEndDate.add(Calendar.DATE, -1);
        offsetEndDate = this.getCalendarForCloseHour(offsetEndDate);

        if (offsetEndDate.after(offsetStartDate)) {
            // Let's find out the total number of whole weeks and the store
            // hours for those weeks
            final long differenceInMillSecs = offsetEndDate.getTimeInMillis() - offsetStartDate.getTimeInMillis();
            final int numberOfDays = (int) Math.ceil((differenceInMillSecs)
                    / (Constants.Calculation.MILLI_SECONDS_IN_A_HOUR * Constants.Calculation.TWENTY_FOUR_HOURS));
            final int numberofWeeks = numberOfDays / 7;
            final int numberofDaysLeft = numberOfDays % 7;
            totalStoreHours += this.getTotalOpenHoursForTheWeek() * numberofWeeks;

            int endDayOfTheWeekForEndDate = endDate.get(Calendar.DAY_OF_WEEK);

            for (int counter = 0; counter < numberofDaysLeft; counter++) {
            	// Decrement the day as we want to add all the remaining days
            	endDayOfTheWeekForEndDate--;
            	
            	// Reset the week if we reach to the first day
            	if (endDayOfTheWeekForEndDate < Calendar.SUNDAY) {
            		endDayOfTheWeekForEndDate = Calendar.SATURDAY;
            	}
            	
                totalStoreHours += this.getOpenHours(endDayOfTheWeekForEndDate);
            }
        }

        // Add the hours for the first day
        double hoursToIncludeForFirstDay = 0.0;
        final Calendar storeStartTimeForStartDate = this.getCalendarForOpenHour(startDate);
        final Calendar storeEndTimeForStartDate = this.getCalendarForCloseHour(startDate);

        if (!startDate.after(storeStartTimeForStartDate)) {
            hoursToIncludeForFirstDay = this.getOpenHours(startDate.get(Calendar.DAY_OF_WEEK));
        } else if (startDate.after(storeStartTimeForStartDate) && startDate.before(storeEndTimeForStartDate)) {
            hoursToIncludeForFirstDay = this.getCloseFor(startDate).calculateDifferenceInHours(startDate);
        }
        
        // Add the hours for Last Day
        double hoursToIncludeForLastDay = 0.0;
        final Calendar storeStartTimeForEndDate = this.getCalendarForOpenHour(endDate);
        final Calendar storeEndTimeForEndDate = this.getCalendarForCloseHour(endDate);
        if (endDate.after(storeStartTimeForEndDate) && endDate.before(storeEndTimeForEndDate)) {
            hoursToIncludeForLastDay = this.getOpenFor(endDate).calculateDifferenceInHours(endDate);
        } else if (!endDate.before(storeEndTimeForEndDate)) {
            hoursToIncludeForLastDay = this.getOpenHours(endDate.get(Calendar.DAY_OF_WEEK));
        }
        totalStoreHours = totalStoreHours + hoursToIncludeForFirstDay + hoursToIncludeForLastDay;
        return totalStoreHours;
    }

    /**
     * Gets the tuesday close.
     *
     * @return the tuesday close
     */
    public Time getTuesdayClose() {
        return tuesdayClose;
    }

    /**
     * Gets the tuesday open.
     *
     * @return the tuesday open
     */
    public Time getTuesdayOpen() {
        return tuesdayOpen;
    }

    /**
     * Gets the wednesday close.
     *
     * @return the wednesday close
     */
    public Time getWednesdayClose() {
        return wednesdayClose;
    }

    /**
     * Gets the wednesday open.
     *
     * @return the wednesday open
     */
    public Time getWednesdayOpen() {
        return wednesdayOpen;
    }

    /**
     * Checks if is date range within store hours.
     *
     * @param dateRange the date range
     * @return true, if is date range within store hours
     */
    public boolean isDateRangeWithinStoreHours(final DateRange dateRange) {
        return dateRange.isOnSameDay();
    }

    /**
     * Sets the close.
     *
     * @param close the new close
     */
    public void setClose(final Time close) {
        setMondayClose(close);
        setTuesdayClose(close);
        setWednesdayClose(close);
        setThursdayClose(close);
        setFridayClose(close);
        setSaturdayClose(close);
        setSundayClose(close);
    }

    /**
     * Sets the friday close.
     *
     * @param fridayClose the new friday close
     */
    public void setFridayClose(final Time fridayClose) {
        this.fridayClose = fridayClose;
    }

    /**
     * Sets the friday open.
     *
     * @param fridayOpen the new friday open
     */
    public void setFridayOpen(final Time fridayOpen) {
        this.fridayOpen = fridayOpen;
    }

    /**
     * Sets the monday close.
     *
     * @param mondayClose the new monday close
     */
    public void setMondayClose(final Time mondayClose) {
        this.mondayClose = mondayClose;
    }

    /**
     * Sets the monday open.
     *
     * @param mondayOpen the new monday open
     */
    public void setMondayOpen(final Time mondayOpen) {
        this.mondayOpen = mondayOpen;
    }

    /**
     * Sets the open.
     *
     * @param open the new open
     */
    public void setOpen(final Time open) {
        setMondayOpen(open);
        setTuesdayOpen(open);
        setWednesdayOpen(open);
        setThursdayOpen(open);
        setFridayOpen(open);
        setSaturdayOpen(open);
        setSundayOpen(open);
    }

    /**
     * Sets the saturday close.
     *
     * @param saturdayClose the new saturday close
     */
    public void setSaturdayClose(final Time saturdayClose) {
        this.saturdayClose = saturdayClose;
    }

    /**
     * Sets the saturday open.
     *
     * @param saturdayOpen the new saturday open
     */
    public void setSaturdayOpen(final Time saturdayOpen) {
        this.saturdayOpen = saturdayOpen;
    }

    /**
     * Sets the store number.
     *
     * @param storeNumber the new store number
     */
    public void setStoreNumber(final Integer storeNumber) {
        this.storeNumber = storeNumber;
    }

    /**
     * Sets the sunday close.
     *
     * @param sundayClose the new sunday close
     */
    public void setSundayClose(final Time sundayClose) {
        this.sundayClose = sundayClose;
    }

    /**
     * Sets the sunday open.
     *
     * @param sundayOpen the new sunday open
     */
    public void setSundayOpen(final Time sundayOpen) {
        this.sundayOpen = sundayOpen;
    }

    /**
     * Sets the thursday close.
     *
     * @param thursdayClose the new thursday close
     */
    public void setThursdayClose(final Time thursdayClose) {
        this.thursdayClose = thursdayClose;
    }

    /**
     * Sets the thursday open.
     *
     * @param thursdayOpen the new thursday open
     */
    public void setThursdayOpen(final Time thursdayOpen) {
        this.thursdayOpen = thursdayOpen;
    }

    /**
     * Sets the tuesday close.
     *
     * @param tuesdayClose the new tuesday close
     */
    public void setTuesdayClose(final Time tuesdayClose) {
        this.tuesdayClose = tuesdayClose;
    }

    /**
     * Sets the tuesday open.
     *
     * @param tuesdayOpen the new tuesday open
     */
    public void setTuesdayOpen(final Time tuesdayOpen) {
        this.tuesdayOpen = tuesdayOpen;
    }

    /**
     * Sets the wednesday close.
     *
     * @param wednesdayClose the new wednesday close
     */
    public void setWednesdayClose(final Time wednesdayClose) {
        this.wednesdayClose = wednesdayClose;
    }

    /**
     * Sets the wednesday open.
     *
     * @param wednesdayOpen the new wednesday open
     */
    public void setWednesdayOpen(final Time wednesdayOpen) {
        this.wednesdayOpen = wednesdayOpen;
    }

    /**
     * Will return the Calendar object for the close hour.
     *
     * @param calendar - the date on which we want to get the timestamp of close hour
     * @return the calendar for close hour
     */
    private Calendar getCalendarForCloseHour(final Calendar calendar) {
        final Calendar endTimeStamp = Calendar.getInstance();
        endTimeStamp.setTimeInMillis(calendar.getTimeInMillis());

        final Time time = this.getCloseFor(calendar);
        endTimeStamp.set(Calendar.HOUR_OF_DAY, time.getHour());
        endTimeStamp.set(Calendar.MINUTE, time.getMinutes());
        endTimeStamp.set(Calendar.SECOND, 0);
        return endTimeStamp;
    }

    /**
     * Will return the Calendar object for the open hour.
     *
     * @param calendar - the date on which we want to get the timestamp of open hour
     * @return the calendar for open hour
     */
    private Calendar getCalendarForOpenHour(final Calendar calendar) {
        final Calendar startTimeStamp = Calendar.getInstance();
        startTimeStamp.setTimeInMillis(calendar.getTimeInMillis());

        final Time time = this.getOpenFor(calendar);
        startTimeStamp.set(Calendar.HOUR_OF_DAY, time.getHour());
        startTimeStamp.set(Calendar.MINUTE, time.getMinutes());
        startTimeStamp.set(Calendar.SECOND, 0);
        return startTimeStamp;
    }

    /**
     * Returns the checkin date based on the store close hours.  This is necessary because team member can choose
     * a checkin time that is outside the store.  Hence we should only consider the time till the store is open.
     * @param upper the checkin time for which we have to find the correct checkin time based on store hours.
     * @return Calendar instance representing the correct checkin time.
     */
    private Calendar getCheckinDateBaseOnStoreCloseHours(final Calendar upper) {
        final Calendar storeOpenHourTime = getCalendarForOpenHour(upper);
        if (storeOpenHourTime.after(upper)) {
            return storeOpenHourTime;
        }

        final Calendar storeCloseHourTime = getCalendarForCloseHour(upper);

        if (storeCloseHourTime.after(upper)) {
            return upper;
        }
        return storeCloseHourTime;
    }

    /**
     * Returns the checkout date based on the store open hours.  This is necessary because team member can choose
     * a checkout time that is outside the store.  Hence we should only consider the time till the store is open.
     * @param lower the checkout time for which we have to find the correct checkout time based on store hours.
     * @return Calendar instance representing the correct checkout time.
     */
    private Calendar getCheckoutDateBaseOnStoreOpenHours(final Calendar lower) {
        final Calendar storeCloseHourTime = getCalendarForCloseHour(lower);
        if (storeCloseHourTime.before(lower)) {
            return storeCloseHourTime;
        }

        final Calendar storeOpenHourTime = getCalendarForOpenHour(lower);
        if (storeOpenHourTime.before(lower)) {
            return lower;
        }
        return storeOpenHourTime;
    }

    /**
     * Gets the close for.
     *
     * @param calendar the calendar
     * @return the close for
     */
    private Time getCloseFor(final Calendar calendar) {
        return getTimeFor(calendar, getCloseHours());
    }

    /**
     * Gets the close hours.
     *
     * @return the close hours
     */
    private List<Time> getCloseHours() {
        final List<Time> allCloseHours = new ArrayList<Time>();
        allCloseHours.add(getSundayClose());
        allCloseHours.add(getMondayClose());
        allCloseHours.add(getTuesdayClose());
        allCloseHours.add(getWednesdayClose());
        allCloseHours.add(getThursdayClose());
        allCloseHours.add(getFridayClose());
        allCloseHours.add(getSaturdayClose());
        return allCloseHours;
    }

    /**
     * Gets the open for.
     *
     * @param calendar the calendar
     * @return the open for
     */
    private Time getOpenFor(final Calendar calendar) {
        return getTimeFor(calendar, getOpenHours());
    }

    /**
     * Gets the open hours.
     *
     * @return the open hours
     */
    private List<Time> getOpenHours() {
        final List<Time> allOpenHours = new ArrayList<Time>();
        allOpenHours.add(getSundayOpen());
        allOpenHours.add(getMondayOpen());
        allOpenHours.add(getTuesdayOpen());
        allOpenHours.add(getWednesdayOpen());
        allOpenHours.add(getThursdayOpen());
        allOpenHours.add(getFridayOpen());
        allOpenHours.add(getSaturdayOpen());
        return allOpenHours;
    }

    /**
     * Gets the time for.
     *
     * @param calendar   the calendar
     * @param storeHours the store hours
     * @return the time for
     */
    private Time getTimeFor(final Calendar calendar, final List<Time> storeHours) {
        return storeHours.get(calendar.get(Calendar.DAY_OF_WEEK) - 1);
    }

    /**
     * {@inheritDoc}
     */
    public Integer getKey() {
        return storeNumber;
    }
}
