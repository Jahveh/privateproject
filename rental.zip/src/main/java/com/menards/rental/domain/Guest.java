/*
 * Guest.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

import com.menards.rental.converters.DateToStringConverter;
import com.menards.rental.utils.Constants;

/**
 * The guest class.
 * @author deep
 */
@Entity
@RooJavaBean
@Table(name = "guest")
@RooEntity(identifierColumn = "guest_id", finders = { "findGuestsByPhoneNumber", "findGuestsByPhoneNumberEquals" })
public class Guest implements Serializable {

	/** The Constant logger. */
	protected static final Log logger = LogFactory.getLog(Guest.class.toString());

	
	/** The first name. */
	@Size(max = 30)
	@Column(name = "guest_first_name")
	private String firstName;

	/** The last name. */
	@Size(max = 30)
	@Column(name = "guest_last_name")
	private String lastName;

	/** The company name. */
	@Size(max = 50)
	@Column(name = "guest_company_name")
	private String companyName;

	/** The address. */
	@Embedded
	@AttributeOverrides(value = {
	        @AttributeOverride(name = "line", column = @Column(name = "guest_address")),
	        @AttributeOverride(name = "city", column = @Column(name = "guest_city")),
	        @AttributeOverride(name = "state", column = @Column(name = "guest_state_cd", columnDefinition = "char(2)")),
	        @AttributeOverride(name = "zipCode", column = @Column(name = "guest_postal_cd", columnDefinition = "char(10)")) })
	private Address address = new Address();

	/** The phone number. */
	@Column(name = "guest_phone_nbr")
	private String phoneNumber;

	/** The email. */
	@Column(name = "guest_email_address")
	private String email;

	/** The date of birth. */
	@Temporal(value = TemporalType.DATE)
	@DateTimeFormat(style = "S-")
	@Column(name = "guest_birth_dt")
	private Date dateOfBirth;

	/** The identification. */
	@Embedded
	@AttributeOverrides(value = {
	        @AttributeOverride(name = "number",
	        		column = @Column(name = "guest_identification_val", columnDefinition = "char(20)")),
	        @AttributeOverride(name = "expiryDate", column = @Column(name = "guest_license_exp_dt")),
	        @AttributeOverride(name = "state", 
	        		column = @Column(name = "guest_license_state_cd", columnDefinition = "char(2)")),
            @AttributeOverride(name = "type", column = @Column(name = "guest_identification_type",
                    columnDefinition = "char(1)")) })
	private Identification identification = new Identification();

	@Column(name = "gim_guest_account_id")
	private Long gimGuestAccountId;

	@Column(name = "gim_address_id")
	private Long gimAddressId;
	
	/**
	 * Instantiates a new guest.
	 */
	public Guest() {
	}

	/**
	 * Instantiates a new guest.
	 *
	 * @param phoneNumber the phone number
	 */
	public Guest(final String phoneNumber) {
		setPhoneNumber(phoneNumber);
	}

	/**
	 * Instantiates a new guest.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 */
	public Guest(final String firstName, final String lastName) {
		this(firstName, lastName, null);
	}

	/**
	 * Instantiates a new guest.
	 *
	 * @param fn the fn
	 * @param ln the ln
	 * @param company the company
	 */
	public Guest(final String fn, final String ln, final String company) {
		setFirstName(fn);
		setLastName(ln);
		setCompanyName(company);
	}

	/**
	 * Find all guests by phone number.
	 *
	 * @param phoneNumber the phone number
	 * @return the list
	 */
	public static List<Guest> findAllGuestsByPhoneNumber(final String phoneNumber) {
		return findGuestsByPhoneNumber(phoneNumber).getResultList();
	}

	/**
	 * Copy from.
	 *
	 * @param guest the guest
	 */
	public void copyFrom(final Guest guest) {
		setFirstName(guest.getFirstName());
		setLastName(guest.getLastName());
		setCompanyName(guest.getCompanyName());
		setEmail(guest.getEmail());
		setPhoneNumber(guest.getPhoneNumber());
		setDateOfBirth(guest.getDateOfBirth());
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * Gets the company name.
	 *
	 * @return the company name
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * Gets the company name.
	 *
	 * @return the company name
	 */
	public String getCompanyNameEscaped() {
		return StringEscapeUtils.escapeHtml(companyName);
	}

	/**
	 * Gets the date of birth.
	 *
	 * @return the date of birth
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * Gets the date of birth str.
	 *
	 * @return the date of birth str
	 */
	public String getDateOfBirthStr() {
		try {
			return new DateToStringConverter().toString(getDateOfBirth());
		} catch (final Exception e) {
			logger.error(e.getMessage(), e);
			return "";
		}
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Gets the full name.
	 *
	 * @return the full name
	 */
	public String getFullName() {
		return String.format("%1$s, %2$s", getLastName(), getFirstName());
	}

	/**
	 * Gets the full name.
	 *
	 * @return the full name
	 */
	public String getFullNameEscaped() {
		return StringEscapeUtils.escapeHtml(String.format("%1$s, %2$s", getLastName(), getFirstName()));
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Gets the identification.
	 *
	 * @return the identification
	 */
	public Identification getIdentification() {
        if (null == identification) {
            identification = new Identification();
        }
        return identification;
	}

    /**
	 * Gets the phone number.
	 *
	 * @return the phone number
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Checks if is driver age greater than minimum rental age.
	 *
	 * @param minimumRentalAge the minimum rental age
	 * @return true, if is driver age greater than minimum rental age
	 */
	public boolean isDriverAgeGreaterThanMinimumRentalAge(final int minimumRentalAge) {
		return (getAge() >= minimumRentalAge);
	}

	/**
     * Returns true if email is provided.
     * @return true if email is provided
     */
    public boolean isEmailProvided() {
        return (null != email && !"".equals(email));
    }

	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(final Address address) {
		this.address = address;
	}

	/**
	 * Sets the company name.
	 *
	 * @param companyName the new company name
	 */
	public void setCompanyName(final String companyName) {
		this.companyName = companyName;
	}

	/**
	 * Sets the date of birth.
	 *
	 * @param dateOfBirth the new date of birth
	 */
	public void setDateOfBirth(final Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * Sets the date of birth str.
	 *
	 * @param dateOfBirth the new date of birth str
	 */
	public void setDateOfBirthStr(final String dateOfBirth) {
		try {
			setDateOfBirth((Date) new DateToStringConverter().toObject(dateOfBirth, Date.class));
		} catch (final Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(final String email) {
		this.email = email;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}

	/**
     * Setter for the full name.  Splits the name and sets in last name and then in first name.
     * @param fullName the full name of the guest.
     */
    public void setFullName(final String fullName) {
        final String[] nameParts = fullName.split(",");
        setLastName(nameParts[0]);
        if (nameParts.length >= 2) {
            setFirstName(nameParts[1].trim());
        }
    }

	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(final String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Sets the identification.
	 *
	 * @param identification the new identification
	 */
	public void setIdentification(final Identification identification) {
		this.identification = identification;
	}

    /**
	 * Sets the phone number.
	 *
	 * @param phoneNumber the new phone number
	 */
	public void setPhoneNumber(final String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

    /**
     * Returns true if the guest has not provided any identification.
     * @return true if guest has not provided some identification.
     */
    public boolean isNoIdentificationProvided() {
        return ((null == identification.getNumber())
                || (Constants.Action.EMPTY_STRING.equals(identification.getNumber())));
    }

    /**
     * Returns true if un-masked identification value is available.
     * @return true if un-masked identification value is available.
     */
    public boolean isUnMaskedIdentificationAvailable() {
        return (null != identification.getUnMaskedNumber());
    }

    /**
     * Setter for the unmasked identification number.
     * @param unMaskedIdentificationNumber the value to set.
     */
    public void setUnMaskedIdentificationNumber(final String unMaskedIdentificationNumber) {
        identification.setUnMaskedNumber(unMaskedIdentificationNumber);
    }

    /**
     * The setter for the masked identification number.
     * @param maskedIdentificationNumber the value to set.
     */
    public void setMaskedIdentificationNumber(final String maskedIdentificationNumber) {
        identification.setNumber(maskedIdentificationNumber);
    }

    /**
     * Getter for the masked identification number.
     * @return the String value representing the masked identification number.
     */
    public String getMaskedIdentificationNumber() {
        return identification.getNumber();
    }

    /**
     * Copies the transient information from the other guest.
     * @param other the guest from which we need to copy the transient information.
     */
    public void copyTransientInformationFrom(final Guest other) {
        setUnMaskedIdentificationNumber(other.getUnMaskedIdentificationNumber());
    }

    /**
     * The getter for the un-masked identification number.
     * @return the string value representing the value of un-masked identification number.
     */
    public String getUnMaskedIdentificationNumber() {
        return identification.getUnMaskedNumber();
    }

    /**
	 * Gets the age.
	 *
	 * @return the age
	 */
	private int getAge() {
		final long ageInMilliseconds = new Date().getTime() - dateOfBirth.getTime();
		return (int) (ageInMilliseconds / Constants.Calculation.MILLI_SECONDS_IN_A_YEAR);
	}

    /**
     * The method that returns true if the guest address has a valid zip code.
     * @return true if guest address holds valid zipcode, false otherwise.
     */
    public boolean hasValidZipCode() {
        return address.hasValidZipCode();
    }

    /**
	 * Gets the gim guest account id.
	 *
	 * @return Long
	 */
	public Long getGimGuestAccountId() {
		return gimGuestAccountId;
	}

    /**
	 * Sets the gim guest account id.
	 *
	 * @param Long gimGuestAccountId
	 */
	public void setGimGuestAccountId(Long gimGuestAccountId) {
		this.gimGuestAccountId = gimGuestAccountId;
	}

    /**
	 * Gets the gim address id.
	 *
	 * @return Long
	 */
	public Long getGimAddressId() {
		return gimAddressId;
	}

    /**
	 * Sets the gim address id.
	 *
	 * @param Long gimAddressId
	 */
	public void setGimAddressId(Long gimAddressId) {
		this.gimAddressId = gimAddressId;
	}
    
    
}
