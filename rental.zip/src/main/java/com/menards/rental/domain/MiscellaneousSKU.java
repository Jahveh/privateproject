/*
 * MiscellaneousSKU.java
 */
package com.menards.rental.domain;

import org.apache.log4j.Logger;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Query;
import javax.persistence.Table;
import java.util.List;

/**
 * The domain class that represent miscellaneous sku's in the system.
 * This includes the sku's for damage waiver for now.
 *
 * @author Deep Shah
 */
@Entity
@RooJavaBean
@Table(name = "misc_sku")
@RooEntity(identifierColumn = "misc_id", finders = {"findMiscellaneousSKUsByType"})
public class MiscellaneousSKU {

    /** The log4j logger. */
    private static final Logger logger = Logger.getLogger(MiscellaneousSKU.class);

    /** The value. */
	@Column(name = "sku", unique = true, nullable = false,
            updatable = false, columnDefinition = "int(11)")
	private Long value;

    /** The type. */
	@Column(name = "type_name", columnDefinition = "varchar(20)")
	private String type;

    /**
     * The finder that will return the damage waiver sku.
     * @return the MiscellaneousSKU reference for the damage waiver type of sku.
     */
    public static MiscellaneousSKU findDamageWaiverSKU() {
        final Query query = findMiscellaneousSKUsByType(Type.DAMAGE_WAIVER.toString());
        final List<MiscellaneousSKU> damageWaiverSKUs = query.getResultList();
        if(damageWaiverSKUs.isEmpty()) {
            logger.error("The damage waiver sku is not setup!" + " This means we will not be sending the damage waiver amounts to kiosk");
//            logger.error("This means we will not be sending the damage waiver amounts to kiosk");
            return null;
        }
        return damageWaiverSKUs.get(0);
    }

    /** The enum that represents various type of miscellaneous sku's. */
    public enum Type {
        DAMAGE_WAIVER;
    }
}
