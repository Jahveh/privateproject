/*
 * ZeroIncrementalHoursCalculationRule.java
 */
package com.menards.rental.domain.rule;

import com.menards.rental.domain.StoreHourBasedRentalDateRange;

/**
 * The calculation rule that returns zero as incremental hours.
 * @author deep
 */
public class ZeroIncrementalHoursCalculationRule implements IncrementalHoursCalculationRule {

	/**
	 * Instantiates a new zero incremental hours calculation rule.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @param rentalDateRange the rental date range
	 */
	public ZeroIncrementalHoursCalculationRule(final double baseSkuHrQty,
	        final StoreHourBasedRentalDateRange rentalDateRange) {
	}

    /**
     * {@inheritDoc}
     */
	public double calculate() {
		return 0;
	}
}
