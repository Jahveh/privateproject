/*
 * ElecRentalCd.java
 */
package com.menards.rental.domain;

/**
 * The Enum ElecRentalCd.
 */
public enum ElecRentalCd {

	/** The Not rental. */
	NotRental(0, "NOT_RENTAL"),
	/** The Base. */
	Base(1, "BASE"),
	/** The Incremental. */
	Incremental(2, "ADDITIONAL"),
	/** The Selling. */
	Selling(3, "SELLING"),
	/** The Surcharge. */
	Surcharge(4, "SURCHARGE"),
	/** Unkown/Null. */
	Unknown(5, "UNKNOWN");
	

	/** The code. */
	private final int code;

	/** The description. */
	private final String description;

	/**
	 * Instantiates a new elec rental cd.
	 *
	 * @param code the code
	 * @param description the description
	 */
	ElecRentalCd(final int code, final String description) {
		this.code = code;
		this.description = description;
	}

	/**
	 * Gets the elec rental cd.
	 *
	 * @param code the code
	 * @return the elec rental cd
	 */
	public static ElecRentalCd getElecRentalCd(final int code) {
		switch (code) {
		case 0:
			return ElecRentalCd.NotRental;
		case 1:
			return ElecRentalCd.Base;
		case 2:
			return ElecRentalCd.Incremental;
		case 3:
			return ElecRentalCd.Selling;
		case 4:
			return ElecRentalCd.Surcharge;
		default:
			return ElecRentalCd.Unknown;
		}
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

}
