package com.menards.rental.domain;

/**
 * The interface that represents that an entity is cachable.
 *
 * @author deep
 */
public interface Cachable {

    /**
     * The method that should be implemented by all implementing classes.  This method returns the cache key for the
     * object to be cached.
     * @return the Integer value representing the cache key.
     */
    Integer getKey();
}
