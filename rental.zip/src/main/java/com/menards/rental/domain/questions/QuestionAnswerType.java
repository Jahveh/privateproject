package com.menards.rental.domain.questions;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the question_answer_type database table.
 * 
 */
@Entity
@Table(name="question_answer_type")
@NamedQuery(name="QuestionAnswerType.findAll", query="SELECT q FROM QuestionAnswerType q")
public class QuestionAnswerType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="answer_type_id")
	private int answerTypeId;

	@Column(name="answer_type")
	private String answerType;

	//bi-directional many-to-one association to Question
	@OneToMany(mappedBy="questionAnswerType")
	private List<Quiz> questions;

	public QuestionAnswerType() {
	}

	public int getAnswerTypeId() {
		return this.answerTypeId;
	}

	public void setAnswerTypeId(int answerTypeId) {
		this.answerTypeId = answerTypeId;
	}

	public String getAnswerType() {
		return this.answerType;
	}

	public void setAnswerType(String answerType) {
		this.answerType = answerType;
	}

	public List<Quiz> getQuestions() {
		return this.questions;
	}

	public void setQuestions(List<Quiz> questions) {
		this.questions = questions;
	}

	public Quiz addQuestion(Quiz question) {
		getQuestions().add(question);
		question.setQuestionAnswerType(this);

		return question;
	}

	public Quiz removeQuestion(Quiz question) {
		getQuestions().remove(question);
		question.setQuestionAnswerType(null);

		return question;
	}

}