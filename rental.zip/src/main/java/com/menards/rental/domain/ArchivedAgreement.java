/**
 * ArchivedAgreement.java
 */
package com.menards.rental.domain;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.hibernate.Session;
import org.hibernate.annotations.Cascade;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.entity.RooEntity;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * The domain class for Archived agreements.
 * @author deep
 */
@Entity
@RooJavaBean
@RooEntity(identifierColumn = "archived_rental_agreement_id", finders = "findArchivedAgreementsByAgreementNumber")
@Table(name = "archived_rental_agreement")
public class ArchivedAgreement {

    /** The agreement. */
    @ManyToOne(targetEntity = Agreement.class, fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "agreement_id")
    private Agreement agreement;

    /**
     * The guest.
     */
    @OneToOne(targetEntity = Guest.class, optional = true)
    @JoinColumn(name = "guest_id", nullable = true)
    private Guest guest;

    /**
     * The store.
     */
    @Embedded
    private Store store;

    /**
     * The agreement number.
     */
    @NotNull
    @Column(name = "rental_agreement_nbr", nullable = false, unique = true)
    private String agreementNumber;

    /**
     * The rental date.
     */
    @NotNull
    @Column(name = "tran_dt", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "SS")
    private Calendar rentalDate;

    /** The sub total value of the agreement. */
    @Column(name = "sub_total_amt")
    private BigDecimal subTotal = new BigDecimal("0.0");

    /**
     * The items.
     */
    @OneToMany(targetEntity = ArchivedAgreementItem.class, fetch = FetchType.LAZY,
            mappedBy = "agreement", cascade = CascadeType.ALL)
    @Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
    private Set<ArchivedAgreementItem> items = new HashSet<ArchivedAgreementItem>();

    /**
     * Returns the ArchivedAgreemeent matching the given agreement number.
     * @param agreementNumber the areement number that we need to find.
     * @return the ArchivedAgreement matching the given number.  Null if  none exists.
     */
    public static ArchivedAgreement findArchivedAgreementByAgreementNumber(final String agreementNumber) {
        final Query query = findArchivedAgreementsByAgreementNumber(agreementNumber);
        final List<ArchivedAgreement> archivedAgreements = query.getResultList();
        if (!archivedAgreements.isEmpty()) {
            return archivedAgreements.get(0);
        }

        return null;
    }

    /**
     * Returns the matching agreements based on the search criteria passed.
     * @param searchArchivedAgreementsCriteria the criteria for which we are doing the search.
     * @return the List of archived agreements.
     */
    public static List<ArchivedAgreement> findArchivedAgreementsBySearchCriteria(
            final DetachedCriteria searchArchivedAgreementsCriteria) {
        return searchArchivedAgreementsCriteria.getExecutableCriteria((Session) entityManager().getDelegate()).list();
    }

    /**
     * Gets the agreement number only.
     *
     * @return the agreement number only
     */
    public String getAgreementNumberOnly() {
        final String[] agreementParts = agreementNumber.split("-");
        if (agreementParts.length < 2) {
            return agreementParts[0];
        }
        return agreementParts[1];
    }

    /**
     * The setter for the agreement.
     * @param agreement the value to set.
     */
    public void setAgreement(final Agreement agreement) {
        this.agreement = agreement;
        setAgreementNumber(agreement.getAgreementNumber());
        setGuest(agreement.getGuest());
        setStore(agreement.getStore());
        setSubTotal(agreement.getSubTotal());
    }

    /**
     * Returns the agreement version.
     * @return the version number of thea greement.
     */
    public String getAgreementVersion() {
        final String[] agreementParts = agreementNumber.split("-");
        if (agreementParts.length < 3) {
            return agreementParts[0];
        }
        return agreementParts[2];
    }

    /**
     * Returns the 8 digit agreement number removing the hyphen e.g. if agreement number is 1234-23456-001 it will
     * return 23456001
     *
     * @return the eight digit agreement number without hyphen
     */
    public Long getEightDigitAgreementNumberWithoutHyphen() {
        final String numberAsText = (agreementNumber.replaceAll("-", "")).substring(4);
        return Long.parseLong(numberAsText);
    }

    /**
     * Returns true if the agreement is the latest in the history.
     * @return true if the agreement is the latest in the history, false otherwise.
     */
    public boolean isLatest() {
        return agreementNumber.equals(agreement.getAgreementNumber());
    }

    /**
     * Returns a list of archived agreement by agreement in.
     * @param agreements the agreements for which we have to find archived agreements.
     * @return the List of archived agreements maching the criteria.
     */
    public static List<ArchivedAgreement> findAllArchivedAgreementsByAgreementsIn(
            final List<Agreement> agreements) {
        final Query query = entityManager()
                .createQuery("select a from ArchivedAgreement a where a.agreement in (:agreements)");
        query.setParameter("agreements", agreements);
        return query.getResultList();
    }
}
