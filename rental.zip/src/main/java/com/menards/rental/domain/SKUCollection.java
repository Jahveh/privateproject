/*
 * SKUs.java
 */
package com.menards.rental.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * The sku collection class.  The class that represents a collection of RentalSKU.
 * @author deep
 */
public class SKUCollection extends CollectionUtil<RentalSKU> {

	/**
	 * Instantiates a new sku collection.
	 *
	 * @param allSKUs the all sku's held by this collection.
	 */
	public SKUCollection(final List<RentalSKU> allSKUs) {
		super(allSKUs);
	}

	/**
	 * Gets the base rental sku's.
	 *
	 * @return the base rental sku's.
	 */
	public List<RentalSKU> getBaseSKUs() {
		return getFilteredSKUsByType(RentalSKU.Type.BASE);
	}

	/**
	 * Gets the incremental rental sku's.
	 *
	 * @return the incremental rental sku's.
	 */
	public List<RentalSKU> getIncrementalSKUs() {
		return getFilteredSKUsByType(RentalSKU.Type.ADDITIONAL);
	}

	/**
	 * Gets the selling rental sku's.
	 *
	 * @return the selling rental sku's.
	 */
	public List<RentalSKU> getSellingSKUs() {
		return getFilteredSKUsByType(RentalSKU.Type.SELLING);
	}

	/**
	 * Gets the surcharge rental sku's.
	 *
	 * @return the surcharge rental sku's.
	 */
	public List<RentalSKU> getSurchargeSKUs() {
		return getFilteredSKUsByType(RentalSKU.Type.SURCHARGE);
	}

	/**
	 * Gets the filtered rental sku's by type.
	 *
	 * @param type the type of sku that we need to return.
	 * @return the filtered rental sku's by type.
	 */
	private List<RentalSKU> getFilteredSKUsByType(final RentalSKU.Type type) {
		final List<RentalSKU> skus = new ArrayList<RentalSKU>();
		doInLoop(new ExpressionEvaluator<RentalSKU>() {

			public void evaluate(final RentalSKU entity) {
				if (entity.matches(type)) {
					skus.add(entity);
				}
			}
		});
		return skus;
	}
}
