/*
 * IncrementalHoursCalculationRules.java
 */
package com.menards.rental.domain.rule;

import com.menards.rental.domain.StoreHourBasedRentalDateRange;

/**
 * The class that represents the composition of all the incremental hours calculation rules.
 * @author deep
 */
public class IncrementalHoursCalculationRuleComposite implements IncrementalHoursCalculationRule {

	/** The base sku hr qty. */
	private final double baseSkuHrQty;

	/** The rental date range. */
	private final StoreHourBasedRentalDateRange rentalDateRange;

	/** The incremental sku hr qty. */
	private final double incrementalSkuHrQty;

	/**
	 * Instantiates a new incremental hours calculation rules.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @param incrementalSkuHrQty the incremental sku hr qty
	 * @param rentalDateRange the rental date range
	 */
	public IncrementalHoursCalculationRuleComposite(final double baseSkuHrQty, final double incrementalSkuHrQty,
	        final StoreHourBasedRentalDateRange rentalDateRange) {
		this.baseSkuHrQty = baseSkuHrQty;
		this.incrementalSkuHrQty = incrementalSkuHrQty;
		this.rentalDateRange = rentalDateRange;
	}

	/**
     * {@inheritDoc}
     * Calculate the incremental hours which is charged as addition.
     * Guests are charged hourly for the entire time the store is open.
	 */
	public double calculate() {
		return new DiffDaysIncreHrsCalcRule(baseSkuHrQty, incrementalSkuHrQty, rentalDateRange)
		        .calculate();
	}

}
