/*
 * DamageWaiver.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Embeddable;

import com.menards.rental.utils.Constants;

/**
 * The damage waiver class.
 * @author deep
 */
@Embeddable
public class DamageWaiver implements Serializable {

	/** The is declined. */
	private Boolean isDeclined;

	/** Damage Waiver amount. */
	private BigDecimal amount;
	
	/** Damage waiver credit amount. */
	private BigDecimal creditAmount;

	/**
	 * Instantiates a new damage waiver.
	 */
	public DamageWaiver() {
		this(false, Constants.DamageWaiver.DAMAGE_WAIVER_DEFAULT_AMOUNT);
	}

	/**
	 * Instantiates a new damage waiver.
	 *
	 * @param isDeclined the is declined
	 * @param amount the amount
	 */
	public DamageWaiver(final boolean isDeclined, final BigDecimal amount) {
		this.isDeclined = isDeclined;
		this.amount = amount;
	}

	/**
	 * Calculate the damage waiver amount.
	 *
	 * @param chargeAmount the charge amount
	 */
	public void calculate(final BigDecimal chargeAmount) {
		if (isDeclined()) {
			setAmount(Constants.DamageWaiver.DAMAGE_WAIVER_DEFAULT_AMOUNT);
			return;
		}
		setAmount(chargeAmount.multiply(Constants.DamageWaiver.DAMAGE_WAIVER_PERCENTAGE));
	}

	/**
	 * Calculate credit. The credit is the percentage reduction on the damage waiver
	 * amount if Guest returns the rented item early.  No credit is given on the base charge amount.  Hence while
     * calculating the percentage we should not include the damage waiver applied to the base charge amount.
	 *
	 * @param percentageReduction the percentage by which the amount to be reduced which
	 *                            becomes the credit amount.
     * @param basePriceAmount the base price amount value on which no credit is given.
	 */
	public void calculateCredit(final double percentageReduction, final BigDecimal basePriceAmount) {
		if (isDeclined()) {
			this.creditAmount = new BigDecimal("0.0");
            return;
	    }

        this.creditAmount = amount.subtract(
                basePriceAmount.multiply(Constants.DamageWaiver.DAMAGE_WAIVER_PERCENTAGE))
                .multiply(new BigDecimal(percentageReduction));
	}

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * Gets the credit amount.
	 *
	 * @return the credit amount
	 */
	public BigDecimal getCreditAmount() {
		return creditAmount == null ? new BigDecimal(0.0d) : creditAmount;
	}

	/**
	 * Gets the declined.
	 *
	 * @return the declined
	 */
	public Boolean getDeclined() {
		return isDeclined;
	}

	
	/**
	 * Checks if is declined.
	 *
	 * @return the boolean
	 */
	public Boolean isDeclined() {
		return isDeclined;
	}

	/**
	 * Merge.
	 *
	 * @param damageWaiver the damage waiver
	 * @param chargeAmount the charge amount
	 */
	public void merge(final DamageWaiver damageWaiver, final BigDecimal chargeAmount) {
		setDeclined(damageWaiver.isDeclined());
		if (damageWaiver.isDeclined()) {
			setAmount(Constants.DamageWaiver.DAMAGE_WAIVER_DEFAULT_AMOUNT);
			return;
		}
		calculate(chargeAmount);
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount the new amount
	 */
	public void setAmount(final BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * Sets the credit amount.
	 *
	 * @param creditAmount the new credit amount
	 */
	public void setCreditAmount(final BigDecimal creditAmount) {
		this.creditAmount = creditAmount;
	}
	
	/**
	 * Sets the declined.
	 *
	 * @param declined the new declined
	 */
	public void setDeclined(final Boolean declined) {
		isDeclined = declined;
	}
}
