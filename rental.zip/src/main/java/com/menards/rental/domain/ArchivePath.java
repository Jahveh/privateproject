/**
 * ArchivePath.java
 */
package com.menards.rental.domain;

/**
 * The class that holds information about archive path.
 *
 * @author deep
 */
public class ArchivePath {

    /** The url from where we need to archive. */
    private String urlFrom;


    /**
     * The getter for the url from value.
     * @return the value of url from.
     */
    public String getURLFrom() {
        return urlFrom;
    }

    /**
     * The setter for the url from value.
     * @param urlFrom the value to set.
     */
    public void setURLFrom(final String urlFrom) {
        this.urlFrom = urlFrom;
    }
}
