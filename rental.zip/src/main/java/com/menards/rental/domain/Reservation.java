/*
 * Reservation.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.persistence.*;

import com.menards.rental.utils.Constants;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

import com.menards.rental.format.SimpleTimePeriodFormatter;

/**
 * The Class Reservation.
 */
@Entity
@RooJavaBean
@Table(name = "reservation_detail")
@RooEntity(identifierColumn = "reservation_id")
public class Reservation implements Serializable {

	/** The check out time stamp. */
	@Column(name = "estimated_check_out_ts")
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar checkOutTimeStamp;

	/** The check in time stamp. */
	@Column(name = "estimated_check_in_ts")
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar checkInTimeStamp;

	/** The product. */
	@ManyToOne(targetEntity = Product.class, fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "product_id")
	private Product product;

	/** The agreement. */
	@ManyToOne(targetEntity = ReservationAgreement.class, fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "reservation_agreement_id")
	private ReservationAgreement agreement;

	/** The status. */
	@ManyToOne(targetEntity = ReservationStatus.class, fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "reservation_status_id")
	private ReservationStatus status;

    /** The estimated charge amount. */
    @Column(name = "estimated_charge_amt")
    private BigDecimal estimatedChargeAmount;

    /** The estimated damage waiver. */
    @Column(name = "estimated_damage_waiver_amt")
    private BigDecimal estimatedDamageWaiver = new BigDecimal("0.0");

    /** The estimated surcharge price amount. */
    @Column(name = "estimated_surcharge_price_amt")
    private BigDecimal estimatedSurchargePriceAmount;

    /** The esitmated rental duration. */
    @Column(name = "estimated_sku_hr_qty")
    private Double estimatedRentalDuration;

    /** The base price amount. */
    @Column(name = "base_price_amt")
    private BigDecimal basePriceAmount;

    /** The incremental price amount. */
    @Column(name = "incremental_price_amt")
    private BigDecimal incrementalPriceAmount;

    /** The surcharge price amount. */
    @Column(name = "surcharge_price_amt")
    private BigDecimal surchargePriceAmount;

    /** The base sku hr qty. */
    @Column(name = "base_sku_hr_qty")
    private Double baseSkuHrQty;

    /** The incremental sku hr qty. */
    @Column(name = "incremental_sku_hr_qty")
    private Double incrementalSkuHrQty;


	/** The is in process. */
	@Transient
	private boolean isInProcess;

	/** The item serial number. */
	@Transient
	private Long itemSerialNumber;


	/**
	 * Fulfill.
	 */
	public void fulfill() {
		setStatus(ReservationStatus.findFulfilled());
	}

	/**
     * Getter for base price amount.
     * @return the value.
     */
    public BigDecimal getBasePriceAmount() {
        return basePriceAmount;
    }

	/**
     * Getter for base sku hr.
     * @return the value.
     */
    public Double getBaseSkuHrQty() {
        return baseSkuHrQty;
    }

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return product.getDescriptionEscaped();
	}

	/**
	 * Gets the formatted check in time.
	 *
	 * @return the formatted check in time
	 */
	public String getFormattedCheckInTime() {
		if (null == getCheckInTimeStamp()) {
			return "";
		}
		return new SimpleDateFormat("MM/dd/yyyy hh:mm aa").format(getCheckInTimeStamp().getTime());
	}

	/**
	 * Gets the formatted check out time.
	 *
	 * @return the formatted check out time
	 */
	public String getFormattedCheckOutTime() {
		if (null == getCheckOutTimeStamp()) {
			return "";
		}
		return new SimpleDateFormat("MM/dd/yyyy hh:mm aa").format(getCheckOutTimeStamp().getTime());
	}

	/**
     * Getter for incremental price amount.
     * @return the value.
     */
    public BigDecimal getIncrementalPriceAmount() {
        return incrementalPriceAmount;
    }

	/**
     * Getter for incremental sku hr.
     * @return the value.
     */
    public Double getIncrementalSkuHrQty() {
        return incrementalSkuHrQty;
    }

	/**
	 * Gets the rental duration display.
	 *
	 * @return the rental duration display
	 */
	public String getRentalDurationDisplay() {
		return new SimpleTimePeriodFormatter().format(getEstimatedRentalDuration());
	}

	/**
	 * Gets the rental sku.
	 *
	 * @return the rental sku
	 */
	public String getRentalSKU() {
		return product.getFormattedBaseSKU();
	}

    /**
     * Getter for the base sku value.
     * @return the base sku value.
     */
    public Long getBaseSKUValue() {
        return product.getBaseSkuValue();
    }

    /**
     * The surcharge sku applicable for this reservation.
     * @return the string representing the surcharge sku.
     */
    public String getSurchargeSKU() {
        return product.getFormattedSurchargeSKU();
    }

	/**
     * Getter for surcharge price amount.
     * @return the value.
     */
    public BigDecimal getSurchargePriceAmount() {
        return surchargePriceAmount;
    }

	/**
	 * Checks if is cancelled.
	 *
	 * @return true, if is cancelled
	 */
	public boolean isCancelled() {
		return status.isCancelled();
	}

	/**
	 * Checks if is for product.
	 *
	 * @param productId the product id
	 * @return true, if is for product
	 */
	public boolean isForProduct(final long productId) {
		return product.isIdMatching(productId);
	}

	/**
	 * Checks if is for same product.
	 *
	 * @param agreementItem the agreement item
	 * @return true, if is for same product
	 */
	public boolean isForSameProduct(final AgreementItem agreementItem) {
		return product.isIdMatching(agreementItem.getProductId());
	}

	/**
	 * Checks if is for store.
	 *
	 * @param storeNumber the store number
	 * @return true, if is for store
	 */
	public boolean isForStore(final Integer storeNumber) {
		return agreement.isForStore(storeNumber);
	}

	/**
	 * Checks if is fulfilled.
	 *
	 * @return true, if is fulfilled
	 */
	public boolean isFulfilled() {
		return status.isFulfilled();
	}

    /**
	 * Checks if is in process.
	 *
	 * @return true, if is in process
	 */
	public boolean isInProcess() {
		return isInProcess;
	}

    /**
	 * Checks if is open.
	 *
	 * @return true, if is open
	 */
	public boolean isOpen() {
		return status.isOpen();
	}

    /**
	 * Checks if is overlapping.
	 *
	 * @param other the other
	 * @return true, if is overlapping
	 */
	public boolean isOverlapping(final Reservation other) {
		return isOverlappingForStore(other.getStoreNumber(), other.getCheckOutTimeStamp(), other
		        .getCheckInTimeStamp());
	}

    /**
	 * Checks if is overlapping for store.
	 *
	 * @param storeNumber the store number
	 * @param outDate the out date
	 * @param inDate the in date
	 * @return true, if is overlapping for store
	 */
	public boolean isOverlappingForStore(final Integer storeNumber, final Calendar outDate, final Calendar inDate) {
		if (!isForStore(storeNumber)) {
			return false;
		}

		return !(((checkOutTimeStamp.compareTo(outDate) > 0) && (checkOutTimeStamp.compareTo(inDate) > 0))
                || ((checkInTimeStamp.compareTo(outDate) < 0) && (checkInTimeStamp.compareTo(inDate) < 0)));
	}

    /**
	 * Prepare agreement item.
	 *
	 * @param agreementItem the agreement item
	 */
	public void prepareAgreementItem(final AgreementItem agreementItem) {
		agreementItem.setDueBy(getCheckInTimeStamp());
		agreementItem.setReservationAgainstProduct(this);
	}

    /**
     * Calculates the charges and durations based ont he checkout and checkin timestamp.
     */
    public void calculateEstimatedChargesAndDuration() {
        final ChargeCalculator chargeCalculator = new ChargeCalculator(
                basePriceAmount, incrementalPriceAmount, baseSkuHrQty,
                incrementalSkuHrQty, checkOutTimeStamp, checkInTimeStamp);
        chargeCalculator.calculate();
        setEstimatedChargeAmount(chargeCalculator.getChargeAmount());
        if (product.getIsDamageWaiverAvailable()) {
            setEstimatedDamageWaiver(
                    Constants.DamageWaiver.DAMAGE_WAIVER_PERCENTAGE.multiply(getEstimatedChargeAmount()));
        }
        setEstimatedRentalDuration(chargeCalculator.getRentalDuration());
        setEstimatedSurchargePriceAmount(getSurchargePriceAmount());
    }

    /**
     * Returns the total estimated charge amount which is the sum of estimated charge
     * amount and the surcharge price amount.
     * @return the total esitmated charge amount.
     */
    public BigDecimal getTotalEstimatedChargeAmountPlusSurchargeAmount() {
        if (estimatedSurchargePriceAmount == null) {
            return estimatedChargeAmount;
        }
        return estimatedChargeAmount.add(estimatedSurchargePriceAmount);
    }

    /**
     * Copies the charges and durations from the product.
     */
    public void copyChargeInfo() {
        setBaseSkuHrQty(product.getBaseSkuHrQty());
        setIncrementalSkuHrQty(product.getIncrementalSkuHrQty());
    }

    /**
     * Copies the price from the kiosk product detail.
     * @param kioskProductDetail the kiosk product details.
     */
    public void copyPriceFrom(final KioskProductDetail kioskProductDetail) {
        setBasePriceAmount(kioskProductDetail.getBaseSKUChargeAmount());
        setIncrementalPriceAmount(kioskProductDetail.getIncrementalSKUChargeAmount());
        setSurchargePriceAmount(kioskProductDetail.getSurchargeSKUChargeAmount());
    }

    /**
     * The setter for the base price amount.
     * @param basePriceAmount the value.
     */
    public void setBasePriceAmount(final BigDecimal basePriceAmount) {
        this.basePriceAmount = basePriceAmount;
    }

    /**
     * Setter for base sku hr qty.
     * @param baseSkuHrQty the value.
     */
    public void setBaseSkuHrQty(final Double baseSkuHrQty) {
        this.baseSkuHrQty = baseSkuHrQty;
    }

    /**
     * Setter for the incremental price amount.
     * @param incrementalPriceAmount the value.
     */
    public void setIncrementalPriceAmount(final BigDecimal incrementalPriceAmount) {
        this.incrementalPriceAmount = incrementalPriceAmount;
    }

    /**
     * Setter for incremental sku hr qty.
     * @param incrementalSkuHrQty the value.
     */
    public void setIncrementalSkuHrQty(final Double incrementalSkuHrQty) {
        this.incrementalSkuHrQty = incrementalSkuHrQty;
    }

    /**
	 * Sets the in process.
	 *
	 * @param inProcess the new in process
	 */
	public void setInProcess(final boolean inProcess) {
		isInProcess = inProcess;
	}

    /**
     * Setter for surcharge price amount.
     * @param surchargePriceAmount the value.
     */
    public void setSurchargePriceAmount(final BigDecimal surchargePriceAmount) {
        this.surchargePriceAmount = surchargePriceAmount;
    }

    /**
	 * Start processing.
	 */
	public void startProcessing() {
		setInProcess(true);
	}

    /**
	 * Gets the store number.
	 *
	 * @return the store number
	 */
	private Integer getStoreNumber() {
		return agreement.getStoreNumber();
	}

    /**
     * Returns the list of reservations that have the estimated checkout date earlier than the threshold.
     * @param threshold the threshold for the checkout date.
     * @return list of open reservations having estimated checkout date earlier than the threshold.
     */
    public static List<Reservation> findAllOpenReservationsThatAreOlderThan(final Calendar threshold) {
        final Query query = entityManager()
                .createQuery("select r from Reservation r "
                        + "where r.status = :openStatus and r.checkOutTimeStamp < :threshold");
        query.setParameter("openStatus", ReservationStatus.findOpen());
        query.setParameter("threshold", threshold);
        return query.getResultList();
    }

    /**
     * Should returns true if guest age is greater than minium rental age.
     * @param guest the guest under question.
     * @return true if the guest meets the age limit, false otherwise.
     */
    public boolean isGuestAgeGreaterThanMinimumAge(final Guest guest) {
        return product.isGuestAgeGreaterThanMinimumAge(guest);
    }
}
