/*
 * DifferenceOfValueAndBaseHoursWithRoundingIncrementalHoursCalculationRule.java
 */
package com.menards.rental.domain.rule;

import com.menards.rental.domain.StoreHourBasedRentalDateRange;
import com.menards.rental.domain.strategy.Max12HoursPerDayRoundingStrategy;

/**
 * The difference of value and base hours calculation rule with rounding.
 * @author deep
 */
public class DiffOfValAndBaseHrsWithRndIncreHrsCalcRule implements
        IncrementalHoursCalculationRule {

	/** The base sku hr qty. */
	private final double baseSkuHrQty;

	/** The incremental sku hr qty. */
	private final double incrementalSkuHrQty;

	/** The rental date range. */
	private final StoreHourBasedRentalDateRange rentalDateRange;

	/**
	 * Instantiates a new difference of value and base hours with rounding incremental hours calculation rule.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @param incrementalSkuHrQty the incremental sku hr qty
	 * @param rentalDateRange the rental date range
	 */
	public DiffOfValAndBaseHrsWithRndIncreHrsCalcRule(final double baseSkuHrQty,
	        final double incrementalSkuHrQty, final StoreHourBasedRentalDateRange rentalDateRange) {
		this.baseSkuHrQty = baseSkuHrQty;
		this.incrementalSkuHrQty = incrementalSkuHrQty;
		this.rentalDateRange = rentalDateRange;
	}

    /**
     * {@inheritDoc}
     */
	public double calculate() {
		return new Max12HoursPerDayRoundingStrategy().calculateRoundedIncrementalHoursAfterSubtractingBaseHours(
		        baseSkuHrQty, incrementalSkuHrQty, rentalDateRange.getActualDurationInHours());
	}
}
