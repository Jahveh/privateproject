/*
 * AgreementIncrement.java
 */
package com.menards.rental.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.dao.DataAccessException;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;

import com.menards.rental.utils.Constants;

/**
 * The Class AgreementIncrement.
 */
@Entity
@RooJavaBean
@RooToString
@Table(name = "agreement_increment")
@RooEntity(finders = { "findAgreementIncrementsByStoreNumber" })
public class AgreementIncrement implements Serializable {

	/** The store number. */
	@NotNull
	@Size(min = 50)
	@Column(name = "store_number")
	private Integer storeNumber;

	/** The current number. */
	@Column(name = "current_number")
	private Integer currentNumber;

	/**
	 * Instantiates a new agreement increment.
	 */
	public AgreementIncrement() {

	}

	/**
	 * Instantiates a new agreement increment.
	 *
	 * @param storeNumber the store number
	 */
	public AgreementIncrement(final Integer storeNumber) {
		this(storeNumber, Constants.Agreement.AGREEMENT_NUMBER_INITIAL_VALUE);
	}

	/**
	 * Instantiates a new agreement increment.
	 *
	 * @param storeNumber the store number
	 * @param currentNumber the current number
	 */
	public AgreementIncrement(final Integer storeNumber, final int currentNumber) {
		this.storeNumber = storeNumber;
		this.currentNumber = currentNumber;
	}

	/**
	 * Gets the next agreement number for store number.
	 *
	 * @param storeNumber the store number
	 * @return the next agreement number for store number
	 */
	public static int getNextAgreementNumberForStoreNumber(final Integer storeNumber) {
		AgreementIncrement agreementIncrement;
		try {
			agreementIncrement = (AgreementIncrement) AgreementIncrement.findAgreementIncrementsByStoreNumber(
			        storeNumber).getSingleResult();
		} catch (final DataAccessException dae) {
			agreementIncrement = createNewAgreementIncrementForStore(storeNumber);
		}
		agreementIncrement.incrementCurrentNumber();
		agreementIncrement.persist();
		return agreementIncrement.getCurrentNumber();

	}

	/**
	 * Creates the new agreement increment for store.
	 *
	 * @param storeNumber the store number
	 * @return the agreement increment
	 */
	private static AgreementIncrement createNewAgreementIncrementForStore(final Integer storeNumber) {
		return new AgreementIncrement(storeNumber);
	}

	/**
	 * Increment current number.
	 */
	private void incrementCurrentNumber() {
		currentNumber++;
		if (currentNumber > Constants.Agreement.AGREEMENT_NUMBER_MAX_VALUE) {
			currentNumber = Constants.Agreement.AGREEMENT_NUMBER_INITIAL_VALUE;
		}
	}
}
