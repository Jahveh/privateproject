/*
 * MinimumItmsRequiredCalculationStrategy.java
 */
package com.menards.rental.domain.strategy;

import java.util.ArrayList;
import java.util.List;

import com.menards.rental.domain.Reservation;

/**
 * Minimum number of items required calculation strategy. 
 * @author deep
 */
public class MinimumItmsRequiredCalculationStrategy {

	/** The overlapping reservations. */
	private final List<Reservation> overlappingReservations;

	/**
	 * Instantiates a new minimum number of items required calculation strategy.
	 *
	 * @param overlappingReservations the overlapping reservations
	 */
	public MinimumItmsRequiredCalculationStrategy(final List<Reservation> overlappingReservations) {
		this.overlappingReservations = new ArrayList<Reservation>(overlappingReservations);
	}

	/**
	 * Count.
	 *
	 * @return the int
	 */
	public int count() {
		return countActuallyOverlappingReservationsForStore(overlappingReservations);
	}

	/**
	 * Gets the non overlapping reservations list.
	 *
	 * @return the non overlapping reservations list
	 */
	public List<List<Reservation>> getNonOverlappingReservationsList() {
		return getNonOverlappingReservationsList(overlappingReservations, new ArrayList<List<Reservation>>());
	}

	/**
	 * Count actually overlapping reservations for store.
	 *
	 * @param overlappingReservations the overlapping reservations
	 * @return the int
	 */
	private int countActuallyOverlappingReservationsForStore(final List<Reservation> overlappingReservations) {
		if (overlappingReservations.size() <= 1) {
			return overlappingReservations.size();
		}

		overlappingReservations.removeAll(findNonOverlappingDurationsFor(overlappingReservations.get(0),
		        overlappingReservations.subList(1, overlappingReservations.size())));

		return 1 + countActuallyOverlappingReservationsForStore(overlappingReservations);
	}

	/**
	 * Find non overlapping durations for.
	 *
	 * @param me the me
	 * @param reservations the reservations
	 * @return the list
	 */
	private List<Reservation> findNonOverlappingDurationsFor(final Reservation me,
	        final List<Reservation> reservations) {
		final List<Reservation> nonOverlappingDurations = new ArrayList<Reservation>();
		nonOverlappingDurations.add(me);
		if (reservations.isEmpty()) {
			return nonOverlappingDurations;
		}

		final List<Reservation> reservationsThatDontOverlapMe = new ArrayList<Reservation>();
		for (final Reservation reservation : reservations) {
			if (!me.isOverlapping(reservation)) {
				reservationsThatDontOverlapMe.add(reservation);
			}
		}
		if (reservationsThatDontOverlapMe.size() <= 1) {
			nonOverlappingDurations.addAll(reservationsThatDontOverlapMe);
			return nonOverlappingDurations;
		}
		nonOverlappingDurations.addAll(findNonOverlappingDurationsFor(reservationsThatDontOverlapMe.get(0),
		        reservationsThatDontOverlapMe.subList(1, reservationsThatDontOverlapMe.size())));
		return nonOverlappingDurations;
	}

	/**
	 * Gets the non overlapping reservations list.
	 *
	 * @param overlappingReservations the overlapping reservations
	 * @param listOfNonOverlappingReservations the list of non overlapping reservations
	 * @return the non overlapping reservations list
	 */
	private List<List<Reservation>> getNonOverlappingReservationsList(
	        final List<Reservation> overlappingReservations,
	        final List<List<Reservation>> listOfNonOverlappingReservations) {
		if (overlappingReservations.isEmpty()) {
			return listOfNonOverlappingReservations;
		}
		if (overlappingReservations.size() == 1) {
			listOfNonOverlappingReservations.add(overlappingReservations);
			return listOfNonOverlappingReservations;
		}

		listOfNonOverlappingReservations.add(findNonOverlappingDurationsFor(overlappingReservations.get(0),
		        overlappingReservations.subList(1, overlappingReservations.size())));
		overlappingReservations.removeAll(listOfNonOverlappingReservations.get(listOfNonOverlappingReservations
		        .size() - 1));

		return getNonOverlappingReservationsList(overlappingReservations, listOfNonOverlappingReservations);
	}
}
