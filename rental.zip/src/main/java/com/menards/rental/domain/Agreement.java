/*
 * Agreement.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Query;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.annotations.Cascade;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

import com.menards.rental.builder.AgreementNumberBuilder;
import com.menards.rental.service.notification.AgreementUpdateNotifier;
import com.menards.rental.utils.Constants;

/**
 * The Class Agreement.
 * @author deep
 */
@Entity
@RooJavaBean
@Table(name = "rental_agreement", uniqueConstraints = {@UniqueConstraint(columnNames = {"rental_agreement_nbr",
        "store_nbr", "tran_dt" }) })
@RooEntity(identifierColumn = "rental_agreement_id", finders = {"findAgreementsByStore",
        "findAgreementsByStoreAndAgreementNumber", "findAgreementsByStoreAndAgreementNumberLike",
        "findAgreementsByAgreementNumber", "findAgreementsByAgreementStatusAndLastUpdateDateLessThan" })
public class Agreement implements Serializable {

	@Transient
	private Integer checkinTeamMember;
	
	/**
     * The log.
     */
    private static final Logger log = Logger.getLogger(Agreement.class);

    /**
     * The guest.
     */
    @OneToOne(targetEntity = Guest.class, optional = true, cascade = CascadeType.ALL)
    @JoinColumn(name = "guest_id", nullable = true)
    private Guest guest;

    /**
     * The agreement number.
     */
    @NotNull
    @Column(name = "rental_agreement_nbr", nullable = false)
    private String agreementNumber;

    public String getAgreementNbr() {
    	return agreementNumber;
    }
    
    /**
     * The rental date.
     */
    @NotNull
    @Column(name = "tran_dt", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "SS")
    private Calendar rentalDate;

    /**
     * The void approved team member name.
     */
    @Column(name = "void_approved_tm_number")
    private Integer voidApprovedTeamMemberNumber;

    /** The team member who approved the rental for a guest with no id. */
    @Column(name = "no_id_rental_approved_tm_number")
    private Integer noIdRentalApprovedTeamMemberNumber;

    /**
     * The items.
     */
    @OneToMany(targetEntity = AgreementItem.class, fetch = FetchType.LAZY,
            mappedBy = "agreement", cascade = CascadeType.ALL)
    @Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
    private Set<AgreementItem> items = new HashSet<AgreementItem>();

    /**
     * The created by team member name.
     */
    @Column(name = "enter_by_tm_number")
    private Integer createdByTeamMemberNumber;

    /**
     * The agreement status.
     */
    @ManyToOne(targetEntity = AgreementStatus.class, fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "rental_status_cd")
    private AgreementStatus agreementStatus;

    /**
     * The transaction number.
     */
    @Column(name = "tran_nbr")
    private String transactionNumber;

    /**
     * The register number.
     */
    @Column(name = "tran_reg_nbr")
    private String registerNumber;

    /** The initial paid date. */
    @Column(name = "initial_paid_dt")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "SS")
    private java.util.Calendar initialPaidDate;

    /**
     * The overall comment.
     */
    @Column(name = "overall_comment")
    private String overallComment;

    /**
     * The store.
     */
    @Embedded
    private Store store;

    /** The last update date.  The date when the agreement was last updated. */
    @Column(name = "last_update_date")
    private java.util.Calendar lastUpdateDate;

    /**
     * The vehicle rental detail.
     */
    @Transient
    private VehicleRentalDetail vehicleRentalDetail;

    /**
     * The item list.
     */
    @Transient
    private List<AgreementItem> itemList = LazyList.decorate(new ArrayList<AgreementItem>(), FactoryUtils
            .instantiateFactory(AgreementItem.class));

    /**
     * The removed item list.
     */
    @Transient
    private List<AgreementItem> removedItemList = new ArrayList<AgreementItem>();

    /**
     * The checkin date.
     */
    @Transient
    private Calendar checkinDate;

    /** The store user info associated with the agreement. */
    @Transient
    private StoreUserInfo storeUser;
    /** The Agreement log  associated with the agreement.*/
	@OneToOne(targetEntity = AgreementLog.class, optional = true, mappedBy = "agreement", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private AgreementLog agreementLog;

    /** The agreement update notifier. */
    @Autowired
    private transient AgreementUpdateNotifier agreementUpdateNotifier;

    /**
     * Instantiates a new agreement.
     */
    public Agreement() {
    }

    /**
     * Instantiates a new agreement.
     *
     * @param agreementNumber the agreement number
     * @param store           the store
     */
    public Agreement(final String agreementNumber, final Store store) {
        setAgreementNumber(agreementNumber);
        setStore(store);
    }

    /**
     * Find active agreement associated with item.
     *
     * @param item the item
     * @return the agreement
     */
    public static Agreement findActiveAgreementAssociatedWithItem(final Item item) {
        final Query query = entityManager().createQuery(
                "select a from Agreement a inner join a.items ai "
                        + "where a.agreementStatus = :status and ai.item = :item and ai.status = :checkedout_and_paid");
        query.setParameter("status", AgreementStatus.findActive());
        query.setParameter("item", item);
        query.setParameter("checkedout_and_paid", AgreementItemStatus.findCheckedOutAndPaidInitial());
        final List<Agreement> agreementList = query.getResultList();
        if ((null != agreementList) && (agreementList.size() > 1)) {
            log.error("More than one active agreement are associated with Item " + item.getId()
                    + " THIS SHOULD NOT HAPPEN");
            return null;
        }
        if ((null != agreementList) && (agreementList.size() == 1)) {
            return agreementList.get(0);
        }
        return null;
    }

    /**
     * Find active agreement associated with item.
     *
     * @param item the item
     * @return the agreement
     */
    public static Long findActiveAgreementIdAssociatedWithItem(final Item item) {
        final Query query = entityManager().createQuery(
                "select a.id from Agreement a inner join a.items ai "
                        + "where a.agreementStatus = :status and ai.item = :item and ai.status = :checkedout_and_paid");
        query.setParameter("status", AgreementStatus.findActive());
        query.setParameter("item", item);
        query.setParameter("checkedout_and_paid", AgreementItemStatus.findCheckedOutAndPaidInitial());
        final List agreementList = query.getResultList();
        if ((null != agreementList) && (agreementList.size() > 1)) {
            log.error("More than one active agreement are associated with Item " + item.getId()
                    + " THIS SHOULD NOT HAPPEN");
            return null;
        }
        if ((null != agreementList) && (agreementList.size() == 1)) {
            return (Long) agreementList.get(0);
        }
        return null;
    }

    /**
     * returns the agreement for the given number.
     *
     * @param agreementNumber the agreement number
     * @return the agreement
     */
    public static Agreement findAgreementByAgreementNumber(final String agreementNumber) {
        final Query query = Agreement.findAgreementsByAgreementNumber(agreementNumber);
        final List<Agreement> agreementList = query.getResultList();

        if (agreementList.size() > 0) {
            return agreementList.get(0);
        }
        return null;
    }

    /**
     * Find agreements by agreement status and store number for a time period.
     *
     * @param agreementStatus the agreement status
     * @param storeNumber     the store number
     * @param startDate       the start date
     * @param endDate         the end date
     * @return the list
     */
    public static List<Agreement> findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(
            final AgreementStatus agreementStatus, final Integer storeNumber, final Calendar startDate,
            final Calendar endDate) {
        final EntityManager manager = Agreement.entityManager();
        final Query query = manager
                .createQuery("from Agreement a "
                        + "where a.agreementStatus = :status and a.store.storeNumber = :storeNumber "
                        + "and a.rentalDate between :startDate and :endDate");
        query.setParameter("status", agreementStatus);
        query.setParameter("storeNumber", storeNumber);
        query.setParameter("startDate", startDate);
        query.setParameter("endDate", endDate);
        return query.getResultList();
    }

    /**
     * Find agreements by search criteria.
     *
     * @param searchAgreementsCriteria the search agreements criteria
     * @return the list
     */
    public static List<Agreement> findAgreementsBySearchCriteria(final DetachedCriteria searchAgreementsCriteria) {
        return searchAgreementsCriteria.getExecutableCriteria((Session) entityManager().getDelegate()).list();
    }

    /**
     * Load full.
     *
     * @param agreementId the agreement id
     * @return the agreement
     */
    public static Agreement loadFull(final long agreementId) {
    	Agreement agreement = (Agreement) entityManager().createQuery(
                "SELECT a from Agreement a LEFT JOIN FETCH a.items i "
                        + "LEFT JOIN FETCH i.vehicleRentalDetail v LEFT JOIN FETCH i.chargeInfo.answers ca "
                        + "LEFT JOIN FETCH i.item ii LEFT JOIN FETCH i.status LEFT JOIN FETCH ii.itemStatus "
                        + "LEFT JOIN FETCH ii.product p "
                        + "LEFT JOIN FETCH p.skuInfo.baseSKU LEFT JOIN FETCH p.skuInfo.incrementalSKU "
                        + "LEFT JOIN FETCH p.skuInfo.surchargeSKU LEFT JOIN FETCH p.skuInfo.sellingSKU "
                        + "LEFT JOIN FETCH a.guest "
                        + "LEFT JOIN FETCH v.vehicle LEFT JOIN FETCH v.additionalDrivers "
                        + "LEFT JOIN FETCH a.agreementStatus WHERE a.id=:id")
                .setParameter("id", agreementId)
                .getSingleResult();
    	return agreement;
    }

    /**
     * Adds the to items.
     *
     * @param agreementItem the agreement item
     */
    public void addToItems(final AgreementItem agreementItem) {
        items.add(agreementItem);
        agreementItem.setAgreement(this);
        itemList.clear();
    }

    /**
     * Adds the to removed item list.
     *
     * @param removedAgreementItem the removed agreement item
     */
    public void addToRemovedItemList(final AgreementItem removedAgreementItem) {
        removedItemList.add(removedAgreementItem);
    }

    /**
     * Calculate damage waiver charges.
     */
    public void calculateDamageWaiverCharges() {
        new AgreementItemCollection(items).calculateDamageWaiverCharges();
    }

    /**
     * Cancel agreement.
     */
    public void cancelAgreement() {
        this.setAgreementStatus(AgreementStatus.findCancelled());
        this.persist();
        new AgreementItemCollection(items).markAgreementItemStatusAsAvailable();
    }

    /**
     * Checkin marked items.
     */
    public void checkinMarkedItems() {
        new AgreementItemCollection(items).checkinMarkedItems();
    }

    /**
     * Find item by serial number.
     *
     * @param serialNumber the serial number
     * @return the agreement item
     */
    public AgreementItem findItemBySerialNumber(final long serialNumber) {
        return new AgreementItemCollection(items).findItemBySerialNumber(serialNumber);
    }

    /**
     * Fulfill reservations.
     */
    public void fulfillReservations() {
        new AgreementItemCollection(getItems()).fulfillReservations();
    }

    /**
     * Generate new number.
     *
     * @param agreementNumberBuilder the agreement number builder
     */
    public void generateNewNumber(final AgreementNumberBuilder agreementNumberBuilder) {
        setAgreementNumber(agreementNumberBuilder.build(this.getStore().getStoreNumber()));
    }

    /**
     * Gets the agreement number only.
     *
     * @return the agreement number only
     */
    public String getAgreementNumberOnly() {
        final String[] agreementParts = agreementNumber.split("-");
        if (agreementParts.length < 2) {
            return agreementParts[0];
        }
        return agreementParts[1];
    }

    /**
     * Returns the agreement number removing the hyphen e.g. if agreement number is 1234-23456-001 it will return
     * 123423456001
     *
     * @return the agreement number without hyphen
     */
    public Long getAgreementNumberWithoutHyphen() {
        final String numberAsText = agreementNumber.replaceAll("-", "");
        return Long.parseLong(numberAsText);
    }

    /**
     * Gets the agreement status.
     *
     * @return the agreement status
     */
    public AgreementStatus getAgreementStatus() {
        return agreementStatus;
    }

    /**
     * Check if the agreement can be voided or cancelled.
     *
     * @return true if agreement can be voided or canceled.
     */
    public boolean getCancelorVoidAllowed() {
        // If the agreement is in active or pending status only
        // than the cancel and void does makes sense
        if (agreementStatus.isActive() || agreementStatus.isPending()) {
            // Now we have to make sure that all the agreement items
            // to this agreement are not in checked in or returned state
            return new AgreementItemCollection(items).isEveryItemCheckedOutOrCheckedOutAndPaidInitial();
        }
        return false;
    }

    /**
     * Gets the checkin time.
     *
     * @return the checkin time
     */
    public Calendar getCheckinDate() {
        return checkinDate;
    }

    /**
     * Get the damage waiver total of the agreement. If the guest has declined damage waiver that is excluded Damage
     * Waiver
     *
     * @return the damage waiver total
     */
    public BigDecimal getDamageWaiverTotal() {
        BigDecimal total = new BigDecimal("0.0");
        if ((null == items) || (items.isEmpty()) || (null == agreementStatus)) {
            return total;
        }
        if (agreementStatus.isPending()) {
            total = new AgreementItemCollection(items).getDamageWaiverTotal();
        }
        if (agreementStatus.isVoided()) {
            total = new AgreementItemCollection(items).getDamageWaiverTotal().negate();
        }
        return total;
    }

    /**
     * Gets the display overall comment.
     *
     * @return the display overall comment
     */
    public String getDisplayOverallComment() {
        if (null != overallComment) {
            return overallComment.replace("\n", "\\n\\\n");
        }
        return null;
    }

    /**
     * This calculates the effective charge which has to be charged to the customer at that point of time.
     *
     * @return the effective rental total excluding damage waiver
     */
    public BigDecimal getEffectiveRentalTotalExcludingDamageWaiver() {
        if ((null == items) || (agreementStatus.isCancelled()) || (agreementStatus.isCompleted())) {
            return new BigDecimal("0.0");
        }
        return new AgreementItemCollection(items).getEffectiveRentalTotalExcludingDamageWaiver();
    }

    /**
     * Returns the 8 digit agreement number removing the hyphen e.g. if agreement number is 1234-23456-001 it will
     * return 23456001
     *
     * @return the eight digit agreement number without hyphen
     */
    public Long getEightDigitAgreementNumberWithoutHyphen() {
        final String numberAsText = (agreementNumber.replaceAll("-", "")).substring(4);
        return Long.parseLong(numberAsText);
    }

    /**
     * Returns the 8 digit agreement number removing the hyphen e.g. if agreement number is 1234-23456-001 it will
     * return 23456001 for a given agreement number.
     *
     * @return the eight digit agreement number without hyphen
     */
    public Long getEightDigitAgreementNumberWithoutHyphenFor(final String agreementNumber) {
        final String numberAsText = (agreementNumber.replaceAll("-", "")).substring(4);
        return Long.parseLong(numberAsText);
    }

    /**
     * Gets the guest.
     *
     * @return the guest
     */
    public Guest getGuest() {
        return this.guest;
    }

    /**
     * Gets the guest phone number.
     *
     * @return the guest phone number
     */
    public String getGuestPhoneNumber() {
        if (null != guest) {
            return guest.getPhoneNumber();
        }
        return null;
    }

    /**
     * Gets the item list.
     *
     * @return the item list
     */
    public List<AgreementItem> getItemList() {
        if (itemList.isEmpty()) {
            itemList.addAll(items);
        }
        return itemList;
    }

    /**
     * Gets the items.
     *
     * @return the items
     */
    public Set<AgreementItem> getItems() {
        return items;
    }

    /**
     * Gets the next item serial number.  This is the item serial number whose checklist questions have to be answered.
     * @return Long value representing the next items serial number.
     */
    public Long getNextItemSerialNumberToAnswerChecklist() {
        return new AgreementItemCollection(itemList).getNextItemSerialNumberToAnswerChecklist();
    }

    /**
     * Gets the overall comment.
     *
     * @return the overall comment
     */
    public String getOverallComment() {
        return overallComment;
    }

    /**
     * Gets the price override approved by.
     *
     * @return the price override approved by
     */
    public Integer getPriceOverrideApprovedBy() {
        return new AgreementItemCollection(items).getPriceOverrideApprovedBy();
    }

    /**
     * Gets the quantity override approved by.
     *
     * @return the quantity override approved by
     */
    public Integer getQuantityOverrideApprovedBy() {
        return new AgreementItemCollection(items).getQuantityOverrideApprovedBy();
    }

    /**
     * Gets the removed item list.
     *
     * @return the removed item list
     */
    public List<AgreementItem> getRemovedItemList() {
        return removedItemList;
    }

    /**
     * Gets the rental date.
     *
     * @return the rental date
     */
    public Calendar getRentalDate() {
        return rentalDate;
    }

    /**
     * Get the total of rental charge including damage waiver.
     *
     * @return the sub total
     */
    public BigDecimal getSubTotal() {
        return getEffectiveRentalTotalExcludingDamageWaiver().add(getDamageWaiverTotal());
    }

    /**
     * Gets the total additional charge amount of items in returned state.
     *
     * @return the total additional charge amount of items currently checkedin.
     */
    public BigDecimal getTotalAdditionalChargeAmount() {
        BigDecimal totalCharges = new BigDecimal("0");
        for (final AgreementItem agreementItem : this.getItems()) {
            if (agreementItem.isReturned()) {
                totalCharges = totalCharges.add(agreementItem.getTotalAdditionalChargeAmount());
            }
        }

        // Now add the damage waiver credit to it
        totalCharges = totalCharges.add(getTotalDamageWaiverCredit());
        return totalCharges.setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
    }

    /**
     * Gets the total additional charge amount of items currently checkedin. This method is used only while the check in
     * process in going on. For finding the total additional charge amount for report please look into
     * getTotalAdditionalChargeAmount()
     *
     * @return the total additional charge amount of items currently checkedin
     */
    public BigDecimal getTotalAdditionalChargeAmountOfItemsCurrentlyCheckedin() {
        BigDecimal totalCharges = new AgreementItemCollection(items)
                .getTotalAdditionalChargeAmountOfItemsCurrentlyCheckedin();
        totalCharges = totalCharges.add(getTotalDamageWaiverCreditOfItemsCurrentlyCheckedin());
        return totalCharges;
    }

    /**
     * Gets the total damage waiver credit of items that are in returned state.
     *
     * @return the total damage waiver credit for returned items.
     */
    public BigDecimal getTotalDamageWaiverCredit() {
        BigDecimal total = new BigDecimal("0");
        for (final AgreementItem agreementItem : this.getItems()) {
            if (agreementItem.isReturned() && agreementItem.getIsDamageWaiverAvailable()) {
                total = total.add(agreementItem.getDamageWaiverCredit());
            }
        }
        return total;
    }

    /**
     * Gets the total damage waiver credit of items currently checkedin. This method is used only while the check in
     * process in going on. For finding the damage waiver credit for report please look into
     * getTotalDamageWaiverCredit()
     *
     * @return the total damage waiver credit of items currently checkedin
     */
    public BigDecimal getTotalDamageWaiverCreditOfItemsCurrentlyCheckedin() {
        return new AgreementItemCollection(items).getTotalDamageWaiverCreditOfItemsCurrentlyCheckedin();
    }

	/**
	 * Gets the total damage waiver credit.
	 *
	 * @return the total additional charge amount of items currently checkedin.
	 */
	public boolean isDamageWaiverToBeCredited() {
		return getTotalDamageWaiverCreditOfItemsCurrentlyCheckedin().compareTo(new BigDecimal("0")) < 0;
	}

    /**
     * Gets the vehicle rental detail.
     *
     * @return the vehicle rental detail
     */
    public VehicleRentalDetail getVehicleRentalDetail() {
        if (null == vehicleRentalDetail) {
            vehicleRentalDetail = new AgreementItemCollection(items).getFirstVehicleRentalDetail();
        }
        return vehicleRentalDetail;
    }

    /**
     * Increment number.
     *
     * @param agreementNumberBuilder the agreement number builder
     */
    public void incrementNumber(final AgreementNumberBuilder agreementNumberBuilder) {
        setAgreementNumber(agreementNumberBuilder.buildNextIncrement(this.agreementNumber));
    }

    /**
     * Returns true if the agreement status is active.
     * @return true if agreement is in the active state.
     */
    public boolean isActive() {
        return agreementStatus.isActive();
    }

    /**
     * Checks if is completed.
     *
     * @return true, if is completed
     */
    public boolean isCompleted() {
        return agreementStatus.isCompleted();
    }

    /**
     * Checks if is driver age greater than minimum rental age.
     *
     * @return true, if is driver age greater than minimum rental age
     */
    public boolean isDriverAgeGreaterThanMinimumRentalAge() {
        return new AgreementItemCollection(items).isDriverAgeGreaterThanMinimumRentalAge(this);
    }

    /**
     * Checks if is driver age greater than minimum rental age.
     *
     * @param minimumAgeToRent the minimum age to rent
     * @return true, if is driver age greater than minimum rental age
     */
    public boolean isDriverAgeGreaterThanMinimumRentalAge(final int minimumAgeToRent) {
        return (guest.isDriverAgeGreaterThanMinimumRentalAge(minimumAgeToRent)
                && getVehicleRentalDetail().isDriverAgeGreaterThanMinimumRentalAge(minimumAgeToRent));
    }

    /**
     * Checks if is editable.
     *
     * @return true, if is editable
     */
    public boolean isEditable() {
        return agreementStatus.isPending();
    }

    /**
     * Checks if is every item available right now.
     *
     * @return true, if is every item available right now
     */
    public boolean isEveryItemAvailableRightNow() {
        return new AgreementItemCollection(items).isEveryItemAvailableRightNow();
    }

    /**
     * Checks if is insurance additional driver license required.
     *
     * @return true, if is insurance additional driver license required
     */
    public boolean isInsuranceAdditionalDriverLicenseRequired() {
        return new AgreementItemCollection(items).isInsuranceAdditionalDriverLicenseRequired();
    }

    /**
     * Check if the item is already part of the agreement.
     *
     * @param item - The item which needs to be checked if it is part of agreement
     * @return true, if is item part of agreement
     */
    public boolean isItemPartOfAgreement(final Item item) {
        return new AgreementItemCollection(items).containsBySerialNumber(item);
    }

    /**
     * Returns true if the agreement is in pending state.
     * @return true if agreement is in pending state.
     */
    public boolean isPending() {
        return agreementStatus.isPending();
    }

    /**
     * Returns true if atleast one vehicle is rented.
     * @return true if agreement has one vehicle in it.
     */
    public boolean isVehicleRented() {
        return new AgreementItemCollection(items).isVehicleRented();
    }

    /**
     * Checks if is voided.
     *
     * @return true, if is voided.
     */
    public boolean isVoided() {
        return agreementStatus.isVoided();
    }

    /**
     * Checks if is cancelled.
     *
     * @return true, if is cancelled.
     */
    public boolean isCancelled() {
        return agreementStatus.isCancelled();
    }

    /**
     * Merge vehicle rental details.
     */
    public void mergeVehicleRentalDetails() {
        mergeVehicleRentalDetails(this);
    }

    /**
     * Merge vehicle rental details.
     *
     * @param destination the destination
     */
    public void mergeVehicleRentalDetails(final Agreement destination) {
        new AgreementItemCollection(items).merge(destination.getVehicleRentalDetail());
    }

    /**
     * Removes the item by serial number.
     *
     * @param serialNumber the serial number
     * @return the agreement item
     */
    public AgreementItem removeItemBySerialNumber(final Long serialNumber) {
        final AgreementItem agreementItem = findItemBySerialNumber(serialNumber);
        if (null != agreementItem) {
            return removeItem(agreementItem);
        }
        return null;
    }

    /**
     * Sets the agreement number.
     *
     * @param agreementNumber the new agreement number
     */
    public void setAgreementNumber(final String agreementNumber) {
        this.agreementNumber = agreementNumber;
    }

    /**
     * Sets the agreement status.
     *
     * @param agreementStatus the new agreement status
     */
    public void setAgreementStatus(final AgreementStatus agreementStatus) {
        this.agreementStatus = agreementStatus;
    }

    /**
     * The setter for the checkin date.
     * @param checkinDate the value.
     */
    public void setCheckinDate(final Calendar checkinDate) {
        if(null != this.checkinDate) {
            return;
        }
        this.checkinDate = checkinDate;
    }

    /**
     * Sets the guest.
     *
     * @param guest the new guest
     */
    public void setGuest(final Guest guest) {
        this.guest = guest;
    }

    /**
     * Sets the items.
     *
     * @param items the new items
     */
    public void setItems(final Set<AgreementItem> items) {
        this.items = items;
    }

    /**
     * Sets the overall comment.
     *
     * @param overallComment the new overall comment
     */
    public void setOverallComment(final String overallComment) {
        this.overallComment = overallComment;
    }

    /**
     * Sets the price override approved by.
     *
     * @param priceOverrideManagerName the new price override approved by
     */
    public void setPriceOverrideApprovedBy(final Integer priceOverrideManagerName) {
        new AgreementItemCollection(items).setPriceOverrideApprovedBy(priceOverrideManagerName);
    }

    /**
     * Sets the quantity override approved by.
     *
     * @param quantityOverrideManagerName the new quantity override approved by
     */
    public void setQuantityOverrideApprovedBy(final Integer quantityOverrideManagerName) {
        new AgreementItemCollection(items).setQuantityOverrideApprovedBy(quantityOverrideManagerName);
    }

    /**
     * Sets the removed item list.
     *
     * @param removedItemList the new removed item list
     */
    public void setRemovedItemList(final List<AgreementItem> removedItemList) {
        this.removedItemList = removedItemList;
    }

    /**
     * Sets the rental date.
     *
     * @param rentalDate the new rental date
     */
    public void setRentalDate(final Calendar rentalDate) {
        this.rentalDate = rentalDate;
    }

    /**
     * Sets the todays date.
     */
    public void setTodaysDate() {
        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        setRentalDate(calendar);
    }

    /**
     * Sets the vehicle rental detail.
     *
     * @param vehicleRentalDetail the new vehicle rental detail
     */
    public void setVehicleRentalDetail(final VehicleRentalDetail vehicleRentalDetail) {
        this.vehicleRentalDetail = vehicleRentalDetail;
    }

    /**
     * updates the status of all returned items to the value passed as argument.
     * @param agreementItemStatus the status value to update.
     */
    public void updateAgreementItemForReturnedItems(final AgreementItemStatus agreementItemStatus) {
        new AgreementItemCollection(items).updateAgreementItemForReturnedItems(
                agreementItemStatus
        );

    }

    /**
     * Update agreement item status.
     *
     * @param agreementItemStatus the agreement item status
     */
    public void updateAgreementItemStatus(final AgreementItemStatus agreementItemStatus) {
        new AgreementItemCollection(items).updateAgreementItemStatus(agreementItemStatus);
    }

    /**
     * Should update the checkout date of all the agreement items to the value passed as argument.
     * @param transactionDate the checkout date that we probably got from kiosk server.
     */
    public void updateCheckoutDate(final Calendar transactionDate) {
        new AgreementItemCollection(items).updateCheckoutDate(transactionDate);
    }

    /**
     * Update items status.
     *
     * @param status the status
     */
    public void updateItemsStatus(final ItemStatus status) {
        new AgreementItemCollection(items).updateItemsStatus(status);
    }

    /**
     * Update overrides.
     */
    public void updateOverrides() {
        new AgreementItemCollection(items).updateOverrides();
    }

    /**
     * Update removed items status.
     */
    public void updateRemovedItemsStatus() {
        new AgreementItemCollection(removedItemList).updateItemsStatus(ItemStatus.findAvailable());
    }

    /**
     * Update status if required.
     *
     * @param agreementStatus the agreement status
     */
    public void updateStatusIfRequired(final AgreementStatus agreementStatus) {
        if (null == getAgreementStatus()) {
            setAgreementStatus(agreementStatus);
        }
    }

    /**
     * Update the status of agreement to completed if all the items have been returned and paid complete.
     * @param completedStatus the completed status to set in the agreement if all items have been returned.
     */
    public void updateStatusToCompletedIfAllItemsReturned(final AgreementStatus completedStatus) {
        if (new AgreementItemCollection(items).isEveryItemReturnedAndPaid()) {
            setAgreementStatus(completedStatus);
        }
    }

    /**
     * Voids the agreement.
     */
    public void voidAgreement() {
        this.setAgreementStatus(AgreementStatus.findVoided());
        this.persist();
        new AgreementItemCollection(items).markAgreementItemStatusAsAvailable();
    }

    /**
     * The method that represents that the void was completed successfully.  Should mark all the items as returned
     * and paid complete.
     */
    public void voidComplete() {
        new AgreementItemCollection(items).markAgreementItemsReturnedAndPaid();
    }

    /**
     * Returns true if there are other items other than the pick & go truck.
     * @return true if other items are present.
     */
    public boolean getHasOtherItemsThatDoNotRequireAdditionalDriver() {
        return new AgreementItemCollection(items).getHasOtherItemsThatDoNotRequireAdditionalDriver();
    }

    /**
     * Returns true if agreement has items that are returned but not paid.
     * @return true if agreement has items that are returned but not paid.
     */
    public boolean hasItemsThatAreReturnedButNotPaid() {
        return new AgreementItemCollection(items).hasItemsThatAreReturnedButNotPaid();
    }

    /**
     * Returns true if agreement has atleast one item.
     * @return true if agreement has atlest one item.
     */
    public boolean hasItems() {
        return !items.isEmpty();
    }

    /**
     * Returns true if agreement has no total additional charge.
     * @return boolean value indicating that there is no additional charge.
     */
    public boolean isNoTotalAdditionalChargeApplicable() {
        final double chargeAmount = getTotalAdditionalChargeAmount().doubleValue();
        return ((Constants.Calculation.LOWER_ZERO_VALUE < chargeAmount)
                && (chargeAmount < Constants.Calculation.HIGHER_ZERO_VALUE));
    }

    /**
     * The method that returns true if the agreement is in paid in any state.
     * @return true if agreement is either completed or if its active and there are no additional charges applicable.
     */
    public boolean isAgreementPaidInAnyState() {
        return isCompleted() || (isActive() && isNoTotalAdditionalChargeApplicable());
    }

    /**
     * Returns the created by team member name from the store user info.
     * @return the name of the team member who created the agreement.
     */
    public String getCreatedByTeamMemberName() {
        if (null != storeUser) {
            return storeUser.getName();
        }
        return String.valueOf(createdByTeamMemberNumber);
	}

	/**
     * Returns the list of agreements who have items that where checkedout before the given time period
     * but have not been paid for. 
     * @param threshold the time period before which the items should be checked out.
     * @return list of matching agreements.
     */
    public static List<Agreement> findAllPendingAgreementsOlderThan(final Calendar threshold) {
        return findAgreementsByAgreementStatusAndLastUpdateDateLessThan(AgreementStatus.findPending(),
                threshold).getResultList();
    }

    /**
     * Returns the upcoming due by date from the list of items held by this agreement.
     * @return the upcoming due by date.
     */
    public Calendar getUpcomingDueBy() {
        return new AgreementItemCollection(items).getUpcomingDueBy();
    }

    /**
     * Should update the last updated date.  This method is called whenever the agreement is updated or persisted.
     * we simply set the last updated date value to the current date when this happens.
     */
    @PrePersist
    @PreUpdate
    public void updateLastUpdatedDate() {
        lastUpdateDate = Calendar.getInstance();
    }

    /**
     * Getter for the store number.
     * @return the store number value.
     */
    public Integer getStoreNumber() {
        return getStore().getStoreNumber();
    }

    /**
     * Appends to the overall comment.
     * @param comment the comment to append to the overall comment.
     */
    public void appendComment(final String comment) {
        if (null == overallComment) {
            overallComment = Constants.Action.EMPTY_STRING;
        }
        overallComment += comment;
    }

    /**
     * Checks if is transient.
     *
     * @return true, if is transient.
     */
    public boolean isTransient() {
        return (null == getId());
    }

    /**
     * Copies the transient information from the other agreement reference.
     * @param other the other agreement reference from which we have to copy the transient information.
     */
    public void copyTransientInformationFrom(final Agreement other) {
        getGuest().copyTransientInformationFrom(other.getGuest());
    }


    /**
     * The getter for the agreement update notifier.
     * @return the AgreementUpdateNotifier value.
     */
    public AgreementUpdateNotifier getAgreementUpdateNotifier() {
        if (null == agreementUpdateNotifier) {
            agreementUpdateNotifier = new Agreement().agreementUpdateNotifier;
        }
        return agreementUpdateNotifier;
    }

    /**
     * Returns the formatted last update date.
     * @return the formatted last update date.
     */
    public String getFormattedLastUpdateDate() {
        return new SimpleDateFormat(Constants.DateFormat.DATE_FORMAT).format(lastUpdateDate.getTime());
    }

    /**
     * Returns the full transaction identifier.
     * @return the String value representing the transaction identifier.  Its a combination of Store number,
     * month, day, year, register number and transaction number values.
     */
    public String getFullTransactionIdentifier() {
        return String.format("%04d%02d%02d%02d%02d%04d", new Integer(store.getStoreNumber()),
                initialPaidDate.get(Calendar.MONTH) + 1,
                initialPaidDate.get(Calendar.DATE),
                new Integer(String.valueOf(initialPaidDate.get(Calendar.YEAR)).substring(2)),
                new Integer(registerNumber), new Integer(transactionNumber));
    }

    /**
     * Returns the full transaction identifier space seperated.
     * @return the String value representing the transaction identifier.  Its a combination of Store number,
     * month, day, year, register number and transaction number values.
     */
    public String getFullTransactionIdentifierSpaceSeperated() {
        return String.format("%04d %02d %02d %02d %02d %04d", new Integer(store.getStoreNumber()),
                initialPaidDate.get(Calendar.MONTH) + 1,
                initialPaidDate.get(Calendar.DATE),
                new Integer(String.valueOf(initialPaidDate.get(Calendar.YEAR)).substring(2)),
                new Integer(registerNumber), new Integer(transactionNumber));
    }

    /**
     * Returns the formatted initial Paid date for the use of gui.
     * @return the string representing the formatted paid date.
     */
    public String getFormattedInitialPaidDate() {
        return String.format("%1$s %2$s %3$s", initialPaidDate.get(Calendar.MONTH) + 1,
                initialPaidDate.get(Calendar.DATE), String.valueOf(initialPaidDate.get(Calendar.YEAR)).substring(2));
    }


    /**
     * Returns the list of currently checkedin items.
     * @return the list of currently checkedin items.
     */
    public AgreementItemCollection getCurrentlyCheckedInItems() {
        return new AgreementItemCollection(items).getCurrentlyCheckedInItems();
    }

    /**
     * Removes the item.
     *
     * @param item the item
     * @return the agreement item
     */
    private AgreementItem removeItem(final AgreementItem item) {
        new AgreementItemCollection(items).remove(item);
        itemList.clear();
        return item;
    }

    /**
     * Sets the item list.
     *
     * @param itemList the new item list
     */
    private void setItemList(final List<AgreementItem> itemList) {
        this.itemList = itemList;
    }

	public Integer getCheckinTeamMember() {
		return checkinTeamMember;
	}

	public void setCheckinTeamMember(Integer checkinTeamMember) {
		this.checkinTeamMember = checkinTeamMember;
	}
    public void updateDueByDate(final Calendar transactionDate) {
        new AgreementItemCollection(items).updateDueByDate(transactionDate);
    }

	public AgreementLog getAgreementLog() {
		return agreementLog;
	}

	public void setAgreementLog(AgreementLog agreementLog) {
		this.agreementLog = agreementLog;
	}

}
