/**
 * ArchivedAgreementData.java
 */
package com.menards.rental.domain;

import org.hibernate.annotations.Proxy;

import javax.persistence.*;

/**
 * The class that represents the agreement archive data.
 *
 * @author deep
 */
@Entity
@Table(name = "archived_agreement_data")
@Proxy(lazy = false)
public class ArchivedAgreementData {

    /** The id of the archived agreement data. */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "archived_agreement_data_id")
    private Long id;

    /** The archived agreement id. */
    @Column(name = "archived_agreement_id")
    private Long archivedAgreementId;

    /** The data. */
    @Lob
    @Column(name = "archived_data")
    private byte[] data;

    /**
     * The constructor that takes archived agreement id and data as arguments.
     * @param archivedAgreementId the archived agreement id.
     * @param data the archived data.
     */
    public ArchivedAgreementData(final Long archivedAgreementId, final byte[] data) {
        this.archivedAgreementId = archivedAgreementId;
        this.data = data;
    }

    /**
     * The default constructor.
     */
    public ArchivedAgreementData() {
        this(null, null);
    }

    /**
     * The getter for the data.
     * @return the data value.
     */
    public byte[] getData() {
        return data;
    }

    /**
     * The setter for the data.
     * @param data the value to set.
     */
    public void setData(final byte[] data) {
        this.data = data;
    }
}
