/*
 * Address.java
 */
package com.menards.rental.domain;

import org.apache.commons.lang.StringEscapeUtils;

import java.io.Serializable;

import javax.persistence.Embeddable;

/**
 * The address class.
 * @author deep
 */
@Embeddable
public class Address implements Serializable {

	/** The line. */
	private String line;

	/** The city. */
	private String city;

	/** The state. */
	private String state;

	/** The zip code. */
	private String zipCode;

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCityEscaped() {
		return StringEscapeUtils.escapeHtml(city);
	}

	/**
	 * Gets the city state zip.
	 *
	 * @return the city state zip
	 */
	public String getCityStateZip() {
		return String.format("%s, %s %s", city, state, zipCode);
	}

	/**
	 * Gets the city state zip.
	 *
	 * @return the city state zip
	 */
	public String getCityStateZipEscaped() {
		return StringEscapeUtils.escapeHtml(String.format("%s, %s %s", city, state, zipCode));
	}

	/**
	 * Gets the line.
	 *
	 * @return the line
	 */
	public String getLine() {
		return line;
	}

	/**
	 * Gets the line.
	 *
	 * @return the line
	 */
	public String getLineEscaped() {
		return StringEscapeUtils.escapeHtml(line);
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * Gets the zip code.
	 *
	 * @return the zip code
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * Sets the city.
	 *
	 * @param city the new city
	 */
	public void setCity(final String city) {
		this.city = city;
	}

	/**
	 * Sets the line.
	 *
	 * @param line the new line
	 */
	public void setLine(final String line) {
		this.line = line;
	}

	/**
	 * Sets the state.
	 *
	 * @param state the new state
	 */
	public void setState(final String state) {
		this.state = state;
	}

	/**
	 * Sets the zip code.
	 *
	 * @param zipCode the new zip code
	 */
	public void setZipCode(final String zipCode) {
		this.zipCode = zipCode;
	}
	
    /**
     * The method that returns true if the guest address has a valid zip code.
     * @return true if guest address holds valid zipcode, false otherwise.
     */
    public boolean hasValidZipCode() {
        try {
            Long.parseLong(this.zipCode);
            return true;
        } catch (final Exception e) {
            return false;
        }
    }
    
    
}
