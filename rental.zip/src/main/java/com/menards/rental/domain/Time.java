/*
 * Time.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.util.Calendar;

import com.menards.rental.utils.Constants;

/**
 * The class that represents the time that is a combination of hour and minutes.
 * @author deep
 */
public class Time implements Serializable {

	/** The hour. */
	private Integer hour;

	/** The minutes. */
	private Integer minutes;

	/**
	 * Instantiates a new time.
	 *
	 * @param value the value
	 */
	public Time(final String value) {
		hour = Integer.parseInt(value.substring(0, 2));
		minutes = Integer.parseInt(value.substring(3, 5));
	}

	/**
	 * Calculate difference in hours.
	 *
	 * @param calendar the calendar
	 * @return the double
	 */
	public double calculateDifferenceInHours(final Calendar calendar) {
		final Calendar dateForCalculation = Calendar.getInstance();
		dateForCalculation.setTime(calendar.getTime());
		dateForCalculation.set(Calendar.HOUR_OF_DAY, getHour());
		dateForCalculation.set(Calendar.MINUTE, getMinutes());
		
		Calendar lower = calendar;
		if (dateForCalculation.before(calendar)) {
			lower = dateForCalculation;
		}

		Calendar upper = dateForCalculation;
		if (dateForCalculation.before(calendar)) {
			upper = calendar;
		}
		
		
		return new DateRange(lower, upper).getTotalDurationInHours();
	}

	/**
	 * Gets the hour.
	 *
	 * @return the hour
	 */
	public int getHour() {
		return hour;
	}

	/**
	 * Gets the minutes.
	 *
	 * @return the minutes
	 */
	public int getMinutes() {
		return minutes;
	}

	/**
	 * Gets the time in hours for24 hour clock.
	 *
	 * @return the time in hours for24 hour clock
	 */
	public double getTimeInHoursFor24HourClock() {
		return hour + ((minutes + 0.0) / Constants.Calculation.MINUTES_IN_AN_HOUR);
	}

}
