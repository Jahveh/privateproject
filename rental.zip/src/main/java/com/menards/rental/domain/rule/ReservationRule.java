/*
 * ReservationRule.java
 */
package com.menards.rental.domain.rule;

import java.util.Calendar;

import com.menards.rental.domain.Item;

/**
 * Interface to implement for creating business rules on what is allowed to be
 * reserved.
 * @author deep
 */
public interface ReservationRule {

	/**
	 * Checks if the current item can be reserved.
	 * 
	 * @param item
	 *            The item to check for reservation
	 * @param outDate
	 *            The checkout date desired.
	 * @param inDate
	 *            The checkin date desired.
	 * @return True if this item can be reserved.
	 */
	boolean hasNoConflictingReservation(Item item, Calendar outDate, Calendar inDate);
}
