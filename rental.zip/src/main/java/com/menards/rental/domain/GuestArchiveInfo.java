package com.menards.rental.domain;

import com.menards.rental.decoder.SignatureDecoder;
import com.menards.rental.utils.Constants;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * The class that holds information about the guest archived signature.
 *
 * @author deep
 */
public class GuestArchiveInfo {

    /** The agreement number. */
    private String agreementNumber;

    /** The time when the guest signed the agreement. */
    private Calendar calendar;

    /** The store reference. */
    private Store store;

    /** The signature lable. */
    private String signatureForRentalAgreementLabel;

    /** The legal text to append. */
    private String legalText;

    /** The string representation of the encoded signature. */
    private String encodedSignature;

    /** The signature data reference. */
    private byte[] signatureData;

    /**
     * The guest archive info constructor with all the required parameters.
     * @param agreementNumber the agreement number associated with the archive.
     * @param calendar the calendar reference when the guest has signed the agreement.
     * @param store the store for which the archive is to be updated.
     * @param signatureForRentalAgreementLabel the label for the guest signature.
     * @param legalText the legal text to be appended at the footer.
     * @param encodedSignature the encoded signature of the guest
     */
    public GuestArchiveInfo(final String agreementNumber,
                            final Calendar calendar,
                            final Store store,
                            final String signatureForRentalAgreementLabel,
                            final String legalText, final String encodedSignature) {
        this.agreementNumber = agreementNumber;
        this.calendar = calendar;
        this.store = store;
        this.signatureForRentalAgreementLabel = signatureForRentalAgreementLabel;
        this.legalText = legalText;
        this.encodedSignature = encodedSignature;
    }

    /**
     * The agreement number getter.
     * @return the value to return.
     */
    public String getAgreementNumber() {
        return agreementNumber;
    }

    /**
     * The getter for the calendar when guest signed the agreement.
     * @return the value held.
     */
    public Calendar getCalendar() {
        return calendar;
    }

    /**
     * The getter for the store.
     * @return the store value.
     */
    public Store getStore() {
        return store;
    }

    /**
     * The getter for the signature label.
     * @return the value to return.
     */
    public String getSignatureForRentalAgreementLabel() {
        return signatureForRentalAgreementLabel;
    }

    /**
     * The getter for the legal text.
     * @return the value.
     */
    public String getLegalText() {
        return legalText;
    }

    /**
     * The getter for the signature data.  We are assuming that the encoded signature will be in base 64 encoding.
     * @return the signature data.
     */
    public byte[] getSignatureData() {
        if (null != signatureData) {
            return signatureData;
        }
        if(null == encodedSignature || "".equals(encodedSignature)) {
            return null;
        }
        signatureData = new SignatureDecoder(encodedSignature).decode();
        return signatureData;
    }

    /**
     * Returns the line 1 of the store.
     * @return the line 1 of the store.
     */
    public String getStoreLine1() {
        return "MENARDS - " + store.getStoreNumber() + " - " + store.getStoreAbbreviation();
    }

    /**
     * Returns the line2 of the store.
     * @return the line2 of the store.
     */
    public String getStoreLine2() {
        return new SimpleDateFormat(Constants.DateFormat.DATE_FORMAT).format(calendar.getTime()) + "       STORE "
                + store.getStoreNumber() + "       "
                + new SimpleDateFormat(Constants.DateFormat.TIME_FORMAT).format(calendar.getTime());
    }

    /**
     * The getter for the signature line.
     * @return the String value representing the signature line.
     */
    public String getSignatureLine() {
        return signatureForRentalAgreementLabel + " " + agreementNumber;
    }
}
