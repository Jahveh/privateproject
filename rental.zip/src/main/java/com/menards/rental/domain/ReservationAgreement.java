/*
 * ReservationAgreement.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.*;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.hibernate.annotations.*;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

/**
 * The reservation agreement class.
 * @author deep
 */
@Entity
@Table(name = "reservation_agreement")
@RooEntity(identifierColumn = "reservation_agreement_id", finders = "findReservationAgreementsByStatusAndStore")
@RooJavaBean
public class ReservationAgreement implements Serializable {

	/** The guest. */
	@OneToOne(targetEntity = Guest.class, optional = true, cascade = CascadeType.ALL)
	@JoinColumn(name = "guest_id", nullable = true)
	private Guest guest;

	/** The reservations. */
	@OneToMany(targetEntity = Reservation.class, cascade = CascadeType.ALL, mappedBy = "agreement")
    @Cascade(value = org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<Reservation> reservations = new HashSet<Reservation>();

	/** The store. */
	@Embedded
	private Store store;

	/** The status. */
	@ManyToOne(targetEntity = ReservationAgreementStatus.class, fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "reservation_agreement_status_id")
	private ReservationAgreementStatus status;

	/** The overall comment. */
	@Column(name = "note_txt")
	private String overallComment;

	/** The created by team member name. */
	@Column(name = "enter_by_tm_number")
	private Integer createdByTeamMemberNumber;

	/** The created by team member name. */
	@Column(name = "enter_by_tm_name")
	private String createdByTeamMemberName;

	/** The reservation list. */
	@Transient
	private List<Reservation> reservationList = LazyList.decorate(new ArrayList<Reservation>(), FactoryUtils
	        .instantiateFactory(Reservation.class));

    /**
	 * Find open reservation agreements by store.
	 *
	 * @param store the store
	 * @return the list
	 */
	public static List<ReservationAgreement> findAllOpenReservationAgreementsByStore(final Store store) {
        EntityManager em = entityManager();
        Query query = em.createQuery("SELECT ReservationAgreement FROM ReservationAgreement AS reservationagreement " +
               "WHERE reservationagreement.status = :status AND reservationagreement.store.storeNumber = :storeNumber");
        query.setParameter("status", ReservationAgreementStatus.findOpen());
        query.setParameter("storeNumber", store.getStoreNumber());
		return query.getResultList();
	}

	/**
	 * Load full.
	 *
	 * @param id the id.
	 * @return the reservation agreement.
	 */
	public static ReservationAgreement loadFull(final Long id) {
		return (ReservationAgreement) entityManager().createQuery(
		        "select a from ReservationAgreement a left join fetch a.reservations r "
		                + "left join fetch a.guest g left join fetch a.status st "
		                + "left join fetch r.product p left join fetch r.status rst "
		                + "left join fetch p.skuInfo.baseSKU b where a.id=:agreementId")
                .setParameter("agreementId", id)
		        .getSingleResult();
	}

	/**
	 * Adds the reservation.
	 *
	 * @param reservation the reservation
	 */
	public void addReservation(final Reservation reservation) {
		getReservations().add(reservation);
		reservation.setAgreement(this);
	}

	/**
	 * Cancel.
	 */
	public void cancel() {
		setStatus(ReservationAgreementStatus.findCancelled());
		new ReservationCollection(reservations).cancel();
		merge();
	}

	/**
	 * Find reservation by id.
	 *
	 * @param reservationId the reservation id
	 * @return the reservation
	 */
	public Reservation findReservationById(final Long reservationId) {
		return new ReservationCollection(reservations).findReservationById(reservationId);
	}

	/**
	 * Fulfill if all reservations fulfilled or cancelled.
	 */
	public void fulfillIfAllReservationsFulfilledOrCancelled() {
		if (new ReservationCollection(reservations).isAnyReservationOpen()) {
			return;
		}

		setStatus(ReservationAgreementStatus.findFulfilled());
	}

    /**
     * Gets the not null guest.  This method will always return a not null value.  If the guest held by the object is
     * null this method returns a new instance of guest object.  If the object holds a valid instance of guest then
     * this method returns that instance.
     *
     * @return the not null guest.  Always a valid guest instance.
     */
	public Guest getGuest() {
        if (null == guest) {
            guest = new Guest();
        }
        return guest;
	}

	/**
	 * Gets the reservation for.
	 *
	 * @param productId the product id
	 * @return the reservation for
	 */
	public Reservation getReservationFor(final long productId) {
		return new ReservationCollection(reservations).getReservationFor(productId);
	}

	/**
	 * Gets the reservation list.
	 *
	 * @return the reservation list
	 */
	public List<Reservation> getReservationList() {
		if (reservationList.isEmpty()) {
			reservationList.addAll(reservations);
		}
		return reservationList;
	}

	/**
	 * Gets the store number.
	 *
	 * @return the store number
	 */
	public Integer getStoreNumber() {
		return store.getStoreNumber();
	}

	/**
	 * Returns the damage waiver applied to all reservations.
	 *
	 * @return the damage waiver total
	 */
	public BigDecimal getTotalDamageWaiver() {
        return new ReservationCollection(reservations).getTotalDamageWaiver();
	}

	/**
	 * Returns the total charge amout for all reservations.
	 *
	 * @return the sub total
	 */
	public BigDecimal getTotalEstimatedChargeAmount() {
        return new ReservationCollection(reservations).getTotalEstimatedChargeAmount();
	}

	/**
	 * Returns the total charge amount including damage waiver.
	 *
	 * @return the estimated total
	 */
	public BigDecimal getTotalEstimatedPlusDamageWaiverChargeAmount() {
        return this.getTotalEstimatedChargeAmount().add(getTotalDamageWaiver());

	}

	/**
	 * Checks for reservations.
	 *
	 * @return true, if successful
	 */
	public boolean hasReservations() {
		return (!reservations.isEmpty());
	}

	/**
	 * Checks if is for store.
	 *
	 * @param storeNumber the store number
	 * @return true, if is for store
	 */
	public boolean isForStore(final Integer storeNumber) {
		return store.isMatching(storeNumber);
	}

	/**
	 * Checks if is reservation Present for.
	 *
	 * @param product the product
	 * @return true, if is reservation present for
	 */
	public boolean isReservationPresentFor(final Product product) {
		return new ReservationCollection(reservations).isReservationPresentFor(product);
	}

	/**
	 * Checks if is transient.
	 *
	 * @return true, if is transient
	 */
	public boolean isTransient() {
		return null == getId();
	}

	/**
	 * Removes the reservation for.
	 *
	 * @param productId the product id
	 */
	public void removeReservationFor(final long productId) {
		new ReservationCollection(reservations).removeReservationFor(productId);
	}

	/**
	 * Sets the guest.
	 *
	 * @param guest the new guest
	 */
	public void setGuest(final Guest guest) {
		this.guest = guest;
	}

    /**
	 * Sets the reservation list.
	 *
	 * @param reservationList the new reservation list
	 */
	public void setReservationList(final List<Reservation> reservationList) {
		this.reservationList = reservationList;
	}

    /**
     * Removes the reservation from the reservation agreement.
     * @param reservation the reservation to remove.
     */
    public void removeReservation(final Reservation reservation) {
        if (reservation != null) {
            reservations.remove(reservation);
            reservation.setAgreement(null);
        }
    }

    /**
     * The setter for the store user.
     * @param storeUser the value to set.
     */
    public void setStoreUser(final StoreUserInfo storeUser) {
        setCreatedByTeamMemberName(String.valueOf(getCreatedByTeamMemberNumber()));
        if (null != storeUser) {
            setCreatedByTeamMemberName(storeUser.getName());
        }
    }

	/**
 	 * Returns list of open reservation agreements that have no open reservations.
     * @return List of reservation agreements that do not have any open reservations.
     */
    public static List<ReservationAgreement> findAllOpenReservationAgreementsThatHaveNoOpenReservation() {
        final Query query = entityManager()
                .createQuery("select ra from ReservationAgreement ra where ra.status = :openStatus "
                      + "and :openReservationStatus <> all(select r.status from Reservation r where r.agreement = ra)");
        query.setParameter("openStatus", ReservationAgreementStatus.findOpen());
        query.setParameter("openReservationStatus", ReservationStatus.findOpen());
        return query.getResultList();
    }

    /**
     * The method that returns true if the guest age is greater than minimum rental age required by all the rentals
     * selected by guest.
     * @return true if guest meets the criteria, false otherwise.
     */
    public boolean isGuestAgeGreaterThanMinimumAge() {
        return new ReservationCollection(reservations).isGuestAgeGreaterThanMinimumAge(getGuest());
    }
}
