/*
 * Vehicle.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

/**
 * The Class Vehicle.
 */
@Entity
@RooJavaBean
@RooEntity(identifierColumn = "vehicle_id")
@Table(name = "vehicle")
public class Vehicle implements Serializable {

	/** The license plate val. */
	@Column(name = "license_plate_val", length = 15)
	private String licensePlateVal;

	/** The license plate state cd. */
	@Column(name = "license_plate_state_cd")
	private String licensePlateStateCd;

	/** The vehicle make name. */
	@Column(name = "vehicle_make_name", length = 20)
	private String vehicleMakeName;

	/** The vehicle model name. */
	@Column(name = "vehicle_model_name", length = 20)
	private String vehicleModelName;

	/** The fleet nbr. */
	@Column(name = "fleet_nbr")
	private Integer fleetNbr;

	/** The item. */
	@OneToOne(targetEntity = Item.class, optional = false)
	@JoinColumn(name = "item_id", unique = true)
	private Item item;

	/** The rental details. */
	@OneToMany(targetEntity = VehicleRentalDetail.class, 
			mappedBy = "vehicle", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<VehicleRentalDetail> rentalDetails = new HashSet<VehicleRentalDetail>();

}
