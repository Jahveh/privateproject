/*
 * SKU.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

/**
 * The Class SKU.
 */
@Entity
@RooJavaBean
@Table(name = "rental_sku")
@RooEntity(identifierColumn = "sku_id", finders = { "findRentalSKUsByType", "findRentalSKUsByValue" })
public class RentalSKU implements Serializable {

	/**
	 * The Enum Type.
	 */
	public enum Type {

		/** The BASE. */
		BASE,

        /** The ADDITIONAL. */
		ADDITIONAL,

        /** The SELLING. */
		SELLING,

        /** The SURCHARGE. */
		SURCHARGE;

		/**
		 * Matches.
		 *
		 * @param type the type
		 * @return true, if successful
		 */
		public boolean matches(final String type) {
			return this.toString().equals(type);
		}
	}

    /** The value. */
	@Column(name = "sku", unique = true, nullable = false, updatable = false)
	private Long value;

	/** The description. */
	@Column(name = "rental_sku_desc")
	private String description;

    /** The type. */
	@Column(name = "keyword_name")
	private String type;

	/**
	 * Instantiates a new sKU.
	 */
	public RentalSKU() {
	}

	/**
	 * Instantiates a new sKU.
	 *
	 * @param type the type
	 * @param price the price
	 * @param value the value
	 */
	public RentalSKU(final String type, final BigDecimal price, final long value) {
		this.type = type;
        this.value = value;
	}

	/**
	 * Find all skus ordered by type and value.
	 *
	 * @return the list
	 */
	public static List<RentalSKU> findAllSKUSOrderedByTypeAndValue() {
		return entityManager().createQuery("select o from RentalSKU o order by o.type, o.value").getResultList();
	}

	/**
	 * Find sku by value.
	 *
	 * @param value the value
	 * @return the sKU
     * @throws IllegalStateException when more than one sku is found for the given value.  This means the setup of the
     * datebase is not correct.  This should never happen.
	 */
	public static RentalSKU findSKUByValue(final long value) {
		final Query query = findRentalSKUsByValue(value);

		final List<RentalSKU> skuList = query.getResultList();

		if ((null == skuList) || (skuList.isEmpty())) {
			return null;
		}

		// The size of the list should never be more than 1
		// otherwise throw an exception
		if (skuList.size() > 1) {
			throw new IllegalStateException("More than one sku available for sku number " + value);
		}

        return skuList.get(0);
	}

	/**
	 * Gets the formatted value.
	 *
	 * @return the formatted value
	 */
	public String getFormattedValue() {
		return MessageFormat.format("{0}-{1}", String.valueOf(getValue()).substring(0, 3), String.valueOf(getValue())
		        .substring(3));
	}

	/**
	 * Gets the info.
	 *
	 * @return the info
	 */
	public String getInfo() {
		return MessageFormat.format("{0}: {1}", getFormattedValue(), getDescription());
	}

	/**
	 * Matches.
	 *
	 * @param type the type
	 * @return true, if successful
	 */
	public boolean matches(final Type type) {
		return type.matches(this.type);
	}

    /**
     * Returns the escaped value of the description.
     * @return the escaped value of the description.
     */
    public String getDescriptionEscaped() {
        return StringEscapeUtils.escapeHtml(description);
    }
}
