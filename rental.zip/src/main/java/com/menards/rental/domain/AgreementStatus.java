/*
 * AgreementStatus.java
 */
package com.menards.rental.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

/**
 * The Class AgreementStatus.
 * @author deep
 */
@Entity
@RooJavaBean
@Table(name = "rental_status")
@RooEntity(identifierColumn = "rental_status_id", finders = { "findAgreementStatusesByStatusCode" })
public class AgreementStatus implements Serializable {

	/**
	 * The Enum Code.
	 */
	public enum Code {

		/** The PENDING. */
		PENDING('P'),

        /** The ACTIVE. */
		ACTIVE('A'),

        /** The COMPLETED. */
		COMPLETED('C'),

        /** The VOIDED. */
		VOIDED('V'),

        /** The CANCELLED. */
		CANCELLED('N');

		/** The code. */
		private char code;

		/**
		 * Instantiates a new code.
		 *
		 * @param code the code
		 */
		Code(final char code) {
			this.code = code;
		}

		/**
		 * Gets the code.
		 *
		 * @return the code
		 */
		public char getCode() {
			return code;
		}

		/**
		 * Matches.
		 *
		 * @param code the code
		 * @return true, if successful
		 */
		public boolean matches(final char code) {
			return code == this.code;
		}
	}

	/** The status code. */
	@Column(name = "rental_status_cd", nullable = false)
	@Size(max = 20)
	private char statusCode;

	/** The description. */
	@Column(name = "rental_status_desc", nullable = false)
	@Size(max = 100)
	private String description;

	/**
	 * Instantiates a new agreement status.
	 */
	public AgreementStatus() {
	}

	/**
	 * Instantiates a new agreement status.
	 *
	 * @param statusCode the status code
	 */
	public AgreementStatus(final char statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * Find active.
	 *
	 * @return the agreement status
	 */
	public static AgreementStatus findActive() {
		return findItemStatusByStatusCode(Code.ACTIVE);
	}

	/**
	 * Find cancelled.
	 *
	 * @return the agreement status
	 */
	public static AgreementStatus findCancelled() {
		return findItemStatusByStatusCode(Code.CANCELLED);
	}

	/**
	 * Find completed.
	 *
	 * @return the agreement status
	 */
	public static AgreementStatus findCompleted() {
		return findItemStatusByStatusCode(Code.COMPLETED);
	}

	/**
	 * Find pending.
	 *
	 * @return the agreement status
	 */
	public static AgreementStatus findPending() {
		return findItemStatusByStatusCode(Code.PENDING);
	}

	/**
	 * Find voided.
	 *
	 * @return the agreement status
	 */
	public static AgreementStatus findVoided() {
		return findItemStatusByStatusCode(Code.VOIDED);
	}

	/**
	 * Find item status by status code.
	 *
	 * @param code the code
	 * @return the agreement status
	 */
	private static AgreementStatus findItemStatusByStatusCode(final Code code) {
		return (AgreementStatus) findAgreementStatusesByStatusCode(code.getCode()).getSingleResult();
	}

	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return (Code.ACTIVE.matches(statusCode));
	}

	/**
	 * Checks if is cancelled.
	 *
	 * @return true, if is cancelled
	 */
	public boolean isCancelled() {
		return (Code.CANCELLED.matches(statusCode));
	}

	/**
	 * Checks if is completed.
	 *
	 * @return true, if is completed
	 */
	public boolean isCompleted() {
		return (Code.COMPLETED.matches(statusCode));
	}

	/**
	 * Checks if is pending.
	 *
	 * @return true, if is pending
	 */
	public boolean isPending() {
		return (Code.PENDING.matches(statusCode));
	}

	/**
	 * Checks if is voided.
	 *
	 * @return true, if is voided
	 */
	public boolean isVoided() {
		return (Code.VOIDED.matches(statusCode));
	}

    /**
     * {@inheritDoc}
     */
	@Override
	public String toString() {
		return String.valueOf(statusCode);
	}
}
