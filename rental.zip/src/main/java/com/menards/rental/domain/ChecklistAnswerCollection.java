/*
 * ChecklistAnswers.java
 */
package com.menards.rental.domain;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;

/**
 * The class that represents a collection of checklist answers.
 * @author deep
 */
public class ChecklistAnswerCollection extends CollectionUtil<ChecklistAnswer> {

	/**
	 * Instantiates a new checklist answers.
	 *
	 * @param answers the answers
	 */
	public ChecklistAnswerCollection(final Collection<ChecklistAnswer> answers) {
		super(answers);
	}

	/**
	 * Creates the empty answers.  This method iterates over the list of questions and creates that many empty answers.
	 *
	 * @param questions the questions for which we need the answers.
	 * @param agreementItem the agreement item.
	 */
	public void createEmptyAnswers(final List<Question> questions, final AgreementItem agreementItem) {
		new CollectionUtil<Question>(questions).doInLoop(new ExpressionEvaluator<Question>() {

			public void evaluate(final Question entity) {
                /*
                We iterate over the questions and add an empty ChecklistAnswer for each question available in the db.
                The below syntax is adding a checklist answer to the collection held by this collection class.
                 */
				ChecklistAnswerCollection.this.add(new ChecklistAnswer(agreementItem, entity));
			}
		});
	}

	/**
	 * Gets the total charge amount.
	 *
	 * @return the total charge amount
	 */
	public BigDecimal getTotalChargeAmount() {
		BigDecimal totalCharge = new BigDecimal("0");
		for (final ChecklistAnswer answer : getEntities()) {
			totalCharge = totalCharge.add(answer.getChargeAmount());
		}
		return totalCharge;
	}
}
