/*
 * AgreementItemOverride.java
 */
package com.menards.rental.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Type;
import org.springframework.roo.addon.javabean.RooJavaBean;

/**
 * The Class AgreementItemOverride.
 *
 * @author geoff
 * @since Jun 14, 2010
 */
@Embeddable
@RooJavaBean
public class AgreementItemOverride implements Serializable {

	/** The has quantity override. */
	@Column(name = "qty_override_flg")
	@Type(type = "yes_no")
	private Boolean hasQuantityOverride = false;

	/** The quantity override by name. */
	@Column(name = "qty_override_by_number")
	private Integer quantityOverrideByNumber;

	/** The quantity override reason. */
	@ManyToOne(targetEntity = OverrideReason.class, 
			fetch = FetchType.EAGER, optional = true, cascade = { CascadeType.REFRESH })
	@JoinColumn(name = "in_override_cd")
	private OverrideReason quantityOverrideReason;

	/** The quantity override comment. */
	@Column(name = "qty_override_comment")
	private String quantityOverrideComment;

	/** The has price override. */
	@Column(name = "price_override_flg")
	@Type(type = "yes_no")
	private Boolean hasPriceOverride = false;

	/** The price override by name. */
	@Column(name = "price_override_by_number")
	private Integer priceOverrideByNumber;

	/** The price override comment. */
	@Column(name = "price_override_comment")
	private String priceOverrideComment;

	/** The price override reason. */
	@ManyToOne(targetEntity = OverrideReason.class, 
			fetch = FetchType.EAGER, optional = true, cascade = { CascadeType.REFRESH })
	@JoinColumn(name = "out_override_cd")
	private OverrideReason priceOverrideReason;

	/** The reservation override by name. */
	@Column(name = "reservation_override_by_number")
	private Integer reservationOverrideByNumber;

	/**
	 * Gets the checks for reservation override.
	 *
	 * @return the checks for reservation override
	 */
	public boolean getHasReservationOverride() {
		return (null != getReservationOverrideByNumber());
	}

	/**
	 * Gets the not null price override reason.
	 *
	 * @return the not null price override reason
	 */
	public OverrideReason getNotNullPriceOverrideReason() {
		if (null != getPriceOverrideReason()) {
			return getPriceOverrideReason();
		}
		setPriceOverrideReason(new OverrideReason());
		return getPriceOverrideReason();
	}

	/**
	 * Gets the not null quantity override reason.
	 *
	 * @return the not null quantity override reason
	 */
	public OverrideReason getNotNullQuantityOverrideReason() {
		if (null != getQuantityOverrideReason()) {
			return getQuantityOverrideReason();
		}
		setQuantityOverrideReason(new OverrideReason());
		return getQuantityOverrideReason();
	}

	/**
	 * Sets the not null price override reason.
	 *
	 * @param priceOverrideReason the new not null price override reason
	 */
	public void setNotNullPriceOverrideReason(final OverrideReason priceOverrideReason) {
		setPriceOverrideReason(priceOverrideReason);
	}

	/**
	 * Sets the not null quantity override reason.
	 *
	 * @param quantityOverrideReason the new not null quantity override reason
	 */
	public void setNotNullQuantityOverrideReason(final OverrideReason quantityOverrideReason) {
		setQuantityOverrideReason(quantityOverrideReason);
	}

	/**
	 * Sets the price override reason.
	 *
	 * @param priceOverrideReason the new price override reason
	 */
	public void setPriceOverrideReason(final OverrideReason priceOverrideReason) {
		this.hasPriceOverride = (null != priceOverrideReason);
		this.priceOverrideReason = priceOverrideReason;
	}

	/**
	 * Sets the quantity override reason.
	 *
	 * @param quantityOverrideReason the new quantity override reason
	 */
	public void setQuantityOverrideReason(final OverrideReason quantityOverrideReason) {
		this.hasQuantityOverride = (null != quantityOverrideReason);
		this.quantityOverrideReason = quantityOverrideReason;
	}

	/**
	 * Sets the reservation override by name.
	 *
	 * @param reservationOverrideByNumber the new reservation override by name
	 */
	public void setReservationOverrideByName(final Integer reservationOverrideByNumber) {
		this.reservationOverrideByNumber = reservationOverrideByNumber;
	}

	/**
	 * Update override reason.
	 */
	public void updateOverrideReason() {
		updatePriceOverrideReason();
		updateQuantityOverrideReason();
	}

	/**
	 * Update price override reason.
	 */
	private void updatePriceOverrideReason() {
		if ((null == priceOverrideReason) || (null == priceOverrideReason.getId())) {
			setPriceOverrideReason(null);
			setPriceOverrideByNumber(null);
			return;
		}
		setPriceOverrideReason(OverrideReason.findOverrideReason(priceOverrideReason.getId()));
	}

	/**
	 * Update quantity override reason.
	 */
	private void updateQuantityOverrideReason() {
		if ((null == quantityOverrideReason) || (null == quantityOverrideReason.getId())) {
			setQuantityOverrideByNumber(null);
			setQuantityOverrideReason(null);
			return;
		}
		setQuantityOverrideReason(OverrideReason.findOverrideReason(quantityOverrideReason.getId()));
	}
}
