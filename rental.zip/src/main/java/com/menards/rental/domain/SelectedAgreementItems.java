/*
 * SelectedAgreementItems.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;

import javax.persistence.Column;

import org.apache.log4j.Logger;

/**
 * The collection class that represents the collection of selected agreement items for a
 * rental agreement.
 * @author danderson
 */
public class SelectedAgreementItems extends CollectionUtil<AgreementItem> implements Serializable {

    /** The logger. */
    private static final Logger logger = Logger.getLogger(SelectedAgreementItems.class);

	private String overallComment;
	private Calendar dueBy; 
	private Calendar checkoutDate; 
	private AgreementItemOverride override = new AgreementItemOverride();
	private String usageOutNumberList;
	private String usageInNumberList;
	private Integer checkinTeamMember;
	private Calendar checkinDate; 
	private List<ChecklistAnswer> answerList;
	private DamageInfo damageInfo;
	
	/**
	 * Instantiates a new collection of selected agreement items.
	 *
	 * @param agreementItems the selected agreement items
	 */
	public SelectedAgreementItems(final Collection<AgreementItem> agreementItems) {
		super(agreementItems);
	}

	
	public String getOverallComment() {
		return overallComment;
	}

	public void setOverallComment(final String overallComment) {
		this.overallComment = overallComment;
	}


	public Calendar getDueBy() {
		return dueBy;
	}


	public void setDueBy(final Calendar dueBy) {
		this.dueBy = dueBy;
	}


	public AgreementItemOverride getOverride() {
		return override;
	}


	public void setOverride(final AgreementItemOverride override) {
		this.override = override;
	}


	public List<AgreementItem> getAllItems(){
		return (List<AgreementItem>)getEntities();
	}


	public List<AgreementItem> getAllItemsSortedBySKU(){
		List<AgreementItem> resultList = (List<AgreementItem>)getEntities();
		java.util.Collections.sort(resultList);
		return resultList;
	}

	public String getUsageOutNumberList() {
		return usageOutNumberList;
	}


	public void setUsageOutNumberList(final String usageOutNumberList) {
		this.usageOutNumberList = usageOutNumberList;
	}


	public Calendar getCheckoutDate() {
		return checkoutDate;
	}


	public void setCheckoutDate(final Calendar checkoutDate) {
		this.checkoutDate = checkoutDate;
	}


	public Integer getCheckinTeamMember() {
		return checkinTeamMember;
	}


	public void setCheckinTeamMember(final Integer checkinTeamMember) {
		this.checkinTeamMember = checkinTeamMember;
	}


	public String getUsageInNumberList() {
		return usageInNumberList;
	}


	public void setUsageInNumberList(final String usageInNumberList) {
		this.usageInNumberList = usageInNumberList;
	}

	public Calendar getCheckinDate() {
		return checkinDate;
	}


	public void setCheckinDate(final Calendar checkinDate) {
		this.checkinDate = checkinDate;
	}


	public List<ChecklistAnswer> getAnswerList() {
		return answerList;
	}


	public void setAnswerList(final List<ChecklistAnswer> answerList) {
		this.answerList = answerList;
	}

	public void createEmptyAnswersIfRequired(List<Question> questions){
		if( this.getAnswerList() == null || this.getAnswerList().isEmpty() || this.getAnswerList().size() != questions.size() ) {
	        this.setAnswerList(this.getAllItems().get(0).getAnswerList());
	    }
	}

	
	public DamageInfo getDamageInfo() {
		return damageInfo;
	}


	public void setDamageInfo(DamageInfo damageInfo) {
		this.damageInfo = damageInfo;
	}

	/**
	 * Gets the not null damage info.
	 *
	 * @return the not null damage info
	 */
	public DamageInfo getNotNullDamageInfo() {
		if (null == getDamageInfo()) {
			setDamageInfo(new DamageInfo());
		}
		return getDamageInfo();
	}

	/**
	 * Sets the not null damage info.
	 *
	 * @param the not null damage info
	 */
	public void setNotNullDamageInfo(DamageInfo damageInfo) {
		setDamageInfo(damageInfo);
	}

}
