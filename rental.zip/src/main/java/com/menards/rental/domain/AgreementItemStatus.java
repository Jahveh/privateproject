/*
 * AgreementItemStatus.java
 */
package com.menards.rental.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;

/**
 * The Class AgreementItemStatus.
 * @author deep
 */
@Entity
@RooJavaBean
@RooToString
@RooEntity(identifierColumn = "rental_detail_status_id", finders = { "findAgreementItemStatusesByStatusCode" })
@Table(name = "rental_detail_status")
public class AgreementItemStatus implements Serializable {

	/**
	 * The Enum AgreementItemStatusCode.
	 */
	public enum AgreementItemStatusCode {

		/** The CHECKE d_ out. */
		CHECKED_OUT('O'), /** The CHECKE d_ ou t_ an d_ pai d_ initial. */
		CHECKED_OUT_AND_PAID_INITIAL('P'), /** The RETURNED. */
		RETURNED('R'), /** The RETURNE d_ an d_ pai d_ complete. */
		RETURNED_AND_PAID_COMPLETE('C');

		/** The code. */
		private final char code;

		/**
		 * Instantiates a new agreement item status code.
		 *
		 * @param code the code
		 */
		AgreementItemStatusCode(final char code) {
			this.code = code;
		}

		/**
		 * Gets the code.
		 *
		 * @return the code
		 */
		public char getCode() {
			return code;
		}

		/**
		 * Checks if is match.
		 *
		 * @param code the code
		 * @return true, if is match
		 */
		public boolean isMatch(final char code) {
			return code == this.code;
		}
	}

	/** The status code. */
	@Column(name = "rental_detail_status_cd", columnDefinition = "char")
	private char statusCode;

	/** The description. */
	@Column(name = "rental_detail_status_desc", nullable = false)
	@Size(max = 100)
	private String description;

	/**
	 * Find checked out.
	 *
	 * @return the agreement item status
	 */
	public static AgreementItemStatus findCheckedOut() {
		return findAgreementItemStatusByStatusCode(AgreementItemStatusCode.CHECKED_OUT);
	}

	/**
	 * Find checked out and paid initial.
	 *
	 * @return the agreement item status
	 */
	public static AgreementItemStatus findCheckedOutAndPaidInitial() {
		return findAgreementItemStatusByStatusCode(AgreementItemStatusCode.CHECKED_OUT_AND_PAID_INITIAL);
	}

	/**
	 * Find returned.
	 *
	 * @return the agreement item status
	 */
	public static AgreementItemStatus findReturned() {
		return findAgreementItemStatusByStatusCode(AgreementItemStatusCode.RETURNED);
	}

	/**
	 * Find returned and paid complete.
	 *
	 * @return the agreement item status
	 */
	public static AgreementItemStatus findReturnedAndPaidComplete() {
		return findAgreementItemStatusByStatusCode(AgreementItemStatusCode.RETURNED_AND_PAID_COMPLETE);
	}

	/**
	 * Checks if is checked out.
	 *
	 * @return true, if is checked out
	 */
	public boolean isCheckedOut() {
		return AgreementItemStatusCode.CHECKED_OUT.isMatch(this.statusCode);
	}

	/**
	 * Checks if is checked out and paid initial.
	 *
	 * @return true, if is checked out and paid initial
	 */
	public boolean isCheckedOutAndPaidInitial() {
		return AgreementItemStatusCode.CHECKED_OUT_AND_PAID_INITIAL.isMatch(this.statusCode);
	}

	/**
	 * Checks if is returned.
	 *
	 * @return true, if is returned
	 */
	public boolean isReturned() {
		return AgreementItemStatusCode.RETURNED.isMatch(this.statusCode);
	}

	/**
	 * Checks if is returned and paid complete.
	 *
	 * @return true, if is returned and paid complete
	 */
	public boolean isReturnedAndPaidComplete() {
		return AgreementItemStatusCode.RETURNED_AND_PAID_COMPLETE.isMatch(this.statusCode);
	}

    /**
     * Find agreement item status by status code.
     *
     * @param code the code
     * @return the agreement item status
     */
    private static AgreementItemStatus findAgreementItemStatusByStatusCode(final AgreementItemStatusCode code) {
        return (AgreementItemStatus) AgreementItemStatus.findAgreementItemStatusesByStatusCode(code.code)
                .getSingleResult();
    }
}
