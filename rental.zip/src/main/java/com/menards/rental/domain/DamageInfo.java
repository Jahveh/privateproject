/*
 * DamageInfo.java
 */
package com.menards.rental.domain;

import org.apache.commons.lang.StringEscapeUtils;

import java.io.Serializable;

import javax.persistence.Embeddable;

/**
 * The damage info class.
 * @author deep
 */
@Embeddable
public class DamageInfo implements Serializable {

	/** The is excessive damage done. */
	private Boolean isExcessiveDamageDone;

	/** The damage comment. */
	private String damageComment;

	/** The damage approved by. */
	private Integer damageApprovedBy;


	/**
	 * Gets the damage comment.
	 *
	 * @return the damage comment
	 */
	public String getDamageComment() {
		return damageComment;
	}

    /**
     * Returns the damage comment in the escaped html format.
     * @return the damage command in the escaped html format.
     */
    public String getDamageCommentEscaped() {
        return StringEscapeUtils.escapeHtml(damageComment);
    }

	/**
	 * Gets the excessive damage done.
	 *
	 * @return the excessive damage done
	 */
	public Boolean getExcessiveDamageDone() {
		return isExcessiveDamageDone;
	}

	/**
	 * Sets the damage comment.
	 *
	 * @param damageComment the new damage comment
	 */
	public void setDamageComment(final String damageComment) {
		this.damageComment = damageComment;
	}

	/**
	 * Sets the excessive damage done.
	 *
	 * @param excessiveDamageDone the new excessive damage done
	 */
	public void setExcessiveDamageDone(final Boolean excessiveDamageDone) {
		isExcessiveDamageDone = excessiveDamageDone;
	}

    /**
     * The getter for the damage approved by.
     * @return the value.
     */
    public Integer getDamageApprovedBy() {
        return damageApprovedBy;
    }

    /**
     * The setter for the damamge approved by.
     * @param damageApprovedBy the value to set.
     */
    public void setDamageApprovedBy(final Integer damageApprovedBy) {
        this.damageApprovedBy = damageApprovedBy;
    }
}
