/**
 * ArchivedAgreementItem.java
 */
package com.menards.rental.domain;

import javax.persistence.*;

import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
import org.springframework.roo.addon.entity.RooEntity;

/**
 * The domain class that represents the archived agreement item.
 * @author deep
 */
@Entity
@RooJavaBean
@RooToString
@RooEntity(identifierColumn = "archived_rental_detail_id")
@Table(name = "archived_rental_detail")
public class ArchivedAgreementItem {

    /** The agreement. */
    @ManyToOne(targetEntity = ArchivedAgreement.class, fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "archived_agreement_id")
    private ArchivedAgreement agreement;

    /** The item. */
    @ManyToOne(targetEntity = Item.class,
            fetch = FetchType.EAGER, optional = false, cascade = { CascadeType.REFRESH })
    @JoinColumn(name = "item_id")
    private Item item;

}
