/*
 * NumberOfItemsGreaterThanNumberOfOverlappingReservationDurationReservationRule.java
 */
package com.menards.rental.domain.rule;

import java.util.Calendar;
import java.util.List;

import org.springframework.stereotype.Component;

import com.menards.rental.domain.Item;
import com.menards.rental.domain.ItemStatus;

/**
 * Checks if there are more items available in the store than are currently
 * reserved.
 * @author deep
 */
@Component(value = "numberOfItemsGreaterThanNumberOfOverlappingReservationDurationReservationRule")
public class ItemCountGreaterThanOverlapingReservationsRule
                 implements ReservationRule {

    /**
     * {@inheritDoc}
     */
	public boolean hasNoConflictingReservation(final Item item, final Calendar outDate, final Calendar inDate) {
		final List<Item> itemsCurrentlyAvailableInStore = Item.findAllItemsByStoreNumberAndProductAndItemStatus(item
		        .getStoreNumber(), item.getProduct(), ItemStatus.findAvailable());
		return itemsCurrentlyAvailableInStore.size() > item.countActuallyOverlappingReservations(outDate, inDate);
	}
}
