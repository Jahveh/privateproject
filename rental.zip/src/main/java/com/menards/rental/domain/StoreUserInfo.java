/**
 * StoreUserInfo.java
 */
package com.menards.rental.domain;

import java.io.Serializable;

/**
 * The class that represents the store user.
 *
 * @author deep
 */
public class StoreUserInfo implements Serializable {
    /** The user id. */
    private Integer id;

    /** The name of the user. */
    private String name;

    /** The position of this store user. */
    private String position;

    /**
     * The getter for the name.
     * @return the value of the name.
     */
    public String getName() {
        return name;
    }

    /**
     * The setter for the user id.
     * @param id the value.
     */
    public void setId(final Integer id) {
        this.id = id;
    }

    /**
     * The setter for the store user name.
     * @param name the value to set.
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * The setter for the position.
     * @param position the value to set.
     */
    public void setPosition(final String position) {
        this.position = position;
    }

    /**
     * The getter for the position of the current user.
     * @return the position of the user.
     */
    public String getPosition() {
        return position;
    }

    /**
     * The getter for the user id.
     * @return the user id value.
     */
    public Integer getId() {
        return id;
    }
}
