package com.menards.rental.domain.questions;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the question_category database table.
 * 
 */
@Entity
@Table(name="question_category")
@NamedQuery(name="QuestionCategory.findAll", query="SELECT q FROM QuestionCategory q")
public class QuestionCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="category_id")
	private int categoryId;

	@Column(name="category_name")
	private String categoryName;

	//bi-directional many-to-one association to QuestionCategoryMap
	@OneToMany(mappedBy="questionCategory")
	private List<QuestionCategoryMap> questionCategoryMaps;

	//bi-directional many-to-one association to QuestionCategorySkuMap
	@OneToMany(mappedBy="questionCategory")
	private List<QuestionCategorySkuMap> questionCategorySkuMaps;

	public QuestionCategory() {
	}

	public int getCategoryId() {
		return this.categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return this.categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<QuestionCategoryMap> getQuestionCategoryMaps() {
		return this.questionCategoryMaps;
	}

	public void setQuestionCategoryMaps(List<QuestionCategoryMap> questionCategoryMaps) {
		this.questionCategoryMaps = questionCategoryMaps;
	}

	public QuestionCategoryMap addQuestionCategoryMap(QuestionCategoryMap questionCategoryMap) {
		getQuestionCategoryMaps().add(questionCategoryMap);
		questionCategoryMap.setQuestionCategory(this);

		return questionCategoryMap;
	}

	public QuestionCategoryMap removeQuestionCategoryMap(QuestionCategoryMap questionCategoryMap) {
		getQuestionCategoryMaps().remove(questionCategoryMap);
		questionCategoryMap.setQuestionCategory(null);

		return questionCategoryMap;
	}

	public List<QuestionCategorySkuMap> getQuestionCategorySkuMaps() {
		return this.questionCategorySkuMaps;
	}

	public void setQuestionCategorySkuMaps(List<QuestionCategorySkuMap> questionCategorySkuMaps) {
		this.questionCategorySkuMaps = questionCategorySkuMaps;
	}

	public QuestionCategorySkuMap addQuestionCategorySkuMap(QuestionCategorySkuMap questionCategorySkuMap) {
		getQuestionCategorySkuMaps().add(questionCategorySkuMap);
		questionCategorySkuMap.setQuestionCategory(this);

		return questionCategorySkuMap;
	}

	public QuestionCategorySkuMap removeQuestionCategorySkuMap(QuestionCategorySkuMap questionCategorySkuMap) {
		getQuestionCategorySkuMaps().remove(questionCategorySkuMap);
		questionCategorySkuMap.setQuestionCategory(null);

		return questionCategorySkuMap;
	}

}