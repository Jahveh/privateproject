package com.menards.rental.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "overdue_notification")
public class OverdueNotificationTimes implements Serializable {
	
	
	@Id
	@Column(name = "notification_id")
	@GeneratedValue
	private int id;
	
	@Column(name = "agreement_nbr")
	private String agreementNumber;
	
	@Column(name = "notification_amt")
	private int times;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAgreementNumber() {
		return agreementNumber;
	}

	public void setAgreementNumber(String agreementNumber) {
		this.agreementNumber = agreementNumber;
	}

	public int getTimes() {
		return times;
	}

	public void setTimes(int times) {
		this.times = times;
	}
	
}
