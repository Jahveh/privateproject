/*
 * DifferenceOfTotalAndBaseHoursIncrementalHoursCalculationRule.java
 */
package com.menards.rental.domain.rule;

import com.menards.rental.domain.StoreHourBasedRentalDateRange;

/**
 * The calculation rule that returns the differnce of total and base hours to find the incremental hours.
 * @author deep
 */
public class DiffOfTotalAndBaseHrsAndIncrHrsCalcRule implements IncrementalHoursCalculationRule {

	/** The base sku hr qty. */
	private final double baseSkuHrQty;

	/** The rental date range. */
	private final StoreHourBasedRentalDateRange rentalDateRange;

	/**
	 * Instantiates a new difference of total and base hours incremental hours calculation rule.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @param rentalDateRange the rental date range
	 */
	public DiffOfTotalAndBaseHrsAndIncrHrsCalcRule(final double baseSkuHrQty,
	        final StoreHourBasedRentalDateRange rentalDateRange) {
		this.baseSkuHrQty = baseSkuHrQty;
		this.rentalDateRange = rentalDateRange;
	}

    /**
     * {@inheritDoc}
     */
	public double calculate() {
		return rentalDateRange.subtractHoursFromTotalDuration(baseSkuHrQty);
	}
}
