/*
 * Reservations.java
 */
package com.menards.rental.domain;

import com.menards.rental.domain.strategy.MinimumItmsRequiredCalculationStrategy;
import com.menards.rental.utils.Constants;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * The class representing a collection of reservations.
 * @author deep
 */
public class ReservationCollection extends CollectionUtil<Reservation> {

    /**
     * Instantiates a new reservations.
     *
     * @param reservations the reservations
     */
    public ReservationCollection(final Collection<Reservation> reservations) {
        super(reservations);
    }

    /**
     * Cancel the reservations.
     */
    public void cancel() {
        final ReservationStatus cancelledStatus = ReservationStatus.findCancelled();
        doInLoop(new ExpressionEvaluator<Reservation>() {

            public void evaluate(final Reservation entity) {
                if (!entity.isOpen()) {
                    return;
                }
                entity.setStatus(cancelledStatus);
            }
        });
    }

    /**
     * Count minimum number of items required to fulfill current reservations for a store for given duration.
     *
     * @param storeNumber the store number
     * @param outDate     the out date
     * @param inDate      the in date
     * @return the int
     */
    public int countMinimumNumberOfItemsRequiredToFulfillCurrentReservationsForAStoreForGivenDuration(
            final Integer storeNumber, final Calendar outDate, final Calendar inDate) {
        return new MinimumItmsRequiredCalculationStrategy(getOverlappingReservationsForStore(storeNumber,
                outDate, inDate)).count();
    }

    /**
     * Find reservation by id.
     *
     * @param reservationId the reservation id
     * @return the reservation
     */
    public Reservation findReservationById(final Long reservationId) {
        return returnEntityIfConditionIsTrue(new ConditionEvaluator<Reservation>() {

            public boolean evaluate(final Reservation entity) {
                return entity.getId().equals(reservationId);
            }
        });
    }

    /**
     * Get the csv fromat of checkout dates.
     * @return the csv formatted checked out dates.
     */
    public String getCSVCheckoutDates() {
        if (size() == 0) {
        	return "";
        }
        final StringBuilder stringBuilder = new StringBuilder();
        final SimpleDateFormat dateTimeFormat = new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT);
        doInLoop(new ExpressionEvaluator<Reservation>() {

            public void evaluate(final Reservation entity) {
                stringBuilder.append(dateTimeFormat.format(entity.getCheckOutTimeStamp().getTime())).append(",");
            }
        });
        return stringBuilder.substring(0, stringBuilder.length() - 1);
    }

    /**
     * Gets the first checkou date.
     *
     * @return the first checkou date
     */
    public Calendar getFirstCheckouDate() {
        return returnEntityIfConditionIsTrue(new ConditionEvaluator<Reservation>() {
            public boolean evaluate(final Reservation entity) {
                return true;
            }
        }).getCheckOutTimeStamp();
    }

    /**
     * Gets the non overlapping reservations list for store.
     *
     * @param storeNumber the store number
     * @param outDate     the out date
     * @param inDate      the in date
     * @return the non overlapping reservations list for store
     */
    public List<List<Reservation>> getNonOverlappingReservationsListForStore(final Integer storeNumber,
                                                                             final Calendar outDate,
                                                                             final Calendar inDate) {
        return new MinimumItmsRequiredCalculationStrategy(getOverlappingReservationsForStore(storeNumber,
                outDate, inDate)).getNonOverlappingReservationsList();
    }

    /**
     * Gets the open reservations for.
     *
     * @param storeNumber the store number
     * @return the open reservations for
     */
    public List<Reservation> getOpenReservationsFor(final Integer storeNumber) {
        return super.returnEntitiesIfConditionIsTrue(new ConditionEvaluator<Reservation>() {

            public boolean evaluate(final Reservation entity) {
                return entity.isOpen() && entity.isForStore(storeNumber);
            }
        });
    }
    
    /**
     * Gets the open reservations for the entities passed to the super.
     *
     * @return the open reservations for the entities passed to the super 
     */
    public List<Reservation> getOpenReservations() {
        return super.returnEntitiesIfConditionIsTrue(new ConditionEvaluator<Reservation>() {

            public boolean evaluate(final Reservation entity) {
                return entity.isOpen();
            }
        });
    }

    /**
     * Gets the overlapping open reservations for store.
     *
     * @param storeNumber the store number
     * @param outDate     the out date
     * @param inDate      the in date
     * @return the overlapping open reservations for store
     */
    public List<Reservation> getOverlappingOpenReservationsForStore(final Integer storeNumber,
                                                                    final Calendar outDate, final Calendar inDate) {
        final List<Reservation> openReservationsFor = getOpenReservationsFor(storeNumber);
        return new ReservationCollection(openReservationsFor)
                .returnEntitiesIfConditionIsTrue(new ConditionEvaluator<Reservation>() {

                    public boolean evaluate(final Reservation entity) {
                        return entity.isOverlappingForStore(storeNumber, outDate, inDate);
                    }
                });
    }

    /**
     * This returns the reservation of it is present for the productId.
     *
     * @param productId the product id
     * @return the reservation for
     */
    public Reservation getReservationFor(final long productId) {
        return returnEntityIfConditionIsTrue(new ConditionEvaluator<Reservation>() {
            public boolean evaluate(final Reservation entity) {
                return entity.isForProduct(productId);
            }
        });
    }

    /**
     * Gets the sorted open reservations.
     *
     * @return the sorted open reservations
     */
    public List<Reservation> getSortedOpenReservations() {
        final List<Reservation> sortedReservations = new ArrayList<Reservation>(getEntities());

        Collections.sort(sortedReservations, new Comparator<Reservation>() {

            public int compare(final Reservation r1, final Reservation r2) {
                return r1.getCheckOutTimeStamp().compareTo(r2.getCheckOutTimeStamp());
            }
        });

        return new ReservationCollection(sortedReservations)
                .returnEntitiesIfConditionIsTrue(new ConditionEvaluator<Reservation>() {

                    public boolean evaluate(final Reservation entity) {
                        return entity.isOpen();
                    }
                });
    }

    /**
     * Returns the total damage waiver of all the reservations.
     * @return the total damage waiver of all the reservations.
     */
    public BigDecimal getTotalDamageWaiver() {
        BigDecimal subTotal = new BigDecimal("0.0");
        for (final Reservation reservation : getEntities()) {
            subTotal = subTotal.add(reservation.getEstimatedDamageWaiver());
            }
        return subTotal;
    }

    /**
     * Returns the sum total of estimated charge amount of all reservations.
     * @return the sum total of estimated charge amount of all reservations.
     */
    public BigDecimal getTotalEstimatedChargeAmount() {
        BigDecimal subTotal = new BigDecimal("0.0");
        for (final Reservation reservation : getEntities()) {
            subTotal = subTotal.add(reservation.getTotalEstimatedChargeAmountPlusSurchargeAmount());
            }
        return subTotal;
    }

    /**
     * Checks if is any reservation for store.
     *
     * @param storeNumber the store number
     * @return true, if is any reservation for store
     */
    public boolean isAnyReservationForStore(final Integer storeNumber) {
        return returnTrueIfAnyConditionIsTrue(new ConditionEvaluator<Reservation>() {

            public boolean evaluate(final Reservation entity) {
                return entity.isForStore(storeNumber);
            }
        });
    }

    /**
     * Checks if is any reservation open.
     *
     * @return true, if is any reservation open
     */
    public boolean isAnyReservationOpen() {
        return returnTrueIfAnyConditionIsTrue(new ConditionEvaluator<Reservation>() {

            public boolean evaluate(final Reservation entity) {
                return entity.isOpen();
            }
        });
    }

    /**
     * Checks if is any reservation overlapping for store.
     *
     * @param storeNumber the store number
     * @param outDate     the out date
     * @param inDate      the in date
     * @return true, if is any reservation overlapping for store
     */
    public boolean isAnyReservationOverlappingForStore(final Integer storeNumber, final Calendar outDate,
                                                       final Calendar inDate) {
        return returnTrueIfAnyConditionIsTrue(new ConditionEvaluator<Reservation>() {

            public boolean evaluate(final Reservation entity) {
                return entity.isOverlappingForStore(storeNumber, outDate, inDate);
            }
        });
    }

    /**
     * Checks if is reservation present for.
     *
     * @param product the product
     * @return true, if is reservation present for
     */
    public boolean isReservationPresentFor(final Product product) {
        return returnTrueIfAnyConditionIsTrue(new ConditionEvaluator<Reservation>() {

            public boolean evaluate(final Reservation entity) {
                return entity.isForProduct(product.getId());
            }
        });
    }

    /**
     * Removes the reservation for.
     *
     * @param productId the product id
     */
    public void removeReservationFor(final long productId) {
        final Reservation reservation = returnEntityIfConditionIsTrue(new ConditionEvaluator<Reservation>() {

            public boolean evaluate(final Reservation entity) {
                return entity.isForProduct(productId);
            }
        });
        reservation.setAgreement(null);
        remove(reservation);
    }

    /**
     * The method that returns true if the guest age is greater than the minimum rental age.
     * @param guest the guest whos age is to be verified.
     * @return true if the guest age is greater than the minimum rental age for all products.
     */
    public boolean isGuestAgeGreaterThanMinimumAge(final Guest guest) {
        return returnFalseIfAnyConditionIsFalse(new ConditionEvaluator<Reservation>() {

            /**
             * {@inheritDoc}
             */
            public boolean evaluate(final Reservation entity) {
                return entity.isGuestAgeGreaterThanMinimumAge(guest);
            }
        });
    }

    /**
     * Gets the overlapping reservations for store.
     *
     * @param storeNumber the store number
     * @param outDate     the out date
     * @param inDate      the in date
     * @return the overlapping reservations for store
     */
    private List<Reservation> getOverlappingReservationsForStore(final Integer storeNumber, final Calendar outDate,
                                                                 final Calendar inDate) {
        return super.returnEntitiesIfConditionIsTrue(new ConditionEvaluator<Reservation>() {

            public boolean evaluate(final Reservation entity) {
                return entity.isOverlappingForStore(storeNumber, outDate, inDate);
            }
        });
    }
}
