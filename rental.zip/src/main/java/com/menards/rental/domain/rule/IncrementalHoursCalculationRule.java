/*
 * IncrementalHoursCalculationRule.java
 */
package com.menards.rental.domain.rule;

/**
 * Interface to implement to create calculation rules for dealing with
 * incremental hours (hours beyond the base number of rental hours) that an item
 * is charged for when checked out.
 * @author deep
 */
public interface IncrementalHoursCalculationRule {

	/**
	 * Calculate.
	 *
	 * @return the double
	 */
	double calculate();
}
