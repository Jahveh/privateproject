package com.menards.rental.domain;

import java.math.BigDecimal;

/**
 * The class that hold the information about sku from the kiosk server.
 *
 * @author deep
 */
public class KioskSKUDetail {

    /**
     * The current charge amount at kiosk.
     */
    private BigDecimal chargeAmount;

    /** The number of items. */
    private int numberOfItems;

    /**
     * The getter for the charge amount.
     *
     * @return the charge amount.
     */
    public BigDecimal getChargeAmount() {
        return chargeAmount;
    }

    /**
     * Getter for number of items.
     * @return the number of items.
     */
    public int getNumberOfItems() {
        return numberOfItems;
    }

    /**
     * Returns true if at least one item is setup for the given sku.
     * @return true if at least one item is setup for the given sku.    
     */
    public boolean isAtLeastOneItemSetup() {
        return numberOfItems > 0;
    }

    /**
     * Setter for chargeAmount.
     * @param chargeAmount value to set.
     */
    public void setChargeAmount(final BigDecimal chargeAmount) {
        this.chargeAmount = chargeAmount;
    }

    /**
     * Setter for numberOfItems.
     * @param numberOfItems value to set.
     */
    public void setNumberOfItems(final int numberOfItems) {
        this.numberOfItems = numberOfItems;
    }
}
