/*
 * ChecklistAnswer.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.MessageFormat;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

import javax.persistence.*;

/**
 * The checklist answers class.
 * @author deep 
 */

@Entity
@RooJavaBean
@RooEntity(identifierColumn = "answer_id")
@Table(name = "checklist_answer")
public class ChecklistAnswer implements Serializable {

	/**
	 * The Enum AnswerCode.
	 */
	public enum AnswerCode {

		/** The YES. */
		YES('Y'),
		/** The NO. */
		NO('N'),
		/** The NA. */
		NA('A');

		/** The code. */
		private Character code;

		/**
		 * Instantiates a new answer code.
		 *
		 * @param code the code
		 */
		AnswerCode(final char code) {
			this.code = code;
		}

		/**
		 * Gets the code.
		 *
		 * @return the code
		 */
		public String getCode() {
			return code.toString();
		}

		/**
		 * Matches.
		 *
		 * @param code the code
		 * @return true, if successful
		 */
		public boolean matches(final String code) {
            if (code == null) {
                return false;
            }
			return this.code == code.toCharArray()[0];
		}
	}

	/** The agreement item. */
	@ManyToOne(targetEntity = AgreementItem.class, fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "rental_detail_id")
	private AgreementItem agreementItem;

	/** The answer. */
	@Column(name = "answer_flg", columnDefinition = "char")
	private String answer;

	/** The question text. */
	@Column(name = "question_txt")
	private String questionText;

    /** The charge amount. */
	@Column(name = "charge_amt")
	private BigDecimal chargeAmount = new BigDecimal("0");

    /** The question sku. */
    @Column(name = "sku")
    private Long sku;

    /** The estimated charge amount. */
    @Transient
    private BigDecimal estimatedChargeAmount = new BigDecimal("0");

    /**
	 * Instantiates a new checklist answer.
	 */
	public ChecklistAnswer() {
		this(null, new Question());
	}

    /**
     * The constructor for the check list answer.
     * @param agreementItem the item.
     * @param chargeAmount the charge amount.
     */
    public ChecklistAnswer(final AgreementItem agreementItem, final BigDecimal chargeAmount) {
        this.agreementItem = agreementItem;
        this.chargeAmount = chargeAmount;
    }

    /**
     * The constructor for the check list answer.
     * @param agreementItem the agreement item for which we are answering this question.
     * @param question the question associated with this answer.
     */
    public ChecklistAnswer(final AgreementItem agreementItem, final Question question) {
        this.agreementItem = agreementItem;
        this.questionText = question.getText();
        this.estimatedChargeAmount = question.getChargeAmount();
        this.sku = question.getSku();
    }

	/**
	 * Gets the agreement item.
	 *
	 * @return the agreement item
	 */
	public AgreementItem getAgreementItem() {
		return agreementItem;
	}

	/**
	 * Gets the answer.
	 *
	 * @return the answer
	 */
	public String getAnswer() {
		return answer;
	}

	/**
	 * Gets the charge amount.
	 *
	 * @return the charge amount
	 */
	public BigDecimal getChargeAmount() {
		return chargeAmount;
	}

	/**
     * The getter for the estimated charge amount.
     * @return the value.
     */
    public BigDecimal getEstimatedChargeAmount() {
        return estimatedChargeAmount;
    }

	/**
	 * Gets the question text.
	 *
	 * @return the question text
	 */
	public String getQuestionText() {
		return questionText;
	}

	/**
	 * Checks if is yes answer.
	 *
	 * @return true, if is yes answer
	 */
	public boolean isYesAnswer() {
		return AnswerCode.YES.matches(answer);
	}

	/**
	 * Sets the agreement item.
	 *
	 * @param agreementItem the new agreement item
	 */
	public void setAgreementItem(final AgreementItem agreementItem) {
		this.agreementItem = agreementItem;
	}

	/**
	 * Sets the answer.
	 *
	 * @param answer the new answer
	 */
	public void setAnswer(final String answer) {
		this.answer = answer;
	}

	/**
	 * Sets the charge amount.
	 *
	 * @param chargeAmount the new charge amount
	 */
	public void setChargeAmount(final BigDecimal chargeAmount) {
		this.chargeAmount = chargeAmount;
	}

    /**
     * The setter for the estimated charge amount.
     * @param estimatedChargeAmount the value.
     */
    public void setEstimatedChargeAmount(final BigDecimal estimatedChargeAmount) {
        this.estimatedChargeAmount = estimatedChargeAmount;
    }

    /**
	 * Sets the question text.
	 *
	 * @param questionText the new question text
	 */
	public void setQuestionText(final String questionText) {
		this.questionText = questionText;
	}

    /**
     * Returns the formatted sku value.
     * @return the formatted sku value.
     */
    public String getFormattedSKU() {
        return MessageFormat.format("{0}-{1}",
                String.valueOf(sku).substring(0, 3),
                String.valueOf(sku).substring(3));
    }
}
