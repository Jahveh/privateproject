/*
 * AdditionalDriver.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

import com.menards.rental.utils.Constants;

/**
 * The Class AdditionalDriver.
 */
@Entity
@RooJavaBean
@RooEntity(identifierColumn = "extra_driver_id")
@Table(name = "extra_driver")
public class AdditionalDriver implements Serializable {

	/** The identification. */
	@Embedded
	@AttributeOverrides(value = {
	        @AttributeOverride(name = "number", column = @Column(name = "extra_driver_license_val")),
	        @AttributeOverride(name = "expiryDate", column = @Column(name = "extra_driver_license_exp_dt")),
	        @AttributeOverride(name = "state", column = @Column(name = "extra_driver_license_state_cd")) })
	private Identification identification = new Identification();

	/** The name. */
	@Column(name = "extra_driver_name")
	private String name;

	/** The address. */
	@Embedded
	@AttributeOverrides(value = {
	        @AttributeOverride(name = "line", column = @Column(name = "extra_driver_address")),
	        @AttributeOverride(name = "city", column = @Column(name = "extra_driver_city")),
	        @AttributeOverride(name = "state", column = @Column(name = "extra_driver_state_cd")),
	        @AttributeOverride(name = "zipCode", column = @Column(name = "extra_driver_postal_cd")) })
	private Address address = new Address();

	/** The date of birth. */
	@Column(name = "extra_driver_birth_dt")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(style = "S-")
	private Date dateOfBirth;

	/** The vehicle rental detail. */
	@ManyToOne(targetEntity = VehicleRentalDetail.class, optional = false)
	@JoinColumn(name = "vehicle_rental_detail_id")
	private VehicleRentalDetail vehicleRentalDetail;

	@Column(name = "gim_guest_account_id")
	private Long gimGuestAccountId;
	
	@Column(name = "gim_address_id")
	private Long gimAddressId;
		
    /**
	 * Checks if is driver age greater than minimum rental age.
	 *
	 * @param minimumRentalAge the minimum rental age
	 * @return true, if is driver age greater than minimum rental age
	 */
	public boolean isDriverAgeGreaterThanMinimumRentalAge(final int minimumRentalAge) {
		return getAge() >= minimumRentalAge;
	}

    /**
	 * Gets the age.
	 *
	 * @return the age
	 */
	private int getAge() {
		final long ageInMilliseconds = new Date().getTime() - dateOfBirth.getTime();
		return (int) (ageInMilliseconds / Constants.Calculation.MILLI_SECONDS_IN_A_YEAR);
	}

    /**
     * Getter for the identification.
     * @return the identification value held.  This method will never return a null value.  It will create an object
     * and set it if the initial value was null.
     */
    public Identification getIdentification() {
        if (null == identification) {
            identification = new Identification();
        }
        return identification;
    }

    /**
     * Getter for the address.
     * @return The address reference held by the additional driver.  This method never returns null it will create an
     * object if the initial value held by the object was null.
     */
    public Address getAddress() {
        if (null == this.address) {
        	this.address = new Address();
        }
        return this.address;
    }

    /**
     * Returns the escaped value of the name.
     * @return the String value representing the escaped name.
     */
    public String getNameEscaped() {
        return StringEscapeUtils.escapeHtml(name);
    }

    /**
	 * Gets the gim guest account id.
	 *
	 * @return Long
	 */
	public Long getGimGuestAccountId() {
		return gimGuestAccountId;
	}

    /**
	 * Sets the gim guest account id.
	 *
	 * @param Long gimGuestAccountId
	 */
	public void setGimGuestAccountId(Long gimGuestAccountId) {
		this.gimGuestAccountId = gimGuestAccountId;
	}

    /**
	 * Gets the gim address id.
	 *
	 * @return Long
	 */
	public Long getGimAddressId() {
		return gimAddressId;
	}

    /**
	 * Sets the gim address id.
	 *
	 * @param Long gimAddressId
	 */
	public void setGimAddressId(Long gimAddressId) {
		this.gimAddressId = gimAddressId;
	}    
}
