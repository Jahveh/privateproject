/*
 * SKUInfo.java
 */
package com.menards.rental.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * The sku info class.
 * @author deep
 */
@Embeddable
public class SKUInfo implements Serializable {

	/** The base sku. */
	@ManyToOne(targetEntity = RentalSKU.class, fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "base_sku")
	private RentalSKU baseSKU;

	/** The incremental sku. */
	@ManyToOne(targetEntity = RentalSKU.class, fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "incremental_sku")
	private RentalSKU incrementalSKU;

	/** The selling sku. */
	@ManyToOne(targetEntity = RentalSKU.class, fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "selling_sku")
	private RentalSKU sellingSKU;

	/** The surcharge sku. */
	@ManyToOne(targetEntity = RentalSKU.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "surcharge_sku")
	private RentalSKU surchargeSKU;

	/** The base sku hr qty. */
	@Column(name = "base_sku_hr_qty")
	private Double baseSkuHrQty = 4.0;

	/** The incremental sku hr qty. */
	@Column(name = "incremental_sku_hr_qty")
	private Double incrementalSkuHrQty = 1.0;

    /**
     * Should copy the hours from the other skuInfo.
     * @param other The instance from which we have to copy the Hours.
     */
    public void copyHoursFrom(final SKUInfo other) {
        setBaseSkuHrQty(other.getBaseSkuHrQty());
        setIncrementalSkuHrQty(other.getIncrementalSkuHrQty());
    }

	/**
	 * Creates the charge info.
	 *
	 * @return the charge info
	 */
	public ChargeInfo createChargeInfo() {
		return new ChargeInfo(baseSkuHrQty, incrementalSkuHrQty);
	}

    /**
	 * Gets the base sku.
	 *
	 * @return the base sku
	 */
	public RentalSKU getBaseSKU() {
		return baseSKU;
	}

	/**
	 * Gets the base sku hr qty.
	 *
	 * @return the base sku hr qty
	 */
	public Double getBaseSkuHrQty() {
		return baseSkuHrQty;
	}

	/**
	 * Gets the base sku id.
	 *
	 * @return the base sku id
	 */
	public Long getBaseSKUId() {
		return getBaseSKU().getId();
	}

	/**
     * Getter for base sku value.
     * @return base sku value.
     */
    public Long getBaseSkuValue() {
        return baseSKU.getValue();
    }

	/**
     * Getter for selling sku value.
     * @return selling sku value.
     */
    public Long getSellingSkuValue() {
        return sellingSKU.getValue();
    }

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return getBaseSKU().getDescription();
	}

	/**
	 * Gets the formatted base sku.
	 *
	 * @return the formatted base sku
	 */
	public String getFormattedBaseSKU() {
		return baseSKU.getFormattedValue();
	}

	/**
	 * Gets the formatted incremental sku.
	 *
	 * @return the formatted incremental sku
	 */
	public String getFormattedIncrementalSKU() {
		return incrementalSKU.getFormattedValue();
	}

	/**
	 * Gets the formatted selling sku.
	 *
	 * @return the formatted selling sku
	 */
	public String getFormattedSellingSKU() {
		return sellingSKU.getFormattedValue();
	}

	/**
	 * Gets the formatted surcharge sku.
	 *
	 * @return the formatted surcharge sku
	 */
	public String getFormattedSurchargeSKU() {
		return surchargeSKU.getFormattedValue();
	}

    /**
	 * Gets the incremental sku.
	 *
	 * @return the incremental sku
	 */
	public RentalSKU getIncrementalSKU() {
		return incrementalSKU;
	}

	/**
	 * Gets the incremental sku hr qty.
	 *
	 * @return the incremental sku hr qty
	 */
	public Double getIncrementalSkuHrQty() {
		return incrementalSkuHrQty;
	}

	/**
	 * Gets the incremental sku id.
	 *
	 * @return the incremental sku id
	 */
	public Long getIncrementalSKUId() {
		return getIncrementalSKU().getId();
	}

	/**
     * The getter for incremental sku value.
     * @return the incremental sku.
     */
    public Long getIncrementalSkuValue() {
        return incrementalSKU.getValue();
    }

	/**
	 * Gets the selling sku.
	 *
	 * @return the selling sku
	 */
	public RentalSKU getSellingSKU() {
		return sellingSKU;
	}

	/**
	 * Gets the selling sku id.
	 *
	 * @return the selling sku id
	 */
	public Long getSellingSKUId() {
		return getSellingSKU().getId();
	}

    /**
	 * Gets the surcharge sku.
	 *
	 * @return the surcharge sku
	 */
	public RentalSKU getSurchargeSKU() {
		return surchargeSKU;
	}

	/**
	 * Gets the surcharge sku id.
	 *
	 * @return the surcharge sku id
	 */
	public Long getSurchargeSKUId() {
		return getSurchargeSKU().getId();
	}

	/**
     * Getter for the surcharge sku value.
     * @return the value.
     */
    public Long getSurchargeSkuValue() {
        return surchargeSKU.getValue();
    }

	/**
     * The getter to find whether the surcharge sku is setup or not.
     * @return true if surcharge sku is setup.
     */
    public boolean isSurchargeSKUSetup() {
        return surchargeSKU != null;
    }

    /**
	 * Sets the base sku.
	 *
	 * @param baseSKU the new base sku
	 */
	public void setBaseSKU(final RentalSKU baseSKU) {
		this.baseSKU = baseSKU;
	}

	/**
	 * Sets the base sku hr qty.
	 *
	 * @param baseSkuHrQty the new base sku hr qty
	 */
	public void setBaseSkuHrQty(final Double baseSkuHrQty) {
		this.baseSkuHrQty = baseSkuHrQty;
	}

    /**
	 * Sets the incremental sku.
	 *
	 * @param incrementalSKU the new incremental sku
	 */
	public void setIncrementalSKU(final RentalSKU incrementalSKU) {
		this.incrementalSKU = incrementalSKU;
	}

    /**
	 * Sets the incremental sku hr qty.
	 *
	 * @param incrementalSkuHrQty the new incremental sku hr qty
	 */
	public void setIncrementalSkuHrQty(final Double incrementalSkuHrQty) {
		this.incrementalSkuHrQty = incrementalSkuHrQty;
	}

    /**
	 * Sets the selling sku.
	 *
	 * @param sellingSKU the new selling sku
	 */
	public void setSellingSKU(final RentalSKU sellingSKU) {
		this.sellingSKU = sellingSKU;
	}

    /**
	 * Sets the surcharge sku.
	 *
	 * @param surchargeSKU the new surcharge sku
	 */
	public void setSurchargeSKU(final RentalSKU surchargeSKU) {
		this.surchargeSKU = surchargeSKU;
	}
}
