/*
 * ChargeInfo.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.hibernate.annotations.Cascade;

import com.menards.rental.utils.Constants;

/**
 * The charge info class.
 * @author deep 
 */
@Embeddable
public class ChargeInfo implements Serializable {

	/** The checkout date. */
	@Column(name = "check_out_ts")
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar checkoutDate;

	/** The due by. */
	@Column(name = "due_by_ts")
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar dueBy;

	/** The checkin date. */
	@Column(name = "check_in_ts")
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar checkinDate;

	/** Copied values. */

	@Column(name = "base_price_amt")
	private BigDecimal basePriceAmount = new BigDecimal("0.0");

	/** The incremental price amount. */
	@Column(name = "incremental_price_amt")
	private BigDecimal incrementalPriceAmount = new BigDecimal("0.0");

	/** The surcharge price amount. */
	@Column(name = "surcharge_price_amt")
	private BigDecimal surchargePriceAmount = new BigDecimal("0.0");

	/** The base sku hr qty. */
	@Column(name = "base_sku_hr_qty")
	private Double baseSkuHrQty  = 0.0;

	/** The incremental sku hr qty. */
	@Column(name = "incremental_sku_hr_qty")
	private Double incrementalSkuHrQty = 0.0;

	/** Copied values end here. */

	/** Calculated values. */
	@Column(name = "base_sku_qty")
	private Integer baseTimeUnits;

	/** The incremental time units. */
	@Column(name = "incremental_sku_qty")
	private Integer incrementalTimeUnits;

	/**
	 * These are the incremental unit at check-in. Only the difference of actual
	 * quantities and estimated incremental quantities. Could be positive or
	 * negative, We update this value when we do a quantity override
	 */
	@Column(name = "additional_incremental_sku_qty")
	private Integer additionalIncrementalTimeUnits;

	/** If a price override is done its done on the base + incremental chargeAmount and
	 * we apply the percentage change to both baseChargeAmount and incrementalChargeAmount.
	 *
	*/
	@Column(name = "base_charge_amt")
	private BigDecimal baseChargeAmount;

	/** The incremental charge amount. */
	@Column(name = "incremental_charge_amt")
	private BigDecimal incrementalChargeAmount;

	/** The additional incremental charge amount while checkin. */
	@Column(name = "additional_incremental_charge_amt")
	private BigDecimal additionalIncrementalChargeAmount;

	/** The checklist answers charge amount. */
	@Column(name = "check_charge_amt")
	private BigDecimal checklistAnswersChargeAmount;

	/** Calculated values end here. */

	@Embedded
	@AttributeOverrides ({@AttributeOverride(name = "isDeclined", column = @Column(name = "damage_waiver_flg")),
	        @AttributeOverride(name = "amount", column = @Column(name = "damage_waiver_amt")),
	        @AttributeOverride(name = "creditAmount", column = @Column(name = "damage_waiver_credit_amt")) })
	private DamageWaiver damageWaiver = new DamageWaiver();

	/** The answers. */
	@OneToMany(targetEntity = ChecklistAnswer.class,
			cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "agreementItem")
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<ChecklistAnswer> answers = new HashSet<ChecklistAnswer>();

	/** The answer list. */
	@Transient
	private List<ChecklistAnswer> answerList = LazyList.decorate(new ArrayList<ChecklistAnswer>(), FactoryUtils
	        .instantiateFactory(ChecklistAnswer.class));

	/**
	 * Instantiates a new charge info.
	 */
	public ChargeInfo() {
	}

	/**
	 * Instantiates a new charge info.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @param incrementalSkuHrQty the incremental sku hr qty
	 */
	public ChargeInfo(final Double baseSkuHrQty, final Double incrementalSkuHrQty) {
		this.baseSkuHrQty = baseSkuHrQty;
		this.incrementalSkuHrQty = incrementalSkuHrQty;
	}

	/**
	 * Calculate damage waiver charges.
	 */
	public void calculateDamageWaiverCharges() {
		damageWaiver.calculate(calculateEstimatedChargeAmount());
	}

	/**
	 * Calculate estimated charges and duration.
	 */
	public void calculateEstimatedChargesAndDuration() {
		setBaseTimeUnits(1);
        final ChargeCalculator chargeCalculator = new ChargeCalculator(basePriceAmount,
                incrementalPriceAmount,
                baseSkuHrQty,
                incrementalSkuHrQty,
                checkoutDate,
                dueBy);
        chargeCalculator.calculate();
        setIncrementalTimeUnits(chargeCalculator.getIncrementalTimeUnits());
		setBaseChargeAmount(basePriceAmount);
		setIncrementalChargeAmount(chargeCalculator.getIncrementalChargeAmount());
		calculateDamageWaiverCharges();
	}

	/**
	 * The price override will apply the equal %age reduction on the base and incremental
	 * price, so that the total amounts to the price overridden amount.
	 *
	 * @param estimatedChargeAmountWithoutSurcharge the estimated charge amount without surcharge.
	 */
	public void doPriceOverride(final BigDecimal estimatedChargeAmountWithoutSurcharge) {
		final BigDecimal originalEstimatedChargeAmountWithoutSurcharge = getEstimatedChargeAmountWithoutSurcharge();

		//Find the %age change as per overridden amount
		final BigDecimal differenceInChargeAmount =
			originalEstimatedChargeAmountWithoutSurcharge.subtract(estimatedChargeAmountWithoutSurcharge);
		final BigDecimal percentageChange =
			differenceInChargeAmount.divide(originalEstimatedChargeAmountWithoutSurcharge,
			     Constants.Calculation.SCALE_CONTROL,
                 RoundingMode.HALF_EVEN);


		BigDecimal multiplicationFactor = percentageChange.subtract(new BigDecimal("1.0")).negate();

		//Recalculate the base and incremental charge amount and than apply a scale of 2
		//so that we have two decimal points
		baseChargeAmount = baseChargeAmount.multiply(multiplicationFactor);
		incrementalChargeAmount = incrementalChargeAmount.multiply(multiplicationFactor);

		//The above calculation might still make the calculation off by a little because of
		//various rounding off, so find the differential from the original price overridden amount
		final BigDecimal differentialAmount =
			baseChargeAmount.add(incrementalChargeAmount).subtract(estimatedChargeAmountWithoutSurcharge);
		
		//Subtract it differential back to base charge amount
		baseChargeAmount = baseChargeAmount.subtract(differentialAmount)
                .setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);

        basePriceAmount = baseChargeAmount;

        if(null != incrementalTimeUnits && incrementalTimeUnits > 0) {
            final BigDecimal incrementalTimeUnitsDecimal = new BigDecimal(incrementalTimeUnits);
            incrementalPriceAmount = incrementalChargeAmount.divide(incrementalTimeUnitsDecimal)
                    .setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
            incrementalChargeAmount = incrementalPriceAmount.multiply(incrementalTimeUnitsDecimal);
        }
	}

	/**
	 * Do quantity override. The quantity overriding is done on the
	 * total incremental quantity which is a sum of initial incremental and
	 * additional incremental.
	 *
	 * See MNDR-420 for detail use case
	 *
	 * @param actualIncrementalTimeUnits the actual incremental time units
	 */
	public void doQuantityOverride(final int actualIncrementalTimeUnits) {
		
		setAdditionalIncrementalTimeUnits(actualIncrementalTimeUnits - incrementalTimeUnits);
		setAdditionalIncrementalChargeAmount(calculateAdditionalIncrementalChargeAmount());
		
		//If the actual incremental time units are negative, than the guest has returned
		//item before time or the quantity has been overridden. 
		//We need to give credit on damage waiver also
		if (null != this.additionalIncrementalTimeUnits && 0 > this.additionalIncrementalTimeUnits) {
			//Find the percentage reduction
			double percentageReduction = (double) additionalIncrementalTimeUnits / incrementalTimeUnits;
			this.damageWaiver.calculateCredit(percentageReduction, basePriceAmount);
		} else {
			damageWaiver.setCreditAmount(new BigDecimal("0.0"));
		}
	}

	/**
	 * Gets the actual incremental charge amount.
	 *
	 * @return the actual incremental charge amount
	 */
	public BigDecimal getActualIncrementalChargeAmount() {
		return calculateEstimatedChargeAmount()
                .add(calculateAdditionalIncrementalChargeAmount())
                .setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
	}

	/**
	 * Gets the actual incremental duration display with actual check in time.
	 * @return double value representing the actual incremental durations.
	 */
	 public Double getActualIncrementalDuration() {
	        return (getActualRentalDuration() - this.getBaseSkuHrQty());
	 }

	/**
	 * Gets the actual incremental time units.
	 *
	 * @return the actual incremental time units
	 */
	public Integer getActualIncrementalTimeUnits() {
		return getAdditionalIncrementalTimeUnits() + getIncrementalTimeUnits();
	}

	/**
	 * Gets the actual rental duration.
	 *
	 * @return the actual rental duration
	 */
	public Double getActualRentalDuration() {
		return calculateActualRentalDuration();
	}

	/**
	 * Gets the additional incremental charge amount.
	 *
	 * @return the additional incremental charge amount
	 */
	public BigDecimal getAdditionalIncrementalChargeAmount() {
		return additionalIncrementalChargeAmount == null ? new BigDecimal(0.0d) : additionalIncrementalChargeAmount;
	}

	/**
	 * Gets the additional incremental time units.
	 *
	 * @return the additional incremental time units
	 */
	public Integer getAdditionalIncrementalTimeUnits() {
		return additionalIncrementalTimeUnits == null ? 0: additionalIncrementalTimeUnits;
	}

	/**
	 * Gets the answer list.
	 *
	 * @return the answer list
	 */
	public List<ChecklistAnswer> getAnswerList() {
		if (answerList.isEmpty()) {
            answerList.addAll(getAnswers());
        }
        return answerList;
	}

	/**
	 * Gets the answers.
	 *
	 * @return the answers
	 */
	public Set<ChecklistAnswer> getAnswers() {
		return answers;
	}

	/**
	 * Gets the base charge amount.
	 *
	 * @return the base charge amount
	 */
	public BigDecimal getBaseChargeAmount() {
		return baseChargeAmount;
	}

	/**
	 * Gets the base price amount.
	 *
	 * @return the base price amount
	 */
	public BigDecimal getBasePriceAmount() {
		return basePriceAmount;
	}

	/**
	 * Gets the base sku hr qty.
	 *
	 * @return the base sku hr qty
	 */
	public Double getBaseSkuHrQty() {
		return baseSkuHrQty;
	}

	/**
	 * Gets the base time units.
	 *
	 * @return the base time units
	 */
	public Integer getBaseTimeUnits() {
		return baseTimeUnits;
	}

	/**
	 * Gets the checkin date.
	 *
	 * @return the checkin date
	 */
	public Calendar getCheckinDate() {
		return checkinDate;
	}

	/**
	 * Gets the checklist answers charge amount.
	 *
	 * @return the checklist answers charge amount
	 */
	public BigDecimal getChecklistAnswersChargeAmount() {
		return checklistAnswersChargeAmount == null ? new BigDecimal(0.0d) : checklistAnswersChargeAmount;
	}

	/**
	 * Gets the checkout date.
	 *
	 * @return the checkout date
	 */
	public Calendar getCheckoutDate() {
		return checkoutDate;
	}

	/**
	 * Gets the damage waiver.
	 *
	 * @return the damage waiver
	 */
	public DamageWaiver getDamageWaiver() {
		return damageWaiver;
	}

	/**
	 * Gets the damage waiver amount.
	 *
	 * @return the damage waiver amount
	 */
	public BigDecimal getDamageWaiverAmount() {
		return getDamageWaiver().getAmount();
	}

	/**
	 * Gets the due by.
	 *
	 * @return the due by
	 */
	public Calendar getDueBy() {
		return dueBy;
	}

	/**
	 * Gets the estimated charge amount without surcharge.
	 *
	 * @return the estimated charge amount without surcharge
	 */
	public BigDecimal getEstimatedChargeAmountWithoutSurcharge() {
		return getBaseChargeAmount()
                .add(getIncrementalChargeAmount())
                .setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
	}

	/**
	 * Gets the estimated rental duration.
	 *
	 * @return the estimated rental duration
	 */
	public Double getEstimatedRentalDuration() {
		return calculateEstimatedRentalDuration();
	}

	/**
	 * Gets the incremental charge amount.
	 *
	 * @return the incremental charge amount
	 */
	public BigDecimal getIncrementalChargeAmount() {
		return incrementalChargeAmount;
	}

	/**
	 * Gets the incremental price amount.
	 *
	 * @return the incremental price amount
	 */
	public BigDecimal getIncrementalPriceAmount() {
		return incrementalPriceAmount;
	}

	/**
	 * Gets the incremental sku hr qty.
	 *
	 * @return the incremental sku hr qty
	 */
	public Double getIncrementalSkuHrQty() {
		return incrementalSkuHrQty;
	}

	/**
	 * Gets the incremental time units.
	 *
	 * @return the incremental time units
	 */
	public Integer getIncrementalTimeUnits() {
		return incrementalTimeUnits == null ? 0 : incrementalTimeUnits;
	}

	/**
	 * Gets the surcharge price amount.
	 *
	 * @return the surcharge price amount
	 */
	public BigDecimal getSurchargePriceAmount() {
		return surchargePriceAmount;
	}

	/**
	 * Gets the total additional charge amount.
	 *
	 * @return the total additional charge amount
	 */
	public BigDecimal getTotalAdditionalChargeAmount() {
		return getChecklistAnswersChargeAmount()
                .add(getAdditionalIncrementalChargeAmount())
                .setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
	}

	/**
	 * Gets the total estimated charge amount.
	 *
	 * @return the total estimated charge amount
	 */
	public BigDecimal getTotalEstimatedChargeAmount() {
          BigDecimal totalEstimatedChargeAmount = getBaseChargeAmount().add(getIncrementalChargeAmount());

    	 BigDecimal surchargeAmount = getSurchargePriceAmount();

    	 //We might now have surcharge amount applicable for the item
    	 if (null != surchargeAmount) {
    		 totalEstimatedChargeAmount = totalEstimatedChargeAmount.add(surchargeAmount);
    	 }

         return totalEstimatedChargeAmount.setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
	}

	/**
	 * Mark to checkin.
	 */
	public void markToCheckin() {
/*		answers.clear();
		answers.addAll(answerList);*/
		calculateActualChargesAndDuration();
	}

	/**
	 * Sets the additional incremental charge amount.
	 *
	 * @param additionalIncrementalChargeAmount the new additional incremental charge amount
	 */
	public void setAdditionalIncrementalChargeAmount(final BigDecimal additionalIncrementalChargeAmount) {
		this.additionalIncrementalChargeAmount = additionalIncrementalChargeAmount;
	}

	/**
	 * Sets the additional incremental time units.
	 *
	 * @param additionalIncrementalTimeUnits the new additional incremental time units
	 */
	public void setAdditionalIncrementalTimeUnits(final Integer additionalIncrementalTimeUnits) {
		this.additionalIncrementalTimeUnits = additionalIncrementalTimeUnits;
	}

	/**
	 * Sets the answer list.
	 *
	 * @param answerList the new answer list
	 */
	public void setAnswerList(final List<ChecklistAnswer> answerList) {
		this.answerList = answerList;
	}

	/**
	 * Sets the answers.
	 *
	 * @param answers the new answers
	 */
	public void setAnswers(final Set<ChecklistAnswer> answers) {
		this.answers = answers;
	}

	/**
	 * Sets the base charge amount.
	 *
	 * @param baseChargeAmount the new base charge amount
	 */
	public void setBaseChargeAmount(final BigDecimal baseChargeAmount) {
		this.baseChargeAmount = baseChargeAmount;
	}

	/**
	 * Sets the base price amount.
	 *
	 * @param basePriceAmount the new base price amount
	 */
	public void setBasePriceAmount(final BigDecimal basePriceAmount) {
		this.basePriceAmount = basePriceAmount;
	}

	/**
	 * Sets the base sku hr qty.
	 *
	 * @param baseSkuHrQty the new base sku hr qty
	 */
	public void setBaseSkuHrQty(final Double baseSkuHrQty) {
		this.baseSkuHrQty = baseSkuHrQty;
	}

	/**
	 * Sets the base time units.
	 *
	 * @param baseTimeUnits the new base time units
	 */
	public void setBaseTimeUnits(final Integer baseTimeUnits) {
		this.baseTimeUnits = baseTimeUnits;
	}

	/**
	 * Sets the checkin date.
	 *
	 * @param checkinDate the new checkin date
	 */
	public void setCheckinDate(final Calendar checkinDate) {
		this.checkinDate = checkinDate;
	}

	/**
	 * Sets the checklist answers charge amount.
	 *
	 * @param checklistAnswersChargeAmount the new checklist answers charge amount
	 */
	public void setChecklistAnswersChargeAmount(final BigDecimal checklistAnswersChargeAmount) {
		this.checklistAnswersChargeAmount = checklistAnswersChargeAmount;
	}

	/**
	 * Sets the checkout date.
	 *
	 * @param checkoutDate the new checkout date
	 */
	public void setCheckoutDate(final Calendar checkoutDate) {
		this.checkoutDate = checkoutDate;
	}

	/**
	 * Sets the damage waiver.
	 *
	 * @param damageWaiver the new damage waiver
	 */
	public void setDamageWaiver(final DamageWaiver damageWaiver) {
		this.damageWaiver = damageWaiver;
	}

	/**
	 * Sets the due by.
	 *
	 * @param dueBy the new due by
	 */
	public void setDueBy(final Calendar dueBy) {
		this.dueBy = dueBy;
	}

	/**
	 * Sets the incremental charge amount.
	 *
	 * @param incrementalChargeAmount the new incremental charge amount
	 */
	public void setIncrementalChargeAmount(final BigDecimal incrementalChargeAmount) {
		this.incrementalChargeAmount = incrementalChargeAmount;
	}

	/**
	 * Sets the incremental price amount.
	 *
	 * @param incrementalPriceAmount the new incremental price amount
	 */
	public void setIncrementalPriceAmount(final BigDecimal incrementalPriceAmount) {
		this.incrementalPriceAmount = incrementalPriceAmount;
	}

	/**
	 * Sets the incremental sku hr qty.
	 *
	 * @param incrementalSkuHrQty the new incremental sku hr qty
	 */
	public void setIncrementalSkuHrQty(final Double incrementalSkuHrQty) {
		this.incrementalSkuHrQty = incrementalSkuHrQty;
	}

	/**
	 * Sets the incremental time units.
	 *
	 * @param incrementalTimeUnits the new incremental time units
	 */
	public void setIncrementalTimeUnits(final Integer incrementalTimeUnits) {
		this.incrementalTimeUnits = incrementalTimeUnits;
	}

    /**
	 * Sets the surcharge price amount.
	 *
	 * @param surchargePriceAmount the new surcharge price amount
	 */
	public void setSurchargePriceAmount(final BigDecimal surchargePriceAmount) {
		this.surchargePriceAmount = surchargePriceAmount;
	}

	/**
	 * Calculate actual charges and duration.
	 */
	private void calculateActualChargesAndDuration() {
		
        final ChargeCalculator chargeCalculator = new ChargeCalculator(basePriceAmount,
                incrementalPriceAmount,
                baseSkuHrQty,
                incrementalSkuHrQty,
                checkoutDate,
                checkinDate);

        chargeCalculator.calculate();

		//Calculate the actual charges
		final int actualIncrementalUnits = chargeCalculator.getIncrementalTimeUnits();

		setAdditionalIncrementalTimeUnits(actualIncrementalUnits - incrementalTimeUnits);
		setAdditionalIncrementalChargeAmount(calculateAdditionalIncrementalChargeAmount());
		
		//Calculate the charges based on the checklist answers
//		setChecklistAnswersChargeAmount(new ChecklistAnswerCollection(answers).getTotalChargeAmount());
		
		//If the actual incremental time units are negative, than the guest has returned
		//item before time. We need to give credit on damage waiver also
		if (null != this.additionalIncrementalTimeUnits && 0 > this.additionalIncrementalTimeUnits) {
			//Find the percentage reduction
			double percentageReduction = (double) additionalIncrementalTimeUnits / incrementalTimeUnits;
			this.damageWaiver.calculateCredit(percentageReduction, basePriceAmount);
		} else {
			damageWaiver.setCreditAmount(new BigDecimal("0.0"));
		}
	}

	/**
	 * Calculate actual rental duration.
	 *
	 * @return the double
	 */
	private Double calculateActualRentalDuration() {
		return calculateEstimatedRentalDuration() + calculateAdditionalRentalDuration();
	}

    /**
	 * Calculate additional incremental charge amount.
	 *
	 * @return the big decimal
	 */
	private BigDecimal calculateAdditionalIncrementalChargeAmount() {
		return incrementalPriceAmount.multiply(new BigDecimal(additionalIncrementalTimeUnits.toString()))
                .setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
	}

	/**
	 * Calculate additional rental duration.
	 *
	 * @return the double
	 */
	private Double calculateAdditionalRentalDuration() {
		return incrementalSkuHrQty * (additionalIncrementalTimeUnits == null ? 0.0d : additionalIncrementalTimeUnits);
	}

	/**
	 * Calculate base rental duration.
	 *
	 * @return the double
	 */
	private Double calculateBaseRentalDuration() {
		return baseSkuHrQty * baseTimeUnits;
	}

	/**
	 * Calculate estimated charge amount.
	 *
	 * @return the big decimal
	 */
	private BigDecimal calculateEstimatedChargeAmount() {
        return baseChargeAmount.add(incrementalChargeAmount).setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
	}

	/**
	 * Calculate estimated rental duration.
	 *
	 * @return the double
	 */
	private Double calculateEstimatedRentalDuration() {
		return calculateBaseRentalDuration() + calculateIncrementalRentalDuration();
	}

	/**
	 * Calculate incremental rental duration.
	 *
	 * @return the double
	 */
	private Double calculateIncrementalRentalDuration() {
		return incrementalSkuHrQty * incrementalTimeUnits;
	}
}
