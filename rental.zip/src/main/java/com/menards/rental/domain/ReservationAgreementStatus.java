/*
 * ReservationAgreementStatus.java
 */
package com.menards.rental.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

/**
 * The reservation agreement status domain class.
 * @author deep
 */
@Entity
@Table(name = "reservation_agreement_status")
@RooEntity(identifierColumn = "reservation_agreement_status_id", finders = "findReservationAgreementStatusesByCode")
@RooJavaBean
public class ReservationAgreementStatus implements Serializable {

	/**
	 * The Enum ReservationAgreementStatusCode.
	 */
	public enum ReservationAgreementStatusCode {

		/** The OPEN. */
		OPEN('O'),
		/** The CANCELLED. */
		CANCELLED('C'),
		/** The FULLFILLED. */
		FULLFILLED('F');

		/** The code. */
		private final Character code;

		/**
		 * Instantiates a new reservation agreement status code.
		 *
		 * @param code the code
		 */
		ReservationAgreementStatusCode(final char code) {
			this.code = code;
		}

		/**
		 * Gets the code.
		 *
		 * @return the code
		 */
		public String getCode() {
			return code.toString();
		}
	}

	/** The code. */
	@Column(name = "code", nullable = false, unique = true)
	private String code;

	/** The description. */
	@Column(name = "description")
	private String description;

	/**
	 * Find cancelled.
	 *
	 * @return the reservation agreement status
	 */
	public static ReservationAgreementStatus findCancelled() {
		return findReservationAgreementStatusByCode(ReservationAgreementStatusCode.CANCELLED);
	}

	/**
	 * Find fulfilled.
	 *
	 * @return the reservation agreement status
	 */
	public static ReservationAgreementStatus findFulfilled() {
		return findReservationAgreementStatusByCode(ReservationAgreementStatusCode.FULLFILLED);
	}

	/**
	 * Find open.
	 *
	 * @return the reservation agreement status
	 */
	public static ReservationAgreementStatus findOpen() {
		return findReservationAgreementStatusByCode(ReservationAgreementStatusCode.OPEN);
	}

	/**
	 * Find reservation agreement status by code.
	 *
	 * @param statusCode the status code
	 * @return the reservation agreement status
	 */
	private static ReservationAgreementStatus findReservationAgreementStatusByCode(
	        final ReservationAgreementStatusCode statusCode) {
		return (ReservationAgreementStatus) findReservationAgreementStatusesByCode(statusCode.getCode())
		        .getSingleResult();
	}
}
