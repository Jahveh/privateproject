/*
 * OverrideReason.java
 */
package com.menards.rental.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Size;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;

/**
 * The Class OverrideReason.
 */
@Entity
@RooJavaBean
@RooToString
@Table(name = "override", uniqueConstraints = @UniqueConstraint(columnNames = { "override_cd" }))
@RooEntity(identifierColumn = "override_cd")
public class OverrideReason implements Serializable {

	/** The reason. */
	@Column(name = "override_reason_txt", nullable = false)
	@Size(max = 100)
	private String reason;

}
