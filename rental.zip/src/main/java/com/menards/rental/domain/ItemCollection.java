package com.menards.rental.domain;

import java.util.*;

/**
 * The class that represents the collection of items.
 *
 * @author deep
 */
public class ItemCollection extends CollectionUtil<Item> {
    /**
     * Instantiates a new collection.
     *
     * @param entities the entities
     */
    public ItemCollection(final Collection<Item> entities) {
        super(entities);
    }

    /**
     * Counts the total number of available items.
     * @return the int value representing total number of available items.
     */
    public int countAvailable() {
        int availableCount = 0;
        for (final Item item : getEntities()) {
            if (item.isAvailable()) {
                availableCount++;
            }
        }
        return availableCount;
    }

    /**
     * Returns the sortedlist of items by serial number.
     * @return the list of items sorted by serial number.
     */
    public List<Item> getSortedListBySerialNumber() {
        final List<Item> sortedItems = new ArrayList<Item>(getEntities());
        Collections.sort(sortedItems, new Comparator<Item>() {

            /**
             * {@inheritDoc}
             */
            public int compare(final Item first, final Item second) {
                return first.getSerialNumber().compareTo(second.getSerialNumber());
            }
        });
        return sortedItems;
    }
}
