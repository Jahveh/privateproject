package com.menards.rental.domain;

import com.menards.rental.service.external.KioskService;
import com.menards.rental.service.external.exception.KioskException;
import com.menards.rental.utils.Constants;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;

import java.util.*;

/**
 * The class that represents a list of agreements.
 *
 * @author deep
 */
@Configurable
public class AgreementCollection extends CollectionUtil<Agreement> {

    /** The log4j logger reference. */
    private static final Logger logger = Logger.getLogger(AgreementCollection.class);

    /** The kiosk service reference. */
    @Autowired
    private KioskService kioskService;

    /**
     * The constructor that takes a collection of agreements as argument.
     * @param agreements the agreements.
     */
    public AgreementCollection(final Collection<Agreement> agreements) {
        super(agreements);
    }

    /**
     * The list of agreements that have returned items.
     * @return list of agreements.
     */
    public List<Agreement> findAgreementsThatHaveReturnedItems() {
        return returnEntitiesIfConditionIsTrue(new ConditionEvaluator<Agreement>() {

            public boolean evaluate(final Agreement entity) {
                return entity.hasItemsThatAreReturnedButNotPaid();
            }
        });
    }

    /**
     * Cancels all the agreement held by the collection.
     */
    public void cancel() {
        doInLoop(new ExpressionEvaluator<Agreement>() {
            /**
             * {@inheritDoc}
             */
            public void evaluate(final Agreement entity) {
                entity.appendComment(Constants.Agreement.AGREEMENT_CANCELED_BY_SYSTEM_COMMENT);
                entity.cancelAgreement();
                sendCancelRequestToKiosk(entity);
            }
        });
    }

    /**
     * Returns the list of set of agreements that are grouped by store.
     * @return list of set of agreements that are grouped by store.
     */
    public List<List<Agreement>> getAgreementsGroupedByStore() {
        final HashMap<Integer, List<Agreement>> storeNumberVsAgreements = new HashMap<Integer, List<Agreement>>();
        doInLoop(new ExpressionEvaluator<Agreement>() {

            /**
             * {@inheritDoc}
             */
            public void evaluate(final Agreement entity) {
                List<Agreement> agreements = storeNumberVsAgreements.get(entity.getStoreNumber());
                if (null == agreements) {
                    storeNumberVsAgreements.put(entity.getStoreNumber(),  new ArrayList<Agreement>());
                    agreements = storeNumberVsAgreements.get(entity.getStoreNumber());
                }
                agreements.add(entity);
            }
        });
        return new ArrayList<List<Agreement>>(storeNumberVsAgreements.values());
    }

    /**
     * The setter for the kiosk service.
     * @param kioskService the value to set.
     */
    public void setKioskService(final KioskService kioskService) {
        this.kioskService = kioskService;
    }

    /**
     * The method that sends a cancel request to the kiosk server to cancel the agreement.
     * @param agreement the agreement that is to be canceled.
     */
    private void sendCancelRequestToKiosk(final Agreement agreement) {
        try {
            kioskService.cancelAgreement(agreement);
        } catch (final KioskException e) {
        	logger.error(e.getMessage(), e);
        }
    }
}
