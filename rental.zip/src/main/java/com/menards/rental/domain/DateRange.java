/*
 * DateRange.java
 */
package com.menards.rental.domain;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.menards.rental.utils.Constants;
import org.apache.log4j.Logger;

/**
 * The class that represents a date range i.e. a combination of a lower and an upper date.
 * @author deep
 */
public class DateRange {

    /** The logger. */
    private static final Logger logger = Logger.getLogger(DateRange.class);

	/** The lower. */
	private Calendar lower;

	/** The upper. */
	private Calendar upper;

	/**
	 * Instantiates a new date range.
	 *
	 * @param lower the lower
	 * @param upper the upper
	 */
	public DateRange(final Calendar lower, final Calendar upper) {
		this.lower = lower;
		this.upper = upper;
	}

    /**
     * The constructor that takes lower and upper as string values.
     * @param lowerString The lower value.
     * @param upperString The upper value.
     */
    public DateRange(final String lowerString, final String upperString) {
        try {
            lower = Calendar.getInstance();
            lower.setTime(new SimpleDateFormat(Constants.DateFormat.DATE_FORMAT).parse(lowerString));
            upper = Calendar.getInstance();
            upper.setTime(new SimpleDateFormat(Constants.DateFormat.DATE_FORMAT).parse(upperString));
        } catch (ParseException e) {
//            logger.error(e.getMessage(), e);
            logger.warn(e.getMessage(), e);
            throw new IllegalArgumentException(e);
        }
    }

    /**
	 * Gets the total duration in hours.
	 *
	 * @return the total duration in hours
	 */
	public double getTotalDurationInHours() {
		return (upper.getTimeInMillis() - lower.getTimeInMillis()) / Constants.Calculation.MILLI_SECONDS_IN_A_HOUR;
	}

	/**
     * The method that finds whether the date is in range or not.
     * @param calendar the date in question.
     * @return true if the date is in range.
     */
    public boolean isDateInRange(final Calendar calendar) {
        return (lower.compareTo(calendar) <= 0) && (upper.compareTo(calendar) >= 0);
    }

	/**
	 * Checks if is on same day.
	 *
	 * @return true, if is on same day
	 */
	public boolean isOnSameDay() {
		return ((lower.get(Calendar.DATE) == upper.get(Calendar.DATE))
                && (lower.get(Calendar.MONTH) == upper.get(Calendar.MONTH))
                && (lower.get(Calendar.YEAR) == upper.get(Calendar.YEAR)));
	}

	/**
	 * Checks if is total duration less than.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @return true, if is total duration less than
	 */
	public boolean isTotalDurationLessThan(final double baseSkuHrQty) {
		return getTotalDurationInHours() < baseSkuHrQty;
	}

	/**
	 * Subtract hours from total duration.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @return the double
	 */
	public double subtractHoursFromTotalDuration(final double baseSkuHrQty) {
		return getTotalDurationInHours() - baseSkuHrQty;
	}

	/**
	 * Gets the lower.
	 *
	 * @return the lower
	 */
	protected Calendar getLower() {
		return lower;
	}

    /**
	 * Gets the upper.
	 *
	 * @return the upper
	 */
	protected Calendar getUpper() {
		return upper;
	}
}
