/*
 * Report.java
 */
package com.menards.rental.domain;

import com.menards.rental.service.ContextService;
import com.menards.rental.utils.Constants;

/**
 * The report domain class that holds what type of report to generate and what is the medium used to download the
 * report.
 * 
 * @author deep
 */
public class Report implements ContextService.StoreNumberable
{

	/**
	 * The Enum Type.
	 */
	public enum Type
	{

		/** The Overdue rental report. */
		OVERDUE_RENTAL_REPORT("Overdue Rentals not checked in Report", "overdue_rental_report.csv",
						Constants.AppType.STORE_UTILITY, Constants.ReportPublisher.CSV_CONTENT_TYPE, true, false),

		/** The Overdue rental report which has been noticed*/
		NOTICED_OVERDUE_RENTAL_REPORT("Overdue Rentals not checked in Report(FEM has been noticed)", "overdue_rental_report.csv",
						Constants.AppType.STORE_UTILITY, Constants.ReportPublisher.CSV_CONTENT_TYPE, true, false),
						
		/** The void rental report. */
		VOID_RENTAL_REPORT("Rental Agreement Void Report", "void_rental.csv", Constants.AppType.STORE_UTILITY,
						Constants.ReportPublisher.CSV_CONTENT_TYPE, true, false),

		/** The Not recalled at register report. */
		NOT_RECALLED_AT_REGISTER_REPORT("Rental Agreement Not recalled at Register Report",
						"not_recalled_report.csv", Constants.AppType.STORE_UTILITY,
								Constants.ReportPublisher.CSV_CONTENT_TYPE, true, false),

		/** The Out of stock report. */
		OUT_OF_STOCK_REPORT("Out of Stock Report", "out_of_stock_report.csv", Constants.AppType.GO_UTILITY,
								Constants.ReportPublisher.CSV_CONTENT_TYPE,
						true, true),

		/** The Vendor notification_ report. */
		VENDOR_NOTIFICATION_REPORT("Vendor Notification Report", "vendor_notification_report.csv",
						Constants.AppType.GO_UTILITY, Constants.ReportPublisher.CSV_CONTENT_TYPE, true, true),

		/** The rental override notification report. */
		RENTAL_OVERRIDE_NOTIFICATION_REPORT("Rental Override Notification Report", null, Constants.AppType.NONE,
								Constants.ReportPublisher.PLAIN_CONTENT_TYPE, false, false),

		/** The reservation made notification report. */
		RESERVATION_MADE_NOTIFICATION_REPORT("Reservation at Menards", "reservation_details.pdf",
								Constants.AppType.NONE,
								Constants.ReportPublisher.PDF_CONTENT_TYPE, true, true),

		/** The notifcation that agreements have been cancelled automatically since they were not paid. */
		AGREEMENTS_CANCELLED_NOTIFICATION_REPORT("Auto-Cancelled Rental Agreements",
								"AGREEMENTS_CANCELLED_NOTIFICATION_REPORT.vm",
								Constants.AppType.NONE,
								Constants.ReportPublisher.PLAIN_CONTENT_TYPE, false, false),

		/** The archived agreement report. */
		ARCHIVED_AGREEMENT_REPORT("Archived Agreement Report", "rentalAgreement.pdf", Constants.AppType.NONE,
								Constants.ReportPublisher.PDF_CONTENT_TYPE, false, false),

		/** The archived agreement report. */
		AGREEMENT_REPORT("Agreement Report", "rentalAgreement.pdf", Constants.AppType.NONE,
								Constants.ReportPublisher.PDF_CONTENT_TYPE, false, false),

		/** The report for reservation type of agreements. */
		RESERVATION_REPORT("Reservation Report", "reservationAgreement.pdf",
								Constants.AppType.NONE, Constants.ReportPublisher.PDF_CONTENT_TYPE, false, false),

		/** The Not Returned Rental Report. */
		NOT_RETURNED_RENTAL_REPORT("Rental Item Not Returned Report",
						"not_returned_report.csv", Constants.AppType.GO_UTILITY, Constants.ReportPublisher.CSV_CONTENT_TYPE, false, true),
		/**The Demand Letter Report. */
		DEMAND_LETTER_REPORT("Demand Letter Report", "demandLetter.pdf", Constants.AppType.NONE,	
                Constants.ReportPublisher.PDF_CONTENT_TYPE, false, false);
		/** The description. */
		private String description;

		/** The file name. */
		private String fileName;

		// appType tells for which application the report is valid
		/** The app type. */
		private String appType;

		/** The content type. */
		private String contentType;

		// If true send the downloaded report format as servletAttachment on a servlet stream
		/** The servletAttachment. */
		private boolean servletAttachment;

		/** The boolean indicating whether the report has any email servletAttachment or not. */
		private boolean emailAttachment;

		/**
		 * Instantiates a new type.
		 * 
		 * @param description the description
		 * @param fileName the file name
		 * @param appType the app type
		 * @param contentType the content type
		 * @param servletAttachment the servletAttachment
		 */
		Type(final String description, final String fileName, final String appType, final String contentType,
						final boolean servletAttachment, final boolean emailAttachment)
		{
			this.description = description;
			this.fileName = fileName;
			this.appType = appType;
			this.contentType = contentType;
			this.servletAttachment = servletAttachment;
			this.emailAttachment = emailAttachment;
		}

		/**
		 * Gets the app type.
		 * 
		 * @return the app type
		 */
		public String getAppType()
		{
			return appType;
		}

		/**
		 * Gets the content type.
		 * 
		 * @return the content type
		 */
		public String getContentType()
		{
			return contentType;
		}

		/**
		 * Gets the description.
		 * 
		 * @return the description
		 */
		public String getDescription()
		{
			return description;
		}

		/**
		 * Gets the file name.
		 * 
		 * @return the file name
		 */
		public String getFileName()
		{
			return fileName;
		}

		/**
		 * Checks if is servletAttachment.
		 * 
		 * @return true, if is servletAttachment
		 */
		public boolean isServletAttachment()
		{
			return servletAttachment;
		}

		/**
		 * The getter suggesting that the report has an email attachment.
		 * 
		 * @return true if the report has an email attachment.
		 */
		public boolean isEmailAttachment()
		{
			return emailAttachment;
		}

		/**
		 * Sets the app type.
		 * 
		 * @param appType the new app type
		 */
		public void setAppType(final String appType)
		{
			this.appType = appType;
		}

		/**
		 * Sets the servletAttachment.
		 * 
		 * @param servletAttachment the new servletAttachment
		 */
		public void setServletAttachment(final boolean servletAttachment)
		{
			this.servletAttachment = servletAttachment;
		}

		/**
		 * Sets the content type.
		 * 
		 * @param contentType the new content type
		 */
		public void setContentType(final String contentType)
		{
			this.contentType = contentType;
		}

		/**
		 * Sets the description.
		 * 
		 * @param description the new description
		 */
		public void setDescription(final String description)
		{
			this.description = description;
		}

		/**
		 * Sets the file name.
		 * 
		 * @param fileName the new file name
		 */
		public void setFileName(final String fileName)
		{
			this.fileName = fileName;
		}

	}

	/** The store number. */
	private Integer storeNumber;

	/** The type. */
	private Type type;

	/** The report medium. */
	private String reportMedium;

	/**
	 * Gets the report medium.
	 * 
	 * @return the report medium
	 */
	public String getReportMedium()
	{
		return reportMedium;
	}

	/**
	 * Gets the store number.
	 * 
	 * @return the store number
	 */
	public Integer getStoreNumber()
	{
		return storeNumber;
	}

	/**
	 * Returns the template name to use.
	 * 
	 * @return String representing the template name.
	 */
	public String getTemplateName()
	{
		String template = Constants.ReportFormatter.REPORT_TEMPLATES_FOLDER_PATH + type;

		//Based on the final destination of report we will have different date
		if (Constants.ReportMedium.EMAIL.equalsIgnoreCase(reportMedium))
		{
			template += Constants.ReportFormatter.VELOCITY_FILE_EXTENSION;
			return template;
		}

		template += Constants.ReportFormatter.CSV_REPORT_SUFFIX;
		template += Constants.ReportFormatter.VELOCITY_FILE_EXTENSION;
		return template;
	}

	/**
	 * Gets the type.
	 * 
	 * @return the type
	 */
	public Type getType()
	{
		return type;
	}

	/**
	 * Gets the types.
	 * 
	 * @return the types
	 */
	public Type[] getTypes()
	{
		return Type.values();
	}

	/**
	 * Should return true if the report medium is download.
	 * 
	 * @return true if the report is to be downloaded
	 */
	public boolean isToBeDownloaded()
	{
		return Constants.ReportMedium.DOWNLOAD.equalsIgnoreCase(reportMedium);
	}

	/**
	 * Should return true if the report medium is email.
	 * 
	 * @return true if the report medium is email.
	 */
	public boolean isToBeEmailed()
	{
		return Constants.ReportMedium.EMAIL.equalsIgnoreCase(getReportMedium());
	}

	/**
	 * Sets the report medium.
	 * 
	 * @param reportMedium the new report medium
	 */
	public void setReportMedium(final String reportMedium)
	{
		this.reportMedium = reportMedium;
	}

	/**
	 * {@inheritDoc}
	 */
	public void setStoreNumber(final Integer storeNumber)
	{
		this.storeNumber = storeNumber;
	}

	/**
	 * Sets the type.
	 * 
	 * @param type the new type
	 */
	public void setType(final Type type)
	{
		this.type = type;
	}
}
