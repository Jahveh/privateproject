/*
 * ReservationStatus.java
 */
package com.menards.rental.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

/**
 * The reservation status class.
 * @author deep
 */
@Entity
@Table(name = "reservation_status")
@RooEntity(identifierColumn = "reservation_status_id", finders = "findReservationStatusesByCode")
@RooJavaBean
public class ReservationStatus implements Serializable {

	/**
	 * The Enum ReservationStatusCode.
	 */
	public enum ReservationStatusCode {

		/** The OPEN. */
		OPEN("O"),
		/** The CANCELLED. */
		CANCELLED("C"),
		/** The FULLFILLED. */
		FULLFILLED("F");

		/** The code. */
		private final String code;

		/**
		 * Instantiates a new reservation status code.
		 *
		 * @param code the code
		 */
		ReservationStatusCode(final String code) {
			this.code = code;
		}

		/**
		 * Gets the code.
		 *
		 * @return the code
		 */
		public String getCode() {
			return code;
		}

		/**
		 * Checks if is matching.
		 *
		 * @param code the code
		 * @return true, if is matching
		 */
		public boolean isMatching(final String code) {
			return this.code.equals(code);
		}
	}

	/** The code. */
	@Column(name = "code", nullable = false, unique = true)
	private String code;

	/** The description. */
	@Column(name = "description")
	private String description;

	/**
	 * Find cancelled.
	 *
	 * @return the reservation status
	 */
	public static ReservationStatus findCancelled() {
		return findReservationStatusByCode(ReservationStatusCode.CANCELLED);
	}

	/**
	 * Find fulfilled.
	 *
	 * @return the reservation status
	 */
	public static ReservationStatus findFulfilled() {
		return findReservationStatusByCode(ReservationStatusCode.FULLFILLED);

	}

	/**
	 * Find open.
	 *
	 * @return the reservation status
	 */
	public static ReservationStatus findOpen() {
		return findReservationStatusByCode(ReservationStatusCode.OPEN);
	}

	/**
	 * Find reservation status by code.
	 *
	 * @param statusCode the status code
	 * @return the reservation status
	 */
	private static ReservationStatus findReservationStatusByCode(final ReservationStatusCode statusCode) {
		return (ReservationStatus) findReservationStatusesByCode(statusCode.getCode()).getSingleResult();
	}

	/**
	 * Checks if is cancelled.
	 *
	 * @return true, if is cancelled
	 */
	public boolean isCancelled() {
		return ReservationStatusCode.CANCELLED.isMatching(code);
	}

	/**
	 * Checks if is fulfilled.
	 *
	 * @return true, if is fulfilled
	 */
	public boolean isFulfilled() {
		return ReservationStatusCode.FULLFILLED.isMatching(code);
	}

	/**
	 * Checks if is open.
	 *
	 * @return true, if is open
	 */
	public boolean isOpen() {
		return ReservationStatusCode.OPEN.isMatching(code);
	}
}
