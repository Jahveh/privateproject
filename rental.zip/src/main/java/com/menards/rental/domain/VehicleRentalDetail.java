/*
 * VehicleRentalDetail.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

/**
 * The Class VehicleRentalDetail.
 */
@Entity
@RooJavaBean
@RooEntity(identifierColumn = "vehicle_rental_detail_id")
@Table(name = "vehicle_rental_detail")
public class VehicleRentalDetail implements Serializable {

	/** The agreement item. */
	@OneToOne(targetEntity = AgreementItem.class, optional = false)
	@JoinColumn(name = "rental_detail_id", unique = true)
	private AgreementItem agreementItem;

	/** The vehicle. */
	@ManyToOne(targetEntity = Vehicle.class, fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "vehicle_id")
	private Vehicle vehicle;
 
	/** The insurance. */
	@Embedded
	@AttributeOverrides(value = {
	        @AttributeOverride(name = "companyName", column = @Column(name = "guest_ins_name")),
	        @AttributeOverride(name = "policyNumber", column = @Column(name = "guest_ins_policy_val")),
	        @AttributeOverride(name = "policyExpirationDate", column = @Column(name = "guest_ins_exp_date")),
	        @AttributeOverride(name = "agent.name", column = @Column(name = "guest_ins_agent_name")),
	        @AttributeOverride(name = "agent.phoneNumber", column = @Column(name = "guest_ins_agent_phone_nbr")),
	        @AttributeOverride(name = "agent.address.line", column = @Column(name = "guest_ins_agent_address")),
	        @AttributeOverride(name = "agent.address.city", column = @Column(name = "guest_ins_agent_city")),
	        @AttributeOverride(name = "agent.address.state", column = @Column(name = "guest_ins_agent_state_cd")),
	        @AttributeOverride(name = "agent.address.zipCode", column = @Column(name = "guest_ins_agent_postal_cd")) 
	        })
	private Insurance insurance = new Insurance();

	/** The is extra driver needed. */
	@Column(name = "extra_driver_flg")
	private boolean isExtraDriverNeeded;

	/** The additional drivers. */
	@OneToMany(targetEntity = AdditionalDriver.class, cascade = CascadeType.ALL, mappedBy = "vehicleRentalDetail")
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	private Set<AdditionalDriver> additionalDrivers = new HashSet<AdditionalDriver>();

	/** The additional driver. */
	@Transient
	private AdditionalDriver additionalDriver;

	/**
	 * Gets the additional driver.
	 *
	 * @return the additional driver
	 */
	public AdditionalDriver getAdditionalDriver() {
		if (null != additionalDriver) {
			return additionalDriver;
		}
		additionalDriver = new AdditionalDriverCollection(additionalDrivers).getFirstAdditionalDriver();
		return additionalDriver;
	}

	/**
	 * Gets the additional drivers.
	 *
	 * @return the additional drivers
	 */
	public Set<AdditionalDriver> getAdditionalDrivers() {
		return additionalDrivers;
	}

	/**
	 * Gets the agreement item.
	 *
	 * @return the agreement item
	 */
	public AgreementItem getAgreementItem() {
		return agreementItem;
	}

	/**
	 * Gets the insurance.
	 *
	 * @return the insurance
	 */
	public Insurance getInsurance() {
		return insurance;
	}

	/**
	 * Gets the vehicle.
	 *
	 * @return the vehicle
	 */
	public Vehicle getVehicle() {
		return vehicle;
	}

	/**
	 * Checks if is driver age greater than minimum rental age.
	 *
	 * @param minimumRentalAge the minimum rental age
	 * @return true, if is driver age greater than minimum rental age
	 */
	public boolean isDriverAgeGreaterThanMinimumRentalAge(final int minimumRentalAge) {
		if (!isExtraDriverNeeded()) {
			return true;
		}

		if( null != additionalDriver ){ // In this scenario, we haven't collected that information yet.
			return additionalDriver.isDriverAgeGreaterThanMinimumRentalAge(minimumRentalAge);
		}
		else{
			return true;
		}
	}

	/**
	 * Checks if is extra driver needed.
	 *
	 * @return true, if is extra driver needed
	 */
	public boolean isExtraDriverNeeded() {
		return isExtraDriverNeeded;
	}

	/**
	 * Merge.
	 *
	 * @param item the item
	 * @param vehicleRentalDetail the vehicle rental detail
	 */
	public void merge(final Item item, final VehicleRentalDetail vehicleRentalDetail) {
		setInsurance(vehicleRentalDetail.getInsurance());
		setVehicle(item.getVehicle());
		setExtraDriverNeeded(vehicleRentalDetail.isExtraDriverNeeded());

		final AdditionalDriver extraDriver = vehicleRentalDetail.getAdditionalDriver();
		clearAdditionalDrivers();

		if (!isExtraDriverNeeded()) {
			return;
		}

		addAdditionalDriver(extraDriver);
	}

	/**
	 * Sets the additional driver.
	 *
	 * @param additionalDriver the new additional driver
	 */
	public void setAdditionalDriver(final AdditionalDriver additionalDriver) {
		this.additionalDriver = additionalDriver;
	}

	/**
	 * Sets the additional drivers.
	 *
	 * @param additionalDrivers the new additional drivers
	 */
	public void setAdditionalDrivers(final Set<AdditionalDriver> additionalDrivers) {
		this.additionalDrivers = additionalDrivers;
	}

	/**
	 * Sets the agreement item.
	 *
	 * @param agreementItem the new agreement item
	 */
	public void setAgreementItem(final AgreementItem agreementItem) {
		this.agreementItem = agreementItem;
	}

	/**
	 * Sets the extra driver needed.
	 *
	 * @param extraDriverNeeded the new extra driver needed
	 */
	public void setExtraDriverNeeded(final boolean extraDriverNeeded) {
		isExtraDriverNeeded = extraDriverNeeded;
	}

	/**
	 * Sets the insurance.
	 *
	 * @param insurance the new insurance
	 */
	public void setInsurance(final Insurance insurance) {
		this.insurance = insurance;
	}

	/**
	 * Sets the vehicle.
	 *
	 * @param vehicle the new vehicle
	 */
	public void setVehicle(final Vehicle vehicle) {
		this.vehicle = vehicle;
	}


    /**
     * Returns true if additional driver is added to the vehicle.
     * @return true if additional driver has some value in it.
     */
    public boolean isAdditionalDriverAdded() {
        return !additionalDrivers.isEmpty();
    }    

	/**
	 * Adds the additional driver.
	 *
	 * @param additionalDriver the additional driver
	 */
	private void addAdditionalDriver(final AdditionalDriver additionalDriver) {
		additionalDriver.setVehicleRentalDetail(this);
		additionalDriver.setId(null);
		additionalDriver.setVersion(null);
		additionalDrivers.add(additionalDriver);
	}

	/**
	 * Clear additional drivers.
	 */
	private void clearAdditionalDrivers() {
		additionalDrivers.clear();
		additionalDriver = null;
	}
}
