/*
 * ItemWillBeAvailableAtEveryOverlappingReservationPeriodReservationRule.java
 */
package com.menards.rental.domain.rule;

import java.util.Calendar;
import java.util.List;

import org.springframework.stereotype.Component;

import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.Item;
import com.menards.rental.domain.ItemStatus;
import com.menards.rental.domain.Reservation;
import com.menards.rental.domain.ReservationCollection;

/**
 * Checks whether the item should be available when the checkout time will
 * occur.
 * @author deep
 */
@Component(value = "itemWillBeAvailableAtEveryOverlappingReservationPeriodReservationRule")
public class ItemAvailableAtOverlappingReservationRule implements ReservationRule {

    /**
     * {@inheritDoc}
     */
	public boolean hasNoConflictingReservation(final Item item, final Calendar outDate, final Calendar inDate) {
		final List<List<Reservation>> nonOverlappingReservationsList = item.getNonOverlappingReservationsList(
		        outDate, inDate);
		final List<Item> itemsInTheStoreRightNow = Item.findAllItemsByStoreNumberAndProductAndItemStatus(item
		        .getStoreNumber(), item.getProduct(), ItemStatus.findAvailable());

		for (int i = 0; i < itemsInTheStoreRightNow.size() - 1; i++) {
			nonOverlappingReservationsList.remove(i);
		}

		for (int i = 0; i < nonOverlappingReservationsList.size(); i++) {
			final List<AgreementItem> agreementItemsThatWillBeReturned = AgreementItem
			        .findAllOpenAgreementItemsByProductHavingDueByDateLessThan(item.getProduct(),
                            new ReservationCollection(
			                nonOverlappingReservationsList.get(i)).getFirstCheckouDate());
			if (agreementItemsThatWillBeReturned.size() < i + 1) {
				return false;
			}
		}
		return true;
	}
}
