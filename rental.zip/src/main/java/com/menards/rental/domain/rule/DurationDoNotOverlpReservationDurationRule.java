/*
 * RentalDurationDoNotOverlapExistingReservationDurationReservationRule.java
 */
package com.menards.rental.domain.rule;

import java.util.Calendar;

import org.springframework.stereotype.Component;

import com.menards.rental.domain.Item;

/**
 * This rule returns true if the current out and in time do not overlap with an existing reservation.
 * @author deep
 */
@Component(value = "rentalDurationDoNotOverlapExistingReservationDurationReservationRule")
public class DurationDoNotOverlpReservationDurationRule implements ReservationRule {

    /**
     * {@inheritDoc}
     */
	public boolean hasNoConflictingReservation(final Item item, final Calendar outDate, final Calendar inDate) {
		return !item.hasOverlappingReservations(outDate, inDate);
	}
}
