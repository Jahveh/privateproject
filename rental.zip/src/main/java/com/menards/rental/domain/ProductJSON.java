package com.menards.rental.domain;
/**
 * This class is used to simplify Product down to something that Jackson can
 * parse and send as a response to ajax requests.
 * 
 * @author maanders
 *
 */
public class ProductJSON
{
  private Product product;
  private double baseSKUHrQty;
  private Long incSKUId;
  private double incSKUHrQty;
  private Long sellingSKUId;
  private boolean isSaleAllowed;
  private Long surchargeSKUId;
  private int minAgeToRent;
  private String vendorEmail;
  private boolean isInsAndAddDriverReq;
  private boolean isDamageWaiverAvail;
  private boolean isUsageTrackReq;
  private String usageTrackText;
  private String rentalPrompt;
  
  /**
   * Provide base SKU ID of the product that details are needed for.
   * 
   * @param baseSKUId
   */
  public ProductJSON(final Long baseSKUId)
  {
  	product = Product.findProductByBaseSKUId(baseSKUId);
  	
  	try
		{
			baseSKUHrQty = product.getBaseSkuHrQty();
			incSKUId = product.getIncrementalSKUId();
			incSKUHrQty = product.getIncrementalSkuHrQty();
			sellingSKUId = product.getSellingSKUId();
			isSaleAllowed = product.isSaleAllowed();
			surchargeSKUId = product.getSurchargeSKUId();
			minAgeToRent = product.getMinimumAgeToRent();
			vendorEmail = product.getVendorEmail();
			isInsAndAddDriverReq = product.getInsuranceAdditionalDriverLicenseRequired();
			isDamageWaiverAvail = product.getIsDamageWaiverAvailable();
			isUsageTrackReq = product.getUsageTrackingFlag();
			usageTrackText = product.getUsageTrackingText();
			rentalPrompt = product.getRentalPromptText();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
  }


	/**
	 * @return the baseSKUHrQty
	 */
	public double getBaseSKUHrQty()
	{
		return baseSKUHrQty;
	}


	/**
	 * @return the incSKUId
	 */
	public Long getIncSKUId()
	{
		return incSKUId;
	}


	/**
	 * @return the incSKUHrQty
	 */
	public double getIncSKUHrQty()
	{
		return incSKUHrQty;
	}


	/**
	 * @return the sellingSKUId
	 */
	public Long getSellingSKUId()
	{
		return sellingSKUId;
	}


	/**
	 * @return the isSaleAllowed
	 */
	public boolean isSaleAllowed()
	{
		return isSaleAllowed;
	}


	/**
	 * @return the surchargeSKUId
	 */
	public Long getSurchargeSKUId()
	{
		return surchargeSKUId;
	}


	/**
	 * @return the minAgeToRent
	 */
	public int getMinAgeToRent()
	{
		return minAgeToRent;
	}


	/**
	 * @return the vendorEmail
	 */
	public String getVendorEmail()
	{
		return vendorEmail;
	}


	/**
	 * @return the isInsAndAddDriverReq
	 */
	public boolean isInsAndAddDriverReq()
	{
		return isInsAndAddDriverReq;
	}


	/**
	 * @return the isDamageWaiverAvail
	 */
	public boolean isDamageWaiverAvail()
	{
		return isDamageWaiverAvail;
	}


	/**
	 * @return the isUsageTrackReq
	 */
	public boolean isUsageTrackReq()
	{
		return isUsageTrackReq;
	}


	/**
	 * @return the usageTrackText
	 */
	public String getUsageTrackText()
	{
		return usageTrackText;
	}


	/**
	 * @return the rentalPrompt
	 */
	public String getRentalPrompt()
	{
		return rentalPrompt;
	}
}
