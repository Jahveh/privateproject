/*
 * Insurance.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;

import org.apache.commons.lang.StringEscapeUtils;

/**
 * The insurance class.
 * @author deep
 */
@Embeddable
public class Insurance implements Serializable {

	/** The company name. */
	private String companyName;

	/** The policy number. */
	private String policyNumber;

	/** The policy number. */
	private Date policyExpirationDate;

	/** The agent. */
	@Embedded
	private Agent agent = new Agent();

	/**
	 * Gets the agent.
	 *
	 * @return the agent
	 */
	public Agent getAgent() {
		return agent;
	}

	/**
	 * Gets the company name.
	 *
	 * @return the company name
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * Gets the company name.
	 *
	 * @return the company name
	 */
	public String getCompanyNameEscaped() {
		return StringEscapeUtils.escapeHtml(companyName);
	}

	/**
	 * Gets the policy number.
	 *
	 * @return the policy number
	 */
	public String getPolicyNumber() {
		return policyNumber;
	}

	/**
	 * Gets the policy expiration date.
	 *
	 * @return the policy expiration date
	 */
	public Date getPolicyExpirationDate() {
		return policyExpirationDate;
	}

	/**
	 * Sets the agent.
	 *
	 * @param agent the new agent
	 */
	public void setAgent(final Agent agent) {
		this.agent = agent;
	}

	/**
	 * Sets the company name.
	 *
	 * @param companyName the new company name
	 */
	public void setCompanyName(final String companyName) {
		this.companyName = companyName;
	}

	/**
	 * Sets the policy number.
	 *
	 * @param policyNumber the new policy number
	 */
	public void setPolicyNumber(final String policyNumber) {
		this.policyNumber = policyNumber;
	}

	/**
	 * Sets the policy expiration date.
	 *
	 * @param policyExpirationDate the new policy expiration date
	 */
	public void setPolicyExpirationDate(final Date policyExpirationDate) {
		this.policyExpirationDate = policyExpirationDate;
	}
	
	
}
