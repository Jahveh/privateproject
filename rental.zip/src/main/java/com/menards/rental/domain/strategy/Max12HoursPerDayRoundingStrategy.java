/*
 * Max12HoursPerDayRoundingStrategy.java
 */
package com.menards.rental.domain.strategy;

import com.menards.rental.utils.Constants;

/**
 * Rounds the number of days off into a maximum of 12 hours of rental per day.
 * @author deep
 */
public class Max12HoursPerDayRoundingStrategy {

	/**
	 * Calculate rounded incremental hours after subtracting base hours.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @param incrementalSkuHrQty the incremental sku hr qty
	 * @param actualDurationInHours the actual duration in hours
	 * @return the double
	 */
	public double calculateRoundedIncrementalHoursAfterSubtractingBaseHours(final double baseSkuHrQty,
	        final double incrementalSkuHrQty, final double actualDurationInHours) {
		final double chargeableDurationInADay = getMaxChargeableDurationInADay(actualDurationInHours);

		final double probableIncrementalUnits = Math.ceil((chargeableDurationInADay - baseSkuHrQty)
		        / incrementalSkuHrQty);

		/**
		 * Checking whether the total hours i.e. base + increment is greater
		 * than 12 if yes then we have to floor the incremental units. Else we
		 * are good to return the ceil value
		 */
		if (((probableIncrementalUnits * incrementalSkuHrQty) + baseSkuHrQty) <= Constants.Calculation.TWELVE_HOURS) {
			return probableIncrementalUnits * incrementalSkuHrQty;
		}
		return (Math.floor((chargeableDurationInADay - baseSkuHrQty) / incrementalSkuHrQty) * incrementalSkuHrQty);
	}

	/**
	 * Gets the max chargeable duration in a day.
	 *
	 * @param actualDurationInHours the actual duration in hours
	 * @return the max chargeable duration in a day
	 */
	private double getMaxChargeableDurationInADay(final double actualDurationInHours) {
		if (actualDurationInHours > Constants.Calculation.TWELVE_HOURS) {
			return Constants.Calculation.TWELVE_HOURS;
		}
        return actualDurationInHours;
	}
}
