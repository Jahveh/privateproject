package com.menards.rental.domain;

import com.menards.rental.utils.Constants;

import java.util.Collection;

/**
 * The class that represents a collection of reservation agreements.
 *
 * @author deep
 */
public class ReservationAgreementCollection extends CollectionUtil<ReservationAgreement> {

    /**
     * Instantiates a new collection.
     *
     * @param entities the entities
     */
    public ReservationAgreementCollection(final Collection<ReservationAgreement> entities) {
        super(entities);
    }

    /**
     * Cancels all the reservation agreements held by this collection.
     */
    public void cancel() {
        final ReservationAgreementStatus cancelled = ReservationAgreementStatus.findCancelled();
        doInLoop(new ExpressionEvaluator<ReservationAgreement>() {

            /**
             * {@inheritDoc}
             */
            public void evaluate(final ReservationAgreement entity) {
                entity.setStatus(cancelled);
                String initialValue = "";
                if (null != entity.getOverallComment()) {
                    initialValue = entity.getOverallComment();
                }
                entity.setOverallComment(initialValue
                        + Constants.Reservation.RESERVATION_CANCELED_BY_SYSTEM_COMMENT);
            }
        });
    }
}
