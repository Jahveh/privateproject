package com.menards.rental.domain.questions;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the question_category_map database table.
 * 
 */
@Entity
@Table(name="question_category_map")
@NamedQuery(name="QuestionCategoryMap.findAll", query="SELECT q FROM QuestionCategoryMap q")
public class QuestionCategoryMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private QuestionCategoryMapPK id;

	//bi-directional many-to-one association to Question
	@ManyToOne
	@JoinColumn(name="question_id", insertable=false, updatable=false)
	private Quiz question;

	//bi-directional many-to-one association to QuestionCategory
	@ManyToOne
	@JoinColumn(name="question_category_id", insertable=false, updatable=false)
	private QuestionCategory questionCategory;

	//bi-directional many-to-one association to QuestionType
	@ManyToOne
	@JoinColumn(name="question_type_id", insertable=false, updatable=false)
	private QuestionType questionType;

	public QuestionCategoryMap() {
	}

	public QuestionCategoryMapPK getId() {
		return this.id;
	}

	public void setId(QuestionCategoryMapPK id) {
		this.id = id;
	}

	public Quiz getQuestion() {
		return this.question;
	}

	public void setQuestion(Quiz question) {
		this.question = question;
	}

	public QuestionCategory getQuestionCategory() {
		return this.questionCategory;
	}

	public void setQuestionCategory(QuestionCategory questionCategory) {
		this.questionCategory = questionCategory;
	}

	public QuestionType getQuestionType() {
		return this.questionType;
	}

	public void setQuestionType(QuestionType questionType) {
		this.questionType = questionType;
	}

}