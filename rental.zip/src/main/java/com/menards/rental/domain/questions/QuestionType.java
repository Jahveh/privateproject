package com.menards.rental.domain.questions;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the question_type database table.
 * 
 */
@Entity
@Table(name="question_type")
@NamedQuery(name="QuestionType.findAll", query="SELECT q FROM QuestionType q")
public class QuestionType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="type_id")
	private int typeId;

	private String type;

	//bi-directional many-to-one association to QuestionCategoryMap
	@OneToMany(mappedBy="questionType")
	private List<QuestionCategoryMap> questionCategoryMaps;

	public QuestionType() {
	}

	public int getTypeId() {
		return this.typeId;
	}

	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<QuestionCategoryMap> getQuestionCategoryMaps() {
		return this.questionCategoryMaps;
	}

	public void setQuestionCategoryMaps(List<QuestionCategoryMap> questionCategoryMaps) {
		this.questionCategoryMaps = questionCategoryMaps;
	}

	public QuestionCategoryMap addQuestionCategoryMap(QuestionCategoryMap questionCategoryMap) {
		getQuestionCategoryMaps().add(questionCategoryMap);
		questionCategoryMap.setQuestionType(this);

		return questionCategoryMap;
	}

	public QuestionCategoryMap removeQuestionCategoryMap(QuestionCategoryMap questionCategoryMap) {
		getQuestionCategoryMaps().remove(questionCategoryMap);
		questionCategoryMap.setQuestionType(null);

		return questionCategoryMap;
	}

}