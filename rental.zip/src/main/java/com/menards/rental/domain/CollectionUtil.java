/*
 * Collection.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * The class that represents a collection of any type.
 * @param <T> the generic type. Could be any class such as AgreementItem or Reservation
 * @author deep
 */
public class CollectionUtil<T> implements Serializable {

	/** The entities. */
	private final Collection<T> entities;

	/**
	 * Instantiates a new collection.
	 *
	 * @param entities the entities
	 */
	public CollectionUtil(final Collection<T> entities) {
		this.entities = entities;
	}

	/**
	 * Adds the entity to the list of entities held by this collection.
	 *
	 * @param entity to add.
	 */
	public void add(final T entity) {
		entities.add(entity);
	}

	/**
	 * Returns true if the entity is contained in the collection.
	 *
	 * @param entity to find in the collection.
	 * @return true, if entity was found in the collection.
	 */
	public boolean contains(final T entity) {
		return entities.contains(entity);
	}

	/**
	 * Removes the entity from the collection.
	 *
	 * @param entity to remove.
	 */
	public void remove(final T entity) {
		entities.remove(entity);
	}

	/**
	 * Return entities if condition is true.
	 *
	 * @param evaluator the evaluator
	 * @return the list
	 */
	public List<T> returnEntitiesIfConditionIsTrue(final ConditionEvaluator<T> evaluator) {
		final List<T> matchingEntities = new ArrayList<T>();
		for (final T entity : entities) {
			if (evaluator.evaluate(entity)) {
				matchingEntities.add(entity);
			}
		}
		return matchingEntities;
	}

	/**
	 * Returns the Size of the collection.
	 *
	 * @return the int value representing the size of the collection.
	 */
	public int size() {
		return entities.size();
	}

	/**
	 * Do in loop.
	 *
	 * @param evaluator the evaluator
	 */
	public void doInLoop(final ExpressionEvaluator<T> evaluator) {
		for (final T entity : entities) {
			evaluator.evaluate(entity);
		}
	}

    /**
     * Return entity if condition is true.
     *
     * @param evaluator the evaluator
     * @return the t
     */
    public T returnEntityIfConditionIsTrue(final ConditionEvaluator<T> evaluator) {
        for (final T entity : entities) {
            if (evaluator.evaluate(entity)) {
                return entity;
            }
        }
        return null;
    }

	/**
	 * Gets the entities.
	 *
	 * @return the entities
	 */
	protected Collection<T> getEntities() {
		return entities;
	}

	/**
	 * Return false if any condition is false.
	 *
	 * @param evaluator the evaluator
	 * @return true, if successful
	 */
	protected boolean returnFalseIfAnyConditionIsFalse(final ConditionEvaluator<T> evaluator) {
		for (final T entity : entities) {
			if (!evaluator.evaluate(entity)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Return true if any condition is true.
	 *
	 * @param evaluator the evaluator
	 * @return true, if successful
	 */
	protected boolean returnTrueIfAnyConditionIsTrue(final ConditionEvaluator<T> evaluator) {
		for (final T entity : entities) {
			if (evaluator.evaluate(entity)) {
				return true;
			}
		}
		return false;
	}
}
