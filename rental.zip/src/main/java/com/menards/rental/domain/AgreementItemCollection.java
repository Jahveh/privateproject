/*
 * AgreementItemCollection.java
 */
package com.menards.rental.domain;

import com.menards.rental.utils.Constants;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;

/**
 * The collection class that represents the collection of agreement items.
 * @author deep
 */
public class AgreementItemCollection extends CollectionUtil<AgreementItem> implements Serializable {

    /** The logger. */
    private static final Logger logger = Logger.getLogger(AgreementItemCollection.class);

	/**
	 * Instantiates a new agreement items.
	 *
	 * @param agreementItems the agreement items
	 */
	public AgreementItemCollection(final Collection<AgreementItem> agreementItems) {
		super(agreementItems);
	}

	/**
	 * Calculate damage waiver charges.
	 */
	public void calculateDamageWaiverCharges() {
		doInLoop(new ExpressionEvaluator<AgreementItem>() {

			public void evaluate(final AgreementItem entity) {
				entity.calculateDamageWaiverCharges();
			}
		});
	}

	/**
	 * Checkin marked items.
	 */
	public void checkinMarkedItems() {
		doInLoop(new ExpressionEvaluator<AgreementItem>() {

			public void evaluate(final AgreementItem entity) {
				if (entity.isCheckedin()) {
                    entity.actualCheckin();
                }
			}
		});
	}

	/**
	 * Contains by serial number.
	 *
	 * @param item the item
	 * @return true, if successful
	 */
	public boolean containsBySerialNumber(final Item item) {
		final Long itemSerialNumber = item.getSerialNumber();
		return returnTrueIfAnyConditionIsTrue(new ConditionEvaluator<AgreementItem>() {

			public boolean evaluate(final AgreementItem entity) {
				return entity.matches(itemSerialNumber);
			}
		});
	}

	/**
	 * Find item by serial number.
	 *
	 * @param serialNumber the serial number
	 * @return the agreement item
	 */
	public AgreementItem findItemBySerialNumber(final Long serialNumber) {
		return returnEntityIfConditionIsTrue(new ConditionEvaluator<AgreementItem>() {
			public boolean evaluate(final AgreementItem entity) {
				return entity.matches(serialNumber);
			}
		});
	}

	/**
	 * Fulfill reservations.
	 */
	public void fulfillReservations() {
		doInLoop(new ExpressionEvaluator<AgreementItem>() {

			public void evaluate(final AgreementItem entity) {
				entity.fulfillReservation();
			}
		});
	}

	/**
	 * Gets the damage waiver total.
	 *
	 * @return the damage waiver total
	 */
	public BigDecimal getDamageWaiverTotal() {
		BigDecimal total = new BigDecimal("0.0");
		for (final AgreementItem item : getEntities()) {
			
			//Check if damage waiver is available for this item
			if (item.getIsDamageWaiverAvailable()) {
			   total = total.add(item.getDamageWaiverAmount());
			}
		}
		return total.setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
	}

	/**
	 * Gets the effective rental total excluding damage waiver.
	 *
	 * @return the effective rental total excluding damage waiver
	 */
	public BigDecimal getEffectiveRentalTotalExcludingDamageWaiver() {
		BigDecimal total = new BigDecimal("0.0");
		for (final AgreementItem agreementItem : getEntities()) {

			if (agreementItem.isReturnedAndPaidComplete()) {
                logger.info("Not Adding the charges of this rental item since its already returned and paid");
			} else if (agreementItem.isAgreementVoided()) {
				total = total.subtract(agreementItem.getTotalEstimatedChargeAmount());
			} else if (agreementItem.isCheckedOut()) {
				total = total.add(agreementItem.getTotalEstimatedChargeAmount());
			} else if (agreementItem.isReturned()) {
				total = total.add(agreementItem.getTotalAdditionalChargeAmount());
			}
		}
		return total.setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
	}

	/**
	 * Gets the first vehicle rental detail.
	 *
	 * @return the first vehicle rental detail
	 */
	public VehicleRentalDetail getFirstVehicleRentalDetail() {
		final AgreementItem agreementItem = returnEntityIfConditionIsTrue(new ConditionEvaluator<AgreementItem>() {

			public boolean evaluate(final AgreementItem entity) {
				return null != entity.getVehicleRentalDetail();
			}
		});
		if (null == agreementItem) {
			return new VehicleRentalDetail();
		}
		return agreementItem.getVehicleRentalDetail();
	}

	/**
	 * Gets the price override approved by.
	 *
	 * @return the price override approved by
	 */
	public Integer getPriceOverrideApprovedBy() {
		final AgreementItem entity = returnEntityIfConditionIsTrue(new ConditionEvaluator<AgreementItem>() {

			public boolean evaluate(final AgreementItem entity) {
				return null != entity.getPriceOverrideByNumber();
			}
		});
		if (null == entity) {
			return null;
		}
		return entity.getPriceOverrideByNumber();
	}

	/**
	 * Gets the quantity override approved by.
	 *
	 * @return the quantity override approved by
	 */
	public Integer getQuantityOverrideApprovedBy() {
		final AgreementItem entity = returnEntityIfConditionIsTrue(new ConditionEvaluator<AgreementItem>() {

			public boolean evaluate(final AgreementItem entity) {
				return null != entity.getQuantityOverrideByNumber();
			}
		});
		if (null == entity) {
			return null;
		}
		return entity.getQuantityOverrideByNumber();
	}

	/**
	 * Gets the total additional charge amount of items currently checkedin.
	 *
	 * @return the total additional charge amount of items currently checkedin
	 */
	public BigDecimal getTotalAdditionalChargeAmountOfItemsCurrentlyCheckedin() {
		BigDecimal total = new BigDecimal("0");
		for (final AgreementItem agreementItem : getEntities()) {
			if (agreementItem.isCheckedin()) {
				total = total.add(agreementItem.getTotalAdditionalChargeAmount());
			}
		}
		return total.setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
	}
	
	/**
	 * Gets the total damage waiver credit.
	 *
	 * @return the total additional charge amount of items currently checkedin.
	 */
	public BigDecimal getTotalDamageWaiverCreditOfItemsCurrentlyCheckedin() {
		BigDecimal total = new BigDecimal("0");
		for (final AgreementItem agreementItem : getEntities()) {
			if (agreementItem.getIsDamageWaiverAvailable()  && agreementItem.isCheckedin()) {
                total = total.add(agreementItem.getDamageWaiverCredit());
            }
		}
		return total.setScale(Constants.Calculation.CURRENCY_SCALE, RoundingMode.HALF_EVEN);
	}

	/**
	 * Checks if is driver age greater than minimum rental age.
	 *
	 * @param agreement the agreement
	 * @return true, if is driver age greater than minimum rental age
	 */
	public boolean isDriverAgeGreaterThanMinimumRentalAge(final Agreement agreement) {
		return returnFalseIfAnyConditionIsFalse(new ConditionEvaluator<AgreementItem>() {

			public boolean evaluate(final AgreementItem entity) {
				return entity.isDriverAgeGreaterThanMinimumRentalAge(agreement);
			}
		});
	}

	/**
	 * Checks if is every item available right now.
	 *
	 * @return true, if is every item available right now
	 */
	public boolean isEveryItemAvailableRightNow() {
		if (size() == 0) {
			return false;
		}
		return returnFalseIfAnyConditionIsFalse(new ConditionEvaluator<AgreementItem>() {

			public boolean evaluate(final AgreementItem entity) {
				final Item item = Item.findItem(entity.getItemId());
				entity.setItem(item);
				if (!entity.isTransient()) {
					return true;
				}
				if (!item.isAvailable()) {
					return false;
				}
				return true;
			}
		});
	}

	/**
	 * Checks if is insurance additional driver license required.
	 *
	 * @return true, if is insurance additional driver license required
	 */
	public boolean isInsuranceAdditionalDriverLicenseRequired() {
		return returnTrueIfAnyConditionIsTrue(new ConditionEvaluator<AgreementItem>() {

			public boolean evaluate(final AgreementItem entity) {
				return entity.isInsuranceAdditionalDriverLicenseRequired();
			}
		});
	}

	/**
	 * Mark agreement item status as available.
	 */
	public void markAgreementItemStatusAsAvailable() {
        final Calendar checkinDate = Calendar.getInstance();
        final ItemStatus availableStatus = ItemStatus.findAvailable();
        final AgreementItemStatus returnedStatus = AgreementItemStatus.findReturned();
		doInLoop(new ExpressionEvaluator<AgreementItem>() {

			public void evaluate(final AgreementItem entity) {
                entity.updateItemStatus(availableStatus);
                entity.setStatus(returnedStatus);
                entity.setCheckinDate(checkinDate);
				entity.persistItem();
			}
		});
	}

    /**
     * Marks the agreement items returned and paid complete.
     */
    public void markAgreementItemsReturnedAndPaid() {
        final AgreementItemStatus returnedAndPaidComplete = AgreementItemStatus.findReturnedAndPaidComplete();
		doInLoop(new ExpressionEvaluator<AgreementItem>() {

			public void evaluate(final AgreementItem entity) {
                entity.setStatus(returnedAndPaidComplete);
				entity.persistItem();
			}
		});
    }

	/**
	 * Merge.
	 *
	 * @param vehicleRentalDetail the vehicle rental detail
	 */
	public void merge(final VehicleRentalDetail vehicleRentalDetail) {
		doInLoop(new ExpressionEvaluator<AgreementItem>() {
			public void evaluate(final AgreementItem entity) {
				if (entity.isInsuranceAdditionalDriverLicenseRequired()) {
                    entity.merge(vehicleRentalDetail);
                }
			}
		});
	}

    /**
     * {@inheritDoc}
     */
	@Override
	public void remove(final AgreementItem agreementItem) {
		super.remove(agreementItem);
		agreementItem.setAgreement(null);
	}

	/**
	 * Removes the all.
	 *
	 * @param removedItemList the removed item list
	 */
	public void removeAll(final AgreementItemCollection removedItemList) {
		if ((null == removedItemList) || (removedItemList.size() == 0)) {
            logger.error("Cannot remove the items if the collection passed is null or empty");
			return;
		}

		final Iterator<AgreementItem> agreementItemIterator = getEntities().iterator();
		while (agreementItemIterator.hasNext()) {
			final AgreementItem agreementItem = agreementItemIterator.next();
			if (removedItemList.containsById(agreementItem)) {
                agreementItemIterator.remove();
                agreementItem.setAgreement(null);
            }
		}
	}

	/**
	 * Sets the price override approved by.
	 *
	 * @param managerNumber the new price override approved by
	 */
	public void setPriceOverrideApprovedBy(final Integer managerNumber) {
		doInLoop(new ExpressionEvaluator<AgreementItem>() {

			public void evaluate(final AgreementItem entity) {
				if (entity.getHasPriceOverride()) {
					entity.setPriceOverrideByNumber(managerNumber);
				}
			}
		});
	}

	/**
	 * Sets the quantity override approved by.
	 *
	 * @param quantityOverrideManagerNumber the new quantity override approved by
	 */
	public void setQuantityOverrideApprovedBy(final Integer quantityOverrideManagerNumber) {
		doInLoop(new ExpressionEvaluator<AgreementItem>() {

			public void evaluate(final AgreementItem entity) {
				if (entity.getHasQuantityOverride()) {
					entity.setQuantityOverrideByNumber(quantityOverrideManagerNumber);
				}
			}
		});
	}

	/**
	 * Update agreement item status.
	 *
	 * @param agreementItemStatus the agreement item status
	 */
	public void updateAgreementItemStatus(final AgreementItemStatus agreementItemStatus) {
		doInLoop(new ExpressionEvaluator<AgreementItem>() {

			public void evaluate(final AgreementItem entity) {
				entity.setStatus(agreementItemStatus);
			}
		});
	}

    /**
	 * Update items status.
	 *
	 * @param itemStatus the item status
	 */
	public void updateItemsStatus(final ItemStatus itemStatus) {
		doInLoop(new ExpressionEvaluator<AgreementItem>() {

			public void evaluate(final AgreementItem entity) {
				final Item item = Item.findItem(entity.getItemId());
				item.setItemStatus(itemStatus);
				item.merge();
			}
		});
	}

    /**
	 * Update overrides.
	 */
	public void updateOverrides() {
		doInLoop(new ExpressionEvaluator<AgreementItem>() {

			public void evaluate(final AgreementItem entity) {
				entity.updateOverrides();
			}
		});
	}

    /**
     * Generates next item serial number for answers.
     * @return gets the next serial number.
     */
    public Long getNextItemSerialNumberToAnswerChecklist() {
    	final AgreementItem agreementItem = returnEntityIfConditionIsTrue(new ConditionEvaluator<AgreementItem>() {

            public boolean evaluate(final AgreementItem entity) {
                return entity.isToBeCheckedin();
            }
        });

        if (null != agreementItem) {
            return agreementItem.getSerialNumber();
        }
        return null;
    }

    /**
     * Returns true if vehicle is rented.
     * @return true if vehicle is rented.
     */
    public boolean isVehicleRented() {
        return returnTrueIfAnyConditionIsTrue(new ConditionEvaluator<AgreementItem>() {

            public boolean evaluate(final AgreementItem entity) {
                return (null != entity.getVehicleRentalDetail());
            }
        });
    }

    /**
     * Updates the checkout date of the items to the passed value.
     * @param transactionDate the date to update.
     */
    public void updateCheckoutDate(final Calendar transactionDate) {
        doInLoop(new ExpressionEvaluator<AgreementItem>() {

            public void evaluate(final AgreementItem entity) {
                entity.updateCheckoutDate(transactionDate);
            }
        });
    }

    /**
     * Updates the agreement item status for items that have been returned and paid for.
     * @param agreementItemStatus the status to set.
     */
    public void updateAgreementItemForReturnedItems(final AgreementItemStatus agreementItemStatus) {
        doInLoop(new ExpressionEvaluator<AgreementItem>() {

            public void evaluate(final AgreementItem entity) {
                if (entity.isReturned()) {
                    entity.setStatus(agreementItemStatus);
                }
            }
        });
    }

    /**
     * Returns true if every item is returned and paid.
     * @return true if every item is returned and paid.
     */
    public boolean isEveryItemReturnedAndPaid() {
        return returnFalseIfAnyConditionIsFalse(new ConditionEvaluator<AgreementItem>() {

            public boolean evaluate(final AgreementItem entity) {
                return entity.isReturnedAndPaidComplete();
            }
        });
    }

    /**
     * Return true if agreement items have item that does not require an additional driver.
     * @return true if item list has an item that does not require additional driver.
     */
    public boolean getHasOtherItemsThatDoNotRequireAdditionalDriver() {
        return returnTrueIfAnyConditionIsTrue(new ConditionEvaluator<AgreementItem>() {

            public boolean evaluate(final AgreementItem entity) {
                return !entity.isInsuranceAdditionalDriverLicenseRequired();
            }
        });
    }

    /**
     * The method that returns true if in the items collection we have items that are returned but not paid.
     * @return true if items are there which are returned but not paid.
     */
    public boolean hasItemsThatAreReturnedButNotPaid() {
        return returnTrueIfAnyConditionIsTrue(new ConditionEvaluator<AgreementItem>() {

            public boolean evaluate(final AgreementItem entity) {
                return entity.isReturned();
            }
        });
    }

    /**
     * Returns true if none of the items are returned or renturned and paid complete.
     * @return true if all items are checkedout or checkedout and paid complete
     */
    public boolean isEveryItemCheckedOutOrCheckedOutAndPaidInitial() {
        return returnFalseIfAnyConditionIsFalse(new ConditionEvaluator<AgreementItem>() {

            /**
             * {@inheritDoc}
             */
            public boolean evaluate(final AgreementItem entity) {
                return (!entity.isReturned() && !entity.isReturnedAndPaidComplete());
            }
        });
    }

    /**
     * Returns the earliest due by date from the list of items held by this collection.
     * @return the earliers due by date.
     */
    public Calendar getUpcomingDueBy() {
        Calendar upcomingDueBy = null;
        for (AgreementItem agreementItem : getEntities()) {
            if (((null == upcomingDueBy)
                    || (upcomingDueBy.after(agreementItem.getDueBy()))
                    ) && (!(agreementItem.isReturned() || agreementItem.isReturnedAndPaidComplete()))) {
                upcomingDueBy = agreementItem.getDueBy();
            }
        }
        return upcomingDueBy;
    }

    /**
     * Returns the collection of current checkedin items.
     * @return the AgreementItemCollection of items currently Checkedin.
     */
    public AgreementItemCollection getCurrentlyCheckedInItems() {
        return new AgreementItemCollection(returnEntitiesIfConditionIsTrue(new ConditionEvaluator<AgreementItem>() {
            public boolean evaluate(final AgreementItem entity) {
                return entity.isCheckedin();
            }
        }));
    }

    /**
	 * Contains by id.
	 *
	 * @param agreementItem the agreement item
	 * @return true, if successful
	 */
	private boolean containsById(final AgreementItem agreementItem) {
		return returnTrueIfAnyConditionIsTrue(new ConditionEvaluator<AgreementItem>() {

			public boolean evaluate(final AgreementItem entity) {
				return entity.getId().equals(agreementItem.getId());
			}
		});
	}
	/**
	 * update due by date
	 * @param transactionDate
	 */
    public void updateDueByDate(final Calendar transactionDate) {
        doInLoop(new ExpressionEvaluator<AgreementItem>() {

            public void evaluate(final AgreementItem entity) {
            	if(!(entity.isReturned() || entity.isReturnedAndPaidComplete())){
                entity.setDueBy(transactionDate);
                entity.calculateEstimatedChargesAndDuration();
                }
            }
        });
    }
}
