/*
 * DifferentDaysIncrementalHoursCalculationRule.java
 */
package com.menards.rental.domain.rule;

import com.menards.rental.domain.StoreHourBasedRentalDateRange;

/**
 * The calculation rule that calculates the difference of days between the checkin and checkout dates.
 * @author deep
 */
public class DiffDaysIncreHrsCalcRule implements IncrementalHoursCalculationRule {

	/** The base sku hr qty. */
	private final double baseSkuHrQty;

	/** The incremental sku hr qty. */
	private final double incrementalSkuHrQty;

	/** The rental date range. */
	private final StoreHourBasedRentalDateRange rentalDateRange;

	/**
	 * Instantiates a new different days incremental hours calculation rule.
	 *
	 * @param baseSkuHrQty the base sku hr qty
	 * @param incrementalSkuHrQty the incremental sku hr qty
	 * @param rentalDateRange the rental date range
	 */
	public DiffDaysIncreHrsCalcRule(final double baseSkuHrQty, final double incrementalSkuHrQty,
	        final StoreHourBasedRentalDateRange rentalDateRange) {
		this.baseSkuHrQty = baseSkuHrQty;
		this.incrementalSkuHrQty = incrementalSkuHrQty;
		this.rentalDateRange = rentalDateRange;
	}

    /**
     * {@inheritDoc} 
     * Calculate the incremental hours which is charged as addition.
     * Guests are charged hourly for the entire time the store is open.
     */
	public double calculate() {
		double totalAdditionalHours = 0;
		totalAdditionalHours = rentalDateRange.getActualDurationInHours() - baseSkuHrQty;
		/**
		 * Actual duration in hours should be greater than the base sku hour
		 * quantity, otherwise user don't need pay for the additional hours,
		 * that is, the additional hours should equal 0.
		 */
		if (totalAdditionalHours < 0) {
			totalAdditionalHours = 0;
		}
		return totalAdditionalHours;
	}
	
}
