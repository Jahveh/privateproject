/**
 * OutOfStockAuditTrailCollection.java
 */
package com.menards.rental.domain;

import java.util.*;

/**
 * The class represents a collection of out of stock audit trails.
 *
 * @author deep
 */
public class OutOfStockAuditTrailCollection extends CollectionUtil<OutOfStockAuditTrail> {

    /**
     * The constructor with entities as argument.
     * @param entities the collection of out of stock audit trail records.
     */
    public OutOfStockAuditTrailCollection(final Collection<OutOfStockAuditTrail> entities) {
        super(entities);
    }

    /**
     * Returns the set of distinct store numbers from the collection of trail records.
     * @return set of distinct store numbers.
     */
    public Set<Integer> getDistinctStoreNumbers() {
        final Set<Integer> storeNumbers = new LinkedHashSet<Integer>();
        doInLoop(new ExpressionEvaluator<OutOfStockAuditTrail>() {

            public void evaluate(final OutOfStockAuditTrail entity) {
                storeNumbers.add(entity.getStoreNumber());
            }
        });
        return storeNumbers;
    }

    /**
     * Returns the set of distinct product ids.
     * @return the set of distinct product ids.
     */
    public Set<Product> getDistinctProducts() {
        final HashSet<Product> products = new LinkedHashSet<Product>();
        doInLoop(new ExpressionEvaluator<OutOfStockAuditTrail>() {

            public void evaluate(final OutOfStockAuditTrail entity) {
                products.add(entity.getProduct());
            }
        });
        return products;
    }
}
