/**
 * StoreUserCollection.java
 */
package com.menards.rental.domain;

import com.menards.rental.utils.Constants;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * The collection of store user.
 *
 * @author deep
 */
public class StoreUserCollection extends CollectionUtil<StoreUserInfo> implements Cachable {

    /** The store number. */
    private final Integer storeNumber;

    /**
     * The constructor with the store users as argument.
     * @param storeUsers the store user collection.
     * @param storeNumber the store number associated with these users.
     */
    public StoreUserCollection(final Collection<StoreUserInfo> storeUsers, final Integer storeNumber) {
        super(storeUsers);
        this.storeNumber = storeNumber;
    }

    /**
     * Returns the cache key in this case the store number.
     * @return the store number which acts the cache key.
     */
    public Integer getKey() {
        return storeNumber;
    }

    /**
     * Returns the list of user names.
     * @return the list of user names.
     */
    public List<StoreUserInfo> getGeneralManagers() {
        final ArrayList<StoreUserInfo> userNames = new ArrayList<StoreUserInfo>();
        doInLoop(new ExpressionEvaluator<StoreUserInfo>() {

            public void evaluate(final StoreUserInfo entity) {
                if (Constants.TeamService.GENERAL_MANAGER.equals(entity.getPosition()) ||
                		Constants.TeamService.ASSISTANT_GENERAL_MANAGER.equals(entity.getPosition())) {
                    userNames.add(entity);
                }
            }
        });
        return userNames;
    }

    /**
     * The method that returns the store user reference that matches the given id.
     * @param id the user id which is to be found from the store user collection.
     * @return the matching store user info reference.
     */
    public StoreUserInfo getStoreUserById(final Integer id) {
        return returnEntityIfConditionIsTrue(new ConditionEvaluator<StoreUserInfo>() {

            public boolean evaluate(final StoreUserInfo entity) {
                return entity.getId().equals(id);
            }
        });
    }

    /**
     * Returns the collection of store users held by this collection.
     * @return the collection of store users.
     */
    public List<StoreUserInfo> getStoreUsers() {
        return new ArrayList<StoreUserInfo>(getEntities());
    }
}
