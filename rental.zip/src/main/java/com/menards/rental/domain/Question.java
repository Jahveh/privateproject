/*
 * Question.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;

/**
 * The question class.
 * @author deep
 */
@Entity
@RooJavaBean
@Table(name = "checklist_question")
@RooEntity(identifierColumn = "question_id")
public class Question implements Serializable {

	/** The text. */
	@Column(name = "question_txt", nullable = false)
	private String text;

    /** The sku value. */
    @Column(name = "sku", nullable = false)
    private Long sku;

    /** The charge amount for the question. */
    @Column(name = "charge_amt", nullable = false)
    private BigDecimal chargeAmount;

	/**
	 * Instantiates a new question.
	 */
	public Question() {
		this(null);
	}

	/**
	 * Instantiates a new question.
	 *
	 * @param text the text
	 */
	public Question(final String text) {
		this.text = text;
	}
}
