/*
 * ItemStatus.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Size;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;

/**
 * The Class ItemStatus.
 * @author deep
 */
@Entity
@RooJavaBean
@RooToString
@Table(name = "item_status", uniqueConstraints = @UniqueConstraint(columnNames = { "item_status_cd" }))
@RooEntity(identifierColumn = "item_status_id", finders = { "findItemStatusesByStatusCode" })
public class ItemStatus implements Serializable {

	/**
	 * The Enum Code.
	 */
	public static enum Code {

		/** The available code. */
		AVAILABLE('A'),

        /** The on hold code. */
		ON_HOLD('H'),

        /** The rented code. */
		RENTED('R'),

        /** The unrentable code. */
		UNRENTABLE('U'),

        /** The deleted code. */
		DELETED('D');

		/** The code. */
		private char code;

		/**
		 * Instantiates a new code.
		 *
		 * @param code the code
		 */
		private Code(final char code) {
			this.code = code;
		}

		/**
		 * Gets the code.
		 *
		 * @return the code
		 */
		public char getCode() {
			return code;
		}

		/**
		 * Checks if is match.
		 *
		 * @param code the code
		 * @return true, if is match
		 */
		public boolean isMatch(final char code) {
			return code == this.code;
		}

		/**
		 * Sets the code.
		 *
		 * @param code the new code
		 */
		public void setCode(final char code) {
			this.code = code;
		}
	}

	/** The status code. */
	@Column(name = "item_status_cd", nullable = false, columnDefinition = "char(1)")
	private char statusCode;

	/** The description. */
	@Column(name = "item_status_desc", nullable = false)
	@Size(max = 100)
	private String description;

	/**
     * The method that returns the list of rentable status.
     * @return the list of all rentable status
     */
    public static List<ItemStatus> findAllRentableStatuses() {
        return entityManager()
                .createQuery("select s from ItemStatus s where s.statusCode in ('A', 'H', 'R')")
                .getResultList();
    }

	/**
     * The method that returns the list of currently rentable status.
     * @return the list of all currently rentable status
     */
    public static List<ItemStatus> findAllCurrentlyRentableStatuses() {
        return entityManager()
                .createQuery("select s from ItemStatus s where s.statusCode in ('A', 'H')")
                .getResultList();
    }

	/**
	 * Find available.
	 *
	 * @return the item status
	 */
	public static ItemStatus findAvailable() {
		return findItemStatusByStatusCode(Code.AVAILABLE);
	}

	/**
	 * Find deleted.
	 *
	 * @return the item status
	 */
	public static ItemStatus findDeleted() {
		return findItemStatusByStatusCode(Code.DELETED);
	}

	/**
	 * Find on hold.
	 *
	 * @return the item status
	 */
	public static ItemStatus findOnHold() {
		return findItemStatusByStatusCode(Code.ON_HOLD);
	}

	/**
	 * Find rented.
	 *
	 * @return the item status
	 */
	public static ItemStatus findRented() {
		return findItemStatusByStatusCode(Code.RENTED);
	}

	/**
	 * Find unrentable.
	 *
	 * @return the item status
	 */
	public static ItemStatus findUnrentable() {
		return findItemStatusByStatusCode(Code.UNRENTABLE);
	}

	/**
	 * Find item status by status code.
	 *
	 * @param code the code
	 * @return the item status
	 */
	private static ItemStatus findItemStatusByStatusCode(final Code code) {
		return (ItemStatus) findItemStatusesByStatusCode(code.getCode()).getSingleResult();
	}

	/**
	 * Checks if is available.
	 *
	 * @return true, if is available
	 */
	public boolean isAvailable() {
		return (Code.AVAILABLE.isMatch(statusCode));
	}

	/**
	 * Checks if is deleted.
	 *
	 * @return true, if is deleted
	 */
	public boolean isDeleted() {
		return (Code.DELETED.isMatch(statusCode));
	}

	/**
	 * Checks if is on hold.
	 *
	 * @return true, if is on hold
	 */
	public boolean isOnHold() {
		return (Code.ON_HOLD.isMatch(statusCode));
	}

    /**
	 * Checks if is rented.
	 *
	 * @return true, if is rented
	 */
	public boolean isRented() {
		return (Code.RENTED.isMatch(statusCode));
	}

    /**
	 * Checks if is unrentable.
	 *
	 * @return true, if is unrentable
	 */
	public boolean isUnrentable() {
		return (Code.UNRENTABLE.isMatch(statusCode));
	}
}
