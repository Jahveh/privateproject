/*
 * ItemSerialNumberIncrement.java
 */
package com.menards.rental.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;

/**
 * The Class ItemSerialNumberIncrement.
 */
@Entity
@RooJavaBean
@RooToString
@Table(name = "item_serial_number_increment")
@RooEntity(finders = { "findItemSerialNumberIncrementsByStoreNumberAndProduct" })
public class ItemSerialNumberIncrement implements Serializable {

	/** The store number. */
	@Column(name = "store_nbr")
	private Integer storeNumber;

	/** The product. */
	@ManyToOne(optional = false)
	@JoinColumn(name = "product_id")
	private Product product;

	/** The current number. */
	@Column(name = "current_number")
	private Integer currentNumber;

	/**
	 * Creates the new item serial number increment.
	 *
	 * @param storeNumber the store number
	 * @param product the product
	 * @return the item serial number increment
	 */
	public static ItemSerialNumberIncrement createNewItemSerialNumberIncrement(final Integer storeNumber,
	        final Product product) {
		final ItemSerialNumberIncrement itemSerialNumberIncrement = new ItemSerialNumberIncrement();
		itemSerialNumberIncrement.setStoreNumber(storeNumber);
		itemSerialNumberIncrement.setProduct(product);

		// Set the first number to 10000 so that we have 5 digit placeholder
		// when we generate the serial number
		itemSerialNumberIncrement.setCurrentNumber(10000);
		return itemSerialNumberIncrement;
	}
}
