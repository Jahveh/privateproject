package com.menards.rental.domain.questions;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PersistenceContext;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Configurable;


/**
 * The persistent class for the question database table.
 * 
 */
@Configurable
@Entity
@Table(name = "question")
@NamedQuery(name="Quiz.findAll", query="SELECT q FROM Quiz q")
public class Quiz implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="question_id")
	private int questionId;

	@Column(name="question_text")
	private String questionText;

	//bi-directional many-to-one association to QuestionAnswerType
	@ManyToOne
	@JoinColumn(name="answer_type_id")
	private QuestionAnswerType questionAnswerType;

	//bi-directional many-to-one association to QuestionCategoryMap
	@OneToMany(mappedBy="question")
	private List<QuestionCategoryMap> questionCategoryMaps;

	public Quiz() {
	}

	public int getQuestionId() {
		return this.questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public String getQuestionText() {
		return this.questionText;
	}

	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}

	public QuestionAnswerType getQuestionAnswerType() {
		return this.questionAnswerType;
	}

	public void setQuestionAnswerType(QuestionAnswerType questionAnswerType) {
		this.questionAnswerType = questionAnswerType;
	}

	public List<QuestionCategoryMap> getQuestionCategoryMaps() {
		return this.questionCategoryMaps;
	}

	public void setQuestionCategoryMaps(List<QuestionCategoryMap> questionCategoryMaps) {
		this.questionCategoryMaps = questionCategoryMaps;
	}

	public QuestionCategoryMap addQuestionCategoryMap(QuestionCategoryMap questionCategoryMap) {
		getQuestionCategoryMaps().add(questionCategoryMap);
		questionCategoryMap.setQuestion(this);
		return questionCategoryMap;
	}

	public QuestionCategoryMap removeQuestionCategoryMap(QuestionCategoryMap questionCategoryMap) {
		getQuestionCategoryMaps().remove(questionCategoryMap);
		questionCategoryMap.setQuestion(null);

		return questionCategoryMap;
	}

}