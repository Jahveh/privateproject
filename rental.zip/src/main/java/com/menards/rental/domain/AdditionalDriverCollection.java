/*
 * AdditionalDrivers.java
 */
package com.menards.rental.domain;

import java.io.Serializable;
import java.util.Collection;

/**
 * The class representing the collection of Additional drivers.
 * @author deep
 */
public class AdditionalDriverCollection implements Serializable {

	/** The drivers. */
	private Collection<AdditionalDriver> drivers;

	/**
	 * Instantiates a new additional drivers.
	 *
	 * @param drivers the drivers
	 */
	public AdditionalDriverCollection(final Collection<AdditionalDriver> drivers) {
		this.drivers = drivers;
	}

	/**
	 * Gets the first additional driver.
	 *
	 * @return the first additional driver
	 */
	public AdditionalDriver getFirstAdditionalDriver() {
		if (drivers.isEmpty()) {
			return new AdditionalDriver();
		}

		return drivers.iterator().next();
	}
}
