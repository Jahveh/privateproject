package com.menards.rental.domain;

import java.math.BigDecimal;

/**
 * The kiosk project details that holds the details of base, incremental and surcharge sku if any.
 *
 * @author deep
 */
public class KioskProductDetail {

    /** The reference of base sku detail. */
    private KioskSKUDetail baseSKUDetail;

    /** The reference of incremental sku detail. */
    private KioskSKUDetail incrementalSKUDetail;

    /** The reference of surcharge sku detail. */
    private KioskSKUDetail surchargeSKUDetai;

    /**
     * Returns the base sku charge amount.
     * @return getter for base sku charge amount.
     */
    public BigDecimal getBaseSKUChargeAmount() {
        return baseSKUDetail.getChargeAmount();
    }

    /**
     * The getter for base sku detail.
     * @return the base sku detail.
     */
    public KioskSKUDetail getBaseSKUDetail() {
        return baseSKUDetail;
    }

    /**
     * Returns the incremental sku charge amount.
     * @return getter for incremental sku charge amount.
     */
    public BigDecimal getIncrementalSKUChargeAmount() {
        return incrementalSKUDetail.getChargeAmount();
    }

    /**
     * The getter for incremental sku detail.
     * @return the incremental sku detail.
     */
    public KioskSKUDetail getIncrementalSKUDetail() {
        return incrementalSKUDetail;
    }

    /**
     * Returns the surcharge sku charge amount.
     * @return getter for surcharge sku charge amount.
     */
    public BigDecimal getSurchargeSKUChargeAmount() {
        if (surchargeSKUDetai == null) {
            return null;
        }
        
        return surchargeSKUDetai.getChargeAmount();
    }

    /**
     * Getter for surcharge sku detail.
     * @return the surcharge sku detail.
     */
    public KioskSKUDetail getSurchargeSKUDetai() {
        return surchargeSKUDetai;
    }

    /**
     * Returns true if base sku is setup.
     * @return true if base sku is setup.
     */
    public boolean isBaseSKUSetup() {
        return baseSKUDetail != null;
    }

    /**
     * Setter for base sku detail.
     * @param baseSKUDetail the value.
     */
    public void setBaseSKUDetail(final KioskSKUDetail baseSKUDetail) {
        this.baseSKUDetail = baseSKUDetail;
    }

    /**
     * Setter for incremental sku detail.
     * @param incrementalSKUDetail the value.
     */
    public void setIncrementalSKUDetail(final KioskSKUDetail incrementalSKUDetail) {
        this.incrementalSKUDetail = incrementalSKUDetail;
    }

    /**
     * The setter for surcharge sku detail.
     * @param surchargeSKUDetai the value.
     */
    public void setSurchargeSKUDetai(final KioskSKUDetail surchargeSKUDetai) {
        this.surchargeSKUDetai = surchargeSKUDetai;
    }
}
