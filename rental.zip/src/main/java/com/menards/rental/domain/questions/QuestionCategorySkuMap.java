package com.menards.rental.domain.questions;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the question_category_sku_map database table.
 * 
 */
@Entity
@Table(name="question_category_sku_map")
@NamedQuery(name="QuestionCategorySkuMap.findAll", query="SELECT q FROM QuestionCategorySkuMap q")
public class QuestionCategorySkuMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="category_sku_map_id")
	private int id;

	@Column(name="sku_id")
	private int skuId;

	//bi-directional many-to-one association to QuestionCategory
	@ManyToOne
	@JoinColumn(name="category_id")
	private QuestionCategory questionCategory;

	public QuestionCategorySkuMap() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSkuId() {
		return this.skuId;
	}

	public void setSkuId(int skuId) {
		this.skuId = skuId;
	}

	public QuestionCategory getQuestionCategory() {
		return this.questionCategory;
	}

	public void setQuestionCategory(QuestionCategory questionCategory) {
		this.questionCategory = questionCategory;
	}

}