/*
 * ReservationAction.java
 */
package com.menards.rental.action;

import java.util.List;

import com.menards.rental.domain.*;
import com.menards.rental.service.NotificationService;
import com.menards.rental.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.webflow.action.MultiAction;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.menards.rental.service.GuestService;
import com.menards.rental.service.MenardsService;
import com.menards.rental.service.ReservationService;
import com.menards.rental.service.external.TeamService;

/**
 * The action class that is used during the reservation web-flow.  This class holds various methods that will be invoked
 * at various stages in the reservation flow.
 * @author deep
 */
@Component(value = "reservationAction")
public class ReservationAction extends MultiAction {

	/** The reservation service. */
	@Autowired
	private ReservationService reservationService;

	/** The Team service. */
	@Autowired
	private TeamService teamService;

	/** The agreement action. */
	@Autowired
	private AgreementAction agreementAction;

	/** The menards service. */
	@Autowired
	private MenardsService menardsService;
	
    /**
     * The guest service.
     */
    @Autowired
    private GuestService guestService;

    /** The notification service. */
    @Autowired
    private NotificationService notificationService;

    /**
	 * Adds the agreement item to agreement.
	 *
	 * @param agreement the agreement
	 * @param agreementItem the agreement item
	 * @param reservationAgreement the reservation agreement
	 * @param selectedReservationId the selected reservation id
	 * @param requestContext the request context
	 * @return the event
	 */
	public Event addAgreementItemToAgreement(final Agreement agreement, final AgreementItem agreementItem,
	        final ReservationAgreement reservationAgreement, final Long selectedReservationId,
	        final RequestContext requestContext) {
		final Event event = agreementAction.addAgreementItemToAgreement(agreement, agreementItem, requestContext);

		if (Constants.Action.SUCCESS.equals(event.getId())) {
            reservationAgreement.findReservationById(selectedReservationId).startProcessing();
        }
		return event;
	}

	/**
	 * Copy guest info.
	 *
	 * @param agreement the agreement
	 * @param reservationAgreement the reservation agreement
	 */
	public void copyGuestInfo(final Agreement agreement, final ReservationAgreement reservationAgreement) {
		if (null == agreement.getGuest()) {
            final Guest guest = new Guest();
            guest.copyFrom(reservationAgreement.getGuest());
            agreement.setGuest(guest);
		}
	}

	/**
	 * Creates the reservation.
	 *
	 * @param productId the product id
	 * @param agreement the agreement
	 * @param requestContext the request context
	 * @return the reservation
	 */
	public Reservation createReservation(final long productId, final ReservationAgreement agreement,
	        final RequestContext requestContext) {
		final Product product = Product.findProduct(productId);
		if (agreement.isReservationPresentFor(product)) {
			requestContext.getFlashScope().put(Constants.Reservation.ALREADY_RESERVED_ERROR, true);
			return null;
		}

        if (Item.countRentableItemsByProductAndStoreNumber(product, agreement.getStoreNumber()) == 0) {
            requestContext.getFlashScope().put(Constants.Reservation.RENTABLE_ITEMS_NOT_FOUND_ERROR, true);
            return null;
        }

        final Reservation reservation = reservationService.createReservation(product, agreement);
        if (reservation == null) {
            requestContext.getFlashScope().put(Constants.Agreement.KIOSK_ERROR, true);
        }
        return reservation;
	}

	/**
	 * Creates the reservation agreement.
	 *
	 * @return the reservation agreement
	 */
	public ReservationAgreement createReservationAgreement() {
		return reservationService.createReservationAgreement();
	}

	/**
	 * Edits the reservation form the given reservation agreement and with the given reservation product id.
	 *
	 * @param reservationAgreement the reservation agreement
	 * @param selectedProductId the selected product id
	 * @return the reservation that was edited.
	 */
	public final Reservation editReservationFor(final ReservationAgreement reservationAgreement,
	        final long selectedProductId) {
		return reservationAgreement.getReservationFor(selectedProductId);
	}

	/**
	 * Fulfill reservation.
	 *
	 * @param agreement the agreement.
	 * @param reservationAgreement the reservation agreement.
	 */
	public void fulfillReservation(final Agreement agreement, final ReservationAgreement reservationAgreement) {
		agreement.fulfillReservations();
		reservationAgreement.fulfillIfAllReservationsFulfilledOrCancelled();
		reservationAgreement.merge();
	}

	/**
	 * Gets the all general manager for store.
	 *
	 * @return the all general manager
	 */
	public List<StoreUserInfo> getAllManagers() {
		return teamService.getGeneralManagerForCurrentStore();
	}

    /**
	 * Gets the all products.
	 *
	 * @return the all products
	 */
	public List<Product> getAllProducts() {
		return Product.findAllProducts();
	}

	/**
	 * Gets the rental item to edit.
	 *
	 * @param agreement the agreement
	 * @param reservationAgreement the reservation agreement
	 * @param itemSerialNumber the item serial number
	 * @param selectedReservationId the selected reservation id
	 * @param requestContext the request context
	 * @return the rental item to edit
	 */
	public AgreementItem getRentalItemToEdit(final Agreement agreement,
	        final ReservationAgreement reservationAgreement, final Long itemSerialNumber,
	        final Long selectedReservationId, final RequestContext requestContext) {
		final Reservation reservation = reservationAgreement.findReservationById(selectedReservationId);
		final AgreementItem agreementItem = agreementAction.getRentalItemToAdd(agreement, itemSerialNumber,
		        requestContext);

		if (null == agreementItem) {
            logger.error("InvalidArgument to edit the item agreementItem should be not null");
			return null;
		}

		if (reservation.isForSameProduct(agreementItem)) {
			reservation.prepareAgreementItem(agreementItem);
			return agreementItem;
		}

		requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS,
                Constants.Reservation.INVALID_ITEM_RESERVATION_COMBINATION_ERROR);
		return null;
	}

	/**
	 * Load reservation agreement.
	 *
	 * @param reservationAgreementId the reservation agreement id
	 * @return the reservation agreement
	 */
	public ReservationAgreement loadReservationAgreement(final long reservationAgreementId) {
		return ReservationAgreement.loadFull(reservationAgreementId);
	}

	/**
	 * Populate active item andreservations by current store.
	 *
	 * @param productId the product id
	 * @param requestContext the request context
	 */
	public void populateActiveItemAndReservationsByCurrentStore(final Long productId,
	        final RequestContext requestContext) {
		final Store store = menardsService.getCurrentStore();
		populateActiveItemAndReservationByStoreNumber(productId, requestContext, store.getStoreNumber());
	}

	/**
	 * Populate active item and reservations for.
	 *
	 * @param productId the product id
	 * @param reservationAgreement the reservation agreement
	 * @param requestContext the request context
	 */
	public void populateActiveItemAndReservationsFor(final Long productId,
	        final ReservationAgreement reservationAgreement, final RequestContext requestContext) {
		populateActiveItemAndReservationByStoreNumber(productId, requestContext, reservationAgreement
		        .getStoreNumber());
	}

	/**
	 * Removes the reservation for.
	 *
	 * @param reservationAgreement the reservation agreement
	 * @param selectedProductId the selected product id
	 */
	public void removeReservationFor(final ReservationAgreement reservationAgreement, final long selectedProductId) {
		reservationAgreement.removeReservationFor(selectedProductId);
	}

	/**
	 * Removes the temporary reservation.
	 *
	 * @param requestContext the request context
	 */
	public void removeTemporaryReservation(final RequestContext requestContext) {
        final ReservationAgreement reservationAgreement = (ReservationAgreement) requestContext
                .getFlowScope().get(Constants.Reservation.RESERVATION_AGREEMENT_KEY);
        reservationAgreement.removeReservation((Reservation) requestContext.getViewScope()
                .remove(Constants.Reservation.RESERVATION_KEY));
	}

	/**
	 * Reserve the chosen product and return success if product was successfully reserved else return error.
	 *
	 * @param reservation the reservation.
	 * @param reservationAgreement the reservation agreement.
	 * @param requestContext the request context.
	 * @return the event representing whether the reservation was successful or not.
	 */
	public Event reserveProduct(final Reservation reservation, final ReservationAgreement reservationAgreement,
	        final RequestContext requestContext) {
		final Product product = Product.findProduct(reservation.getProduct().getId());

		if (reservationService.isReservationPossible(product, reservation, reservationAgreement)) {
			reservationAgreement.addReservation(reservation);
            reservationService.calculateEstimatedChargesAndDuration(reservation);
			return success();
		}
		requestContext.getFlashScope().put(
		        Constants.Reservation.CONFLICTING_RESERVATIONS_KEY,
		        product.getOverlappingOpenReservationsForStore(reservationAgreement.getStoreNumber(), reservation
		                .getCheckOutTimeStamp(), reservation.getCheckInTimeStamp()));
		return error();
	}

    /**
     * Updates the estimated charges and duration based on the new time stamp that we might have received.
     * @param reservation the reservation to update.
     */
    public void updateEstimatedChargesAndDuration(final Reservation reservation) {
        reservationService.calculateEstimatedChargesAndDuration(reservation);
    }
	
	/**
	 * Saves the reservation agreement in the db.
	 *
	 * @param reservationAgreement the reservation agreement to save.
	 * @param requestContext the request context the .
	 * @return the reservation agreement.
	 */
	public ReservationAgreement save(final ReservationAgreement reservationAgreement,
	        final RequestContext requestContext) {
        if (saveReservationAgreement(reservationAgreement, requestContext)) {
            notificationService.sendReservationNotificationFor(reservationAgreement);
            requestContext.getFlashScope().put(Constants.Agreement.SHOW_REPORT, true);
            return loadReservationAgreement(reservationAgreement.getId());
        }
        return reservationAgreement;
    }

    /**
     * Saves the reservation.  This method is called when team member clicks save notes.
     * @param reservationAgreement the reservation agreement to be saved.
     * @param requestContext the request context reference so that we could give feedback to the user.
     * @return the fully loaded reservation agreement reference.
     */
    public ReservationAgreement saveNotes(final ReservationAgreement reservationAgreement,
                                          final RequestContext requestContext) {
        if (saveReservationAgreement(reservationAgreement, requestContext)) {
            return loadReservationAgreement(reservationAgreement.getId());
        }
        return reservationAgreement;
    }

    /**
     * The method that populates the tm name from the tm number that was ented by the user.  This is required sot that
     * when we mail the reservation pdf to the user it has the tm name and not the number on it.
     * @param reservationAgreement the reservation agreement for which we have to find the tm name from the tm number.
     */
    public void populateTMNameFromTMNumber(final ReservationAgreement reservationAgreement) {
        reservationService.populateTMNameFromTMNumber(reservationAgreement);
    }

    /**
     * The method that will check whether the guest meets the minimum age limit for all the products
     * that he is reserving.
     * @param reservationAgreement the reservation agreement holding all the reservations.
     * @param requestContext the requeset context so that we could populate any error.
     * @return Event success if guest meets the criteria, error otherwise.
     */
    public Event addGuest(final ReservationAgreement reservationAgreement, final RequestContext requestContext) {
        if (reservationAgreement.isGuestAgeGreaterThanMinimumAge()) {
            return success();
        }
        requestContext.getFlashScope().put(Constants.Agreement.MIN_AGE_LIMIT_NOT_MET, true);
        return error();
    }

	/**
	 * Sets the agreement action.
	 *
	 * @param agreementAction the new agreement action
	 */
	public void setAgreementAction(final AgreementAction agreementAction) {
		this.agreementAction = agreementAction;
	}

	/**
	 * Sets the menards service.
	 *
	 * @param menardsService the new menards service
	 */
	public void setMenardsService(final MenardsService menardsService) {
		this.menardsService = menardsService;
	}

    /**
     * The setter for the notification service.
     * @param notificationService the value to set.
     */
	public void setNotificationService(final NotificationService notificationService) {
        this.notificationService = notificationService;
    }

	/**
	 * Sets the reservation service.
	 *
	 * @param reservationService the new reservation service
	 */
	public void setReservationService(final ReservationService reservationService) {
		this.reservationService = reservationService;
	}

	/**
	 * Sets the Team service.
	 *
	 * @param teamService the team service
	 */
	public void setTeamService(final TeamService teamService) {
		this.teamService = teamService;
	}

    /**
	 * Populate active item and reservation by store number.
	 *
	 * @param productId the product id
	 * @param requestContext the request context
	 * @param storeNumber the store number
	 */
	private void populateActiveItemAndReservationByStoreNumber(final Long productId,
	        final RequestContext requestContext, final Integer storeNumber) {
		final Product product = Product.findProduct(productId);

		requestContext.getViewScope().put(Constants.Reservation.ITEM_LIST_KEY,
                Item.findAllItemsByProductAndStoreNumber(product, storeNumber));

		requestContext.getViewScope().put(Constants.Reservation.RESERVATION_LIST_KEY,
                product.getOpenReservationsFor(storeNumber));
	}

    /**
     * Saves the reservation agreement to the db and returnes true if everything goes fine.
     * @param reservationAgreement the agreement to be saved.
     * @param requestContext the request context reference so that we could populate any errors if they occur.
     * @return true if reservation was saved successfully, false otherwise.
     */
    private boolean saveReservationAgreement(final ReservationAgreement reservationAgreement,
                                             final RequestContext requestContext) {
        if (!reservationAgreement.hasReservations()) {
            requestContext.getFlashScope().put(Constants.Reservation.NO_RESERVATIONS_FOUND_ERROR, true);
            return false;
        }
        try {
		    reservationService.save(reservationAgreement);
            return true;
        } catch (final RuntimeException e) {
            requestContext.getFlashScope().put(Constants.Reservation.COULD_NOT_SAVE_RESERVATIONS_ERROR, true);
        }
        return false;
    }
}
