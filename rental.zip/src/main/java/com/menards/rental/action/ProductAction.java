/*
 * ProductAction.java
 */
package com.menards.rental.action;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.webflow.execution.RequestContext;

import com.menards.rental.domain.Product;
import com.menards.rental.domain.RentalSKU;
import com.menards.rental.domain.SKUCollection;
import com.menards.rental.service.ProductService;

/**
 * Handles the product creation and editing logic.
 *
 * @author deep
 */
@Component(value = "productAction")
public class ProductAction {

	/** The product service. */
	@Autowired
	private ProductService productService;

	/**
	 * Populate the pre-requisits for showing the setupSku page.
	 *
	 * @param requestContext the skus will be populated in the request scope.
	 */
	public void populateSKU(final RequestContext requestContext) {
		final SKUCollection skus = new SKUCollection(RentalSKU.findAllSKUSOrderedByTypeAndValue());
		requestContext.getRequestScope().put("baseSKUs", skus.getBaseSKUs());
		requestContext.getRequestScope().put("incrementalSKUs", skus.getIncrementalSKUs());
		requestContext.getRequestScope().put("sellingSKUs", skus.getSellingSKUs());
		requestContext.getRequestScope().put("surchargeSKUs", skus.getSurchargeSKUs());
	}

	/**
	 * Saves the product.
	 *
	 * @param productToSave the product
	 */
	public void save(final Product productToSave) {
        final Product existingProduct = Product.findProductByBaseSKUId(productToSave.getBaskSKUId());
        if (existingProduct == null) {
            productService.save(productToSave);
            return;
        }
        productService.merge(existingProduct, productToSave);
	}

	/**
	 * Sets the product service.
	 *
	 * @param productService the new product service
	 */
	public void setProductService(final ProductService productService) {
		this.productService = productService;
	}
}
