package com.menards.rental.action;

import com.menards.rental.dao.SearchDao;
import com.menards.rental.domain.Product;
import com.menards.rental.domain.RentalSKU;
import com.menards.rental.service.ContextService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * The class that is used in various flows to search sku information.
 *
 * @author deep
 */
@Component(value = "searchAction")
public class SearchAction {

    /** The context service. */
    @Autowired
    private ContextService contextService;

    /** The serach dao reference. */
    @Autowired
    private SearchDao searchDao;

    /**
     * The method returns an instance of sku which will be used during the search flow.
     * @return the rental sku reference.
     */
    public RentalSKU createEmptySKU() {
        return new RentalSKU();
    }

    /**
     * Returns the list of products with their items for the current store.
     * @param baseSKU the base sku search parameter which is the filter criteria for us.  If null is passed all
     * skus will be searched.
     * @return the list of products for the current store.
     */
    public List<Product> getAllMatchingProductsForCurrentStore(final RentalSKU baseSKU) {
        return searchDao.getAllMatchingProductsForStore(contextService.getStoreNumber(), baseSKU);
    }

    /**
     * The setter for the context service.
     * @param contextService the value.
     */
    public void setContextService(final ContextService contextService) {
        this.contextService = contextService;
    }

    /**
     * The setter for the search dao.
     * @param searchDao the value.
     */
    public void setSearchDao(final SearchDao searchDao) {
        this.searchDao = searchDao;
    }
}
