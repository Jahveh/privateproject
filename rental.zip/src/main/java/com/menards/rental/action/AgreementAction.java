/*
 * AgreementAction.java
 */
package com.menards.rental.action;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.webflow.action.MultiAction;
import org.springframework.webflow.context.servlet.ServletExternalContext;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;
import org.springframework.webflow.execution.RequestContextHolder;

import com.menards.guest.common.GuestAccount;
import com.menards.guest.common.GuestAccount.Address;
import com.menards.guest.common.GuestAccount.Phone;
import com.menards.guest.common.GuestAccountUtils;
import com.menards.mymenards.integration.vo.SecureUser;
import com.menards.rental.domain.AdditionalDriver;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.ChecklistAnswer;
import com.menards.rental.domain.Guest;
import com.menards.rental.domain.Item;
import com.menards.rental.domain.OverrideReason;
import com.menards.rental.domain.Question;
import com.menards.rental.domain.SelectedAgreementItems;
import com.menards.rental.domain.StoreUserInfo;
import com.menards.rental.dto.QuestionDto;
import com.menards.rental.dto.QuestionFollowUpDto;
import com.menards.rental.repository.QuizRepository;
import com.menards.rental.security.MenardsUser;
import com.menards.rental.service.AgreementService;
import com.menards.rental.service.EmailService;
import com.menards.rental.service.ReservationService;
import com.menards.rental.service.external.TeamService;
import com.menards.rental.utils.ApplicationControl;
import com.menards.rental.utils.MenardsProperties;
import com.menards.rental.utils.Constants;

/**
 * The action class that will be used during the agreement flow.
 * @author deep
 */
@Component(value = "agreementAction")
public class AgreementAction extends MultiAction {

	private static final Logger log = Logger.getLogger(AgreementAction.class);
	
	@Autowired
	private QuizRepository questionRepository;
	
    /**
     * The agreement service.
     */
    @Autowired
    private AgreementService agreementService;

    @Autowired
    private EmailService emailService;
    
    /**
     * The Team service.
     */
    @Autowired
    private TeamService teamService;

    /**
     * The reservation service.
     */
    @Autowired
    private ReservationService reservationService;

    /** The menards properties reference. */
    @Autowired
    private MenardsProperties menardsProperties;
    
    /**
	 * Adds the agreement item to agreement.
	 *
	 * @param agreement the agreement
	 * @param agreementItem the agreement item
	 * @param requestContext the request context
	 * @return the event
	 */
	public Event addAgreementItemToAgreement(final Agreement agreement, final AgreementItem agreementItem,
	        final RequestContext requestContext) {
		final Item item = Item.findItemBySerialNumber(agreementItem.getSerialNumber());
		if (null == item) {
			requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.NOT_FOUND);
			return error();
		}

		final Calendar expectedCheckOutDate = Calendar.getInstance();
		if (!agreementItem.isReservationBeingFulfilledOrHasReservationOverride()
		        && !reservationService.hasNoConflictingReservation(item, expectedCheckOutDate, agreementItem
		                .getDueBy())) {
			requestContext.getFlashScope().put(Constants.Agreement.CONFLICTING_RESERVATIONS,
			        item.getOverlappingOpenReservationsFor(expectedCheckOutDate, agreementItem.getDueBy()));
			return error();
		}
		Long baseSkuValue = item.getProduct().getBaseSkuValue();
		agreementService.addAgreementItemToAgreement(agreement, agreementItem, item);
		return success();
	}

	
    /**
	 * Adds the agreement items to agreement.
	 *
	 * @param agreement the agreement
	 * @param selectedAgreementItems the selected agreement items
	 * @param requestContext the request context
	 * @return the event
	 */
	public Event addAgreementItemsToAgreement(final Agreement agreement, final SelectedAgreementItems selectedAgreementItems,
	        final String usageOutNumberList, final RequestContext requestContext) {

		// Parse out the serial number and usage numbers into a HashMap
		HashMap<String,String> productUsageNumbers = null;
		if( usageOutNumberList != null && !usageOutNumberList.isEmpty() ){
			final List<String> productUsageNumberList = new ArrayList<String>(Arrays.asList(usageOutNumberList.split("\\s*,\\s*")));
			productUsageNumbers = new HashMap<String,String>();
			for( String nvString : productUsageNumberList ){
				StringTokenizer prodTok = new StringTokenizer(nvString, ":");
				// Serial Number:Usage Out Number
				productUsageNumbers.put(prodTok.nextToken(), prodTok.nextToken());
			}
		}
		
		final List<AgreementItem> itemList = selectedAgreementItems.getAllItems();

		for( AgreementItem agreementItem : itemList ){
			final Item item = Item.findItemBySerialNumber(agreementItem.getSerialNumber());
			if (null == item) {
				requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.NOT_FOUND);
				return error();
			}
	
			// There is only one dueBy date, we need to set it on each item individually.
			agreementItem.setDueBy(selectedAgreementItems.getDueBy());
			
			// There is only one checkout date, we need to set it on each item individually.
			agreementItem.getChargeInfo().setCheckoutDate(selectedAgreementItems.getCheckoutDate());

			// There is only one comment, we need to set it on each item individually.
			agreementItem.setOverallComment(selectedAgreementItems.getOverallComment());

			// Set the usage out number
			String serialNumber = agreementItem.getItem().getSerialNumber().toString();
			if( productUsageNumbers != null && productUsageNumbers.containsKey(serialNumber) ){
				agreementItem.setUsageOutNumber(new Double(productUsageNumbers.get(serialNumber)));
			}
			
			final Calendar expectedCheckOutDate = Calendar.getInstance();
			if (!agreementItem.isReservationBeingFulfilledOrHasReservationOverride()
			        && !reservationService.hasNoConflictingReservation(item, expectedCheckOutDate, agreementItem
			                .getDueBy())) {
				requestContext.getFlashScope().put(Constants.Agreement.CONFLICTING_RESERVATIONS,
				        item.getOverlappingOpenReservationsFor(expectedCheckOutDate, agreementItem.getDueBy()));
				return error();
			}
	
			agreementService.addAgreementItemToAgreement(agreement, agreementItem, item);
		}
		return success();
	}
	
	/**
     * Adds the guest and driver information.
     *
     * @param destination    the destination
     * @param requestContext the request context
     * @return the event
     */
    public Event addGuestAndDriverInformation(final Agreement destination, final RequestContext requestContext) {
        if (!destination.isDriverAgeGreaterThanMinimumRentalAge()) {
            requestContext.getFlashScope().put(Constants.Agreement.MIN_AGE_LIMIT_NOT_MET, true);
            return error();
        }

        destination.mergeVehicleRentalDetails();
        return success();
    }

	/**
     * Adds the id and insurance information.
     *
     * @param agreement    the Agreement
     * @param requestContext the request context
     * @return the event
     */
    public Event addIdAndInsuranceInformation(final Agreement agreement, final RequestContext requestContext) {
        if( !agreement.isDriverAgeGreaterThanMinimumRentalAge() ) {
            requestContext.getFlashScope().put(Constants.Agreement.MIN_AGE_LIMIT_NOT_MET, true);
            return error();
        }

        agreement.mergeVehicleRentalDetails();
        return success();
    }

	/**
     * Adds the id and insurance information.
     *
     * @param agreement    the Agreement
     * @param requestContext the request context
     * @return the event
     */
    public Event addAdditionalDriverInformation(final Agreement agreement, final RequestContext requestContext) {
        if( !agreement.isDriverAgeGreaterThanMinimumRentalAge() ) {
            requestContext.getFlashScope().put(Constants.Agreement.MIN_AGE_LIMIT_NOT_MET, true);
            return error();
        }

        agreement.mergeVehicleRentalDetails();
        return success();
    }
    /**
     * recalculate the amount of  the agreement
     * @param dueBy the dueby when equipment is returned
     * @param agreement the agreement
     * @return
     */
    public Agreement reCalculateAmount(final String dueBy,final Agreement agreement) {
	    if(null != agreement && null !=agreement.getId()){
	    	return agreementService.reCalculateAmount(dueBy,agreement);
	    }
		return agreement;
	}
    /**
     * save a extend date
     * @param dueBy new Date
     * @param agreement
     * @param requestContext
     * @return
     */
    public Event extendCheckInDate(final String dueBy,final Agreement agreement,final RequestContext requestContext) {
    	Agreement newAgreement=agreementService.mergeAgreement(dueBy,agreement);
	    	updateFlowScopeAgreement(newAgreement,requestContext);
	    	return success();
	}
    /**
     * Get all AgreementItems of current agreement
     * @param agreement
     * @return
     */
    public SelectedAgreementItems getSelectedAgreementItems(final Agreement agreement) {
    	Calendar checkinDate=Calendar.getInstance();
    	if(agreement.getAgreementLog()!=null&&agreement.getAgreementLog().getPreDueBy()!=null){
    	    checkinDate=agreement.getAgreementLog().getPreDueBy();
    	}else{
    		checkinDate=agreement.getUpcomingDueBy();
    	}
    	Calendar dueBy=Calendar.getInstance();
    	dueBy.setTime(checkinDate.getTime());
    	dueBy.add(Calendar.DATE, 5);
    	SelectedAgreementItems selectedAgreementItems= new SelectedAgreementItems(agreement.getItemList());
    	selectedAgreementItems.setCheckinDate(checkinDate);
    	selectedAgreementItems.setDueBy(dueBy);
        return selectedAgreementItems;
    }
    /**
     * Checkin marked items.
     *
     * @param agreement      the agreement
     * @param requestContext the request context
     */
    public void checkinMarkedItems(final Agreement agreement, final RequestContext requestContext) {
        if (!validateCheckIn(agreement, requestContext)) {
        	return;
        }
        doCheckInFollowUp(agreement);
    	final String oldAgreementNumber = agreement.getAgreementNumber();
        agreementService.checkinMarkedItems(agreement);
        agreementService.syncInventoryForCheckedInItems(agreement);

        final Agreement savedAgreement = Agreement.findAgreement(agreement.getId());

        if (savedAgreement != null && savedAgreement.isNoTotalAdditionalChargeApplicable()) {
            agreementService.makeAgreementCompleteIfPossible(
                    savedAgreement, Calendar.getInstance());
        }

        requestContext.getFlowScope().put(Constants.Agreement.NOT_EDITABLE, true);

        if(sendAgreementToKioskServer(savedAgreement, oldAgreementNumber, requestContext)) {
            requestContext.getFlashScope().put(Constants.Agreement.SHOW_REPORT, true);
        };
        
    }
    
    /**
     * do check in follow-ups by sending emails to front end managers based on the quesion answers 
     * @param agreement rental agreement object
     */
    private void doCheckInFollowUp(final Agreement agreement) {
    	agreement.getCheckinDate().add(Calendar.DATE, 5);
    	Integer checkinTeamMember = agreement.getCheckinTeamMember();
    	Integer storeNumber = agreement.getStoreNumber();
    	String frontEndManagerEmail = teamService.getFrontEndManagerEmailFor(storeNumber);
    	frontEndManagerEmail = "fpeng9943@menards.net";
    	List<String> genericMailMessageContent = new ArrayList<String>();
    	for (AgreementItem agreementItem : agreement.getItems()) {
    		if (agreementItem.isCheckedin()) {
    			agreementItem.setCheckinTeamMember(checkinTeamMember);
    			for (QuestionDto questionDto : agreementItem.getCheckInQuestionList()) {
    				if ("NO".equals(questionDto.getAnswer())) {//if any question's answer is NO, then save it in a temp list, then send the whole list to FEM through email.
    					genericMailMessageContent.add("Agreement Item Serial Number: " + agreementItem.getSerialNumber() + " | " + questionDto.getQuestionText() + " -> NO");
    				}
    				if (questionDto.getQuestionFollowUpDto() != null) {
	    				QuestionFollowUpDto questionFollowUpDto = questionDto.getQuestionFollowUpDto();
	    				if (questionDto.getAnswer().equals(questionFollowUpDto.getFollowUpTrigger()) &&//if the answer needs follow-up
	    						questionFollowUpDto.getQuestionFollowUpTypeId() == 3 && // if the follow-up type is send to manual email
	    						StringUtils.isNotEmpty(questionFollowUpDto.getFollowUpContent())) {//if the manual email content is not empty
	    					emailService.sendEmailMessage(frontEndManagerEmail, 
	    							"[FOLLOW-UP NEEDED] Checking In Agreement # " + agreement.getAgreementNbr(), 
	    							questionFollowUpDto.getFollowUpContent());
	    				}
    				}
    			}
    		}
    	}
    	if (!genericMailMessageContent.isEmpty()) {
    		sendGenericMailMessage(frontEndManagerEmail, agreement.getAgreementNbr(), genericMailMessageContent);
    	}
    }
    
    /**
     * Send email to front end managers as long as there is any "NO" answer for any of the questions.
     * @param frontEndManagerEmail
     * @param agreementNumber
     * @param genericMailMessageContent
     */
    private void sendGenericMailMessage(String frontEndManagerEmail, String agreementNumber, List<String> genericMailMessageContent) {
    	String messageContent = StringUtils.join(genericMailMessageContent, "\n");
    	emailService.sendEmailMessage(frontEndManagerEmail, 
				"[FOLLOW-UP NEEDED] Checking In Agreement # " + agreementNumber, 
				messageContent);
    }
    
    /**
     * Validate check-in parameters which include team member number check and question answer check.
     * @param agreement
     * @param requestContext
     * @return
     */
    private boolean validateCheckIn(final Agreement agreement, final RequestContext requestContext) {
    	boolean result = true;
    	result = validateCheckInTeamMember(requestContext);
    	for (AgreementItem agreementItem : agreement.getItems()) {
    		if (agreementItem.isCheckedin()) {
    			for (QuestionDto questionDto : agreementItem.getCheckInQuestionList()) {
    				if (questionDto.getAnswer() == null) {
    					requestContext.getFlashScope().put(Constants.Agreement.QUESTION_NOT_ANSWERED, true);
    					return false;
    				}
    			}
    		}
    	}
    	return result;
    }
    
    /**
     * validate team member number from user input
     * @param requestContext
     * @return
     */
    private boolean validateCheckInTeamMember(final RequestContext requestContext) {
    	boolean result = true;
    	String checkInTeamMember = requestContext.getExternalContext().getRequestParameterMap().get("checkinTeamMember");
    	if (StringUtils.isEmpty(checkInTeamMember)) {
    		result = false;
    		requestContext.getFlashScope().put(Constants.Agreement.CHECK_IN_TEAM_MEMBER_REQUIRED, true);
    	}
    	return result;
    }
    
    /**
     * Ensure guest initialized.
     *
     * @param agreement the agreement
     */
    public void ensureGuestInitialized(final Agreement agreement) {
        if (null == agreement.getGuest()) {
            agreement.setGuest(new Guest());
        }
    }

    /**
     * Gets the checklist questions for.
     *
     * @param agreement               the agreement
     * @param checkinItemSerialNumber the checkin item serial number
     * @return the checklist questions for
     */
    public AgreementItem getChecklistQuestionsFor(final Agreement agreement, final Long checkinItemSerialNumber) {
        final AgreementItem agreementItem = agreement.findItemBySerialNumber(checkinItemSerialNumber);
        agreementItem.setCheckinDate(agreement.getCheckinDate());
        return agreementItem;
    }

    /**
     * Gets the all checklist questions for.
     *
     * @param agreement               the agreement
     * @param selectedSerialNumbers 	the selected checkin items serial numbers
     * @return the checklist questions for
     */
    public SelectedAgreementItems getMultiItemChecklistQuestions(final Agreement agreement, final String selectedSerialNumbers) {
		List<AgreementItem> agreementItemList = null;

    	if( null == selectedSerialNumbers || selectedSerialNumbers.isEmpty() ) {
			return null;
		}
		
		List<String> serialNumbers = new ArrayList<String>(Arrays.asList(selectedSerialNumbers.split("\\s*,\\s*")));
		
		for(String serialNumber : serialNumbers){
	        final AgreementItem agreementItem = agreement.findItemBySerialNumber(new Long(serialNumber));
	        agreementItem.setCheckinDate(agreement.getCheckinDate());
	        
	        if( agreementItemList == null ){
	        	agreementItemList = new ArrayList<AgreementItem>();
	        }
	        agreementItemList.add(agreementItem);
		}
        return new SelectedAgreementItems(agreementItemList);
    }

    /**
	 * Gets the rental item to add.
	 *
	 * @param agreement the agreement
	 * @param serialNumber the serial number
	 * @param requestContext the request context
	 * @return the rental item to add
	 */
	public AgreementItem getRentalItemToAdd(final Agreement agreement, final Long serialNumber,
	        final RequestContext requestContext) {
		if (null == serialNumber) {
			requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.NOT_FOUND);
			return null;
		}

		final Item item = Item.findItemBySerialNumber(serialNumber);
		if (null == item) {
			requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.NOT_FOUND);
			return null;
		}

		// Check if item is already part of agreement
		if (agreement.isItemPartOfAgreement(item)) {
			requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.ALREADY_ADDED);
			return null;
		}

		// Check if item is on hold
		if (!item.isAvailable()) {
			requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.ON_HOLD);
			return null;
		}

        final AgreementItem agreementItem = agreementService.createNewAgreementItem(item, agreement);

        if (agreementItem == null) {
            requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.KIOSK_ERROR);
            return null;
        }
        
        requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.FOUND);
        return agreementItem;
	}

	
    /**
	 * Gets the rental items to add.
	 *
	 * @param agreement the agreement
	 * @param selectedSerialNumbers the serial number
	 * @param requestContext the request context
	 * @return the rental items to add
	 */
	public SelectedAgreementItems getRentalItemsToAdd(final Agreement agreement, final String selectedSerialNumbers,
	        final RequestContext requestContext) {
		List<AgreementItem> agreementItemList = null;
		
		if( null == selectedSerialNumbers || selectedSerialNumbers.isEmpty() ) {
			requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.ITEMS_NOT_FOUND);
			return null;
		}
		
		List<String> serialNumbers = new ArrayList<String>(Arrays.asList(selectedSerialNumbers.split("\\s*,\\s*")));
		
		for(String serialNumber : serialNumbers){
			final Item item = Item.findItemBySerialNumber(new Long(serialNumber));
			if (null == item) {
				requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.ITEMS_NOT_FOUND);
				return null;
			}
	
			// Check if item is already part of agreement
			if (agreement.isItemPartOfAgreement(item)) {
				requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.ALREADY_ADDED);
				return null;
			}
	
			// Check if item is on hold
			if (!item.isAvailable()) {
				requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.ON_HOLD);
				return null;
			}
	
	        final AgreementItem agreementItem = agreementService.createNewAgreementItem(item, agreement);
	
	        if (agreementItem == null) {
	            requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.KIOSK_ERROR);
	            return null;
	        }
	        
	        if( agreementItemList == null ){
	        	agreementItemList = new ArrayList<AgreementItem>();
	        }
	        agreementItemList.add(agreementItem);
	        requestContext.getFlashScope().put(Constants.Agreement.ITEM_STATUS, Constants.Agreement.FOUND);
		}
        return new SelectedAgreementItems(agreementItemList);
	}
	
    /**
     * Gets the rental item to edit.
     *
     * @param agreement    the agreement
     * @param serialNumber the serial number
     * @return the rental item to edit
     */
    public AgreementItem getRentalItemToEdit(final Agreement agreement, final Long serialNumber) {
        return agreement.findItemBySerialNumber(serialNumber);
    }

    /**
     * Returns true if there are more items to checkin.  False otherwise
     *
     * @param agreement      The agreement currently been checkedin
     * @param requestContext The request context so that
     * we can populate the next checkinItemSerialNumber in the request scope
     * @return True if there are more items to checkin.  False otherwise
     */
    public boolean hasMoreItemsToBeCheckedin(final Agreement agreement, final RequestContext requestContext) {
        final Long nextItemSerialNumberToAnswerChecklist = agreement.getNextItemSerialNumberToAnswerChecklist();
        
        if (null == nextItemSerialNumberToAnswerChecklist) {
            return false;
        }
        
        requestContext.getFlashScope().put(Constants.Agreement.CHECKIN_ITEM_SERIAL_NUMBER,
                nextItemSerialNumberToAnswerChecklist);
        return true;
    }

    /**
     * This method checks whether user has atleast selected one item to checkin.  If not then it will return an error.
     * @param agreement the agreement that holds items to checkin.
     * @param requestContext the request context in which error will be populated.
     * @return the event object indicating whether the transition is successful or not.
     */
    public Event checkIfAtleastOneItemSelectedForCheckin(final Agreement agreement,
                                                         final RequestContext requestContext) {
        if (hasMoreItemsToBeCheckedin(agreement, requestContext)) {
            return success();
        }
        requestContext.getFlashScope().put(Constants.Agreement.NO_ITEMS_SELECTED_FOR_CHECKIN_ERROR_KEY, true);
        return error();
    }

    /**
     * This method will return an error condition if no checkin questions are setup.  Returns success otherwise.
     * @param requestContext the error message will be populated in the request context.
     * @return the success event if atleast one checkin question is setup, error otherwise.
     */
    public Event checkIfAtleastOneCheckinQuestionIsSetup(final RequestContext requestContext) {
        if(Question.countQuestions() > 0) {
            return success();
        }

        requestContext.getFlashScope().put(Constants.Agreement.NO_CHECKLIST_QUESTIONS_SETUP_ERROR_KEY, true);
        return error();
    }

    /**
     * Load agreement.
     *
     * @param agreementId the agreement id
     * @return the agreement
     */
    public Agreement loadAgreement(final long agreementId) {
        return Agreement.loadFull(agreementId);
    }

    /**
     * Mark item to checkin.
     *
     * @param itemToCheckin the item to checkin
     */
    public void markItemToCheckin(final AgreementItem itemToCheckin) {
        itemToCheckin.markToCheckin();
    }

    /**
     * Mark items to checkin.
     *
     * @param itemsToCheckin the items to checkin
     */
    public void markItemsToCheckin(final SelectedAgreementItems itemsToCheckin, final String usageInNumberList) {
		// Parse out the serial number and usage numbers into a HashMap
		HashMap<String,String> productUsageNumbers = null;
		if( usageInNumberList != null && !usageInNumberList.isEmpty() ){
			final List<String> productUsageNumberList = new ArrayList<String>(Arrays.asList(usageInNumberList.split("\\s*,\\s*")));
			productUsageNumbers = new HashMap<String,String>();
			for( String nvString : productUsageNumberList ){
				StringTokenizer prodTok = new StringTokenizer(nvString, ":");
				// Serial Number:Usage Out Number
				productUsageNumbers.put(prodTok.nextToken(), prodTok.nextToken());
			}
		}
    	
        List<AgreementItem> items = itemsToCheckin.getAllItems();
        for( AgreementItem item : items ){
        	// Set the checkin date/time
        	item.setCheckinDate(itemsToCheckin.getCheckinDate());
        	
        	// Set the checkin team member
        	item.setCheckinTeamMember(itemsToCheckin.getCheckinTeamMember());
        	
        	// Set the comment
        	item.getNotNullDamageInfo().setDamageComment(itemsToCheckin.getNotNullDamageInfo().getDamageComment());
        	
			String serialNumber = item.getItem().getSerialNumber().toString();
			if( productUsageNumbers != null && productUsageNumbers.containsKey(serialNumber) ){
				item.setUsageInNumber(new Double(productUsageNumbers.get(serialNumber)));
			}
        	
        	// Set the answers
        	List<ChecklistAnswer> answers = item.getAnswerList();
        	for( int answerIndex = 0; answerIndex < answers.size(); answerIndex++ ){
        		answers.get(answerIndex).setAnswer(itemsToCheckin.getAnswerList().get(answerIndex).getAnswer());
        	}
        	
        	item.markToCheckin();
        }
    }

    /**
     * Populate checkin lookups.
     *
     * @param agreementItem  the agreement item
     * @param requestContext the request context
     */
    public void populateCheckinLookups(final AgreementItem agreementItem, final RequestContext requestContext) {
        final List<Question> questions = Question.findAllQuestions();
        agreementItem.createEmptyAnswersIfRequired(questions);
        requestContext.getRequestScope().put(Constants.Agreement.QUESTIONS, questions);
        requestContext.getRequestScope().put(Constants.Agreement.MANAGER_NAMES,
                teamService.getGeneralManagerForCurrentStore());
    }
    
    /**
     * Populate multi-item checkin lookups.
     *
     * @param selectedAgreementItems  the selected agreement items
     * @param requestContext the request context
     */
    public void populateMultiItemCheckinLookups(final SelectedAgreementItems selectedAgreementItems, final RequestContext requestContext) {
        final List<Question> questions = Question.findAllQuestions();
        
        List<AgreementItem> items = selectedAgreementItems.getAllItems();
        
        for(AgreementItem item : items ){
	        item.createEmptyAnswersIfRequired(questions);
        }
		selectedAgreementItems.createEmptyAnswersIfRequired(questions);
        
        requestContext.getRequestScope().put(Constants.Agreement.QUESTIONS, questions);
        requestContext.getRequestScope().put(Constants.Agreement.MANAGER_NAMES,
                teamService.getGeneralManagerForCurrentStore());
    }
    
    /**
     * Populate override lookups.
     *
     * @param agreement      the agreement
     * @param requestContext the request context
     */
    public void populateOverrideLookups(final Agreement agreement, final RequestContext requestContext) {
        requestContext.getRequestScope().put(Constants.Agreement.MANAGER_NAMES,
                teamService.getGeneralManagerForCurrentStore());
        requestContext.getRequestScope().put(Constants.Agreement.SELECTED_PRICE_OVERRIDE_MANAGER_NAME,
                agreement.getPriceOverrideApprovedBy());
        requestContext.getRequestScope().put(Constants.Agreement.SELECTED_QUANTITY_OVERRIDE_MANAGE_NAME,
                agreement.getQuantityOverrideApprovedBy());
        requestContext.getRequestScope().put(Constants.Agreement.OVERRIDE_REASONS,
                OverrideReason.findAllOverrideReasons());
    }

    /**
     * Populate popup lookups.
     *
     * @param requestContext the request context
     */
    public void populatePopupLookups(final RequestContext requestContext) {
        requestContext.getRequestScope().put(Constants.Agreement.MANAGER_NAMES,
                teamService.getGeneralManagerForCurrentStore());
    }

    /**
     * populate check-out questions.
     */
    public void populateCheckOutQuestion() {
    	RequestContext requestContext = RequestContextHolder.getRequestContext();
    	Agreement agreement = (Agreement)requestContext.getFlowScope().get("agreement");
    	for (AgreementItem agreementItem : agreement.getItems()) {
    		if (agreementItem.getCheckOutQuestionList().isEmpty()) {
	    		Long itemSerialNumber = agreementItem.getItem().getSerialNumber();
	    		Long agreementId = agreement.getId() == null ? 0L : agreement.getId();
	    		List<QuestionDto> questionDtoList = questionRepository.getCheckOutQuestionsByItemSerialNumber(itemSerialNumber, agreementId);
	    		agreementItem.setCheckOutQuestionList(questionDtoList);
    		}
    	}
    	
    }
    
    /**
     * populate check-in questions
     */
    public void populateCheckInQuestion() {
    	RequestContext requestContext = RequestContextHolder.getRequestContext();
    	Agreement agreement = (Agreement)requestContext.getFlowScope().get("agreement");
    	for (AgreementItem agreementItem : agreement.getItems()) {
    		if (agreementItem.isCheckedin() && agreementItem.getCheckInQuestionList().isEmpty()) {
	    		Long itemSerialNumber = agreementItem.getItem().getSerialNumber();
	    		Long agreementId = agreement.getId() == null ? 0L : agreement.getId();
	    		List<QuestionDto> questionDtoList = questionRepository.getCheckInQuestionsByItemSerialNumber(itemSerialNumber, agreementId);
	    		agreementItem.setCheckInQuestionList(questionDtoList);
    		}
    	}
    	setCheckinDate(agreement);
    }
    
    /**
     * update check-in time for each agreement items to be checked in
     * @param agreement
     * @param requestContext
     * @throws ParseException
     */
    public void setCheckinTime(final Agreement agreement, final RequestContext requestContext) throws ParseException {
    	String checkinDateParam = requestContext.getExternalContext().getRequestParameterMap().get("checkinDate");
    	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm aa");
    	Date checkinDate = sdf.parse(checkinDateParam);
    	setCheckinDate(agreement, checkinDate, true);
    }
    
    /**
     * update agreement item extra charge based on the answers
     * @param agreement
     * @param requestContext
     */
    public void updateCheckinQuestion(final Agreement agreement, final RequestContext requestContext) {
    	Long workingSerialNumber = Long.parseLong(requestContext.getExternalContext().getRequestParameterMap().get("workingSerialNumber"));
    	Integer workingQuestionId = Integer.valueOf(requestContext.getExternalContext().getRequestParameterMap().get("workingQuestionId"));
    	for (AgreementItem agreementItem : agreement.getItems()) {
    		if (workingSerialNumber.equals(agreementItem.getSerialNumber())) {//found the right agreement item on the agreement
    			
    			for (QuestionDto questionDto : agreementItem.getCheckInQuestionList()) {
    				
    				if (workingQuestionId.equals(questionDto.getQuestionId())) {//found the right questionDto on the agreement item
    					boolean isSettingCleanQuestion = false;
    					if (questionDto.getQuestionText().toLowerCase().contains("clean")) {
        					isSettingCleanQuestion = true;
        				}

    					QuestionFollowUpDto questionFollowUpDto = questionRepository.getCheckInQuesionFollowUp(workingSerialNumber, workingQuestionId);
    					if (questionFollowUpDto != null && questionDto.getAnswer().equals(questionFollowUpDto.getFollowUpTrigger())) {//has followup and answer meets followup trigger
    						questionDto.setQuestionFollowUpDto(questionFollowUpDto);
    						if (questionFollowUpDto.getQuestionFollowUpTypeId() == 2) {//needs extra charge
    							if (!questionDto.getQuestionText().toLowerCase().contains("clean")) { //clean fee needs special treatment
	    							BigDecimal extraCharge = new BigDecimal(Double.parseDouble(questionFollowUpDto.getFollowUpContent()));
	    							questionDto.setExtraCharge(extraCharge);
	    							agreementItem.getChargeInfo().setChecklistAnswersChargeAmount(agreementItem.getChargeInfo().getChecklistAnswersChargeAmount().add(extraCharge));
	    							questionDto.setOldExtraCharge(extraCharge);
    							}
    						}
    						
    					} else { //has no follow-up or the answer does NOT meet follow-up trigger
    						questionDto.setQuestionFollowUpDto(null);
    						if (!questionDto.getQuestionText().toLowerCase().contains("clean")) { //clean fee needs special treatment
	    						if (questionFollowUpDto != null && questionFollowUpDto.getQuestionFollowUpTypeId() == 2) {//need to remove extra charge
	    							BigDecimal extraCharge = new BigDecimal(Double.parseDouble(questionFollowUpDto.getFollowUpContent()));
	    							questionDto.setExtraCharge(new BigDecimal(0.0d));
	    							if (questionDto.getOldExtraCharge().equals(extraCharge)) {
	    								agreementItem.getChargeInfo().setChecklistAnswersChargeAmount(agreementItem.getChargeInfo().getChecklistAnswersChargeAmount().subtract(extraCharge));
	    							}
	    						}
							}
    					}
    					if (isSettingCleanQuestion) {
    						chargeCleanFeeFor(agreementItem);
    					}
						return;
    				}
    			}
    		}
    	}
    }
    /**
     * charge clean fee for an agreement item, if multiple "clean" answers are there, just charge one clean fee for each agreement item.
     * @param agreementItem
     */
    private void chargeCleanFeeFor(AgreementItem agreementItem) {
    	boolean isAnyCleanQuestionSetNO = false;
    	for (QuestionDto questionDto : agreementItem.getCheckInQuestionList()) {//clean all clean quesiton's follow-up
    		if (questionDto.getQuestionText().toLowerCase().contains("clean")) {
    			questionDto.setQuestionFollowUpDto(null);
    		}
    		
    	}
    	
    	for (QuestionDto questionDto : agreementItem.getCheckInQuestionList()) {
    		if (questionDto.getQuestionText().toLowerCase().contains("clean")
    				&& questionDto.getAnswer() != null && questionDto.getAnswer().equals("NO")) {
    			isAnyCleanQuestionSetNO = true;
    			QuestionFollowUpDto questionFollowUpDto = questionRepository.getCheckInQuesionFollowUp(agreementItem.getSerialNumber(), questionDto.getQuestionId());
    			questionDto.setQuestionFollowUpDto(questionFollowUpDto);
    		}
    	}
    	
    	if (agreementItem.isCleanFeeCovered && !isAnyCleanQuestionSetNO) {//remove $20.00 from the agreement item's extra charge
    		BigDecimal cleanCharge = new BigDecimal(20.0D);
			agreementItem.getChargeInfo().setChecklistAnswersChargeAmount(
					agreementItem.getChargeInfo().getChecklistAnswersChargeAmount().subtract(cleanCharge)
			);
			agreementItem.isCleanFeeCovered = false;
    	}
    	
    	if (!agreementItem.isCleanFeeCovered && isAnyCleanQuestionSetNO) {//add $20.00 to the agreement item's extra charge
    		BigDecimal cleanCharge = new BigDecimal(20.0D);
			agreementItem.getChargeInfo().setChecklistAnswersChargeAmount(
					agreementItem.getChargeInfo().getChecklistAnswersChargeAmount().add(cleanCharge)
			);
			agreementItem.isCleanFeeCovered = true;
    	}

    }
    
    private void setCheckinDate(Agreement agreement){
    	this.setCheckinDate(agreement, new Date(), false);
    }
    
    private void setCheckinDate(Agreement agreement, Date checkinDate, boolean isManuallyCheckin){
    	Calendar calendar = Calendar.getInstance();
    	calendar.setTime(checkinDate);
    	for (AgreementItem agreementItem : agreement.getItems()) {
    		if (agreementItem.isCheckedin()) {
    			
    			if (isManuallyCheckin || agreementItem.getChargeInfo().getCheckinDate() == null) {
    				agreementItem.getChargeInfo().setCheckinDate(calendar);
    			}
    			
    			if (!agreementItem.getOverride().getHasQuantityOverride()) {
	    			agreementItem.getChargeInfo().markToCheckin();
	    		}
	    		
    		}
    	}
    }
    

    /**
     * Populate the rental items model.
     *
     * @param requestContext the request context
     */
    public void populateRentalItemsModel(final RequestContext requestContext) {
        ServletExternalContext externalContext = (ServletExternalContext) requestContext.getExternalContext();
        HttpServletRequest request = (HttpServletRequest)externalContext.getNativeRequest();
        log.info("* Inbound URL: " + requestContext.getFlowExecutionUrl());
        String proxyPath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/proxy/gim/ping";
        log.info("Proxy ping path: " + proxyPath);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_PROXY_URL, proxyPath);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_BASE_URL, menardsProperties.get(Constants.GuestInformationService.GIM_BASE_URL_PROP));
        
        String returnPath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/app/agreementflow/create?execution=" + requestContext.getFlowExecutionContext().getKey() + "&_eventId=proceedFromGIM";
        log.info("Return path: " + returnPath);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_RETURN_URL, URLEncoder.encode(returnPath));

        String noResponseURL = request.getContextPath() + "/app/agreementflow/create?execution=" + requestContext.getFlowExecutionContext().getKey() + "&_eventId=proceed";
        log.info("No Response URL: " + noResponseURL);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_NO_RESPONSE_URL, noResponseURL);
    }

    /**
     * Determines the application flow for guest information entry.
     *
     * @param requestContext the request context
     */
    public void determineContinueFlow(final RequestContext requestContext) {
    	boolean bypassEnabled = ApplicationControl.isGIMBypassEnabled();

    	log.info("* GIM BYPASS ENABLED: " + bypassEnabled);
        requestContext.getRequestScope().put(Constants.AgreementAction.GIM_BYPASS_ENABLED, bypassEnabled);
    }
    
    /**
     * Populate the additional driver model.
     *
     * @param requestContext the request context
     */
    public void populateAdditionalDriverModel(final RequestContext requestContext) {
        ServletExternalContext externalContext = (ServletExternalContext) requestContext.getExternalContext();
        HttpServletRequest request = (HttpServletRequest)externalContext.getNativeRequest();

        log.info("* Inbound URL: " + requestContext.getFlowExecutionUrl());
        String proxyPath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/proxy/gim/ping";
        log.info("Proxy ping path: " + proxyPath);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_PROXY_URL, proxyPath);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_BASE_URL, menardsProperties.get(Constants.GuestInformationService.GIM_BASE_URL_PROP));
        
        String returnPath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/app/agreementflow/create?execution=" + requestContext.getFlowExecutionContext().getKey() + "&_eventId=proceedGIMAddlDriver";
        log.info("Return path: " + returnPath);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_RETURN_URL, URLEncoder.encode(returnPath));

        String noResponseURL = request.getContextPath() + "/app/agreementflow/create?execution=" + requestContext.getFlowExecutionContext().getKey() + "&_eventId=getAddlDriver";
        log.info("No Response URL: " + noResponseURL);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_NO_RESPONSE_URL, noResponseURL);
    
        // Back button URLs
        String backButtonReturnPath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/app/agreementflow/create?execution=" + requestContext.getFlowExecutionContext().getKey() + "&_eventId=gatherIdAndInsurance";
        log.info("Back Button Return path: " + backButtonReturnPath);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_BACK_BUTTON_RETURN_URL, URLEncoder.encode(backButtonReturnPath));
    }
    
    public void populateGIMAdditionalDriverModel(final RequestContext requestContext) {
        ServletExternalContext externalContext = (ServletExternalContext) requestContext.getExternalContext();
        HttpServletRequest request = (HttpServletRequest)externalContext.getNativeRequest();

        log.info("* Inbound URL: " + requestContext.getFlowExecutionUrl());
        String proxyPath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/proxy/gim/ping";
        log.info("Proxy ping path: " + proxyPath);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_PROXY_URL, proxyPath);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_BASE_URL, menardsProperties.get(Constants.GuestInformationService.GIM_BASE_URL_PROP));
        
        String returnPath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/app/agreementflow/create?execution=" + requestContext.getFlowExecutionContext().getKey() + "&_eventId=storeAddlDriverInformation";
        log.info("Return path: " + returnPath);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_RETURN_URL, URLEncoder.encode(returnPath));

        String noResponseURL = request.getContextPath() + "/app/agreementflow/create?execution=" + requestContext.getFlowExecutionContext().getKey() + "&_eventId=getAddlDriver";
        log.info("No Response URL: " + noResponseURL);
        requestContext.getRequestScope().put(Constants.GuestInformationService.GIM_NO_RESPONSE_URL, noResponseURL);
    }

    public void populateGuestInformation(final RequestContext requestContext, final Agreement agreement, final String guestXMLData){

    	// Validate the basics and parse the xml data
    	GuestAccount guestAccount = getGuestAccountFromResponse(requestContext, agreement, guestXMLData);
    	
    	if( null != guestAccount ){
        	// Get the bill to address as the address of record
        	Address billTo = null;
        	List<GuestAccount.Address> addresses = guestAccount.getAddresses();
    		for( Address address : addresses ){
    			if( address.getAddressTypeCode().equals("B") ){
    				billTo = address;
    				break;
    			}
    		}

        	// Ensure that we have a bill to address
        	if( null == billTo ){
    	        requestContext.getFlashScope().put(Constants.Agreement.NO_BILL_TO_ADDRESS_PROVIDED_ERROR, true);
    	        return;
        	}
    		
        	// Ensure that the empty guest object exists
            if ( null == agreement.getGuest() ) {
                agreement.setGuest(new Guest());
            }

        	// Set the GIM guest account id to the Guest model and therefore to the database
        	if( null != guestAccount.getGuestAccountId() ){
                agreement.getGuest().setGimGuestAccountId(guestAccount.getGuestAccountId());       		
        	}
        	
        	// If there is an address id, then store that
        	if( null != billTo.getGuestAccountAddressId() ){
        		agreement.getGuest().setGimAddressId(billTo.getGuestAccountAddressId());
        	}
        	        	
        	// A business may or may not have a person's name also associated with it.
        	log.info("***** Bill-To First Name: " + billTo.getFirstName() + ", Last Name: " + billTo.getLastName());
        	if( null != billTo.getFirstName() && !billTo.getFirstName().isEmpty() ){
                agreement.getGuest().setFirstName(billTo.getFirstName());        		
                agreement.getGuest().setLastName(billTo.getLastName());        		
        	}
 
        	// If this is a business account, use the business name from the bill to address
        	if( guestAccount.getGuestAccountTypeCode().equals("B") ){
            	if( null != billTo.getBusinessName() && !billTo.getBusinessName().isEmpty() ){
            		agreement.getGuest().setCompanyName(billTo.getBusinessName());            	
            	}
        	}
        	
        	// Set the address for the guest, using the bill to address
        	if( null == billTo.getAddressLine2() || billTo.getAddressLine1().isEmpty() ){
        		agreement.getGuest().getAddress().setLine(billTo.getAddressLine1());
        	}
        	else{
        		agreement.getGuest().getAddress().setLine(billTo.getAddressLine1() + " " + billTo.getAddressLine2());
        	}
        	agreement.getGuest().getAddress().setCity(billTo.getCity());
        	agreement.getGuest().getAddress().setState(billTo.getStateCode());
        	agreement.getGuest().getAddress().setZipCode(billTo.getPostalCode());
        	List<GuestAccount.Phone> phones = billTo.getPhones();
        	String homePhone = null;
        	String mobilePhone = null;
        	String workPhone = null;
        	String workMobile = null;
        	for( Phone phone : phones ){
    			String number;
    			if( phone.getPhoneNumber().length() == 10 ){
    				number = phone.getPhoneNumber().substring(0, 3) + "-" + phone.getPhoneNumber().substring(3, 6) + "-" + phone.getPhoneNumber().substring(6, 10);
    			}
    			else{
    				number = phone.getPhoneNumber();
    			}
        		switch( phone.getPhoneTypeId() ){
	        		case 1:{
	        			workMobile = number;
	        			break;
	        		}
	        		case 2:{
	        			workPhone = number;
	        			break;
	        		}
	        		case 3:{
	        			homePhone = number;
	        			break;
	        		}
	        		case 4:{
	        			mobilePhone = number;
	        			break;
	        		}
        		}
        	}
        	if( null != homePhone && !homePhone.isEmpty() ){
        		agreement.getGuest().setPhoneNumber(homePhone);
        	}
        	else if( null != mobilePhone && !mobilePhone.isEmpty() ){
        		agreement.getGuest().setPhoneNumber(mobilePhone);
        	}
        	else if( null != workPhone && !workPhone.isEmpty() ){
        		agreement.getGuest().setPhoneNumber(workPhone);
        	}
        	else if( null != workMobile && !workMobile.isEmpty() ){
        		agreement.getGuest().setPhoneNumber(workMobile);
        	}
        	
        	// Set the email address
        	if( null != billTo.getEmails() && !billTo.getEmails().isEmpty() ){
        		agreement.getGuest().setEmail(billTo.getEmails().get(0).getEmail());
        	}
        }
    }

    public String isGuestPopulated(final RequestContext requestContext, final Agreement agreement){
    	String response = "no";
    	
    	if( null != agreement && null != agreement.getGuest() ){
    		response = "yes";
    	}
    	else{
    		if( "exit".equals(requestContext.getFlashScope().get(Constants.Agreement.GUEST_EXIT)) ){
    			response = "exit";
    		}
    		else{
    			ensureGuestInitialized(agreement); // Need to initialize for the guest information page
    		}
    	}
    	
    	return response;
    }

    public void addAdditionalDriverInformation(final RequestContext requestContext, final Agreement agreement, final String guestXMLData){

    	// Validate the basics and parse the xml data
    	GuestAccount guestAccount = getGuestAccountFromResponse(requestContext, agreement, guestXMLData);
    	
    	if( null != guestAccount ){
        	// Get the bill to address as the address of record
        	Address billTo = null;
        	List<GuestAccount.Address> addresses = guestAccount.getAddresses();
    		for( Address address : addresses ){
    			if( address.getAddressTypeCode().equals("B") ){
    				billTo = address;
    				break;
    			}
    		}
    		
        	// Ensure that we have a bill to address
        	if( null == billTo ){
    	        requestContext.getFlashScope().put(Constants.Agreement.NO_BILL_TO_ADDRESS_PROVIDED_ERROR, true);
    	        return;
        	}
        	
        	// Ensure that the vehicle rental detail exists
            if( null != agreement.getVehicleRentalDetail()) {
    	        requestContext.getFlashScope().put(Constants.Agreement.VEHICLE_RENTAL_ITEM_DETAILS_MISSING_ERROR, true);
    	        return;
            }
        	
        	// Ensure that the empty guest object exists
            if( null == agreement.getVehicleRentalDetail().getAdditionalDriver() ) {
            	agreement.getVehicleRentalDetail().setAdditionalDriver(new AdditionalDriver());
            }
        	
        	// Set the GIM guest account id to the Guest model and therefore to the database
        	if( null != guestAccount.getGuestAccountId() ){
        		agreement.getVehicleRentalDetail().getAdditionalDriver().setGimGuestAccountId(guestAccount.getGuestAccountId());        		
        	}

        	// Set the GIM address id to the Guest model and therefore to the database
        	if( null != billTo.getGuestAccountAddressId() ){
        		agreement.getVehicleRentalDetail().getAdditionalDriver().setGimAddressId(billTo.getGuestAccountAddressId());        		
        	}
        	
        	// A business may or may not have a person's name also associated with it.
        	if( null != billTo.getFirstName() && !billTo.getFirstName().isEmpty() ){
        		agreement.getVehicleRentalDetail().getAdditionalDriver().setName(billTo.getFirstName() + " " + billTo.getLastName());        		
        	}
        	        	
        	// Set the address for the guest, using the bill to address
        	if( null == billTo.getAddressLine2() || billTo.getAddressLine1().isEmpty() ){
        		agreement.getVehicleRentalDetail().getAdditionalDriver().getAddress().setLine(billTo.getAddressLine1());
        	}
        	else{
        		agreement.getVehicleRentalDetail().getAdditionalDriver().getAddress().setLine(billTo.getAddressLine1() + " " + billTo.getAddressLine2());
        	}
        	agreement.getVehicleRentalDetail().getAdditionalDriver().getAddress().setCity(billTo.getCity());
        	agreement.getVehicleRentalDetail().getAdditionalDriver().getAddress().setState(billTo.getStateCode());
        	agreement.getVehicleRentalDetail().getAdditionalDriver().getAddress().setZipCode(billTo.getPostalCode());
        }
    }
    
    public String isAdditionalDriverPopulated(final RequestContext requestContext, final Agreement agreement){
    	String response = "no";
    	
    	if( null != agreement && null != agreement.getVehicleRentalDetail().getAdditionalDriver() ){
    		response = "yes";
    	}
    	else if( "exit".equals(requestContext.getFlashScope().get(Constants.Agreement.GUEST_EXIT)) ){
			response = "exit";
    	}
    	
    	return response;
    }

    public GuestAccount getGuestAccountFromResponse(final RequestContext requestContext, final Agreement agreement, final String guestXMLData){
    	if( null == guestXMLData || guestXMLData.isEmpty() ){
	        requestContext.getFlashScope().put(Constants.Agreement.NO_GUEST_INFORMATION_RECEIVED_FROM_CENTRAL_REPOSITORY_ERROR, true);
	        return null;
    	}

    	if( null == agreement ){
	        requestContext.getFlashScope().put(Constants.Agreement.NO_AGREEMENT_AVAILABLE_IN_FLOW_SCOPE_ERROR, true);
	        return null;
    	}
    	
    	String unencodedGuestXMLData = null;
    	log.info("****** Encoded GIM response: " + guestXMLData);
    	try{
    		unencodedGuestXMLData = URLDecoder.decode(guestXMLData, "UTF-8");
    	}
    	catch( UnsupportedEncodingException ueex ){
	        requestContext.getFlashScope().put(Constants.Agreement.UNABLE_TO_DECODE_GUEST_INFORMATION_ERROR, true);
	        return null;    		
    	}
    	
    	if( null == unencodedGuestXMLData || unencodedGuestXMLData.isEmpty() ){
	        requestContext.getFlashScope().put(Constants.Agreement.NO_DECODED_GUEST_INFORMATION_ERROR, true);
	        return null;
    	}
    	log.info("****** Unencoded GIM response: " + unencodedGuestXMLData);

        // Parse the guest info xml string into a GuestAccount instance
        GuestAccount guestAccount = GuestAccountUtils.getGuestAccountFromUrlParam(unencodedGuestXMLData);
        if( !"success".equals(guestAccount.getReturnCode()) ){
	        if( "guestExit".equals(guestAccount.getReturnCode()) ){
	        	requestContext.getFlashScope().put(Constants.Agreement.GUEST_EXIT, "exit");
	        }
	        else{
	        	requestContext.getFlashScope().put(Constants.Agreement.UNABLE_TO_RETRIEVE_GUEST_INFORMATION_ERROR, true);
	        }
	        return null;
        } 
        else {
        	return guestAccount;
        }
    }
    
    /**
     * Re calculate charges and duration for agreement item.
     *
     * @param agreementItem the agreement item
     */
    public void reCalculateChargesAndDurationForAgreementItem(final AgreementItem agreementItem) {
        agreementItem.calculateEstimatedChargesAndDuration();
    }

    /**
     * Removes the agreement item from agreement.
     *
     * @param agreement    the agreement
     * @param serialNumber the serial number
     */
    public void removeAgreementItemFromAgreement(final Agreement agreement, final Long serialNumber) {
        // Now remove the agreement item from the agreement. The front end
        // sends us the item id and as we do not have duplicate items,
        // let's figure out the agreementItem which contains this item
        agreementService.removeItemFromAgreement(agreement, serialNumber);
    }

    private boolean validateRequiredAnswers(Agreement agreement) {
    	for (AgreementItem agreementItem : agreement.getItems()) {
    		for (QuestionDto questionDto : agreementItem.getCheckOutQuestionList()) {
    			if (questionDto.getAnswerTypeId() != 3 && StringUtils.isEmpty(questionDto.getAnswer())) {
    				return false;
    			}
    		}
    	}
    	return true;
    }
    
    private boolean checkAnswerFollowUp(Agreement agreement) {
    	for (AgreementItem agreementItem : agreement.getItems()) {
    		for (QuestionDto questionDto : agreementItem.getCheckOutQuestionList()) {
    			QuestionFollowUpDto questionFollowUpDto = questionRepository.getCheckOutQuesionFollowUp(agreementItem.getSerialNumber(), questionDto.getQuestionId());
    			if (questionFollowUpDto != null) {
    				if (questionDto.getAnswer().equals(questionFollowUpDto.getFollowUpTrigger())) {
    					return false;
    				}
    			}
    		}
    	}
    	return true;
    }
    
    /**
     * Save or update.
     *
     * @param destination    the destination
     * @param requestContext the request context
     * @return the event
     */
    public Event saveOrUpdate(final Agreement destination, final RequestContext requestContext) {
        final String oldAgreementNumber = destination.getAgreementNumber();
        try {
            if (!destination.hasItems()) {
                requestContext.getFlashScope().put(Constants.Agreement.NO_ITEMS_SELECTED_ERROR_KEY, true);
                return error();
            }
            if (!validateRequiredAnswers(destination)) {
            	requestContext.getFlashScope().put(Constants.Agreement.QUESTION_NOT_ANSWERED, true);
                return error();
            }
            agreementService.saveOrUpdateAgreement(destination);
            final Agreement agreement = updateFlowScopeAgreement(destination, requestContext);
            agreement.copyTransientInformationFrom(destination);
        } catch (final IllegalStateException e) {
            requestContext.getFlashScope().put(Constants.Agreement.HAS_ERROR, true);
            return error();
        }

        if(sendAgreementToKioskServer(destination, oldAgreementNumber, requestContext)) {
            requestContext.getFlashScope().put(Constants.Agreement.SHOW_REPORT, true);
            agreementService.sendRentalOverrideMailsIfAny(destination);
        }

        return success();
    }
    
    public Event saveAnswerQuestions(final Agreement agreement) {
    	agreementService.persistQuestionAnswers(agreement);
    	return success();
    }
    

    /**
     * Sets the agreement service.
     *
     * @param agreementService the new agreement service
     */
    public void setAgreementService(final AgreementService agreementService) {
        this.agreementService = agreementService;
    }

    /**
     * Sets the price override manager name and update charges.
     *
     * @param destination the destination
     * @param managerNumber the manager name
     */
    public void setPriceOverrideManagerNameAndUpdateCharges(final Agreement destination, final Integer managerNumber) {
        destination.setPriceOverrideApprovedBy(managerNumber);
        destination.calculateDamageWaiverCharges();
    }

    /**
     * Sets the quantity override manager name to agreement.
     *
     * @param agreement                   the agreement
     * @param quantityOverrideManagerNumer the quantity override manager name
     */
    public void setQuantityOverrideManagerNameToAgreement(final Agreement agreement,
                                                          final Integer quantityOverrideManagerNumer) {
        agreement.setQuantityOverrideApprovedBy(quantityOverrideManagerNumer);
    }

    /**
     * Sets the reservation service.
     *
     * @param reservationService the new reservation service
     */
    public void setReservationService(final ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    /**
     * Sets the Team service.
     *
     * @param teamService - team service
     */
    public void setTeamService(final TeamService teamService) {
        this.teamService = teamService;
    }
    
    public void setMenardsProperties(MenardsProperties menardsProperties) {
		this.menardsProperties = menardsProperties;
	}

	/**
     * Update damage waiver charges.
     *
     * @param agreement the agreement
     */
    public void updateDamageWaiverCharges(final Agreement agreement) {
        agreement.calculateDamageWaiverCharges();
    }

	/**
     * Marks the chosen item for checkin so that when the page loads we show the item as already checked.
     * @param agreement the agreement to which the item belongs.
     * @param itemSerialNumber the item serial number that we will be checkin.
     */
    public void markItemForCheckin(final Agreement agreement, final Long itemSerialNumber) {
        if ((null != itemSerialNumber) && (0 != itemSerialNumber)) {
            final AgreementItem item = agreement.findItemBySerialNumber(itemSerialNumber);
            if (item != null) {
                item.setCheckedin(true);
            }
        }
    }

    /**
     * Saves the notes of the agreement if possible.  The agreement will be saved only if the agreement is
     * not editable in general and user is simply trying to save notes.
     * @param agreement the agreement to which the notes have to be saved.
     * @param requestContext that will be used to update the agreement reference.
     */
    public void saveNotesIfPossible(final Agreement agreement, final RequestContext requestContext) {
        if (!agreement.isEditable()) {
        	agreementService.persistComments(agreement);
            updateFlowScopeAgreement(agreement, requestContext);
        }
    }

    /**
     * Sends the agreement to the kiosk server.
     * @param agreement the agreement that is to be sent to the kiosk server.
     * @param agreementNumber the areement number for which we have to send the agreement to kiosk server.
     * @param requestContext the request context which will be populated with the error flag if kiosk service failed.
     * @return boolean indicating whether the ageement was sent to the kiosk or not.
     */
    private boolean sendAgreementToKioskServer(final Agreement agreement, final String agreementNumber, final RequestContext requestContext) {
        //Send the message to kiosk about the agreement
        if (!agreementService.sendAgreementToKiosk(agreement, agreementNumber)) {
            requestContext.getFlashScope().put(Constants.Agreement.KIOSK_ERROR, true);
            return false;
        }
        return true;
    }

    /**
     * Puts the new updated agreement in the flow scope.
     * @param destination the agreement that was merged.
     * @param requestContext the request context in which we have to update the reference.
     * @return The agreement reference that we get from the DB.
     */
    private Agreement updateFlowScopeAgreement(final Agreement destination, final RequestContext requestContext) {
        final Agreement agreement = Agreement.loadFull(destination.getId());
        requestContext.getFlowScope().put(Constants.Agreement.AGREEMENT,
                agreement);
        return agreement;
    }
    /**
     * Get the user's access permissions
     * @param agreement
     * @return if the user's position is manager
     */
    public  boolean isManagerStoreUser(final Agreement agreement){
    	MenardsUser user=(MenardsUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    	String userName=user.getUsername().toUpperCase();
        return userName.startsWith("BCKOFF01")||userName.startsWith("OFFMGR01");
    }
}
