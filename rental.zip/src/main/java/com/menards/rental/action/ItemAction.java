/*
 * ItemAction.java
 */
package com.menards.rental.action;

import com.menards.rental.utils.Constants;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.webflow.action.MultiAction;
import org.springframework.webflow.core.collection.MutableAttributeMap;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.menards.rental.domain.Item;
import com.menards.rental.domain.Product;
import com.menards.rental.service.ItemService;

/**
 * The Class ItemAction.
 */
@Component(value = "itemAction")
public class ItemAction extends MultiAction {

	/** The log. */
	private static final Logger log = Logger.getLogger(ItemAction.class);

	/** The Constant IS_VEHICLE. */
	private static final String IS_VEHICLE = "isVehicle";

	/** The item service. */
	@Autowired
	private ItemService itemService;

    /**
	 * Creates the new item.
	 *
	 * @return the item
	 */
	public Item createNewItem() {
		return itemService.createNewItem();
	}

	/**
	 * Generate item serial number.
	 *
	 * @param item the item
	 * @param context the context
     * @return Event object which could be either success or failure.
	 */
	public Event generateItemSerialNumber(final Item item, final RequestContext context) {
        if (itemService.isNewItemCreationNotPossible(item)) {
            context.getFlashScope().put("maxItemsAlreadyCreated", true);
            return error();
        }

		item.generateSerialNumber();

		final Product product = item.getProduct();
		setIsVehicleContextForProduct(context.getFlashScope(), product);
        return success();
	}

	/**
	 * Save item.
	 *
	 * @param item the item
     * @param requestContext the request context that will be used to populate the error.
     * @return event whether the save of item was successful or not.
	 */
	public Event saveItem(final Item item, final RequestContext requestContext) {
        itemService.saveItem(item);
        if (itemService.syncItemInventory(item.getProduct())) {
            return success();
        }
        requestContext.getFlashScope().put(Constants.Agreement.KIOSK_ERROR, true);
        return error();
	}

    /**
     * Syncs the item inventory of the product with the given id with the kiosk.
     * @param productId the product for which we have to sync inventory.
     * @param requestContext the request context object which will be used to populate error if any.
     */
    public void syncInventory(final Long productId, final RequestContext requestContext) {
        final Product product = Product.findProduct(productId);

        if (itemService.syncItemInventory(product)) {
            requestContext.getFlashScope().put(Constants.Action.SYNC_INVENTORY_SUCCESS, true);
            return;
        }
        requestContext.getFlashScope().put(Constants.Action.SYNC_INVENTORY_FAILURE, true);
    }

	/**
	 * Sets the item service.
	 *
	 * @param itemService the new item service
	 */
	public void setItemService(final ItemService itemService) {
		this.itemService = itemService;
	}

	/**
	 * Sets the is vehicle context for product.
	 *
	 * @param scope the scope
	 * @param product the product
	 */
	private void setIsVehicleContextForProduct(final MutableAttributeMap scope, final Product product) {
        if (product == null) {
            scope.put(IS_VEHICLE, false);
            return;
        }
        scope.put(IS_VEHICLE, product.getInsuranceAdditionalDriverLicenseRequired());
	}
}
