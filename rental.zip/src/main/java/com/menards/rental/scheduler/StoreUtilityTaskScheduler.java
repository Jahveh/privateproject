/*
 * StoreUtilityTaskScheduler.java
 */
package com.menards.rental.scheduler;

import com.menards.rental.service.AutomatedReportService;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * This class is invoked by the Spring as part of its scheduler mechanism.
 *
 * @author lalit
 */
public class StoreUtilityTaskScheduler {

	/** The automated report service. */
	@Autowired
	private AutomatedReportService automatedReportService;

	/**
	 * Send emails for each store to its general manager.
	 */
	public void doDailyTask() {
        automatedReportService.generateAndPublishDailyReportsForAllStores();
	}

    /**
     * The setter for the automated report service.
     * @param automatedReportService the value.
     */
    public void setAutomatedReportService(final AutomatedReportService automatedReportService) {
        this.automatedReportService = automatedReportService;
    }
}
