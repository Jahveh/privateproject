/*
 * GoUtilityTaskSchedular.java
 */
package com.menards.rental.scheduler;

import java.util.Calendar;

import com.menards.rental.service.AutomatedReportService;
import com.menards.rental.service.external.TeamService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.menards.rental.service.external.StoreService;
import org.springframework.stereotype.Component;

/**
 * The Class GoUtilityTaskScheduler.
 */
@Component(value = "goUtilityTaskSchedulerForTestingOnly")
public class GoUtilityTaskScheduler
{

	/** The Store Service. */
	@Autowired
	private StoreService storeService;

	/** The team service reference. */
	@Autowired
	private TeamService teamService;

	/** Automated report service refernce. */
	@Autowired
	private AutomatedReportService automatedReportService;

	/** The log4j logger. */
	private static final Logger logger = Logger.getLogger(GoUtilityTaskScheduler.class);

	/**
	 * Do daily task.
	 */
	public void doDailyTask()
	{

		//Refresh the store hours for all the stores
		storeService.init();
		teamService.init();

		//Run the Not returned report daily to send to the helpdesk.
		automatedReportService.generateAndPublishNotReturnedReport();
	}

	/**
	 * Do weekly task for go utility.
	 */
	public void doWeeklyTask()
	{

		final Calendar reportStartDate = Calendar.getInstance();
		reportStartDate.add(Calendar.DATE, -7);

		final Calendar reportEndDate = Calendar.getInstance();

		generateVendorNotificationReport(reportStartDate, reportEndDate);
	}

	/**
	 * Setter for the automated report service.
	 * 
	 * @param automatedReportService the value.
	 */
	public void setAutomatedReportService(final AutomatedReportService automatedReportService)
	{
		this.automatedReportService = automatedReportService;
	}

	/**
	 * Generates and publishes the vendor notification report.
	 * 
	 * @param reportStartDate the report start date.
	 * @param reportEndDate the report end date.
	 */
	private void generateVendorNotificationReport(final Calendar reportStartDate, final Calendar reportEndDate)
	{
		try
		{
			automatedReportService.generateAndPublishVendorNotificationReport(reportStartDate, reportEndDate);
		}
		catch (final Exception e)
		{
			logger.error("Error while creating the Vendor notification Report For duration: "
										+ reportStartDate.getTime()
										+ " to " + reportEndDate.getTime()
										+ " -" + e.getMessage(), e);
//			logger.error(e.getMessage(), e);
		}
	}
}
