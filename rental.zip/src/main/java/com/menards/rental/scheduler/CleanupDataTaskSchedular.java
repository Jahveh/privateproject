package com.menards.rental.scheduler;

import com.menards.rental.domain.Agreement;
import com.menards.rental.service.AgreementService;
import com.menards.rental.service.NotificationService;
import com.menards.rental.service.ReservationService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * The cleanup data task schedular.  This guys cleans up the db.  Primarily it does two things
 * First to move the onHold items to availalbe state for items have have been on hold for more than a predefined time.
 * Second Cancels the reservation after every 15 mins the reservation has been started.
 *
 * @author deep
 */
@Component(value = "cleanupDataTaskSchedular")
public class CleanupDataTaskSchedular {

    /** The logger. */
    private static final Logger logger = Logger.getLogger(CleanupDataTaskSchedular.class);

    /** The agreement service reference. */
    @Autowired
    private AgreementService agreementService;

    /** The reservation service reference. */
    @Autowired
    private ReservationService reservationService;

    /** The notification service reference. */
    @Autowired
    private NotificationService notificationService;

    /**
     * Makes the onHold item Available if they were on hold more than a predefined amount of time.
     */
    public void makeOnHoldItemsAvailable() {
        logger.debug("Making the items that were checkedout but not paid for before the threshold - Available - START");
        final List<Agreement> autoCancelledAgreements = agreementService.makeItemsAvailableIfThresholdHasPassed();
        agreementService.removeArchiveFor(autoCancelledAgreements);
        logger.debug("Making the items that were checkedout but not paid for before the threshold - Available - END");
    }

    /**
     * The method that will be invoked at regular intervals to cancel the reservations.  If the reservation time has
     * started and threshold has crossed then we cancel those reservations.  If all reservations have been canceled
     * then we cancel the reservation agreement. 
     */
    public void cancelReservations() {
        logger.debug("Cancel the reservations that have crossed the threshold - START");
        reservationService.cancelAllReservationsThatHaveCrossedThreshold();
        logger.debug("Cancel the reservation agreements that have not open reservations.");
        reservationService.cancelAllReservationAgreementsWithNoOpenReservations();
        logger.debug("Cancel the reservations that have crossed the threshold - END");
    }

    /**
     * The setter for the agreement service.
     * @param agreementService the value.
     */
    public void setAgreementService(final AgreementService agreementService) {
        this.agreementService = agreementService;
    }

    /**
     * The setter for the reservation service.
     * @param reservationService the value.
     */
    public void setReservationService(final ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    /**
     * The setter for the notification service.
     * @param notificationService the value to set.
     */
    public void setNotificationService(final NotificationService notificationService) {
        this.notificationService = notificationService;
    }
}
