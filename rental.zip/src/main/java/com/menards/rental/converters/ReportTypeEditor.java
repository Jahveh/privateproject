/*
 * ReportTypeEditor.java
 */
package com.menards.rental.converters;

import java.beans.PropertyEditorSupport;

import com.menards.rental.domain.Report;

/**
 * Spring PropertyEditor for handling Report.Type enum values.
 * @author deep
 */
public class ReportTypeEditor extends PropertyEditorSupport {

    /**
     * {@inheritDoc}
     */
	@Override
	public String getAsText() {
		if (null == getValue()) {
			return null;
		}
		return getValue().toString();
	}

    /**
     * {@inheritDoc}
     */
	@Override
	public void setAsText(final String text) {
		if (null == text) {
			return;
		}
		setValue(Report.Type.valueOf(text));
	}
}
