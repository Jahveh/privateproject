/*
 * CalendarToStringConverter.java
 */
package com.menards.rental.converters;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Logger;

import org.springframework.binding.convert.converters.StringToObject;

import com.menards.rental.utils.Constants;

/**
 * Spring framework converter to handle Calendar objects displayed in our custom
 * Date & Time Format.
 * @author deep
 */
public class CalendarToStringConverter extends StringToObject {

	/** The Constant log. */
	private static final Logger log = Logger.getLogger(CalendarToStringConverter.class.toString());

	/** The sdf. */
	private final SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT);

	/**
	 * Instantiates a new calendar to string converter.
	 */
	public CalendarToStringConverter() {
		super(Calendar.class);
	}

    /**
     * {@inheritDoc}
     */
	@Override
	protected Object toObject(final String value, final Class targetClass) throws Exception {
		final Calendar calendar = Calendar.getInstance();

		try {
			// Date Format with time
			final Date date = sdf.parse(value);
			calendar.setTime(date);
			return calendar;

		} catch (final ParseException pe) {
			log.warning(pe.getMessage());
			return null;
		}
	}

    /**
     * {@inheritDoc}
     */
	@Override
	protected String toString(final Object value) throws Exception {
		final Calendar calendar = (Calendar) value;
		
		if (null != calendar) {
			return sdf.format(calendar.getTime());
		}
        return "";
	}
}
