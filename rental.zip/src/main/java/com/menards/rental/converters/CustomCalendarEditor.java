/*
 * CustomCalendarEditor.java
 */
package com.menards.rental.converters;

import java.beans.PropertyEditorSupport;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Logger;

import com.menards.rental.utils.Constants;

/**
 * Spring property editor to support displaying and consuming date & times in
 * our custom formatted way.
 * @author deep
 */
public class CustomCalendarEditor extends PropertyEditorSupport {

	/** The Constant log. */
	private static final Logger log = Logger.getLogger(CustomCalendarEditor.class.toString());

	/** The sdf. */
	private final SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT);

    /**
     * {@inheritDoc}
     */
	@Override
	public String getAsText() {
		final Calendar calendar = (Calendar) getValue();
	
		if (null != calendar) {
			return sdf.format(calendar.getTime());
		}
        return "";
	}

    /**
     * {@inheritDoc}
     */
	@Override
	public void setAsText(final String text) {
		final Calendar calendar = Calendar.getInstance();

		try {
			// Date Format with time
			final Date date = sdf.parse(text);
			calendar.setTime(date);
			setValue(calendar);
		} catch (final ParseException pe) {
			log.warning(pe.getMessage());
			setValue(null);
		}
	}
}
