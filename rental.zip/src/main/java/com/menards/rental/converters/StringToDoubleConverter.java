package com.menards.rental.converters;

import org.springframework.binding.convert.converters.StringToDouble;

import java.text.NumberFormat;

/**
 * The class that is responsible to convert a double value to string and string to double value.
 * @author deep
 */
public class StringToDoubleConverter extends StringToDouble {

    @Override
    public Object toObject(final String string, final Class objectClass) throws Exception {
        return NumberFormat.getInstance().parse(string).doubleValue();
    }


}
