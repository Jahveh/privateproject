/*
 * DateToStringConverter.java
 */
package com.menards.rental.converters;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

import org.springframework.binding.convert.converters.StringToDate;

import com.menards.rental.utils.Constants;

/**
 * Spring framework converter to handle Date objects displayed in our custom
 * Date & Time Format.
 * @author deep
 */
public class DateToStringConverter extends StringToDate {

	/** The Constant log. */
	private static final Logger log = Logger.getLogger(DateToStringConverter.class.toString());

	/** The sdf. */
	private final SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_FORMAT);

    /**
     * {@inheritDoc}
     */
	@Override
	public String getPattern() {
		return Constants.DateFormat.DATE_FORMAT;
	}

    /**
     * {@inheritDoc}
     */
	@Override
	public Object toObject(final String value, final Class targetClass) throws Exception {
		try {
			// Date Format with time
			return sdf.parse(value);
		} catch (final ParseException pe) {
			log.warning(pe.getMessage());
			return null;
		}
	}

    /**
     * {@inheritDoc}
     */
	@Override
	public String toString(final Object target) throws Exception {
		final Date date = (Date) target;
		
		if (null != date) {
			return sdf.format(date);
		}
        return "";
	}
}
