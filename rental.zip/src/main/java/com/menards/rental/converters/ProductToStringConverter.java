/*
 * ProductToStringConverter.java
 */
package com.menards.rental.converters;

import org.springframework.binding.convert.converters.StringToObject;

import com.menards.rental.domain.Product;

/**
 * Spring converter that handles easily serializing Product instances and then
 * rehydrating them from the database.
 * @author lalit
 */
public class ProductToStringConverter extends StringToObject {

	/**
	 * Instantiates a new product to string converter.
	 */
	public ProductToStringConverter() {
		super(Product.class);
	}

    /**
     * {@inheritDoc}
     */
	@Override
	protected Object toObject(final String string, final Class targetClass) throws Exception {
		try {
			final Long id = Long.parseLong(string);
			return Product.findProduct(id);
		} catch (final NumberFormatException nfe) {
			return null;
		}
	}

    /**
     * {@inheritDoc}
     */
	@Override
	protected String toString(final Object object) throws Exception {
		return ((Product) object).getId().toString();
	}
}
