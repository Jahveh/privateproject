/*
 * CustomConversionService.java
 */
package com.menards.rental.converters;

import org.springframework.binding.convert.service.DefaultConversionService;
import org.springframework.stereotype.Component;

/**
 * Extends the DefaultConversionService to register our custom Converters so
 * they are available to the application at runtime.
 * 
 * @author deep
 */
@Component(value = "customConversionService")
public class CustomConversionService extends DefaultConversionService {

    /**
     * {@inheritDoc}
     */
	@Override
	protected void addDefaultConverters() {
		super.addDefaultConverters();
		addConverter(new CalendarToStringConverter());
		addConverter(new DateToStringConverter());
		addConverter(new ProductToStringConverter());
        addConverter(new StringToDoubleConverter());
	}
}
