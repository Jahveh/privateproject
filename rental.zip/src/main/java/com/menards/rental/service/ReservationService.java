/*
 * ReservationService.java
 */
package com.menards.rental.service;

import java.util.Calendar;
import java.util.List;

import com.menards.rental.domain.*;
import com.menards.rental.service.external.KioskService;
import com.menards.rental.service.external.TeamService;
import com.menards.rental.utils.Constants;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.menards.rental.domain.rule.ReservationRule;

/**
 * The reservation service used to perform create, read, update and delete of reservation and reservation agreements.
 * @author deep
 */
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
public class ReservationService {

	/** The reservation rules. */
	private List<ReservationRule> reservationRules;

	/** The menards service. */
	private MenardsService menardsService;

	/** The context service. */
	private ContextService contextService;

    /** The kiosk service reference. */
    private KioskService kioskService;

    /** The team service reference. */
    private TeamService teamService;

    /**
     * Calculates the estimated charges and duration for a given reservation.
     * @param reservation for which we have to calculated the charges and duration.
     */
    public void calculateEstimatedChargesAndDuration(final Reservation reservation) {
        reservation.calculateEstimatedChargesAndDuration();
    }

	/**
	 * Create a new reservation.
	 * 
	 * @param product
	 *            The product to be reserved.
	 * @param reservationAgreement
	 *            The reservation agreement that this reservation belongs to.
	 * @return The initialized Reservation
	 */
	public Reservation createReservation(final Product product, final ReservationAgreement reservationAgreement) {
        final KioskProductDetail kioskProductDetail = kioskService.getKioskProductDetail(product);

        if ((kioskProductDetail == null) || (!kioskProductDetail.isBaseSKUSetup())) {
            return null;
        }

        final Reservation reservation = new Reservation();
		reservation.setProduct(product);
		reservation.setAgreement(reservationAgreement);
		reservation.setStatus(ReservationStatus.findOpen());
        reservation.copyChargeInfo();
        reservation.copyPriceFrom(kioskProductDetail);
		return reservation;
	}

	/**
	 * Create a new reservation agreement with the information about the store,
	 * the status and the team member properly initialized.
	 * 
	 * @return The initialized reservatio nagreement.
	 */
	public ReservationAgreement createReservationAgreement() {
		final ReservationAgreement agreement = new ReservationAgreement();
		agreement.setStore(menardsService.getCurrentStore());
		agreement.setStatus(ReservationAgreementStatus.findOpen());
		return agreement;
	}

	/**
	 * Checks an item to see if it can be reserved.
	 *
	 * @param item the item
	 * @param outDate the out date
	 * @param inDate the in date
	 * @return true, if successful
	 */
	public boolean hasNoConflictingReservation(final Item item, final Calendar outDate, final Calendar inDate) {
		for (final ReservationRule reservationRule : reservationRules) {
			if (reservationRule.hasNoConflictingReservation(item, outDate, inDate)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Checks if is reservation possible.
	 *
	 * @param product the product
	 * @param reservation the reservation
	 * @param reservationAgreement the reservation agreement
	 * @return true, if is reservation possible
	 */
	public boolean isReservationPossible(final Product product, final Reservation reservation,
	        final ReservationAgreement reservationAgreement) {
		final int overlappingReservationsCount = product.countActuallyOverlappingReservationsForStore(
		        reservationAgreement.getStoreNumber(), reservation.getCheckOutTimeStamp(), reservation
		                .getCheckInTimeStamp());
		final long itemsCurrentlyRentableInTheStore = Item.countRentableItemsByProductAndStoreNumber(
                product,
		        reservationAgreement.getStoreNumber());
		return itemsCurrentlyRentableInTheStore > overlappingReservationsCount;
	}

	/**
	 * Save.
	 *
	 * @param reservationAgreement the reservation agreement
	 */
	@Transactional
	public void save(final ReservationAgreement reservationAgreement) {
		if (reservationAgreement.isTransient()) {
			reservationAgreement.persist();
			return;
		}
		reservationAgreement.merge();
	}

    /**
     * Populate the team member name from the team member number.
     * @param reservationAgreement the reservation agreement in which we have to populate the sore user info.
     */
    public void populateTMNameFromTMNumber(final ReservationAgreement reservationAgreement) {
        final StoreUserInfo storeUserInfo = teamService
                .getStoreUserByIdForCurrentStore(reservationAgreement.getCreatedByTeamMemberNumber());
        reservationAgreement.setStoreUser(storeUserInfo);
	}
	
	/**
     * Cancel all reservations that have crossed the threshold.
     */
    @Transactional
    public void cancelAllReservationsThatHaveCrossedThreshold() {
        final Calendar threshold = Calendar.getInstance();
        threshold.add(Calendar.MINUTE, Constants.Cleanup.DEFAULT_RESERVATION_CLEANUP_MINUTES_THRESHOLD);
        final List<Reservation> oldReservations = Reservation.findAllOpenReservationsThatAreOlderThan(threshold);
        new ReservationCollection(oldReservations).cancel();
    }

    /**
     * Cancel all the reservation agreements that have no open reservations.
     */
    @Transactional
    public void cancelAllReservationAgreementsWithNoOpenReservations() {
        final List<ReservationAgreement> reservationAgreementsToCancel =
                ReservationAgreement.findAllOpenReservationAgreementsThatHaveNoOpenReservation();
        new ReservationAgreementCollection(reservationAgreementsToCancel).cancel();
    }

	/**
	 * Sets the context service.
	 *
	 * @param contextService the new context service
	 */
	public void setContextService(final ContextService contextService) {
		this.contextService = contextService;
	}

	/**
     * Setter for the kiosk service.
     * @param kioskService the value.
     */
    public void setKioskService(final KioskService kioskService) {
        this.kioskService = kioskService;
    }

    /**
	 * Sets the menards service.
	 *
	 * @param menardsService the new menards service
	 */
	public void setMenardsService(final MenardsService menardsService) {
		this.menardsService = menardsService;
	}

    /**
	 * Sets the reservation rules.
	 *
	 * @param reservationRules the new reservation rules
	 */
	public void setReservationRules(final List<ReservationRule> reservationRules) {
		this.reservationRules = reservationRules;
	}

    /**
     * The setter for the team service.
     * @param teamService the value to set.
     */
    public void setTeamService(final TeamService teamService) {
        this.teamService = teamService;
    }
}
