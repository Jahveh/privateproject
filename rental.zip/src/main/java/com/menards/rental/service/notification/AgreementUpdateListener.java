/**
 * AgreementUpdateListener.java
 */
package com.menards.rental.service.notification;

/**
 * The listener interface that should be implemented by all the agreement update listeners.
 *
 * @author deep
 */
public interface AgreementUpdateListener extends Listener<AgreementUpdateEvent> {
}
