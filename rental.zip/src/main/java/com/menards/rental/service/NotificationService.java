package com.menards.rental.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementCollection;
import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.Item;
import com.menards.rental.domain.Report;
import com.menards.rental.domain.ReservationAgreement;
import com.menards.rental.utils.Constants;

/**
 * The email notification service so that various notifications could be sent to the GM's when required.
 * @author deep
 */
@Service
public class NotificationService {

    /** The report service reference. */
    @Autowired
    private ReportService reportService;

    /** The log4j logger. */
    private static final Logger logger = Logger.getLogger(NotificationService.class);


    /**
     * Sends the rental override notification mail to the gm.  When there is conflicting reservation at that time
     * we need to send a mail to the gm this is that method.
     * @param agreementItem the rental item which was created by overriding the reservation.
     */
    public void sendRentalOverrideNotificationFor(final AgreementItem agreementItem) {

        final Map<String, Object> model = new HashMap<String, Object>();

        model.put(Constants.Report.AGREEMENT_ITEM_KEY, agreementItem);

        reportService.generateAndPublishReport(
                getReportFor(Report.Type.RENTAL_OVERRIDE_NOTIFICATION_REPORT, agreementItem
                        .getItem().getStoreNumber()), model);
    }

    /**
     * Send the mail to the guest with the pdf attachment of the reservation agreeemnt.
     * @param reservationAgreement the areement that has to be sent to the guest.
     */
    public void sendReservationNotificationFor(final ReservationAgreement reservationAgreement) {
        if (reservationAgreement.getGuest().isEmailProvided()) {

            final Map<String, Object> model = new HashMap<String, Object>();
            model.put(Constants.Report.RESERVATION_AGREEMENT_KEY, reservationAgreement);
            reportService.generateAndPublishReport(
                    getReportFor(Report.Type.RESERVATION_MADE_NOTIFICATION_REPORT,
                            reservationAgreement.getStoreNumber()), model);
        }
    }

    /**
     * Sends the notifications for the agreements that have been cancelled automatically.
     * @param agreements the agreements that have been cancelled automatically because they were old.
     */
    public void sendCancelledAgreementsNotificationsFor(final List<Agreement> agreements) {
        final AgreementCollection agreementCollection = new AgreementCollection(agreements);
        for (final List<Agreement> agreementForStore : agreementCollection.getAgreementsGroupedByStore()) {
            final Agreement agreement = agreementForStore.get(0);
            final Report report = getReportFor(Report.Type.AGREEMENTS_CANCELLED_NOTIFICATION_REPORT,
                    agreement.getStoreNumber());

            final HashMap<String, Object> map = new HashMap<String, Object>();
            map.put(Constants.Report.CANCELLED_AGREEMENTS_KEY, agreementForStore);
            map.put(Constants.Report.STORE_KEY, agreement.getStore());
            generateAndPublishReport(report, map);
        }
    }

    /**
     * The setter for the report service.
     * @param reportService the value to set.
     */
    public void setReportService(final ReportService reportService) {
        this.reportService = reportService;
    }

    /**
     * Returns the report reference for the given type.
     * @param type the type of the report to create.
     * @param storeNumber the store number for which the report is being generated.
     * @return the report object of the given type.
     */
    private Report getReportFor(final Report.Type type, final Integer storeNumber) {
        final Report report = new Report();
        report.setType(type);
        report.setStoreNumber(storeNumber);
        report.setReportMedium(Constants.ReportMedium.EMAIL);
        return report;
    }

    /**
     * Generates and publishes the given report with the given model.
     * @param report the report that is to be published.
     * @param model the model that is to be used to publish the report.
     */
    private void generateAndPublishReport(final Report report, final Map<String, Object> model) {
        try {
            reportService.generateAndPublishReport(report, model);
        } catch (final Exception e) {
            logger.error(e.getMessage(),  e);
        }
    }
}
