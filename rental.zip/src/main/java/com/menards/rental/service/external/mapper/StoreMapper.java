package com.menards.rental.service.external.mapper;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.menards.rental.domain.CollectionUtil;
import com.menards.rental.domain.ConditionEvaluator;
import com.menards.rental.domain.Store;
import com.menards.rental.domain.StoreHour;
import com.menards.rental.domain.Time;
import com.menards.rental.utils.Constants;
import com.menards.rental.utils.MenardsProperties;
import com.menards.service.yard.StoreHours;
import com.menards.service.yard.StoreHoursList;
import com.menards.service.yard.Yardship;
import com.menards.service.yard.YardshipList;

/**
 * The mapper for mapping yard list into a store.
 *
 * @author deep
 */
@Component
public class StoreMapper {

    /** The menards properties reference. */
    @Autowired
    private MenardsProperties menardsProperties;
    
	/** The log. */
	private static final Logger log = Logger.getLogger(StoreMapper.class);

    /**
     * Maps the yardships list rethrned from the web-service to our domain store object.
     *
     * @param yardShipList the response from the yard service.
     * @param storeNumber  the store number that was queried for.
     * @return the Store reference that was mapped
     * @throws IllegalArgumentException if the store witht he given store number was not found in the yardship list.
     */
    public Store mapToStore(final YardshipList yardShipList, final Integer storeNumber) {
        final Yardship yardship = new CollectionUtil<Yardship>(yardShipList.getYardShip())
                .returnEntityIfConditionIsTrue(new ConditionEvaluator<Yardship>() {

                    public boolean evaluate(final Yardship entity) {
                        return storeNumber.equals(entity.getYardNumber());
                    }
                });
        if (null == yardship) {
            throw new IllegalArgumentException("Store not found for store number: " + storeNumber);
        }

        return mapToStore(yardship);
    }

    /**
     * Maps the store hour list into store hours.
     * @param storesHourList the list that we received from the yard service.
     * @return the list mapped of store hours.
     */
    public List<StoreHour> mapToStoreHours(final StoreHoursList storesHourList) {
        final List<StoreHour> storeHours = new ArrayList<StoreHour>();
        for (final StoreHours storeHoursFromYardService : storesHourList.getStoreHours()) {
            storeHours.add(mapToStoreHour(storeHoursFromYardService));
        }
        return storeHours;
    }

    /**
     * Maps the yardship to the store reference.
     *
     * @param yardship the yardship that is to be mapped to the store.
     * @return the Store reference mapped from the yardship.
     */
    private Store mapToStore(final Yardship yardship) {
        final Store store = new Store();
        store.setStoreNumber(yardship.getYardNumber());
        store.setStoreName(yardship.getName());
        store.setStoreAbbreviation(yardship.getAbbreviation());
        store.setStoreAddress1(yardship.getAddress1());
        store.setStoreAddress2(yardship.getCity());
        store.setStorePostalNumber(Integer.parseInt(yardship.getPostalCode().replaceAll("-", "")));
        store.setStoreFaxNumber(yardship.getFaxNumber());
        store.setStorePhoneNumber(yardship.getPhoneNumber());
        store.setKioskHost(Constants.YardServiceConstants.DNS_PREFIX + yardship.getYardNumber());
        
        if (null != menardsProperties.getKioskHost()) {
            store.setKioskHost(menardsProperties.getKioskHost());
        }

        log.info("Hostname for kiosk server: " + store.getKioskHost());
        
        return store;
    }

    /**
     *  Maps the storeHours received from yard service to StoreHour domain object.
     *
     * @param storeHoursFromYardService the store hours from yard service.
     * @return the mapped store hour.
     */
    private StoreHour mapToStoreHour(final StoreHours storeHoursFromYardService) {
        final StoreHour storeHour = new StoreHour();

        storeHour.setStoreNumber(storeHoursFromYardService.getStoreNumber());
        storeHour.setMondayOpen(new Time(storeHoursFromYardService.getMondayOpenTime()));
        storeHour.setMondayClose(new Time(storeHoursFromYardService.getMondayCloseTime()));
        storeHour.setTuesdayOpen(new Time(storeHoursFromYardService.getTuesdayOpenTime()));
        storeHour.setTuesdayClose(new Time(storeHoursFromYardService.getTuesdayCloseTime()));
        storeHour.setWednesdayOpen(new Time(storeHoursFromYardService.getWednesdayOpenTime()));
        storeHour.setWednesdayClose(new Time(storeHoursFromYardService.getWednesdayCloseTime()));
        storeHour.setThursdayOpen(new Time(storeHoursFromYardService.getThursdayOpenTime()));
        storeHour.setThursdayClose(new Time(storeHoursFromYardService.getThursdayCloseTime()));
        storeHour.setFridayOpen(new Time(storeHoursFromYardService.getFridayOpenTime()));
        storeHour.setFridayClose(new Time(storeHoursFromYardService.getFridayCloseTime()));
        storeHour.setSaturdayOpen(new Time(storeHoursFromYardService.getSaturdayOpenTime()));
        storeHour.setSaturdayClose(new Time(storeHoursFromYardService.getSaturdayCloseTime()));
        storeHour.setSundayOpen(new Time(storeHoursFromYardService.getSundayOpenTime()));
        storeHour.setSundayClose(new Time(storeHoursFromYardService.getSundayCloseTime()));

        return storeHour;
    }

    /**
     * The setter for menards properties.
     * @param menardsProperties the value to set.
     */
    public void setMenardsProperties(final MenardsProperties menardsProperties) {
        this.menardsProperties = menardsProperties;
    }
}
