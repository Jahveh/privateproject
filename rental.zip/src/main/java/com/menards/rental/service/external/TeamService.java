/*
 * TeamService.java
 */
package com.menards.rental.service.external;

import java.util.List;

import com.menards.rental.domain.StoreUserCollection;
import com.menards.rental.domain.StoreUserInfo;
import com.menards.rental.service.external.mapper.TeamMemberMapper;
import com.menards.rental.utils.Constants;
import com.menards.teammember.TeamMemberWebService;
import com.menards.teammember.types.legacy.StoreUser;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.menards.rental.service.ContextService;

/**
 * This is the facade for the the Teamemeber service.
 * @author deep
 */
@Service
public class TeamService {

    /** The log4j logger reference. */
    private static final Logger logger = Logger.getLogger(TeamService.class);

    /** The Team member service. */
    @Autowired
	private TeamMemberWebService teamMemberService;

    /** The context service. */
    @Autowired
    private ContextService contextService;

    /** The team member mapper. */
    @Autowired
    private TeamMemberMapper teamMemberMapper;

    /** The store service reference. */
    @Autowired
    private StoreService storeService;

    /** The cached store users. */
    private final Cache<StoreUserCollection> storeUsers = new Cache<StoreUserCollection>();


    /**
      * Get Front End Manager Email for Current Store.
      * 
      * @return the string reprsenting the front end manager email for the current store.
      */
     public String getFrontEndManagerEmailForCurrentStore() {
         try {
             return formatFrontEndManagerEmail(contextService.getUser().getStore().getStoreAbbreviation());
         } catch(final Exception e) {
             logger.debug("Could not get front end manager email for current store.  " +
                     "This is normal.  This could happen because request is coming from an automated report creator");
             logger.debug(e.getMessage(), e);
             return null;
         }
     }

     /**
      * Gets the front end manager email address for the given store number.  If the store number is null
      * this method returns the email address for the current store.
      * @param storeNumber the store number for which we have to find the front end manager email.
      * @return the string value representing the front end manager email address.
      */
     public String getFrontEndManagerEmailFor(final Integer storeNumber) {
         if (null == storeNumber) {
             return getFrontEndManagerEmailForCurrentStore();
         }
         return formatFrontEndManagerEmail(storeService.getStoreByStoreNumber(storeNumber)
                 .getStoreAbbreviation());
     }
     
     /**
      * Formats the store abbreviation to the front end manager email address.
      * @param storeAbbreviation the store abbreviation from which we have to format the FEM email.
      * @return the string value representing the front end manager email address.
      */
     private String formatFrontEndManagerEmail(final String storeAbbreviation) {
         return storeAbbreviation
                 + Constants.TeamService.FRONT_END_MANAGER_EMAIL_POST_FIX;
     }  
    
    /**
     * Get General Manager Email for Current Store.
     * 
     * @return the string representing the general manager email for the current store.
     */
    public String getGeneralManagerEmailForCurrentStore() {
        try {
            return formatGeneralManagerEmail(contextService.getUser().getStore().getStoreAbbreviation());
        } catch(final Exception e) {
            logger.debug("Could not get general manager email for current store.  " +
                    "This is normal.  This could happen because request is coming from an automated report creator");
            logger.debug(e.getMessage(), e);
            return null;
        }
    }

    /**
     * Gets the general manager email address for the given store number.  If the store number is null
     * this method returns the email address for the current store.
     * @param storeNumber the store number for which we have to find the general manager email.
     * @return the string value representing the general manager email address.
     */
    public String getGeneralManagerEmailFor(final Integer storeNumber) {
        if (null == storeNumber) {
            return getGeneralManagerEmailForCurrentStore();
        }
        return formatGeneralManagerEmail(storeService.getStoreByStoreNumber(storeNumber)
                .getStoreAbbreviation());
    }

    /**
     * Get the list of general Managers.
     *
     * @return List of all the general manager names for the current store.
     * @throws IllegalStateException if team member service fails while getting the store users.
     */
    public List<StoreUserInfo> getGeneralManagerForCurrentStore() {
        return getStoreUsersForCurrentStore().getGeneralManagers();
	}

    /**
     * Returns the store user by the user id passed as argument.
     * @param userId the id of the user for which we have to search the store user.
     * @return the StoreUserInfo reference for the matching user id.  Null if none found.
     */
    public StoreUserInfo getStoreUserByIdForCurrentStore(final Integer userId) {
        return getStoreUsersForCurrentStore().getStoreUserById(userId);
    }

    /**
     * Initialize will set the generalManages Map to null. This will
     * be called by the schedular every day morning and the general manager
     * list will be build and cached as and when the general manager for a
     * store is asked for.
     *
     */
    public void init() {
        storeUsers.clear();
    }

    /**
     * Set the context service.
     *
     * @param contextService the value.
     */
    public void setContextService(final ContextService contextService) {
        this.contextService = contextService;
    }

    /**
     * The setter for the team member mapper.
     * @param teamMemberMapper the value to set.
     */
    public void setTeamMemberMapper(final TeamMemberMapper teamMemberMapper) {
        this.teamMemberMapper = teamMemberMapper;
    }

    /**
     * The getter for the general managers cache.
     * @return the cached general managers.
     */
    public Cache<StoreUserCollection> getStoreUsers() {
        return storeUsers;
    }

    /**
     * Returns the store users collection for the current store.  First this method will lookup the values in the cache
     * if the values are not found in the cache then a call to the team service will be made.
     * @return the StoreUserCollection for the current store.
     */
    private StoreUserCollection getStoreUsersForCurrentStore() {
        final Integer storeNumber = contextService.getStoreNumber();
        if (null != storeUsers.lookup(storeNumber)) {
            return storeUsers.lookup(storeNumber);
        }

        try {
            //Fetch the store User list
            final List<StoreUser> storeUserList = teamMemberService.getStoreUsersByStoreNumber(storeNumber);

            storeUsers.put(teamMemberMapper.mapToStoreUsers(storeUserList, storeNumber));
            return storeUsers.lookup(storeNumber);
        } catch (final RuntimeException e) {
            logger.warn(e.getMessage(), e);
            throw new IllegalStateException(e);
        }
    }

    /**
     * Formats the store abbreviation to the general manager email address.
     * @param storeAbbreviation the store abbreviation from which we have to format the gm email.
     * @return the string value representing the general manager email address.
     */
    private String formatGeneralManagerEmail(final String storeAbbreviation) {
        return storeAbbreviation
                + Constants.TeamService.GENERAL_MANAGER_EMAIL_POST_FIX;
    }
}
