/**
 * PDFReader.java
 */
package com.menards.rental.service.archive;

import com.menards.rental.dao.ArchivedAgreementDataDao;
import com.menards.rental.domain.ArchivedAgreement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * The pdf reader that reads the pdf at a given path.
 *
 * @author deep
 */
@Component
public class PDFReader {

    /** The archived agreement data dao. */
    @Autowired
    private ArchivedAgreementDataDao archivedAgreementDataDao;

    /**
     * Reads the pdf at the given archivedAgreement and returns the byte array of the pdf.
     *
     * @param archivedAgreement the archivedAgreement to read.
     * @return the byte array of the pdf.
     */
    public byte[] read(final ArchivedAgreement archivedAgreement) {
        return archivedAgreementDataDao.getArchiveDataFor(archivedAgreement.getId()).getData();
    }

    /**
     * The setter for the dao.
     * @param archivedAgreementDataDao the value to set.
     */
    public void setArchivedAgreementDataDao(final ArchivedAgreementDataDao archivedAgreementDataDao) {
        this.archivedAgreementDataDao = archivedAgreementDataDao;
    }
}
