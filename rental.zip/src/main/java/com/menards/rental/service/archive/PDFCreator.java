/**
 * PDFCreator.java
 */
package com.menards.rental.service.archive;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import com.menards.rental.domain.ArchivePath;
import com.menards.rental.domain.GuestArchiveInfo;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.*;

/**
 * The class that is responsible for creating the pdf.
 *
 * @author deep
 */
@Component
public class PDFCreator {

    /** The logger. */
    private static final Logger logger = Logger.getLogger(PDFCreator.class);

    /**
     * This method creates the pdf using the information from the archive path.
     * @param archivePath the archive path that holds information about the url and directory path where the archive.
     * @return the byte array representing the pdf document.
     */
    public byte[] create(final ArchivePath archivePath) {
        try {
            final ITextRenderer iTextRenderer = new ITextRenderer();
            logger.info("Parsing the html document at: " + archivePath.getURLFrom());
            iTextRenderer.setDocument(archivePath.getURLFrom());
            iTextRenderer.layout();
            final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            iTextRenderer.createPDF(byteArrayOutputStream);
            iTextRenderer.finishPDF();
            final byte[] pdfBytes = byteArrayOutputStream.toByteArray();
            byteArrayOutputStream.close();
            logger.info("Done creating PDF");
            return pdfBytes;
        } catch (final DocumentException e) {
            logger.error(e.getMessage(), e);
            return null;
        } catch (final IOException e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    /**
     * This method updates the pdf archive with the passed in guest information.
     * @param archiveToUpdate the archive to update/
     * @param guestArchiveInfo the guest information which which the archive is to be updated.
     * @return the byte array representing the updated archive.
     */
    public byte[] update(final byte[] archiveToUpdate, final GuestArchiveInfo guestArchiveInfo) {
        try {
            final Document document = new Document();
            final PdfReader pdfReader = new PdfReader(archiveToUpdate);
            final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            final PdfWriter pdfWriter = PdfWriter.getInstance(document, outputStream);

            document.open();
            final PdfContentByte cb = pdfWriter.getDirectContent(); // Holds the PDF

            for (int i = 1; i <= pdfReader.getNumberOfPages(); i++) {
                document.newPage();
                final PdfImportedPage importedPage = pdfWriter.getImportedPage(pdfReader, i);
                cb.addTemplate(importedPage, 0, 0);
            }
            document.newPage();
            document.add(new Paragraph(guestArchiveInfo.getStoreLine1()));
            document.add(new Paragraph(guestArchiveInfo.getStoreLine2()));
            document.add(new Paragraph(guestArchiveInfo.getSignatureLine()));
            if( null != guestArchiveInfo.getSignatureData()) {
                document.add(Image.getInstance(guestArchiveInfo.getSignatureData()));
            }
            document.add(new Paragraph(guestArchiveInfo.getLegalText()));

            outputStream.flush();
            document.close();
            pdfWriter.close();
            pdfReader.close();
            final byte[] updatedPDFBytes = outputStream.toByteArray();
            outputStream.close();
            return updatedPDFBytes;
        } catch (final IOException e) {
            logger.error(e.getMessage(), e);
        } catch (final DocumentException e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }
}
