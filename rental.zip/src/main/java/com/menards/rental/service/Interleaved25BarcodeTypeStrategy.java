package com.menards.rental.service;

import com.menards.rental.barcode.BarcodeDetails;
import org.krysalis.barcode4j.impl.AbstractBarcodeBean;
import org.krysalis.barcode4j.impl.int2of5.Interleaved2Of5Bean;
import org.springframework.stereotype.Component;

/**
 * The interleaved 25 barcode type strategy.
 *
 * @author deep
 */
@Component(value = "interleaved25BarcodeTypeStrategy")
public class Interleaved25BarcodeTypeStrategy implements BarcodeTypeStrategy {

    /**
     * {@inheritDoc}
     */
    public AbstractBarcodeBean getBean(final BarcodeDetails barcodeDetails) {

        final Interleaved2Of5Bean bean = new Interleaved2Of5Bean();
        // Configure the barcode generator

		bean.setModuleWidth(barcodeDetails.getNarrowBarWidth());
		bean.setWideFactor(barcodeDetails.getWidthFactor());
		bean.doQuietZone(false);
		bean.setBarHeight(barcodeDetails.getBarHeight());
        bean.setFontSize(2.4);
        return bean;
    }
}
