/**
 * ArchivedAgreementItemMapper.java
 */
package com.menards.rental.service.archive.mapper;

import com.menards.rental.domain.*;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

/**
 * The class that will be used to map the archived agreement items.
 *
 * @author deep
 */
@Component
public class ArchivedAgreementItemMapper {

    /**
     * The mapper for mapping the agreement items to archived agreement items.
     *
     * @param items the items that have to be mapped.
     * @param agreement the agreement which which this items are associated.
     * @return the list of mapped archived agreement items.
     */
    public Set<ArchivedAgreementItem> mapToArchivedAgreementItems(final Set<AgreementItem> items,
                                                                  final ArchivedAgreement agreement) {
        final HashSet<ArchivedAgreementItem> archivedItems = new HashSet<ArchivedAgreementItem>();
        new AgreementItemCollection(items).doInLoop(new ExpressionEvaluator<AgreementItem>() {

            /**
             * {@inheritDoc}
             */
            public void evaluate(final AgreementItem entity) {
                archivedItems.add(mapToArchivedAgreement(entity, agreement));
            }
        });
        return archivedItems;
    }

    /**
     * The method that will map agreement item to archived agreement item.
     * @param agreementItem the agreement item that is to be mapped.
     * @param agreement the archived agreement reference.
     * @return the Archived agreement item reference.
     */
    private ArchivedAgreementItem mapToArchivedAgreement(final AgreementItem agreementItem,
                                                         final ArchivedAgreement agreement) {
        final ArchivedAgreementItem archivedAgreementItem = new ArchivedAgreementItem();
        archivedAgreementItem.setItem(agreementItem.getItem());
        archivedAgreementItem.setAgreement(agreement);
        return archivedAgreementItem;
    }


}
