/**
 * AgreementArchiveUpdateListener.java
 */
package com.menards.rental.service.notification;

import com.menards.rental.dao.ArchivedAgreementDataDao;
import com.menards.rental.domain.ArchivedAgreement;
import com.menards.rental.service.archive.PDFArchiver;
import com.menards.rental.service.archive.mapper.ArchivedAgreementMapper;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;

/**
 * The class that is responsible for archiving the agreements as soon as it gets an event.
 *
 * @author deep
 */
@Component
@Transactional(propagation = Propagation.REQUIRED)
public class AgreementArchiveUpdateListener implements AgreementUpdateListener {
    /**
     * The log4j logger.
     */
    private static final Logger logger = Logger.getLogger(AgreementArchiveUpdateListener.class);

    /**
     * The agreement update notifier reference.
     */
    @Autowired
    private AgreementUpdateNotifier agreementUpdateNotifier;

    /** The pdf archiver reference. */
    @Autowired
    private PDFArchiver pdfArchiver;

    /** The archived areement mapper. */
    @Autowired
    private ArchivedAgreementMapper archivedAgreementMapper;

    /** The agreement archive data dao reference. */
    @Autowired
    private ArchivedAgreementDataDao archivedAgreementDataDao;

    /**
     * This method will register the this reference with the notifier.
     */
    @PostConstruct
    public void registerWithTheNotifier() {
        agreementUpdateNotifier.addListener(this);
    }

    /**
     * {@inheritDoc}
     */
    public void notifyUpdate(final AgreementUpdateEvent event) {
        final ArchivedAgreement archivedAgreement = ArchivedAgreement.findArchivedAgreementByAgreementNumber(
                event.getAgreementNumber());

        if (null != archivedAgreement) {
            logger.info("Already an archived record exists for the agreement # " + event.getAgreementNumber()
                    + " Need to remove this record so that an update could be created");
            archivedAgreement.remove();
            archivedAgreement.flush();
            archivedAgreementDataDao.removeArchiveData(archivedAgreement);
        }

        byte[] archiveData = pdfArchiver.archive(event.getAgreement());
        final ArchivedAgreement agreement = archivedAgreementMapper.mapToArchivedAgreement(
                event.getAgreement());

        agreement.persist();

        archivedAgreementDataDao.createArchiveData(agreement, archiveData);
        archiveData = null;
    }

    /**
     * The setter for the notifier.
     * @param agreementUpdateNotifier the value to set.
     */
    public void setAgreementUpdateNotifier(final AgreementUpdateNotifier agreementUpdateNotifier) {
        this.agreementUpdateNotifier = agreementUpdateNotifier;
    }

    /**
     * The setter for the pdf archiver.
     * @param pdfArchiver the value to set.
     */
    public void setPDFArchiver(final PDFArchiver pdfArchiver) {
        this.pdfArchiver = pdfArchiver;
    }

    /**
     * The setter for the archived agreement mapper.
     * @param archivedAgreementMapper the value to set.
     */
    public void setArchivedAgreementMapper(final ArchivedAgreementMapper archivedAgreementMapper) {
        this.archivedAgreementMapper = archivedAgreementMapper;
    }

    /**
     * The setter for the data dao.
     * @param archivedAgreementDataDao the value to set.
     */
    public void setArchivedAgreementDataDao(final ArchivedAgreementDataDao archivedAgreementDataDao) {
        this.archivedAgreementDataDao = archivedAgreementDataDao;
    }
}
