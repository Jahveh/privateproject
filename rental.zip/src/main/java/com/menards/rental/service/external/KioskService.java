/*
 * KioskService.java
 */
package com.menards.rental.service.external;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.Guest;
import com.menards.rental.domain.KioskProductDetail;
import com.menards.rental.domain.KioskSKUDetail;
import com.menards.rental.domain.Product;
import com.menards.rental.service.external.exception.KioskException;
import com.menards.rental.service.external.mapper.KioskRequestResponseMapper;
import com.menards.rental.utils.Constants;

/**
 * The Class KioskService.
 */
@Service
public class KioskService {

    /**
     * The Constant logger.
     */
    private static final Log logger = LogFactory.getLog(KioskService.class);


    /**
     * The kiosk gateway this is the one that actually talks to the kiosk server.
     */
    @Autowired
    private KioskGateway kioskGateway;

    /**
     * The kiosk request and response mapper.
     */
    @Autowired
    private KioskRequestResponseMapper kioskRequestResponseMapper;

    /**
     * Send the agreement information to Kiosk which has been cancelled in rental.
     *
     * @param agreement the agreement that is to be canceled.
     */
    public void cancelAgreement(final Agreement agreement) {
        try {
            final DynaBean request = kioskRequestResponseMapper.mapToCancelAgreementRequeste(agreement);

            List<DynaBean> rentalSkuResults = kioskGateway.processRequestFor(request, agreement.getStoreNumber());

            if ((null == rentalSkuResults) || (rentalSkuResults.isEmpty())) {
                logger.error("Could not cancel the agreement #" + agreement.getAgreementNumber());
                return;
            }
            final DynaBean result = rentalSkuResults.get(0);
            if (isErrorResult(result)) {
                logger.error("Error while canceling the agreement at kiosk server #" + agreement.getAgreementNumber()
                		+ " Error message code #" + result.get("errorCode"));
//                logger.error("Error message code #" + result.get("errorCode"));
                if(result.get("errorCode") != "506"){
                	throw new KioskException();
                }
            }

            logger.info("Cancel successful at Kiosk for " + agreement.getAgreementNumber());
        } catch (KioskCommunicationException e) {
            logger.warn("Cancel Agreement not successful in Kiosk for Agreement # " 
            			+ agreement.getAgreementNumber()
            			+ " -" + e.getMessage(), e);
//            logger.error(e.getMessage(), e);
            throw new KioskException();
        }
    }

    /**
     * The method that will cancel the previous agreement if the agreement is still in the pending state.  This should
     * be done so that the old agreement is not recallable at the register.
     * @param agreement the new agreement that was saved.
     * @param agreementNumber the old agreement number.
     */
    public void cancelPreviousAgreementIfRequired(final Agreement agreement, final String agreementNumber) {
        if(agreementNumber.endsWith(Constants.Agreement.NO_REVISION_SUFFIX)) {
            logger.debug("Should not cancel the agreement: " + agreementNumber + " as its no longer in pending state");
            return;
        }
        try {
            final DynaBean request = kioskRequestResponseMapper
                    .mapToCancelAgreementRequesteWithAgreementNumber(agreement, agreementNumber);

            List<DynaBean> rentalSkuResults = kioskGateway.processRequestFor(request, agreement.getStoreNumber());

            if ((null == rentalSkuResults) || (rentalSkuResults.isEmpty())) {
                logger.error("Could not cancel the agreement #" + agreementNumber);
                return;
            }
            final DynaBean result = rentalSkuResults.get(0);
            if (isErrorResult(result)) {
                logger.error("Error while canceling the agreement at kiosk server #" + agreementNumber
                				+ " Error message code #" + result.get("errorCode"));
//                logger.error("Error message code #" + result.get("errorCode"));
                return;
            }

            logger.info("Cancel successful at Kiosk for " + agreementNumber);
        } catch (KioskCommunicationException e) {
            logger.error("Cancel Agreement not successful in Kiosk for Agreement # " + agreementNumber
            				+ " -" + e.getMessage(), e);
//            logger.error(e.getMessage(), e);
        }
    }

    /**
     * Returns the guest list by the phone number passed as argument.
     * @param phoneNumber the phone number to search in kiosk server.
     * @return the list of guests matching the given phone number.
     */
    public List<Guest> getGuestListByPhoneNumber(final String phoneNumber) {
        try {
            final DynaBean request = kioskRequestResponseMapper.mapToGuestListByPhoneNumberRequest(phoneNumber);

            final List<DynaBean> results = kioskGateway.processRequest(request);

            if ((null == results) || (results.isEmpty())) {
                logger.error("Could not get a valid resonse from Kiosk Server for guest phone number: " + phoneNumber);
                return new ArrayList<Guest>();
            }

            return kioskRequestResponseMapper.mapToGuestListFromResults(results, phoneNumber);
        } catch (final KioskCommunicationException ksce) {
            logger.error(ksce.getMessage(), ksce);
        }

        return new ArrayList<Guest>();
    }

    /**
     * The method that returns us the kiosk product detail.  This includes information about all three skus.
     * @param product for which we have to find the sku details.
     * @return the KioskProductDetail reference that holds information about various skus from the kiosk server.
     */
    public KioskProductDetail getKioskProductDetail(final Product product) {
        final KioskProductDetail kioskProductDetail = new KioskProductDetail();
        kioskProductDetail.setBaseSKUDetail(getKioskSKUDetailFor(product.getBaseSkuValue()));
        kioskProductDetail.setIncrementalSKUDetail(getKioskSKUDetailFor(product.getIncrementalSkuValue()));

        if (product.isSurchargeSKUSetup()) {
            kioskProductDetail.setSurchargeSKUDetai(getKioskSKUDetailFor(product.getSurchargeSkuValue()));
        }

        return kioskProductDetail;
    }

    /**
     * Thie method returns the Kiosk SKU details based on the sku number passed.
     * @param sku for which we have to retrieve KioskSKUDetail.
     * @return KioskSKUDetail holding the details on the kiosk server.
     */
    public KioskSKUDetail getKioskSKUDetailFor(final Long sku) {
        try {
            final DynaBean request = kioskRequestResponseMapper.mapToSKUExtendedInfoRequest(sku);
            final List<DynaBean> results = kioskGateway.processRequest(request);
            if ((null == results) || (results.isEmpty())) {
                logger.error("Could not get the sku extended information for #" + sku);
                return null;
            }
            final DynaBean result = results.get(0);
            if (isErrorResult(result)) {
                logger.error("Error returned from the kiosk server while getting sku extended info for #" + sku
                				+ " -Error message code #" + result.get("errorCode"));
//                logger.error("Error message code #" + result.get("errorCode"));
                return null;
            }

            return kioskRequestResponseMapper.mapToKioskSKUDetailFromResults(results);
        } catch (final KioskCommunicationException e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    /**
     * Send agreementto kiosk.
     *
     * @param agreement the agreement
     */
    public void sendAgreementToKiosk(final Agreement agreement) {

        try {
            final DynaBean request = kioskRequestResponseMapper.mapToRentalHeaderRequest(agreement);

            final List<DynaBean> results = kioskGateway.processRequest(request);

            if ((results == null) || (results.isEmpty())) {
//                logger.error("Could not send the agreement to kiosk server #" + agreement.getAgreementNumber());
                logger.warn("Could not send the agreement to kiosk server #" + agreement.getAgreementNumber());
                throw new KioskException();
            }

            final DynaBean result = results.get(0);
            if (isErrorResult(result)) {
                logger.warn("Error while sending the agreement to kiosk server #" + agreement.getAgreementNumber()
                				+ " -Error message code #" + result.get("errorCode"));
//                logger.error("Error message code #" + result.get("errorCode"));
                throw new KioskException();
            }
            logStatus(result);

            sendAgreementItemsToKiosk(agreement);
        } catch (final KioskCommunicationException e) {
//            logger.error(e.getMessage(), e);
            logger.warn(e.getMessage(), e);
            throw new KioskException();
        }
    }

    /**
     * The setter for the kiosk gateway.
     *
     * @param kioskGateway the kiosk gateway.
     */
    public void setKioskGateway(final KioskGateway kioskGateway) {
        this.kioskGateway = kioskGateway;
    }

    /**
     * Setter for the kioskRequestResponseMapper.
     *
     * @param kioskRequestResponseMapper The kiosk requeset response mapper.
     */
    public void setKioskRequestResponseMapper(final KioskRequestResponseMapper kioskRequestResponseMapper) {
        this.kioskRequestResponseMapper = kioskRequestResponseMapper;
    }

    /**
     * This method will sync inventory with the kiosk server.  Sends the total rentable items count
     * to the server.
     * @param product the product for which the inventory is to be updated.
     * @param totalRentableItems the number of items that are currently rentable in the system.
     * @throws com.menards.rental.service.external.exception.KioskException when sync inventory is not successful.
     */
    public void syncInventory(final Product product, final long totalRentableItems) {
        try {
            final DynaBean request = kioskRequestResponseMapper.mapToSyncInventoryRequest(product, totalRentableItems);
            final List<DynaBean> results = kioskGateway.processRequest(request);
            if ((null == results) || (results.isEmpty())) {
//                logger.error("Could not sync inventory with kiosk server");
                logger.warn("Could not sync inventory with kiosk server");
                throw new KioskException();
            }

            final DynaBean result = results.get(0);
            if (isErrorResult(result)) {
//                logger.error("Error while sync inventory " + result);
                logger.warn("Error while sync inventory " + result);
                logError(result);
                throw new KioskException();
            }
        } catch (final KioskCommunicationException e) {
//            logger.error(e.getMessage(), e);
            logger.warn(e.getMessage(), e);
            throw new KioskException(e);
        }
    }

    /**
     * Send the agreement information to Kiosk which has been voided in rental.
     *
     * @param agreementNumber for which the void request is to be sent.
     */
    public void voidAgreement(final String agreementNumber) {
        try {
            final DynaBean request = kioskRequestResponseMapper.mapToVoidAgreementRequest(agreementNumber);

            List<DynaBean> rentalSkuResults = kioskGateway.processRequest(request);

            if ((null == rentalSkuResults) || (rentalSkuResults.isEmpty())) {
                logger.error("Could not void the agreement #" + agreementNumber);
                return;
            }
            final DynaBean result = rentalSkuResults.get(0);
            if (isErrorResult(result)) {
                logger.warn("Got an error while voiding the agreement #" + agreementNumber
                				+ " -Error message code #" + result.get("errorCode"));
//                logger.error("Error message code #" + result.get("errorCode"));
                throw new KioskException();
            }

            logger.info("Void successful at Kiosk for " + agreementNumber);
        } catch (KioskCommunicationException e) {
            logger.warn("void Agreement not successful in Kiosk for Agreement # " + agreementNumber
            				+ " -" + e.getMessage(), e);
//            logger.error(e.getMessage(), e);
            throw new KioskException();
        }
    }

    /**
     * The method that populates the unmasked identification numbers for the given agreement.
     * @param agreement the agreement reference for which we need to get back the unmasked value.
     * @param agreementNumber for which we need to get the unmasked value.
     */
    public void populateUnMaskedIdentificationNumbers(final Agreement agreement,
                                                      final String agreementNumber) {
        try {
            final DynaBean request = kioskRequestResponseMapper.mapToUnMaskIdentificationRequest(agreementNumber);

            List<DynaBean> results = kioskGateway.processRequest(request);

            if ((null == results) || (results.isEmpty())) {
                logger.error("Could not get the unmasked value for the identification number #"
                        + agreement.getAgreementNumber());
                return;
            }
            final DynaBean result = results.get(0);
            if (isErrorResult(result)) {
                logger.error("Got an error while getting the unmasked identification number for agreement #"
                        + agreement.getAgreementNumber() 
                        + " -Error message code #" + result.get("errorCode"));
//                logger.error("Error message code #" + result.get("errorCode"));
                return;
            }

            logger.info("Found the unmasked identification number for # " + agreementNumber);
            kioskRequestResponseMapper.mapToUnMaskedIdentificationNumbers(results, agreement);
        } catch (final KioskCommunicationException e) {
            logger.error("Could not get the unmasked value for # " + agreement.getAgreementNumber()
            				+ " -" + e.getMessage(), e);
//            logger.error(e.getMessage(), e);
        }
    }

    /**
     * Send the agreement items to the kiosk server.
     *
     * @param agreement - The agreement whose items need to be sent.
     */
    private void sendAgreementItemsToKiosk(final Agreement agreement) {
        // Now send the rental details
        AgreementItem agreementItemToSendWithComments = null;
        for (final AgreementItem agreementItem : agreement.getItems()) {
            sendAgreementItemToKiosk(agreementItem);
            agreementItemToSendWithComments = agreementItem;
        }
        sendAgreementItemComments(agreement, agreementItemToSendWithComments);
    }

    /**
     * Sends the agremeent item comments if required to the kiosk server.
     * @param agreement the agreement that is to be sent.
     * @param agreementItem the agreement item whos sku should be sent to kiosk server.
     */
    private void sendAgreementItemComments(final Agreement agreement, final AgreementItem agreementItem) {
        final List<DynaBean> requests = kioskRequestResponseMapper.mapToRentalDetailCommentRequests(
                agreement, agreementItem);

        for (final DynaBean request : requests) {
            final List<DynaBean> results = kioskGateway.processRequest(request);
            if ((null == results) || (results.isEmpty())) {
                logger.info("No Response returned when sending agreement comments and insurance info to KIOSK server");
                return;
            }

            final DynaBean result = results.get(0);
            logStatus(result);
        }
    }

    /**
     * Send agreement item to kiosk.
     *
     * @param agreementItem the agreement item.
     */
    private void sendAgreementItemToKiosk(final AgreementItem agreementItem) {
        if (agreementItem.isCheckedOutAndPaid() || agreementItem.isReturnedAndPaidComplete()) {
            logger.debug("The current item is being returned and paid complete or is checked out and paid complete.");
            logger.debug("No need to send this item to KIOSK: " + agreementItem.getDescription());
            return;
        }
        sendBaseChargeOfAgreementItemToKiosk(agreementItem);
        sendSurchargeChargeOfAgreementItemToKiosk(agreementItem);
        sendAdditionalChargeOfAgreementItemToKiosk(agreementItem);
        sendDamageWaiverToKiosk(agreementItem);
        sendOtherAdditionalChargesOfAgreementItemToKiosk(agreementItem);
    }

    /**
     * The method that will send only the base charge of the agreement item to the kiosk server.
     * @param agreementItem the agreement item whose base charge is to be sent to the kiosk server.
     */
    private void sendBaseChargeOfAgreementItemToKiosk(final AgreementItem agreementItem) {
        if(agreementItem.isInitialChargeNotApplicable()) {
            logger.debug("The item is currently being returned: " + agreementItem.getDescription());
            logger.debug("We do not refund the base charges hence no need to send this to kiosk");
            return;
        }
        final DynaBean request = kioskRequestResponseMapper.mapToBaseRentalDetailRequest(agreementItem);

        final List<DynaBean> results = kioskGateway.processRequest(request);

        if ((null == results) || (results.isEmpty())) {
            logger.info("No Response returned when sending base agreement details to KIOSK server");
            return;
        }

        final DynaBean result = results.get(0);
        logStatus(result);
    }

    /**
     * The method that will send only the surcharge charge of the agreement item to the kiosk server.
     * @param agreementItem the agreement item whose surcharge charge is to be sent to the kiosk server.
     */
    private void sendSurchargeChargeOfAgreementItemToKiosk(final AgreementItem agreementItem) {
        if(agreementItem.getItem().getProduct().getSkuInfo().getSurchargeSKU() == null) {
            logger.debug("No surcharge found for item: " + agreementItem.getDescription());
            return;
        }
        if(agreementItem.isInitialChargeNotApplicable()) {
            logger.debug("The item is currently being returned: " + agreementItem.getDescription());
            logger.debug("We do not refund the surcharge charges hence no need to send this to kiosk");
            return;
        }
        final DynaBean request = kioskRequestResponseMapper.mapToSurchargeRentalDetailRequest(agreementItem);

        final List<DynaBean> results = kioskGateway.processRequest(request);

        if ((null == results) || (results.isEmpty())) {
            logger.info("No Response returned when sending surcharge agreement details to KIOSK server");
            return;
        }

        final DynaBean result = results.get(0);
        logStatus(result);
    }

    /**
     * The method that will send only the additional charge of the agreement item to the kiosk server.
     * @param agreementItem the agreement item whose additional charge is to be sent to the kiosk server.
     */
    private void sendAdditionalChargeOfAgreementItemToKiosk(final AgreementItem agreementItem) {
        if(agreementItem.getIncrementalTimeUnitsByStatus() == 0) {
            logger.debug("No Incremental charge applied while checkout or checkin to: " + agreementItem.getDescription());
            return;
        }

        final DynaBean request = kioskRequestResponseMapper.mapToAdditionalRentalDetailRequest(agreementItem);

        final List<DynaBean> results = kioskGateway.processRequest(request);

        if ((null == results) || (results.isEmpty())) {
            logger.info("No Response returned when sending additional charge agreement details to KIOSK server");
            return;
        }

        final DynaBean result = results.get(0);
        logStatus(result);
    }

    /**
     * The method that will send only the additional charge of the agreement item to the kiosk server.
     * @param agreementItem the agreement item whose additional charge is to be sent to the kiosk server.
     */
    private void sendOtherAdditionalChargesOfAgreementItemToKiosk(final AgreementItem agreementItem) {
        if(!agreementItem.isReturned()) {
            logger.debug("The item is not being returned right now: " + agreementItem.getDescription());
            logger.debug("This means we will not have any other charges on the item");
            return;
        }

        final List<DynaBean> requests = kioskRequestResponseMapper
                .mapToOtherAdditionalChargesRentalDetailRequest(agreementItem);

        for (final DynaBean request : requests) {
            final List<DynaBean> results = kioskGateway.processRequest(request);
            if ((null == results) || (results.isEmpty())) {
                logger.info("No Response returned when sending agreement other additional charges to KIOSK server");
                return;
            }

            final DynaBean result = results.get(0);
            logStatus(result);
        }
    }

    /**
     * Sends the damage waiver total value to the kiosk server.
     * @param agreementItem the agreementItem whose damage waiver value is to be sent.
     */
    private void sendDamageWaiverToKiosk(final AgreementItem agreementItem) {
        if(!agreementItem.getIsDamageWaiverAvailable()) {
            logger.debug("The damage waiver is not available for this item.  No need to send it to kiosk: "
                    + agreementItem.getDescription());
            return ;
        }
        if(agreementItem.getDamageWaiverAmountByStatus().compareTo(Constants.DamageWaiver.DAMAGE_WAIVER_DEFAULT_AMOUNT) == 0) {
            logger.debug("The damage waiver for this item is zero in the current state.  No need to send it to kiosk: "
                    + agreementItem.getDescription());
            return;
        }

        final DynaBean request = kioskRequestResponseMapper.mapToDamageWaiverRentalDetailRequest(agreementItem);

        final List<DynaBean> results = kioskGateway.processRequest(request);

        if ((null == results) || (results.isEmpty())) {
            logger.info("No Response returned when sending damage waiver agreementItem details to KIOSK server");
            return;
        }

        final DynaBean result = results.get(0);
        logStatus(result);
    }

    /**
     * Returns true if the response has message type as error.
     * @param result the result from the kiosk server.
     * @return true if the response has errors.
     */
    private boolean isErrorResult(final DynaBean result) {
        return (result == null)
                || (Constants.Kiosk.ERROR_RESPONSE_TYPE.equals(result.get("messageType")))
                || (Constants.Kiosk.ERROR_RESPONSE_TYPE.equals(result.get("status")));
    }

    /**
     * Log the status value.
     *
     * @param result The result from which we need to log the value.
     */
    private void logStatus(final DynaBean result) {
        logger.info("status: " + result.get("status"));
    }

    /**
     * Logs the exact error to the logger stream.
     * @param result the response we got from the kiosk server.
     */
    private void logError(final DynaBean result) {
        if (result == null) {
            return;
        }
        logger.error("Error code: " + result.get("messageCode") + " Error Message: " + result.get("message"));
//        logger.error("Error Message: " + result.get("message"));
    }
}
