package com.menards.rental.service.external;

import com.menards.rental.domain.*;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * A simple implementation of the cache.  This class can cache any object.  It provides methods to put, get and reset
 * the cache.
 *
 * @author deep
 * @param <T> the type of object we will be caching in this cache.
 */
public class Cache<T extends Cachable> {
    /**
     * The map that holds stores information that is cached.
     * Initializing it with a Hashtable because multiple threads might access this map simultaneously.
     * We need synchroneous access.  Please dont change it to HashMap.
     */
    private final Map<Integer, T> values = new Hashtable<Integer, T>();

    /**
     * Returns the cached value matching the key passed as argument.
     * @param key the key to be looked for.
     * @return the Cached reference if available else returns null.
     */
    public T lookup(final Integer key) {
        return values.get(key);
    }

    /**
     * The method that puts the entity in the cache.
     * @param value the value to be put in the cache.
     */
    public void put(final T value) {
        values.put(value.getKey(), value);
    }

    /**
     * Returns the set of keys that are held by the cache.
     * @return the set of keys that are held by the cache.
     */
    public Set<Integer> keys() {
        return values.keySet();
    }

    /**
     * The method puts all the values into the cache.  The cache key is obtained from the cacheable interface.
     * @param values the list of values that have to be put in the cache.
     */
    public void putAll(final List<T> values) {
        new CollectionUtil<T>(values).doInLoop(new ExpressionEvaluator<T>() {

            public void evaluate(final T entity) {
                Cache.this.put(entity);
            }
        });
    }

    /**
     * Should clear the cache.
     */
    public void clear() {
        values.clear();
    }

    /**
     * Should return true if the cache is empty.
     * @return true if cache is empty, false otherwise.
     */
    public boolean isEmpty() {
        return values.isEmpty();
    }
}
