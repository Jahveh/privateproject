/*
 * GuestService.java
 */
package com.menards.rental.service;

import java.util.Iterator;
import java.util.List;

import com.menards.rental.domain.Agreement;
import com.menards.rental.service.external.KioskService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.menards.rental.domain.Guest;

/**
 * The guest service this class deals with reading guest info from kiosk server.
 * @author deep
 */
@Service
public class GuestService {

    /** The logger. */
    private static final Logger logger = Logger.getLogger(GuestService.class);

	/** The Kiosk service. */
	@Autowired
	private KioskService kioskService;

	/**
	 * Find guests by phone number.
	 *
	 * @param guestPhoneNumber the guest phone number
	 * @return the list
	 */
	public List<Guest> findGuestsByPhoneNumber(final String guestPhoneNumber) {
        final List<Guest> guests = kioskService.getGuestListByPhoneNumber(guestPhoneNumber);
        final Iterator<Guest> iterator = guests.iterator();
        while(iterator.hasNext()) {
            final Guest guest = iterator.next();
            if(!guest.hasValidZipCode()) {
                iterator.remove();
            }
        }
        return guests;
	}

	/**
	 * Sets the kiosk service.
	 *
	 * @param kioskService the new kiosk service
	 */
	public void setKioskService(final KioskService kioskService) {
		this.kioskService = kioskService;
	}

    /**
     * Populates the unmasked identification number in the agreement.
     * This is only done if We have only masked value with us.  And guest has chosen an identification type other than
     * no id.
     * @param agreement the agreement for which we need to get the unmasked value of the identification number.
     * @param agreementNumber the agreement number that we need to lookup the id number for.
     */
    public void populateUnMaskedIdentificationNumberIfRequired(final Agreement agreement, final String agreementNumber) {
        final Guest guest = agreement.getGuest();
        if (guest.isNoIdentificationProvided() || guest.isUnMaskedIdentificationAvailable()) {
            logger.debug("Either guest has provided no identification yet or we already have the un-masked value.");
            return;
        }
        kioskService.populateUnMaskedIdentificationNumbers(agreement, agreementNumber);
    }
}
