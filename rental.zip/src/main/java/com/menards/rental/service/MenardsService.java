/*
 * MenardsService.java
 */
package com.menards.rental.service;

import com.menards.rental.service.external.StoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.menards.rental.domain.Store;

/**
 * The class that is used to talk to the menards services.
 * @author deep
 */
@Service
public class MenardsService {

    /** The store service reference. */
    @Autowired
    private StoreService storeService;

	/** The context service. */
	@Autowired
	private ContextService contextService;

    /**
	 * The Class StoreNumber.
     * @author deep
	 */
	public class StoreNumber implements ContextService.StoreNumberable {

		/** The store number. */
		private Integer storeNumber;

		/**
		 * Gets the store number.
		 *
		 * @return the store number
		 */
		public Integer getStoreNumber() {
			return storeNumber;
		}

        /**
         * {@inheritDoc}
         */
		public void setStoreNumber(final Integer storeNumber) {
			this.storeNumber = storeNumber;
		}
	}


	/**
	 * Gets the current store.
	 *
	 * @return the current store
	 */
	public Store getCurrentStore() {
		return contextService.getUser().getStore();
	}

	/**
	 * Gets the store by store number.
	 *
	 * @param storeNumber the store number
	 * @return the store by store number
	 */
	public Store getStoreByStoreNumber(final Integer storeNumber) {
        return storeService.getStoreByStoreNumber(storeNumber);
	}

	/**
	 * Sets the context service.
	 *
	 * @param contextService the new context service
	 */
	public void setContextService(final ContextService contextService) {
		this.contextService = contextService;
	}

    /**
     * The setter for the store service.
     * @param storeService the value.
     */
    public void setStoreService(final StoreService storeService) {
        this.storeService = storeService;
    }
}
