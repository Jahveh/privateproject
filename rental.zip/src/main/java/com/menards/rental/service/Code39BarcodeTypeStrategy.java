/**
 * Code39BarcodeTypeStrategy.java
 */
package com.menards.rental.service;

import com.menards.rental.barcode.BarcodeDetails;
import org.krysalis.barcode4j.impl.AbstractBarcodeBean;
import org.krysalis.barcode4j.impl.code39.Code39Bean;
import org.springframework.stereotype.Component;

/**
 * The code 39 barcode type strategy.
 *
 * @author deep
 */
@Component(value = "code39BarcodeTypeStrategy")
public class Code39BarcodeTypeStrategy implements BarcodeTypeStrategy {

    /**
     * {@inheritDoc}
     */
    public AbstractBarcodeBean getBean(final BarcodeDetails barcodeDetails) {

        final Code39Bean bean = new Code39Bean();
		// Configure the barcode generator

		bean.setModuleWidth(barcodeDetails.getNarrowBarWidth());
		bean.setWideFactor(barcodeDetails.getWidthFactor());
		bean.doQuietZone(false);
		bean.setBarHeight(barcodeDetails.getBarHeight());
        return bean;
    }
}
