/*
 * AgreementService.java
 */
package com.menards.rental.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.menards.rental.builder.AgreementNumberBuilder;
import com.menards.rental.builder.StoreAndAgreementNumberBuilder;
import com.menards.rental.dao.ArchivedAgreementDataDao;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementCollection;
import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.AgreementItemStatus;
import com.menards.rental.domain.AgreementLog;
import com.menards.rental.domain.AgreementStatus;
import com.menards.rental.domain.ArchivedAgreement;
import com.menards.rental.domain.ExpressionEvaluator;
import com.menards.rental.domain.GuestArchiveInfo;
import com.menards.rental.domain.Item;
import com.menards.rental.domain.ItemStatus;
import com.menards.rental.domain.KioskProductDetail;
import com.menards.rental.domain.StoreUserInfo;
import com.menards.rental.dto.QuestionAnswerDto;
import com.menards.rental.dto.QuestionDto;
import com.menards.rental.repository.QuizRepository;
import com.menards.rental.service.archive.PDFArchiver;
import com.menards.rental.service.external.KioskService;
import com.menards.rental.service.external.TeamService;
import com.menards.rental.service.external.exception.KioskException;
import com.menards.rental.service.notification.AgreementUpdateNotifier;
import com.menards.rental.utils.Constants;

/**
 * The service that handles various phases in agreement lifecycle.
 *
 * @author deep
 */
@Service
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
public class AgreementService {

    /**
     * The log.
     */
    private static final Logger log = Logger.getLogger(AgreementService.class);

    /**
     * The context service.
     */
    @Autowired
    private ContextService contextService;

    @Autowired
    private QuizRepository quizRepository;
    
    /**
     * The agreement number builder.
     */
    @Autowired
    private AgreementNumberBuilder agreementNumberBuilder;

    /**
     * The notification service.
     */
    @Autowired
    private NotificationService notificationService;

    /**
     * The kiosk service.
     */
    @Autowired
    private KioskService kioskService;

    /**  The team service reference. */
    @Autowired
    private TeamService teamService;

    /** The guest service reference. */
    @Autowired
    private GuestService guestService;

    /** The agreement update notifier. */
    @Autowired
    private AgreementUpdateNotifier agreementUpdateNotifier;

    /** The pdf archiver. */
    @Autowired
    private PDFArchiver pdfArchiver;

    /** The archived agreement data dao. */
    @Autowired
    private ArchivedAgreementDataDao archivedAgreementDataDao;

    @Autowired
    private ItemService itemService;

    /**
     * Adds the agreement item to agreement.
     *
     * @param agreement     the agreement
     * @param agreementItem the agreement item
     * @param item          the item
     */
    public void addAgreementItemToAgreement(final Agreement agreement, final AgreementItem agreementItem,
                                            final Item item) {
        agreement.addToItems(agreementItem);
        agreementItem.setStatus(AgreementItemStatus.findCheckedOut());
        agreementItem.setItem(item);
        agreementItem.calculateEstimatedChargesAndDuration();
    }

    /**
     * Checkin marked items.
     *
     * @param agreement the agreement
     */
    public void checkinMarkedItems(final Agreement agreement) {

        agreement.checkinMarkedItems();

        final Agreement savedAgreement = Agreement.findAgreement(agreement.getId());
        savedAgreement.incrementNumber(agreementNumberBuilder);
        savedAgreement.merge();
    }

    /**
     * Creates the new agreement.
     *
     * @return the agreement
     */
    public Agreement createNewAgreement() {
        final Agreement agreement = new Agreement();

        contextService.applyContextToAgreement(agreement);

        agreement.generateNewNumber(agreementNumberBuilder);

        agreement.setTodaysDate();
        agreement.setAgreementStatus(AgreementStatus.findPending());
        return agreement;
    }

    /**
     * Creates the new agreement item.
     *
     * @param item      the item
     * @param agreement the agreement
     * @return the agreement item
     */
    public AgreementItem createNewAgreementItem(final Item item, final Agreement agreement) {
        final KioskProductDetail kioskProductDetail = kioskService.getKioskProductDetail(item.getProduct());

        if ((kioskProductDetail == null) || (!kioskProductDetail.isBaseSKUSetup())) {
            return null;
        }

        final AgreementItem agreementItem = new AgreementItem(item, agreement);
        agreementItem.copyChargeInfo();
        agreementItem.copyPriceFrom(kioskProductDetail);
        return agreementItem;
    }

    /**
     * Makes the agreement active.  When we get a paid notification from the kios server then we make the agreement
     * active.
     *
     * @param agreement       the agreement that is to be made active.
     * @param transactionDate the date on which it was made active.
     */
    public void makeAgreementActive(final Agreement agreement, final Calendar transactionDate) {
        agreement.setAgreementStatus(AgreementStatus.findActive());
        agreement.updateAgreementItemStatus(AgreementItemStatus.findCheckedOutAndPaidInitial());
        agreement.updateItemsStatus(ItemStatus.findRented());
        agreement.updateCheckoutDate(transactionDate);
        agreement.merge();
    }

    /**
     * When we receive a message from kios service that agreement is paid when the agreement is in Active state
     * we have to mark it completed if all the items have been returned.
     *
     * @param agreement       the areement that is to be completed.
     * @param transactionDate the date on which this happened.
     */
    public void makeAgreementCompleteIfPossible(final Agreement agreement, final Calendar transactionDate) {
        agreement.updateAgreementItemForReturnedItems(AgreementItemStatus.findReturnedAndPaidComplete());
        agreement.updateStatusToCompletedIfAllItemsReturned(AgreementStatus.findCompleted());
        agreement.merge();
    }

    /**
     * Removes the item from agreement.
     *
     * @param agreement    the agreement
     * @param serialNumber the serial number
     * @return the agreement item
     */
    public AgreementItem removeItemFromAgreement(final Agreement agreement, final Long serialNumber) {
        final AgreementItem removedAgreementItem = agreement.removeItemBySerialNumber(serialNumber);
        if ((null == removedAgreementItem) || removedAgreementItem.isTransient()) {
            return null;
        }
        agreement.addToRemovedItemList(removedAgreementItem);
        return removedAgreementItem;
    }

    /**
     * Save or update agreement.
     *
     * @param agreement the agreement
     */
    public void saveOrUpdateAgreement(final Agreement agreement) {
        /*
           * Finding the agreement from the db in case we are updating the
           * agreement
           */
        prepareForSave(agreement);
        if (null == agreement.getId()) {
            agreement.persist();
            agreement.persistQuestionAnswers();
            return;
        }

        /**
         * The items could have been removed from the persisted agreement we
         * need to update their status to Available
         */
        agreement.updateRemovedItemsStatus();
        agreement.merge();
        agreement.persistQuestionAnswers();
        
    }
    
    public void persistQuestionAnswers(Agreement agreement) {
    	List<QuestionAnswerDto> questionAnswerDtoList = new ArrayList<QuestionAnswerDto>();
    	Long agreementId = agreement.getId();
    	for (AgreementItem agreementItem : agreement.getItems()) {
    		for (QuestionDto questionDto : agreementItem.getCheckOutQuestionList()) {
    			QuestionAnswerDto questionAnswerDto = new QuestionAnswerDto();
    			questionAnswerDto.setRentalAgreementId(agreementId.intValue());
    			questionAnswerDto.setQuestionId(questionDto.getQuestionId());
    			questionAnswerDto.setQuestionTypeId(2);
    			questionAnswerDto.setItemSerialNumber(questionDto.getItemSerialNumber());
    			questionAnswerDto.setAnswerText(questionDto.getAnswer());
    			questionAnswerDtoList.add(questionAnswerDto);
    		}
    	}
    	quizRepository.persistCheckoutQuestionAnswer(questionAnswerDtoList);
    }

    /**
     * Will send the rental override mail if required.
     *
     * @param agreement the agreement for which the mail has to be sent.
     */
    public void sendRentalOverrideMailsIfAny(final Agreement agreement) {
        for (AgreementItem agreementItem : agreement.getItems()) {
            if (agreementItem.isReservationOverridden()) {
                notificationService.sendRentalOverrideNotificationFor(agreementItem);
            }
        }
    }

	/**
  	 * Makes the items available and cancels the agreement if the threshold of 2 hours has passed.
     * @return List of areements that were cancelled.  This is needed so that layers above can do some processing with
     * them if required.
     */
    public List<Agreement> makeItemsAvailableIfThresholdHasPassed() {
        final Calendar thresholdCheckoutDate = Calendar.getInstance();
        thresholdCheckoutDate.add(Calendar.HOUR, Constants.Cleanup.DEFAULT_AGREEMENT_CLEANUP_HOURS_THRESHOLD);
        final List<Agreement> oldAgreements =
                Agreement.findAllPendingAgreementsOlderThan(thresholdCheckoutDate);

        new AgreementCollection(oldAgreements).cancel();
        log.debug("Number of agreements canceled: " + oldAgreements.size()
                + " Because they were in not paid for and threshold has crossed!");
        return oldAgreements;
    }

    /**
	 * Sets the agreement number builder.
	 *
	 * @param agreementNumberBuilder the new agreement number builder
	 */
	public void setAgreementNumberBuilder(
	        final StoreAndAgreementNumberBuilder agreementNumberBuilder) {
		this.agreementNumberBuilder = agreementNumberBuilder;
	}

    /**
     * Sets the context service.
     *
     * @param contextService the new context service
     */
    public void setContextService(final ContextService contextService) {
        this.contextService = contextService;
    }

    /**
     * The kioskService setter.
     *
     * @param kioskService the value.
     */
    public void setKioskService(final KioskService kioskService) {
        this.kioskService = kioskService;
    }

    /**
     * The setter for the notification service.
     *
     * @param notificationService the value.
     */
    public void setNotificationService(final NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    /**
     * Populates the tm name from the tm number in the agreement.
     * @param agreement in which we need to populate the team members name.
     */
    public void populateTMNameFromTMNumber(final Agreement agreement) {
        final StoreUserInfo storeUserInfo = teamService
                .getStoreUserByIdForCurrentStore(agreement.getCreatedByTeamMemberNumber());
        agreement.setStoreUser(storeUserInfo);
    }

    /**
     * Sends the agreement to the kiosk server.  Before sending the agreement we need to unmask the guest identification
     * and their after send the agreement to kiosk server.
     * @param agreement the agreement that needs to be sent to the kiosk server.
     * @param agreementNumber the previous agreement number for which we should lookup guest information.
     * @return boolean true if the send was successful, false otherwise.
     */
    public boolean sendAgreementToKiosk(final Agreement agreement, final String agreementNumber) {
        try {
            guestService.populateUnMaskedIdentificationNumberIfRequired(agreement, agreementNumber);
            agreementUpdateNotifier.notifyUpdate(agreement);
            kioskService.sendAgreementToKiosk(agreement);
            kioskService.cancelPreviousAgreementIfRequired(agreement, agreementNumber);
            return true;
        } catch (final Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }

    /**
     * Cancles the agreement at the kiosk end.  This method also notifies the agreements listeners that the agreement
     * is cancelled.
     * @param agreement the agreement to cancel.
     * @return boolean true if the cancel was successful, false otherwise.
     */
    public boolean cancelAgreement(final Agreement agreement) {
        try {
            kioskService.cancelAgreement(agreement);
            return true;
        } catch (final KioskException e) {
            log.error(e.getMessage(), e);
            return false;
        }
    }

    /**
     * The method that is responsible to void the agreement.
     * @param agreement the agreement to void.
     */
    public void voidAgreement(final Agreement agreement) {
        agreement.incrementNumber(agreementNumberBuilder);
        agreement.voidAgreement();
    }

    /**
     * Voids the agreement with the kiosk service.  This method also notifies the listeners that the agreement has been
     * updated.
     *
     * @param agreement the agreement that is to be voided.
     * @param agreementNumber the old agreement number, will be used to lookup guest information.
     * @return boolean true if the agreement was voided, false otherwise.
     */
    public boolean sendVoidedAgreementToKiosk(final Agreement agreement, final String agreementNumber) {
        try {
            kioskService.voidAgreement(agreementNumber);
            if(!sendAgreementToKiosk(agreement, agreementNumber)) {
                return false;
            }
            return true;
        } catch (final KioskException e) {
            log.error(e.getMessage(), e);
            return false;
        }
    }

    /**
     * Updates the archived agreement pdf with the guest information.
     * @param archivedAgreement the archived agreement that is to be updated.
     * @param guestArchiveInfo the guest information using which the agreement is to be updated.
     */
    public void updateArchive(final ArchivedAgreement archivedAgreement,
                              final GuestArchiveInfo guestArchiveInfo) {
        byte[] archive = pdfArchiver.updateArchive(archivedAgreement, guestArchiveInfo);
        archivedAgreementDataDao.updateArchiveData(archivedAgreement, archive);
        archive = null;
    }

    /**
     * Merges the agreement with the one saved in the db.
     * @param agreement the saved agreement.
     */
    public void merge(final Agreement agreement) {
        agreement.merge();
    }

    /**
     * Removes the archive information for the auto cancelled agreements.
     * @param cancelledAgreements the agreement that have been automatically cancelled.
     */
    public void removeArchiveFor(final List<Agreement> cancelledAgreements) {
        if (cancelledAgreements.isEmpty()) {
            log.debug("No agreements were auto cancelled.  Nothing to do.");
            return;
        }
        final List<ArchivedAgreement> archivedAgreements = ArchivedAgreement
                .findAllArchivedAgreementsByAgreementsIn(cancelledAgreements);
        for (ArchivedAgreement archivedAgreement : archivedAgreements) {
            archivedAgreement.remove();
            archivedAgreementDataDao.removeArchiveData(archivedAgreement);
        }
    }

    /**
     * Syncs the inventory for the checkedin items.
     * @param agreement the agreement that is current checkedin.
     */
    public void syncInventoryForCheckedInItems(final Agreement agreement) {
        agreement.getCurrentlyCheckedInItems().doInLoop(new ExpressionEvaluator<AgreementItem>() {
            public void evaluate(final AgreementItem entity) {
                itemService.syncItemInventory(entity.getItem().getProduct());
            }
        });
    }

    /**
     * The setter for the team service.
     * @param teamService the value to set.
     */
    public void setTeamService(final TeamService teamService) {
        this.teamService = teamService;
    }

    /**
     * The setter for the guest service.
     * @param guestService the value to set.
     */
    public void setGuestService(final GuestService guestService) {
        this.guestService = guestService;
    }

    /**
     * The setter for the agreement update noifier.
     * @param agreementUpdateNotifier the value to set.
     */
    public void setAgreementUpdateNotifier(final AgreementUpdateNotifier agreementUpdateNotifier) {
        this.agreementUpdateNotifier = agreementUpdateNotifier;
    }

    /**
     * The setter for the item service.
     * @param itemService the value to set.
     */
    public void setItemService(final ItemService itemService) {
        this.itemService = itemService;
    }

    /**
     * Prepare for save.
     *
     * @param agreement the agreement
     */
    private void prepareForSave(final Agreement agreement) {
        if (!agreement.isEveryItemAvailableRightNow()) {
            throw new IllegalStateException();
        }
        contextService.applyContextToAgreement(agreement);
        agreement.incrementNumber(agreementNumberBuilder);
        agreement.updateAgreementItemStatus(AgreementItemStatus.findCheckedOut());
        agreement.updateItemsStatus(ItemStatus.findOnHold());
        agreement.updateStatusIfRequired(AgreementStatus.findPending());
        agreement.updateOverrides();
    }
    
    /**
     * Persist the agreement comments that were updated
     * @param agreement the agreement to update.
     */
    public void persistComments(final Agreement agreement) {
    	Agreement attachedAgreement = Agreement.loadFull(agreement.getId());
    	attachedAgreement.setOverallComment(agreement.getOverallComment());
    	attachedAgreement.merge();
    }
    /**
     * recalculate the amount if the due by have been updated
     * @param dueBy the due by date to update
     * @param agreement the agreement to update.
     * @return the new Agreement
     */
	public Agreement reCalculateAmount(final String dueBy,final Agreement agreement) {
		Agreement attachedAgreement = Agreement.loadFull(agreement.getId());
	  	Calendar calendar = Calendar.getInstance();
    	calendar.setTime(new Date(dueBy));
		attachedAgreement.updateDueByDate(calendar);
		return attachedAgreement;
	}
	/**
	 * Persist the agreement due by that were updated
	 * @param dueBy the due by date to update
	 * @param agreement  the agreement to update.
	 * @return Agreement the new Agreement
	 */
	public Agreement mergeAgreement(final String dueBy,final Agreement agreement) {
		AgreementLog agreementLog=agreement.getAgreementLog();
        if(agreementLog==null){
       	 agreementLog= new AgreementLog();
       	 agreementLog.setAgreement(agreement);
       	 agreementLog.setPreDueBy(agreement.getUpcomingDueBy());
        }
        Agreement attachedAgreement = reCalculateAmount(dueBy,agreement);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date(dueBy));
        agreementLog.setCurDuyBy(calendar);
        agreementLog.setAgreement(attachedAgreement);
        attachedAgreement.setAgreementLog(agreementLog);
        attachedAgreement.merge();
        return attachedAgreement;
	}
    
}
