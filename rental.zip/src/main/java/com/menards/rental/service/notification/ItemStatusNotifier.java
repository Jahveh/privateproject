package com.menards.rental.service.notification;

import com.menards.rental.domain.Item;
import org.springframework.stereotype.Component;

import java.util.Calendar;

/**
 * Implementing a simple observer pattern here.  The Item Status Notifier is nothing but a component that will publish
 * notifications when item status is updated.  The interested parties could register with the notifier and they will
 * receive the notifications at appropreate times.
 *
 * @author deep
 */
@Component
public class ItemStatusNotifier extends BaseNotifier<ItemStatusListener, ItemStatusUpdatedEvent, Item> {

    /**
     * {@inheritDoc}
     */
    @Override
    protected ItemStatusUpdatedEvent getEvent(final Item item) {
        return new ItemStatusUpdatedEvent(item, Calendar.getInstance());
    }
}
