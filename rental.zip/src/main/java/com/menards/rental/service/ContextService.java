/*
 * ContextService.java
 */
package com.menards.rental.service;

import com.menards.rental.domain.Agreement;
import com.menards.rental.security.MenardsUser;

/**
 * Interface to the current context that the application is running in.
 * 
 * @author geoff
 */
public interface ContextService {

	/**
	 * The Interface StoreNumberable.
	 */
	public interface StoreNumberable {

		/**
		 * Sets the store number.
		 *
		 * @param storeNumber the new store number
		 */
		void setStoreNumber(Integer storeNumber);
	}

	/**
	 * Gets the store number.
	 *
	 * @return the store number
	 */
	Integer getStoreNumber();

	/**
	 * Gets the user.
	 *
	 * @return the user
	 */
	MenardsUser getUser();

	/**
	 * Applies the Store Number and Team Member information to the agreement.
	 *
	 * @param agreement The agreement that needs the context.
	 */
	void applyContextToAgreement(Agreement agreement);

	/**
	 * Apply the current Store Number to an item.
	 * 
	 * @param storeNumberable
	 *            An item that can have a store number set into it
	 */
	void applyStoreContext(StoreNumberable storeNumberable);

}
