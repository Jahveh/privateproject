/**
 * BarcodeTypeStrategy.java
 */
package com.menards.rental.service;

import com.menards.rental.barcode.BarcodeDetails;
import org.krysalis.barcode4j.impl.AbstractBarcodeBean;

/**
 * The barcode type strategy that will could have.  The implementing classes should return an instance of
 * AbstractBarcodeBean reference.
 *
 * @author deep
 */
public interface BarcodeTypeStrategy {
    /**
     * Returns a reference of abstract barcode bean based on the barcode details passed as argument.
     * @param barcodeDetails the details from which we need to generate the barcode bean.
     * @return the AbstractBarcodeBean reference for the given barcode details.
     */
    AbstractBarcodeBean getBean(final BarcodeDetails barcodeDetails);
}
