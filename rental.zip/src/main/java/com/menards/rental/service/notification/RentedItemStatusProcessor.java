package com.menards.rental.service.notification;

import com.menards.rental.domain.Item;
import com.menards.rental.domain.ItemStatus;
import com.menards.rental.domain.OutOfStockAuditTrail;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * The class that handles the rented item status.
 *
 * @author deep
 */
@Component
public class RentedItemStatusProcessor implements ItemStatusUpdateProcessor {
    /** The logger reference. */
    private static final Logger logger = Logger.getLogger(RentedItemStatusProcessor.class);
    /**
     * {@inheritDoc}
     */
    public boolean canProcess(final ItemStatusUpdatedEvent event) {
        return event.isRented();
    }

    /**
     * {@inheritDoc}
     */
    public void process(final ItemStatusUpdatedEvent event) {
        final long availableItemCount = Item.countItemsByProductAndStoreNumberAndItemStatus(event.getProduct(),
                event.getStoreNumber(),
                ItemStatus.findAvailable());
        if (availableItemCount > 0) {
            logger.debug(
                    "One or more item is in available state in the store for the given product, hence nothing to do");
            return;
        }

        final OutOfStockAuditTrail existingOutOfStockAuditTrail = OutOfStockAuditTrail
                .findOutOfStockAuditTrailByProductAndStoreNumberAndEndTimeIsNull(event.getProduct(),
                        event.getStoreNumber());
        if (existingOutOfStockAuditTrail != null) {
            logger.debug("We already have the product in the OutOfStockAuditTrail. No need to create another trail");
            return;
        }

        final OutOfStockAuditTrail outOfStockAuditTrail = new OutOfStockAuditTrail();
        outOfStockAuditTrail.setProduct(event.getProduct());
        outOfStockAuditTrail.setStoreNumber(event.getStoreNumber());
        outOfStockAuditTrail.setStartTime(event.getWhen());
        outOfStockAuditTrail.persist();
    }
}
