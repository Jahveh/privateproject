package com.menards.rental.service;

import com.menards.rental.domain.Product;
import com.menards.rental.domain.Report;
import com.menards.rental.service.external.StoreService;
import com.menards.rental.utils.Constants;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Generate the automated reports of the system.  Right now there are two automated reports
 * Vendor notification report and the out of stock report.
 *
 * @author deep
 */
@Service
public class AutomatedReportService {

    /** The log4j logger. */
    private static final Logger logger = Logger.getLogger(AutomatedReportService.class);

    /** The report service. */
    @Autowired
    private ReportService reportService;

    /** The store service. */
    @Autowired
    private StoreService storeService;


    /**
     * Should generate the vendor notification report for all the products that require vendor notification for the
     * given time frame.
     * @param reportStartDate the report start date.
     * @param reportEndDate the report end date.
     */
    public void generateAndPublishVendorNotificationReport(final Calendar reportStartDate,
                                                           final Calendar reportEndDate) {
        final Report vendorNotificationReport = getReport(Report.Type.VENDOR_NOTIFICATION_REPORT, null);

        // Set the start and end date in the model
        final Map<String, Object> modelMap = getModelWithStartAndEndDates(reportStartDate, reportEndDate);

        for (Product product : Product.findAllProductsByVendorEmailNotNullOrEmpty()) {
            modelMap.put(Constants.Report.PRODUCT_KEY, product);
            generateAndPublishReport(vendorNotificationReport, modelMap);
        }
    }

    /**
     * Generate the not returned rental item report for the help desk.
     * This report is generated nightly.
     * 
     */
    public void generateAndPublishNotReturnedReport(){
    	reportService.generateAndPublishReport(getReport(Report.Type.NOT_RETURNED_RENTAL_REPORT, null), 
        		new HashMap<String,Object>());
    }

    /**
     * Generates and publishes daily reports for all stores.
     */
    public void generateAndPublishDailyReportsForAllStores() {
        final Set<Integer> storeNumbers = storeService.getAllStoreNumbers();
        for (Integer storeNumber : storeNumbers) {
            generateAndPublishReportForStore(storeNumber, Report.Type.OVERDUE_RENTAL_REPORT,
                    new HashMap<String, Object>());
            generateAndPublishReportForStore(storeNumber, Report.Type.NOTICED_OVERDUE_RENTAL_REPORT,
            		new HashMap<String, Object>());
            generateAndPublishReportForStore(storeNumber, Report.Type.VOID_RENTAL_REPORT,
                    new HashMap<String, Object>());
            generateAndPublishReportForStore(storeNumber, Report.Type.NOT_RECALLED_AT_REGISTER_REPORT,
                    new HashMap<String, Object>());
        }
    }

    /**
     * The setter for the report service.
     * @param reportService the value.
     */
    public void setReportService(final ReportService reportService) {
        this.reportService = reportService;
    }

    /**
     * The setter for the store service.
     * @param storeService the value.
     */
    public void setStoreService(final StoreService storeService) {
        this.storeService = storeService;
    }

    /**
     * Returns the model object with start and end dates populated in the map.
     * @param reportStartDate the start date of the report.
     * @param reportEndDate the end date of the report.
     * @return the Map model object with start and end dates.
     */
    private Map<String, Object> getModelWithStartAndEndDates(
            final Calendar reportStartDate, final Calendar reportEndDate) {
        final Map<String, Object> modelMap = new HashMap<String, Object>();
        modelMap.put(Constants.Report.REPORT_START_DATE_KEY, reportStartDate);
        modelMap.put(Constants.Report.REPORT_END_DATE_KEY, reportEndDate);
        return modelMap;
    }

    /**
     * Returns the report object constructed for the given report type.
     * @param type the type of report we want to generate.
     * @param storeNumber the store number for the report.
     * @return the Report object with the necessary information.
     */
    private Report getReport(final Report.Type type, final Integer storeNumber) {
        final Report report = new Report();
        report.setReportMedium(Constants.ReportMedium.EMAIL);
        report.setType(type);
        report.setStoreNumber(storeNumber);
        return report;
    }

    /**
     * Generates and publishes the report for a given store.
     * @param storeNumber The store number for which the report is to be published.
     * @param reportType the report that is to be published.
     * @param model The report model to use.
     */
    private void generateAndPublishReportForStore(final Integer storeNumber, final Report.Type reportType,
                                                  final Map<String, Object> model) {
        generateAndPublishReport(getReport(reportType, storeNumber), model);
    }

    /**
     * Generates and publishes the given report with the given model.
     * @param report the report that is to be published.
     * @param model the model that is to be used to publish the report.
     */
    private void generateAndPublishReport(final Report report, final Map<String, Object> model) {
        try {
            reportService.generateAndPublishReport(report, model);
        } catch (final Exception e) {
            logger.error(e.getMessage(),  e);
        }
    }
}
