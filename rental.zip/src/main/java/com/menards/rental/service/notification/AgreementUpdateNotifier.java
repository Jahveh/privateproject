/**
 * AgreementUpdateNotifier.java
 */
package com.menards.rental.service.notification;

import com.menards.rental.domain.Agreement;
import org.springframework.stereotype.Component;

/**
 * The class that is responsible for notifing the listeners that the agreement has been updated.  This class implements
 * an observer pattern to notify all the interested parties that the agreement was updated.
 *
 * @author deep
 */
@Component
public class AgreementUpdateNotifier extends BaseNotifier<AgreementUpdateListener, AgreementUpdateEvent, Agreement> {

    /**
     * {@inheritDoc}
     */
    @Override
    protected AgreementUpdateEvent getEvent(final Agreement agreement) {
        return new AgreementUpdateEvent(agreement);
    }
}
