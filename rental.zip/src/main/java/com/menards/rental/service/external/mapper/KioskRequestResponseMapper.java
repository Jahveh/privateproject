package com.menards.rental.service.external.mapper;

import com.menards.kiosk.comm.KioskRequest;
import com.menards.rental.domain.*;
import com.menards.rental.service.external.KioskCommunicationException;
import com.menards.rental.service.external.KioskGateway;
import com.menards.rental.utils.Constants;
import org.apache.commons.beanutils.DynaBean;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * The mapper that will map from our objects to objects that kiosk understands.
 *
 * @author deep
 */
@Component
public class KioskRequestResponseMapper {

    /**
     * The kiosk gateway reference.
     */
    @Autowired
    private KioskGateway kioskGateway;

    /** The logger. */
    private static final Logger logger = Logger.getLogger(KioskRequestResponseMapper.class);

    /** Formatter for policy expiration date **/
	private static SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_FORMAT);

    /**
     * The method to create the cancel agreement request.
     * @param agreement the agreement that is being canceled.
     * @return The cancel agreement request.
     */
    public DynaBean mapToCancelAgreementRequeste(final Agreement agreement) {
        return mapToCancelAgreementRequesteWithAgreementNumber(agreement, agreement.getAgreementNumber());
    }

    /**
     * Maps the agreement to cancel agreement request with the given agreement number.
     * @param agreement the agreement which is supposed to be cancelled.
     * @param agreementNumber the agreement number to be used for cancellation.
     * @return The cancel agreement request.
     */
    public DynaBean mapToCancelAgreementRequesteWithAgreementNumber(final Agreement agreement, final String agreementNumber) {
        final DynaBean request = kioskGateway.createRequestBeanFor(KioskRequest.VOID_TRANSACTION,
                agreement.getStoreNumber());
        request.set("clientId", Constants.Kiosk.CLIENT_ID);
        request.set("documentNumber", agreement.getEightDigitAgreementNumberWithoutHyphenFor(agreementNumber).toString());
        return request;
    }

    /**
     * The method to create the guest list request.
     * @param phoneNumber the phone number against which we have to search the guests.
     * @return The request holding the guest phone number.
     */
    public DynaBean mapToGuestListByPhoneNumberRequest(final String phoneNumber) {
        final DynaBean request = kioskGateway.createRequestBean(KioskRequest.GUEST_INFO);
        request.set("clientId", Constants.Kiosk.CLIENT_ID); // Include on ALL Kiosk
        request.set("phoneNumber", phoneNumber.replaceAll("-", ""));
        return request;
    }

    /**
     * Should map the response from Kiosk server to the list of guests.
     * @param results the response from kiosk server holding guest information.
     * @param phoneNumber the phone number that we used to search these guests.
     * @return List of guest that have the matching phone number.
     */
    public List<Guest> mapToGuestListFromResults(final List<DynaBean> results, final String phoneNumber) {
        final ArrayList<Guest> guests = new ArrayList<Guest>();
        for (DynaBean result : results) {
            guests.add(createGuest(result, phoneNumber));
        }
        return guests;
    }

    /**
     * Returns the mapped KioskSKUDetail object.
     * @param results the list of results returned from the kiosk server.
     * @return The kiosk sku details object.
     */
    public KioskSKUDetail mapToKioskSKUDetailFromResults(final List<DynaBean> results) {
        final KioskSKUDetail kioskSKUDetail = new KioskSKUDetail();
        DynaBean result = results.get(0);

        kioskSKUDetail.setNumberOfItems(Integer.parseInt((String) result.get("quantityOnHand")));

        kioskSKUDetail.setChargeAmount(new BigDecimal((String) result.get("retailPrice")));
        final String promoStartDateString = (String) result.get("promoStart");
        final String promoEndDateString = (String) result.get("promoEnd");

        if ((promoEndDateString != null)
                && (promoStartDateString != null)
                && new DateRange(promoStartDateString, promoEndDateString).isDateInRange(Calendar.getInstance())) {
            kioskSKUDetail.setChargeAmount(new BigDecimal((String) result.get("promoPrice")));
        }
        return kioskSKUDetail;
    }

    /**
     * The method to convert the agreementItem to the RentalDetailRequest containing only the base charge.
     * @param agreementItem The agreementItem to send to the kiosk server with only base charge.
     * @return The kiosk request.
     */
    public DynaBean mapToBaseRentalDetailRequest(final AgreementItem agreementItem) {
        String quantity = "1";
        if(agreementItem.getAgreement().isVoided()) {
            quantity = "-1";
        }
        return mapToRentalDetailRequest(agreementItem,
                agreementItem.getItem().getBaseSkuValue().toString(), quantity,
                agreementItem.getChargeInfo().getBaseChargeAmount(), agreementItem.getDescription(),
                agreementItem.getOverallComment(), "");
    }

    /**
     * The method to convert the agreementItem to the RentalDetailRequest to send the surcharge price amount.
     * @param agreementItem The agreementItem to send to the kiosk server with the surcharge price.
     * @return The kiosk request.
     */
    public DynaBean mapToSurchargeRentalDetailRequest(final AgreementItem agreementItem) {
        String quantity = "1";
        if(agreementItem.getAgreement().isVoided()) {
            quantity = "-1";
        }
        return mapToRentalDetailRequest(agreementItem,
                agreementItem.getItem().getSurchargeSkuValue().toString(), quantity,
                agreementItem.getChargeInfo().getSurchargePriceAmount(), agreementItem.getDescription(),
                agreementItem.getItem().getProduct().getSkuInfo().getSurchargeSKU().getDescription(), "");
    }

    /**
     * The method to convert the agreementItem to the RentalDetailRequest to send the additional price amount.
     * @param agreementItem The agreementItem to send to the kiosk server with the additional price.
     * @return The kiosk request.
     */
    public DynaBean mapToAdditionalRentalDetailRequest(final AgreementItem agreementItem) {
        return mapToRentalDetailRequest(agreementItem,
                agreementItem.getItem().getIncrementalSkuValue().toString(),
                String.valueOf(agreementItem.getIncrementalTimeUnitsByStatus()),
                agreementItem.getIncrementalPriceAmount(),
                agreementItem.getDescription(), "Additional Hours", "");
    }

    /**
     * The method to convert the agreementItem to the RentalDetailRequest list for other additional charges.
     * @param agreementItem The agreementItem to send to the kiosk server with the other additional charges.
     * @return The kiosk request list.
     */
    public List<DynaBean> mapToOtherAdditionalChargesRentalDetailRequest(final AgreementItem agreementItem) {
        final ArrayList<DynaBean> requests = new ArrayList<DynaBean>();

        for(ChecklistAnswer answer : agreementItem.getAnswers()) {
            if(answer.isYesAnswer()) {
                requests.add(mapToRentalDetailRequest(agreementItem,
                        answer.getSku().toString(),
                        "1",
                        answer.getChargeAmount(),
                        agreementItem.getDescription(),
                        "Check In Charge",
                        answer.getQuestionText()));
            }
        }
        return requests;
    }

    /**
     * The method to convert the agreement item to the RentalDetailRequest to send the damage waiver price amount.
     * @param agreementItem The agreement item whose damage waiver is to be sent.
     * @return The kiosk request.
     * @throws IllegalStateException
     */
    public DynaBean mapToDamageWaiverRentalDetailRequest(final AgreementItem agreementItem) {
        final MiscellaneousSKU damageWaiverSKU = MiscellaneousSKU.findDamageWaiverSKU();
        if(damageWaiverSKU == null) {
//            logger.error("Please setup damage waiver sku for sending the damagewaiver information to kiosk");
            logger.warn("Please setup damage waiver sku for sending the damagewaiver information to kiosk");
            throw new KioskCommunicationException(new IllegalStateException("No DamageWaiver sku setup in the DB"));
        }

        String quantity = "1";
        String multiplicationFactor = "1.0";
        if(agreementItem.isReturned()) {
            quantity = "-1";
            multiplicationFactor = "-1.0";
        }
        return mapToRentalDetailRequest(agreementItem, damageWaiverSKU.getValue().toString(), quantity,
                agreementItem.getDamageWaiverAmountByStatus().multiply(new BigDecimal(multiplicationFactor)),
                agreementItem.getDescription(), "Damage Waiver", "");
    }

    /**
     * The mapper to convert the agreement into rental header request.
     *
     * @param agreement The agreement reference to send to the kiosk server
     * @return DynaBean that reqpresents the kiosk request.
     */
    public DynaBean mapToRentalHeaderRequest(final Agreement agreement) {
        final DynaBean request = kioskGateway.createRequestBean(KioskRequest.RENTAL_HEADER_CREATE);
        request.set("clientId", Constants.Kiosk.CLIENT_ID); // Include on ALL Kiosk
        // messages
        request.set("docNumber", agreement.getEightDigitAgreementNumberWithoutHyphen().toString());
        final Guest guest = agreement.getGuest();
        request.set("lastName", guest.getLastName());
        request.set("firstName", guest.getFirstName());
        request.set("companyName", guest.getCompanyName());
        request.set("address", guest.getAddress().getLine());
        request.set("city", guest.getAddress().getCity());
        request.set("state", guest.getAddress().getState());
        request.set("zip", guest.getAddress().getZipCode());
        request.set("phone", guest.getPhoneNumber().replaceAll("-", ""));
        request.set("email", guest.getEmail());

        if (!guest.isNoIdentificationProvided()) {
            request.set("dlNumber", guest.getIdentification().getUnMaskedNumber());
        }

        if (agreement.isVehicleRented()) {
            final VehicleRentalDetail vehicleRentalDetail = agreement.getVehicleRentalDetail();
            if (vehicleRentalDetail.isAdditionalDriverAdded()) {
                final AdditionalDriver additionalDriver = vehicleRentalDetail.getAdditionalDriver();
                request.set("driverTwoDLNum", additionalDriver.getIdentification().getUnMaskedNumber());
            }
        }

        request.set("teamMember", agreement.getCreatedByTeamMemberNumber().toString());
        final DecimalFormat decFormat = new DecimalFormat("####.##");

        String rentalInOutValue = "RO";
        /**
         * The sub total value should be the sub total value in case if the rental agreement is been checked-out.
         */
        String subTotal = decFormat.format(agreement.getSubTotal());
        if(agreement.isVoided()) {
            rentalInOutValue = "RI";
        } else if (!agreement.isPending()) {
            /**
             * The sub total value should be the total additional charges if the rental agreement is being checked-in.
             */
            subTotal = decFormat.format(agreement.getTotalAdditionalChargeAmount());

            // Populating the rental in or out value.  It could be RO for rental out and RI for rental in.
            // If the agreement is in pending state then it will always be RO else if agreement is in Active state
            // then it will be RI.
            rentalInOutValue = "RI";
        }

        request.set("subTotal", subTotal);
        request.set("rentalInOut", rentalInOutValue);
        return request;
    }

    /**
     * Creates the request for the sku extended information.
     * @param sku The sku whose information we need.
     * @return the request.
     */
    public DynaBean mapToSKUExtendedInfoRequest(final Long sku) {
        final DynaBean request = kioskGateway.createRequestBean(KioskRequest.SKU_INFO_EXTENDED);
        request.set("clientId", Constants.Kiosk.CLIENT_ID); // Include on ALL Kiosk
        request.set("sku", sku.toString());
        return request;
    }

    /**
     * Maps to SyncInventroy request.
     * @param product the product for which we will sync inventory.
     * @param totalRentableItems total number of rentable items.
     * @return The SyncInventory request.
     */
    public DynaBean mapToSyncInventoryRequest(final Product product, final long totalRentableItems) {
        final DynaBean request = kioskGateway.createRequestBean(KioskRequest.INVENTORY_UPDATE);
        request.set("clientId", Constants.Kiosk.CLIENT_ID); // Include on ALL Kiosk
        request.set("sku", String.valueOf(product.getBaseSkuValue()));
        request.set("newQuantity", String.valueOf(totalRentableItems));
        request.set("employeeName", "RENT"); // for rental form, value will always be "RENT"
        request.set("message", "RENTAL");
        return request;
    }

    /**
     * The method to create the void agreement request.
     * @param agreementNumber the agreementnumber that is voided.
     * @return the void agreement request object.
     */
    public DynaBean mapToVoidAgreementRequest(final String agreementNumber) {
        final DynaBean request = kioskGateway.createRequestBean(KioskRequest.RENTAL_AGREEMENT_VOID);
        request.set("clientId", Constants.Kiosk.CLIENT_ID);
        request.set("raNumber", (agreementNumber.replaceAll("-", "")).substring(4));
        return request;
    }

    /**
     * Maps the agreement to get unmasked identification request.
     * @param agreementNumber the agreement that is to be mapped.
     * @return the DynaBean that represents the request.
     */
    public DynaBean mapToUnMaskIdentificationRequest(final String agreementNumber) {
        final DynaBean request = kioskGateway.createRequestBean(KioskRequest.RENTAL_DRIVER_REQUEST);
        request.set("clientId", Constants.Kiosk.CLIENT_ID);
        request.set("docNumber", (agreementNumber.replaceAll("-", "")).substring(4));
        return request;
    }

    /**
     * Returns the unmasked identification number from the response.
     * @param results the results that we received from the kiosk server.
     * @param agreement the agreement where we have to populate the un-masked identification numbers.
     */
    public void mapToUnMaskedIdentificationNumbers(final List<DynaBean> results, final Agreement agreement) {
        final DynaBean result = results.get(0);
        agreement.getGuest().setUnMaskedIdentificationNumber((String) result.get("driverOneDL"));
        if (agreement.isVehicleRented() && agreement.getVehicleRentalDetail().isAdditionalDriverAdded()) {
            agreement.getVehicleRentalDetail().getAdditionalDriver().getIdentification()
                    .setUnMaskedNumber((String) result.get("driverTwoDL"));
        }
    }

    /**
     * Maps the agreement and the agreement item into a list of dyna beans that holds requeset for various comments.
     * @param agreement the agreement for which the request is to be sent.
     * @param agreementItem the agreement item which is to be sent.
     * @return the list of DynaBeans that represent the list of requests to sent to kiosk server.
     */
    public List<DynaBean> mapToRentalDetailCommentRequests(
            final Agreement agreement, final AgreementItem agreementItem) {
        final ArrayList<DynaBean> requests = new ArrayList<DynaBean>();
        if (!agreement.isVehicleRented()) {
            logger.info("Vehicle is not rented in #" + agreement.getAgreementNumber() + ".  No need to send comments");
            return requests;
        }
        final VehicleRentalDetail vehicleRentalDetail = agreement.getVehicleRentalDetail();
        final Insurance insurance = vehicleRentalDetail.getInsurance();
        requests.add(mapToRentalDetaliCommentRequest(agreement, agreementItem,
                "Ins Co: " + insurance.getCompanyName()));
        requests.add(mapToRentalDetaliCommentRequest(agreement, agreementItem,
                "Agent: " + insurance.getAgent().getName()));
        requests.add(mapToRentalDetaliCommentRequest(agreement, agreementItem,
                "Insurance Policy No: " + insurance.getPolicyNumber()));
        String formattedDate = sdf.format(insurance.getPolicyExpirationDate());
        requests.add(mapToRentalDetaliCommentRequest(agreement, agreementItem,
                "Ins. Exp. Date: " + formattedDate));
        requests.add(mapToRentalDetaliCommentRequest(agreement, agreementItem,
                "Agent Ph: " + insurance.getAgent().getPhoneNumber().replaceAll("-", "")));
        requests.add(mapToRentalDetaliCommentRequest(agreement, agreementItem,
                "Agent Add: " + insurance.getAgent().getAddress().getLine()));
        requests.add(mapToRentalDetaliCommentRequest(agreement, agreementItem,
                "Agent C,S,Z: " + insurance.getAgent().getAddress().getCity() + ", "
                        + insurance.getAgent().getAddress().getState() + ", "
                        + insurance.getAgent().getAddress().getZipCode()));

        if (vehicleRentalDetail.isAdditionalDriverAdded()) {
            final AdditionalDriver additionalDriver = vehicleRentalDetail.getAdditionalDriver();
            logger.info("Additional drivers details also need to be sent for #" + agreement.getAgreementNumber());
            requests.add(mapToRentalDetaliCommentRequest(agreement, agreementItem,
                "Addl Drvr: " + additionalDriver.getName()));
            requests.add(mapToRentalDetaliCommentRequest(agreement, agreementItem,
                    "Driver DOB: " + new SimpleDateFormat(Constants.DateFormat.DATE_FORMAT)
                            .format(additionalDriver.getDateOfBirth())));
        }

        return requests;
    }

    /**
     * Creates the request dyna bean from the passed information.
     * @param agreement the areement for which the request is to be created.
     * @param agreementItem thea greement item for which the request is to be sent.
     * @param comment the comment that is to be sent to the kiosk server.
     * @return the DynaBean representing the request.
     */
    private DynaBean mapToRentalDetaliCommentRequest(
            final Agreement agreement, final AgreementItem agreementItem, final String comment) {
        final DynaBean request = kioskGateway.createRequestBean(KioskRequest.RENTAL_DETAIL_CREATE);
        request.set("clientId", Constants.Kiosk.CLIENT_ID);
        request.set("docNumber", agreement.getEightDigitAgreementNumberWithoutHyphen().toString());
        request.set("sku", agreementItem.getItem().getBaseSkuValue().toString());
        request.set("quantity", "0");
        request.set("additionalDesc", comment);
        return request;
    }

    /**
     * The setter for the kiosk Gateway.
     * @param kioskGateway The kiosk gateway.
     */
    public void setKioskGateway(final KioskGateway kioskGateway) {
        this.kioskGateway = kioskGateway;
    }

    /**
     * The method creates a guest from the response we get from the kiosk service.
     * @param result response from the kiosk server.
     * @param phoneNumber the phone number that we had requrested.
     * @return the Guest object holding data from the kiosk response.
     */
    private Guest createGuest(final DynaBean result, final String phoneNumber) {
        final Guest guest = new Guest();
        guest.setFullName((String) result.get("name"));
        guest.getAddress().setLine((String) result.get("address1"));
        guest.getAddress().setCity((String) result.get("city"));
        guest.getAddress().setState((String) result.get("state"));
        guest.getAddress().setZipCode((String) result.get("zip"));
        guest.setPhoneNumber(phoneNumber);
        return guest;
    }

    /**
     * Returns the rental detail request with the given parameters.
     * @param agreementItem the agreement item for which the request is to be created.
     * @param sku the sku for which the request is to be sent.
     * @param quantity the quantity of items.
     * @param retailPrice the retail price.
     * @param description1 the description1 of the item.
     * @param description2 the additional description to be sent to the kiosk server.
     * @param description3 the additional description 3 to be sent to the kiosk server.
     * @return the Request reference.
     */
    private DynaBean mapToRentalDetailRequest(final AgreementItem agreementItem,
                                              final String sku,
                                              final String quantity,
                                              final BigDecimal retailPrice,
                                              final String description1,
                                              final String description2,
                                              final String description3) {
        final DynaBean request = kioskGateway.createRequestBean(KioskRequest.RENTAL_DETAIL_CREATE);
        request.set("clientId", Constants.Kiosk.CLIENT_ID); // Include on ALL Kiosk
        // messages
        request.set("docNumber", agreementItem.getAgreement().getEightDigitAgreementNumberWithoutHyphen().toString());
        request.set("sku", sku);
        request.set("quantity", quantity);

        final DecimalFormat decFormat = new DecimalFormat("####.##");

        request.set("retailPrice", decFormat.format(retailPrice));

        request.set("additionalDesc", description1);
        request.set("additionalDesc2", description2);
        request.set("additionalDesc3", description3);
        if (agreementItem.getHasPriceOverride()) {
            request.set("overrideReason", agreementItem.getOverride().getPriceOverrideComment());
        }
        request.set("damageWaiverDecline", agreementItem.getDamageWaiver().getDeclined().toString());
        return request;
    }
}
