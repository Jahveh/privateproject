/*
 * MyMenardsContextService.java
 */
package com.menards.rental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.Store;
import com.menards.rental.security.MenardsUser;

/**
 * Implementation of the ContextService that gets user and store information
 * from the Spring Security context that was loaded by the {@code
 * MyMenardsUserDetailsService}.
 *
 * @author geoff
 */
@Service("contextService")
public class MyMenardsContextService implements ContextService {

	/** The menards service. */
	@Autowired
	private MenardsService menardsService;

    /**
     * {@inheritDoc}
     */
	public void applyContextToAgreement(final Agreement agreement) {
		// Get the store from the System V Service
		final Store store = menardsService.getCurrentStore();
		agreement.setStore(store);
	}

    /**
     * {@inheritDoc}
     */
	public void applyStoreContext(final StoreNumberable sn) {
		sn.setStoreNumber(getStoreNumber());
	}

	/**
	 * The current store that is in context.
	 * 
	 * @return The store number for the current store
	 */
	public Integer getStoreNumber() {
        return getUser().getStore().getStoreNumber();
	}

	/**
	 * Get the current {@code MenardsUser} from the SecurityContext holder.
	 *
	 * @return The MenardsUser that represents the logged in user
	 */
	public MenardsUser getUser() {
		final MenardsUser user = (MenardsUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		// XXX: Do we want some sort of existence checking? Or is that not even
		// possible?
		// if (null == user)
		// throw new
		// RuntimeException("No user in the current context. User is not authenticated.");

		return user;
	}

	/**
	 * The current user that is in context.
	 * 
	 * @return The username of the current team member
	 */
	public String getUserName() {
		return getUser().getUsername();
	}

	/**
	 * Sets the menards service.
	 *
	 * @param menardsService the new menards service
	 */
	public void setMenardsService(final MenardsService menardsService) {
		this.menardsService = menardsService;
	}
}
