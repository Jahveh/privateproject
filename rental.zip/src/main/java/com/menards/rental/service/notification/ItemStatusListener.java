/**
 * ItemStatusListener.java
 */
package com.menards.rental.service.notification;

/**
 * The interface that should be implemented by all the interested item status listeners.  The classes that are
 * registered with the ItemStatusNotifier would not notified of the updated item status.
 *
 * @author deep
 */
public interface ItemStatusListener extends Listener<ItemStatusUpdatedEvent> {

}
