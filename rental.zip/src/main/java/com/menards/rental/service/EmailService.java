/*
 * EmailService.java
 */
package com.menards.rental.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

/**
 * The Class EmailService.
 */
@Service
public class EmailService {

	/** The log. */
	private static final Logger log = Logger.getLogger(EmailService.class.toString());

	/** The mail sender. */
	@Autowired
	private JavaMailSender mailSender;

	/**
	 * send the mail message.
	 *
	 * @param preparator the preparator
	 */
	public void sendEmailMessage(final MimeMessagePreparator preparator) {

		try {
			mailSender.send(preparator);
		} catch (final MailException ex) {
            log.error(ex.getMessage(), ex);
		}
	}

	/**
	 * Sets the mail sender.
	 *
	 * @param mailSender the new mail sender
	 */
	public void setMailSender(final JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}
	
	public void sendEmailMessage(String to, String subject, String body) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("RentalAgreements@menards.net");
        message.setTo(to);
        message.setSubject(subject);
        message.setText(body);
        mailSender.send(message);
    }
	
}
