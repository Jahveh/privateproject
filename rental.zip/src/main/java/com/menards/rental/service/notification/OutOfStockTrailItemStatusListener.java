package com.menards.rental.service.notification;

import com.menards.rental.domain.CollectionUtil;
import com.menards.rental.domain.ConditionEvaluator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import java.util.List;

/**
 * The class that is responsible for creating the out of stock audit trail.
 *
 * @author deep
 */
@Component
@Transactional(propagation = Propagation.REQUIRED)
public class OutOfStockTrailItemStatusListener implements ItemStatusListener {

    /** The log4j logger. */
    private static final Logger logger = Logger.getLogger(OutOfStockTrailItemStatusListener.class);

    /** The item status notifier reference. */
    @Autowired
    private ItemStatusNotifier itemStatusNotifier;

    /** The list of item status processors. */
    @Autowired
    private List<ItemStatusUpdateProcessor> itemStatusUpdateProcessors;

    /**
     * This method will register the this reference with the notifier.
     */
    @PostConstruct
    public void registerWithTheNotifier() {
        itemStatusNotifier.addListener(this);
    }

    /**
     * {@inheritDoc}
     */
    @Transactional
    public void notifyUpdate(final ItemStatusUpdatedEvent event) {
        final ItemStatusUpdateProcessor processor =
                new CollectionUtil<ItemStatusUpdateProcessor>(itemStatusUpdateProcessors)
                .returnEntityIfConditionIsTrue(new ConditionEvaluator<ItemStatusUpdateProcessor>() {

                    public boolean evaluate(final ItemStatusUpdateProcessor entity) {
                        return entity.canProcess(event);
                    }
                });
        if (null == processor) {
            logger.error("Could not find any processor to process the item status update event: " + event);
            return;
        }
        processor.process(event);
    }

    /**
     * The setter for the item status notifier.
     * @param itemStatusNotifier the value.
     */
    public void setItemStatusNotifier(final ItemStatusNotifier itemStatusNotifier) {
        this.itemStatusNotifier = itemStatusNotifier;
    }

    /**
     * The setter for the item status update processor.
     * @param itemStatusUpdateProcessors the list of processors.
     */
    public void setItemStatusUpdateProcessors(final List<ItemStatusUpdateProcessor> itemStatusUpdateProcessors) {
        this.itemStatusUpdateProcessors = itemStatusUpdateProcessors;
    }
}
