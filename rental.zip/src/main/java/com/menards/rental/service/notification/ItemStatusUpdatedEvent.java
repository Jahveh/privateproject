package com.menards.rental.service.notification;

import com.menards.rental.domain.Item;
import com.menards.rental.domain.ItemStatus;
import com.menards.rental.domain.Product;

import java.util.Calendar;

/**
 * The event that means that the item status has been updated. This event holds the time stamp when the update occurred.
 *
 * @author deep
 */
public class ItemStatusUpdatedEvent implements Event {

    /** The item reference for which this event occurred. */
    private Item item;

    /** The date representing when did the event occurr. */
    private Calendar when;

    /**
     * The constructor that takes the item and when as arguments.  This makes this class an immutable class.
     * @param item the item reference.
     * @param when the when reference.
     */
    public ItemStatusUpdatedEvent(final Item item, final Calendar when) {
        this.item = item;
        this.when = when;
    }

    /**
     * The getter for the item.
     * @return the value.
     */
    public Item getItem() {
        return item;
    }

    /**
     * The getter for the event time.
     * @return the value.
     */
    public Calendar getWhen() {
        return when;
    }

    /**
     * Should return true if the item was placed on hold.
     * @return true if item was placed on hold.
     */
    public boolean isOnHold() {
        return item.isOnHold();
    }

    /**
     * Returns true if the item is available.
     * @return true if the item is available.
     */
    public boolean isAvailable() {
        return item.isAvailable();
    }

    /**
     * Returns the product associated with the item.
     * @return the Product associated with the item.
     */
    public Product getProduct() {
        return item.getProduct();
    }

    /**
     * The getter for the store number.
     * @return returns the store number.
     */
    public Integer getStoreNumber() {
        return item.getStoreNumber();
    }

    /**
     * The getter for the item status.
     * @return the item status of the item.
     */
    public ItemStatus getItemStatus() {
        return item.getItemStatus();
    }

    /**
     * Should return true if the item is rented.
     * @return true if the item is rented.
     */
    public boolean isRented() {
        return item.isRented();
    }

    /**
     * Should return true if the item is unrentable.
     * @return true if the item is un-rentable.
     */
    public boolean isUnRentable() {
        return item.isUnRentable();
    }
}
