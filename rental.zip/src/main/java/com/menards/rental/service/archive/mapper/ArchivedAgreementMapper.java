/**
 * ArchivedAgreementMapper.java
 */
package com.menards.rental.service.archive.mapper;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.ArchivedAgreement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Calendar;

/**
 * The mapper for the archived agreements.
 *
 * @author deep
 */
@Component
public class ArchivedAgreementMapper {

    /** The mapper for the archived agreement items. */
    @Autowired
    private ArchivedAgreementItemMapper archivedAgreementItemMapper;

    /**
     * The method that will map an agreement into an Archived agreement.
     * @param agreement the agreement that is to be mapped.
     * @return the archived areement reference.
     */
    public ArchivedAgreement mapToArchivedAgreement(final Agreement agreement) {
        final ArchivedAgreement archivedAgreement = new ArchivedAgreement();
        archivedAgreement.setAgreement(agreement);
        archivedAgreement.setRentalDate(Calendar.getInstance());
        archivedAgreement.setItems(archivedAgreementItemMapper.mapToArchivedAgreementItems(agreement.getItems(),
                archivedAgreement));
        return archivedAgreement;
    }

    /**
     * The setter for the archived agreement item mapper.
     * @param archivedAgreementItemMapper the value to set.
     */
    public void setArchivedAgreementItemMapper(final ArchivedAgreementItemMapper archivedAgreementItemMapper) {
        this.archivedAgreementItemMapper = archivedAgreementItemMapper;
    }
}
