package com.menards.rental.service.external;

/**
 * The exception that will be thrown by the Kiosk Gateway if things go wrong.
 * @author deep
 */
public class KioskCommunicationException extends RuntimeException {

    /**
     * The constructor that takes the exception that was the real cause as argument.
     * @param throwable The exception that was the real cause of this exception.
     */
    public KioskCommunicationException(final Throwable throwable) {
        super(throwable);
    }
}
