package com.menards.rental.service.external;

import com.menards.kiosk.comm.KioskRequest;
import com.menards.kiosk.comm.KioskSocketComm;
import com.menards.kiosk.comm.KioskSocketCommException;
import com.menards.kiosk.mapper.strategy.MapperStrategy;
import com.menards.rental.service.ContextService;
import com.menards.rental.utils.Constants;
import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

/**
 * The Kiosk gateway the guy that actually talks to the kiosk servers.
 *
 * @author deep
 */
@Component
public class KioskGateway {

    /**
     * The Constant logger.
     */
    private static final Log logger = LogFactory.getLog(KioskGateway.class);

    /**
     * The store service.
     */
    @Autowired
    private StoreService storeService;

    /**
     * The context service.
     */
    @Autowired
    private ContextService contextService;

    /**
     * The method to create the request bean.
     * @param kioskRequest The type of the request
     * @return The request object.
     */
    public DynaBean createRequestBean(final KioskRequest kioskRequest) {
        return createRequestBeanFor(kioskRequest, contextService.getStoreNumber());
    }

    /**
     * Creates the requestbean for the given request and the store number passed as argument.  This method should be
     * preffered when we alread yknow the store number before hand.
     * @param kioskRequest the kiosk request that is to created.
     * @param storeNumber the store number for which the bean is to be created.
     * @return the DynaBean representing the request.
     */
    public DynaBean createRequestBeanFor(final KioskRequest kioskRequest, final Integer storeNumber) {
        try {
            final DynaBean dynaBean = getKioskSocketComm(storeNumber).createRequestBean(kioskRequest);
            populateEmptyValueInProperties(kioskRequest, dynaBean);
            return dynaBean;
        } catch (KioskSocketCommException e) {
//            logger.error(e.getMessage(), e);
            logger.warn(e.getMessage(), e);
            throw new KioskCommunicationException(e);
        } catch (IOException e) {
//            logger.error(e.getMessage(), e);
            logger.warn(e.getMessage(), e);
            throw new KioskCommunicationException(e);
        }
    }

    /**
     * Proceess the request.
     *
     * @param request the request.
     * @return the list of response objects from the kiosk server.
     */
    public List<DynaBean> processRequest(final DynaBean request) {
        return processRequestFor(request, contextService.getStoreNumber());
    }

    /**
     * Proceess the request.
     *
     * @param request the request
     * @param storeNumber the store number for which the request is to be processed.
     * @return the list of response objects from the kiosk server.
     */
    public List<DynaBean> processRequestFor(final DynaBean request, final Integer storeNumber) {
        try {
    		try {
				Configuration config = ((KioskRequest) request.get("kioskRequestType")).createConfiguration();
				logger.info("About to send kiosk message: " + decodeRequest(config, request));
			} catch (Exception e) {
				logger.error("Kiosk message could not be decoded for logging purposes.", e);
			}
            logger.info("Start of KIOSK communication");
            return getKioskSocketComm(storeNumber).sendRequest(request);
        } catch (final KioskSocketCommException e) {
//            logger.error(e.getMessage(), e);
            logger.warn(e.getMessage(), e);
            throw new KioskCommunicationException(e);
        } finally {
            logger.info("End of KIOSK communication");
        }
    }

    /**
     * Create the KioskSocketComm for the current store.
     *
     * @return the kiosk socket communication object for the current store.
     * @param storeNumber the store number for which the requeset is to be created.
     */
    private KioskSocketComm getKioskSocketComm(final Integer storeNumber) {
        KioskSocketComm kioskComm = new KioskSocketComm();
        kioskComm.setHost(storeService.getStoreByStoreNumber(storeNumber)
                .getKioskHost());
        kioskComm.setPort(Constants.Kiosk.KIOSK_PORT);
        return kioskComm;
    }

    /**
     * Populates empty string values to all the request properties of the given dynamic bean.
     * @param kioskRequest the kiosk request for which we have created this dynamic bean.
     * @param dynaBean the dynamic bean reference which has to be populated with empty values.
     * @throws IOException in case the properties file was not found.
     */
    private void populateEmptyValueInProperties(final KioskRequest kioskRequest,
                                                final DynaBean dynaBean) throws IOException {
        final Properties properties = getPropertiesFor(kioskRequest);
        for (final Object key : properties.keySet()) {
            final String name = key.toString();
            if (name.startsWith(Constants.Kiosk.REQUEST_PROPERTY_PREFIX)) {
                dynaBean.set(name.substring(Constants.Kiosk.REQUEST_PROPERTY_PREFIX.length()),
                        Constants.Action.EMPTY_STRING);
            }
        }
    }

    /**
     * Returns the list of properties associated with the kiosk request.
     * @param kioskRequest the kiosk request for which we need to return the properties.
     * @return The properties reference which holds al properties for the kiosk requeset.
     * @throws IOException in case the properties file was not found.
     */
    private Properties getPropertiesFor(final KioskRequest kioskRequest) throws IOException {
        final Properties properties = new Properties();
        properties.load(new ClassPathResource(kioskRequest.getPrefix()
                + Constants.Kiosk.PROPERTIES_FILE_EXTENSION)
                .getInputStream());
        return properties;
    }
    
	/**
	 * Pulled (nasty) from kiosksocketcomm to get the message out of the stupid dynabean!
	 * 
	 * @param configuration configuration used to determine strategy
	 * @return strategy used to handle the request and response
	 */
	private String decodeRequest(final Configuration configuration, final DynaBean requestBean) {
		
		// Determine the concrete mapper strategy to use for building the request
		// message and creating java beans out of the response.
		MapperStrategy mapperStrategy = null;
		try {
			Class strategyClass = Class.forName(configuration.getString("strategyClassName"));
			mapperStrategy = (MapperStrategy) strategyClass.newInstance();
			mapperStrategy.setConfiguration(configuration);
		}
		catch (final ClassCastException e) {
			logger.error("ClassCastException in createMapperStrategy", e);
		}
		catch (final InstantiationException e) {
			logger.error("InstantiationException in createMapperStrategy", e);
		}
		catch (final ClassNotFoundException e) {
			logger.error("ClassNotFoundException in createMapperStrategy", e);
		}
		catch (final IllegalAccessException e) {
			logger.error("IllegalAccessException in createMapperStrategy", e);
		}
		
		return mapperStrategy.buildRequestHeader(requestBean) 
		 + mapperStrategy.buildRequestBody(requestBean);
		
	}

}
