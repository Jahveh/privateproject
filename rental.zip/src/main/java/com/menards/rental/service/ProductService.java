/*
 * ProductService.java
 */
package com.menards.rental.service;

import com.menards.rental.domain.Product;
import com.menards.rental.domain.RentalSKU;
import com.menards.rental.domain.SKUInfo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * The product service this class deals with creating and updating products.
 * @author deep
 */
@Service(value = "productService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
public class ProductService {

    /**
     * Create a new instance of a product with all of the SKU information
     * initialized. This is helpful for when you display a Product on a page and
     * want to associate it to SKU ids.
     *
     * @return A new product ready to use.
     */
    public Product createNewProduct() {
        final Product product = new Product();
        final SKUInfo skuInfo = new SKUInfo();
        skuInfo.setBaseSKU(new RentalSKU());
        skuInfo.setIncrementalSKU(new RentalSKU());
        skuInfo.setSellingSKU(new RentalSKU());
        skuInfo.setSurchargeSKU(new RentalSKU());
        product.setSkuInfo(skuInfo);
        return product;
    }

    /**
     * Merges the existing product with this new values.  Used when we try to setup another sku with
     * the same base sku value.
     * @param existingProduct the existing product from the db.
     * @param newProduct the new project in which we have entered new values.
     */
    public void merge(final Product existingProduct, final Product newProduct) {
        copySKUs(existingProduct, newProduct);
        existingProduct.copyOtherInformationFrom(newProduct);
        existingProduct.merge();
    }

    /**
     * Updates the SKUs with the persisten values from the database and saves
     * the Product.
     *
     * @param product The product that needs to be saved.
     */
    public void save(final Product product) {
        copySKUs(product, product);
        product.persist();
    }

    /**
     * Copies the sku values into the existing product from the new product.
     * @param existingProduct the product in which values have to be copied.
     * @param newProduct the product from which the values have to be copied.
     */
    private void copySKUs(final Product existingProduct, final Product newProduct) {
        final RentalSKU baseSKU = RentalSKU.findRentalSKU(newProduct.getBaskSKUId());
        existingProduct.setBaseSKU(baseSKU);

        final RentalSKU incrementalSKU = RentalSKU.findRentalSKU(newProduct.getIncrementalSKUId());
        existingProduct.setIncrementalSKU(incrementalSKU);

        final RentalSKU sellingSKU = RentalSKU.findRentalSKU(newProduct.getSellingSKUId());
        existingProduct.setSellingSKU(sellingSKU);

        final RentalSKU surchargeSKU = RentalSKU.findRentalSKU(newProduct.getSurchargeSKUId());
        existingProduct.setSurchargeSKU(surchargeSKU);

        existingProduct.copyValuesFromSKU();
    }
}
