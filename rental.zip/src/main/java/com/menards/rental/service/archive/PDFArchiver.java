/**
 * PDFArchiver.java
 */
package com.menards.rental.service.archive;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

import com.lowagie.text.DocumentException;
import com.menards.rental.builder.ArchivePathBuilder;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.ArchivedAgreement;
import com.menards.rental.domain.GuestArchiveInfo;
import com.menards.rental.domain.ReservationAgreement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.xhtmlrenderer.pdf.ITextRenderer;

/**
 * The PDF Archiver that will help us create pdf archives of the given rental agreements.
 *
 * @author deep
 */
@Component
public class PDFArchiver {

    /**
     * The archive path builder reference.
     */
    @Autowired
    private ArchivePathBuilder archivePathBuilder;

    /** The pdf creator reference. */
    @Autowired
    private PDFCreator pdfCreator;

    /** The pdf reader reference. */
    @Autowired
    private PDFReader pdfReader;


    /**
     * Creates an archived pdf for the given agreement.  Returns the relative path of the archived pdf.
     *
     * @param agreement The agreement that is to be archived.
     * @return byte array representing the pdf data.
     */
    public byte[] archive(final Agreement agreement) {
        return pdfCreator.create(archivePathBuilder.build(agreement));
    }

    /**
     * Creates the archive of the reservation areement passed as argument.
     * @param reservationAgreement the reservation agreement for which the pdf is to be generated.
     * @return the byte array representing the pdf for the reservation agreement.
     */
    public byte[] archive(final ReservationAgreement reservationAgreement) {
        return pdfCreator.create(archivePathBuilder.build(reservationAgreement));
    }

    /**
     * Returns the archived pdf.
     * @param archivedAgreement the archived agreement whose pdf we need to return.
     * @return the byte array representing the archived pdf.
     */
    public byte[] getArchive(final ArchivedAgreement archivedAgreement) {
        return pdfReader.read(archivedAgreement);
    }

    /**
     * Updates the archive with the guest information passed in.
     * @param archivedAgreement the archive that is to be updated.
     * @param guestArchiveInfo the guest information with which the archive is to be updated.
     * @return the byte array of the updated archive.
     */
    public byte[] updateArchive(final ArchivedAgreement archivedAgreement, final GuestArchiveInfo guestArchiveInfo) {
        byte[] archive = getArchive(archivedAgreement);
        try {
        return pdfCreator.update(archive, guestArchiveInfo);
        } finally {
            archive = null;
        }
    }

    /**
     * The setter for the pdf creator.
     * @param pdfCreator the value to set.
     */
    public void setPDFCreator(final PDFCreator pdfCreator) {
        this.pdfCreator = pdfCreator;
    }

    /**
     * The setter for the rental path builder.
     * @param archivePathBuilder the value to set.
     */
    public void setArchivePathBuilder(final ArchivePathBuilder archivePathBuilder) {
        this.archivePathBuilder = archivePathBuilder;
    }

    /**
     * The setter for pdf reader.
     * @param pdfReader the value to set.
     */
    public void setPDFReader(final PDFReader pdfReader) {
        this.pdfReader = pdfReader;
    }
    /**
     * Returns the archived pdf.
     * @param agreementId the archived agreement whose pdf we need to return.
     * @return the byte array representing the archived pdf.
     */
    public byte[] archive(final String agreementId) {
        return pdfCreator.create(archivePathBuilder.build(agreementId));
    }
    public String getEmailText(final String agreementId){
    	 URL url;
    	 byte[] buffer = null;
		try {
			url = new URL(archivePathBuilder.build(agreementId).getURLFrom());
			InputStream in=url.openStream();
	    	 int count = 0;
	    	  while (count == 0) {
	    	   count = in.available();
	    	  }
	    	 buffer = new byte[count];
	    	 int readCount = 0; 
	    	  while (readCount < count) {
	    	   readCount += in.read(buffer, readCount, count - readCount);
	    	  }
	    	  in.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	 
    	 String str=new String(buffer);
         return str;
    }
}
