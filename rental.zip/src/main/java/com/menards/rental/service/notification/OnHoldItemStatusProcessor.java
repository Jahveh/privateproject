package com.menards.rental.service.notification;

import org.springframework.stereotype.Component;

/**
 * The onHold item status processor.  This processor does nothing as we dont have to log anything when the item is put
 * on hold.
 *
 * @author deep
 */
@Component
public class OnHoldItemStatusProcessor implements ItemStatusUpdateProcessor {

    /**
     * {@inheritDoc}
     */
    public boolean canProcess(final ItemStatusUpdatedEvent event) {
        return event.isOnHold();
    }

    /**
     * {@inheritDoc}
     */
    public void process(final ItemStatusUpdatedEvent event) {
    }
}
