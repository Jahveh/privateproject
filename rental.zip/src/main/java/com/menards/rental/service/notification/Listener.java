/**
 * Listener.java
 */
package com.menards.rental.service.notification;

/**
 * The interface that helps us listen to all sorts of notifications.
 *
 * @author deep
 * @param <T> the type of event that this interface will be listening to.
 */
public interface Listener<T extends Event> {
    /**
     * The item status update notification.  Implementing classes should do the required processing in this method.
     * @param event the event that has occurred and needs to be processed.
     */
    void notifyUpdate(final T event);
}
