/*
 * ItemService.java
 */
package com.menards.rental.service;

import com.menards.rental.decorator.LazyItemList;
import com.menards.rental.domain.*;
import com.menards.rental.service.external.KioskCommunicationException;
import com.menards.rental.service.external.KioskService;
import com.menards.rental.service.external.exception.KioskException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

/**
 * The Class ItemService.
 */
@Service
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
public class ItemService {

    /** The logger reference. */
    private static final Logger logger = Logger.getLogger(ItemService.class);

	/** The context service. */
	@Autowired
	private ContextService contextService;

    /** The kiosk server. */
    @Autowired
    private KioskService kioskService;

	/**
	 * Create a new instance of an Item with the Store and ItemStatus
	 * initialized to the proper values.
	 *
	 * @return The new instance of an Item ready to use.
	 */
	public Item createNewItem() {
		final Item item = new Item();
		item.setStoreNumber(contextService.getStoreNumber());
		return item;
	}

	/**
     * The method that returns true is new item creation is not possible.
     * @param item the item that is to be created.
     * @return true if new item creation is not possible.
     */
    public boolean isNewItemCreationNotPossible(final Item item) {
        final long itemsCount = Item.countRentableItemsByProductAndStoreNumber(item.getProduct(), item.getStoreNumber());
        final KioskSKUDetail kioskSKUDetail = kioskService.getKioskSKUDetailFor(item.getSellingSkuValue());
        return ((null == kioskSKUDetail) || (itemsCount >= kioskSKUDetail.getNumberOfItems()));
    }

    /**
     * Saves the item to the db.
     * @param item to save.
     */
    public void saveItem(final Item item) {
        item.setUsageNumber(new BigDecimal("0.0"));

        // If the associate product has a vehicle, let is get saved.
        // otherwise set the vehicle to null
        if (item.getProduct().getInsuranceAdditionalDriverLicenseRequired()) {
            final Vehicle vehicle = item.getVehicle();
            vehicle.setItem(item);
            item.setVehicle(vehicle);
        } else {
            item.setVehicle(null);
        }
        item.setItemStatus(ItemStatus.findAvailable());
        item.persist();
    }

    /**
	 * Sets the context service.
	 *
	 * @param contextService the new context service
	 */
	public void setContextService(final ContextService contextService) {
		this.contextService = contextService;
	}

    /**
     * The setter for the kiosk service.
     * @param kioskService the value.
     */
    public void setKioskService(final KioskService kioskService) {
        this.kioskService = kioskService;
    }

    /**
     * Syncs the item inventory with the kiosk server.
     * @param product for which we have to sync inventory.
     * @return true if the sync inventory was successful.  False otherwise.
     */
    public boolean syncItemInventory(final Product product) {
        try {
            kioskService.syncInventory(
                    product, Item.countCurrentlyRentableItemsByProductAndStoreNumber(
                    product, contextService.getStoreNumber()));
            return true;
        } catch (final KioskException e) {
            logger.error(e.getMessage(), e);
            return false;
        }
    }

    /**
     * This method is responsible to update the status of the selected items.  If the number of rentable items in the
     * system exceeds total items setup in the kiosk then an IllegalStateException will be thrown.  If communication
     * with kiosk server fails then KioskCommunication exception will be thrown.
     * @param itemList the list of items whose status is to be updated.
     * @throws IllegalStateException if number of rentable items exceeds total items setup in kiosk server
     * @throws IllegalArgumentException if user tries to change an item status to rented when no active agreement is
     * associated with the item.
     * @throws com.menards.rental.service.external.KioskCommunicationException if we are unable to sync inventory
     * with kiosk server.
     */
    public void updateItemStatus(final LazyItemList itemList) {
        Item itemToSync = null;
		for (final Item item : itemList.getItems()) {
            final Item itemToUpdate = Item.findItem(item.getId());
            final ItemStatus itemStatus = ItemStatus.findItemStatus(item.getItemStatus().getId());
            if(itemStatus.isRented()) {
                if(null == Agreement.findActiveAgreementAssociatedWithItem(itemToUpdate)) {
                    throw new IllegalArgumentException("Cannot change the status to rented for: "
                            + itemToUpdate.getDescription() + ", as no active agreement is associated with it");
                }
            }
            itemToUpdate.setItemStatus(itemStatus);
            itemToUpdate.persist();
            itemToSync = itemToUpdate;
		}

        checkCountOfRentableItemsDoNotExceedItemsSetupAtKiosk(itemToSync);

        try {
            kioskService.syncInventory(itemToSync.getProduct(),
                    Item.countCurrentlyRentableItemsByProductAndStoreNumber(
                            itemToSync.getProduct(), itemToSync.getStoreNumber()));
        } catch (final KioskException e) {
            logger.warn(e.getMessage(), e);
            throw new KioskCommunicationException(e);
        }
    }

    /**
     * Checks that the cound of rentable items do not exceed the count of items in kiosk server.
     *
     *
     * @param item the item for which the count is to be checked.
     * @throws IllegalStateException if number of rentable items in the rental system exceeds the items setup in kiosk.
     */
    private void checkCountOfRentableItemsDoNotExceedItemsSetupAtKiosk(final Item item) {
        final long itemsCount = Item.countRentableItemsByProductAndStoreNumber(item.getProduct(),
                item.getStoreNumber());
        final KioskSKUDetail kioskSKUDetail = kioskService.getKioskSKUDetailFor(item.getSellingSkuValue());
        if ((null == kioskSKUDetail) || (itemsCount > kioskSKUDetail.getNumberOfItems())) {
            throw new IllegalStateException("Rentable items exceeds items setup on Kiosk");
        }
    }
}
