package com.menards.rental.service.external.exception;

import com.menards.rental.service.external.KioskCommunicationException;

/**
 * The exception that represents that something has gone wrong while communicating with the kiosk server.
 * @author deep
 */
public class KioskException extends RuntimeException {

    /**
     * The constructor that takes the kiosk communiation excepiton as argument.
     * @param e the exception object.
     */
    public KioskException(final KioskCommunicationException e) {
        super(e);
    }

    /**
     * The default constructor.
     */
    public KioskException() {

    }
}
