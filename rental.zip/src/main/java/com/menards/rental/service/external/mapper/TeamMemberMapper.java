package com.menards.rental.service.external.mapper;

import com.menards.rental.domain.StoreUserCollection;
import com.menards.rental.domain.StoreUserInfo;
import com.menards.teammember.types.legacy.StoreUser;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * The mapper that maps the store users to team store user infos.
 *
 * @author deep
 */
@Component
public class TeamMemberMapper {
    /**
     * Maps the list of store users to the store user collection which holds only the general managers.
     * @param storeUserList the store user list that we get from the team member service.
     * @param storeNumber the store number where the users belong.
     * @return the mapped StoreUserCollection reference.
     */
    public StoreUserCollection mapToStoreUsers(final List<StoreUser> storeUserList, final Integer storeNumber) {
        final StoreUserCollection storeUserCollection = new StoreUserCollection(new ArrayList<StoreUserInfo>(), storeNumber);
        for(StoreUser storeUser : storeUserList) {
        	storeUserCollection.add(mapToStoreUserInfo(storeUser));
        }
        return storeUserCollection;
    }

    /**
     * The mapper to map from store user to store user info.
     * @param storeUser the store user that is to be mapped.
     * @return the mapped store user info reference.
     */
    private StoreUserInfo mapToStoreUserInfo(final StoreUser storeUser) {
        final StoreUserInfo storeUserInfo = new StoreUserInfo();
        storeUserInfo.setId(storeUser.getUserId());
        storeUserInfo.setName(storeUser.getUserName());
        storeUserInfo.setPosition(storeUser.getPositionName());
        return storeUserInfo;
    }
}
