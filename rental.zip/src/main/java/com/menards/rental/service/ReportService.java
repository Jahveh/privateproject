/*
 * ReportService.java
 */
package com.menards.rental.service;

import com.menards.rental.domain.Report;
import com.menards.rental.report.ReportCreator;
import com.menards.rental.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * The Class ReportService.
 */
@Service
public class ReportService {

    /**
     * The report creators.
     */
    @Autowired
    private List<ReportCreator> reportCreators;

    /**
     * Generates the report as well as publishes the report based on the report medium.
     * If the report medium is email the report is emailed to the desired receiptents else it will be published
     * on the servlet output stream.
     *
     * @param report the report object which we have to generate.
     * @param model  the model object to fill the report.
     */
    public void generateAndPublishReport(final Report report, final Map<String, Object> model) {
        for (final ReportCreator reportCreator : reportCreators) {
            if (reportCreator.canCreate(report)) {
                final String reportData = reportCreator.create(report, model);
                model.put(Constants.ReportPublisher.DATA_KEY, reportData);
                reportCreator.publish(report, model);
                return;
            }
        }
        throw new IllegalArgumentException("Report Creator for: " + report.getType() + " is not available!");
    }

    /**
     * Sets the report creators.
     *
     * @param reportCreators the new report creators
     */
    public void setReportCreators(final List<ReportCreator> reportCreators) {
        this.reportCreators = reportCreators;
	}
}
