/*
 * SkuService.java
 */
package com.menards.rental.service;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.menards.rental.domain.ElecRentalCd;
import com.menards.rental.domain.RentalSKU;
import com.menards.rental.generated.skulist.SkuList;

/**
 * Service class to handle mediating between SKUs from JMS and database
 * entities.
 */
@Service
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
public class SkuService {

	/** The logger. */
	private static final Logger logger = Logger.getLogger(SkuService.class);

	/**
	 * Add a new SKU or update an existing one.
	 * 
	 * @param sku
	 *            The SKU to add or update that came from JMS
	 */
	public void addOrUpdateSKU(final SkuList.Sku sku) {
		RentalSKU skuEntity = RentalSKU.findSKUByValue(Long.parseLong(sku.getSkuNbr()));
		if (null == skuEntity) {
			skuEntity = new RentalSKU();
			logger.debug("No SKU found for " + sku.getSkuNbr());
		}

		skuEntity.setDescription(sku.getDescription());
		skuEntity.setValue(Long.parseLong(sku.getSkuNbr()));
		final ElecRentalCd elecRentalCd = ElecRentalCd.getElecRentalCd(Integer.parseInt(sku.getElecRentalCd()));
		skuEntity.setType(elecRentalCd.getDescription());
		skuEntity.persist();
	}

	/**
	 * Remove a SKU from the database.
	 * 
	 * @param sku
	 *            The SKU to remove that came from JMS
	 */
	public void deleteSKU(final SkuList.Sku sku) {
		final RentalSKU skuEntity = RentalSKU.findSKUByValue(Long.parseLong(sku.getSkuNbr()));
		if (null == skuEntity) {
			logger.debug("For deleting no SKU found for " + sku.getSkuNbr());
			return;
		}

		skuEntity.remove();
	}
}
