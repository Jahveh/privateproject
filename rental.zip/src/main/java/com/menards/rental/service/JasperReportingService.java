/*
 * JasperReportingService.java
 */
package com.menards.rental.service;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * The Class JasperReportingService.
 */
@Service
public class JasperReportingService {

	/** The data source. */
	@Autowired
	private DataSource dataSource;

	/**
	 * Gets the data source.
	 *
	 * @return the data source
	 */
	public DataSource getDataSource() {
		return dataSource;
	}
}
