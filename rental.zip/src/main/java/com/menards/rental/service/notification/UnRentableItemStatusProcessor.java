package com.menards.rental.service.notification;

import com.menards.rental.domain.Item;
import com.menards.rental.domain.ItemStatus;
import com.menards.rental.domain.OutOfStockAuditTrail;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * The status processor that deals with all the un-rentable status.
 *
 * @author deep
 */
@Component
public class UnRentableItemStatusProcessor implements ItemStatusUpdateProcessor {
    /** The logger reference. */
    private static final Logger logger = Logger.getLogger(UnRentableItemStatusProcessor.class);
    /**
     * {@inheritDoc}
     */
    public boolean canProcess(final ItemStatusUpdatedEvent event) {
        return event.isUnRentable();
    }

    /**
     * {@inheritDoc}
     */
    public void process(final ItemStatusUpdatedEvent event) {
        final long rentableItemsCount = Item.countRentableItemsByProductAndStoreNumber(event.getProduct(),
                event.getStoreNumber());
        if (rentableItemsCount == 0) {
            logger.debug("Number of rentable items in the system is zero.  "
                    + "Hence its a situation where sku is not setup for the store.  Nothing to do");
            return;
        }

        final long totalAvailableOrOnHoldItems =
                  Item.countItemsByProductAndStoreNumberAndItemStatus(event.getProduct(), event.getStoreNumber(),
                        ItemStatus.findAvailable())
                + Item.countItemsByProductAndStoreNumberAndItemStatus(event.getProduct(),
                event.getStoreNumber(), ItemStatus.findOnHold());
        if (totalAvailableOrOnHoldItems > 0) {
            logger.debug(
                "Even after making the item unrentable still there are items available or onHold in the system."
                        + "  Nothing to do.");
            return;
        }

        final OutOfStockAuditTrail outOfStockAuditTrail = new OutOfStockAuditTrail();
        outOfStockAuditTrail.setProduct(event.getProduct());
        outOfStockAuditTrail.setStoreNumber(event.getStoreNumber());
        outOfStockAuditTrail.setStartTime(event.getWhen());
        outOfStockAuditTrail.persist();
    }
}
