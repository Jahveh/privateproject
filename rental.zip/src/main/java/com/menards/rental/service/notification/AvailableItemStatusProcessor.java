package com.menards.rental.service.notification;

import com.menards.rental.domain.Item;
import com.menards.rental.domain.OutOfStockAuditTrail;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * The processor that is supposed to process the available item status event.
 *
 * @author deep
 */
@Component
public class AvailableItemStatusProcessor implements ItemStatusUpdateProcessor {

    /** The logger. */
    private static final Logger logger = Logger.getLogger(AvailableItemStatusProcessor.class);

    /**
     * {@inheritDoc}
     */
    public boolean canProcess(final ItemStatusUpdatedEvent event) {
        return event.isAvailable();
    }

    /**
     * {@inheritDoc}
     */
    public void process(final ItemStatusUpdatedEvent event) {
        final long availableItemCount = Item.countItemsByProductAndStoreNumberAndItemStatus(event.getProduct(),
                event.getStoreNumber(),
                event.getItemStatus());
        if (availableItemCount > 1) {
            logger.info("More than one item is available and hence not Item was not out of stock");
            return;
        }
        final OutOfStockAuditTrail outOfStockAuditTrail = OutOfStockAuditTrail
                .findOutOfStockAuditTrailByProductAndStoreNumberAndEndTimeIsNull(event.getProduct(),
                        event.getStoreNumber());
        if (null == outOfStockAuditTrail) {
            logger.info("No out of stock record found for product: " + event.getProduct().getId() + " storeNumber: "
                    + event.getStoreNumber());
            logger.info(
                   "This could happen because none of the items were rentable before and now one has become available");
            return;
        }

        outOfStockAuditTrail.setEndTime(event.getWhen());
        outOfStockAuditTrail.merge();
        logger.debug("Updated the out of stock audit trail record");
    }
}
