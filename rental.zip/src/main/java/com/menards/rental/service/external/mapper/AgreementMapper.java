/**
 * AgreementMapper.class
 */
package com.menards.rental.service.external.mapper;

import java.util.Calendar;

import org.springframework.stereotype.Component;

import com.menards.rental.domain.Agreement;
import com.menards.rental.generated.rentaltransdata.RentalTransData;

/**
 * The mapper class that will map the rental transaction information into the rental agreement.
 *
 * @author deep
 */
@Component
public class AgreementMapper {

    /**
     * Copies the values from rental transaction bean into the agreement.
     * @param agreement the agreement into which we have to copy the values.
     * @param rentalTrans the rental transaction xml that we received from kiosk.
     * @param initialPaidDate the initial paid date for the agreement.
     */
    public void copyValues(final Agreement agreement, final RentalTransData.RentalTrans rentalTrans,
                           final Calendar initialPaidDate) {
        agreement.setTransactionNumber(rentalTrans.getTranNum());
        agreement.setRegisterNumber(rentalTrans.getRegNum());
        agreement.setInitialPaidDate(initialPaidDate);
    }
}
