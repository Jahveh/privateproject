/**
 * BaseNotifier.java
 */
package com.menards.rental.service.notification;

import com.menards.rental.domain.CollectionUtil;
import com.menards.rental.domain.ExpressionEvaluator;
import java.util.HashSet;

/**
 * The base notifier that works with a set of notification listeners.
 *
 * @author deep
 * @param <T> the type of listener with which this notifier works.
 * @param <E> this class works with a given entity
 * @param <D> the domain class for which this notifier exists.
 */
public abstract class BaseNotifier<T extends Listener<E>, E extends Event, D> {
    /**
     * The current item status listeners list.
     */
    private final CollectionUtil<T> listeners =
            new CollectionUtil<T>(new HashSet<T>());

    /**
     * The method that adds the listener passed in as argument to the list of listeners currently registered with the
     * notifier.
     *
     * @param listener The listener reference.
     */
    public void addListener(final T listener) {
        listeners.add(listener);
    }

    /**
     * Removes the listener from the current list of listeners that are registered with this notifier.
     *
     * @param listener the listener reference that is to be removed from the current list.
     */
    public void removeListener(final T listener) {
        listeners.remove(listener);
    }

    /**
     * The getter for the current item status listeners.
     *
     * @return the list of item status listeners that are currently registered.
     */
    CollectionUtil<T> getListeners() {
        return listeners;
    }

    /**
     * This method notifys the listener about the domain status change event.
     *
     * @param domain the domain whose status has changed.
     */
    public void notifyUpdate(final D domain) {
        final E event = getEvent(domain);
        listeners.doInLoop(new ExpressionEvaluator<T>() {

            public void evaluate(final T entity) {
                entity.notifyUpdate(event);
            }
        });
    }

    /**
     * The implementing classes shouldimplement this method to return the event object associated with them.
     * @param domainObject the domain object that has triggered the event.
     * @return the Event object with which the isteners work.
     */
    protected abstract E getEvent(D domainObject);


}
