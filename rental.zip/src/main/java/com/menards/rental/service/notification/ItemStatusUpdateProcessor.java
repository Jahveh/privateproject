package com.menards.rental.service.notification;

/**
 * The interface that should be implemented to process the item status.  Differet Item status will be
 * handled by different processors.
 *
 * @author deep
 */
public interface ItemStatusUpdateProcessor {

    /**
     * The method that returns true if the current instance can process the item status passed.
     * @param event the update event that occurred.
     * @return true if the instance can process the item status update event.
     */
    boolean canProcess(final ItemStatusUpdatedEvent event);

    /**
     * This method will be called once the reference confirms that it can process this particular update.
     * @param event the update event that needs to be processed.
     */
    void process(final ItemStatusUpdatedEvent event);
}
