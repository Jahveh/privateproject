/*
 * StoreHourService.java
 */
package com.menards.rental.service.external;

import com.menards.rental.domain.Store;
import com.menards.rental.domain.StoreHour;
import com.menards.rental.service.external.mapper.StoreMapper;
import com.menards.service.yard.StoreHoursList;
import com.menards.service.yard.YardshipList;
import com.menards.yard.YardWebService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

import java.util.Set;

/**
 * The Class StoreHourService.
 */
@Service
public class StoreService {

    /**
     * The logger reference.
     */
    private static final Logger logger = Logger.getLogger(StoreService.class);

    /**
     * The cached stores.
     */
    private final Cache<Store> stores = new Cache<Store>();

    /**
     * The cached store hours.
     */
    private final Cache<StoreHour> storeHours = new Cache<StoreHour>();

    /**
     * The yard service.
     */
    @Autowired
    private YardWebService yardService;

    /** The store mapper reference. */
    @Autowired
    private StoreMapper storeMapper;

    /**
     * Gets the store hour for the given store number.
     *
     * @param storeNumber the store number for which we need to find the store hours.
     * @return the store hours for the given store number.
     */
    public StoreHour getStoreHourByStoreNumber(final Integer storeNumber) {
        return storeHours.lookup(storeNumber);
    }

    /**
     * Should return the list of all the store numbers.
     *
     * @return list of all available store numbers.
     */
    public Set<Integer> getAllStoreNumbers() {
        return storeHours.keys();
    }

    /**
     * Initialization routine. Spring will use this to initialize the object state.
     * this method is also called by the schedular at regualar interval to refresh
     * the list
     * @throws IllegalArgumentException if we are unable to get all store hours from yard service.
     */
    @PostConstruct
    public void init() {
        clearAllCaches();
        cacheStoreHours();
    }

    /**
     * Returns the store that matches the store number passed in as agument.
     *
     * @param storeNumber the store number to match.
     * @return the store object matching the store number
     * @throws IllegalArgumentException if a store with the given number is not found in the yard service.
     */
    public Store getStoreByStoreNumber(final Integer storeNumber) {

        if (null != stores.lookup(storeNumber)) {
            return stores.lookup(storeNumber);
        }

        try {
            final YardshipList yardShipList = yardService.getYardByYardNumber(storeNumber);

            if (isError(yardShipList)) {
//                logger.error("Could not find store with store number #: " + storeNumber);
                logger.warn("Could not find store with store number #: " + storeNumber);
                throw new IllegalArgumentException("Could not find store with store number #: " + storeNumber);
            }

            stores.put(storeMapper.mapToStore(yardShipList, storeNumber));
            return stores.lookup(storeNumber);
        } catch (final RuntimeException e) {
            logger.warn(e.getMessage(), e);
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * The setter for the store mapper.
     * @param storeMapper the value to set.
     */
    public void setStoreMapper(final StoreMapper storeMapper) {
        this.storeMapper = storeMapper;
    }

    /**
     * Gets all store hours and caches them.
     * @throws IllegalStateException if the class is unable to get the store hours from yard service or yard service
     * returns an error response.
     */
    private void cacheStoreHours() {
        try {
            final StoreHoursList storesHourList = yardService.getAllStoreHours();

            if (isError(storesHourList)) {
//                logger.error("Invalid response returned by yard service while getting all store hours.");
                logger.warn("Invalid response returned by yard service while getting all store hours.");
                throw new IllegalStateException("Could not get all store hours from yard service. "
                        + "Please solve this issue and reboot the app");
            }

            storeHours.putAll(storeMapper.mapToStoreHours(storesHourList));
        } catch (final RuntimeException e) {
            logger.warn(e.getMessage(), e);
            throw new IllegalStateException(e);
        }
    }

    /**
     * Clear all caches held by the store service.
     */
    private void clearAllCaches() {
        storeHours.clear();
        stores.clear();
    }

    /**
     * The method that returns true if the yardShipList returned has error.
     *
     * @param yardShipList the list that we got as response from the yardShipd service.
     * @return true if the yardShipList is an error response.
     */
    private boolean isError(final YardshipList yardShipList) {
        return ((null == yardShipList) || (yardShipList.getYardShip().isEmpty()));
    }

    /**
     * The method returns true if the storeHourList retrieved from the yard service is not valid.
     *
     * @param storesHourList the store hour list retrieved from the yard service.
     * @return true if the list returned from the yard service is invalid, false otherwise.
     */
    private boolean isError(final StoreHoursList storesHourList) {
        return ((null == storesHourList) || (storesHourList.getStoreHours().isEmpty()));
    }

    /**
     * The getter for the cached stores.
     * @return the cached stores.
     */
    public Cache<Store> getStores() {
        return stores;
    }

    /**
     * The getter for the cached store hours.
     * @return the cached store hours.
     */
    public Cache<StoreHour> getStoreHours() {
        return storeHours;
    }
}
