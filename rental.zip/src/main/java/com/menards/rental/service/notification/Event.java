/**
 * Event.java
 */
package com.menards.rental.service.notification;

/**
 * The event that will be bubbled up when a notification is sent.  This is just a marker interface.
 *
 * @author deep
 */
public interface Event {
}
