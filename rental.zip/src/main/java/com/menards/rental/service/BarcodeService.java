/*
 * BarcodeService.java
 */
package com.menards.rental.service;

import org.krysalis.barcode4j.tools.UnitConv;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.menards.rental.barcode.Barcode;
import com.menards.rental.barcode.BarcodeDetails;
import com.menards.rental.barcode.BarcodeGenerator;

/**
 * The Class BarcodeService.
 */
@Service
public class BarcodeService {

	/** The barcode generator. */
	@Autowired
	private BarcodeGenerator barcodeGenerator;

	/**
	 * Gets the pNG image bar code.
	 *
	 * @param toGenerateValue the value whose barcode is to be generated.
     * @param typeStrategy the barcode type strategy.
     * @return the pNG image bar code
	 */
	public Barcode getPNGImageBarCode(final String toGenerateValue, final BarcodeTypeStrategy typeStrategy) {
		final BarcodeDetails barcodeDetails = new BarcodeDetails();
		barcodeDetails.setImageType("image/png");
		barcodeDetails.setBarHeight(8.5); // 12.5 mm
		barcodeDetails.setNarrowBarWidth(UnitConv.in2mm(1.0f / 140)); // 0.20 mm
		barcodeDetails.setWidthFactor(2);
		barcodeDetails.setResolution(140);
        barcodeDetails.setTypeStrategy(typeStrategy);
        barcodeDetails.setToGenerateValue(toGenerateValue);
		return barcodeGenerator.generateBarcode(barcodeDetails);
	}

	/**
	 * Sets the barcode generator.
	 *
	 * @param barcodeGenerator the new barcode generator
	 */
	public void setBarcodeGenerator(final BarcodeGenerator barcodeGenerator) {
		this.barcodeGenerator = barcodeGenerator;
	}
}
