/**
 * AgreementUpdateEvent.java
 */
package com.menards.rental.service.notification;

import com.menards.rental.domain.Agreement;

/**
 * The event that will be used when an agreement is updated.
 *
 * @author deep
 */
public class AgreementUpdateEvent implements Event {

    /** The agreement reference. */
    private Agreement agreement;

    /**
     * The constructor that takes agreement as argument.
     * @param agreement the agreement reference.
     */
    public AgreementUpdateEvent(final Agreement agreement) {
        this.agreement = agreement;
    }

    /**
     * The getter for the agreement.
     * @return the value.
     */
    public Agreement getAgreement() {
        return agreement;
    }

    /**
     * The getter for the agreement number.
     * @return the String value representing the agreement number.
     */
    public String getAgreementNumber() {
        return agreement.getAgreementNumber();
    }
}
