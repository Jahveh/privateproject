/**
 * SignatureDecoder.java
 */
package com.menards.rental.decoder;

import com.menards.rental.utils.Constants;
import com.menards.signature.conversion.JDASignature;
import com.menards.signature.conversion.NCRSignature;
import com.menards.signature.conversion.Signature;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * The signature decoder class that will use the decoder provided by menards to decode the given signature.
 *
 * @author deep
 */
public class SignatureDecoder {

    /**
     * The encoded signature.
     */
    private String encodedSignature;

    /**
     * The constructor that takes encoded signature as argument.
     *
     * @param encodedSignature the encoded signature.
     */
    public SignatureDecoder(final String encodedSignature) {
        this.encodedSignature = encodedSignature;
    }

    /**
     * Returns the decoded signature back to the caller.
     *
     * @return the decoded signature to the caller.
     */
    public byte[] decode() {
        final Signature signature = new Signature(encodedSignature, new NCRSignature());
        final Image image = signature.getImage(200, 100);

        int width = image.getWidth(null);
        int height = image.getHeight(null);
        int type = BufferedImage.TYPE_INT_ARGB; // you can experiment with this one
        BufferedImage bi = new BufferedImage(width, height, type);
        Graphics2D g2d = bi.createGraphics();
        g2d.drawImage(image, 0, 0, null);
        g2d.dispose();
        try {
            final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            ImageIO.write(bi, Constants.ReportPublisher.PNG_FORMAT_TYPE, outputStream);
            return outputStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
