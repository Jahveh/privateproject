/*
 * MyMenardsAutoLoginFilter.java
 */
package com.menards.rental.security;

import java.util.EnumSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;

import com.menards.mymenards.integration.vo.SecureUser;
import com.menards.mymenards.integration.vo.Systems;
import com.menards.mymenards.security.HttpAuthentication;
import com.menards.rental.stubs.SecureUserStub;
import com.menards.rental.utils.MenardsProperties;

/**
 * Pre-authentication filter to integrate with the MyMenards authentication
 * portal to identify the user. Actual setup of roles, store information, etc
 * will be retrieved up by the {@code MyMenardsUserDetailService}
 * 
 * @author geoff
 */
public class MyMenardsAutoLoginFilter extends AbstractPreAuthenticatedProcessingFilter {

	/** The logger. */
	private static final Log logger = LogFactory.getLog(MyMenardsAutoLoginFilter.class);

	/** The systems. */
	private List<String> systems;

	/** The menards properties reference. */
	private MenardsProperties menardsProperties;

	/**
	 * Gets the systems.
	 * 
	 * @return the systems
	 */
	public List<String> getSystems() {
		return systems;
	}

	/**
	 * Gets the systems as an EnumSet.
	 * 
	 * @return the systems
	 */
	public EnumSet<Systems> getSystemsEnum() {
		EnumSet<Systems> systemSet = EnumSet.noneOf(Systems.class);

		for (String system : this.systems) {
			Systems enumValue = Systems.valueOf(system);
			if (null != enumValue) {
				systemSet.add(enumValue);
			}
		}

		return systemSet;
	}

	/**
	 * Sets the systems.
	 * 
	 * @param systems the new systems
	 */
	public void setSystems(final List<String> systems) {
		this.systems = systems;
	}

	/**
	 * The setter for menards properties.
	 * 
	 * @param menardsProperties the value to set.
	 */
	public void setMenardsProperties(final MenardsProperties menardsProperties) {
		this.menardsProperties = menardsProperties;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Object getPreAuthenticatedCredentials(final HttpServletRequest request) {
		return "ROLE_TEAM_MEMBER";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.web.authentication.preauth.
	 * AbstractPreAuthenticatedProcessingFilter#
	 * getPreAuthenticatedPrincipal(javax.servlet.http.HttpServletRequest)
	 */
	@Override
	protected Object getPreAuthenticatedPrincipal(final HttpServletRequest request) {
		logger.debug("Calling MyMenards pre-authentication.");
		SecureUser secureUser = null;
		if (request.getRequestURL().indexOf("report") == -1) {
			logger.debug("Finding user.");
			try {
				if (menardsProperties.isMyMenardsStubModeEnabled()) {
					secureUser = SecureUserStub.getSecureUser();
				} else {
					final MyMenardsRequestWrapper myMenardsRequestWrapper = new MyMenardsRequestWrapper(
							request);
					if (menardsProperties.isStubStoreSetup()) {
						myMenardsRequestWrapper.setAttribute("x-forwarded-for", "10.88.88.50");
					}
					HttpAuthentication httpAuth = HttpAuthentication.getInstance();
					secureUser = httpAuth.authenticate(request, getSystemsEnum());
				}
			} catch (final Exception ex) {
				logger.error(ex.getMessage(), ex);
			}

			logger.debug("Found User: " + secureUser.getUserName());
		}
		return secureUser;
	}
}
