/*
 * MenardsUser.java
 */
package com.menards.rental.security;

import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import com.menards.mymenards.integration.vo.SecureUser;
import com.menards.rental.domain.Store;

/**
 * This is a wrapper over the Spring security User object and actually exposed
 * MyMenards SecureUSerIF properties. The username properties come by default
 * from the base class User and rest all properties are introduced in this class
 * itself
 * 
 * @author lalit
 * 
 */
@SuppressWarnings("serial")
public class MenardsUser extends User {

	/** The Constant logger. */
	protected static final Log logger = LogFactory.getLog(MenardsUser.class.toString());

	/** The store. */
	private Store store;

	/**
	 * SecureUserIf contains a lot of parameters. All may not be relevant for
	 * rental application. As and when new properties need to be exposed to the
	 * rental application, keep exposing them by introducing new properties in
	 * MenardsUser and setting them in populateUserDetails method
	 *
	 * @param user the user
	 * @param authorities the authorities
	 */
	public MenardsUser(final SecureUser user, final Collection<GrantedAuthority> authorities){
		super(user.getUserName(), "NOT_USED", true, true, true, true, authorities);
		populateUserDetails(user);
	}

	/**
	 * Gets the store.
	 *
	 * @return the store
	 */
	public Store getStore() {
		return store;
	}

	/**
	 * Builds the store.
	 *
	 * @param user the user
	 * @return the store
	 */
	private Store buildStore(final SecureUser user) {
		final Store storeObj = new Store();

		storeObj.setStoreNumber(Integer.parseInt(user.getStoreNumber()));
		storeObj.setStoreName(user.getStoreName());
		storeObj.setStoreAddress1(user.getAddress());
		storeObj.setStoreAddress2(user.getAddress2());
        final String zip = user.getZip();
        if (null != zip) {
            storeObj.setStorePostalNumber(Integer.parseInt(zip.replaceAll("-", "")));
        }
		storeObj.setStorePhoneNumber(user.getStorePhone());
		storeObj.setStoreFaxNumber(user.getStoreFax());
        storeObj.setStoreAbbreviation(user.getStoreAbbreviation());

        return storeObj;
	}

	/**
	 * Populate user details.
	 *
	 * @param user the user
	 */
	private void populateUserDetails(final SecureUser user){
		store = buildStore(user);
	}

}
