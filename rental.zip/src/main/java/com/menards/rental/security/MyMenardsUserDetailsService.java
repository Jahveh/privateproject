package com.menards.rental.security;

import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;

import com.menards.mymenards.integration.vo.SecureUser;

/**
 * UserDetailsService that creates a User object that is stored as the
 * {@code Principal} of the SecurityContext and contains User, Role and Store
 * information for the MyMenards user.
 * 
 * @author geoff
 */
public class MyMenardsUserDetailsService implements AuthenticationUserDetailsService {

	/** The Constant logger. */
	protected static final Log logger = LogFactory.getLog(MyMenardsUserDetailsService.class.toString());

	/**
	 * {@inheritDoc}
	 */
	public UserDetails loadUserDetails(final Authentication token) {
		// TODO: Need to synch the roles with menards roles
		return new MenardsUser((SecureUser) token.getPrincipal(), new ArrayList<GrantedAuthority>());
	}
}
