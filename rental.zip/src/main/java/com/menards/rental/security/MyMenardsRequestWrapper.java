/**
 * MyMenardsRequestWrapper.java
 */
package com.menards.rental.security;

import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by IntelliJ IDEA.
 *
 * @author Deep Shah
 */
public class MyMenardsRequestWrapper extends HttpServletRequestWrapper {

    /**
     * The logger.
     */
    private static final Logger logger = Logger.getLogger(MyMenardsRequestWrapper.class);

    /**
     * The constructor that takes the servlet request as argument.
     *
     * @param request the servlet request value to set.
     */
    public MyMenardsRequestWrapper(final HttpServletRequest request) {
        super(request);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getHeader(final String name) {
        logger.info("###################Requesting header: " + name + " ########################");
        final Object attribute = getAttribute(name);
        if(null == attribute) {
            return super.getHeader(name);
        }
        return attribute.toString();
    }
}
