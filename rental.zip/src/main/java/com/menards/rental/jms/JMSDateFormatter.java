package com.menards.rental.jms;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.menards.rental.generated.rentaltransdata.RentalTransData;
import com.menards.rental.utils.Constants;

/**
 * The jms date formatter.
 *
 * @author deep
 */
@Component
public class JMSDateFormatter {

    /** The log4j logger. */
    private static final Logger log = Logger.getLogger(JMSDateFormatter.class);

    /**
     * Constructs the transaction date from the two seperate parts received from the rental transaction message.
     * @param rentalTrans the message that we get from kiosk server.
     * @return the Calendar object representing the transaction date.
     */
    public Calendar getTransactionDate(final RentalTransData.RentalTrans rentalTrans) {
        try {
            final Calendar transactionDate = Calendar.getInstance();
            transactionDate.setTime(new SimpleDateFormat(
                    Constants.JMSMessageListener.DEFAULT_DATE_FORMAT).parse(
                    String.format("%1$s %2$s", rentalTrans.getTranDate(), rentalTrans.getTranTime())));
            return transactionDate;
        } catch (ParseException e) {
            log.error("Could not parse the date", e);
            return null;
        }
    }


}
