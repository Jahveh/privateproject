package com.menards.rental.jms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.menards.rental.builder.AgreementNumberBuilder;
import com.menards.rental.domain.Agreement;
import com.menards.rental.generated.rentaltransdata.RentalTransData;

/**
 * The agreement notification message listener.  This guy listens to the agreement notifications for paid
 * returned agreement notifications.
 * @author deep
 */
@Component(value = "agreementNotificationMessageListener")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
public class AgreementNotificationMessageListener extends JMSMessageListener {

    /** The agreement number builder. */
    @Autowired
    private AgreementNumberBuilder agreementNumberBuilder;

    /** The agreement notification processor. */
    @Autowired
    private AgreementNotificationProcessor agreementNotificationProcessor;

    /**
     * Setter for the agreement number build.
     * @param agreementNumberBuilder the value.
     */
    public void setAgreementNumberBuilder(final AgreementNumberBuilder agreementNumberBuilder) {
        this.agreementNumberBuilder = agreementNumberBuilder;
    }

    /**
     * The setter for the agreement notification processor.
     * @param agreementNotificationProcessor the processor to set.
     */
    public void setAgreementNotificationProcessor(final AgreementNotificationProcessor agreementNotificationProcessor) {
        this.agreementNotificationProcessor = agreementNotificationProcessor;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected Class getObjectClass() {
        return RentalTransData.class;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void processMessage(final Object messageObject) {
        final RentalTransData rentalTransData = (RentalTransData) messageObject;
        for (RentalTransData.RentalTrans rentalTrans : rentalTransData.getRentalTrans()) {

            final Agreement agreement = Agreement.findAgreementByAgreementNumber(
                    agreementNumberBuilder.build(rentalTrans.getStoreNum(), rentalTrans.getRentalDocNum()));

            if (agreement != null) {
                agreementNotificationProcessor.process(agreement, rentalTrans);
            }
        }
    }
}
