/**
 * AgreementNotificationProcessor.java
 */
package com.menards.rental.jms;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.CollectionUtil;
import com.menards.rental.domain.ConditionEvaluator;
import com.menards.rental.generated.rentaltransdata.RentalTransData;

/**
 * The class that is responsible to process the agreement when a notification is sent.
 *
 * @author deep
 */
@Component
public class AgreementNotificationProcessor {

    /** The agreement processors configured in the system. */
    @Autowired
    private List<AgreementProcessor> agreementProcessors;

    /**
     * The method that will process the given agreement with the given transaction data.
     * @param agreement the agreement that is to be processed.
     * @param rentalTrans the rental transaction data.
     */
    public void process(final Agreement agreement,
                                 final RentalTransData.RentalTrans rentalTrans) {
        final AgreementProcessor agreementProcessor = new CollectionUtil<AgreementProcessor>(agreementProcessors).returnEntityIfConditionIsTrue(
                new ConditionEvaluator<AgreementProcessor>() {

                    /**
                     * {@inheritDoc}
                     */
                    public boolean evaluate(final AgreementProcessor entity) {
                        return entity.canProcess(agreement);
                    }
                });

        if (agreementProcessor != null) {
            agreementProcessor.process(agreement, rentalTrans);
        }
    }

    /**
     * The setter for the agreement processors.
     * @param agreementProcessors the value to set.
     */
    public void setAgreementProcessors(final List<AgreementProcessor> agreementProcessors) {
        this.agreementProcessors = agreementProcessors;
    }
}
