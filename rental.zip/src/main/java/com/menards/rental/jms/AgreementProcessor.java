/**
 * AgreementProcessor.java
 */
package com.menards.rental.jms;

import com.menards.rental.domain.Agreement;
import com.menards.rental.generated.rentaltransdata.RentalTransData;

/**
 * The interface that should be implemented by all the parties who desire to process the agreement
 * when a notification is received..
 *
 * @author deep
 */
public interface AgreementProcessor {

    /**
     * The method that should return true if the given agreement processor can process the agreement.
     * @param agreement the agreement that is to be processed.
     * @return true if the agreement can be processed by this processor.  False otherwise.
     */
    boolean canProcess(final Agreement agreement);

    /**
     * The method that should process the given agreement using the transaction information passed in.
     * @param agreement the agreement that is to be processed.
     * @param rentalTrans the transaction information using which we should process the agreement.
     */
    void process(final Agreement agreement, final RentalTransData.RentalTrans rentalTrans);
}
