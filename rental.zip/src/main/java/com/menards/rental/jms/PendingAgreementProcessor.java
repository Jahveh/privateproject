/**
 * PendingAgreementProcessor.java
 */
package com.menards.rental.jms;

import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.ArchivedAgreement;
import com.menards.rental.domain.GuestArchiveInfo;
import com.menards.rental.generated.rentaltransdata.RentalTransData;
import com.menards.rental.service.AgreementService;
import com.menards.rental.service.external.mapper.AgreementMapper;
import com.menards.rental.utils.Constants;

/**
 * The agreement processor that processes pending agreements.
 *
 * @author deep
 */
@Component
public class PendingAgreementProcessor implements AgreementProcessor {

    /** The areement service. */
    @Autowired
    private AgreementService agreementService;

    /** The agreement mapper reference. */
    @Autowired
    private AgreementMapper agreementMapper;

    /** The jms date formatter. */
    @Autowired
    private JMSDateFormatter jmsDateFormatter;

    /**
     * {@inheritDoc}
     */
    public boolean canProcess(final Agreement agreement) {
        return agreement.isPending();
    }

    /**
     * {@inheritDoc}
     */
    public void process(final Agreement agreement, final RentalTransData.RentalTrans rentalTrans) {
        final Calendar transactionDate = jmsDateFormatter.getTransactionDate(rentalTrans);
        final ArchivedAgreement archivedAgreement =
                ArchivedAgreement.findArchivedAgreementByAgreementNumber(agreement.getAgreementNumber());
        final GuestArchiveInfo guestArchiveInfo = new GuestArchiveInfo(
                archivedAgreement.getEightDigitAgreementNumberWithoutHyphen().toString(),
                transactionDate,
                archivedAgreement.getStore(), Constants.Archive.SIGNATURE_FOR_RENTAL_AGREEMENT_LABEL,
                Constants.Archive.RENTAL_MERCHANDISE_TNC_LABEL, rentalTrans.getTranSignature());
        agreementMapper.copyValues(agreement, rentalTrans, transactionDate);
        agreementService.makeAgreementActive(agreement, transactionDate);
        agreementService.updateArchive(archivedAgreement, guestArchiveInfo);
    }

    /**
     * The setter for the agreement service.
     * @param agreementService the value to set.
     */
    public void setAgreementService(final AgreementService agreementService) {
        this.agreementService = agreementService;
    }

    /**
     * The setter for agreement mapper.
     * @param agreementMapper the value to set.
     */
    public void setAgreementMapper(final AgreementMapper agreementMapper) {
        this.agreementMapper = agreementMapper;
    }

    /**
     * The setter for jms date formatter.
     * @param jmsDateFormatter the value to set.
     */
    public void setJMSDateFormatter(final JMSDateFormatter jmsDateFormatter) {
        this.jmsDateFormatter = jmsDateFormatter;
    }
}
