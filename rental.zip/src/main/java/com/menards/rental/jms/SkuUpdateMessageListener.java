/*
 * SkuUpdateMessageListener.java
 */
package com.menards.rental.jms;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.menards.rental.generated.skulist.SkuList;
import com.menards.rental.service.SkuService;

/**
 * A JMS listener to get updates about SKUs.
 *
 * @see com.menards.rental.jms.JMSMessageListener
 */
@Component(value = "skuUpdateListener")
public class SkuUpdateMessageListener extends JMSMessageListener {

    /**
     * The logger.
     */
    private static final Logger logger = Logger.getLogger(SkuUpdateMessageListener.class);

    /**
     * The sku service.
     */
    @Autowired
    private SkuService skuService;

    /**
     * The setter for the sku service.
     * @param skuService the value.
     */
    public void setSkuService(final SkuService skuService) {
        this.skuService = skuService;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    protected Class getObjectClass() {
        return SkuList.class;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void processMessage(final Object messageObject) {
        final SkuList skuList = (SkuList) messageObject;

        for (final SkuList.Sku sku : skuList.getSku()) {
            executeAction(sku);
        }
    }

    /**
     * Execute action.
     *
     * @param sku the sku
     */
    private void executeAction(final SkuList.Sku sku) {
        final String action = sku.getAction();
        if (action.equalsIgnoreCase("ADD")) {
            skuService.addOrUpdateSKU(sku);
        } else if (action.equalsIgnoreCase("DELETE")) {
            skuService.deleteSKU(sku);
        } else {
            logger.warn("Unknown action: " + action);
        }
    }
}
