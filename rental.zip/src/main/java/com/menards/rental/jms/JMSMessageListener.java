package com.menards.rental.jms;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * The JMS message listener so that we dont have to repeate the code to convert the message into xml and process it.
 * @author deep
 */
@Component(value = "jmsMessageListener")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
public abstract class JMSMessageListener {
    /** The logger. */
    private static final Logger logger = Logger.getLogger(JMSMessageListener.class);

    /**
     * Handles the message that comes from a queue.
     * @param message the message that we received from the JMS queue.
     */
    public void handleMessage(final String message) {
        logger.info("Received JMS Message for: " + this.getClass().getName());
        if (logger.isDebugEnabled()) {
            logger.debug("\n" + message);
        }

        final Object messageObject = new XMLToObjectConverter(getObjectClass()).convert(message);
        processMessage(messageObject);
    }

    /**
     * The get object class method this method will return the type object with which this listener works.
     * The derived classes should implement this method and return a proper object type.
     * @return the Class reference representing the type of object this class works with.
     */
    protected abstract Class getObjectClass();

    /**
     * Once the message is converted into an object this method will be invoked to process the message.
     * All derived classes should implement this method and do the custom processing of the message.
     * @param messageObject the message object that was converted from the xml message.
     */
    protected abstract void processMessage(final Object messageObject);
}
