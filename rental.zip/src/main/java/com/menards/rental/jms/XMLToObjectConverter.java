package com.menards.rental.jms;

import org.apache.log4j.Logger;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;

/**
 * The class that will create objects from the xml messages.
 * @author deep
 */
public class XMLToObjectConverter {
    /** The logger. */
    private static final Logger logger = Logger.getLogger(XMLToObjectConverter.class);

    /** The class whose object we will return. */
    private Class clazz;

    /**
     * The constructor that takes in the parameter i.e. the class whose objects we will return.
     * @param clazz - The class whose object we will return.
     */
    public XMLToObjectConverter(final Class clazz) {
        this.clazz = clazz;
    }

    /**
     * The method that is responsible to convert xml string message into object.
     * @param message The xml message.
     * @return the converted object.
     */
    public Object convert(final String message) {
        try {
            // Get the JAXB Context
            final JAXBContext jc = JAXBContext.newInstance(clazz);
            final Unmarshaller unmarshaller = jc.createUnmarshaller();
            final StringReader reader = new StringReader(message);
            return unmarshaller.unmarshal(reader);
        } catch (final JAXBException e) {
//            logger.error("Problem marshalling SKU", e);
            logger.warn("Problem marshalling SKU", e);
            throw new IllegalStateException(e);
        }
    }
}
