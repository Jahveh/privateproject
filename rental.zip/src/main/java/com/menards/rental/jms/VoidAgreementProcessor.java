package com.menards.rental.jms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.ArchivedAgreement;
import com.menards.rental.domain.GuestArchiveInfo;
import com.menards.rental.generated.rentaltransdata.RentalTransData;
import com.menards.rental.service.AgreementService;
import com.menards.rental.utils.Constants;

/**
 * The void agreement processor.
 *
 * @author deep
 */
@Component
public class VoidAgreementProcessor implements AgreementProcessor {

    /** The areement service. */
    @Autowired
    private AgreementService agreementService;

    /** The JMS date formatter. */
    @Autowired
    private JMSDateFormatter jmsDateFormatter;

    /**
     * {@inheritDoc}
     */
    public boolean canProcess(final Agreement agreement) {
        return agreement.isVoided();
    }

    /**
     * {@inheritDoc}
     */
    public void process(final Agreement agreement, final RentalTransData.RentalTrans rentalTrans) {
        final ArchivedAgreement archivedAgreement =
                ArchivedAgreement.findArchivedAgreementByAgreementNumber(agreement.getAgreementNumber());
        agreement.voidComplete();
        final GuestArchiveInfo guestArchiveInfo = new GuestArchiveInfo(
                archivedAgreement.getEightDigitAgreementNumberWithoutHyphen().toString(),
                jmsDateFormatter.getTransactionDate(rentalTrans),
                archivedAgreement.getStore(), Constants.Archive.SIGNATURE_FOR_RENTAL_AGREEMENT_LABEL,
                Constants.Archive.RENTAL_MERCHANDISE_TNC_LABEL, rentalTrans.getTranSignature());
        agreementService.updateArchive(archivedAgreement, guestArchiveInfo);
    }

    /**
     * The setter for the agreement service.
     * @param agreementService the value to set.
     */
    public void setAgreementService(final AgreementService agreementService) {
        this.agreementService = agreementService;
    }

    /**
     * The setter for the jms date formatter.
     * @param jmsDateFormatter the value to set.
     */
    public void setJMSDateFormatter(final JMSDateFormatter jmsDateFormatter) {
        this.jmsDateFormatter = jmsDateFormatter;
    }
}
