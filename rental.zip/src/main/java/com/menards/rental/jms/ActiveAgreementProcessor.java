/**
 * ActiveAgreementProcessor.java
 */
package com.menards.rental.jms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.menards.rental.domain.Agreement;
import com.menards.rental.generated.rentaltransdata.RentalTransData;
import com.menards.rental.service.AgreementService;

/**
 * The processor for active agreements.
 *
 * @author deep
 */
@Component
public class ActiveAgreementProcessor implements AgreementProcessor {

    /** The areement service. */
    @Autowired
    private AgreementService agreementService;

    /** The jms date formatter. */
    @Autowired
    private JMSDateFormatter jmsDateFormatter;


    /**
     * {@inheritDoc}
     */
    public boolean canProcess(final Agreement agreement) {
        return agreement.isActive();
    }

    /**
     * {@inheritDoc}
     */
    public void process(final Agreement agreement, final RentalTransData.RentalTrans rentalTrans) {
        agreementService.makeAgreementCompleteIfPossible(agreement,
                jmsDateFormatter.getTransactionDate(rentalTrans));
    }

    /**
     * The agreement service setter.
     * @param agreementService the value to set.
     */
    public void setAgreementService(final AgreementService agreementService) {
        this.agreementService = agreementService;
    }

    /**
     * The jms date formatter setter.
     * @param jmsDateFormatter the value to set.
     */
    public void setJMSDateFormatter(final JMSDateFormatter jmsDateFormatter) {
        this.jmsDateFormatter = jmsDateFormatter;
    }
}
