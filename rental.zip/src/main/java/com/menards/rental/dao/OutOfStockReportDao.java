/*
 * OutOfStockReportDao.java
 */
package com.menards.rental.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.menards.rental.domain.OutOfStockAuditTrail;
import com.menards.rental.domain.OutOfStockAuditTrailCollection;
import com.menards.rental.domain.Product;
import com.menards.rental.domain.StoreHourBasedRentalDateRange;
import com.menards.rental.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.menards.rental.dto.OutOfStockReportDto;
import com.menards.rental.service.external.StoreService;

/**
 * Handles getting the Out of Stock items for the Out of Stock Report.
 * @author deep
 */
@Repository(value = "outOfStockReportDao")
public class OutOfStockReportDao {

	/** The store hour service. */
	@Autowired
	private StoreService storeService;

	/**
	 * This report finds the out of stock %age of a given product in a store. 
	 * % of Time Out of Stock is calculated as the total amount of time that all
	 * items for each SKU were rented during store hours for the report
	 * timeframe / total store hours for the report timeframe. NOTE: If a store
	 * has 3 items of the same SKU, it is only considered out of stock if all
	 * three items are check-out at the same time.
	 *
	 *
     * @param reportStartDate the start date
     * @param reportEndDate the end date
     * @param storeNumberForReport for which the audit trail is to be generated.
     * @return The report is calculates as follows - First get the audit trail records for all the store
     * and for all products.  Then for each store iterate over the audit trail records and find the products belonging
     * to that store.  For each product there could be multiple entries in the audit trail record list.  The total
     * time for which the product is out of stock is calculated based on the sum of all the windows for which
     * the product was out of stock divided by the total store hours for each day for which the product could be rented.
	 */
	public List<OutOfStockReportDto> getOutOfStockReportData(final Calendar reportStartDate,
                                                             final Calendar reportEndDate) {

		final List<OutOfStockReportDto> outOfStockReportList = new ArrayList<OutOfStockReportDto>();

        /**
         * Getting the list of all the out of stock audit trail records for the given start and end dates.
         * This list contains the records for all the stores and for all the products.  The list could have multiple
         * records for same product.  Each such record represents the window for which the product went out of stock.
         */
		final List<OutOfStockAuditTrail> outOfStockProductList = OutOfStockAuditTrail
               .findOutOfStockAuditTrailsByStartDateBetweenOrderByProduct(
                       reportStartDate,
                       reportEndDate);
        final OutOfStockAuditTrailCollection auditTrailCollection =
                new OutOfStockAuditTrailCollection(outOfStockProductList);

        /**
         * We need to generate the report for each store hence iterating over
         * the distinct store numbers for which we have found the audit trail records.
         */
        for (final Integer storeNumber : auditTrailCollection.getDistinctStoreNumbers()) {
            /**
             * For each store we need to find the total open houses using the store hours based rental date range.
             */
            final double totalStoreOpenHours = new StoreHourBasedRentalDateRange(reportStartDate,
                    reportEndDate, storeNumber).getActualDurationInHours();

            for (final Product product : auditTrailCollection.getDistinctProducts()) {
                /**
                 * For each product for each store we will create an out of stock report dto.  Which will hold the
                 * percentage of time the product went out of stock for the particular store.
                 */
                final OutOfStockReportDto outOfStockReportDto = new OutOfStockReportDto(storeNumber,
                        product.getBaseSkuValue(),
                        product.getDescription());
                double totalOutOfStockHoursForTheProduct = 0.0;
                boolean isOutOfStockReportDtoToBeAdded = false;
                /**
                 * Iterating over the list of out of stock audit trails records and finding the windows for which the
                 * product went out of stock and adding up the durations.
                 */
                for (final OutOfStockAuditTrail outOfStockAuditTrail : outOfStockProductList) {
                    /**
                     * If the out of stock end date is null.  It means that the product is still out of stock.
                     * Hence the end date for out of stock product becomes current date.
                     */
                    Calendar endTime = outOfStockAuditTrail.getEndTime();
                    if (endTime == null) {
                        endTime = reportEndDate;
                    }
                    if (outOfStockAuditTrail.getStoreNumber().equals(storeNumber)
                            && outOfStockAuditTrail.getProduct().equals(product)) {
                        /**
                         * We have found out product and we now need to add up the times for which the product went
                         * out of stock.
                         */
                        isOutOfStockReportDtoToBeAdded = true;
                        totalOutOfStockHoursForTheProduct += new StoreHourBasedRentalDateRange(
                                outOfStockAuditTrail.getStartTime(),
                                endTime,
                                storeNumber).getActualDurationInHours();
                    }
                }
                if (isOutOfStockReportDtoToBeAdded) {
                    /**
                     * Calculating the percentage for which the product was out of stock.
                     */
                    outOfStockReportDto.setPercentageOutOfStock(
                            (totalOutOfStockHoursForTheProduct / totalStoreOpenHours)
                                    * Constants.Calculation.PERCENTAGE_CONVERTER);
                    outOfStockReportList.add(outOfStockReportDto);
                }
            }
        }
		return outOfStockReportList;

	}

    /**
     * The setter for the store service.
     * @param storeService the value.
     */
    public void setStoreService(final StoreService storeService) {
        this.storeService = storeService;
    }
}
