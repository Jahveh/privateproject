/*
 * VoidRentalReportDao.java
 */
package com.menards.rental.dao;

import java.util.Calendar;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementStatus;

/**
 * Handles finding the voided agreements for the Void Rental report.
 * 
 * @author deep
 */
@Repository(value = "voidRentalReportDao")
public class VoidRentalReportDao {

	/**
	 * Get the agreements voided for a given store in a given time period.
	 * 
	 * <em>where time period = [startDate, endDate] inclusive and startDate < endDate</em>
	 * 
	 * @param storeNumber
	 *            The store number to run the report for
	 * @param startDate
	 *            The start of the time period that you want the reports for.
	 * @param endDate
	 *            The end of the time period that you want the report for
	 * @return The list of all of the voided agreements for a store between the
	 *         2 dates
	 */
	public List<Agreement> getVoidedAgreementsBetweenTwoPeriod(final int storeNumber, final Calendar startDate,
	        final Calendar endDate) {
		return Agreement.findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(AgreementStatus.findVoided(),
		        storeNumber, startDate, endDate);
	}
}
