package com.menards.rental.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.AgreementItemStatus;
import com.menards.rental.domain.AgreementStatus;
import com.menards.rental.dto.NotReturnedItemDto;

@Repository(value = "notReturnedItemsDao")
public class NotReturnedItemsDao {
	/** The Constant reportDataQuery. */
	static final String reportDataQuery = " select new com.menards.rental.dto.NotReturnedItemDto "
	        + "(agreement.store.storeNumber, agreement.agreementNumber,  product.skuInfo.baseSKU.value , "
	        + " product.description, item.serialNumber, agreement.rentalDate, agreementItem.chargeInfo.dueBy, agreement.overallComment) "
	        + " from Agreement as agreement, AgreementItem agreementItem, Item item, Product product " + " where "
	        + " agreementItem.agreement = agreement and " + " agreementItem.item = item and "
	        + " item.product = product and " 
	        + " agreement.agreementStatus = :agreementStatus and agreementItem.status = :checkedOutAndPaidInitial and "
	        + " agreementItem.chargeInfo.dueBy <= current_timestamp() " + " group by agreement.agreementNumber ";

	/**
	 * This returns the list of Rentals that have not been returned
	 * and the agreement is in active state.
	 *
	 * @return The NotReturnedItems for all stores
	 */
	public List<NotReturnedItemDto> getNotReturnedItemDtoReport() {
		final EntityManager em = AgreementItem.entityManager();
		final Query query = em.createQuery(reportDataQuery);
		query.setParameter("agreementStatus", AgreementStatus.findActive());
		query.setParameter("checkedOutAndPaidInitial", AgreementItemStatus.findCheckedOutAndPaidInitial());
		return query.getResultList();
	}
}
