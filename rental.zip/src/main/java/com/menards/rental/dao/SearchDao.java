package com.menards.rental.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Filter;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.DistinctRootEntityResultTransformer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.menards.rental.domain.Product;
import com.menards.rental.domain.RentalSKU;
import com.menards.rental.utils.Constants;

/**
 * The class that encapsulates the logic to search products based on the base sku value and return items for the
 * current store only.
 *
 * @author deep
 */
@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class SearchDao {

    /**
     * Returns the matching products for the given store for the given base sku search criteria.
     * @param storeNumber the store number whose Items we are interested in.
     * @param baseSKU the base sku value that we want to search.
     * @return list of products matching the search criteria.
     */
    public List<Product> getAllMatchingProductsForStore(final Integer storeNumber, final RentalSKU baseSKU) {
        final Session session = (Session) Product.entityManager().getDelegate();
        final Filter filter = session.enableFilter("currentStoreItems");
        filter.setParameter("storeNumber", storeNumber);
        final Criteria criteria = session.createCriteria(Product.class);
        criteria.setFetchMode("items", FetchMode.JOIN);
        criteria.setResultTransformer(DistinctRootEntityResultTransformer.INSTANCE);
        if (baseSKU == null) {
            return criteria.list();
        }

        final Criteria baseSKUCriteria = criteria.createCriteria("skuInfo.baseSKU");
        if (null != baseSKU.getValue()) {
            baseSKUCriteria.add(Restrictions.sqlRestriction("concat('', {alias}.sku) like ?", Constants.Dao.LIKE_PRE_POST_FIX
                    + baseSKU.getValue() + Constants.Dao.LIKE_PRE_POST_FIX, Hibernate.STRING));
        }
        if ((null != baseSKU.getDescription())
                && (!Constants.Action.EMPTY_STRING.equals(baseSKU.getDescription().trim()))) {
            baseSKUCriteria.add(Restrictions.ilike("description", Constants.Dao.LIKE_PRE_POST_FIX
                    + baseSKU.getDescription() + Constants.Dao.LIKE_PRE_POST_FIX));
        }
        return criteria.list();
    }
}
