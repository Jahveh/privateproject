/*
 * NotRecalledAtRegisterRentalsDao.java
 */
package com.menards.rental.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.menards.rental.domain.AgreementCollection;
import org.springframework.stereotype.Repository;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementStatus;

/**
 * Handles getting all of the Agreements that were cancelled before being
 * recalled at the register.
 */
@Repository(value = "notRecalledAtRegisterRentalsDao")
public class NotRecalledAtRegisterRentalsDao {

	/**
	 * Fetches the report that were cancelled for a given store and time period
	 * 
	 * <em>where time period = [startDate, endDate] inclusive and startDate < endDate</em>.
	 *
	 * @param storeNumber The store number of the store that you want to get the
	 * agreements for.
	 * @param startDate The start of the time period that you want the reports for.
	 * @param endDate The end of the time period that you want the report for
	 * @return The found agreements that were canceled.
	 */
	public List<Agreement> getNotRecalledAtRegisterRentalsForATimePeriod(final Integer storeNumber,
	        final Calendar startDate, final Calendar endDate) {
        final List<Agreement> notRecalledAgreements = new ArrayList<Agreement>();
        notRecalledAgreements.addAll(Agreement
                .findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(AgreementStatus.findCancelled(),
                        storeNumber, startDate, endDate));
        final List<Agreement> activeAgreements = Agreement
                .findAgreementsByAgreementStatusAndStoreNumberForATimePeriod(AgreementStatus.findActive(),
                        storeNumber, startDate, endDate);
        notRecalledAgreements.addAll(new AgreementCollection(activeAgreements).findAgreementsThatHaveReturnedItems());
        return notRecalledAgreements;
	}
}
