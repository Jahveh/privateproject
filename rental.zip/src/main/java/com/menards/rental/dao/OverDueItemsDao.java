/*
 * OverDueItemsDao.java
 */
package com.menards.rental.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.AgreementItemStatus;
import com.menards.rental.domain.AgreementStatus;
import com.menards.rental.domain.OverdueNotificationTimes;
import com.menards.rental.dto.OverDueItemDto;

/**
 * Handles getting items that are overdue for the Overdue Items report.
 */
@Repository(value = "overDueItemsDao")
public class OverDueItemsDao {
	
	
	/** The Constant reportDataQuery. */
	static final String reportDataQuery = " select new com.menards.rental.dto.OverDueItemDto "
	        + "(agreement.agreementNumber,  product.skuInfo.baseSKU.value , "
	        + " product.description, item.serialNumber, agreement.rentalDate, agreementItem.chargeInfo.dueBy) "
	        + " from Agreement as agreement, AgreementItem agreementItem, Item item, Product product where "
	        + " agreementItem.agreement = agreement and agreementItem.item = item and "
	        + " item.product = product and agreement.store.storeNumber = :storeNumber and  "
	        + " agreement.agreementStatus = :agreementStatus and agreementItem.status = :checkedOutAndPaidInitial and "
	        + " agreementItem.chargeInfo.dueBy <= current_timestamp() " + " group by agreement.agreementNumber ";

	/**
	 * This returns the list of Rentals who have past their estimated return
	 * time and the agreement is in active state.
	 *
	 * @param storeNumber The store number of the store to run the report for
	 * @return The OverDueItems for the given store
	 */
	public List<OverDueItemDto> getOverDueItemDtoReport(final Integer storeNumber) {
		final EntityManager em = AgreementItem.entityManager();
		final Query query = em.createQuery(reportDataQuery);
		query.setParameter("storeNumber", storeNumber);
		query.setParameter("checkedOutAndPaidInitial", AgreementItemStatus.findCheckedOutAndPaidInitial());
		query.setParameter("agreementStatus", AgreementStatus.findActive());
		return query.getResultList();
	}
	
	public List<OverdueNotificationTimes> getNotificationTimes(String agreementNumber){
		final EntityManager em = AgreementItem.entityManager();
		final String queryStr = "from OverdueNotificationTimes overdueNotificationTimes "
				+ "where overdueNotificationTimes.agreementNumber = :agreementNumber";
		Query query = em.createQuery(queryStr);
		query.setParameter("agreementNumber", agreementNumber);
		return query.getResultList();
	}
	
	@Transactional
	public void recordNotificationTimes(OverdueNotificationTimes overdueNotificationTimes){
		final EntityManager em = AgreementItem.entityManager();
		em.persist(overdueNotificationTimes);
	}
	
	@Transactional
	public void updateNotificationTimes(OverdueNotificationTimes overdueNotificationTimes){
		final EntityManager em = AgreementItem.entityManager();
		em.merge(overdueNotificationTimes);
		em.flush();
	}
}
