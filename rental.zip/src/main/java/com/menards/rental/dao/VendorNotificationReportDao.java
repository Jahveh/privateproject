/*
 * VendorNotificationReportDao.java
 */
package com.menards.rental.dao;

import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.menards.rental.domain.Product;
import org.springframework.stereotype.Repository;

import com.menards.rental.domain.AgreementItem;
import com.menards.rental.dto.VendorNotificationReportDto;

/**
 * Gets the list of vendor notification report dto.  The vendo notification report is run for the given start and end
 * time and for a given product.
 * @author deep
 */
@Repository(value = "vendorNotificationReportDao")
public class VendorNotificationReportDao {

	/** The Constant reportDataQuery. */
	static final String reportDataQuery = "select new com.menards.rental.dto.VendorNotificationReportDto("
	        + "guest.firstName, guest.address.line, guest.address.city, guest.address.state,"
	        + "guest.address.zipCode, guest.email, guest.phoneNumber,'', item.storeNumber,"
	        + "agreementItem.chargeInfo.checkoutDate, agreementItem.chargeInfo.checkinDate,"
	        + "item.serialNumber, item.usageNumber) from AgreementItem as agreementItem "
	        + "join AgreementItem.agreement as agreement join agreement.guest as guest "
	        + "join agreementItem.item as item join item.product as product "
            + "where product = :product and agreementItem.status.id > 1 and "
            + "agreementItem.chargeInfo.checkoutDate between :startDate and :endDate "
            + "order by agreementItem.chargeInfo.checkoutDate";

	/**
	 * Gets the vendor notification report data.
	 *
	 * @return the vendor notification report data
     * @param startDate the date from which we need to generate the report.
     * @param endDate the date till which we need to generate the report.
     * @param product the product for which we need to find the data.
	 */
	public List<VendorNotificationReportDto> getVendorNotificationReportData(final Calendar startDate,
                                                                             final Calendar endDate,
                                                                             final Product product) {
		final EntityManager em = AgreementItem.entityManager();
		final Query query = em.createQuery(reportDataQuery);
        query.setParameter("startDate", startDate);
        query.setParameter("endDate", endDate);
        query.setParameter("product", product);
		return query.getResultList();
	}
}
