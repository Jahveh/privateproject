/**
 * ArchivedAgreementDataDao.java
 */
package com.menards.rental.dao;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.menards.rental.domain.ArchivedAgreement;
import com.menards.rental.domain.ArchivedAgreementData;

/**
 * The dao to get data from the archived agreement.
 *
 * @author deep
 */
@Component
public class ArchivedAgreementDataDao {

    /** The logger. */
    private static final Logger logger = Logger.getLogger(ArchivedAgreementDataDao.class);

    /** The session factory reference. */
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * The method that gets the archived data for the given archived agreement id.
     * @param archivedAgreementId the agreement id whose archive data is to be returned.
     * @return the ArvhicedAgreementData value.
     */
    public ArchivedAgreementData getArchiveDataFor(final Long archivedAgreementId) {
        final Session session = sessionFactory.openSession();
        try {
            session.beginTransaction();
            return (ArchivedAgreementData) session
                    .createCriteria(ArchivedAgreementData.class)
                    .add(Restrictions.eq("archivedAgreementId", archivedAgreementId))
                    .uniqueResult();
        } finally {
            session.getTransaction().commit();
            session.close();
        }
    }

    /**
     * Creates the arvhiced agreement data for the given archived agreement with the given data.
     * @param agreement the agreement for which the archive is to be created.
     * @param archiveData the data using which the archive is to be created.
     */
    public void createArchiveData(final ArchivedAgreement agreement,
                                  final byte[] archiveData) {
        final Session session = sessionFactory.openSession();
        try {
            session.beginTransaction();
            final ArchivedAgreementData archived = new ArchivedAgreementData(agreement.getId(),  archiveData);
            session.save(archived);
        } finally {
            session.getTransaction().commit();
            session.close();
        }

    }

    /**
     * The method that updates the archive with the passed in information.
     * @param archivedAgreement the agreement that is to be updated.
     * @param archiveData the archive data with which the information is to be updated.
     */
    public void updateArchiveData(final ArchivedAgreement archivedAgreement, final byte[] archiveData) {
        final Session session = sessionFactory.openSession();
        try {
            session.beginTransaction();
            final ArchivedAgreementData archivedAgreementData = (ArchivedAgreementData) session
                    .createCriteria(ArchivedAgreementData.class)
                    .add(Restrictions.eq("archivedAgreementId", archivedAgreement.getId()))
                    .uniqueResult();
            archivedAgreementData.setData(archiveData);
            session.update(archivedAgreementData);
        } finally {
            session.getTransaction().commit();
            session.close();
        }
    }

    /**
     * Should remove the archive data for the given archived areement.
     * @param archivedAgreement the archived agreement whose data has to be removed.
     */
    public void removeArchiveData(final ArchivedAgreement archivedAgreement) {
        final Session session = sessionFactory.openSession();
        try {
            session.beginTransaction();
            final ArchivedAgreementData archivedAgreementData = (ArchivedAgreementData) session
                    .createCriteria(ArchivedAgreementData.class)
                    .add(Restrictions.eq("archivedAgreementId", archivedAgreement.getId()))
                    .uniqueResult();
            session.delete(archivedAgreementData);
        } finally {
            session.getTransaction().commit();
            session.close();
        }
    }
}
