package com.menards.rental.dto;

import java.io.Serializable;

public class QuestionFollowUpDto implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer questionId;
	private Integer questionTypeId;
	private Integer questionCategoryId;
	private Integer questionFollowUpTypeId;
	private String followUpTrigger;
	private String followUpContent;
	public Integer getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public Integer getQuestionTypeId() {
		return questionTypeId;
	}
	public void setQuestionTypeId(Integer questionTypeId) {
		this.questionTypeId = questionTypeId;
	}
	public Integer getQuestionCategoryId() {
		return questionCategoryId;
	}
	public void setQuestionCategoryId(Integer questionCategoryId) {
		this.questionCategoryId = questionCategoryId;
	}
	public Integer getQuestionFollowUpTypeId() {
		return questionFollowUpTypeId;
	}
	public void setQuestionFollowUpTypeId(Integer questionFollowUpTypeId) {
		this.questionFollowUpTypeId = questionFollowUpTypeId;
	}
	public String getFollowUpTrigger() {
		return followUpTrigger;
	}
	public void setFollowUpTrigger(String followUpTrigger) {
		this.followUpTrigger = followUpTrigger;
	}
	public String getFollowUpContent() {
		return followUpContent;
	}
	public void setFollowUpContent(String followUpContent) {
		this.followUpContent = followUpContent;
	}
	

}
