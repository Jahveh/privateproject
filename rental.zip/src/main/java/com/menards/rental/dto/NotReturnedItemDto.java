package com.menards.rental.dto;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.menards.rental.utils.Constants;

public class NotReturnedItemDto {

	/** The rental item store number */
	private int storeNumber;
	
	/** The agreement number. */
	private String agreementNumber;

	/** The sku value. */
	private Long skuValue;

	/** The product description. */
	private String productDescription;

	/** The item serial number. */
	private Long itemSerialNumber;

	/** The rental agreement date. */
	private Calendar rentalAgreementDate;

	/** The rental item due date. */
	private Calendar rentalItemDueDate;
	
	/** The rental item notes. */
	private String agreementNotes;

	/**
	 * Instantiates a new not returned rental item dto.
	 *
	 * @param storeNumber store where the agreement was made
	 * @param agreementNumber the agreement number
	 * @param skuValue the sku value
	 * @param productDescription the product description
	 * @param itemSerialNumber the item serial number
	 * @param rentalAgreementDate the rental agreement date
	 * @param rentalItemDueDate the rental item due date
	 * @param agreementNotes the rental item notes
	 */
	public NotReturnedItemDto(final int storeNumber, final String agreementNumber,
			final Long skuValue, final String productDescription, final Long itemSerialNumber, 
			final Calendar rentalAgreementDate, final Calendar rentalItemDueDate, final String agreementNotes) {
		this.storeNumber = storeNumber;
		this.agreementNumber = agreementNumber;
		this.skuValue = skuValue;
		this.productDescription = productDescription;
		this.itemSerialNumber = itemSerialNumber;
		this.rentalAgreementDate = rentalAgreementDate;
		this.rentalItemDueDate = rentalItemDueDate;
		this.agreementNotes = agreementNotes;
	}

	/**
	 * Gets the headers.
	 *
	 * @return the headers
	 */
	public static String[] getHeaders() {
		return new String[] {"Store Number","Agreement Number","SKU","Description","Serial Number",
				"Agreement Date","Due Date","Notes"};
	}
	/**
	 * Gets the properties.
	 *
	 * @return the properties
	 */
	public static String[] getProperties() {
		return new String[] {"storeNumber","agreementNumber","skuValue","productDescription","ItemSerialAsString",
				"RentalDateForExport","RentalItemDueDateForExport","agreementNotes" };
	}
	
	/**
	 * Returns the serial number of the item as a string.
	 * Done to prevent serial number from turning to 
	 * scientific notation in excel (currently not solving that).
	 * 
	 * Mainly to be used by the report creator since you could just toString the long
	 * anywhere else.
	 * 
	 * @return itemSerialNumber as a string
	 */
	public String getItemSerialAsString()
	{
		if(null == itemSerialNumber)
		{
			return "";
		}
		return itemSerialNumber.toString();
	}
	
	/**
	 * Gets the date rented for export.
	 *
	 * @return the date rented for export
	 */
	public String getRentalDateForExport() {
		if (null == rentalAgreementDate) {
			return "";
		}

		return new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT).format(rentalAgreementDate.getTime());
	}
	
	/**
	 * Gets the due date for export.
	 *
	 * @return the date rented for export
	 */
	public String getRentalItemDueDateForExport() {
		if (null == rentalItemDueDate) {
			return "";
		}

		return new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT).format(rentalItemDueDate.getTime());
	}
	
	/**
	 * Gets the agreement number.
	 *
	 * @return the agreement number
	 */
	public String getAgreementNumber() {
		return agreementNumber;
	}

	/**
	 * Gets the item serial number.
	 *
	 * @return the item serial number
	 */
	public Long getItemSerialNumber() {
		return itemSerialNumber;
	}

	/**
	 * Gets the product description.
	 *
	 * @return the product description
	 */
	public String getProductDescription() {
		return productDescription;
	}

	/**
	 * Gets the rental agreement date.
	 *
	 * @return the rental agreement date
	 */
	public Calendar getRentalAgreementDate() {
		return rentalAgreementDate;
	}

	/**
	 * Gets the rental agreement date as text.
	 *
	 * @return the rental agreement date as text
	 */
	public String getRentalAgreementDateAsText() {
		if (null == rentalAgreementDate) {
			return "";
		}
		return new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT).format(rentalAgreementDate.getTime());
	}

	/**
	 * Gets the rental item due date.
	 *
	 * @return the rental item due date
	 */
	public Calendar getRentalItemDueDate() {
		return rentalItemDueDate;
	}

	/**
	 * Gets the rental item due date as text.
	 *
	 * @return the rental item due date as text
	 */
	public String getRentalItemDueDateAsText() {
		if (null == rentalItemDueDate) {
			return "";
		}
		return new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT).format(rentalItemDueDate.getTime());
	}

	/**
	 * Gets the sku value.
	 *
	 * @return the sku value
	 */
	public Long getSkuValue() {
		return skuValue;
	}

	/**
	 * Sets the agreement number.
	 *
	 * @param agreementNumber the new agreement number
	 */
	public void setAgreementNumber(final String agreementNumber) {
		this.agreementNumber = agreementNumber;
	}

	/**
	 * Sets the item serial number.
	 *
	 * @param itemSerialNumber the new item serial number
	 */
	public void setItemSerialNumber(final Long itemSerialNumber) {
		this.itemSerialNumber = itemSerialNumber;
	}

	/**
	 * Sets the product description.
	 *
	 * @param productDescription the new product description
	 */
	public void setProductDescription(final String productDescription) {
		this.productDescription = productDescription;
	}

	/**
	 * Sets the rental agreement date.
	 *
	 * @param rentalAgreementDate the new rental agreement date
	 */
	public void setRentalAgreementDate(final Calendar rentalAgreementDate) {
		this.rentalAgreementDate = rentalAgreementDate;
	}

	/**
	 * Sets the rental item due date.
	 *
	 * @param rentalItemDueDate the new rental item due date
	 */
	public void setRentalItemDueDate(final Calendar rentalItemDueDate) {
		this.rentalItemDueDate = rentalItemDueDate;
	}

	/**
	 * Sets the sku value.
	 *
	 * @param skuValue the new sku value
	 */
	public void setSkuValue(final Long skuValue) {
		this.skuValue = skuValue;
	}

	/**
	 * Gets the store number.
	 * @return storeNumber the new store number
	 */
	public int getStoreNumber() {
		return storeNumber;
	}

	/**
	 * Set the rental store number.
	 * 
	 * @param storeNumber
	 */
	public void setStoreNumber(final int storeNumber) {
		this.storeNumber = storeNumber;
	}

	public String getAgreementNotes() {
		if (agreementNotes == null) {
			return "";
		}
		return agreementNotes;
	}

	/**
	 * Set the rental agreement notes
	 * 
	 * @param agreementNotes
	 */
	public void setAgreementNotes(final String agreementNotes) {
		this.agreementNotes = agreementNotes;
	}
}
