/*
 * VendorNotificationReportDto.java
 */
package com.menards.rental.dto;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.menards.rental.utils.Constants;

/**
 * The Dto that is used while creating the vendor notification report.
 * @author deep
 */
public class VendorNotificationReportDto {

	/** The name. */
	private final String name;

	/** The address. */
	private final String address;

	/** The city. */
	private final String city;

	/** The state. */
	private final String state;

	/** The zip. */
	private final String zip;

	/** The email address. */
	private final String emailAddress;

	/** The home phone. */
	private final String homePhone;

	/** The cell phone. */
	private final String cellPhone;

	/** The store number. */
	private final Integer storeNumber;

	/** The date rented. */
	private final Calendar dateRented;

	/** The date returned. */
	private final Calendar dateReturned;

	/** The serial number. */
	private final Long serialNumber;

	/** The hour meter. */
	private final BigDecimal hourMeter;

	/**
	 * Instantiates a new vendor notification report dto.
	 *
	 * @param name the name
	 * @param address the address
	 * @param city the city
	 * @param state the state
	 * @param zip the zip
	 * @param emailAddress the email address
	 * @param homePhone the home phone
	 * @param cellPhone the cell phone
	 * @param storeNumber the store number
	 * @param dateRented the date rented
	 * @param dateReturned the date returned
	 * @param serialNumber the serial number
	 * @param hourMeter the hour meter
	 */
	public VendorNotificationReportDto(final String name, final String address, final String city,
	        final String state, final String zip, final String emailAddress, final String homePhone,
	        final String cellPhone, final Integer storeNumber, final Calendar dateRented,
	        final Calendar dateReturned, final Long serialNumber, final BigDecimal hourMeter) {

		this.name = name;
		this.address = address;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.emailAddress = emailAddress;
		this.homePhone = homePhone;
		this.cellPhone = cellPhone;
		this.storeNumber = storeNumber;
		this.dateRented = dateRented;
		this.dateReturned = dateReturned;
		this.serialNumber = serialNumber;
		this.hourMeter = hourMeter;
	}

	/**
	 * Gets the headers.
	 *
	 * @return the headers
	 */
	public static String[] getHeaders() {
		return new String[] {"Name", "Address", "City", "State", "Zip", "Email Address", "Home Phone", "Cell Phone",
		        "Store Number", "Date Rented", "Date Returned", "Serial Number", "Hour Meter" };
	}

	/**
	 * Gets the properties.
	 *
	 * @return the properties
	 */
	public static String[] getProperties() {
		return new String[] {"name", "address", "city", "state", "zip", "emailAddress", "homePhone", "cellPhone",
		        "storeNumber", "dateRentedForExport", "dateReturnedForExport", "serialNumber", "hourMeter" };
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Gets the cell phone.
	 *
	 * @return the cell phone
	 */
	public String getCellPhone() {
		return cellPhone;
	}

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Gets the date rented.
	 *
	 * @return the date rented
	 */
	public Calendar getDateRented() {
		return dateRented;
	}

	/**
	 * Gets the date rented for export.
	 *
	 * @return the date rented for export
	 */
	public String getDateRentedForExport() {
		if (null == dateRented) {
			return "";
		}

		return new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT).format(dateRented.getTime());
	}

	/**
	 * Gets the date returned.
	 *
	 * @return the date returned
	 */
	public Calendar getDateReturned() {
		return dateReturned;
	}

	/**
	 * Gets the date returned for export.
	 *
	 * @return the date returned for export
	 */
	public String getDateReturnedForExport() {
		if (null == dateReturned) {
			return "";
		}

		return new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT).format(dateReturned.getTime());
	}

	/**
	 * Gets the email address.
	 *
	 * @return the email address
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * Gets the home phone.
	 *
	 * @return the home phone
	 */
	public String getHomePhone() {
		return homePhone;
	}

	/**
	 * Gets the hour meter.
	 *
	 * @return the hour meter
	 */
	public BigDecimal getHourMeter() {
		return hourMeter;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Gets the serial number.
	 *
	 * @return the serial number
	 */
	public Long getSerialNumber() {
		return serialNumber;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * Gets the store number.
	 *
	 * @return the store number
	 */
	public Integer getStoreNumber() {
		return storeNumber;
	}

	/**
	 * Gets the zip.
	 *
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}
}
