package com.menards.rental.dto;

import java.io.Serializable;

public class QuestionAnswerDto implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer rentalAgreementId;
	private Integer questionTypeId;
	private Integer questionId;
	private Long itemSerialNumber;
	private String answerText;
	
	public Long getItemSerialNumber() {
		return itemSerialNumber;
	}
	public void setItemSerialNumber(Long itemSerialNumber) {
		this.itemSerialNumber = itemSerialNumber;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getRentalAgreementId() {
		return rentalAgreementId;
	}
	public void setRentalAgreementId(Integer rentalAgreementId) {
		this.rentalAgreementId = rentalAgreementId;
	}
	public Integer getQuestionTypeId() {
		return questionTypeId;
	}
	public void setQuestionTypeId(Integer questionTypeId) {
		this.questionTypeId = questionTypeId;
	}
	public Integer getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public String getAnswerText() {
		return answerText;
	}
	public void setAnswerText(String answerText) {
		this.answerText = answerText;
	}
	
		
}
