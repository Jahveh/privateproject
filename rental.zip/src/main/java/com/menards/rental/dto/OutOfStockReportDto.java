/*
 * OutOfStockReportDto.java
 */
package com.menards.rental.dto;

import java.text.DecimalFormat;

/**
 * The Class Out of  stock data transfer object.
 * @author deep
 */
public class OutOfStockReportDto {

	/** The store number. */
	private final int storeNumber;

	/** The sku value. */
	private final long skuValue;

	/** The sku description. */
	private final String skuDescription;

	/** The percentage out of stock. */
	private double percentageOutOfStock;

	/**
	 * Instantiates a new out of stock report dto.
	 *
	 * @param storeNumber the store number
	 * @param skuValue the sku value
	 * @param skuDescription the sku description
	 */
	public OutOfStockReportDto(final int storeNumber, final long skuValue, final String skuDescription) {
		this.storeNumber = storeNumber;
		this.skuValue = skuValue;
		this.skuDescription = skuDescription;
	}

	/**
	 * Gets the headers.
	 *
	 * @return the headers
	 */
	public static String[] getHeaders() {
		return new String[] {"Store Number", "SKU Number", "SKU Description", "Percentage Out of Stock" };
	}

	/**
	 * Gets the properties.
	 *
	 * @return the properties
	 */
	public static String[] getProperties() {
		return new String[] {"storeNumber", "skuValue", "skuDescription", "percentageOutOfStock" };
	}

	/**
	 * Gets the percentage out of stock.
	 *
	 * @return the percentage out of stock
	 */
	public String getPercentageOutOfStock() {
		final DecimalFormat format = new DecimalFormat("#0.00");
		return format.format(percentageOutOfStock);
	}

    /**
     * Getter for the out of stock percentage value.
     * @return the double value representing the out of stock percentage.
     */
    public double getPercentageOutOfStockValue() {
        return percentageOutOfStock;
    }

	/**
	 * Gets the sku description.
	 *
	 * @return the sku description
	 */
	public String getSkuDescription() {
		return skuDescription;
	}

	/**
	 * Gets the sku value.
	 *
	 * @return the sku value
	 */
	public long getSkuValue() {
		return skuValue;
	}

	/**
	 * Gets the store number.
	 *
	 * @return the store number
	 */
	public int getStoreNumber() {
		return storeNumber;
	}

	/**
	 * Sets the percentage out of stock.
	 *
	 * @param percentageOutOfStock the new percentage out of stock
	 */
	public void setPercentageOutOfStock(final double percentageOutOfStock) {
		this.percentageOutOfStock = percentageOutOfStock;
	}

}
