package com.menards.rental.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class QuestionDto implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer questionId;
	private String questionText;
	private Long itemSerialNumber;
	private Integer answerTypeId;
	private String answer;
	private BigDecimal extraCharge = new BigDecimal(0.0d);
	private BigDecimal oldExtraCharge = new BigDecimal(0.0d);
	private String emailMessage;
	private QuestionFollowUpDto questionFollowUpDto;
	
	public Long getItemSerialNumber() {
		return itemSerialNumber;
	}
	public void setItemSerialNumber(Long itemSerialNumber) {
		this.itemSerialNumber = itemSerialNumber;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public String getQuestionText() {
		return questionText;
	}
	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}
	public Integer getAnswerTypeId() {
		return answerTypeId;
	}
	public void setAnswerTypeId(Integer answerTypeId) {
		this.answerTypeId = answerTypeId;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public QuestionFollowUpDto getQuestionFollowUpDto() {
		return questionFollowUpDto;
	}
	public void setQuestionFollowUpDto(QuestionFollowUpDto questionFollowUpDto) {
		this.questionFollowUpDto = questionFollowUpDto;
	}
	public BigDecimal getExtraCharge() {
		return extraCharge;
	}
	public void setExtraCharge(BigDecimal extraCharge) {
		this.extraCharge = extraCharge;
	}
	public String getEmailMessage() {
		return emailMessage;
	}
	public void setEmailMessage(String emailMessage) {
		this.emailMessage = emailMessage;
	}
	public BigDecimal getOldExtraCharge() {
		return oldExtraCharge;
	}
	public void setOldExtraCharge(BigDecimal oldExtraCharge) {
		this.oldExtraCharge = oldExtraCharge;
	}
	
	
	
}
