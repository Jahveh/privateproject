/**
 * AgreementsCancelledNotificationReportCreator.java
 */
package com.menards.rental.report;

import com.menards.rental.domain.Report;
import com.menards.rental.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

/**
 * The calss that is responsible for creating and sending agreements cancelled notification report.
 *
 * @author deep
 */
@Component
public class AgreementsCancelledNotificationReportCreator extends BaseReportCreator {

    /**
     * The report formatter.
     */
    @Autowired
    @Qualifier("velocityReportFormatter")
    private ReportFormatter<String> reportFormatter;

    /**
     * The default constructor.
     */
    public AgreementsCancelledNotificationReportCreator()  {
        super(Report.Type.AGREEMENTS_CANCELLED_NOTIFICATION_REPORT);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected ReportFormatter<String> getFormatter(final Report report) {
        return reportFormatter;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void populateReportDataInModel(final Report report, final Map<String, Object> modelMap) {
        final Calendar currentDate = Calendar.getInstance();

        final SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_FORMAT);
        final SimpleDateFormat timeformat = new SimpleDateFormat(Constants.DateFormat.TIME_FORMAT);

        modelMap.put(Constants.ReportPublisher.CURRENT_DATE, sdf.format(currentDate.getTime()));
        modelMap.put(Constants.ReportPublisher.CURRENT_TIME, timeformat.format(currentDate.getTime()));
    }
}
