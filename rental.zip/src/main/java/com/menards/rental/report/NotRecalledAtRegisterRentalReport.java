/*
 * NotRecalledAtRegisterRentalReport.java
 */
package com.menards.rental.report;

import com.menards.rental.dao.NotRecalledAtRegisterRentalsDao;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.Report;
import com.menards.rental.domain.Store;
import com.menards.rental.service.MenardsService;
import com.menards.rental.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * The Class NotRecalledAtRegisterRentalReport which is responsible for generating the not recalled ar register rental
 * report.
 * @author deep
 */
@Component(value = "notRecalledAtRegisterRentalReport")
public class NotRecalledAtRegisterRentalReport extends BaseReportCreator {

    /**
     * The not recalled at register rentals dao.
     */
    @Autowired
    private NotRecalledAtRegisterRentalsDao notRecalledAtRegisterRentalsDao;

    /**
     * The report formatter.
     */
    @Autowired
    @Qualifier("velocityReportFormatter")
    private ReportFormatter<String> reportFormatter;

    /**
     * The menards service.
     */
    @Autowired
    private MenardsService menardsService;

    /**
     * The default constructor.
     */
    public NotRecalledAtRegisterRentalReport() {
        super(Report.Type.NOT_RECALLED_AT_REGISTER_REPORT);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected ReportFormatter<String> getFormatter(final Report report) {
        return reportFormatter;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void populateReportDataInModel(final Report report, final Map<String, Object> modelMap) {
        final Calendar startTime = Calendar.getInstance();
        // Move the time back by 24 hours
        startTime.add(Calendar.HOUR_OF_DAY, -24);
        final Calendar currentDate = Calendar.getInstance();

        final List<Agreement> notRecalledAgreements = notRecalledAtRegisterRentalsDao
                .getNotRecalledAtRegisterRentalsForATimePeriod(report.getStoreNumber(), startTime, currentDate);

        final Store store = menardsService.getStoreByStoreNumber(report.getStoreNumber());

        final SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT);

        modelMap.put(Constants.ReportPublisher.CURRENT_DATE, sdf.format(currentDate.getTime()));
        modelMap.put(Constants.Report.STORE_KEY, store);
        modelMap.put(Constants.Report.REPORT_DATA_KEY, notRecalledAgreements);
        modelMap.put(Constants.Report.IS_EMPTY_KEY, notRecalledAgreements.isEmpty());
    }

    /**
     * Sets the menards service.
     *
     * @param menardsService the new menards service
     */
    public void setMenardsService(final MenardsService menardsService) {
        this.menardsService = menardsService;
	}

    /**
     * Sets the report formatter.
     *
     * @param reportFormatter the new report formatter
     */
    public void setReportFormatter(final ReportFormatter<String> reportFormatter) {
        this.reportFormatter = reportFormatter;
    }

    /**
     * Sets the notRecalledAtRegisterRentalsDao.
     *
     * @param notRecalledAtRegisterRentalsDao
     *         the new void rental report dao
     */
    public void setNotRecalledAtRegisterRentalsDao(
            final NotRecalledAtRegisterRentalsDao notRecalledAtRegisterRentalsDao) {
        this.notRecalledAtRegisterRentalsDao = notRecalledAtRegisterRentalsDao;
    }
}
