/*
 * OverdueRentalReportCreator.java
 */
package com.menards.rental.report;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.menards.rental.dao.NotReturnedItemsDao;
import com.menards.rental.domain.Report;
import com.menards.rental.domain.Store;
import com.menards.rental.dto.NotReturnedItemDto;
import com.menards.rental.dto.VendorNotificationReportDto;
import com.menards.rental.service.MenardsService;
import com.menards.rental.utils.Constants;

/**
 * The Not returned rental report creator. This class creates and publishes the not returned rental report.
 * 
 * @author maanders
 */
@Component(value = "notReturnedRentalReportCreator")
public class NotReturnedRentalReportCreator extends BaseReportCreator
{

	/** The not returned items dao. */
	@Autowired
	private NotReturnedItemsDao NotReturnedItemsDao;

	/** The report formatter. */
	@Autowired
	@Qualifier("velocityReportFormatter")
	private ReportFormatter reportFormatter;

	/**
	 * Email address for this report. (should be set to
	 * an email group that has helpdesk in it for
	 * production.)
	 */
	@Value("${menards.mail.address.prod.support}")
	private String supportEmailAddr;

	/**
	 * The csv report formatter.
	 */
	@Autowired
	@Qualifier("csvReportFormatter")
	private ReportFormatter csvReportFormatter;

	/** The menards service. */
	@Autowired
	private MenardsService menardsService;

	/**
	 * The default constructor.
	 */
	public NotReturnedRentalReportCreator()
	{
		super(Report.Type.NOT_RETURNED_RENTAL_REPORT);
	}

	/**
	 * Sets the menards service.
	 * 
	 * @param menardsService the new menards service
	 */
	public void setMenardsService(final MenardsService menardsService)
	{
		this.menardsService = menardsService;
	}

	/**
	 * Sets the not returned items dao.
	 * 
	 * @param notReturnedItemsDao the new over due items dao
	 */
	public void setNotReturnedItemsDao(final NotReturnedItemsDao notReturnedItemsDao)
	{
		this.NotReturnedItemsDao = notReturnedItemsDao;
	}

	/**
	 * Sets the report formatter.
	 * 
	 * @param reportFormatter the new report formatter
	 */
	public void setReportFormatter(final ReportFormatter reportFormatter)
	{
		this.reportFormatter = reportFormatter;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected ReportFormatter<String> getFormatter(final Report report)
	{
		return reportFormatter;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void preEmailPublish(final Report report, final Map<String, Object> modelMap)
	{
		final SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT);
		modelMap.put(Constants.ReportPublisher.ATTACHMENT_KEY,
								((String) csvReportFormatter.format(null, modelMap)).getBytes());
		modelMap.put(Constants.ReportEmailPublisher.MAIL_TO,
						supportEmailAddr);
		modelMap.put(Constants.ReportEmailPublisher.MAIL_FROM,
								Constants.ReportEmailPublisher.FROM_MAIL_FOR_AUTOMATED_MAILS);
		modelMap.put(Constants.ReportEmailPublisher.MAIL_SUBJECT,
						Report.Type.NOT_RETURNED_RENTAL_REPORT.getDescription() + " For " + sdf.format(new Date()));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void populateReportDataInModel(final Report report, final Map<String, Object> modelMap)
	{
		final List<NotReturnedItemDto> notReturnedItems = NotReturnedItemsDao.getNotReturnedItemDtoReport();
		final SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT);

		modelMap.put(Constants.ReportPublisher.CURRENT_DATE, sdf.format(new Date()));
		modelMap.put(Constants.Report.REPORT_DATA_KEY, notReturnedItems);
		modelMap.put(Constants.Report.HEADERS_KEY, NotReturnedItemDto.getHeaders());
		modelMap.put(Constants.Report.PROPERTIES_KEY, NotReturnedItemDto.getProperties());
		modelMap.put(Constants.Report.IS_EMPTY_KEY, notReturnedItems.isEmpty());
	}
}
