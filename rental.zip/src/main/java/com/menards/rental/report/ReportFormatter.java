/*
 * ReportFormatter.java
 */
package com.menards.rental.report;

import java.util.Map;

/**
 * Interface to implement to create a new way of formatting a report.
 * @param <T> the type of the report formatter could return String or byte[]
 * @author deep
 */
public interface ReportFormatter<T> {

	/**
	 * Format the report.
	 *
	 * @param template - Template for generation of report
	 * @param model The data for the report.
	 * @return The formatted report.
	 */
	T format(String template, Map<String, Object> model);
}
