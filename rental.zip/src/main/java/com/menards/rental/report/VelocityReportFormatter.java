/*
 * VelocityReportFormatter.java
 */
package com.menards.rental.report;

import java.util.Map;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.velocity.VelocityEngineUtils;

/**
 * Format a report that is implemented as a Velocity template.
 * @author deep
 */
@Component(value = "velocityReportFormatter")
public class VelocityReportFormatter implements ReportFormatter<String> {

	/** The velocity engine. */
	@Autowired
	private VelocityEngine velocityEngine;

    /**
     * {@inheritDoc}
     */
	public String format(final String template, final Map<String, Object> model) {
		
		
		// Generate the report
		return VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
		                                       template,
		                                       model);
	}

	/**
	 * Sets the velocity engine.
	 *
	 * @param velocityEngine the new velocity engine
	 */
	public void setVelocityEngine(final VelocityEngine velocityEngine) {
		this.velocityEngine = velocityEngine;
	}
}
