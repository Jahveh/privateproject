/*
 * OutOfStockReportCreator.java
 */
package com.menards.rental.report;

import com.menards.rental.dao.OutOfStockReportDao;
import com.menards.rental.domain.Report;
import com.menards.rental.dto.OutOfStockReportDto;
import com.menards.rental.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * This class is responsible for creating the out of stock report.
 * 
 * @author deep
 */
@Component(value = "outOfStockReportCreator")
public class OutOfStockReportCreator extends BaseReportCreator
{

	/**
	 * The out of stock report dao.
	 */
	@Autowired
	private OutOfStockReportDao outOfStockReportDao;

	/**
	 * The csv report formatter.
	 */
	@Autowired
	@Qualifier("csvReportFormatter")
	private ReportFormatter<String> csvReportFormatter;

	/**
	 * The velocity report formatter.
	 */
	@Autowired
	@Qualifier("velocityReportFormatter")
	private ReportFormatter<String> velocityReportFormatter;

	/**
	 * The default constructor.
	 */
	public OutOfStockReportCreator()
	{
		super(Report.Type.OUT_OF_STOCK_REPORT);
	}

	/**
	 * Sets the csv report formatter.
	 * 
	 * @param csvReportFormatter the new csv report formatter
	 */
	public void setCsvReportFormatter(final ReportFormatter<String> csvReportFormatter)
	{
		this.csvReportFormatter = csvReportFormatter;
	}

	/**
	 * Sets the out of stock report dao.
	 * 
	 * @param outOfStockReportDao the new out of stock report dao
	 */
	public void setOutOfStockReportDao(final OutOfStockReportDao outOfStockReportDao)
	{
		this.outOfStockReportDao = outOfStockReportDao;
	}

	/**
	 * Sets the velocity report formatter.
	 * 
	 * @param velocityReportFormatter the new velocity report formatter
	 */
	public void setVelocityReportFormatter(final ReportFormatter<String> velocityReportFormatter)
	{
		this.velocityReportFormatter = velocityReportFormatter;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected ReportFormatter<String> getFormatter(final Report report)
	{
		return velocityReportFormatter;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void populateReportDataInModel(final Report report, final Map<String, Object> modelMap)
	{
		final SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT);
		Calendar cal = Calendar.getInstance();
		try
		{
			cal.setTime(sdf.parse((String) modelMap.get(Constants.Report.REPORT_START_DATE_KEY)));
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		final Calendar reportStartDate = cal;
		final Calendar reportEndDate = Calendar.getInstance();

		final List<OutOfStockReportDto> reportData = outOfStockReportDao.getOutOfStockReportData(reportStartDate,
								reportEndDate);

		modelMap.put(Constants.Report.REPORT_DATA_KEY, reportData);
		modelMap.put(Constants.Report.IS_EMPTY_KEY, reportData.isEmpty());
		modelMap.put(Constants.Report.HEADERS_KEY, OutOfStockReportDto.getHeaders());
		modelMap.put(Constants.Report.PROPERTIES_KEY, OutOfStockReportDto.getProperties());

		
		modelMap.put(Constants.ReportPublisher.CURRENT_DATE, sdf.format(new Date()));
		// Put the startDate and endDate which is the formatted date to be
		// used to display in the report
		modelMap.put(Constants.Report.START_DATE_KEY, sdf.format(reportStartDate.getTime()));
		modelMap.put(Constants.Report.END_DATE_KEY, sdf.format(reportEndDate.getTime()));

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void preEmailPublish(final Report report, final Map<String, Object> modelMap)
	{
		//Build the template file name based on the report type
		modelMap.put(Constants.ReportEmailPublisher.MAIL_FROM,
					Constants.ReportEmailPublisher.FROM_MAIL_FOR_AUTOMATED_MAILS);

		final String reportCSV = csvReportFormatter.format(null, modelMap);
		modelMap.put(Constants.ReportPublisher.ATTACHMENT_KEY,
								reportCSV.getBytes());
	}
}
