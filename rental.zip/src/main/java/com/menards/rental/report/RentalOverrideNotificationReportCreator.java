/**
 * RentalOverrideNotificationReportCreator.java
 */
package com.menards.rental.report;

import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.Report;
import com.menards.rental.domain.ReservationCollection;
import com.menards.rental.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * The class that is responsible for creating the rental override notification reports.
 *
 * @author deep
 */
@Component
public class RentalOverrideNotificationReportCreator extends BaseReportCreator {

    /** The velocity report formatter that will be used to generate the rental override notification report. */
    @Autowired
    @Qualifier("velocityReportFormatter")
    private ReportFormatter<String> reportFormatter;

    /**
     * The default constructor.
     */
    public RentalOverrideNotificationReportCreator() {
        super(Report.Type.RENTAL_OVERRIDE_NOTIFICATION_REPORT);
    }

    /**
     * The setter for the report formatter.
     * @param reportFormatter the value to set.
     */
    public void setReportFormatter(final ReportFormatter reportFormatter) {
        this.reportFormatter = reportFormatter;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected ReportFormatter<String> getFormatter(final Report report) {
        return reportFormatter;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void populateReportDataInModel(final Report report, final Map<String, Object> modelMap) {
        final AgreementItem agreementItem = (AgreementItem) modelMap.get(Constants.Report.AGREEMENT_ITEM_KEY);
        modelMap.put(Constants.NotificationService.GM_OVERRIDE_NAME, agreementItem
                .getReservationOverrideByName());
        modelMap.put(Constants.NotificationService.ITEM_DESCRIPTION, agreementItem.getDescription());
        modelMap.put(Constants.NotificationService.CHECKOUT_TIMES_CSV,
                new ReservationCollection(agreementItem
                        .getOverlappingOpenReservations()).getCSVCheckoutDates());
    }
}
