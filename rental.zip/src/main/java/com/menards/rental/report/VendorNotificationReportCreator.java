/*
 * VendorNotificationReportCreator.java
 */
package com.menards.rental.report;

import com.menards.rental.dao.VendorNotificationReportDao;
import com.menards.rental.domain.Product;
import com.menards.rental.domain.Report;
import com.menards.rental.dto.VendorNotificationReportDto;
import com.menards.rental.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * The class that is responsble for creating vendor notification reports.
 * @author deep
 */
@Component(value = "vendorNotificationReportCreator")
public class VendorNotificationReportCreator extends BaseReportCreator {

    /**
     * The vendor notification report dao.
     */
    @Autowired
    private VendorNotificationReportDao vendorNotificationReportDao;

    /**
     * The csv report formatter.
     */
    @Autowired
    @Qualifier("csvReportFormatter")
    private ReportFormatter csvReportFormatter;

    /**
     * The velocity report formatter.
     */
    @Autowired
    @Qualifier("velocityReportFormatter")
    private ReportFormatter velocityReportFormatter;

    /**
     * The default constructor.
     */
    public VendorNotificationReportCreator() {
        super(Report.Type.VENDOR_NOTIFICATION_REPORT);
    }

    /**
     * The setter for the dao.
     *
     * @param vendorNotificationReportDao the value.
     */
    public void setVendorNotificationReportDao(final VendorNotificationReportDao vendorNotificationReportDao) {
        this.vendorNotificationReportDao = vendorNotificationReportDao;
    }

    /**
     * The setter for the csv report formatter.
     *
     * @param csvReportFormatter the value.
     */
    public void setCsvReportFormatter(final ReportFormatter csvReportFormatter) {
        this.csvReportFormatter = csvReportFormatter;
    }

    /**
     * The setter for the velocity report formatter.
     *
     * @param velocityReportFormatter the value.
     */
    public void setVelocityReportFormatter(final ReportFormatter velocityReportFormatter) {
        this.velocityReportFormatter = velocityReportFormatter;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected ReportFormatter<String> getFormatter(final Report report) {
        return velocityReportFormatter;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void populateReportDataInModel(final Report report, final Map<String, Object> modelMap) {
        final List<VendorNotificationReportDto> reportData = vendorNotificationReportDao
                .getVendorNotificationReportData((Calendar) modelMap.get(Constants.Report.REPORT_START_DATE_KEY),
                        (Calendar) modelMap.get(Constants.Report.REPORT_END_DATE_KEY),
                        (Product) modelMap.get(Constants.Report.PRODUCT_KEY));

        final SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT);
        modelMap.put(Constants.ReportPublisher.CURRENT_DATE, sdf.format(new Date()));

        modelMap.put(Constants.Report.REPORT_DATA_KEY, reportData);
        modelMap.put(Constants.Report.HEADERS_KEY, VendorNotificationReportDto.getHeaders());
        modelMap.put(Constants.Report.PROPERTIES_KEY, VendorNotificationReportDto.getProperties());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void preEmailPublish(final Report report, final Map<String, Object> modelMap) {
        super.preEmailPublish(report, modelMap);
        modelMap.put(Constants.ReportPublisher.ATTACHMENT_KEY,
                ((String) csvReportFormatter.format(null, modelMap)).getBytes());
        final Product product = (Product) modelMap.get(Constants.Report.PRODUCT_KEY);
        modelMap.put(Constants.ReportEmailPublisher.MAIL_TO, product.getVendorEmail());
    }
}
