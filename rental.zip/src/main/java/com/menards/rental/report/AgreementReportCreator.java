/**
 * AgreementReportCreator.java
 */
package com.menards.rental.report;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.Report;
import com.menards.rental.service.archive.PDFArchiver;
import com.menards.rental.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * The report creator for the agreement reports.
 *
 * @author deep
 */
@Component
public class AgreementReportCreator extends BaseReportCreator {
    /**
     * The report formatter.
     */
    @Autowired
    @Qualifier("doNothingFormatter")
    private ReportFormatter<String> reportFormatter;

    /** The pdf archiver. */
    @Autowired
    private PDFArchiver pdfArchiver;

    /**
     * The default constructor.
     */
    public AgreementReportCreator() {
        super(Report.Type.AGREEMENT_REPORT);
    }

    /**
     * The setter for the pdf archiver.
     * @param pdfArchiver the value to set.
     */
    public void setPDFArchiver(final PDFArchiver pdfArchiver) {
        this.pdfArchiver = pdfArchiver;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected ReportFormatter<String> getFormatter(final Report report) {
        return reportFormatter;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void populateReportDataInModel(final Report report, final Map<String, Object> modelMap) {
        final Long agreementId = (Long) modelMap.get(Constants.Report.AGREEMENT_ID_KEY);
        modelMap.put(Constants.ReportPublisher.BINARY_DATA_KEY,
                pdfArchiver.archive(Agreement.findAgreement(agreementId)));
    }
}
