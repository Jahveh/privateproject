/*
 * OverdueRentalReportCreator.java
 */
package com.menards.rental.report;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.menards.rental.dao.OverDueItemsDao;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.OverdueNotificationTimes;
import com.menards.rental.domain.Report;
import com.menards.rental.domain.Store;
import com.menards.rental.dto.OverDueItemDto;
import com.menards.rental.service.MenardsService;
import com.menards.rental.service.external.TeamService;
import com.menards.rental.utils.Constants;

/**
 * The Overdue rental report creator.  This guy is responsible for creating and publishing the overdue rental report.
 * @author deep
 */
@Component(value = "overdueRentalReportCreator")
public class OverdueRentalReportCreator extends BaseReportCreator {

	/** The over due items dao. */
	@Autowired
	private OverDueItemsDao overDueItemsDao;

	/** The report formatter. */
	@Autowired
	@Qualifier("velocityReportFormatter")
	private ReportFormatter reportFormatter;

	/** The menards service. */
	@Autowired
	private MenardsService menardsService;

    /** The team service reference. */
    @Autowired
    private TeamService teamService;
    
    /**
     * The default constructor.
     */
    public OverdueRentalReportCreator() {
        super(Report.Type.OVERDUE_RENTAL_REPORT);
    }

    /**
	 * Sets the menards service.
	 *
	 * @param menardsService the new menards service
	 */
	public void setMenardsService(final MenardsService menardsService) {
		this.menardsService = menardsService;
	}

	/**
	 * Sets the over due items dao.
	 *
	 * @param overDueItemsDao the new over due items dao
	 */
	public void setOverDueItemsDao(final OverDueItemsDao overDueItemsDao) {
		this.overDueItemsDao = overDueItemsDao;
	}

	/**
	 * Sets the report formatter.
	 *
	 * @param reportFormatter the new report formatter
	 */
	public void setReportFormatter(final ReportFormatter reportFormatter) {
		this.reportFormatter = reportFormatter;
	}

    /**
     * {@inheritDoc}
     */
    @Override
    protected ReportFormatter<String> getFormatter(final Report report) {
        return reportFormatter;
    }

    /**
     * {@inheritDoc}
     * Overriding method to populate custom senders and receivers. Here with the General Managers and Front End Managers.
     * @param report the report for which we have to do the pre email publish tasks.
     * @param modelMap the values are populate in the model.
     */
    @Override
    protected void preEmailPublish(final Report report, final Map<String, Object> modelMap) {
        modelMap.put(Constants.ReportEmailPublisher.MAIL_TO,
                teamService.getFrontEndManagerEmailFor(report.getStoreNumber()));
        modelMap.put(Constants.ReportEmailPublisher.MAIL_FROM,
                Constants.ReportEmailPublisher.FROM_MAIL_FOR_AUTOMATED_MAILS);
    }    
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected void populateReportDataInModel(final Report report, final Map<String, Object> modelMap) {
        final List<OverDueItemDto> overDueItems = overDueItemsDao.getOverDueItemDtoReport(report.getStoreNumber());
        for(OverDueItemDto overDueItemDto : overDueItems){
        	List<OverdueNotificationTimes> OverdueNotificationTimesList = overDueItemsDao.getNotificationTimes(overDueItemDto.getAgreementNumber());
        	if(OverdueNotificationTimesList.size() > 0) {
        		OverdueNotificationTimes times = OverdueNotificationTimesList.get(0);
				int notificationTimes = times.getTimes();
				notificationTimes++;
				times.setTimes(notificationTimes);
				overDueItemsDao.updateNotificationTimes(times);
        	}else {
        		OverdueNotificationTimes newTimes = new OverdueNotificationTimes();
				newTimes.setAgreementNumber(overDueItemDto.getAgreementNumber());
				newTimes.setTimes(1);
				overDueItemsDao.recordNotificationTimes(newTimes);
			}
        }
		final Store store = menardsService.getStoreByStoreNumber(report.getStoreNumber());

		final SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT);
		modelMap.put(Constants.ReportPublisher.CURRENT_DATE, sdf.format(new Date()));

		modelMap.put(Constants.Report.STORE_KEY, store);
		modelMap.put(Constants.Report.REPORT_DATA_KEY, overDueItems);
		modelMap.put(Constants.Report.IS_EMPTY_KEY, overDueItems.isEmpty());
	}

    /**
     * The setter for the team service.
     * @param teamService the value to set.
     */
    protected void setTeamService(final TeamService teamService) {
        this.teamService = teamService;
    }
}
