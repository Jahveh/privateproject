/**
 * AgreementDemandLetterCreator.java
 */
package com.menards.rental.report;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.OutputStreamCounter;
import com.lowagie.text.pdf.PdfWriter;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.Report;
import com.menards.rental.domain.ReservationAgreement;
import com.menards.rental.service.archive.PDFArchiver;
import com.menards.rental.utils.Constants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.util.Map;

/**
 * The report creator for the demand letter reports.
 *
 *@author jerry.wang
 */
@Component
public class AgreementDemandLetterCreator extends BaseReportCreator {
    /**
     * The report formatter.
     */
    @Autowired
    @Qualifier("doNothingFormatter")
    private ReportFormatter<String> reportFormatter;

    /** The pdf archiver. */
    @Autowired
    private PDFArchiver pdfArchiver;

    /**
     * The default constructor.
     */
    public AgreementDemandLetterCreator() {
        super(Report.Type.DEMAND_LETTER_REPORT);
    }

    /**
     * The setter for the pdf archiver.
     * @param pdfArchiver the value to set.
     */
    public void setPDFArchiver(final PDFArchiver pdfArchiver) {
        this.pdfArchiver = pdfArchiver;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected ReportFormatter<String> getFormatter(final Report report) {
        return reportFormatter;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void populateReportDataInModel(final Report report, final Map<String, Object> modelMap) {
        final String agreementId =  modelMap.get(Constants.Report.AGREEMENT_ID_KEY).toString();
        modelMap.put(Constants.ReportPublisher.BINARY_DATA_KEY,
                pdfArchiver.archive(agreementId));
    } 
    @Override
    protected void preEmailPublish(Report report, Map<String, Object> modelMap) {
        modelMap.put(Constants.ReportPublisher.DATA_KEY, pdfArchiver.getEmailText(modelMap.get(Constants.Report.AGREEMENT_ID_KEY).toString()));
        modelMap.put(Constants.ReportEmailPublisher.MAIL_FROM,Constants.ReportEmailPublisher.FROM_MAIL_FOR_AUTOMATED_MAILS);
        modelMap.put(Constants.ReportEmailPublisher.MAIL_TO,modelMap.get(Constants.ReportEmailPublisher.MAIL_TO));
    }
}
