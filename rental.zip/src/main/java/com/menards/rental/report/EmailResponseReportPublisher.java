/*
 * EmailResponseReportPublisher.java
 */
package com.menards.rental.report;

import com.menards.rental.domain.Report.Type;
import com.menards.rental.service.EmailService;
import com.menards.rental.utils.Constants;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import java.net.InetAddress;
import java.util.Map;

/**
 * Publish a report by sending it via Email.
 * 
 * @author deep
 */
@Component("emailResponseReportPublisher")
public class EmailResponseReportPublisher implements ReportPublisher {

	/**
	 * The log.
	 */
	private static final Logger log = Logger.getLogger(EmailResponseReportPublisher.class);

	/**
	 * The mail service.
	 */
	@Autowired
	private EmailService mailService;

	@Value("${menards.mail.address.dev}")
	private String devEmail;

	/**
	 * {@inheritDoc}
	 */
	public void publish(final Type reportType, final Map<String, Object> model) {
		final String subject = (String) model.get(Constants.ReportEmailPublisher.MAIL_SUBJECT);
		final String from = (String) model.get(Constants.ReportEmailPublisher.MAIL_FROM);
		
		final MimeMessagePreparator preparator = new MimeMessagePreparator() {
			public void prepare(final MimeMessage mimeMessage) throws MessagingException {
				log.debug("Starting ---- Preparing the mime message");
				if (log.isDebugEnabled()) {
					log.debug("Mime message: " + mimeMessage);
					log.debug("To: " + model.get(Constants.ReportEmailPublisher.MAIL_TO));
					log.debug("CC: " +  model.get(Constants.ReportEmailPublisher.MAIL_CC));
					log.debug("From: " + model.get(Constants.ReportEmailPublisher.MAIL_FROM));
					log.debug("Data: " + model.get(Constants.ReportPublisher.DATA_KEY));
				}
				
				MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true);
				
				String to = new String();
				String cc = new String();
				Boolean hasCCEmail = model.containsKey(Constants.ReportEmailPublisher.MAIL_CC);

				// run only on one server for nightly process
				// This is the process Web uses to run on only one server.
				try {
					String hostName = InetAddress.getLocalHost().getHostName();
					if (!(hostName.contains("stage1") || hostName.contains("app1") || hostName.contains("dev"))) {
						log.info("Not on primary server. The email will not be sent.");
						return;
					}
				} catch (final Exception e) {
					log.error("Error getting server host name, running on all servers. " + e.getMessage());
				}

				to = (String) model.get(Constants.ReportEmailPublisher.MAIL_TO);
				if (hasCCEmail) {
					cc = (String) model.get(Constants.ReportEmailPublisher.MAIL_CC);
				}

				try {
					message.setTo(to);
					if (hasCCEmail) {
						message.setCc(cc);
					}
					message.setSubject((subject != null && subject != "") ? subject : reportType.getDescription());
					message.setFrom(from);
					message.setText((String) model.get(Constants.ReportPublisher.DATA_KEY), true);
					log.info("Emailing " + subject + " message to: " + to + " from: " + from);
				} catch (final Exception e) {
					message.setTo((String) model.get(Constants.ReportEmailPublisher.MAIL_TO));
					if (hasCCEmail) {
						message.setCc((String) model.get(Constants.ReportEmailPublisher.MAIL_CC));
					}
					message.setSubject(reportType.getDescription());
					message.setFrom((String) model.get(Constants.ReportEmailPublisher.MAIL_FROM));
					message.setText((String) model.get(Constants.ReportPublisher.DATA_KEY), true);
				}

				if (reportType.isEmailAttachment()) {
					message.addAttachment(reportType.getFileName(),
							new ByteArrayResource(((byte[]) model.get(Constants.ReportPublisher.ATTACHMENT_KEY))),
							reportType.getContentType());
				}
					
				log.debug("Ending ----- preparing the mime message");
			}
		};

		if (model.containsKey(Constants.Report.IS_EMPTY_KEY) && (Boolean) model.get(Constants.Report.IS_EMPTY_KEY)) {
			log.debug("The report: " + reportType + " has no data.  Not sending the report via email");
			return;
		}
		
		mailService.sendEmailMessage(preparator);
	}
}
