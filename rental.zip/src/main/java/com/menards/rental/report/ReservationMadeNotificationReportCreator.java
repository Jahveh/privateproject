/**
 * ReservationMadeNotificationReportCreator.java
 */
package com.menards.rental.report;

import com.menards.rental.domain.Report;
import com.menards.rental.domain.ReservationAgreement;
import com.menards.rental.service.archive.PDFArchiver;
import com.menards.rental.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * The class that is responsible for creating reservation notification report.
 *
 * @author deep
 */
@Component
public class ReservationMadeNotificationReportCreator extends BaseReportCreator {

    /**
     * The velocity report formatter.
     */
    @Autowired
    @Qualifier("velocityReportFormatter")
    private ReportFormatter<String> velocityReportFormatter;

    /**
     * The report formatter.
     */
    @Autowired
    @Qualifier("doNothingFormatter")
    private ReportFormatter<String> doNothingFormatter;

    /** The pdf archiver. */
    @Autowired
    private PDFArchiver pdfArchiver;


    /**
     * The default constructor.
     */
    public ReservationMadeNotificationReportCreator() {
        super(Report.Type.RESERVATION_MADE_NOTIFICATION_REPORT, Report.Type.RESERVATION_REPORT);
    }

    /**
     * The setter for the velocity report formatter.
     * @param velocityReportFormatter the value to set.
     */
    public void setVelocityReportFormatter(final ReportFormatter<String> velocityReportFormatter) {
        this.velocityReportFormatter = velocityReportFormatter;
    }

    /**
     * The setter for the pdf archiver.
     * @param pdfArchiver the value to set.
     */
    public void setPDFArchiver(final PDFArchiver pdfArchiver) {
        this.pdfArchiver = pdfArchiver;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected ReportFormatter<String> getFormatter(final Report report) {
        if (report.getType() == Report.Type.RESERVATION_MADE_NOTIFICATION_REPORT) {
            return velocityReportFormatter;
        }
        return doNothingFormatter;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void populateReportDataInModel(final Report report, final Map<String, Object> modelMap) {
        final ReservationAgreement reservationAgreement = (ReservationAgreement)
                modelMap.get(Constants.Report.RESERVATION_AGREEMENT_KEY);
        modelMap.put(Constants.ReportPublisher.BINARY_DATA_KEY, pdfArchiver.archive(reservationAgreement));

    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void preEmailPublish(final Report report, final Map<String, Object> modelMap) {
        super.preEmailPublish(report, modelMap);
        final ReservationAgreement reservationAgreement = (ReservationAgreement)
                modelMap.get(Constants.Report.RESERVATION_AGREEMENT_KEY);
        modelMap.put(Constants.ReportPublisher.ATTACHMENT_KEY,
                modelMap.get(Constants.ReportPublisher.BINARY_DATA_KEY));
        modelMap.put(Constants.ReportEmailPublisher.MAIL_TO, reservationAgreement.getGuest().getEmail());
    }
}
