/*
 * CSVReportFormatter.java
 */
package com.menards.rental.report;

import java.io.IOException;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;

import com.menards.rental.utils.Constants;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.supercsv.exception.SuperCSVException;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

/**
 * Output a report in CSV format.
 * @author deep
 */
@Component(value = "csvReportFormatter")
public class CSVReportFormatter implements ReportFormatter<String> {

	/** The log. */
	private static final Logger log = Logger.getLogger(CSVReportFormatter.class);

    /**
     * {@inheritDoc}
     */
	public String format(final String template, final Map<String, Object> model) {
		final StringWriter outFile = new StringWriter();
		final CsvBeanWriter writer = new CsvBeanWriter(outFile, CsvPreference.EXCEL_PREFERENCE);

		try {
			final String[] headers = (String[]) model.get(Constants.Report.HEADERS_KEY);
			writer.writeHeader(headers);

			final String[] properties = (String[]) model.get(Constants.Report.PROPERTIES_KEY);
			final List<? extends Object> reportData = (List<? extends Object>) model.get(Constants.Report.REPORT_DATA_KEY);
			for (final Object reportDto : reportData) {
				writer.write(reportDto, properties);
			}
		} catch (final SuperCSVException e) {
			log.error("CSV parsing error", e);
		} catch (final IOException e) {
			log.error("Error writing information", e);
		} finally {
			try {
				writer.close();
			} catch (final IOException e) {
                log.error(e.getMessage(), e);
			}
		}

		return outFile.toString();
	}
}
