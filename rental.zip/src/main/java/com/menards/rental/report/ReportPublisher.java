/*
 * ReportPublisher.java
 */
package com.menards.rental.report;

import java.util.Map;

import com.menards.rental.domain.Report;

/**
 * Interface to implement to create a new way of sending a report to a user.
 * @author deep
 */
public interface ReportPublisher {

	/**
	 * Publish.
	 *
	 * @param reportType the report type
	 * @param model the model
	 */
	void publish(Report.Type reportType, Map<String, Object> model);
}
