/**
 * DoNothingFormatter.java
 */
package com.menards.rental.report;

import com.menards.rental.utils.Constants;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * As the name suggests does nothing at all.
 *
 * @author deep
 */
@Component(value = "doNothingFormatter")
public class DoNothingFormatter implements ReportFormatter<String> {

    /**
     * {@inheritDoc}
     */
    public String format(final String template, final Map<String, Object> model) {
        return Constants.Action.EMPTY_STRING;
    }
}
