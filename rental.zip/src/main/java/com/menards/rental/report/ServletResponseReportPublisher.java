/*
 * ServletResponseReportPublisher.java
 */
package com.menards.rental.report;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.menards.rental.domain.Report;
import com.menards.rental.utils.Constants;

/**
 * Publish a report by sending it to the output stream of a Servlet so that the
 * user's browser will prompt them to download it.
 * 
 * @author deep
 */
@Component("servletResponseReportPublisher")
public class ServletResponseReportPublisher implements ReportPublisher {

	/** The log. */
	private static final Logger log = Logger.getLogger(ServletResponseReportPublisher.class);

    /**
     * {@inheritDoc}
     */
	public void publish(final Report.Type reportType, final Map<String, Object> model) {
		
		ServletOutputStream servletOutputStream = null;

        final byte[] array = getData(model);

		final HttpServletResponse response = (HttpServletResponse) model.get(Constants.ReportPublisher.RESPONSE_KEY);
		response.setContentType(reportType.getContentType());
        if (reportType.isServletAttachment()) {
            response.setHeader("Content-Disposition", "attachment; filename=\"" + reportType.getFileName() + "\"");
        }
		try {
			servletOutputStream = response.getOutputStream();
			servletOutputStream.write(array);
			servletOutputStream.flush();
		} catch (final IOException e) {
			log.error(e.getMessage(), e);
		} finally {
			if (null != servletOutputStream) {
				try {
					servletOutputStream.close();
				} catch (final IOException ioe) {
					log.error(ioe.getMessage(), ioe);
				}
			}
		}
	}

    /**
     * The method that returns the data to be used for the report processing.  If the model has binary data
     * then we return that as is.  If not then we get the string data and convert that into bytes.
     * @param model The model from which we need to get the data.
     * @return the byte array representation of the data.
     */
    private byte[] getData(final Map<String, Object> model) {
        if (model.containsKey(Constants.ReportPublisher.BINARY_DATA_KEY)) {
            return (byte[]) model.get(Constants.ReportPublisher.BINARY_DATA_KEY);
        }
        return ((String) model.get(Constants.ReportPublisher.DATA_KEY)).getBytes();
    }
}
