/*
 * VoidRentalReportCreator.java
 */
package com.menards.rental.report;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.menards.rental.dao.VoidRentalReportDao;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.Report;
import com.menards.rental.domain.Store;
import com.menards.rental.service.MenardsService;
import com.menards.rental.service.external.TeamService;
import com.menards.rental.utils.Constants;

/**
 * The void rental report creator.  Responsible for creating the void rentals report.
 * @author deep
 */
@Component(value = "voidRentalReportCreator")
public class VoidRentalReportCreator extends BaseReportCreator {

	/** The void rental report dao. */
	@Autowired
	private VoidRentalReportDao voidRentalReportDao;

	/** The report formatter. */
	@Autowired
	@Qualifier("velocityReportFormatter")
	private ReportFormatter reportFormatter;

	/** The menards service. */
	@Autowired
	private MenardsService menardsService;
	
	/** The team service reference. */
    @Autowired
    private TeamService teamService;

    /**
     * The default constructor.
     */
    public VoidRentalReportCreator() {
        super(Report.Type.VOID_RENTAL_REPORT);
    }

    /**
	 * Sets the menards service.
	 *
	 * @param menardsService the new menards service
	 */
	public void setMenardsService(final MenardsService menardsService) {
		this.menardsService = menardsService;
	}

	/**
	 * Sets the report formatter.
	 *
	 * @param reportFormatter the new report formatter
	 */
	public void setReportFormatter(final ReportFormatter reportFormatter) {
		this.reportFormatter = reportFormatter;
	}

	/**
	 * Sets the void rental report dao.
	 *
	 * @param voidRentalReportDao the new void rental report dao
	 */
	public void setVoidRentalReportDao(final VoidRentalReportDao voidRentalReportDao) {
		this.voidRentalReportDao = voidRentalReportDao;
	}

    /**
     * {@inheritDoc}
     */
    @Override
    protected void populateReportDataInModel(final Report report, final Map<String, Object> modelMap) {
        final Calendar startTime = Calendar.getInstance();
        // Move the time back by 24 hours
        startTime.add(Calendar.HOUR_OF_DAY, -24);

        final List<Agreement> voidedAgreements = voidRentalReportDao.getVoidedAgreementsBetweenTwoPeriod(report
                .getStoreNumber(), startTime, Calendar.getInstance());
        final Store store = menardsService.getStoreByStoreNumber(report.getStoreNumber());

        final SimpleDateFormat sdf = new SimpleDateFormat(Constants.DateFormat.DATE_TIME_FORMAT);
        modelMap.put(Constants.ReportPublisher.CURRENT_DATE, sdf.format(new Date()));
        modelMap.put(Constants.Report.STORE_KEY, store);
        modelMap.put(Constants.Report.REPORT_DATA_KEY, voidedAgreements);
        modelMap.put(Constants.Report.IS_EMPTY_KEY, voidedAgreements.isEmpty());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected ReportFormatter<String> getFormatter(final Report report) {
        return reportFormatter;
    }

	@Override
	protected void preEmailPublish(final Report report, Map<String, Object> modelMap) {
		modelMap.put(Constants.ReportEmailPublisher.MAIL_TO, 
				teamService.getFrontEndManagerEmailFor(report.getStoreNumber()));
		modelMap.put(Constants.ReportEmailPublisher.MAIL_FROM,
                Constants.ReportEmailPublisher.FROM_MAIL_FOR_AUTOMATED_MAILS);
	}

	/**
     * The setter for the team service.
     * @param teamService the value to set.
     */
	public void setTeamService(TeamService teamService) {
		this.teamService = teamService;
	}    
}
