/*
 * ReportCreator.java
 */
package com.menards.rental.report;

import java.util.Map;

import com.menards.rental.domain.Report;

/**
 * The report creator interface.  Various report are available in the system.  To add new report simply implement this
 * interface and implement various methods.  For default publishers use the BaseReportCreator.  This interface
 * will guide the way in which the report is generated.
 */
public interface ReportCreator {

	/**
	 * Can create.
	 *
	 * @param report the report
	 * @return true, if successful
	 */
	boolean canCreate(final Report report);

	/**
	 * Creates the.
	 *
	 * @param report the report
	 * @param modelMap the model map
	 * @return the string
	 */
	String create(final Report report, final Map<String, Object> modelMap);

    /**
     * Should publish the report to the desired receiptents in the desired channel.
     * @param report the report to publish.
     * @param model the model using which we need to publish the report.
     */
    void publish(final Report report, final Map<String, Object> model);
}
