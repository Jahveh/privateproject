/**
 * ArchivedAgreementReportCreator.java
 */
package com.menards.rental.report;

import com.menards.rental.domain.ArchivedAgreement;
import com.menards.rental.domain.Report;
import com.menards.rental.service.archive.PDFArchiver;
import com.menards.rental.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * The archived agreement report creator that creates reports for archived agreements.
 *
 * @author deep
 */
@Component
public class ArchivedAgreementReportCreator extends BaseReportCreator {

    /**
     * The report formatter.
     */
    @Autowired
    @Qualifier("doNothingFormatter")
    private ReportFormatter<String> reportFormatter;

    /** The pdf archiver. */
    @Autowired
    private PDFArchiver pdfArchiver;

    /**
     * The default constructor.
     */
    public ArchivedAgreementReportCreator() {
        super(Report.Type.ARCHIVED_AGREEMENT_REPORT);
    }

    /**
     * The setter for the pdf archiver.
     * @param pdfArchiver the value to set.
     */
    public void setPDFArchiver(final PDFArchiver pdfArchiver) {
        this.pdfArchiver = pdfArchiver;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected ReportFormatter<String> getFormatter(final Report report) {
        return reportFormatter;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void populateReportDataInModel(final Report report, final Map<String, Object> modelMap) {
        final Long agreementId = (Long) modelMap.get(Constants.Report.AGREEMENT_ID_KEY);
        final ArchivedAgreement archivedAgreement = ArchivedAgreement.findArchivedAgreement(agreementId);
        modelMap.put(Constants.ReportPublisher.BINARY_DATA_KEY, pdfArchiver.getArchive(archivedAgreement));
    }
}
