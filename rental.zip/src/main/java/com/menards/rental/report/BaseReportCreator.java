package com.menards.rental.report;

import com.menards.rental.domain.Report;
import com.menards.rental.service.external.TeamService;
import com.menards.rental.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * The base report creator provides the basic functionality of publishing the report based on the medium used to publish
 * the report.
 *
 * @author deep
 */
public abstract class BaseReportCreator implements ReportCreator {

    /** The report types reference. */
    private List<Report.Type> types;

	/** The servlet response report publisher. */
	@Autowired
	@Qualifier("servletResponseReportPublisher")
	private ReportPublisher servletResponseReportPublisher;

	/** The email response report publisher. */
	@Autowired
	@Qualifier("emailResponseReportPublisher")
	private ReportPublisher emailResponseReportPublisher;

    /** The team service reference. */
    @Autowired
    private TeamService teamService;

    /**
     * The constructor that accepts the report type with which this report works.
     * @param types the report types with which this report works.
     */
    public BaseReportCreator(final Report.Type... types) {
        this.types = Arrays.asList(types);
    }

    /**
     * {@inheritDoc}
     */
    public final boolean canCreate(final Report report) {
        return types.contains(report.getType());
    }

    /**
     * {@inheritDoc}
     */
    public final String create(final Report report, final Map<String, Object> modelMap) {
        populateReportDataInModel(report, modelMap);
        return getFormatter(report).format(report.getTemplateName(), modelMap);
    }

    /**
     * {@inheritDoc}
     */
    public final void publish(final Report report, final Map<String, Object> modelMap) {
        if (report.isToBeDownloaded()) {
            servletResponseReportPublisher.publish(report.getType(), modelMap);
        } else if (report.isToBeEmailed()) {
            preEmailPublish(report, modelMap);
            emailResponseReportPublisher.publish(report.getType(), modelMap);
        }
    }

    /**
     * Should do some processing before the email are sent out.  Typically in this phase, the creators should populate
     * the email address of people who should receive the reports.  This default implementation populates defaulat email
     * address from where the reports are sent and to whome the report is sent.
     * Override this method to populate you custom senders and receivers.
     * @param report the report for which we have to do the pre email publish tasks.
     * @param modelMap the values are populate in the model.
     */
    protected void preEmailPublish(final Report report, final Map<String, Object> modelMap) {
        modelMap.put(Constants.ReportEmailPublisher.MAIL_TO,
                teamService.getGeneralManagerEmailFor(report.getStoreNumber()));
        modelMap.put(Constants.ReportEmailPublisher.MAIL_FROM,
                Constants.ReportEmailPublisher.FROM_MAIL_FOR_AUTOMATED_MAILS);
    }

    /**
     * The derived classes should implement this method to return the report formatters used for this report.
     * @param report the report that is to be generated.
     * @return the ReportFormatter that should be used to format the report.
     */
    protected abstract ReportFormatter<String> getFormatter(final Report report);

    /**
     * The derived classes should implement this method and populate report data in the model.
     * @param report the report which needs to be generated.
     * @param modelMap the model map that will be eventually used to create the report.
     */
    protected abstract void populateReportDataInModel(final Report report, final Map<String, Object> modelMap);

    /**
     * The setter for the servlet response publisher.
     * @param servletResponseReportPublisher the value.
     */
    protected void setServletResponseReportPublisher(final ReportPublisher servletResponseReportPublisher) {
        this.servletResponseReportPublisher = servletResponseReportPublisher;
    }

    /**
     * The setter for the email response publisher.
     * @param emailResponseReportPublisher the value.
     */
    protected void setEmailResponseReportPublisher(final ReportPublisher emailResponseReportPublisher) {
        this.emailResponseReportPublisher = emailResponseReportPublisher;
    }

    /**
     * The setter for the team service.
     * @param teamService the value to set.
     */
    protected void setTeamService(final TeamService teamService) {
        this.teamService = teamService;
    }
}
