/**
 * ArchivePathBuilder.java
 */
package com.menards.rental.builder;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.ArchivePath;
import com.menards.rental.domain.ReservationAgreement;
import com.menards.rental.utils.Constants;
import com.menards.rental.utils.MenardsProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * The rental url builder class that uses the properties files to build the url of the rental application.
 *
 * @author deep
 */
@Component
public class ArchivePathBuilder {

    /** The menards properties reference. */
    @Autowired
    private MenardsProperties menardsProperties;

    /**
     * Returns the archive path that holds information about the archive that is to be created for the agreement.
     * @param agreement the agreement whose archive path is to be created.
     * @return the ArchivePath reference for the given agreement.
     */
    public ArchivePath build(final Agreement agreement) {
        final ArchivePath archivePath = new ArchivePath();
        archivePath.setURLFrom(menardsProperties.getApplicationURL()
                + Constants.Report.AGREEMENT_REPORT_PATH + agreement.getId());
        return archivePath;
    }

    /**
     * Builds the archive path for the reservation agreement.
     * @param reservationAgreement the reservation agreement for which we have to build the archive path.
     * @return The archive path reseference with the required information.
     */
    public ArchivePath build(final ReservationAgreement reservationAgreement) {
        final ArchivePath archivePath = new ArchivePath();
        archivePath.setURLFrom(menardsProperties.getApplicationURL()
                + Constants.Report.RESERVATION_REPORT_PATH + reservationAgreement.getId());
        return archivePath;
    }

    /**
     * The setter for the menards properties.
     * @param menardsProperties the value to set.
     */
    public void setMenardsProperties(final MenardsProperties menardsProperties) {
        this.menardsProperties = menardsProperties;
    }
    /**
     * Builds the archive path for the demand letter
     * @param agreementId the agreementid
     * @return the ArchivePath reference for the demand letter.
     */
    public ArchivePath build(final String agreementId) {
        final ArchivePath archivePath = new ArchivePath();
        archivePath.setURLFrom(menardsProperties.getApplicationURL()
                + Constants.Report.AGREEMENT_DEMANDLETTER_PATH + agreementId);
        return archivePath;
    }
}
