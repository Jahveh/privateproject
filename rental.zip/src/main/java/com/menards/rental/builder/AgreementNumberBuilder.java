/*
 * AgreementNumberBuilder.java
 */
package com.menards.rental.builder;

/**
 * Interface to implement a strategy for creating agreement numbers, the unique
 * id of an agreement that is displayed on the printed agreements.
 *
 * @author deep
 */
public interface AgreementNumberBuilder {

	/**
	 * Build a new agreement for a store.
	 *
	 * @param storeNumber The store number for the current store
	 * @return A valid agreement number for that store with the initial
	 * increment.
	 */
	String build(final Integer storeNumber);

	/**
     * Converts the parts of the agreement number into a full agreement number.
     * @param storeNumber the store number.
     * @param eightDigitAgreementNumber the eight digit agreement number.
     * @return String value representing the formatted agreement number
     */
    String build(final String storeNumber, final String eightDigitAgreementNumber);

    /**
	 * Increment the agreement number because the agreement has been modified in
	 * someway after it has been sent to SysV.
	 * 
	 * @param agreementNumber
	 *            The agreement number that needs to be incremented.
	 * @return The next increment of the given agreement number.
	 */
	String buildNextIncrement(final String agreementNumber);
}
