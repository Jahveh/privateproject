/*
 * StoreNumberAndIncrementBasedAgreementNumberBuilder.java
 */
package com.menards.rental.builder;

import com.menards.rental.domain.AgreementIncrement;
import org.springframework.stereotype.Component;

/**
 * Implementation of the AgreementNumberBuilder that uses the AgreementIncrement
 * table in the database to keep track of agreement number usage.
 *
 * @author deep
 */
@Component(value = "agreementNumberBuilder")
public class StoreAndAgreementNumberBuilder implements AgreementNumberBuilder {

    /**
     * {@inheritDoc}
     */
	public String build(final Integer storeNumber) {
		return buildAgreementNumber(storeNumber,
		        AgreementIncrement.getNextAgreementNumberForStoreNumber(storeNumber), 0);
	}

    /**
     * {@inheritDoc}
     */
	public String build(final String storeNumber, final String eightDigitAgreementNumber) {
        return String.format("%1$s-%2$s-%3$s", storeNumber,
                eightDigitAgreementNumber.substring(0, 5), eightDigitAgreementNumber.substring(5));
    }

    /**
     * {@inheritDoc}
     */
	public String buildNextIncrement(final String agreementNumber) {
		final String[] parts = agreementNumber.split("-");
		if (parts.length != 3) {
			return agreementNumber;
		}

		return buildAgreementNumber(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer
		        .parseInt(parts[2]) + 1);
	}

    /**
	 * Builds the agreement number.
	 *
	 * @param storeNumber the store number
	 * @param sequenceNumber the sequence number
	 * @param counter the counter
	 * @return the string
	 */
	private String buildAgreementNumber(final Integer storeNumber, final int sequenceNumber, final int counter) {
		return new StringBuilder().append(storeNumber).append("-").append(String.format("%05d", sequenceNumber))
		        .append("-").append(String.format("%03d", counter % 1000)).toString();
	}
}
