/*
 * LazyItemList.java
 */
package com.menards.rental.decorator;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;

import com.menards.rental.domain.Item;

/**
 * An automatically growing list of Items. If getItems().get(n) is called (where
 * n does not exist in the list) then the list will grow to include n as a new
 * item.
 */
public class LazyItemList implements Serializable {

	/** The items. */
	private List<Item> items;

	/**
	 * Instantiates a new lazy item list.
	 */
	public LazyItemList() {
		items = LazyList.decorate(new ArrayList<Item>(), FactoryUtils.instantiateFactory(Item.class));
	}

	/**
	 * Gets the items.
	 *
	 * @return the items
	 */
	public List<Item> getItems() {
		return items;
	}

	/**
	 * Gets the size.
	 *
	 * @return the size
	 */
	public int getSize() {
        if (items == null) {
            return 0;
        }
		return items.size();
	}

	/**
	 * Sets the items.
	 *
	 * @param items the new items
	 */
	public void setItems(final List<Item> items) {
		this.items = items;
	}
}
