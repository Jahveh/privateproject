/*
 * Barcode.java
 */
package com.menards.rental.barcode;

/**
 * Data object that holds the information about a generated barcode image.
 * @author lalit
 */
public class Barcode {

	/** The image. */
	private final byte[] image;

	/** The image type. */
	private final String imageType;

	/**
	 * Instantiates a new barcode.
	 *
	 * @param type the type
	 * @param image the image
	 */
	public Barcode(final String type, final byte[] image) {
		this.imageType = type;
		this.image = image;
	}

	/**
	 * The bytes that makeup the image.
	 * 
	 * @return The bytes that makeup the barcode image.
	 */
	public byte[] getImage() {
		return image;
	}

	/**
	 * The mimetype of the image.
	 * 
	 * @return The mimetype.
	 */
	public String getImageType() {
		return imageType;
	}
}
