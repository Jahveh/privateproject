/*
 * BarcodeDetails.java
 */
package com.menards.rental.barcode;

import com.menards.rental.service.BarcodeTypeStrategy;
import com.menards.rental.utils.Constants;
import org.krysalis.barcode4j.impl.AbstractBarcodeBean;

/**
 * The parameters to be used for generating the bar code.
 *
 * @author Lalit
 */
public class BarcodeDetails {

	/** width of narrow bar in mm, default is 1mm. */
	private double narrowBarWidth = Constants.Barcode.NARROW_BAR_WIDTH;

	/** factor by which wide module is bigger than narrow module. */
	private double widthFactor = Constants.Barcode.WIDTH_FACTOR;

	/** Image type to be generated. */
	private String imageType;

	/**
	 * height of the bar in mm, default is 12.5 mm.
	 */
	private double barHeight = Constants.Barcode.BAR_HEIGHT;

	/** resolution of the image. */
	private int resolution = Constants.Barcode.RESOLUTION;

    /** The type strategy reference. */
    private BarcodeTypeStrategy typeStrategy;

    /** The string value whose barcode is to be generated. */
    private String toGenerateValue;

    /**
	 * Gets the bar height.
	 *
	 * @return the bar height
	 */
	public double getBarHeight() {
		return barHeight;
	}

	/**
	 * Gets the image type.
	 *
	 * @return the image type
	 */
	public String getImageType() {
		return imageType;
	}

	/**
	 * Gets the narrow bar width.
	 *
	 * @return the narrow bar width
	 */
	public double getNarrowBarWidth() {
		return narrowBarWidth;
	}

	/**
	 * Gets the resolution.
	 *
	 * @return the resolution
	 */
	public int getResolution() {
		return resolution;
	}

	/**
	 * Gets the width factor.
	 *
	 * @return the width factor
	 */
	public double getWidthFactor() {
		return widthFactor;
	}

	/**
	 * Sets the bar height.
	 *
	 * @param barHeight the new bar height
	 */
	public void setBarHeight(final double barHeight) {
		this.barHeight = barHeight;
	}

	/**
	 * Sets the image type.
	 *
	 * @param imageType the new image type
	 */
	public void setImageType(final String imageType) {
		this.imageType = imageType;
	}

	/**
	 * Sets the narrow bar width.
	 *
	 * @param narrowBarWidth the new narrow bar width
	 */
	public void setNarrowBarWidth(final double narrowBarWidth) {
		this.narrowBarWidth = narrowBarWidth;
	}

	/**
	 * Sets the resolution.
	 *
	 * @param resolution the new resolution
	 */
	public void setResolution(final int resolution) {
		this.resolution = resolution;
	}

	/**
	 * Sets the width factor.
	 *
	 * @param widthFactor the new width factor
	 */
	public void setWidthFactor(final double widthFactor) {
		this.widthFactor = widthFactor;
	}

    /**
     * The setter for the typeStrategy.
     * @param typeStrategy the typeStrategy value to set.
     */
    public void setTypeStrategy(final BarcodeTypeStrategy typeStrategy) {
        this.typeStrategy = typeStrategy;
    }

    /**
     * The method that will return an instance of abstract barcode bean depending on the type of barcode we
     * whant to generate.
     * @return the instance of AbstractBarcodeBean bsed on the barcode type.
     */
    public AbstractBarcodeBean getBean() {
        return typeStrategy.getBean(this);
    }

    /**
     * The setter for the to generate value.
     * @param toGenerateValue the value to be generated.
     */
    public void setToGenerateValue(final String toGenerateValue) {
        this.toGenerateValue = toGenerateValue;
    }

    /**
     * The getter for the to generate value.
     * @return the value of toGenerateValue.
     */
    public String getToGenerateValue() {
        return toGenerateValue;
    }

    /**
     * The enum for the barcode types that we support.
     * @author deep
     */
    public enum Type {
        /** The barcode for type CODE 3 of 9. */
        CODE_39,
        /** The interleaved 2 of 5 value. */
        INTERLEAVED_25;
    }
}
