/*
 * BarcodeGenerator.java
 */
package com.menards.rental.barcode;

/**
 * Interface to implement to create a barcode.
 * @author lalit
 */
public interface BarcodeGenerator {

	/**
	 * Generate the bar code as per Code39. Sizing is governed by the barcode
	 * details The sizing logic can be seen at
	 * http://www.adams1.com/39code.html. From the link - The height of the bars
	 * must be at least .15 times the symbol's length or .25 inches, whichever
	 * is larger. The overall length of the symbol is given by the equation: L =
	 * (C + 2)(3N + 6)X + (C + 1)I where L = length of symbol (not counting
	 * quiet zone, dimension will be in mils) C = number of data characters X =
	 * X-dimension (width of the smallest element in mils.) N = wide-to-narrow
	 * multiple(use 3.0 if your code has a 3 to 1 ratio, etc.) I =
	 * intercharacter gap width
	 * 
	 * @param barCodeDetails
	 *            Parameter object containing information used to generate the
	 *            barcode such as height, width and resolution
	 * @return The generated barcode
	 */
	Barcode generateBarcode(final BarcodeDetails barCodeDetails);

}
