/*
 * Barcode4JBarcodeGenerator.java
 */
package com.menards.rental.barcode;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;

import org.apache.log4j.Logger;
import org.krysalis.barcode4j.impl.AbstractBarcodeBean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.springframework.stereotype.Service;

/**
 * Barcode generator implemented with Barcode4J.
 */
@Service("barcodeGenerator")
public class Barcode4JBarcodeGenerator implements BarcodeGenerator {

	/** The log. */
	private static final Logger log = Logger.getLogger(Barcode4JBarcodeGenerator.class);

	/**
	 * Generate the bar code as per Code39. Sizing is governed by the barcode
	 * details The sizing logic can be seen at
	 * http://www.adams1.com/39code.html. From the link - The height of the bars
	 * must be at least .15 times the symbol's length or .25 inches, whichever
	 * is larger. The overall length of the symbol is given by the equation: L =
	 * (C + 2)(3N + 6)X + (C + 1)I where L = length of symbol (not counting
	 * quiet zone, dimension will be in mils) C = number of data characters X =
	 * X-dimension (width of the smallest element in mils.) N = wide-to-narrow
	 * multiple(use 3.0 if your code has a 3 to 1 ratio, etc.) I =
	 * intercharacter gap width
	 *
	 * @param barCodeDetails the bar code details
	 * @return the barcode, returns null if barcode cannot be created
	 */
	public Barcode generateBarcode(final BarcodeDetails barCodeDetails) {


        try {
            // Open output stream
            final ByteArrayOutputStream out = new ByteArrayOutputStream();

            // Set up the canvas provider
            final BitmapCanvasProvider canvas = new BitmapCanvasProvider(out, barCodeDetails.getImageType(),
			        barCodeDetails.getResolution(), BufferedImage.TYPE_BYTE_BINARY, false, 0);

			// Generate the barcode
            final AbstractBarcodeBean bean = barCodeDetails.getBean();
            bean.generateBarcode(canvas, barCodeDetails.getToGenerateValue());

			// Signal end of generation
			canvas.finish();
			
			return new Barcode(barCodeDetails.getImageType(), out.toByteArray());
		} catch (final Exception e) {
			log.error(e.getMessage(), e);
		}
        return null;
	}

}
