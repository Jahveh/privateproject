/*
 * ReservationController.java
 */
package com.menards.rental.controller;

import com.menards.rental.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.menards.rental.domain.ReservationAgreement;

/**
 * The reservation controller used while making reservations.
 * @author deep
 */
@Controller
public class ReservationController {

    /** The reference of the reservation service. */
    @Autowired
    private ReservationService reservationService;

	/**
	 * Cancel.
	 *
	 * @param reservationAgreementId the reservation agreement id
	 * @return the string
	 */
	@RequestMapping(value = "/reservation/cancel/{id}", method = RequestMethod.GET)
	public String cancel(@PathVariable("id") final Long reservationAgreementId) {
		final ReservationAgreement reservationAgreement = ReservationAgreement
		        .findReservationAgreement(reservationAgreementId);
		if (null == reservationAgreement) {
			return "redirect:/";
		}

		reservationAgreement.cancel();
		return "redirect:/";
	}

	/**
	 * Generates the reservation Report in html format.
	 *
	 * @param agreementId the agreement id
	 * @param modelMap the model map
	 * @return the string
	 */
	@RequestMapping(value = "/reservation/report/{id}", method = RequestMethod.GET)
	public String report(@PathVariable(value = "id") final long agreementId, final ModelMap modelMap) {
		final ReservationAgreement reservationAgreement = ReservationAgreement.findReservationAgreement(agreementId);
		modelMap.addAttribute("reservationAgreement", reservationAgreement);
		return "/WEB-INF/views/reports/reservationAgreement.jspx";
	}


}
