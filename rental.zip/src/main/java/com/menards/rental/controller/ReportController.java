/*
 * ReportController.java
 */
package com.menards.rental.controller;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.menards.rental.domain.*;
import com.menards.rental.scheduler.GoUtilityTaskScheduler;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.menards.rental.domain.Report.Type;
import com.menards.rental.service.AutomatedReportService;
import com.menards.rental.service.ContextService;
import com.menards.rental.service.ReportService;
import com.menards.rental.utils.Constants;
import com.menards.rental.utils.Constants.ReportMedium;

/**
 * The Class ReportController.
 */
@Controller
public class ReportController
{
	
	private static final Logger log = Logger.getLogger(ReportController.class);

	/** The report service. */
	@Autowired
	private ReportService reportService;

	/** The context service. */
	@Autowired
	private ContextService contextService;

	/** This reference is for testing only. */
	@Autowired
	@Qualifier("goUtilityTaskSchedulerForTestingOnly")
	private GoUtilityTaskScheduler goUtilityTaskSchedulerForTestingOnly;

	/**
	 * Downloads the report.
	 * 
	 * @param reportType the report type
	 * @param response the response
	 */
	@RequestMapping(value = "/storeutility/downloadreport", method = RequestMethod.POST)
	public void downloadReport(@RequestParam("type") final String reportType,
																final HttpServletResponse response)
	{
		publishReport(reportType, "download", response);
	}

	/**
	 * Generate report.
	 * 
	 * @param reportType the report type
	 * @param response the response
	 * @param modelMap the model map
	 * @return the string
	 */
	@RequestMapping(value = "/storeutility/emailreport", method = RequestMethod.POST)
	public String generateReport(@RequestParam("type") final String reportType,
					final HttpServletResponse response,
					final ModelMap modelMap)
	{

		publishReport(reportType, "email", response);

		modelMap.put("report", new Report());
		modelMap.put("appType", Constants.AppType.STORE_UTILITY);
		return "/storeutility/requestreport";
	}

	@RequestMapping(value = "/generalofficeutility/emailOutOfStock", method = RequestMethod.POST)
	public String emailOutOfStockReport(@RequestParam("startDate") final String startDate, @RequestParam("emailAddress") final String email)
	{
		ModelMap modelMap = new ModelMap();
		final Report report = new Report();
		report.setType(Type.OUT_OF_STOCK_REPORT);
		report.setReportMedium(ReportMedium.EMAIL);

		modelMap.put("report", report);
		modelMap.put("appType", Constants.AppType.GO_UTILITY);
		modelMap.put(Constants.ReportEmailPublisher.MAIL_TO, email);
		modelMap.put(Constants.Report.REPORT_START_DATE_KEY, startDate);

		reportService.generateAndPublishReport(report, modelMap);

		return "redirect:/generalofficeutility";
	}
	
	/**
	 * Method to test the go utility reports.
	 * Generate go report.
	 * 
	 * @return the string representing the view id to render.
	 */
	@RequestMapping(value = "/generalofficeutility/requestreport/daily", method = RequestMethod.GET)
	public String generateGODailyReports() {
		log.info("daily go report");
		goUtilityTaskSchedulerForTestingOnly.doDailyTask();
		return "generalofficeutility/requestreport";
	}

	/**
	 * Method to test the go utility reports.
	 * Generate go report.
	 * 
	 * @return the string representing the view id to render.
	 */
	@RequestMapping(value = "/generalofficeutility/requestreport/weekly", method = RequestMethod.GET)
	public String generateGOWeeklyReports() {
		log.info("weekly go report");
		goUtilityTaskSchedulerForTestingOnly.doWeeklyTask();
		return "generalofficeutility/requestreport";
	}

	/**
	 * Generate go report.
	 * 
	 * @return String representing the view id to render.
	 */
	@RequestMapping(value = "/generalofficeutility/requestreport", method = RequestMethod.GET)
	public String goRequestReport()
	{
		return "generalofficeutility/requestreport";
	}

	/**
	 * Downloads the report.
	 * 
	 * @param agreementId the agreement whose report we need to publish.
	 * @param response the response.
	 */
	@RequestMapping(value = "/report/archivedagreement/{id}", method = RequestMethod.GET)
	public void downloadArchivedAgreementReport(@PathVariable("id") final Long agreementId,
																final HttpServletResponse response)
	{
		publishArchivedAgreementReport(agreementId, response);
	}

	/**
	 * Downloads the agreement report by agreement id.
	 * 
	 * @param agreementId the agreement whose report we need to publish.
	 * @param response the response.
	 */
	@RequestMapping(value = "/report/agreement/{id}", method = RequestMethod.GET)
	public void downloadAgreementReport(@PathVariable("id") final Long agreementId,
																final HttpServletResponse response)
	{
		final ArchivedAgreement archivedAgreement =
								ArchivedAgreement.findArchivedAgreementByAgreementNumber(Agreement
										.findAgreement(agreementId)
										.getAgreementNumber());
		publishArchivedAgreementReport(archivedAgreement.getId(), response);
	}

	/**
	 * Downloads the actual agreement report by agreement id.
	 * 
	 * @param agreementId the agreement whose report we need to publish.
	 * @param response the response.
	 */
	@RequestMapping(value = "/report/actualagreement/{id}", method = RequestMethod.GET)
	public void downloadActualAgreementReport(@PathVariable("id") final Long agreementId,
																							final HttpServletResponse response)
	{

		final HashMap<String, Object> model = new HashMap<String, Object>();
		model.put(Constants.Report.AGREEMENT_ID_KEY, agreementId);
		publishReport(Type.AGREEMENT_REPORT.toString(), Constants.ReportMedium.DOWNLOAD,
								response, model);

	}

	/**
	 * The method that renders the reservation report in pdf format.
	 * 
	 * @param reservationAgreementId the reservation agreement id whose report is to be published.
	 * @param response the http servlet response which will be used to publish the report.
	 */
	@RequestMapping(value = "/report/reservation/{id}", method = RequestMethod.GET)
	public void downloadReservationReport(@PathVariable("id") final Long reservationAgreementId,
																final HttpServletResponse response)
	{
		final ReservationAgreement reservationAgreement =
								ReservationAgreement.findReservationAgreement(reservationAgreementId);

		final HashMap<String, Object> model = new HashMap<String, Object>();
		model.put(Constants.Report.RESERVATION_AGREEMENT_KEY, reservationAgreement);
		publishReport(Report.Type.RESERVATION_REPORT.toString(), Constants.ReportMedium.DOWNLOAD,
								response, model);
	}

	/**
	 * Sets the context service.
	 * 
	 * @param contextService the new context service
	 */
	public void setContextService(final ContextService contextService)
	{
		this.contextService = contextService;
	}

	/**
	 * Sets the report service.
	 * 
	 * @param reportService the new report service
	 */
	public void setReportService(final ReportService reportService)
	{
		this.reportService = reportService;
	}

	/**
	 * Creates the new report.
	 * 
	 * @param reportMedium the report medium
	 * @param reportType the report type
	 * @return the report
	 */
	private Report createNewReport(final String reportMedium, final Type reportType)
	{
		final Report report = new Report();
		report.setType(reportType);
		report.setReportMedium(reportMedium);
		contextService.applyStoreContext(report);
		return report;
	}

	/**
	 * Publishes the report either to email or via servlet output stream.
	 * 
	 * @param reportType the report type to publish.
	 * @param reportMedium the report medium.
	 * @param response the servlet output stream.
	 */
	private void publishReport(final String reportType, final String reportMedium,
																final HttpServletResponse response)
	{
		publishReport(reportType, reportMedium, response, new HashMap<String, Object>());
	}

	/**
	 * Publishes the report either to email or via servlet output stream.
	 * 
	 * @param reportType the report type to publish.
	 * @param reportMedium the report medium.
	 * @param response the servlet output stream.
	 * @param model the model map associated with the report.
	 */
	private void publishReport(final String reportType, final String reportMedium,
																final HttpServletResponse response, final Map<String, Object> model)
	{
		// Put the response object in the model. If it is downloadable report,
		// this parameter
		// will be used otherwise it is ignored
		model.put(Constants.ReportPublisher.RESPONSE_KEY, response);

		final Report report = createNewReport(reportMedium, Type.valueOf(reportType));
		reportService.generateAndPublishReport(report, model);
	}

	/**
	 * Publishes the archived agreement report based on the archived agreement id.
	 * 
	 * @param agreementId the archived agreement id.
	 * @param response the http servlet response.
	 */
	private void publishArchivedAgreementReport(final Long agreementId, final HttpServletResponse response)
	{
		final HashMap<String, Object> model = new HashMap<String, Object>();
		model.put(Constants.Report.AGREEMENT_ID_KEY, agreementId);
		publishReport(Type.ARCHIVED_AGREEMENT_REPORT.toString(), Constants.ReportMedium.DOWNLOAD,
								response, model);
	}
	/**
	 * Generate the demand letter
	 * 
	 * @param agreementId the agreement whose report we need to publish.
	 * @param response the response.
	 */
	@RequestMapping(value = "/report/generateDemandLetter/{id}", method = RequestMethod.GET)
	public void generateDemandLetter(@PathVariable("id") final Long agreementId,
																final HttpServletResponse response)
																
	{
		final HashMap<String, Object> model = new HashMap<String, Object>();
		model.put(Constants.Report.AGREEMENT_ID_KEY, agreementId);
		publishReport(Type.DEMAND_LETTER_REPORT.toString(), Constants.ReportMedium.DOWNLOAD, response, model);
	}
	/**
	 * send a demand letter through the email
	 * @param agreementId the agreement whose report we need to publish.
	 * @param emailAddress the guest email address
	 * @param response
	 * @return String  the url need to redirect
	 */
	@RequestMapping(value = "/report/sendEmailDemandLetter/{id}/{email}", method = RequestMethod.GET)
	public String sendDemandLetter(@PathVariable("id") final Long agreementId,
			@PathVariable("email") final String emailAddress,
			final HttpServletResponse response)
																
	{
		ModelMap modelMap = new ModelMap();
		final Report report = new Report();
		report.setType(Type.DEMAND_LETTER_REPORT);
		report.setReportMedium(ReportMedium.EMAIL);
		modelMap.put("report", report);
		modelMap.put("appType", Constants.AppType.NONE);
		modelMap.put(Constants.ReportEmailPublisher.MAIL_TO, emailAddress);
		modelMap.put(Constants.Report.AGREEMENT_ID_KEY, agreementId);
		reportService.generateAndPublishReport(report, modelMap);
		Agreement attachedAgreement = Agreement.loadFull(agreementId);
		AgreementLog agreementLog=attachedAgreement.getAgreementLog();
		 if(agreementLog==null){
	       	 agreementLog= new AgreementLog();
	       	 agreementLog.setAgreement(attachedAgreement);
	        }
		 agreementLog.setDemandLetterStatus(agreementLog.getDemandLetterStatus()+1);
		 attachedAgreement.setAgreementLog(agreementLog);
		 attachedAgreement.merge();
		return "redirect:/agreementflow/show?isSend=true&agreementId="+agreementId.toString();
	}
}
