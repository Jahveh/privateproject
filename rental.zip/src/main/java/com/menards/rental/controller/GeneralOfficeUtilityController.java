/*
 * GeneralOfficeUtilityController.java
 */
package com.menards.rental.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.menards.rental.domain.ProductJSON;

/**
 * The Class GeneralOfficeUtilityController.
 */

@Controller
public class GeneralOfficeUtilityController {
	
	/**
	 * Index.
	 *
	 * @return the string
	 */
	@RequestMapping(value = "/generalofficeutility", method = RequestMethod.GET)
	public String index() {
		return "generalofficeutility/index";
	}
	
	/**
	 * For use by ajax json request for product information on the GO sku
	 * setup screen.
	 * 
	 * @param baseSKUId
	 * @return {@link ProductJSON} containing details for the base sku provided
	 */
  @RequestMapping(value="/generalofficeutility/item/{baseSKUId}", method = RequestMethod.GET)
  public @ResponseBody ProductJSON lookupBaseSkuDetails(@PathVariable(value = "baseSKUId") final Long baseSKUId) {
  	ProductJSON product = new ProductJSON(baseSKUId);
  	return product;
  }
  

	/**
	 * Index.
	 *
	 * @return the string
	 */
	@RequestMapping(value = "/generalofficeutility/requestOutOfStock", method = RequestMethod.GET)
	public String outOfStock() {
		return "generalofficeutility/requestOutOfStock";
	}
}




















