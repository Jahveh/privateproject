/*
 * SearchController.java
 */
package com.menards.rental.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.menards.rental.domain.ArchivedAgreement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.menards.rental.controller.command.SearchAgreementsCommand;
import com.menards.rental.domain.Agreement;
import com.menards.rental.service.ContextService;

/**
 * The Class SearchController.
 */
@Controller
public class SearchController {

	/** The context service. */
	@Autowired
	private ContextService contextService;

	/**
	 * Index.
	 *
	 * @param modelMap the model map
	 * @return the string
	 */
	@RequestMapping(value = "/storeutility/search", method = RequestMethod.GET)
	public String index(final ModelMap modelMap) {
        final SearchAgreementsCommand command = new SearchAgreementsCommand();
        contextService.applyStoreContext(command);
        return setupSearch(modelMap, command);
	}

	/**
	 * Index.
	 *
	 * @param modelMap the model map
	 * @return the string
	 */
	@RequestMapping(value = "/generalofficeutility/search", method = RequestMethod.GET)
	public String goIndex(final ModelMap modelMap) {
        modelMap.put("showStoreNumber", true);
        return setupSearch(modelMap, new SearchAgreementsCommand());
	}

    /**
	 * Inits the binder.
	 *
	 * @param binder the binder
	 */
	@InitBinder
	public void initBinder(final WebDataBinder binder) {
		final DateFormat format = new SimpleDateFormat("MM/dd/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(format, true));
	}

	/**
	 * Lookup agreement.
	 *
	 * @param searchAgreement the search agreement
	 * @param modelMap the model map
	 * @return the string
	 */
	@RequestMapping(value = "/storeutility/lookup", method = RequestMethod.POST)
	public String lookupAgreement(@ModelAttribute("searchAgreement") final SearchAgreementsCommand searchAgreement,
	        final ModelMap modelMap) {
		final Agreement agreement = Agreement.findAgreementByAgreementNumber(searchAgreement.getAgreementNumber());

		if (null == agreement) {
            modelMap.put("agreementNotFound", true);
            return "search/index";
		}

        return "redirect:/agreementflow/show?agreementId=" + agreement.getId();
	}

	/**
	 * Search agreements.
	 *
	 * @param command the command
	 * @param modelMap the model map
	 * @return the string
	 */
	@RequestMapping(value = "/storeutility/performsearch", method = RequestMethod.GET)
	public String searchAgreements(@ModelAttribute("searchAgreement") final SearchAgreementsCommand command,
	        final ModelMap modelMap) {
        return performSearch(command, modelMap);
	}

	/**
	 * Search agreements.
	 *
	 * @param command the command
	 * @param modelMap the model map
	 * @return the string
	 */
	@RequestMapping(value = "/generalofficeutility/performsearch", method = RequestMethod.GET)
	public String goSearchAgreements(@ModelAttribute("searchAgreement") final SearchAgreementsCommand command,
	        final ModelMap modelMap) {
        modelMap.put("showStoreNumber", true);
        return performSearch(command, modelMap);
	}

    /**
	 * Sets the context service.
	 *
	 * @param contextService the new context service
	 */
	public void setContextService(final ContextService contextService) {
		this.contextService = contextService;
	}

    /**
     * Performs the actual serarch of the agreement.
     * @param command the search comment which holds all the user filled values.
     * @param modelMap the model map which will be used to populate values.
     * @return the next view to render.
     */
    private String performSearch(final SearchAgreementsCommand command, final ModelMap modelMap) {
        final List<ArchivedAgreement> agreements = command.findArchivedAgreementsBySearchCriteria();
        if (agreements.isEmpty()) {
            modelMap.put("agreementNotFound", true);
            return "search/index";
        }

        modelMap.put("agreements", agreements);
        return "search/results";
    }

    /**
     * Sets up the search of the agreements.
     * @param modelMap the map using which the search is to be setup.
     * @param command the command that is to be put in th model map
     * @return the next view to render.
     */
    private String setupSearch(final ModelMap modelMap, final SearchAgreementsCommand command) {
        modelMap.put("searchAgreement", command);
        return "search/index";
    }
}
