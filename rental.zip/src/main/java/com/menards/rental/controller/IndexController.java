/*
 * IndexController.java
 */
package com.menards.rental.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.menards.rental.controller.command.SearchAgreementsCommand;
import com.menards.rental.domain.Item;
import com.menards.rental.domain.ReservationAgreement;
import com.menards.rental.service.ContextService;
import com.menards.rental.service.MenardsService;

/**
 * Handles the default landing page for the Rental Application.
 *
 * @author geoff
 */
@RequestMapping(value = "/index")
@Controller
public class IndexController {

	/** The context service. */
	@Autowired
	private ContextService contextService;

	/** The menards service. */
	@Autowired
	private MenardsService menardsService;

	/**
	 * Inits the binder.
	 *
	 * @param binder the binder
	 */
	@InitBinder
	public void initBinder(final WebDataBinder binder) {
		binder.registerCustomEditor(String.class, new StringTrimmerEditor(true)); // So
		// empty
		// strings
		// will
		// be
		// null
		// on
		// search
		// criteria
	}

	/**
	 * Shows the first page on the application.
	 *
	 * @param cmd the search parameters
	 * @param modelMap the model map in which we will populate the values that view can use to render itself.
	 * @return the string value representing the view to render.
	 */
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String list(@ModelAttribute("agreement") final SearchAgreementsCommand cmd, final ModelMap modelMap) {

		contextService.applyStoreContext(cmd);

		// Let's check first if the serial number of the item entered belongs to
		// this store.
		// If the item does not belongs to this store, tell the user that it's
		// not of this store.
		if (null != cmd.getSerialNumber()) {
			final Item item = Item.findItemBySerialNumber(cmd.getSerialNumber());
			if (null != item) {
				// Check if the item belongs to this store only
				if (!item.isBelongingToThisStore(cmd.getStoreNumber())) {
					modelMap.addAttribute("agreementNotFromThisStore", true);
					modelMap.addAttribute("store", menardsService.getStoreByStoreNumber(item.getStoreNumber()));
					return "/index";
				}
			}
		}

		modelMap.addAttribute("agreements", cmd.findAgreementsBySearchCriteria());
		modelMap.addAttribute("agreement", cmd);
		modelMap.addAttribute("reservationAgreements", ReservationAgreement
		        .findAllOpenReservationAgreementsByStore(menardsService.getCurrentStore()));
		return "/index";
	}

	/**
	 * Sets the context service.
	 *
	 * @param contextService the new context service
	 */
	public void setContextService(final ContextService contextService) {
		this.contextService = contextService;
	}

	/**
	 * Sets the menards service.
	 *
	 * @param menardsService the new menards service
	 */
	public void setMenardsService(final MenardsService menardsService) {
		this.menardsService = menardsService;
	}
}
