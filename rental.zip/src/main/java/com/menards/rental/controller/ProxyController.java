/*
 * SearchController.java
 */
package com.menards.rental.controller;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpParams;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.menards.rental.utils.MenardsProperties;
import com.menards.rental.utils.Constants;

/**
 * The Class ProxyController.
 */
@Controller
public class ProxyController {

	private static final String RESPONSE = "<HTML><HEAD><META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\"><META HTTP-EQUIV=\"Expires\" CONTENT=\"-1\"></HEAD><BODY>%s</BODY><HEAD><META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\"><META HTTP-EQUIV=\"Expires\" CONTENT=\"-1\"></HEAD></HTML>";
	
	// The logger
	private static final Logger log = Logger.getLogger(ProxyController.class);

    // The menards properties reference. 
    @Autowired
    private MenardsProperties menardsProperties;
	
	@SuppressWarnings("unchecked")
	/**
	 * Ping proxy.
	 *
	 * @param modelMap ModelMap
	 * @return String
	 */
	@RequestMapping(value = "/proxy/gim/ping", method = RequestMethod.GET)
	public @ResponseBody String pingGIMProxy(final ModelMap modelMap) {
		String result = "Failure";
		
		try {
			HttpClient httpclient = new DefaultHttpClient();
                        //Secure Protocol implementation.
			SSLContext ctx = SSLContext.getInstance("SSL");
                        //Implementation of a trust manager for X509 certificates
			X509TrustManager tm = new X509TrustManager() {

				public void checkClientTrusted(X509Certificate[] xcs,
						String string) throws CertificateException {
				}

				public void checkServerTrusted(X509Certificate[] xcs,
						String string) throws CertificateException {
				}

				public X509Certificate[] getAcceptedIssuers() {
					return new X509Certificate[0];
				}
			};
			ctx.init(null, new TrustManager[] { tm }, null);
			SSLSocketFactory ssf = new SSLSocketFactory(ctx, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

			ClientConnectionManager ccm = httpclient.getConnectionManager();
                        //register https protocol in httpclient's scheme registry
			SchemeRegistry sr = ccm.getSchemeRegistry();
			sr.register(new Scheme("https", 8443, ssf));

			String gimPath = menardsProperties.get(Constants.GuestInformationService.GIM_BASE_URL_PROP) + "/ping";
			HttpGet httpget = new HttpGet(gimPath);
			HttpParams params = httpclient.getParams();

			params.setParameter("param1", "paramValue1");

			httpget.setParams(params);
			ResponseHandler responseHandler = new BasicResponseHandler();
			Object responseBody;

			responseBody = httpclient.execute(httpget, responseHandler);

			if( null != responseBody ){
				// TODO - Remove later
				log.info("GIM web application pinged successfully");
	
				result = "Success";
			}
		} 
		catch( NoSuchAlgorithmException e ) {
			log.error("Caught NoSuchAlgorithmException pinging the GIM web application.", e);
		} 
		catch( ClientProtocolException e ) {
			log.error("Caught ClientProtocolException pinging the GIM web application.", e);
		} 
		catch( IOException e ) {
			log.error("Caught IOException pinging the GIM web application.", e);
		} 
		catch( Exception ex ) {
			log.error("Caught Exception pinging the GIM web application.", ex);
		}
		
		return result;
	}
	
	/**
	 * Ping proxy.
	 *
	 * @param modelMap ModelMap
	 * @return String
	 */
//	@RequestMapping(value = "/proxy/gim/ping", method = RequestMethod.GET)
//	public @ResponseBody String pingGIMProxy(final ModelMap modelMap) {
//		String result = "Failure";
//
//		HttpClient client = new DefaultHttpClient();
//		//String gimPath = menardsProperties.get(Constants.GuestInformationService.GIM_BASE_URL_PROP) + "/ping";
//		HttpHost host = new HttpHost("dmz-gim-d.menards.net", 8443);
//		ProtocolVersion protocol = new ProtocolVersion("https", 1,1);
//		RequestLine requestLine = new BasicRequestLine("GET", "gim/ping", protocol);
//		HttpRequest request = new BasicHttpRequest(requestLine);
//		try { 
//			HttpResponse response = client.execute(host, request);
//			log.debug(response.getStatusLine());
//			result = "Success";
//		} 
//		catch(ClientProtocolException cpe){
//			log.error("Caught ClientProtocolException pinging the GIM web application.", cpe);
//			cpe.printStackTrace();			
//		}
//		catch(IOException ioe){
//			log.error("Caught IOException pinging the GIM web application.", ioe);
//			ioe.printStackTrace();						
//		}
//		finally {
//		}		
//		return result;
//	}

	/**
	 * Ping proxy.
	 *
	 * @param modelMap ModelMap
	 * @param request HttpServletRequest
	 * @return String
	 */
//	@RequestMapping(value = "/proxy/gim/ping", method = RequestMethod.GET)
//	public @ResponseBody String pingGIMProxy(final ModelMap modelMap, HttpServletRequest request) {
//		String response = "Failure";
//		HttpsURLConnection connection = null;
//
//		URL serverAddress = null;
//		
//		//System.setProperty("javax.net.ssl.trustStore","C:\\_clients\\Menards\\POS\\gimlocal.keystore");
//		log.debug("Trust store path: " + menardsProperties.get(Constants.GuestInformationService.GIM_TRUST_STORE_PATH_PROP));
//		System.setProperty("javax.net.ssl.trustStore", menardsProperties.get(Constants.GuestInformationService.GIM_TRUST_STORE_PATH_PROP));
//		System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
//
//		try {
//			String gimPath = menardsProperties.get(Constants.GuestInformationService.GIM_BASE_URL_PROP) + "/ping";
//			serverAddress = new URL(gimPath);
//			// set up out communications stuff
//			connection = null;
//
//			// Set up the initial connection
//			connection = (HttpsURLConnection) serverAddress.openConnection();
//			
//			connection.setRequestMethod("GET");
//			connection.setDoOutput(true);
//			connection.setReadTimeout(10000);
//
//			connection.connect();
//
//			if (connection.getResponseCode() == 200) {
//				if( connection.getContentLength() > 1 ){
//					log.info("Successfully pinged the GIM web application at: " + gimPath);
//				}
//			} 
//			else {
//				log.error("Received response of " + connection.getResponseCode() + " attempting to access " + gimPath);
//			}
//		} 
//		catch (MalformedURLException e) {
//			log.error("Caught MalformedURLException pinging the GIM web application.", e);
//			e.printStackTrace();
//		} 
//		catch (ProtocolException e) {
//			log.error("Caught ProtocolException pinging the GIM web application.", e);
//			e.printStackTrace();
//		} 
//		catch (IOException e) {
//			log.error("Caught IOException pinging the GIM web application.", e);
//			e.printStackTrace();
//		} 
//		finally {
//			// close the connection, set all objects to null
//			connection.disconnect();
//			connection = null;
//		}
//		
//		return response;
//	}
}
