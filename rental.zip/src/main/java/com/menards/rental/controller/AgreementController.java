/*
 * AgreementController.java
 */
package com.menards.rental.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.menards.rental.barcode.Barcode;
import com.menards.rental.converters.DateToStringConverter;
import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.Guest;
import com.menards.rental.domain.KioskSKUDetail;
import com.menards.rental.repository.QuizRepository;
import com.menards.rental.security.MenardsUser;
import com.menards.rental.service.AgreementService;
import com.menards.rental.service.BarcodeService;
import com.menards.rental.service.BarcodeTypeStrategy;
import com.menards.rental.service.GuestService;
import com.menards.rental.service.external.KioskService;
import com.menards.rental.service.external.TeamService;
import com.menards.rental.utils.Constants;

/**
 * The Class AgreementController.
 */
@RequestMapping("/agreement/**")
@Controller
public class AgreementController {
	
	/** The log. */
	private static final Logger log = Logger.getLogger(AgreementController.class);

	/** The Team service. */
	@Autowired
	private TeamService teamService;

	@Autowired
	private QuizRepository questionRepository;
	
	/** The barcode service. */
	@Autowired
	private BarcodeService barcodeService;

    /** The setter for the agreement. */
    @Autowired
    private AgreementService agreementService;

    /** The guest service reference. */
    @Autowired
    private GuestService guestService;
    @Autowired
    private KioskService kioskService;

    /** The reference of code 39 barcode type strategy. */
    @Autowired
    @Qualifier(value = "code39BarcodeTypeStrategy")
    private BarcodeTypeStrategy code39BarcodeTypeStrategy;

    /** The reference of interleaved 25 barcode type strategy. */
    @Autowired
    @Qualifier(value = "interleaved25BarcodeTypeStrategy")
    private BarcodeTypeStrategy interleaved25BarcodeTypeStrategy;

    /**
	 * Adds the notes.
	 *
	 * @param agreementId the agreement id
	 * @param overallComment the overall comment
	 */
	@RequestMapping(value = "/agreement/addnotes/{id}", method = RequestMethod.POST)
	public void addNotes(@PathVariable(value = "id") final long agreementId,
	        @RequestParam("overallComment") final String overallComment) {
		final Agreement agreement = Agreement.findAgreement(agreementId);
		if (null != agreement) {
            agreement.setOverallComment(overallComment);
            agreement.persist();
		}
	}

	/**
	 * Agreement bar code.
	 *
	 * @param value the agreement id.
	 * @param response the response.
	 */
	@RequestMapping(value = "/agreement/barcode/{value}")
	public void agreementBarCode(@PathVariable(value = "value") final String value,
	        final HttpServletResponse response) {
        publishBarcode(value, code39BarcodeTypeStrategy, response);
    }

    /**
	 * Transaction bar code.
	 *
	 * @param value the agreement id.
	 * @param response the response.
	 */
	@RequestMapping(value = "/agreement/transaction/barcode/{value}")
	public void transactionBarCode(@PathVariable(value = "value") final String value,
	        final HttpServletResponse response) {
        publishBarcode(value, interleaved25BarcodeTypeStrategy, response);
	}

	/**
	 * Cancel agreement.
	 *
	 * @param agreementId the agreement id
	 * @param modelMap the model map
	 * @return the string
	 */
	@RequestMapping(value = "/agreement/cancel/{id}", method = RequestMethod.POST)
	public String cancelAgreement(@PathVariable(value = "id") final long agreementId, final ModelMap modelMap) {
		final Agreement agreement = Agreement.findAgreement(agreementId);

		if (null != agreement) {
            agreement.cancelAgreement();

            modelMap.addAttribute("agreement", agreement);
            modelMap.addAttribute("showReport", true);


            final ArrayList<Agreement> cancelledAgreements = new ArrayList<Agreement>();
            cancelledAgreements.add(agreement);

            agreementService.removeArchiveFor(cancelledAgreements);
            if (!agreementService.cancelAgreement(agreement)) {
                modelMap.addAttribute(Constants.Agreement.KIOSK_ERROR, true);
            }
            return "agreement/cancel";
		}
        log.error("Cannot cancel a null agreement.  To cancel the agreement, a valid agreement should be passed");
        return "redirect:/";
	}

    /**
     * Void agreement.
     *
     * @param agreementId the agreement id
     * @param voidApprovedByTeamMemberName the void approved by team member name
     * @param modelMap the model map
     * @return the string
     */
    @RequestMapping(value = "/agreement/void/{id}/{voidApprovedByName}", method = RequestMethod.POST)
    public String voidAgreement(@PathVariable(value = "id") final long agreementId,
                                @PathVariable(value = "voidApprovedByName") final Integer voidApprovedByTeamMemberName,
                                final ModelMap modelMap) {
        final Agreement agreement = Agreement.findAgreement(agreementId);
        if(null == agreement) {
            log.error("Cannot void a null agreement.  A valid agreement should be passed to sendVoidedAgreementToKiosk");
            return "redirect:/";
        }

        agreement.setVoidApprovedTeamMemberNumber(voidApprovedByTeamMemberName);
        final String oldAgreementNumber = agreement.getAgreementNumber();
        agreementService.voidAgreement(agreement);
        modelMap.addAttribute("agreement", agreement);

        if (!agreementService.sendVoidedAgreementToKiosk(agreement, oldAgreementNumber)) {
            modelMap.addAttribute("managerNames", teamService.getGeneralManagerForCurrentStore());
            modelMap.addAttribute(Constants.Agreement.KIOSK_ERROR, true);
            return "agreement/void";
        }

        modelMap.addAttribute("showReport", true);
        return "agreement/void";

    }

	/**
	 * Cancel or void.
	 *
	 * @param agreementId the agreement id
	 * @param modelMap the model map
	 * @return the string
	 */
	@RequestMapping(value = "/agreement/cancelOrVoid/{id}", method = RequestMethod.GET)
	public String cancelOrVoid(@PathVariable(value = "id") final long agreementId, final ModelMap modelMap) {
		final Agreement agreement = Agreement.findAgreement(agreementId);

		if (null == agreement) {
            log.error("Cannot cancelOrVoid a null agreement.  A valid agreement should be passed to cancelOrVoid");
			return "redirect:/";
		}

		modelMap.addAttribute("agreement", agreement);

		if (agreement.getAgreementStatus().isPending()) {
			return "agreement/cancel";
		}

		if (agreement.getAgreementStatus().isActive()) {
			modelMap.addAttribute("managerNames", teamService.getGeneralManagerForCurrentStore());
			return "agreement/void";
		}

		return "redirect:/";
	}

	/**
	 * Report.
	 *
	 * @param agreementId the agreement id
	 * @param modelMap the model map
	 * @return the string
	 */
	@RequestMapping(value = "/agreement/report/{id}", method = RequestMethod.GET)
	public String report(@PathVariable(value = "id") final long agreementId, final ModelMap modelMap) {
		final Agreement agreement = Agreement.loadFull(agreementId);
		questionRepository.loadCheckOutQuestionAnswersForAgreement(agreement);
        //agreementService.populateTMNameFromTMNumber(agreement);
		modelMap.addAttribute("agreement", agreement);
		return "/WEB-INF/views/reports/agreement.jspx";
	}


    @RequestMapping(value="/agreement/guest/{phoneNumber}", method=RequestMethod.GET)
    public @ResponseBody List<Guest> searchGuest(@PathVariable(value = "phoneNumber") final String phoneNumber) {
        return guestService.findGuestsByPhoneNumber(phoneNumber);
    }

	/**
	 * Sets the barcode service.
	 *
	 * @param barcodeService the new barcode service
	 */
	public void setBarcodeService(final BarcodeService barcodeService) {
		this.barcodeService = barcodeService;
	}

    /**
	 * Sets the Team service.
	 *
	 * @param teamService - team service
	 */
	public void setTeamService(final TeamService teamService) {
		this.teamService = teamService;
	}

    /**
     * The setter for the agreement service.
     * @param agreementService the value to set.
     */
    public void setAgreementService(final AgreementService agreementService) {
        this.agreementService = agreementService;
    }

    /**
     * The setter for the code 39 barcode type strategy.
     * @param code39BarcodeTypeStrategy the value to set.
     */
    public void setCode39BarcodeTypeStrategy(final BarcodeTypeStrategy code39BarcodeTypeStrategy) {
        this.code39BarcodeTypeStrategy = code39BarcodeTypeStrategy;
    }

    /**
     * The setter for the interleaved 25 barcode type strategy.
     * @param interleaved25BarcodeTypeStrategy the value to set.
     */
    public void setInterleaved25BarcodeTypeStrategy(final BarcodeTypeStrategy interleaved25BarcodeTypeStrategy) {
        this.interleaved25BarcodeTypeStrategy = interleaved25BarcodeTypeStrategy;
    }

    /**
     * The setter for the guest service.
     * @param guestService the value to set.
     */
    public void setGuestService(final GuestService guestService) {
        this.guestService = guestService;
    }

    /**
     * Publishes the barcode to the given servlet stream.
     * @param toGenerateValue the barcode value to generate.
     * @param typeStrategy the typeStrategy of barcode to be generated.
     * @param response the response stream where the barcode will be published.
     */
    private void publishBarcode(final String toGenerateValue,
                                final BarcodeTypeStrategy typeStrategy,
                                final HttpServletResponse response) {
        final Barcode barcode = barcodeService.getPNGImageBarCode(
                toGenerateValue, typeStrategy);

        response.setContentType(barcode.getImageType());
        response.setContentLength(barcode.getImage().length);
        try {
            FileCopyUtils.copy(barcode.getImage(), response.getOutputStream());
        } catch (final IOException e) {
            log.error(e.getMessage(), e);
        }
    }
    /**
     * generate the demand letter
     * @param agreementId the agreement id
     * @param modelMap the model map
     * @return the String URL
     */
	@RequestMapping(value = "/agreement/demandLetter/{id}", method = RequestMethod.GET)
	public String generateDemandLetter(@PathVariable(value = "id") final long agreementId, final ModelMap modelMap)
	{
		Agreement agreement = Agreement.loadFull(agreementId);
		modelMap.put("orginPay", agreement.getEffectiveRentalTotalExcludingDamageWaiver());
		StringBuffer names=new StringBuffer();
		BigDecimal sellAmount=new BigDecimal("0.0");
		MenardsUser user=(MenardsUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		modelMap.put("storeUser", user.getUsername());
		try {
			 if(null != agreement && null !=agreement.getId()){
				 agreement = agreementService.reCalculateAmount(new DateToStringConverter().toString(new Date()),agreement);
			  }
			 modelMap.put("newPay", agreement.getEffectiveRentalTotalExcludingDamageWaiver());
			 modelMap.put("returnDate",new DateToStringConverter().toString(agreement.getUpcomingDueBy().getTime()));
			 modelMap.put("checkoutDate",new DateToStringConverter().toString(agreement.getRentalDate().getTime()));
			
			 if(!agreement.getItemList().isEmpty()){
				 for (AgreementItem item:agreement.getItemList()) {
					 if(!(item.isReturned()||item.isReturnedAndPaidComplete())){
						names.append(item.getDescription());
						final KioskSKUDetail kioskSKUDetail = kioskService.getKioskSKUDetailFor(item.getItem().getSellingSkuValue());
					    if(kioskSKUDetail!=null){
					    	sellAmount.add(kioskSKUDetail.getChargeAmount());
					    }
					 }
				}
			 }
			 modelMap.put("sellAmount", sellAmount);
			 modelMap.put("noReturnAmout", sellAmount.add(agreement.getEffectiveRentalTotalExcludingDamageWaiver()));
			 modelMap.put("equipmentName", names.toString());
		} catch (Exception e) {
			 modelMap.put("sellAmount", sellAmount);
			 modelMap.put("noReturnAmout", sellAmount.add(agreement.getEffectiveRentalTotalExcludingDamageWaiver()));
			 modelMap.put("equipmentName", names.toString());
			 log.error(e.getMessage(), e);
		}
		modelMap.put("newAgreement", agreement);
		return "/WEB-INF/views/reports/_demandLetter.jspx";
	}
}
