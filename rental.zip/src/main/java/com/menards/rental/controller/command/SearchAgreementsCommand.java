/*
 * SearchAgreementsCommand.java
 */
package com.menards.rental.controller.command;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.menards.rental.domain.ArchivedAgreement;
import com.menards.rental.utils.Constants;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementStatus;
import com.menards.rental.domain.Guest;
import com.menards.rental.service.ContextService;

/**
 * This command implements the interface StoreNumberable which can be used to get the current store number,
 * from the context service.
 * 
 * @author deep
 */
public class SearchAgreementsCommand implements ContextService.StoreNumberable {

	/** The agreement number. */
	private String agreementNumber;

	/** The phone number. */
	private String phoneNumber;

	/** The serial number. */
	private Long serialNumber;

	/** The store number. */
	private Integer storeNumber;

	/** The start date. */
	private Date startDate;

	/** The end date. */
	private Date endDate;

	/** The base sku number. */
	private String baseSKUNumber;

	/** The guest. */
	private Guest guest;

	/**
	 * Find agreements by search criteria.
	 *
	 * @return the list
	 */
	public List<Agreement> findAgreementsBySearchCriteria() {
		final DetachedCriteria searchCriteria = DetachedCriteria.forClass(Agreement.class);
        searchCriteria.add(Restrictions.not(Restrictions.in("agreementStatus", new Object[] {
                AgreementStatus.findCancelled(), AgreementStatus.findVoided(), AgreementStatus.findCompleted() })));
        setupCriteria(searchCriteria);

		return Agreement.findAgreementsBySearchCriteria(searchCriteria);
	}

    /**
     * Finds the agreement for the given search criteria.  This method looks in the archived agreements table.
     * @return the list of archived agreements that match the search criteria.
     */
    public List<ArchivedAgreement> findArchivedAgreementsBySearchCriteria() {
        final DetachedCriteria searchCriteria = DetachedCriteria.forClass(ArchivedAgreement.class);
        setupCriteria(searchCriteria);
        return ArchivedAgreement.findArchivedAgreementsBySearchCriteria(searchCriteria);
    }

    /**
     * The method that setups the search criteria for he agreement or the archived agreement.
     * @param searchCriteria the criteria to set up.
     */
    private void setupCriteria(final DetachedCriteria searchCriteria) {
        if (null != storeNumber && !Constants.Action.EMPTY_STRING.equals(storeNumber)) {
            searchCriteria.add(Restrictions.eq("store.storeNumber", storeNumber));
        }

        if (null != agreementNumber && !Constants.Action.EMPTY_STRING.equals(agreementNumber)) {
            searchCriteria.add(Restrictions.ilike("agreementNumber",
                    agreementNumber.substring(0, 5) + "-" + agreementNumber.substring(5), MatchMode.ANYWHERE));
        }

        if (null != startDate) {
            final Calendar startDateCalendar = Calendar.getInstance();
            startDateCalendar.setTime(startDate);
            searchCriteria.add(Restrictions.ge("rentalDate", startDateCalendar));
        }

        if (null != endDate) {
            final Calendar endDateCalendar = Calendar.getInstance();
            endDateCalendar.setTime(endDate);
            endDateCalendar.set(Calendar.HOUR, 23);
            endDateCalendar.set(Calendar.MINUTE, 59);
            endDateCalendar.set(Calendar.SECOND, 59);
            searchCriteria.add(Restrictions.le("rentalDate", endDateCalendar));
        }

        if ((null != baseSKUNumber) && !baseSKUNumber.equals(Constants.Action.EMPTY_STRING)) {
            searchCriteria.createCriteria("items")
                    .createCriteria("item")
                    .createCriteria("product")
                    .createCriteria("skuInfo.baseSKU")
                    .add(Restrictions.eq("value", Long.parseLong(baseSKUNumber
                            .replace("-", Constants.Action.EMPTY_STRING))));
        }

        if (null != serialNumber) {
            searchCriteria.createCriteria("items").createCriteria("item").add(
                    Restrictions.eq("serialNumber", serialNumber));
        }

        if (null != phoneNumber) {
            searchCriteria.createCriteria("guest").add(Restrictions.eq("phoneNumber", phoneNumber));
        }

        if (null != guest) {
            final DetachedCriteria guestCriteria = searchCriteria.createCriteria("guest");
            if ((null != guest.getPhoneNumber()) && !guest.getPhoneNumber().equals(Constants.Action.EMPTY_STRING)) {
                guestCriteria.add(Restrictions.eq("phoneNumber", guest.getPhoneNumber()));
            }
            if ((null != guest.getFirstName()) && !guest.getFirstName().equals(Constants.Action.EMPTY_STRING)) {
                guestCriteria.add(Restrictions.ilike("firstName", guest.getFirstName()));
            }
            if ((null != guest.getLastName()) && !guest.getLastName().equals(Constants.Action.EMPTY_STRING)) {
                guestCriteria.add(Restrictions.ilike("lastName", guest.getLastName()));
            }
            if ((null != guest.getCompanyName()) && !guest.getCompanyName().equals(Constants.Action.EMPTY_STRING)) {
                guestCriteria.add(Restrictions.ilike("companyName", guest.getCompanyName()));
            }
        }

        searchCriteria.addOrder(Order.asc("agreementNumber"));
    }

	/**
	 * Gets the agreement number.
	 *
	 * @return the agreement number
	 */
	public String getAgreementNumber() {
		return agreementNumber;
	}

	/**
	 * Gets the base sku number.
	 *
	 * @return the base sku number
	 */
	public String getBaseSKUNumber() {
		return baseSKUNumber;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Gets the guest.
	 *
	 * @return the guest
	 */
	public Guest getGuest() {
		return guest;
	}

	/**
	 * Gets the phone number.
	 *
	 * @return the phone number
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Gets the serial number.
	 *
	 * @return the serial number
	 */
	public Long getSerialNumber() {
		return serialNumber;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * Gets the store number.
	 *
	 * @return the store number
	 */
	public Integer getStoreNumber() {
		return storeNumber;
	}

	/**
	 * Sets the agreement number.
	 *
	 * @param agreementNumber the new agreement number
	 */
	public void setAgreementNumber(final String agreementNumber) {
		this.agreementNumber = agreementNumber;
	}

	/**
	 * Sets the base sku number.
	 *
	 * @param baseSKUNumber the new base sku number
	 */
	public void setBaseSKUNumber(final String baseSKUNumber) {
		this.baseSKUNumber = baseSKUNumber;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(final Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * Sets the guest.
	 *
	 * @param guest the new guest
	 */
	public void setGuest(final Guest guest) {
		this.guest = guest;
	}

	/**
	 * Sets the phone number.
	 *
	 * @param phoneNumber the new phone number
	 */
	public void setPhoneNumber(final String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * Sets the serial number.
	 *
	 * @param serialNumber the new serial number
	 */
	public void setSerialNumber(final Long serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(final Date startDate) {
		this.startDate = startDate;
	}

    /**
     * {@inheritDoc}
     */
	public void setStoreNumber(final Integer storeNumber) {
		this.storeNumber = storeNumber;
	}
}
