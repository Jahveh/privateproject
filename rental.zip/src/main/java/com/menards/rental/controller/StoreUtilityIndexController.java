/*
 * StoreUtilityIndexController.java
 */
package com.menards.rental.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.menards.rental.converters.ReportTypeEditor;
import com.menards.rental.domain.Report;
import com.menards.rental.service.ContextService;
import com.menards.rental.service.ReportService;
import com.menards.rental.utils.Constants;

/**
 * The Class StoreUtilityIndexController.
 * @author deep
 */
@Controller
public class StoreUtilityIndexController {

	/** The report service. */
	@Autowired
	private ReportService reportService;

	/** The context service. */
	@Autowired
	private ContextService contextService;

	/**
	 * Request report.
	 *
	 * @param modelMap the model map.
	 * @return the string representing the next view id to be rendered.
	 */
	@RequestMapping(value = "/storeutility/requestreport", method = RequestMethod.GET)
	public String requestReport(final ModelMap modelMap) {
		modelMap.put("report", new Report());
		modelMap.put("appType", Constants.AppType.STORE_UTILITY);
		return "/storeutility/requestreport";
	}

	/**
	 * Sets the context service.
	 *
	 * @param contextService the new context service
	 */
	public void setContextService(final ContextService contextService) {
		this.contextService = contextService;
	}

	/**
	 * Sets the report service.
	 *
	 * @param reportService the new report service
	 */
	public void setReportService(final ReportService reportService) {
		this.reportService = reportService;
	}

	/**
	 * Store utility index page will be served by this method.
	 *
	 * @return the string representing the view id to be rendered.
	 */
	@RequestMapping(value = "/storeutility", method = RequestMethod.GET)
	public String storeUtility() {
		return "/storeutility/index";
	}

	/**
	 * Inits the binder.
	 *
	 * @param request the request
	 * @param binder the binder
	 */
	@InitBinder
	protected void initBinder(final HttpServletRequest request, final ServletRequestDataBinder binder) {
		binder.registerCustomEditor(Report.Type.class, new ReportTypeEditor());
	}
}
