/*
 * ItemController.java
 */
package com.menards.rental.controller;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.menards.rental.service.*;
import com.menards.rental.service.external.KioskCommunicationException;
import com.menards.rental.utils.Constants;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.menards.rental.barcode.Barcode;
import com.menards.rental.converters.CustomCalendarEditor;
import com.menards.rental.decorator.LazyItemList;
import com.menards.rental.domain.Item;
import com.menards.rental.domain.ItemStatus;
import com.menards.rental.domain.Product;

/**
 * The Class ItemController.
 * @author deep
 */
@Controller
public class ItemController {

	/** The log. */
	private static final Logger log = Logger.getLogger(ItemController.class);

	/** The reservation service. */
	@Autowired
	private ReservationService reservationService;

	/** The barcode service. */
	@Autowired
	private BarcodeService barcodeService;

	/** The context service. */
	@Autowired
	private ContextService contextService;

    /** The item service reference. */
    @Autowired
    private ItemService itemService;

    /** The reference of code 39 barcode type strategy. */
    @Autowired
    @Qualifier(value = "code39BarcodeTypeStrategy")
    private BarcodeTypeStrategy code39BarcodeTypeStrategy;

	/**
	 * Gets the list of rental items for product.
	 *
	 * @param productId the product id
	 * @param modelMap the model map
	 * @return the list of rental items for product
	 */
	@RequestMapping(value = "/storeutility/itemListForProduct", method = RequestMethod.POST)
	public String getListOfRentalItemsForProduct(@RequestParam("productId") final Long productId,
	        final ModelMap modelMap) {
		final Product product = Product.findProduct(productId);

		final List<Item> itemListForProduct = Item.findAllItemsByProductAndStoreNumber(product, contextService
		        .getStoreNumber());

		final LazyItemList itemList = new LazyItemList();
		itemList.getItems().addAll(itemListForProduct);

		modelMap.addAttribute("itemList", itemList);
		modelMap.addAttribute("productList", Product.findAllProducts());
		modelMap.addAttribute("productId", productId);
		modelMap.addAttribute("statusList", ItemStatus.findAllItemStatuses());
		return "/item/updateRentalStatus";
	}

	/**
	 * Inits the binder.
	 *
	 * @param binder the binder
	 */
	@InitBinder
	public void initBinder(final WebDataBinder binder) {
		binder.registerCustomEditor(Calendar.class, new CustomCalendarEditor());
	}

	/**
	 * Item bar code.
	 *
	 * @param barcodeValue the barcode value
	 * @param response the response
	 * @return the string
	 */
	@RequestMapping(value = "/item/barcode/{barcodeValue}")
	public String itemBarCode(@PathVariable(value = "barcodeValue") final long barcodeValue,
	        final HttpServletResponse response) {

		final Barcode barcode = barcodeService.getPNGImageBarCode(String.valueOf(barcodeValue),
                code39BarcodeTypeStrategy);

		response.setContentType(barcode.getImageType());
		response.setContentLength(barcode.getImage().length);

		//FileCopyUtil takes care of closing the stream
		try {
			FileCopyUtils.copy(barcode.getImage(), response.getOutputStream());
		} catch (final IOException e) {
			log.error(e.getMessage(), e);
		}
		return null;
	}

	/**
	 * Sets the barcode service.
	 *
	 * @param barcodeService the new barcode service
	 */
	public void setBarcodeService(final BarcodeService barcodeService) {
		this.barcodeService = barcodeService;
	}

	/**
	 * Sets the context service.
	 *
	 * @param contextService the new context service
	 */
	public void setContextService(final ContextService contextService) {
		this.contextService = contextService;
	}

	/**
     * The setter for the item service.
     * @param itemService the value.
     */
    public void setItemService(final ItemService itemService) {
        this.itemService = itemService;
    }

	/**
	 * Sets the reservation service.
	 *
	 * @param reservationService the new reservation service
	 */
	public void setReservationService(final ReservationService reservationService) {
		this.reservationService = reservationService;
	}

    /**
	 * Update item status.
	 *
	 * @param itemList the item list.
     * @param map the model map used to populate error if any.
	 * @return the string value representing the next view id.
	 */
	@RequestMapping(value = "/storeutility/submitRentalStatus", method = RequestMethod.POST)
	public String updateItemStatus(final LazyItemList itemList, final ModelMap map) {

        try {
            itemService.updateItemStatus(itemList);
            return "redirect:/storeutility";
        } catch (final IllegalStateException e) {
            log.error(e.getMessage(), e);
            map.put(Constants.Agreement.RENTABLE_ITEMS_EXCEEDED_KIOSK_ERROR, true);
        } catch (final IllegalArgumentException e) {
            log.error(e.getMessage(), e);
            map.put(Constants.Agreement.CANNOT_CHANGE_STATUS_TO_RENTED_ERROR, true);
        } catch (final KioskCommunicationException e) {
            log.error(e.getMessage(), e);
            map.put(Constants.Agreement.KIOSK_ERROR, true);
        }
        map.put("productList", Product.findAllProducts());
        return "/item/updateRentalStatus";
	}

    /**
	 * Update rental status of item.
	 *
	 * @param modelMap the model map
	 * @return the string
	 */
	@RequestMapping(value = "/storeutility/updateRentalStatus", method = RequestMethod.GET)
	public String updateRentalStatusOfItem(final ModelMap modelMap) {

		modelMap.addAttribute("productList", Product.findAllProducts());

		return "/item/updateRentalStatus";
	}
}
