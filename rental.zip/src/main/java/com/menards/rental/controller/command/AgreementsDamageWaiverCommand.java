/*
 * AgreementsDamageWaiverCommand.java
 */
package com.menards.rental.controller.command;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;

import com.menards.rental.domain.AgreementItem;

/**
 * The agreements damage waiver command used on the agreement summary page.
 * @author deep
 */
public class AgreementsDamageWaiverCommand {

	/** The item list. */
	private List<AgreementItem> itemList = LazyList.decorate(new ArrayList<AgreementItem>(), FactoryUtils
	        .instantiateFactory(AgreementItem.class));

	/** The id. */
	private long id;

	/**
	 * Instantiates a new agreements damage waiver command.
	 */
	public AgreementsDamageWaiverCommand() {

	}

	/**
	 * Instantiates a new agreements damage waiver command.
	 *
	 * @param id the id
	 * @param items the items
	 */
	public AgreementsDamageWaiverCommand(final long id, final ArrayList<AgreementItem> items) {
		this.id = id;
		this.itemList = items;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * Gets the item list.
	 *
	 * @return the item list
	 */
	public List<AgreementItem> getItemList() {
		return itemList;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(final long id) {
		this.id = id;
	}

	/**
	 * Sets the item list.
	 *
	 * @param itemList the new item list
	 */
	public void setItemList(final List<AgreementItem> itemList) {
		this.itemList = itemList;
	}
}
