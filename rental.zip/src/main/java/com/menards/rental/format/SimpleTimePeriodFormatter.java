/*
 * SimpleTimePeriodFormatter.java
 */
package com.menards.rental.format;

import com.menards.rental.utils.Constants;

/**
 * Display a time period as a user-readable string.
 * 
 * @author deep
 */
public class SimpleTimePeriodFormatter {

	/**
	 * Get the format for the duration where the floating point represents the
	 * number of hours (and parts of hours). e.g. 1.5 would be 1 and a half
	 * hours or 1 Hr 30 Min.
	 * 
	 * @param duration
	 *            The number of hours to format where the remainder is the
	 *            percentage of a whole hour
	 * @return A string in the format of [n Hr] m Min.
	 */
	public String format(final Double duration) {
		if (null == duration) {
			return "";
		}

		final StringBuilder durationText = new StringBuilder();
		final int hours = (int) Math.floor(duration);

		// Get the minutes calculation
		final int minutes = (int) Math.floor((duration - hours) * Constants.Calculation.MINUTES_IN_AN_HOUR);

		// Check if hour is more than 0 hours
		if (hours > 0) {
			durationText.append(hours).append(" Hr ");
		}

		// Get the minutes part
		if (minutes > 0) {
			durationText.append(minutes).append(" Min. ");
		}
		return durationText.toString();
	}
}
