package com.menards.rental.repository;

public class BaseRepository {

}
