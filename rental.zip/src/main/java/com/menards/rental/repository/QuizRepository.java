package com.menards.rental.repository;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.menards.rental.domain.Agreement;
import com.menards.rental.domain.AgreementItem;
import com.menards.rental.domain.questions.Quiz;
import com.menards.rental.dto.QuestionAnswerDto;
import com.menards.rental.dto.QuestionDto;
import com.menards.rental.dto.QuestionFollowUpDto;

@Repository
public class QuizRepository{
	
	@Autowired
	private SessionFactory rentalSessionFactory;
	
	private static String GET_CHECKOUT_QUESTIONS_BY_ITEM_SERIAL_NUMBER = 
			"select m.item_serial_number, m.question_id, question_text, answer_type_id, answer_text from ("
			+ " SELECT ITEM_SERIAL_NUMBER_PARAM item_serial_number, category_map.question_id question_id, question_text, q.answer_type_id answer_type_id"
			+ " FROM question_category_sku_map sku_map"
			+ " JOIN question_category_map category_map ON sku_map.category_id = category_map.question_category_id"
			+ " JOIN question q ON category_map.question_id = q.question_id AND sku_id = ("
			+ " select sku from rental_sku where sku_id = (select base_sku  from product where product_id = (select product_id from item where serial_nbr = ITEM_SERIAL_NUMBER_PARAM))"
			+ " ) AND category_map.question_type_id = 2"
			+ " ) m left join ("
			+ " select rental_agreement_id, question_type_id, question_id, item_serial_number, answer_text"
			+ " from question_answers where question_type_id = 2 and rental_agreement_id = RENTAL_AGREEMENT_ID_PARAM and item_serial_number = ITEM_SERIAL_NUMBER_PARAM"
			+ " ) s on m.item_serial_number = s.item_serial_number and m.question_id = s.question_id";
	
	private static String GET_CHECKIN_QUESTIONS_BY_ITEM_SERIAL_NUMBER = 
			"select m.item_serial_number, m.question_id, question_text, answer_type_id, answer_text from ("
			+ " SELECT ITEM_SERIAL_NUMBER_PARAM item_serial_number, category_map.question_id question_id, question_text, q.answer_type_id answer_type_id"
			+ " FROM question_category_sku_map sku_map"
			+ " JOIN question_category_map category_map ON sku_map.category_id = category_map.question_category_id"
			+ " JOIN question q ON category_map.question_id = q.question_id AND sku_id = ("
			+ " select sku from rental_sku where sku_id = (select base_sku  from product where product_id = (select product_id from item where serial_nbr = ITEM_SERIAL_NUMBER_PARAM))"
			+ " ) AND category_map.question_type_id = 1"
			+ " ) m left join ("
			+ " select rental_agreement_id, question_type_id, question_id, item_serial_number, answer_text"
			+ " from question_answers where question_type_id = 1 and rental_agreement_id = RENTAL_AGREEMENT_ID_PARAM and item_serial_number = ITEM_SERIAL_NUMBER_PARAM"
			+ " ) s on m.item_serial_number = s.item_serial_number and m.question_id = s.question_id";
	
	private static String INSERT_INTO_QUESTION_ANSWERS = 
			"insert into question_answers(rental_agreement_id, question_type_id, question_id, item_serial_number, answer_text) "
			+ " values (:rental_agreement_id, :question_type_id, :question_id, :item_serial_number, :answer_text)";
	
	private static String GET_QUESTION_FOLLOW_UP = 
			"select question_id, question_type_id, question_category_id, question_follow_up_type_id, follow_up_trigger, follow_up_content"
			+ " from question_follow_up where question_id = QUESTION_ID_PARAM and question_type_id = QUESTION_TYPE_ID_PARAM and question_category_id = ("
			+ " select category_id from question_category_sku_map where sku_id = ("
			+ " select sku from rental_sku where sku_id = (select base_sku  from product where product_id = (select product_id from item where serial_nbr = ITEM_SERIAL_NUMBER_PARAM))"
			+ " ))";
	
	
	public QuestionFollowUpDto getCheckInQuesionFollowUp(Long workingSerialNumber, Integer workingQuestionId) {
		final Session session = rentalSessionFactory.openSession();
        try {
            session.beginTransaction();
            String query = getCheckInQuestionFollowUpQuery(workingSerialNumber.toString(), workingQuestionId.toString());
            SQLQuery sqlQuery = session.createSQLQuery(query);
            sqlQuery.addScalar("question_id", Hibernate.INTEGER);
            sqlQuery.addScalar("question_type_id", Hibernate.INTEGER);
            sqlQuery.addScalar("question_category_id", Hibernate.INTEGER);
            sqlQuery.addScalar("question_follow_up_type_id", Hibernate.INTEGER);
            sqlQuery.addScalar("follow_up_trigger", Hibernate.STRING);
            sqlQuery.addScalar("follow_up_content", Hibernate.STRING);
            List resultList = sqlQuery.list();
            return convertToQuestionFollowUpDto(resultList);
        } finally {
            session.getTransaction().commit();
            session.close();
        }
	}
	
	public QuestionFollowUpDto getCheckOutQuesionFollowUp(Long workingSerialNumber, Integer workingQuestionId) {
		final Session session = rentalSessionFactory.openSession();
        try {
            session.beginTransaction();
            String query = getCheckOutQuestionFollowUpQuery(workingSerialNumber.toString(), workingQuestionId.toString());
            SQLQuery sqlQuery = session.createSQLQuery(query);
            sqlQuery.addScalar("question_id", Hibernate.INTEGER);
            sqlQuery.addScalar("question_type_id", Hibernate.INTEGER);
            sqlQuery.addScalar("question_category_id", Hibernate.INTEGER);
            sqlQuery.addScalar("question_follow_up_type_id", Hibernate.INTEGER);
            sqlQuery.addScalar("follow_up_trigger", Hibernate.STRING);
            sqlQuery.addScalar("follow_up_content", Hibernate.STRING);
            List resultList = sqlQuery.list();
            return convertToQuestionFollowUpDto(resultList);
        } finally {
            session.getTransaction().commit();
            session.close();
        }
	}
	
	
	private String getCheckInQuestionFollowUpQuery(String itemSerialNumber, String questionId) {
		String query = GET_QUESTION_FOLLOW_UP.replace("ITEM_SERIAL_NUMBER_PARAM", itemSerialNumber);
		query = query.replace("QUESTION_ID_PARAM", questionId);
		query = query.replace("QUESTION_TYPE_ID_PARAM", "1");
		return query;
	}
	
	private String getCheckOutQuestionFollowUpQuery(String itemSerialNumber, String questionId) {
		String query = GET_QUESTION_FOLLOW_UP.replace("ITEM_SERIAL_NUMBER_PARAM", itemSerialNumber);
		query = query.replace("QUESTION_ID_PARAM", questionId);
		query = query.replace("QUESTION_TYPE_ID_PARAM", "2");
		return query;
	}
	
	public void persistCheckoutQuestionAnswer(List<QuestionAnswerDto> questionAnswerDtoList) {
		final Session session = rentalSessionFactory.openSession();
        try {
            session.beginTransaction();
            for (QuestionAnswerDto questionAnswerDto : questionAnswerDtoList) {
                SQLQuery sqlQuery = session.createSQLQuery(INSERT_INTO_QUESTION_ANSWERS);
                sqlQuery.setInteger("rental_agreement_id", questionAnswerDto.getRentalAgreementId());
                sqlQuery.setInteger("question_type_id", questionAnswerDto.getQuestionTypeId());
                sqlQuery.setInteger("question_id", questionAnswerDto.getQuestionId());
                sqlQuery.setLong("item_serial_number", questionAnswerDto.getItemSerialNumber());
                sqlQuery.setString("answer_text", questionAnswerDto.getAnswerText());
                sqlQuery.executeUpdate();
            }
        } finally {
            session.getTransaction().commit();
            session.close();
        }
		
	}
	
	public List<QuestionDto> getCheckInQuestionsByItemSerialNumber(Long itemSerialNumber, Long agreementId) {
		final Session session = rentalSessionFactory.openSession();
        try {
            session.beginTransaction();
            String query = getCheckInQuestionByItemSerialNumberQuery(itemSerialNumber, agreementId);
            SQLQuery sqlQuery = session.createSQLQuery(query);
            sqlQuery.addScalar("item_serial_number", Hibernate.BIG_INTEGER);
            sqlQuery.addScalar("question_id", Hibernate.INTEGER);
            sqlQuery.addScalar("question_text", Hibernate.STRING);
            sqlQuery.addScalar("answer_type_id", Hibernate.INTEGER);
            sqlQuery.addScalar("answer_text", Hibernate.STRING);
            List resultList = sqlQuery.list();
            return convertToDtoList(resultList);
        } finally {
            session.getTransaction().commit();
            session.close();
        }
	}
	
	private QuestionFollowUpDto convertToQuestionFollowUpDto(List<Object[]> list) {
		if (list.size() != 1) {
			return null;
		}
		QuestionFollowUpDto questionFollowUpDto = new QuestionFollowUpDto();
		Object[] objArray = list.get(0);
		if (objArray[0] != null) {
			questionFollowUpDto.setQuestionId((Integer)objArray[0]);
		}
		if (objArray[1] != null) {
			questionFollowUpDto.setQuestionTypeId((Integer)objArray[1]);
		}
		if (objArray[2] != null) {
			questionFollowUpDto.setQuestionCategoryId((Integer)objArray[2]);
		}
		if (objArray[3] != null) {
			questionFollowUpDto.setQuestionFollowUpTypeId((Integer)objArray[3]);
		}
		if (objArray[3] != null) {
			questionFollowUpDto.setFollowUpTrigger((String)objArray[4]);
		}
		if (objArray[4] != null) {
			questionFollowUpDto.setFollowUpContent((String)objArray[5]);
		}

		return questionFollowUpDto;
	}
	
	public List<QuestionDto> getCheckOutQuestionsByItemSerialNumber(Long itemSerialNumber, Long agreementId) {
		final Session session = rentalSessionFactory.openSession();
        try {
            session.beginTransaction();
            String query = getCheckOutQuestionByItemSerialNumberQuery(itemSerialNumber, agreementId);
            SQLQuery sqlQuery = session.createSQLQuery(query);
            sqlQuery.addScalar("item_serial_number", Hibernate.BIG_INTEGER);
            sqlQuery.addScalar("question_id", Hibernate.INTEGER);
            sqlQuery.addScalar("question_text", Hibernate.STRING);
            sqlQuery.addScalar("answer_type_id", Hibernate.INTEGER);
            sqlQuery.addScalar("answer_text", Hibernate.STRING);
            List resultList = sqlQuery.list();
            return convertToDtoList(resultList);
        } finally {
            session.getTransaction().commit();
            session.close();
        }
	}
	
	public void loadCheckOutQuestionAnswersForAgreement(Agreement agreement) {
		Long agreementId = agreement.getId();
		for (AgreementItem agreementItem : agreement.getItems()) {
			Long itemSerialNumber = agreementItem.getItem().getSerialNumber();
			agreementItem.setCheckOutQuestionList(this.getCheckOutQuestionsByItemSerialNumber(itemSerialNumber, agreementId));
		}
	}
	
	private List<QuestionDto> convertToDtoList(List<Object[]> list) {
		List<QuestionDto> questionDtoList = new ArrayList<QuestionDto>(list.size());
		for (Object[] objArray : list) {
			QuestionDto dto = new QuestionDto();
			if (objArray[0] != null) {
				dto.setItemSerialNumber(((BigInteger)objArray[0]).longValue());
			}
			if (objArray[1] != null) {
				dto.setQuestionId((Integer)objArray[1]);
			}
			if (objArray[2] != null) {
				dto.setQuestionText((String)objArray[2]);
			}
			if (objArray[3] != null) {
				dto.setAnswerTypeId((Integer)objArray[3]);
			}
			if (objArray[4] != null) {
				dto.setAnswer((String)objArray[4]);
			}
			questionDtoList.add(dto);
		}
		return questionDtoList;
	}

	private String getCheckOutQuestionByItemSerialNumberQuery(Long itemSerialItem, Long agreementId) {
		String query = GET_CHECKOUT_QUESTIONS_BY_ITEM_SERIAL_NUMBER.replaceAll("ITEM_SERIAL_NUMBER_PARAM", itemSerialItem.toString());
		query = query.replace("RENTAL_AGREEMENT_ID_PARAM", agreementId.toString());
		return query;
	}
	
	private String getCheckInQuestionByItemSerialNumberQuery(Long itemSerialItem, Long agreementId) {
		String query = GET_CHECKIN_QUESTIONS_BY_ITEM_SERIAL_NUMBER.replace("ITEM_SERIAL_NUMBER_PARAM", itemSerialItem.toString());
		query = query.replace("RENTAL_AGREEMENT_ID_PARAM", agreementId.toString());
		return query;
	}
	
	public Quiz getOne() {
		final Session session = rentalSessionFactory.openSession();
        try {
            session.beginTransaction();
            return (Quiz)session.get(Quiz.class, new Integer(1));
        } finally {
            session.getTransaction().commit();
            session.close();
        }
	}
	
	
}

