/**
 * MenardsProperties.java
 */
package com.menards.rental.utils;

import org.apache.log4j.Logger;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * The menards properties class that holds the properties of the application.
 *
 * @author deep
 */
@Component
public class MenardsProperties {

    /** The log4j logger reference. */
    private static final Logger logger = Logger.getLogger(MenardsProperties.class);

    /** The actual properties reference. */
    private final Properties properties = new Properties();

    /**
     * Loads the properties from the menards properties file.
     */
    @PostConstruct
    public void loadProperties() {
        try {
            loadPropertiesFrom(Constants.Properties.DEFAULT_FILE_PATH);
        } catch (final IOException e) {
            logger.error(e.getMessage(), e);
        }
    }

    /**
     * Returns the property value for the given key.
     * @param key the key for which we have to find the property value.
     * @return the String value representing the property value.
     */
    public String get(final String key) {
        return properties.getProperty(key);
    }

    /**
     * Returns the url of the applicaiton which is the combination of protocol, host, port and context root.
     * @return the String value representing the application url.
     */
    public String getApplicationURL() {
        return get(Constants.Properties.SERVER_PROTOCOL_KEY) + Constants.Properties.PROTOCOL_POST_FIX
                + get(Constants.Properties.SERVER_HOST_KEY) + Constants.Properties.PATH_SEPERATOR
                + get(Constants.Properties.CONTEXT_ROOT_KEY) + Constants.Properties.PATH_SEPERATOR;
    }

    /**
     * Returns the value of kiosk host if any.
     * @return the value of kiosk host if any.
     */
    public String getKioskHost() {
        return properties.getProperty(Constants.Properties.KIOSK_HOST);
    }
    
    /**
     * Returns the DNS suffix set in the properties file.
     * 
     * @return dns suffix to use for the kiosk server name.
     */
    public String getDNSSuffix()
    {
    	return properties.getProperty("menards.app.dns.suffix");    	
    }

    /**
     * The method that returns true if the my menards stub mode is enabled.  This mode is enabled for dev environments
     * only.
     * @return Boolean indicating whether the MyMenards stub mode is enabled.
     */
    public boolean isMyMenardsStubModeEnabled() {
        return Boolean.parseBoolean(get(Constants.Properties.MY_MENARDS_STUB_MODE));
    }

    /**
     * The method that will emulate that a stub store is setup.
     * @return the boolean indicating whether the stub store is setup.
     */
    public boolean isStubStoreSetup() {
        return Boolean.parseBoolean(get(Constants.Properties.STUB_STORE_SETUP));
    }

    /**
     * Loads properties from the given file.
     * @throws IOException if file is not found or in case of any error.
     * @param filePath the path from where the file is to be loaded.
     */
    private void loadPropertiesFrom(final String filePath) throws IOException {
    	InputStream input = null;

    	try {
	        input = (new ClassPathResource(filePath)).getInputStream();
	
	        //load all the properties from this file
	        properties.load(input);
    	} catch(final Exception e) {
    		logger.error("Caught " + e.getClass().getName() + " attempting to load properties from " + filePath);
    	} finally {
    		if (input != null) {
    			try {
		    		//we have loaded the properties, so close the file handle
			        input.close();
    			} catch(final Exception e) {
    				// Nothing to do
    			}
        		input = null;
    		}
    	}
    }
}
