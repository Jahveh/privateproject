/*
 * Constants.java
 */
package com.menards.rental.utils;

import java.math.BigDecimal;

/**
 * The class that holds all the constants in the application.  There are inner classes in this class which hold
 * constants for a specific class.
 * @author deep
 */
public class Constants {

    /**
     * The class holding Agreement Constants.
     */
    public class Agreement {

        /**
         * The item status.
         */
        public static final String ITEM_STATUS = "itemStatus";

        public static final String QUESTION_NOT_ANSWERED = "questionNotAnswered";
        
        public static final String NEED_FEM_APPROVAL = "needFEMApproval";
        
        public static final String CHECK_IN_TEAM_MEMBER_REQUIRED = "checkInTeamMemberRequired";
        
        /**
         * Not found key.
         */
        public static final String NOT_FOUND = "notFound";

        /**
         * Items not found key.
         */
        public static final String ITEMS_NOT_FOUND = "itemsNotFound";

        /**
         * Already added key.
         */
        public static final String ALREADY_ADDED = "alreadyAdded";

        /**
         * On hold key.
         */
        public static final String ON_HOLD = "onHold";

        /**
         * kiosk error key.
         */
        public static final String KIOSK_ERROR = "kioskError";

        /**
         * The found key.
         */
        public static final String FOUND = "found";

        /**
         * The conflicting reservations key.
         */
        public static final String CONFLICTING_RESERVATIONS = "agreementConflictingReservations";

        /**
         * The min age limit not met key.
         */
        public static final String MIN_AGE_LIMIT_NOT_MET = "minimumAgeLimitNotMet";

        /**
         * The manager names key.
         */
        public static final String MANAGER_NAMES = "managerNames";

        /**
         * The selected price override manager name key.
         */
        public static final String SELECTED_PRICE_OVERRIDE_MANAGER_NAME = "selectedPriceOverrideManagerName";

        /**
         * The selected quantity override manager name key.
         */
        public static final String SELECTED_QUANTITY_OVERRIDE_MANAGE_NAME = "selectedQuantityOverrideManagerName";

        /**
         * The override reasons key.
         */
        public static final String OVERRIDE_REASONS = "overrideReasons";

        /**
         * The agreement key.
         */
        public static final String AGREEMENT = "agreement";

        /**
         * The has error key.
         */
        public static final String HAS_ERROR = "hasError";

        /**
         * The show report key.
         */
        public static final String SHOW_REPORT = "showReport";

        /**
         * The questions key.
         */
        public static final String QUESTIONS = "questions";

        /**
         * The checkin item serial number key.
         */
        public static final String CHECKIN_ITEM_SERIAL_NUMBER = "checkinItemSerialNumber";

        /**
         * No items selected key.
         */
        public static final String NO_ITEMS_SELECTED_ERROR_KEY = "agreementNoItemsError";

        /**
         * The Constant that represents agreement initial value.
         */
        public static final int AGREEMENT_NUMBER_INITIAL_VALUE = 40000;
        
        /**
         * The Constant that represents agreement maximum value before resetting.
         */
        public static final int AGREEMENT_NUMBER_MAX_VALUE = 49999;

        /** No items have been selected for checkin error key. */
        public static final String NO_ITEMS_SELECTED_FOR_CHECKIN_ERROR_KEY = "noItemsSelectedForCheckinError";

        /** No checkin questions have been setup error key. */
        public static final String NO_CHECKLIST_QUESTIONS_SETUP_ERROR_KEY = "noChecklistQuestionsError";

        /** The agreement was canceled by system comment. */
        public static final String AGREEMENT_CANCELED_BY_SYSTEM_COMMENT =
                " Agreement was cancelled by System - Hold Status exceeded 2 hours.";

        /** The constant representing whether the agreement is editable or not. */
        public static final String NOT_EDITABLE = "notEditable";

        /** The constant representing the rentable items exceeded then those setup in kiosk. */
        public static final String RENTABLE_ITEMS_EXCEEDED_KIOSK_ERROR = "rentableItemsExceeded";

        /**
         * The constant representing the fact that we cannot change the status to rented if no active agreement is
         * found.
         */
        public static final String CANNOT_CHANGE_STATUS_TO_RENTED_ERROR = "cannotChangeStatusToRented";

        /** The suffix that suggests that the agreement has not be sent to the kiosk server even once. */
        public static final String NO_REVISION_SUFFIX = "000";

        /** The constant representing whether the guest chose to exit or not. */
        public static final String GUEST_EXIT = "guestExit";
        
        /** The guest information received from the central repository is null or empty. */
        public static final String NO_GUEST_INFORMATION_RECEIVED_FROM_CENTRAL_REPOSITORY_ERROR = "noGuestInformationRecievedFromCentralRepository";

        /** The received agreement is null. */
        public static final String NO_AGREEMENT_AVAILABLE_IN_FLOW_SCOPE_ERROR = "noAgreementAvailableInFlowScope";
        
        /** Unable to decode the guest information xml string. */
        public static final String UNABLE_TO_DECODE_GUEST_INFORMATION_ERROR = "unableToDecodeGuestInformation";
        
        /** The decoded the guest information xml string is null or empty. */
        public static final String NO_DECODED_GUEST_INFORMATION_ERROR = "noDecodedGuestInformation";
        
        /** The guest information could not be retrieved successfully. */
        public static final String UNABLE_TO_RETRIEVE_GUEST_INFORMATION_ERROR = "unableToRetrieveGuestInformation";     
        
        /** The guest information did not contain a bill to address, which we treat as the address of record. */
        public static final String NO_BILL_TO_ADDRESS_PROVIDED_ERROR = "noBillToAddressProvided";

        /** The agreement does not contain vehicle rental item details. */
        public static final String VEHICLE_RENTAL_ITEM_DETAILS_MISSING_ERROR = "vehicleRentalItemDetailsMissing";
    }

    /**
     * The Class AppType that holds constatns for the app type.
     * @author lalit
     */
    public static class AppType {

        /**
         * The Constant STORE_UTILITY which representing the store utility app.
         */
        public static final String STORE_UTILITY = "StoreUtility";

        /**
         * The Constant GO_UTILITY which representing the go utility app.
         */
        public static final String GO_UTILITY = "GoUtility";

        /**
         * The these types of report are not shown on the screen they are just sent.
         */
        public static final String NONE = "None";
    }

    /**
     * Barcode Constants holds constatns that will be used while doing the barcode pocessing.
     * @author paresh
     */
    public class Barcode {

        /**
         * The narrowest bar width value.
         */
        public static final double NARROW_BAR_WIDTH = 1.0;

        /**
         * The width factor value.
         */
        public static final double WIDTH_FACTOR = 3;

        /**
         * The bar height value.
         */
        public static final double BAR_HEIGHT = 12.5;

        /**
         * The resolution value.
         */
        public static final int RESOLUTION = 150;
    }

    /**
     * Constant to control the scale of Big decimal operation.
     *
     * @author lalit
     */
    public static class Calculation {

        /**
         * Control of scale, useful in dividing and multiplying.
         */
        public static final int SCALE_CONTROL = 6;

        /**
         * Scale on which the currency values should be maintained.
         */
        public static final int CURRENCY_SCALE = 2;

        /**
         * the lower double value that we consider as zero.
         */
        public static final double LOWER_ZERO_VALUE = -0.001;

        /**
         * The higher double value that we consider as zero.
         */
        public static final double HIGHER_ZERO_VALUE = 0.001;

        /**
         * The constant representing minutes in an hour.
         */
        public static final int MINUTES_IN_AN_HOUR = 60;

        /**
         * The constant representing twelve hours.
         */
        public static final int TWELVE_HOURS = 12;

        /**
         * The constant representing twenty four hours.
         */
        public static final int TWENTY_FOUR_HOURS = 24;

        /**
         * The Constant representing number of milli seconds in an hour.
         */
        public static final double MILLI_SECONDS_IN_A_HOUR = 3600000.0;

        /**
         * The Constant representing number of milli seconds in a day.
         */
        public static final double MILLI_SECONDS_IN_A_DAY = MILLI_SECONDS_IN_A_HOUR * 24;

        /**
         * The Constant representing number of milli seconds in a year.
         */
        public static final double MILLI_SECONDS_IN_A_YEAR = MILLI_SECONDS_IN_A_DAY * 365;

        /** The percentage converter value. */
        public static final double PERCENTAGE_CONVERTER = 100.0;
    }

    /**
     * The Class DamageWaiver holds constants for the damamge wavier calculations.
     * @author deep
     */
    public static class DamageWaiver {

        /**
         * The default damamge waiver amount.
         */
        public static final BigDecimal DAMAGE_WAIVER_DEFAULT_AMOUNT = new BigDecimal("0");

        /**
         * The damage waiver percentage.
         */
        public static final BigDecimal DAMAGE_WAIVER_PERCENTAGE = new BigDecimal("0.10");
    }

    /**
     * The Constants that hold values of jms message listener interfaces.
     * @author deep
     */
    public class JMSMessageListener {

        /**
         * The default date format that comes to us via jms message.
         */
        public static final String DEFAULT_DATE_FORMAT = "MM/dd/yy HHmmss";
    }

    /**
     * Kiosk constants class holds constatns for the kiosk related communiation.
     * @author deep
     */
    public class Kiosk {

        /**
         * The port id.
         */
        public static final int KIOSK_PORT = 4777;

        /**
         * The kiosk client id.
         */
        public static final String CLIENT_ID = "MYMENARDS";

        /**
         * The error message type response from kiosk.
         */
        public static final String ERROR_RESPONSE_TYPE = "ERROR";

        /** The properties file extension. */
        public static final String PROPERTIES_FILE_EXTENSION = ".properties";

        /** The request property prefix. */
        public static final String REQUEST_PROPERTY_PREFIX = "RequestProperty.";
    }

    /**
     * The notification service constatns holds values for notification service.
     * @author deep
     */
    public class NotificationService {
        /**
         * The GM override name key.
         */
        public static final String GM_OVERRIDE_NAME = "generalManagerName";

        /**
         * The item description key.
         */
        public static final String ITEM_DESCRIPTION = "itemDescription";

        /**
         * The checkout times csv key.
         */
        public static final String CHECKOUT_TIMES_CSV = "checkoutTimesCSV";

        /**
         * The policy number.
         */
        public static final String INSURANCE_POLICY_NUMBER = "policyNumber";
        
        /**
         * The agreement number.
         */
        public static final String RENTAL_AGREEMENT_NUMBER = "agreementNumber";
    }

    /**
     * The Class Report holds constants that will be used while generating reports.
     * @author deep
     */
    public class Report {

        /**
         * The constant for store key.
         */
        public static final String STORE_KEY = "store";

        /**
         * The constant for the report data key.
         */
        public static final String REPORT_DATA_KEY = "reportData";

        /**
         * The constant for the hearder key.
         */
        public static final String HEADERS_KEY = "headers";

        /**
         * The constant for properites of the report.
         */
        public static final String PROPERTIES_KEY = "properties";

        /**
         * The start date key.
         */
        public static final String START_DATE_KEY = "startDate";

        /**
         * The end date key.
         */
        public static final String END_DATE_KEY = "endDate";

        /**
         * The report start date key.
         */
        public static final String REPORT_START_DATE_KEY = "reportStartDate";

        /**
         * The report end date key.
         */
        public static final String REPORT_END_DATE_KEY = "reportEndDate";

        /**
         * The product key.
         */
        public static final String PRODUCT_KEY = "product";

        /** The agreement item key constants. */
        public static final String AGREEMENT_ITEM_KEY = "agreementItem";

        /** The agreement item key constants. */
        public static final String AGREEMENT_KEY = "agreement";

        /** The reservation agreement key. */
        public static final String RESERVATION_AGREEMENT_KEY = "reservationAgreement";

        /** The cancelled agreements key. */
        public static final String CANCELLED_AGREEMENTS_KEY = "cancelledAgreements";

        /** The constant for the agreement report path. */
        public static final String AGREEMENT_REPORT_PATH = "agreement/report/";

        /** The reservation report path. */
        public static final String RESERVATION_REPORT_PATH = "reservation/report/";
        /** The demand letter report path. */
        public static final String AGREEMENT_DEMANDLETTER_PATH = "agreement/demandLetter/";
        /** The agreement id key. */
        public static final String AGREEMENT_ID_KEY = "agreementId";

        /** The constant stating whether the report is empty. */
        public static final String IS_EMPTY_KEY = "isEmpty";
    }

    /**
     * The Class ReportEmailPublisher holds constants that will be used while publishing reports via email.
     * @author lalit
     */
    public class ReportEmailPublisher {

        /**
         * The Constant mail to.
         */
        public static final String MAIL_TO = "mailTo";

        /**
         * The Constant mail CC.
         */
        public static final String MAIL_CC = "mailCC";
        
        /**
         * The Constant for mail from key.
         */
        public static final String MAIL_FROM = "mailFrom";

        /**
         * The default from address for automated mails.
         */
        public static final String FROM_MAIL_FOR_AUTOMATED_MAILS = "automated-email@menard-inc.com";

        //TODO: change this to a configuration file or web service lookup!!
		public static final String TO_HELPDESK = "maanders@menards.net";

		/**
		 * The constant for the email subject.
		 */
		public static final String MAIL_SUBJECT = "mailSubject";

    }

    /**
     * The Class ReportFormatter holds constants that will be used while formatting the reports.
     * @author deep
     */
    public class ReportFormatter {

        /**
         * The velocity file extension.
         */
        public static final String VELOCITY_FILE_EXTENSION = ".vm";

        /**
         * The mail templates folder path.
         */
        public static final String REPORT_TEMPLATES_FOLDER_PATH = "mailTemplates/";

        /**
         * The compiled report folder path for jasper reports.
         */
        public static final String COMPILED_REPORT_FOLDER_PATH = "jasperReports/";

        /**
         * The csv suffix.
         */
        public static final String CSV_REPORT_SUFFIX = "_CSV";

        /**
         * The jasper file extension.
         */
        public static final String JASPER_FILE_EXTENSION = ".jasper";

        /**
         * The reservation agreement id key.
         */
        public static final String RESERVATION_AGREEMENT_ID_KEY = "reservation_agreement_id";

        /**
         * The logo path key for menards logo.
         */
        public static final String LOGO_PATH_KEY = "logo_path";

        /**
         * The logo path for menards logo.
         */
        public static final String LOGO_PATH = COMPILED_REPORT_FOLDER_PATH + "menards_logo.jpg";
    }

    /**
     * The Class ReportMedium holds constants for the report medium current it could be email or download.
     * @author lalit
     */
    public class ReportMedium {

        /**
         * The constant to say that the report is to be published via email.
         */
        public static final String EMAIL = "email";

        /**
         * The constant that says that report is to be downloaded.
         */
        public static final String DOWNLOAD = "download";
    }

    /**
     * The Class ReportPublisher holds constants that will be used while publishing the report.
     * @author deep
     */
    public class ReportPublisher {

        /**
         * The response key.
         */
        public static final String RESPONSE_KEY = "response";

        /**
         * The content type key.
         */
        public static final String CONTENT_TYPE_KEY = "contentType";

        /**
         * The report data key.
         */
        public static final String DATA_KEY = "data";

        /** The constant that represents the binary data. */
        public static final String BINARY_DATA_KEY = "binaryData";

        /**
         * The csv content type key.
         */
        public static final String CSV_CONTENT_TYPE = "text/csv";

        /**
         * The current date key.
         */
        public static final String CURRENT_DATE = "currentDate";
        /** The constant for the current time. */
        public static final String CURRENT_TIME = "currentTime";
        /**
         * The attachment key.
         */
        public static final String ATTACHMENT_KEY = "attachment";

        /** The pdf content type constant. */
        public static final String PDF_CONTENT_TYPE = "application/pdf";

        /** The plain content type. */
        public static final String PLAIN_CONTENT_TYPE = "text/plain";

        /** The constant representing the png image format. */
        public static final String PNG_FORMAT_TYPE = "png";
    }

    /**
     * Team Service class that holds constatns that will be used by the team service.
     * @author lalit
     */
    public class TeamService {

        /**
         * The general Manager position.
         */
        public static final String GENERAL_MANAGER = "GM";
        
        /**
         * The assistant general Manager position.
         */
        public static final String ASSISTANT_GENERAL_MANAGER = "AGM";

        /** The general manager post fix constant. */
        public static final String GENERAL_MANAGER_EMAIL_POST_FIX = "GeneralManager@menards.com";
        
        /** The front end manager post fix constant. */
        public static final String FRONT_END_MANAGER_EMAIL_POST_FIX = "Frontend@menards.com";
    }

    /**
     * The Class Version that holds constatns that will be used while showing the app version on the application.
     * @author deep
     */
    public class Version {

        /**
         * The Constant that represents the manifest file path.
         */
        public static final String MANIFEST_PATH = "META-INF/MANIFEST.MF";

        /**
         * The application version key.
         */
        public static final String APPLICATION_VERSION_KEY = "Implementation-Version";

        /**
         * The application build number key.
         */
        public static final String APPLICATION_BUILD_NUMBER_KEY = "Implementation-Build";
    }

    /**
     * The class that represends various date formats in our application.
     * @author deep
     */
    public class DateFormat {
        /**
         * The default date time format.
         */
        public static final String DATE_TIME_FORMAT = "MM/dd/yyyy hh:mm aa";

        /**
         * The default date format.
         */
        public static final String DATE_FORMAT = "MM/dd/yyyy";

        /** The time format for the email. */
        public static final String TIME_FORMAT = "hh:mm aa";
    }

    /**
     * The class that holds constants related to various actions.
     *
     * @author deep
     */
    public class Action {
        /**
         * The constant that represents the success event.
         */
        public static final String SUCCESS = "success";

        /** The empty string constant. */
        public static final String EMPTY_STRING = "";

        /** The key that represents the sync inventory was successful. */
        public static final String SYNC_INVENTORY_SUCCESS = "syncInventorySuccessful";

        /** The key that represents the sync inventory failed. */
        public static final String SYNC_INVENTORY_FAILURE = "syncInventoryError";
    }

    /**
     * The constants around reservations are held in this class.
     * @author deep
     */
    public class Reservation {
        /** The constant representing the already reserved error. */
        public static final String ALREADY_RESERVED_ERROR = "alreadyReserved";

        /** The invalid item reservation combination error. */
        public static final String INVALID_ITEM_RESERVATION_COMBINATION_ERROR = "invalidItemReservationCombination";

        /** No reservations found error. */
        public static final String NO_RESERVATIONS_FOUND_ERROR = "noReservationsFound";

        /** could not save reservations error. */
        public static final String COULD_NOT_SAVE_RESERVATIONS_ERROR = "couldNotSaveReservation";

        /** The reservation agreement key. */
        public static final String RESERVATION_AGREEMENT_KEY = "reservationAgreement";

        /** The reservation key. */
        public static final String RESERVATION_KEY = "reservation";
        
        /** The conflicting reservations key. */
        public static final String CONFLICTING_RESERVATIONS_KEY = "conflictingReservations";

        /** The item list key. */
        public static final String ITEM_LIST_KEY = "itemList";

        /** The reservation list key. */
        public static final String RESERVATION_LIST_KEY = "reservationList";

        /** The rentable items not found error code. */
        public static final String RENTABLE_ITEMS_NOT_FOUND_ERROR = "rentableItemsNotFound";

        /** The reservation was canceled by system comment. */
        public static final String RESERVATION_CANCELED_BY_SYSTEM_COMMENT =
                " Reservation was cancelled by System - Past Reservation Time";
    }

    /**
     * The class that holds the constants for the yard service.
     */
    public static class YardServiceConstants {

        /** The prefix for the stores dns name. */
        public static final String DNS_PREFIX = "sys"; 
	}
	
	/**
     * The class that hold constants related to the daos.
     * @author deep
     */
    public class Dao {
        /** The operator that we need to prefix or post fix in like queries. */
        public static final String LIKE_PRE_POST_FIX = "%";
    }

    /**
     * The class that holds constants related to the cleanup code.
     * @author deep
     */
    public class Cleanup {
        /** The default value after which the agreement that are not paid for should be canceled. */
        public static final int DEFAULT_AGREEMENT_CLEANUP_HOURS_THRESHOLD = -2;

        /** The default value after which all open reservations will be canceled. */
        public static final int DEFAULT_RESERVATION_CLEANUP_MINUTES_THRESHOLD = -15;
    }

    /**
     * The class that holds keys to all the properties of the app.
     * @author deep
     */
    public class Properties {
        /** The key that represents the archive root path. */
        public static final String ARCHIVE_ROOT_PATH_KEY = "menards.archive.root.path";

        /** The key for the server protocol. */
        public static final String SERVER_PROTOCOL_KEY = "menards.app.server.protocol";

        /** The key for the server host. */
        public static final String SERVER_HOST_KEY = "menards.app.server.host";

        /** The key for the server port. */
        public static final String SERVER_PORT_KEY = "menards.app.server.port";

        /** The key for the context root. */
        public static final String CONTEXT_ROOT_KEY = "menards.app.context.root";

        /** The constant for the properties file path. */
        public static final String DEFAULT_FILE_PATH = "rentalAgreements/rentalAgreements.properties";

        /** The protocol post fix value. */
        public static final String PROTOCOL_POST_FIX = "://";

        /** The port seperator constant. */
        public static final String PORT_SEPERATOR = ":";

        /** The path seperator value. */
        public static final String PATH_SEPERATOR = "/";
        /** The kiosk host key value. */
        public static final String KIOSK_HOST = "kiosk.override";

        /** The property that represents the my menards stub mode. */
        public static final String MY_MENARDS_STUB_MODE = "mymenards.stub.mode";

        /** The constant indicating that the stub store is setup */
        public static final String STUB_STORE_SETUP = "menards.stub.store.setup";
    }

    /**
     * The class that holds keys to all the properties of the app.
     * @author deep
     */
    public class ApplicationControl {
        /** The constant for the application control properties file path. */
        public static final String APP_CONTROL_FILE_PATH = "rentalAgreements/rental_appcontrol.properties";
        
        /** The constant for the GIM bypass property. */
        public static final String APP_CONTROL_BYPASS_GIM = "menards.bypass.gim";
    }
    
    /**
     * The class that holds constants for archive information.
     * @author deep
     */
    public class Archive {

        /** The constatns for the signature for rental agreement label. */
        public static final String SIGNATURE_FOR_RENTAL_AGREEMENT_LABEL = "Signature for Rental Agreement ";

        /** The constant for my rental for this merchandise label. */
        public static final String RENTAL_MERCHANDISE_TNC_LABEL
                = "My rental of this merchandise constitutes my agreement to "
                + "all terms and conditions set forth in the rental agreement(s).";
    }
    
    /**
     * The class that holds constants for the guest information service.
     * @author deep
     */
    public class GuestInformationService {
        /** The constants for the proxy url to ping GIM web application */
        public static final String GIM_PROXY_URL = "gimProxyURL";

        /** The constants for the base url to the GIM web application */
        public static final String GIM_BASE_URL = "gimBaseURL";
        
        /** The constants for the base url property to the GIM web application */
        public static final String GIM_BASE_URL_PROP = "menards.guest.info.baseURL";

        /** The constants for the return url to be passed to the GIM web application */
        public static final String GIM_RETURN_URL = "gimReturnURL";
        
        /** The constants for the no response url to be used if the GIM web application is unresponsive */
        public static final String GIM_NO_RESPONSE_URL = "gimNoResponseURL";
        
        /** The constants for the return url to be passed to the GIM web application */
        public static final String GIM_BACK_BUTTON_RETURN_URL = "gimBackButtonReturnURL";
    }

    /**
     * The class that holds keys for the agreement action.
     * @author deep
     */
    public class AgreementAction {
        /** The constant for the GIM bypass property. */
        public static final String GIM_BYPASS_ENABLED = "gimBypassEnabled";

    }
}
