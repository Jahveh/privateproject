/**
 * ApplicationControl.java
 */
package com.menards.rental.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.core.io.ClassPathResource;

/**
 * The dynamic properties class that periodically reads a control properties file to determine application behavior.
 *
 * @author deep
 */
public class ApplicationControl {

	// The logger
	private static final Logger log = Logger.getLogger(ApplicationControl.class);

    /** The actual properties reference. */
    private Properties properties = null;
    
    /** The last loaded time */
    private Date lastLoaded = null;

    private static final ApplicationControl appControl = new ApplicationControl();

    private static final int LOAD_INTERVAL = 300000; // 5 minutes
    
    /**
     * Returns the value of gim bypass setting.
     * If the property doesn't exist, or the file cannot be loaded, this will always return false.
     * 
     * @return boolean.
     */
    public static boolean isGIMBypassEnabled() {
    	Boolean response = Boolean.FALSE;
    	
    	String value = getProperty(Constants.ApplicationControl.APP_CONTROL_BYPASS_GIM);
    	if( null != value ){
    		if( "true".equalsIgnoreCase(value) ){
    			response = Boolean.TRUE;
    		}
    	}
        return response;
    }
    
    /**
     * Property accessor method that will periodically reload the file.
     * @param propKey String
     * @return String 
     */
    private static String getProperty(String propKey){
    	if( appControl.shouldReload() ){
    		synchronized( appControl ){
    	    	if( appControl.shouldReload() ){
    	    		appControl.loadProperties();
    	    	}
			}
    	}
		return appControl.getPropertyValue(propKey);
    }

    
    /**
     * Property accessor method that will periodically reload the file.
     * @param propKey String
     * @return String 
     */
    private String getPropertyValue(String propKey){
    	if( null != properties ){ // Should only be null if the file doesn't exist.
    		return properties.getProperty(propKey);
    	}
    	else{
    		return null;
    	}
    }

    private boolean shouldReload(){
    	Date currTime = new Date();
    	if( null == properties || properties.isEmpty() || null == lastLoaded 
    			|| ((currTime.getTime() - lastLoaded.getTime()) >= LOAD_INTERVAL) ){
    		return true;
    	}
    	else{
    		return false;
    	}
    }
    
    /**
     * Loads properties from the given file.
     */
    private void loadProperties() {
    	InputStream input = null;

    	try {
	        input = (new ClassPathResource(Constants.ApplicationControl.APP_CONTROL_FILE_PATH)).getInputStream();
	
	        //load all the properties from this file
	        properties = new Properties();
	        properties.load(input);
	        lastLoaded = new Date();
    	} catch(final Exception e) {
    		log.error("Caught " + e.getClass().getName() 
    				+ " attempting to load properties from " 
    				+ Constants.ApplicationControl.APP_CONTROL_FILE_PATH);
    	} finally {
    		if (input != null) {
    			try {
			        input.close();
    			} catch(final Exception e){}
        		input = null;
    		}
    	}
    }
}
