//Add new validators for date
$(function() {
    $.validator.addMethod(
         'strictDate',
         function(value, element) {
        	 if(this.optional(element)){
                 return true;
                }
      	   var parsedDate = value.split ("/");
     	   if (parsedDate.length != 3) {
      		   return false;
      	   }
      	   var day, month, year;
      	   month = parsedDate[0]-1;
      	   day = parsedDate[1];
      	   year = parsedDate[2];

      	   var objDate = new Date (value);
      	   if ( month == objDate.getMonth() &&
      			 day == objDate.getDate()  &&
      			 year == objDate.getFullYear()){
      		   return true;
      	   }
     	   return false;
  	  }, "Please enter a valid Date in MM/DD/YYYY format");
    
    $.validator.addMethod(
            'futureTimeStamp',
            function(value, element) { 
            if(this.optional(element)){
               return true;
              }
         	   if(new Date(value) > new Date()){
        	      return true;
         	   }else{
         	      return false;
         	   }
     	  }, "Please enter a valid date in Future");
    
    $.validator.addMethod(
            'pastTimeStamp',
            function(value, element) {  
            	 if(this.optional(element)){
                     return true;
                    }
         	   if(new Date(value) < new Date()){
        	      return true;
         	   }else{
         	      return false;
         	   }
     	  }, "Please enter a valid date in Past");

    $.validator.addMethod("groupDatePast", function(value, element) {
        return (new Date(value) < new Date($(".groupDateFuture").val()));
    }, "Check-in date should be after Check-out date");
  
});



