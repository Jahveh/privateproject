function setupFormForValidation() {
    var container = $('div.container');
    $("#productInformationForm").validate({
        errorContainer: container,
        errorLabelContainer: $("ul", container),
        wrapper: 'li',
        meta: "validate",
        messages: {
           "usageTrackingText": "Please enter usage tracking text",
           "skuInfo.baseSKU.id": "Please select the Base SKU",
           "skuInfo.incrementalSKU.id": "Please select the Incremental SKU",
           "skuInfo.sellingSKU.id": "Please select the Selling SKU", 
           "skuInfo.surchargeSKU.id": "Please select the Surcharge SKU"
        }
    });
}

function enableOrDisableUsageTrackingText(isUsageTrackingEnabled) {
    var disabled = "disabled";
    var methodToCall = "removeClass";
    if(isUsageTrackingEnabled) {
        disabled = "";
        methodToCall = "addClass";
    }
    $("#usageTrackingTextId").attr("disabled", disabled);
    $("#usageTrackingTextId")[methodToCall]("required");
}

function addOnChangeToUsageTrackingRequired() {
    $("#usageTackingRequired").change(function() {
        enableOrDisableUsageTrackingText(true);
    });

    $("#usageTackingNotRequired").change(function() {
        enableOrDisableUsageTrackingText(false);
    });
}

$(function() {
    setupFormForValidation();
    addOnChangeToUsageTrackingRequired();
    enableOrDisableUsageTrackingText($("#usageTackingRequired").is(':checked'));
});