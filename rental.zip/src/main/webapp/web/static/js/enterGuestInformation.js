function toggleRequired(isEveryFieldToBeValidated, classNameToFind, classNameToAddOrRemove) {
    var methodToInvoke = "addClass";
    if (!isEveryFieldToBeValidated) methodToInvoke = "removeClass";

    $(classNameToFind)[methodToInvoke](classNameToAddOrRemove);
}
function toggleRequiredFields(isEveryFieldToBeValidated) {
    toggleRequired(isEveryFieldToBeValidated, ".toggleRequired", "required");
    toggleRequired(isEveryFieldToBeValidated, ".toggleRequiredGroup", "required_group");
    toggleRequired(isEveryFieldToBeValidated, ".toggleRequiredRadioGroup", "required_radio_group");
}

function handleFirstNameAndLastNameChangeEvent(firstNameId, lastNameId, isFirstAndLastNameMandatoryNoMatterWhat) {
    if (isFirstAndLastNameMandatoryNoMatterWhat)  {
        makeFirstAndLastNameOnlyMandatory();
        return;
    }

    if ($(firstNameId).val() == "") {
        if ($(lastNameId).val() == "" && $("#_guest_companyName_id").val() == "") {
            makeFirstAndLastNameOnlyMandatory();
            $("#_guest_companyName_id_label").html("Guest Company Name <span class='red'>*</span>");
        } else if($(lastNameId).val() == "") {
            makeFirstAndLastNameOptional();
        } else {
            makeFirstAndLastNameOnlyMandatory();
        }
        return;
    }
    makeFirstAndLastNameOnlyMandatory();
    return;
}

function setupSearchFirstnameLastnameCompanyValidations(isFirstAndLastNameMandatoryNoMatterWhat) {

    $("#_guest_firstName_id").change(function() {
        handleFirstNameAndLastNameChangeEvent("#_guest_firstName_id",
                "#_guest_lastName_id", isFirstAndLastNameMandatoryNoMatterWhat);
    })

    $("#_guest_lastName_id").change(function() {
        handleFirstNameAndLastNameChangeEvent("#_guest_lastName_id",
                "#_guest_firstName_id", isFirstAndLastNameMandatoryNoMatterWhat);
    });

    $("#_guest_companyName_id").change(function() {
        if(isFirstAndLastNameMandatoryNoMatterWhat) {
            makeFirstAndLastNameOnlyMandatory();
            return;
        }

        if ($("#_guest_companyName_id").val() == "") {
            if ($("#_guest_firstName_id").val() == "" && $("#_guest_lastName_id").val() == "") {
                makeFirstAndLastNameOnlyMandatory();
                $("#_guest_companyName_id_label").html("Guest Company Name <span class='red'>*</span>");
                return;
            }
            makeFirstAndLastNameOnlyMandatory();
            return;
        }

        if($("#_guest_firstName_id").val() == "" && $("#_guest_lastName_id").val() == "") {
            makeFirstAndLastNameOptional();
        }
        return;
    })
}

function makeFirstAndLastNameOnlyMandatory() {
    $("#_guest_firstName_id").addClass("required");
    $("#_guest_lastName_id").addClass("required");
    $("#_guest_companyName_id").removeClass("required");
    $("#_guest_firstName_id_label").html("Guest First Name <span class='red'>*</span>")
    $("#_guest_lastName_id_label").html("Guest Last Name <span class='red'>*</span>")
    $("#_guest_companyName_id_label").html("Guest Company Name")
    return;
}

function makeFirstAndLastNameOptional() {
    $("#_guest_firstName_id").removeClass("required");
    $("#_guest_lastName_id").removeClass("required");
    $("#_guest_companyName_id").addClass("required");
    $("#_guest_firstName_id_label").html("Guest First Name")
    $("#_guest_lastName_id_label").html("Guest Last Name")
    $("#_guest_companyName_id_label").html("Guest Company Name <span class='red'>*</span>")
}

function updateFields() {
    if ($("#_vehicleRentalDetail_isExtraDriverNeeded_id").is(":checked")) {
    	enableOrDisableFields("");
    	$('#additionalDriverDetailDiv').show();        
    }else{
    	enableOrDisableFields("disabled");
        $('#additionalDriverDetailDiv').hide();        
    }
}

function enableOrDisableFields(enableOrDisable) {
    $(".enableDisable").each(function(index, element) {
        enableOrDisableField(element, enableOrDisable);
    })
}

function enableOrDisableField(elementId, enableOrDisable) {
    $(elementId).attr('disabled', enableOrDisable);
}

function maskEveryThingExceptLast4Chars(field) {
    var originalValue = $(field).val();
    var lengthToReplace = originalValue.length - 4;
    var maskedString = "";
    for(var i=0; i < lengthToReplace; i++) {
        maskedString += "X";
    }
    $(field).val(maskedString + originalValue.substring(lengthToReplace));
}
