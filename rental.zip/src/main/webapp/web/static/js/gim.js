function constructGIMUrl(gimBasePath, gimActionId, appReturnURL, userStoreNumber, gimGuestAccountId, gimGuestAccountAddressId, callback){
	var gim_destination_url = gimBasePath + '/start?GimActionId=' + gimActionId + '&amp;returnAddress=' + appReturnURL + 
		'&amp;userTypeId=20&amp;sourceId=31&amp;storeNumber=' + userStoreNumber + '&amp;inputDeviceId=2&amp;internalCompanyId=1';
	
	if( gimGuestAccountId.length > 0 ){
		gim_destination_url += '&amp;guestAccountId=' + gimGuestAccountId;
	}

	if( gimGuestAccountAddressId.length > 0 ){
		gim_destination_url += '&amp;guestAccountAddressId=' + gimGuestAccountAddressId;
	}

	callback(gim_destination_url);
}


